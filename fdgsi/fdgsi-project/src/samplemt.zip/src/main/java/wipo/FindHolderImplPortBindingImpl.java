package wipo;

import javax.xml.ws.Action;


@javax.jws.WebService (endpointInterface="wipo.FindHolder", targetNamespace="http://wipo/", serviceName="FindHolderImplService", portName="FindHolderImplPort")
public class FindHolderImplPortBindingImpl{

    public HolderInfo retreiveHolderRequest(String applicationRegistrationNumber) {
        // TODO Auto-generated method stub
        return null;
    }

}