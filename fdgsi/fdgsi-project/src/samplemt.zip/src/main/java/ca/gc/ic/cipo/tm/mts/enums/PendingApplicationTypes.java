package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;

public enum PendingApplicationTypes {

    // @formatter:off

    MADRID_PENDING_APPLICATION_TYPES(
        TradeMarkStatusType.PRE_FORMALIZED,
        TradeMarkStatusType.FORMALIZED,
        TradeMarkStatusType.DEFAULT_SEARCHED,
        TradeMarkStatusType.APPROVED,
        TradeMarkStatusType.ADVERTISED,
        TradeMarkStatusType.OPPOSED,
        TradeMarkStatusType.ALLOWED,
        TradeMarkStatusType.REGISTRATION_PENDING,
        TradeMarkStatusType.DEFAULT_ALLOWED,
        TradeMarkStatusType.SEARCHED,
        TradeMarkStatusType.DEFAULT_PRE_FORMALIZED,
        TradeMarkStatusType.DEFAULT_FORMALIZED,
        TradeMarkStatusType.REFUSED_AWAITING_APPEAL,
        TradeMarkStatusType.REFUSED_APPEAL_IN_PROGRESS);

    // @formatter:on
    // TODO waiting for this to be added to intrepid - TradeMarkStatusType.REGISTRATION_PENDING,

    private final Set<TradeMarkStatusType> pendingTransactionStatus;

    private PendingApplicationTypes(TradeMarkStatusType... pendingTransactionStatus) {
        this.pendingTransactionStatus = EnumSet.copyOf(Arrays.asList(pendingTransactionStatus));
    }

    public Set<TradeMarkStatusType> getPendingTransactionStatus() {
        return pendingTransactionStatus;
    }

    public Boolean isPendingStatus(TradeMarkStatusType status) {

        if (getPendingTransactionStatus().contains(status)) {
            return true;
        }
        return false;
    }
}
