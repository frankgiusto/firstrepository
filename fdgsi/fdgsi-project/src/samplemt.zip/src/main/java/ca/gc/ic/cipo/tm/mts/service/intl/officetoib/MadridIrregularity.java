package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridIrregularityResponseType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public class MadridIrregularity extends OfficeToIbBase implements IOutboundTransaction {

    private static Logger log = Logger.getLogger(MadridIrregularity.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_IRREGULARITY;

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        MadridIrregularityResponseType transaction = objectFactory.createMadridIrregularityResponseType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        List<Serializable> list = new ArrayList<Serializable>();
        list.add(outboundTransactionDto.getIntlRegNo());
        IdentifierType idType = new IdentifierType();
        idType.setValue(outboundTransactionDto.getIntlRecordId());

        list.add(idType);

        // International Registration Number and Record ID
        transaction.getInternationalRegistrationNumberOrBasicRegistrationApplicationBagOrRecordIdentifier()
            .addAll(list);

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(new Timestamp(System.currentTimeMillis())));

        // Response Text
        JAXBElement<String> responseText = objectFactory.createResponseText(outboundTransactionDto.getResponseText());
        transaction.getFileNameOrResponseTextOrDocumentIncludedBag().add(responseText);

        JAXBElement<MadridIrregularityResponseType> madridobject = objectFactory
            .createMadridIrregularityResponse(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);

    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {

        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return false;
    }

}
