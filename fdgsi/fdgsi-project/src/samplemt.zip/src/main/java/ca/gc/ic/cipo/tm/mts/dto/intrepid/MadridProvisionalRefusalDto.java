package ca.gc.ic.cipo.tm.mts.dto.intrepid;


public class MadridProvisionalRefusalDto {

}
