package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateResponse;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;

public interface IIbToOfficeProcessingService {

    /**
     * Process transaction.
     *
     * @param transaction the transaction
     * @return the automated process response
     * @throws CIPOServiceFault the CIPO service fault
     */
    AutomatedProcessResponse processTransaction(TransactionRequest transaction) throws CIPOServiceFault;

    /**
     * Process manual transaction.
     *
     * @param transaction the transaction
     * @return the manual process response
     * @throws CIPOServiceFault the CIPO service fault
     */
    ManualProcessResponse processManualTransaction(TransactionRequest transaction) throws CIPOServiceFault;

    /**
     * Process ownership change merger transaction.
     *
     * @param transaction the transaction
     * @return the automated process response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public AutomatedProcessResponse processOwnershipChangeMerger(TransactionPairRequest transaction)
        throws CIPOServiceFault;

    // /**
    // * Gets the representative address.
    // *
    // * @param irTranId the ir tran id
    // * @return the representative address
    // * @throws CIPOServiceFault the CIPO service fault
    // */
    // RepresentativeAddressDto getRepresentativeAddress(BigDecimal irTranId) throws CIPOServiceFault;

    /**
     * Gets the response due date.
     *
     * @param irTranId the ir tran id
     * @return the response due date
     * @throws CIPOServiceFault the CIPO service fault
     */
    ResponseDueDateResponse getResponseDueDate(BigDecimal irTranId) throws CIPOServiceFault;

}
