package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationType;
import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateResponse;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IrregularityDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFileTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReturnCode;
import ca.gc.ic.cipo.tm.mts.enums.InboundTransactionTypes;
import ca.gc.ic.cipo.tm.mts.enums.TransactionCategoryType;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.ICourtesyLetterService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionServiceImpl;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;

@Service
public class InboundTransactionService extends MadridTransactionService implements IIbToOfficeProcessingService {

    protected static final Logger logger = LoggerFactory.getLogger(InboundTransactionService.class);

    @Autowired
    private ApplicationContext appContext;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private IIROwnershipChangeMerger irOwnershipChangeMerger;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private ICourtesyLetterService courtestyLetterService;

    @Autowired
    private ITaskService taskService;

    @Value("#{environment['mts.reporting.service.host.name']}")
    private String reportServiceHost;

    @Value("#{environment['mts.rgs.polling.attempts']}")
    private Integer pollingAttempts;

    protected final static HashMap<String, String> pdfEnFrDate;

    static {
        pdfEnFrDate = new HashMap<String, String>();
        pdfEnFrDate.put("01", "janv/Jan");
        pdfEnFrDate.put("02", "fév/Feb");
        pdfEnFrDate.put("03", "mars/Mar");
        pdfEnFrDate.put("04", "avr/Apr");
        pdfEnFrDate.put("05", "mai/May");
        pdfEnFrDate.put("06", "juin/Jun");
        pdfEnFrDate.put("07", "juil/Jul");
        pdfEnFrDate.put("08", "août/Aug");
        pdfEnFrDate.put("09", "sept/Sep");
        pdfEnFrDate.put("10", "oct/Oct");
        pdfEnFrDate.put("11", "nov/Nov");
        pdfEnFrDate.put("12", "déc/Dec");
    }

    @Override
    public AutomatedProcessResponse processTransaction(TransactionRequest transaction) throws CIPOServiceFault {
        // Ensure that the transaction status is correct
        IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(transaction.getIrTranId());

        // new - Check for Inactive marks for D/O transaction types.
        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(intlIrTran.getIntlPkgTranType().getPkgTranCtgryId());

        if (!intlIrTran.getStatusTypeDto().getStatusCtgry().equals(StatusType.MPS_IMPORT_COMPLETE.name())
            && !intlIrTran.getStatusTypeDto().getStatusCtgry().equals(StatusType.PARTIALLY_PROCESSED.name())) {
            throwMTSServiceFault("mts.process.transaction.state.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        // Check if errors in other transactions with same reg no.
        if (!internationalService.existingIrNumberOk(Arrays.asList(intlIrTran.getIntlRegNo()),
            Arrays.asList(BigDecimal.valueOf(StatusType.PROCESSED_WITH_ERROR.getValue())))) {

            throwMTSServiceFault("mts.ir.number.in.error.state", ExceptionReasonCode.RETRYABLE_ERROR);

        }

        // process OO Transactions with Optional IntlRegNum
        if (transactionCategory == TransactionCategory.MADRID_ABANDONMENT_NOTIFICATION
            || transactionCategory == TransactionCategory.MIR_REGISTRATION) {

            logger.debug(
                "processing OO for transactionCategory " + TransactionCategory.MADRID_ABANDONMENT_NOTIFICATION.name()
                    + " or " + TransactionCategory.MIR_REGISTRATION.name());
            return this.processUnprocessedOOTasksWithOptionalIntlRegNum(intlIrTran, transaction, transactionCategory);
        }

        // process OO Transactions with transaction could have IR number
        if (transactionCategory == TransactionCategory.MDT_TOTAL_CANCELLATION) {
            if (StringUtils.isBlank(intlIrTran.getIntlRegNo()) || (intlIrTran.getIntlRegNo() != null
                && CollectionUtils.isEmpty(intrepidCommonService.getFileNumbers(intlIrTran.getIntlRegNo())))) {

                logger.debug(
                    "processing OO for transactionCategory " + TransactionCategory.MDT_TOTAL_CANCELLATION.name());
                return this.processUnprocessedOOTasksWithOptionalIntlRegNum(intlIrTran, transaction,
                    transactionCategory);
            }
        }

        AutomatedProcessResponse processTransactionResponse = null;

        if (!this.isMadridDesignation(transactionCategory)) {
            if (transactionCategory == TransactionCategory.MCP_NO_CATEGORY) { // Completed Processing

                internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSING);
                processTransactionResponse = this.processTransactionRequest(transaction, intlIrTran);
                internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);

            } else {

                if (intlIrTran.getStatusTypeDto().getStatusCtgry().equals(StatusType.PARTIALLY_PROCESSED.name())) {
                    // check if task is still blocked. if unblocked, then process

                    return this.processWaitingTasks(intlIrTran, transaction);

                } else {

                    return this.processUnprocessedTasks(intlIrTran, transaction, transactionCategory);
                }
            }

        } else {
            // Process transaction - This is for madrid designation only
            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSING);
            processTransactionResponse = this.processTransactionRequest(transaction, intlIrTran);
            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);

            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(
                intrepidCommonService.getApplicationByIrId(intlIrTran.getIntlRegNo(), intlIrTran.getIntlRecordId()),
                OfficeType.DO);

            // Create a task for Holder Contact Details webservice.
            List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
            IntlIrTaskDto holderTask = new IntlIrTaskDto();
            holderTask.setFileNumber(applicationDto.getFileNumber());
            holderTask.setIrNumber(intlIrTran.getIntlRegNo());
            activeTaskList.add(holderTask);

            createContactHolderTask(transaction, transactionCategory, activeTaskList);

        }

        return processTransactionResponse;
    }

    protected AutomatedProcessResponse processUnprocessedOOTasksWithOptionalIntlRegNum(IntlIrTranDto intlIrTran,
                                                                                       TransactionRequest transaction,
                                                                                       TransactionCategory transactionCategory)
        throws CIPOServiceFault {

        AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();
        internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSING);

        processTransactionResponse = this.processTransactionRequest(transaction, intlIrTran);
        internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);

        return processTransactionResponse;
    }

    private void createContactHolderTask(TransactionRequest transaction, TransactionCategory transactionCategory,
                                         List<IntlIrTaskDto> activeTaskList) {

        if (transactionCategory == TransactionCategory.MD_REGISTRATION
            || transactionCategory == TransactionCategory.MD_SUBSEQUENT_DESIGNATION
            || transactionCategory == TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION
            || transactionCategory == TransactionCategory.DESIGNATION_TERMINATION
            || transactionCategory == TransactionCategory.MHR_CHANGE_OF_OWNER
            || transactionCategory == TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS) {

            ConsoleTaskList consoleTaskList = new ConsoleTaskList();

            for (IntlIrTaskDto intlIrTaskDto : activeTaskList) {
                ConsoleTaskMeta consoleTaskMeta = new ConsoleTaskMeta();

                consoleTaskMeta.setFileNumber(BigDecimal.valueOf(intlIrTaskDto.getFileNumber()));
                consoleTaskMeta.setExtensionCounter("0");
                consoleTaskMeta.setOfficeType(OfficeType.DO.name());
                consoleTaskMeta.getTransactionIds().add(transaction.getIrTranId());
                consoleTaskMeta.setIrNumber(intlIrTaskDto.getIrNumber());
                consoleTaskMeta.setUserTaskStatus(TaskStatusType.UNPROCESSED.getValue());
                consoleTaskMeta.setUserTaskType(UserTaskType.HOLDER_CONTACT_DETAILS_TASK.getValue());
                consoleTaskList.getTaskListBag().add(consoleTaskMeta);
            }
            taskService.createUserTask(consoleTaskList);
        }
    }

    private AutomatedProcessResponse processUnprocessedTasks(IntlIrTranDto intlIrTran, TransactionRequest transaction,
                                                             TransactionCategory transactionCategory)
        throws CIPOServiceFault {

        AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();

        List<ConsoleTaskResponse> inactiveMarkList = new ArrayList<>();

        // update international transaction status to "Processing".
        internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSING);

        // Get Active Marks and store
        List<Integer> lockedFileList = intrepidCommonService.checkforMarks(intlIrTran.getIntlRegNo(),
            transaction.getIrTranId());

        List<IntlIrTaskDto> taskList = taskService.getTasksByTransactionId(transaction.getIrTranId());

        // Create an "in progress" intrepid email whether we are processing task now or transaction is partially
        // processed.
        intrepidCommonService.createMailInProgress(taskList, intlIrTran.getIrTranId());

        // Check for any blockers for File / IR ie active console tasks that are not Automated
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        boolean partialyProcessed = false;
        for (IntlIrTaskDto intlIrTaskDto : taskList) {
            if (intlIrTaskDto.getTaskTypeDto().getTaskCtgry().equals(UserTaskType.AUTOMATED_TASK.name())
                && intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.UNPROCESSED
                    .getValue().intValue()) {

                if (lockedFileList.contains(intlIrTaskDto.getFileNumber())) {
                    if (hasActiveTasks(transaction.getIrTranId(), intlIrTaskDto)) {
                        // we have a transaction containing an active task for this IR, File Number, so we don't
                        // process transaction.
                        internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.WAITING);
                        partialyProcessed = true;
                        continue;
                    }

                    activeTaskList.add(intlIrTaskDto);
                } else {
                    // No lock acquired
                    partialyProcessed = true;
                    continue;
                }

            } else if (intlIrTaskDto.getTaskTypeDto().getTaskCtgry().equals(UserTaskType.AUTOMATED_TASK.name())
                && intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.ON_HOLD
                    .getValue().intValue()) {

                partialyProcessed = true;
            }
        }

        if (transactionCategory != TransactionCategory.MIR_REGISTRATION) {

            inactiveMarkList = intrepidCommonService.checkforInactiveMarks(intlIrTran.getIntlRegNo(),
                transaction.getIrTranId());

        }

        if (activeTaskList.size() > 0) {
            intlIrTran.setLockedFileList(lockedFileList);
            intlIrTran.setIntlIrTaskList(activeTaskList);

            // Set locked files so they can be released in case of exception
            MadridTransactionServiceImpl.LOCKED_FILES.set(lockedFileList);

            // Process transaction
            processTransactionResponse = this.processTransactionRequest(transaction, intlIrTran);
        } else if (partialyProcessed) {
            // resolve TMPOSTCIF-384
            sendAttachmentsToIntrepidNfs(intlIrTran, new HashMap<ApplicationDto, UserTaskType>(), transactionCategory,
                false);
        }

        // Release locks on applications
        intrepidCommonService.unlockApplicationForTasks(lockedFileList);

        // Create tasks for Contact Holder Details update process
        createContactHolderTask(transaction, transactionCategory, activeTaskList);

        processTransactionResponse.getConsoleTaskBag().addAll(inactiveMarkList);

        // Update Task Status to processed.
        for (IntlIrTaskDto task : activeTaskList) {

            internationalService.updateTaskStatus(task.getTaskId(), TaskStatusType.PROCESSED);
        }

        if (partialyProcessed) {
            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PARTIALLY_PROCESSED);
        } else {
            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);
        }
        return processTransactionResponse;
    }

    private AutomatedProcessResponse processWaitingTasks(IntlIrTranDto intlIrTran, TransactionRequest transaction)
        throws CIPOServiceFault {

        // get all tasks in a WAITING state. Check if task is still blocked. If unblocked, then process

        List<IntlIrTaskDto> taskList = taskService.getTasksByTransactionId(transaction.getIrTranId());
        List<Integer> lockedFileList = new ArrayList<>();

        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();
        boolean partialyProcessed = false;

        for (IntlIrTaskDto intlIrTaskDto : taskList) {
            if (intlIrTaskDto.getTaskTypeDto().getTaskCtgry().equals(UserTaskType.AUTOMATED_TASK.name())
                && (intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.UNPROCESSED
                    .getValue().intValue()
                    || intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.WAITING
                        .getValue().intValue())) {

                // Attempt to lock Application
                if (intrepidCommonService.lockApplicationForTask(intlIrTaskDto.getFileNumber())) {
                    lockedFileList.add(intlIrTaskDto.getFileNumber());

                    if (hasActiveTasks(transaction.getIrTranId(), intlIrTaskDto)) {
                        // we have a transaction containing an active task for this IR, File Number, so we don't
                        // process transaction.
                        internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.WAITING);
                        partialyProcessed = true;
                        continue;
                    }
                    internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.UNPROCESSED);
                    activeTaskList.add(intlIrTaskDto);
                } else {
                    internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.WAITING);
                    partialyProcessed = true;
                    continue;
                }
            }
        }
        if (activeTaskList.size() > 0) {
            intlIrTran.setIntlIrTaskList(activeTaskList);
            intlIrTran.setLockedFileList(lockedFileList);

            // Process transaction
            processTransactionResponse = this.processTransactionRequest(transaction, intlIrTran);

            // Update Task Status to processed.

            for (IntlIrTaskDto task : activeTaskList) {

                internationalService.updateTaskStatus(task.getTaskId(), TaskStatusType.PROCESSED);
            }

            if (!partialyProcessed) {
                internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);
            }
        }
        // Release locks on applications
        intrepidCommonService.unlockApplicationForTasks(lockedFileList);

        return processTransactionResponse;
    }

    /**
     * Checks for active tasks. We are looking for other transactions with the same IR Number contained in the inbound
     * transaction having a record effective date older than that of the transaction. If we find one, we don't process
     * the transaction.
     *
     * @param irTranId the ir tran id
     * @param fileNumber the file number
     * @return true, if we find an active task as explained above
     */
    private boolean hasActiveTasks(BigDecimal irTranId, IntlIrTaskDto intlIrTaskDto) {

        IntlIrTranDto intlIrTranDto = internationalService.getTransactionsByIrTranId(irTranId);

        if (null == intlIrTranDto.getIntlRecordEfctvDt()) {
            logger.error("Transaction does not have an international effective date!!!!: tran id: " + irTranId);
            return true;
        }

        List<BigDecimal> activeTransactionsTasks = internationalService.getTransactionsHavingActiveTasks(
            intlIrTranDto.getIntlRegNo(), BigDecimal.valueOf(intlIrTaskDto.getFileNumber()), intlIrTaskDto.getTaskId(),
            intlIrTranDto.getIntlRecordEfctvDt());
        if (CollectionUtils.isNotEmpty(activeTransactionsTasks)) {
            for (BigDecimal activeTransaction : activeTransactionsTasks) {
                logger.debug("Transaction processing ignored. Active task for transaction found for taskId:"
                    + intlIrTaskDto.toString() + " TransactionId:" + activeTransaction);
            }
            return true;
        }
        return false;
    }

    private boolean isMadridDesignation(TransactionCategory transactionCategory) {

        if (transactionCategory != TransactionCategory.MD_REGISTRATION
            && transactionCategory != TransactionCategory.MD_SUBSEQUENT_DESIGNATION) {
            return false;
        }
        return true;
    }

    @Override
    public AutomatedProcessResponse processOwnershipChangeMerger(TransactionPairRequest transaction)
        throws CIPOServiceFault {

        IntlIrTranDto pairedTransaction = internationalService.getTransactionsByIrTranId(transaction.getIrTranId());
        IntlIrTranDto designationTransaction = internationalService
            .getTransactionsByIrTranId(transaction.getAssociatedIrTranId());

        TransactionPairDto ownershipChangeMerger = new TransactionPairDto();
        ownershipChangeMerger.setMadridDesignationTransaction(designationTransaction);
        ownershipChangeMerger.setPairedTransaction(pairedTransaction);
        ownershipChangeMerger.setPairedTransactionType(TransactionCategory.getTransactionCategoryByValue(
            BigDecimal.valueOf(pairedTransaction.getIntlPkgTranType().getPkgTranCtgryId().intValue())));

        if (pairedTransaction.getStatusTypeDto().getStatusCtgry().equals(StatusType.PARTIALLY_PROCESSED.name())) {
            // check if task is still blocked. if unblocked, then process
            return this.partialProcessMerger(ownershipChangeMerger);
        } else {

            // Get Active Marks and store
            return this.unprocessedMerger(ownershipChangeMerger);
        }

    }

    private AutomatedProcessResponse unprocessedMerger(TransactionPairDto ownershipChangeMerger)
        throws CIPOServiceFault {

        List<ConsoleTaskResponse> inactiveMarkList = null;
        AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();

        List<Integer> lockedFileList = intrepidCommonService.checkforMarks(
            ownershipChangeMerger.getPairedTransaction().getIntlRegNo(),
            ownershipChangeMerger.getPairedTransaction().getIrTranId());

        List<IntlIrTaskDto> taskListTermination = taskService
            .getTasksByTransactionId(ownershipChangeMerger.getPairedTransaction().getIrTranId());

        // Check for any blockers for File / IR ie active console tasks that are not Automated
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        boolean partialyProcessed = false;
        for (IntlIrTaskDto intlIrTaskDto : taskListTermination) {
            if (intlIrTaskDto.getTaskTypeDto().getTaskCtgry().equals(UserTaskType.AUTOMATED_TASK.name())
                && intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.UNPROCESSED
                    .getValue().intValue()) {

                // Continue if locked
                if (lockedFileList.contains(intlIrTaskDto.getFileNumber())) {

                    if (hasActiveTasks(ownershipChangeMerger.getPairedTransaction().getIrTranId(), intlIrTaskDto)) {
                        // we have a transaction containing an active task for this IR, File Number, so we don't
                        // process transaction.
                        internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.WAITING);
                        partialyProcessed = true;
                        continue;
                    }

                    activeTaskList.add(intlIrTaskDto);
                } else {
                    partialyProcessed = true;
                    continue;
                }

            } else if (intlIrTaskDto.getTaskTypeDto().getTaskCtgry().equals(UserTaskType.AUTOMATED_TASK.name())
                && intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.ON_HOLD
                    .getValue().intValue()) {

                partialyProcessed = true;
            }
        }

        inactiveMarkList = intrepidCommonService.checkforInactiveMarks(
            ownershipChangeMerger.getPairedTransaction().getIntlRegNo(),
            ownershipChangeMerger.getPairedTransaction().getIrTranId());

        if (activeTaskList.size() > 0) {
            ownershipChangeMerger.setIntlIrTaskList(activeTaskList);
            ownershipChangeMerger.setLockedFileList(lockedFileList);
            // Process transaction
            processTransactionResponse = this.processOwnershipChangeMergerTransaction(ownershipChangeMerger);

        }
        // Release locks on applications
        intrepidCommonService.unlockApplicationForTasks(lockedFileList);

        processTransactionResponse.getConsoleTaskBag().addAll(inactiveMarkList);

        // Update Task Status to processed.
        for (IntlIrTaskDto task : activeTaskList) {

            internationalService.updateTaskStatus(task.getTaskId(), TaskStatusType.PROCESSED);
        }

        if (partialyProcessed) {
            internationalService.updateTransactionStatus(
                ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId(), StatusType.PARTIALLY_PROCESSED);
            internationalService.updateTransactionStatus(ownershipChangeMerger.getPairedTransaction().getIrTranId(),
                StatusType.PARTIALLY_PROCESSED);
        } else {
            internationalService.updateTransactionStatus(
                ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId(), StatusType.PROCESSED);
            internationalService.updateTransactionStatus(ownershipChangeMerger.getPairedTransaction().getIrTranId(),
                StatusType.PROCESSED);
        }
        return processTransactionResponse;
    }

    private AutomatedProcessResponse partialProcessMerger(TransactionPairDto ownershipChangeMerger)
        throws CIPOServiceFault {

        List<IntlIrTaskDto> taskListAll = taskService
            .getTasksByTransactionId(ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId());
        List<IntlIrTaskDto> taskListOther = taskService
            .getTasksByTransactionId(ownershipChangeMerger.getPairedTransaction().getIrTranId());
        taskListAll.addAll(taskListOther);

        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        List<Integer> lockedFileList = new ArrayList<>();

        boolean partialyProcessed = false;
        AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();

        for (IntlIrTaskDto intlIrTaskDto : taskListAll) {
            if (intlIrTaskDto.getTaskTypeDto().getTaskCtgry().equals(UserTaskType.AUTOMATED_TASK.name())
                && (intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.UNPROCESSED
                    .getValue().intValue()
                    || intlIrTaskDto.getTaskStatusTypeDto().getTaskStatusCtgryId().intValue() == TaskStatusType.WAITING
                        .getValue().intValue())) {

                // Attempt to lock Application
                if (intrepidCommonService.lockApplicationForTask(intlIrTaskDto.getFileNumber())) {
                    lockedFileList.add(intlIrTaskDto.getFileNumber());

                    if (hasActiveTasks(ownershipChangeMerger.getPairedTransaction().getIrTranId(), intlIrTaskDto)) {
                        // we have a transaction containing an active task for this IR, File Number, so we don't
                        // process transaction.
                        internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.WAITING);
                        partialyProcessed = true;
                        continue;
                    }
                    internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.UNPROCESSED);
                    activeTaskList.add(intlIrTaskDto);
                } else {
                    internationalService.updateTaskStatus(intlIrTaskDto.getTaskId(), TaskStatusType.WAITING);
                    partialyProcessed = true;
                    continue;
                }
            }
        }
        if (activeTaskList.size() > 0) {
            ownershipChangeMerger.setIntlIrTaskList(internationalDTOFactory.fileNumberToTaskDtoList(lockedFileList,
                ownershipChangeMerger.getPairedTransaction().getIntlRegNo()));

            // Process transaction
            processTransactionResponse = this.processOwnershipChangeMergerTransaction(ownershipChangeMerger);

            // Update Task Status to processed.

            for (IntlIrTaskDto task : activeTaskList) {

                internationalService.updateTaskStatus(task.getTaskId(), TaskStatusType.PROCESSED);
            }

            if (!partialyProcessed) {
                internationalService.updateTransactionStatus(
                    ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId(), StatusType.PROCESSED);
                internationalService.updateTransactionStatus(ownershipChangeMerger.getPairedTransaction().getIrTranId(),
                    StatusType.PROCESSED);
            }
        }
        // Release locks on applications
        intrepidCommonService.unlockApplicationForTasks(lockedFileList);

        return processTransactionResponse;
    }

    private AutomatedProcessResponse processOwnershipChangeMergerTransaction(TransactionPairDto ownershipChangeMerger)
        throws CIPOServiceFault {

        AutomatedProcessResponse madridTransactionServiceResponse = new AutomatedProcessResponse();

        Map<ApplicationDto, UserTaskType> statusTypeResults = null;

        // update international trans status to "Processing".
        internationalService.updateTransactionStatus(
            ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId(), StatusType.PROCESSING);

        internationalService.updateTransactionStatus(ownershipChangeMerger.getPairedTransaction().getIrTranId(),
            StatusType.PROCESSING);

        try {
            statusTypeResults = irOwnershipChangeMerger.processIRChangeOwnershipMerger(ownershipChangeMerger);
        } catch (Exception exception) {

            // Release locks on applications
            intrepidCommonService.unlockApplicationForTasks(ownershipChangeMerger.getLockedFileList());

            if (exception instanceof MTSServiceFault) {
                // processing designation error.
                try {
                    internationalService.updateTransactionStatus(
                        ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId(),
                        StatusType.PROCESSED_WITH_ERROR);
                    internationalService.updateTransactionStatus(
                        ownershipChangeMerger.getPairedTransaction().getIrTranId(), StatusType.PROCESSED_WITH_ERROR);
                } catch (Exception e) {
                    logger.error("Could not set International transaction status to 'PROCESSED_WITH_ERROR' !", e);
                }
                logger.error("Error processing transaction!", exception);
                throwCIPOFault(exception, ((MTSServiceFault) exception).getFaultInfo());
            }
            throwCIPOFault(exception);
        }

        List<ConsoleTaskResponse> consoleTaskResults = taskService
            .getUserTaskInformation(ownershipChangeMerger.getPairedTransaction().getIrTranId(), statusTypeResults);
        madridTransactionServiceResponse.getConsoleTaskBag().addAll(consoleTaskResults);

        consoleTaskResults = taskService.getUserTaskInformation(
            ownershipChangeMerger.getMadridDesignationTransaction().getIrTranId(),
            new HashMap<ApplicationDto, UserTaskType>());
        madridTransactionServiceResponse.getConsoleTaskBag().addAll(consoleTaskResults);

        return madridTransactionServiceResponse;

    }

    private AutomatedProcessResponse processTransactionRequest(TransactionRequest transactionRequest,
                                                               IntlIrTranDto intlIrTran)
        throws CIPOServiceFault {

        IntlIrTranDto intlIrTransaction = internationalService
            .getTransactionsByIrTranId(transactionRequest.getIrTranId());
        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(intlIrTransaction.getIntlPkgTranType().getPkgTranCtgryId());

        AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();
        Map<ApplicationDto, UserTaskType> notifications = null;

        // What type of transaction are we processing. Get the bean that process this type of transaction
        TransactionCategoryType transactionType = ca.gc.ic.cipo.tm.mts.enums.TransactionCategoryType
            .fromSpecificType(transactionCategory);

        IInboundTransaction inboundTransaction = null;
        try {
            inboundTransaction = (IInboundTransaction) appContext
                .getBean(InboundTransactionTypes.valueOf(transactionType.name()).getInboundTransactionId());
        } catch (Exception e) {
            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED_WITH_ERROR);
            throwMTSServiceFault("mts.not.yet.implemented", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        Object xmlTransaction = null;
        List<ConsoleTaskResponse> consoleTaskResults = null;
        try {
            xmlTransaction = unmarshallTransaction(intlIrTran);
        } catch (Exception exception) {
            throwCIPOFault(exception);
        }

        // Process transaction which updates the Intrepid database.
        notifications = inboundTransaction.processInboundTransaction(intlIrTran, xmlTransaction);

        logger.debug("Transaction processed sucessfully.");

        if (this.isMadridDesignation(transactionCategory)) {
            Set<ApplicationDto> keySet = notifications.keySet();
            Iterator<ApplicationDto> iterator = keySet.iterator();

            if (iterator.hasNext()) {
                ApplicationDto appDto = iterator.next();
                try {
                    // remove lock created by stored proc "get_next_file_number".
                    intrepidCommonService.releaseTrademarkLock(appDto.getFileNumber(), -99);
                } catch (Exception e) {
                    logger.warn("Cannot release next file number lock for file " + appDto.getFileNumber().intValue());
                }
            }
        }

        // Send attachment to intrepid
        if (intlIrTransaction.getIntlRegNo() != null && (intlIrTransaction.getStatusTypeDto().getStatusCtgryId()
            .intValue() != StatusType.PARTIALLY_PROCESSED.getValue().intValue())) {
            sendAttachmentsToIntrepidNfs(intlIrTransaction, notifications, transactionCategory, false);
        }

        consoleTaskResults = taskService.getUserTaskInformation(intlIrTransaction.getIrTranId(), notifications);

        // Create console task and a courtesy letter
        // isRequiredCreateCourtesyLetter(intlIrTransaction, notifications);

        processTransactionResponse.getConsoleTaskBag().addAll(consoleTaskResults);

        try {
            // processing courtesy letter
            courtestyLetterService.processCourtesyLetter(intlIrTransaction, notifications, transactionCategory);

            // change task status to processed if its REPRESENTATIVE_COURTESY_LETTER
            for (ConsoleTaskResponse response : consoleTaskResults) {
                BigDecimal taskId = response.getConsoleTaskId();
                int typeId = response.getUserTaskType();

                if (typeId == UserTaskType.REPRESENTATIVE_COURTESY_LETTER.getValue()) {
                    internationalService.updateTaskStatus(taskId, TaskStatusType.PROCESSED);
                }
            }
        } catch (Exception e) {
            logger.error("Error process courtesy letter", e);
            throwCIPOFault(e);
        }

        return processTransactionResponse;
    }

    @Override
    public ManualProcessResponse processManualTransaction(TransactionRequest transaction) throws CIPOServiceFault {

        ManualProcessResponse processTransactionResponse = new ManualProcessResponse();

        IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(transaction.getIrTranId());
        intlIrTran.setOfficeType(OfficeType.DO); // default

        // Verify that this is a manual transaction

        if (!MadridTransactionType.getManualTransactionCategories().contains(
            TransactionCategory.getTransactionCategoryByValue(intlIrTran.getIntlPkgTranType().getPkgTranCtgryId()))) {

            throwMTSServiceFault("mts.invalid.transaction.category", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(intlIrTran.getIntlPkgTranType().getPkgTranCtgryId());

        List<ConsoleTaskResponse> inactiveMarkList = new ArrayList<>();

        boolean irregularityOO = false;
        if (transactionCategory == TransactionCategory.MI_IRREGULARITY_NOTIFICATION) {
            IrregularityDto irregularityDto = internationalService.getIrregularityInbound(intlIrTran);
            if (irregularityDto != null && irregularityDto.getOfficeType() == OfficeType.OO) {
                irregularityOO = true;
                intlIrTran.setOfficeType(OfficeType.OO);
            }

            intlIrTran.setIrregularityDto(irregularityDto);
        }

        List<Integer> fileNumberList = new ArrayList<>();
        if (!irregularityOO) {
            if (transactionCategory != TransactionCategory.MI_IRREGULARITY_NOTIFICATION) {
                inactiveMarkList = intrepidCommonService.checkforInactiveMarks(intlIrTran.getIntlRegNo(),
                    transaction.getIrTranId());
            }

            fileNumberList = intrepidCommonService.getLockedIntrepidFiles(intlIrTran.getIntlRegNo());
        }
        AutomatedProcessResponse automatedProcessResponse = new AutomatedProcessResponse();

        // set the list to the transaction we are processing.
        if (CollectionUtils.isNotEmpty(fileNumberList) || irregularityOO) {

            // original: update international transaction status to "Processing".
            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSING);

            intlIrTran.setLockedFileList(fileNumberList);
            intlIrTran.setIntlIrTaskList(
                internationalDTOFactory.fileNumberToTaskDtoList(fileNumberList, intlIrTran.getIntlRegNo()));

            automatedProcessResponse = this.processTransactionRequest(transaction, intlIrTran);

            // Release locks on applications
            if (!irregularityOO) {
                intrepidCommonService.unlockApplicationForTasks(fileNumberList);
            }

            intrepidCommonService.createMailInProgress(intlIrTran.getIntlIrTaskList(), intlIrTran.getIrTranId());
            processTransactionResponse.getConsoleTaskBag().addAll(automatedProcessResponse.getConsoleTaskBag());

            processTransactionResponse.getConsoleTaskBag().addAll(inactiveMarkList);

            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);
        }

        List<ConsoleTaskResponse> clist = automatedProcessResponse.getConsoleTaskBag();
        logger.debug("Console tasks sent to MWE");
        for (ConsoleTaskResponse task : clist) {
            logger.debug("Console Id:" + task.getConsoleTaskId() + ", Task Type:" + task.getUserTaskType()
                + ", Authority:" + task.getConsoleTaskGroupId());
        }

        return processTransactionResponse;
    }

    /**
     *
     * Store designs and/or electronic representations in the folder structure
     *
     * @param intlIrTran
     * @param notifications
     * @param transactionCategory
     * @param courtesyLetterOnly
     * @throws MTSServiceFault
     */
    private void sendAttachmentsToIntrepidNfs(IntlIrTranDto intlIrTran, Map<ApplicationDto, UserTaskType> notifications,
                                              TransactionCategory transactionCategory, boolean courtesyLetterOnly)
        throws MTSServiceFault {

        Set<ApplicationDto> applicationDto = null;

        if (notifications.isEmpty()) {
            applicationDto = intrepidCommonService.getIntrepidFiles(intlIrTran).keySet();
        } else {
            applicationDto = notifications.keySet();
        }

        Iterator<ApplicationDto> iterator = applicationDto.iterator();
        Integer preFileNumber = 0;
        String preExtensionCounter = "";
        Integer curFileNumber = 0;
        String curExtensionCounter = "";

        while (iterator.hasNext()) {
            ApplicationDto intrepidApplication = iterator.next();

            if (null != intrepidApplication.getFileNumber()) {
                ApplicationDto application = intrepidCommonService
                    .getApplication(Integer.valueOf(intrepidApplication.getFileNumber()));

                if (application != null) {
                    curFileNumber = intrepidApplication.getFileNumber();
                    curExtensionCounter = intrepidApplication.getExtensionCounter();

                    // make sure for the same file number only sending once
                    if ((curFileNumber != null) && (curFileNumber.intValue() == preFileNumber.intValue())
                        && (curExtensionCounter != null) && (curExtensionCounter.equals(preExtensionCounter))) {
                        continue;
                    } else {
                        preFileNumber = curFileNumber;
                        preExtensionCounter = curExtensionCounter;
                    }

                    boolean markIsStandardCharacters = (application.getTradeMarkType()
                        .intValue() == TradeMarkType.STANDARD_CHARACTERS.getValue());

                    // If the Trade_Mark_Type is being set to Standard Character (previous item) and ViennaCategory and
                    // ViennaDivision of 28 and 11 respectively existed, do not load the Design/Image file for this mark
                    if (markIsStandardCharacters) {
                        internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                            BigDecimal.valueOf(curFileNumber), curExtensionCounter,
                            NfsFileTypeDto.STANDARD_CHARACTERS_ONLY);
                    } else {
                        internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                            BigDecimal.valueOf(curFileNumber), curExtensionCounter, NfsFileTypeDto.OTHERS);
                    }
                }
            }

        }

    }

    @Override
    public ResponseDueDateResponse getResponseDueDate(BigDecimal irTranId) throws CIPOServiceFault {

        ResponseDueDateResponse response = new ResponseDueDateResponse();

        IntlIrTranDto intlIrTransaction = internationalService.getTransactionsByIrTranId(irTranId);

        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(intlIrTransaction.getIntlPkgTranType().getPkgTranCtgryId());

        if (transactionCategory == null || transactionCategory != TransactionCategory.MI_IRREGULARITY_NOTIFICATION) {
            ServiceFaultDetails serviceFaultDetails = this.setServiceDetails("mts.invalid.transaction.category",
                ExceptionReasonCode.SYSTEM_ERROR, ExceptionReturnCode.FATAL);
            throw new MTSServiceFault("Service Fault - getResponseDueDate: ", serviceFaultDetails);
        }

        // unmarshel the xml to get the response date
        MadridIrregularityNotificationType xmlTransaction;
        try {
            xmlTransaction = unmarshallTransaction(intlIrTransaction);
            String responseDateStr = xmlTransaction.getResponseDueDate();
            Date responseDate = DateFormats.getISOSDF().parse(responseDateStr);
            if (responseDate == null) {
                ServiceFaultDetails serviceFaultDetails = this.setServiceDetails(
                    "mts.irregularity.transaction.date.invalid", ExceptionReasonCode.RETRYABLE_ERROR,
                    ExceptionReturnCode.FATAL);
                throw new MTSServiceFault("Service Fault - getResponseDueDate: ", serviceFaultDetails);
            }

            response.setResponseDueDate(responseDate);

        } catch (Exception e) {
            throwCIPOFault(e);
        }
        return response;
    }

}
