package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.Blob;

import ca.gc.ic.cipo.tm.intl.enumerator.IntlAtchmtTypeCode;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;

public interface IOutboundTransactionService {

    /**
     * Creates the outbound transaction. This is exposed as a web service operation for processing a collection of
     * process actions that will create outbound transactions.
     *
     * @param processActionsMeta the process actions meta
     * @param outboundTransactionDto the outbound transaction dto
     * @return void
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OfficeToIbTransactionResponse createAutoOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                       OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault;

    /**
     * Creates the outbound transaction. This is exposed as a web service operation for processing a collection of
     * process actions that will create outbound transactions.
     *
     * @param processActionsMeta the process actions meta
     * @param outboundTransactionDto the outbound transaction dto
     * @return void
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OfficeToIbTransactionResponse createManualOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                         OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault;

    /**
     * Creates the outbound transaction. This method is called internally within MTS for individual requests to create
     * outbound transactions.
     *
     * @param outboundTransactionRequest the outbound transaction request
     * @param outboundTransactionDto the outbound transaction dto
     * @return the office to ib transaction response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OfficeToIbTransactionResponse createAutoOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                       OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault;

    /**
     * Creates the outbound transaction. This method is called internally within MTS for individual requests to create
     * outbound transactions.
     *
     * @param processActionsMeta the process actions meta
     * @param outboundTransactionRequest the outbound transaction request
     * @param outboundTransactionDto the outbound transaction dto
     * @return the office to ib transaction response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OfficeToIbTransactionResponse createAutoOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                       OutboundTransactionRequest outboundTransactionRequest,
                                                                       OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault;

    /**
     * Creates the outbound transaction. This method is called internally within MTS for individual requests to create
     * outbound transactions.
     *
     * @param outboundTransactionRequest the outbound transaction request
     * @param outboundTransactionDto the outbound transaction dto
     * @return the office to ib transaction response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OfficeToIbTransactionResponse createManualOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                         OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault;

    /**
     * Updates the outbound transaction. This method is called internally within MTS for individual requests to create
     * outbound transactions.
     *
     * @param manualReport the manual report request object
     * @param outboundTransactionRequest the outbound transaction request
     * @param outboundTransactionDto the outbound transaction dto
     * @return the office to ib transaction response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OfficeToIbTransactionResponse updateManualOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                         OutboundTransactionDto outboundTransactionDto,
                                                                         ProcessManualReportRequest manualReport)
        throws CIPOServiceFault;

    /**
     * Update Transaction XML and transaction status
     *
     * @param xmlOutputStream
     * @param transactionDto
     * @param transactionStatus
     * @throws CIPOServiceFault
     */

    public void updateTransactionXMLWithStatus(ByteArrayOutputStream xmlOutputStream, IntlIrTranDto transactionDto,
                                               StatusType transactionStatus)
        throws CIPOServiceFault;

    /**
     * Creates the console task. Used in cases were a process action requires a Manual task for the madrid console.
     *
     * @param processActionsMeta the process actions meta
     * @param irTranId the ir tran id
     * @param oppCaseNum
     * @return task ids
     */
    public ManualProcessResponse createConsoleTask(ProcessActionsMeta processActionsMeta, BigDecimal irTranId,
                                                   Integer oppCaseNum);

    /**
     * Creates an attachment for a transaction. This is used mainly for Manual Transactions
     *
     * @param irTransaction the IR Transaction
     * @param document the Document blob
     * @param fileName the filename
     * @param fileFormat the fileFormat
     * @param attachmentType the attachment type
     * @return the intl atchmt
     */
    public IntlAtchmt createAttachment(IntlIrTran irTransaction, Blob document, String fileName,
                                       IntlFileFrmtTypeEnum fileFormat, IntlAtchmtTypeCode attachmentType);

    /**
     * Creates the outbound transaction. This method handles a manual request from the console for G&S which resulted in
     * the need to create a outbound transaction. This is different from other similar operation that create outbound
     * transactions via an Intrepid process action.
     *
     * @param outboundTransactionRequest the outbound transaction request
     * @param outboundTransactionDto the outbound transaction dto
     * @param manualReportRequest the manual report request
     * @return the office to ib transaction response
     */
    public OfficeToIbTransactionResponse createOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                   OutboundTransactionDto outboundTransactionDto,
                                                                   ProcessManualReportRequest manualReportRequest)
        throws CIPOServiceFault;
}
