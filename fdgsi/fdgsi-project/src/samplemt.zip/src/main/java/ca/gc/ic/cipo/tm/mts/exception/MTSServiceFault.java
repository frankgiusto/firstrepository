package ca.gc.ic.cipo.tm.mts.exception;

import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;

public class MTSServiceFault extends CIPOServiceFault {

    /**
     *
     */
    private static final long serialVersionUID = -693179260196787692L;

    private ApplicationDto applicationDto;

    public MTSServiceFault(String message, ServiceFaultDetails faultInfo, ApplicationDto applicationDto) {
        super(message, faultInfo);
        this.setApplicationDto(applicationDto);
    }

    public MTSServiceFault(String message, ServiceFaultDetails faultInfo, Throwable cause) {
        super(message, faultInfo, cause);
    }

    public MTSServiceFault(String message, ServiceFaultDetails faultInfo) {
        super(message, faultInfo);
    }

    public ApplicationDto getApplicationDto() {
        return applicationDto;
    }

    public void setApplicationDto(ApplicationDto applicationDto) {
        this.applicationDto = applicationDto;
    }

}
