package ca.gc.ic.cipo.tm.mts.service.intl;

import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.DuplicateIrregularResponse;

public interface IDuplicateTransactionService {

    public DuplicateIrregularResponse duplicateIrregularityTransaction(BigDecimal irTranId) throws CIPOServiceFault;
}
