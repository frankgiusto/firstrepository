package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.sql.SQLException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * @author giustof
 *
 *         The Class IRCeasingOfEffectTotalService is responsible for creating and or updating applications in the
 *         Intrepid database with wipo international transaction information.
 */
@Service(value = "irCeasingOfEffectTotal")
public class IRCeasingOfEffectTotalService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(IRCeasingOfEffectTotalService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing Total Ceasing of Effect: Intl Record Id:" + intlIrTran.getIntlRecordId());
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        Object objType = transType;

        // Get all applications matching transactions international registration number.
        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                processApplication(application, statusTypeResults, objType);

            }
        } else {
            // Madrid Mark does not exist
            logger.error("Madrid Mark does not exist");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    private void processApplication(Application application, Map<ApplicationDto, UserTaskType> statusTypeResults,
                                    Object objType)
        throws MTSServiceFault {
        if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
            .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

            // Record Applications with the same IR Number
            statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

            if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {

                // Cancel application
                application.setStatusCode(TradeMarkStatusType.CANCELLED.getValue());

                actionDao.saveAction(
                    createAction(objType, application, ActionCode.CANCELLED, SectionAuthority.MADRID.name(), null));

                // Process Action - Print Cancelled Notification’
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_CANCELLED_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processOppositionCases(application, registeredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTERED)) {
                    ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                    appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                    statusTypeResults.put(appDto, UserTaskType.TOTAL_CEASING_OF_EFFECT_DO);
                }

                applicationDao.saveApplication(application);

            } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                // Not Registered
                // Withdraw application
                application.setStatusCode(TradeMarkStatusType.WITHDRAWN.getValue());

                actionDao.saveAction(
                    createAction(objType, application, ActionCode.WITHDRAWN, SectionAuthority.MADRID.name(), null));

                // Process Action - Print Cancelled Notification’
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_WITHDRAWN_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processOppositionCases(application, unRegisteredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTRATION_PENDING)) {
                    ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                    appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                    statusTypeResults.put(appDto, UserTaskType.TOTAL_CEASING_OF_EFFECT_DO);
                }

                applicationDao.saveApplication(application);
            } else {
                // this can only be 'Proposed Opposition'
                logger.error("Invalid application status: " + application.getStatusCode());
                throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
            }

        } else {
            // Inactive Intrepid Application.
            logger.error(
                "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
        }

    }

    private boolean processOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                           TradeMarkStatusType tradeMarkStatusType) {

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        boolean caseFound = false;

        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {
                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    if (!CollectionUtils.isEmpty(oppositionCase.getOppositionCaseActions())) {
                        oppositionCase.setOppStatusCode(OppositionCaseStatus.CLOSED.getValue());

                        oppositionCaseDao.saveOppositionCase(oppositionCase);

                        OppositionCaseAction oppositionCaseAction = createOppositionCaseAction(application,
                            oppositionCase, tradeMarkStatusType, SectionAuthority.OPPS45.name());

                        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
                        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
                        applicationDao.saveApplication(application);

                        // Notify the requestor(s) / or opponent if pending
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            (tradeMarkStatusType == TradeMarkStatusType.REGISTERED
                                ? ProcessActionsType.PRINT_CANCELLED_NOTIFICATION
                                : ProcessActionsType.PRINT_WITHDRAWN_NOTIFICATION),
                            oppositionCase.getOppCaseNumber(), SectionAuthority.MADRID.name()));

                        caseFound = true;
                    } else {
                        logger.error("No Opposition Case Actions found for file number: " + application.getFileNumber()
                            + ", case_number: " + oppositionCase.getOppCaseNumber());
                    }
                }

            }
        }
        return caseFound;

    }

    @Override
    public <T> T unmarshallTransaction(IntlIrTranDto intlIrTran) throws JAXBException, SQLException {
        return marshallingService.unmarshallTransaction(intlIrTran.getIrTranId());
    }

    @Override
    public String getServiceName() {
        return "IRCeasingOfEffectTotalService";
    }

}
