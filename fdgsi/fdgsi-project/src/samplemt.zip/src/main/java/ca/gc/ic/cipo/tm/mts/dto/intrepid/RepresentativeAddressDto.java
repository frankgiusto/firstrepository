package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

public class RepresentativeAddressDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7312211650301893612L;

    private final static int ADDRESS_SIZE_LIMIT = 320;

    private BigDecimal fileNumber;

    private String extensionCounter;

    private String irNumber;

    private String representativeName;

    private List<String> representativeAddress;

    public void setRepresentativeAddress(List<String> representativeAddress) {
        this.representativeAddress = representativeAddress;
    }

    private String countryProvince;

    private String zipPostalCode;

    private String cityName;

    public BigDecimal getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(BigDecimal fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(String extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public String getIrNumber() {
        return irNumber;
    }

    public void setIrNumber(String irNumber) {
        this.irNumber = irNumber;
    }

    public String getRepresentativeName() {
        return representativeName;
    }

    public void setRepresentativeName(String representativeName) {
        this.representativeName = representativeName;
    }

    public List<String> getRepresentativeAddress() {
        if (null == representativeAddress) {
            representativeAddress = new ArrayList<>();
        }
        return representativeAddress;
    }

    public String getCountryProvince() {
        return countryProvince;
    }

    public void setCountryProvince(String countryProvince) {
        this.countryProvince = countryProvince;
    }

    public String getZipPostalCode() {
        return zipPostalCode;
    }

    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public boolean isAddressSizeOk() {
        int nameLength = StringUtils.trimWhitespace(representativeName).length();
        int addressLength = 0;
        for (String address : getRepresentativeAddress()) {
            addressLength += address.trim().length();
        }
        int countryProvLength = (null != countryProvince ? countryProvince.length() : 0);
        int postalCodeLength = (null != zipPostalCode ? zipPostalCode.length() : 0);

        if ((nameLength + addressLength + countryProvLength + postalCodeLength) > ADDRESS_SIZE_LIMIT) {
            return false;
        }
        return true;
    }
}
