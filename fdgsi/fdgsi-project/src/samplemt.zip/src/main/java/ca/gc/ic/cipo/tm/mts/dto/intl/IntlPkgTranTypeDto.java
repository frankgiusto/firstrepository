package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

public class IntlPkgTranTypeDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1058495691551721881L;

    private BigDecimal pkgTranCtgryId;

    private String tranCtgry;

    public BigDecimal getPkgTranCtgryId() {
        return pkgTranCtgryId;
    }

    public void setPkgTranCtgryId(BigDecimal pkgTranCtgryId) {
        this.pkgTranCtgryId = pkgTranCtgryId;
    }

    public String getTranCtgry() {
        return tranCtgry;
    }

    public void setTranCtgry(String tranCtgry) {
        this.tranCtgry = tranCtgry;
    }

    @Override
    public String toString() {
        return "IntlPkgTranTypeDto [pkgTranCtgryId=" + pkgTranCtgryId + ", tranCtgry=" + tranCtgry + "]";
    }

}
