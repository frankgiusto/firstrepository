package ca.gc.ic.cipo.tm.mts.enums;

public enum SectionAuthority {

    AAR,

    EXAMINATION,

    FORMALITIES,

    MADRID,

    OPPS45,

    MC_TMOB_OPERATOR,

    MC_TM_EXAMINER,

    MC_TM_SUPERVISOR,

    MC_TMOB_SUPERVISOR,

    MC_TM_OPERATOR;

    public static boolean contains(String authorityId) {
        for (SectionAuthority sectionAuthority : SectionAuthority.values()) {
            if (sectionAuthority.name().equals(authorityId)) {
                return true;
            }
        }
        return false;
    }
}
