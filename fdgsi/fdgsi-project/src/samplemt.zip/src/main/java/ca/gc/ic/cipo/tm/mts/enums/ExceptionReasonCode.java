package ca.gc.ic.cipo.tm.mts.enums;

/**
 * The Enum ExceptionReasonCode defines the types of CIPOServiceFault
 *
 * @author giustof
 */
public enum ExceptionReasonCode {

    DUPLICATE_DESIGNATION(Integer.valueOf(1)),

    MISSING_MARK_FEATURE_CATEGORY(Integer.valueOf(2)),

    INVALID_CLASS_NUMBER(Integer.valueOf(3)),

    SYSTEM_ERROR(Integer.valueOf(4)),

    INACTIVE_APPLICATION(Integer.valueOf(5)),

    MARK_NOT_FOUND(Integer.valueOf(6)),

    DESIGNATION_ERROR(Integer.valueOf(7)),

    INVALID_PROCESS_ACTION(Integer.valueOf(8)),

    OBJECT_EXISTS(Integer.valueOf(9)),

    INFO_NOT_READY_TO_PROCESS(Integer.valueOf(10)),

    RETRYABLE_ERROR(Integer.valueOf(11)),
	
	DATABASE_DATA_INTEGRITY(Integer.valueOf(12));

    private Integer reasonCode;

    private ExceptionReasonCode(Integer reasonCode) {
        this.reasonCode = reasonCode;
    }

    public Integer getReasonCode() {
        return this.reasonCode;
    }

}
