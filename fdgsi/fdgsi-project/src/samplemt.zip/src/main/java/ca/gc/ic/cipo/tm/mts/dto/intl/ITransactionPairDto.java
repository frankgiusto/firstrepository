package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.util.List;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;

public interface ITransactionPairDto {

    public IntlIrTranDto getMadridDesignationTransaction();

    public IntlIrTranDto getPairedTransaction();

    public TransactionCategory getPairedTransactionType();

    public String getAuthorityId();

    public void setMadridDesignationTransaction(IntlIrTranDto intlIrTranDto);

    public void setPairedTransaction(IntlIrTranDto intlIrTranDto);

    public void setPairedTransactionType(TransactionCategory transactionCategory);

    public void setAuthorityId(String authorityId);

    public boolean isValid();

    public List<IntlIrTaskDto> getIntlIrTaskList();

    public void setIntlIrTaskList(List<IntlIrTaskDto> taskList);
}
