package ca.gc.ic.cipo.tm.mts.util;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import _int.wipo.standards.xmlschema.st96.common.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.LocalizedTextType;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.mops.MOPSServiceResponse;
import ca.gc.ic.cipo.tm.mts.Attachment;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType;
import ca.gc.ic.cipo.tm.mts.OrderedTextType;
import ca.gc.ic.cipo.tm.mts.ProvisionalRefusalDetail;
import ca.gc.ic.cipo.tm.mts.ReferenceCode;
import ca.gc.ic.cipo.tm.mts.ReviewOrFileAppeal;
import ca.gc.ic.cipo.tm.mts.TrademarkInfo;
import ca.gc.ic.cipo.tm.mts.enums.CipoPostalAddressCategoryType;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.xmlschema.common.DocumentType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressBagType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressType;
import ca.gc.ic.cipo.xmlschema.common.RoleCategoryType;
import ca.gc.ic.cipo.xmlschema.common.UnstructuredPostalAddressType;
import ca.gc.ic.cipo.xmlschema.trademark.ClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.ActionType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.ApplicantType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionCaseMarkEventType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionGroundsSubsectionType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionGroundsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.PriorityClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsTypeMF3;

public class ManualReportUtil {

    public static final String REPORT_MESSAGES_BUNDLE_NAME = "reportmessages";

    protected static PropertyResourceBundle reportMessagesEnBundle;

    protected static PropertyResourceBundle reportMessagesFrBundle;

    static {
        reportMessagesEnBundle = (PropertyResourceBundle) ResourceBundle.getBundle(REPORT_MESSAGES_BUNDLE_NAME,
            Locale.ENGLISH);
        reportMessagesFrBundle = (PropertyResourceBundle) ResourceBundle.getBundle(REPORT_MESSAGES_BUNDLE_NAME,
            Locale.FRENCH);
    }

    private static String getReportMessageValue(String key, String lang) {
        if (new Locale(lang).equals(Locale.ENGLISH)) {
            return reportMessagesEnBundle.getString(key);
        } else {
            return reportMessagesFrBundle.getString(key);
        }
    }

    private static String getLocalizedMessage(List<LocalizedTextType> list, String lang) {
        for (LocalizedTextType type : list) {
            if (type.getLanguageCode().equals(lang)) {
                return type.getValue();
            }
        }
        return MtsStringUtil.EMPTY;
    }

    private static String getLocalizedOrderedMessage(List<OrderedTextType> list, String lang) {
        for (OrderedTextType type : list) {
            if (type.getLanguageCode().equals(lang)) {
                return type.getValue();
            }
        }
        return MtsStringUtil.EMPTY;
    }

    /**
     * Field I - o Display ‘Canadian Intellectual Property Office’
     *
     * @param tmOwnerParty
     * @return the owner Name
     */
    public static String getIpOffice(TrademarkApplicationDetailsType tmDetail, String lang) {
        return getReportMessageValue("mf3.ip_office", lang);// "Canadian Intelectual
                                                            // Property Office";
    }

    /**
     * Field III - o Display Owner’s Name
     *
     * o Name from INTERESTED_PARTIES table where Relationship Type is ‘Owner’ (1)
     *
     * @param tmOwnerParty
     * @return the owner Name
     */
    public static String getOwnerName(TMInterestedPartyType owner) {
        if (owner != null) {
            return owner.getName().getEntityName();
        }
        return MtsStringUtil.EMPTY;
    }

    public static String getOpponentName(TrademarkApplicationDetailsType tmDetail) {
        for (ApplicantType applicant : tmDetail.getApplicants()) {
            if (RoleCategoryType.OPPONENT.equals(applicant.getRoleCategory())) {
                return applicant.getName().getEntityName();
            }
        }
        return MtsStringUtil.EMPTY;
    }

    public static String getHolderName(MOPSServiceResponse mopsResponse) {
        for (_int.wipo.standards.xmlschema.st96.mops.trademark.ApplicantType applicant : mopsResponse
            .getMadridRegistration().getMadridRegistrationCurrentStatus().getHolderBag().getHolder()) {
            for (Object obj : applicant.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (obj instanceof String) {
                    return obj.toString();
                }
            }
        }
        return MtsStringUtil.EMPTY;
    }

    /**
     * Gets the Language Code
     *
     * @param tmDetail
     * @return
     */
    public static ISOLanguageCodeType getLanguageCodeType(TrademarkApplicationDetailsType tmDetail) {
        for (ApplicantType applicant : tmDetail.getApplicants()) {
            return applicant.getContact().getLanguage();
        }
        return ISOLanguageCodeType.EN;
    }

    /**
     * Field IV
     *
     * o If the Authority Id from TASKS table is ‘Madrid TM Examiner’:
     *
     * o Display ‘Total provisional refusal based on an ex officio examination’
     *
     * o If the Authority Id from TASKS table is ‘TMOB Operator’:
     *
     * o Display ‘Total provisional refusal based on an opposition’
     *
     * @param isExaminer
     * @return
     */
    public static ProvisionalRefusalDetail getProvisionalDetail(boolean isExaminer, TrademarkDetailsTypeMF3 tmDetail,
                                                                TMInterestedPartyType opponent, String lang) {
        ProvisionalRefusalDetail detail = new ProvisionalRefusalDetail();
        String str = getReportMessageValue("mf3.total_provisional_info_opposition", lang);// "Total provisional refusal
                                                                                          // based on an opposition"
        if (isExaminer) {
            str = getReportMessageValue("mf3.total_provisional_info_examination", lang);// "Total
                                                                                        // provisional
                                                                                        // refusal
                                                                                        // based
                                                                                        // on
                                                                                        // an
                                                                                        // ex
                                                                                        // officio
                                                                                        // examination";
        } else if (opponent != null) {
            detail.setOpponentName(opponent.getContact().getName().getEntityName());
            detail.setOpponentAddress(getPostalAddress(opponent.getContact().getPostalAddressBag()));
        }
        detail.setProvisionalRefusalInfo(str);
        return detail;
    }

    /**
     * Field V o Display ‘Total provisional refusal affects all goods and/or services’
     *
     * @return
     */
    public static String getProvisionalRefusalScope(String lang) {
        return getReportMessageValue("mf3.total_provisional_scope", lang);// "Total
                                                                          // provisional
                                                                          // refusal
                                                                          // affects all
                                                                          // goods
                                                                          // and/or
                                                                          // services";
    }

    /**
     * Field VI
     *
     * o If the Authority Id from TASKS table is ‘Madrid TM Examiner’: o Leave area blank. User will enter the
     * appropriate information
     *
     * o If the Authority Id from TASKS table is ‘TMOB Operator’: o Display the following from OPPOSITION_GROUNDS table
     * for the Opposition Case Number from TASKS table:  Description of Opposition Grounds Code  Description of
     * Subsection Code  Reason  Opposition Grounds Sequence Number
     *
     * @param isExaminer
     * @return
     */
    public static String getOppositionGroundsDescription(boolean isExaminer, TrademarkDetailsTypeMF3 tmDetail,
                                                         String lang, int oppositionCaseNum) {
        StringBuffer sb = new StringBuffer();
        if (!isExaminer) {
            for (OppositionGroundsType ground : tmDetail.getOppositionGroundsBag().getOppositionGrounds()) {
                if (ground.getOppositionCaseNumber().intValue() == oppositionCaseNum) {
                    sb.append(getLocalizedMessage(ground.getOppositionGroundsDesc(), lang));
                    sb.append(MtsStringUtil.LINE_CHANGE);

                    sb.append(ground.getReasonClob());
                    sb.append(MtsStringUtil.DOUBLE_LINE_CHANGE);
                }

            }
        }
        return sb.toString();
    }

    public static boolean hasAuthorityRole(List<UserAuthority> authorities, IntlAuthorityRole role) {
        for (UserAuthority auth : authorities) {
            if (auth.getIntlAuthorityRole().equals(role.name())) {
                return true;
            }
        }
        return false;
    }

    public static String getPostalAddress(PostalAddressBagType addressBag) {
        StringBuffer sb = new StringBuffer();
        if (addressBag.getUnstructuredPostalAddress().size() > 0) {
            boolean homeAddressFounded = false;
            for (UnstructuredPostalAddressType address : addressBag.getUnstructuredPostalAddress()) {
                if (address.getCipoPostalAddressCategory().equals(CipoPostalAddressCategoryType.HOME.getValue())) {
                    // flush the string buff if it has address already
                    MtsStringUtil.flushStringBuff(sb);
                    homeAddressFounded = true;
                    sb.append(address.getUnstructuredAddress());
                    sb.append(MtsStringUtil.LINE_CHANGE);
                    if (address.getCountryDesc() != null) {
                        sb.append(address.getCountryDesc());
                    }
                    break;
                } else {
                    if (!homeAddressFounded && !StringUtils.hasText(sb.toString())) {
                        sb.append(address.getUnstructuredAddress());

                    }
                }
            }
        } else {
            for (PostalAddressType address : addressBag.getPostalAddress()) {
                sb.append(address.getAddressLineText().toString() + MtsStringUtil.COMMA_SPACE);
                sb.append(address.getCountryNumber() + MtsStringUtil.COMMA_SPACE);
                sb.append(address.getPostalCode().toString());
            }
        }
        return sb.toString();
    }

    /**
     * Field IX
     *
     * o If the Authority Id from TASKS table is ‘Madrid TM Examiner’:
     *
     * o Display the date of the latest Examiner’s Report or the date of the latest ‘correspondence created’ from
     * ‘EXAMINATION’ whichever is greater
     *
     *  Maximum Response Date from ACTIONS table where the Action Code is ‘Examiner’s First Report’ (20) or the Action
     * Code is ‘correspondence created’ (15) and the Authority Id is ‘EXAMINATION’
     *
     * o If the Authority Id from TASKS table is ‘TMOB Operator’:
     *
     * o Display the deadline date for the Counter Statement Served on the Opponent  Response Date from
     * OPPOSITION_CASE_ACTIONS table where the Opposition Action ‘C/S Served on Opponent’ (202)
     *
     * @param isExaminer
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return
     */
    public static String getMaximumResponseDate(boolean isExaminer, TrademarkDetailsTypeMF3 tmDetail,
                                                OppositionCaseMarkEventType oppCaseAction) {
        Date d = null;
        if (isExaminer) {
            for (ActionType action : tmDetail.getActionsBag().getActions()) {
                if (action.getResponseDate() != null) {
                    if (action.getActionCode().equals(ActionCode.APPLICATION_CREATED.getValue())) {
                        Date aDate = action.getResponseDate() != null
                            ? action.getResponseDate().toGregorianCalendar().getTime() : null;
                        if (d == null) {
                            d = aDate;
                        } else if (aDate != null && d.before(aDate)) {
                            d = aDate;
                        }
                    }
                    if (action.getActionCode().equals(ActionCode.EXAMINER_FIRST_REPORT.getValue())) {// examiner first
                                                                                                     // report
                        Date aDate = action.getResponseDate() != null
                            ? action.getResponseDate().toGregorianCalendar().getTime() : null;
                        if (d == null) {
                            d = aDate;
                        } else if (aDate != null && d.before(aDate)) {
                            d = aDate;
                        }
                    }
                }
            }
        } else if (oppCaseAction != null && oppCaseAction.getEffectiveDate() != null) {
            d = oppCaseAction.getEffectiveDate().toGregorianCalendar().getTime();
        }
        if (d != null) {
            return DateFormats.getISOSDF().format(d);
        }
        return MtsStringUtil.EMPTY;
    }

    public static String getSystemDate() {
        return DateFormats.getISOSDF().format(new Date());
    }

    /**
     * o Field VII(i)
     *
     * o Filing Date, File Number and Priority Date (if any)
     *
     *  Action Date from ACTIONS table where Action Code is ‘Filed’ (30),
     *
     *
     * @param actionBag
     * @param cited
     * @return
     */
    public static Date getCitedLinkFilingDate(TrademarkDetailsTypeMF3 tmDetail) {
        Date filingDate = null;

        for (ActionType action : tmDetail.getActionsBag().getActions()) {
            if (action.getActionCode().equals(ActionCode.APPLICATION_FILED.getValue())) {
                if (action.getActionDate() != null) {
                    filingDate = action.getActionDate().toGregorianCalendar().getTime();
                }
            }
        }
        return filingDate;
    }

    /**
     * o Field VII(i)
     *
     *  File Number from APPLICATIONS table (+ ‘(‘ Extension Counter ‘)’ if Extension Counter is greater than 0),
     *
     * @param actionBag
     * @param cited
     * @return
     */
    public static String getCitedLinkNumber(TrademarkDetailsTypeMF3 tmDetail) {
        StringBuffer sb = new StringBuffer();

        sb.append(tmDetail.getTradmarkDetails().getApplicationNumber().getFileNumber());
        if (tmDetail.getTradmarkDetails().getApplicationNumber().getExtensionCounter() > 0) {
            sb.append(
                MtsStringUtil.LEFT_BRACKET + tmDetail.getTradmarkDetails().getApplicationNumber().getExtensionCounter()
                    + MtsStringUtil.RIGHT_BRACKET);
        }
        return sb.toString();
    }

    /**
     * o Field VII(i)
     *
     *  Claim Date from CLAIMS table if Claim Type is equal to ‘Priority’ (12). Loop the whole GS bag and find the
     * earliest priority filed date.
     *
     * @param actionBag
     * @param cited
     * @param logger
     * @return
     */
    public static Date getPriorityDate(List<GoodsServicesClaimsType> goodsServicesClaims, Logger logger) {
        Date earliestPriorityDate = null;
        if (goodsServicesClaims == null || goodsServicesClaims.isEmpty()) {
            return earliestPriorityDate;
        }
        for (GoodsServicesClaimsType gsClaim : goodsServicesClaims) {
            if (gsClaim.getClaims() != null && !gsClaim.getClaims().isEmpty()) {
                for (ClaimType claim : gsClaim.getClaims()) {
                    if (claim.getClaimCategoryType() == ca.gc.ic.cipo.tm.enumerator.ClaimType.PRIORITY_FILING.getValue()
                        .intValue()) {
                        String dateString = ((PriorityClaimType) claim).getFiledDate();
                        try {
                            Date priorityDate = DateFormats.getISOSDF().parse(dateString);

                            if (earliestPriorityDate == null) {
                                earliestPriorityDate = priorityDate;
                            } else if (earliestPriorityDate.compareTo(priorityDate) >= 0) {
                                earliestPriorityDate = priorityDate;
                            }
                        } catch (ParseException e) {
                            logger.error("Unable to parse this string <" + dateString + "> to a java.util.Date object");
                        }

                    }
                }
            }
        }

        return earliestPriorityDate;
    }

    /**
     * o Field VII(ii)
     *
     * o Registration Date, Registration Number (if present)
     *
     *  Action Date from ACTIONS table where Action Code is ‘Registered’ (55),
     *
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @param string registrationNumber
     * @return
     */
    public static Date getCitedLinkRegistrationDate(TrademarkDetailsTypeMF3 tmDetail) {
        Date registrationDate = null;
        for (ActionType action : tmDetail.getActionsBag().getActions()) {
            if (action.getActionCode().equals(ActionCode.REGISTRATION.getValue())) {
                if (action.getActionDate() != null) {
                    registrationDate = action.getActionDate().toGregorianCalendar().getTime();
                }
            }
        }
        return registrationDate;
    }

    /**
     * o Field VII(iii)
     *
     * o Name and address of the owner
     *
     *  Name, Address, description of Country/Province, Postal Code (if present) from INTERESTED_PARTIES table where
     * Relationship Type is ‘Owner’ (1)
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return
     */
    public static String getCitedLinkNameAndAddress(TrademarkDetailsTypeMF3 tmDetail) {
        String citedMarkNameAndAddress = MtsStringUtil.EMPTY;
        for (ApplicantType applicant : tmDetail.getApplicantsBag().getApplicants()) {
            // TODO remove the OR. Should only be the owner
            if (applicant.getRoleCategory().equals(RoleCategoryType.OWNER)
                || applicant.getRoleCategory().equals(RoleCategoryType.APPLICANT)) {
                if (applicant.getName() != null && StringUtils.hasText(applicant.getName().getEntityName())) {
                    citedMarkNameAndAddress += applicant.getName().getEntityName() + MtsStringUtil.LINE_CHANGE;
                }

                citedMarkNameAndAddress += getPostalAddress(applicant.getContact().getPostalAddressBag());
            }
        }
        return citedMarkNameAndAddress;
    }

    /**
     * o Field VII(iv)
     *
     * o Reproduction of the mark  Text from TRADEMARK table if the Trademark Type from APPLICATIONS table is ‘Word’ or
     * ‘Standard Characters’, or any other type of mark where a Design file does not exist
     *
     *  Design if the Trademark Type is ‘Design’, or any other type of mark where a Design file exists
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return
     */
    public static TrademarkInfo getTrademarkInfo(TrademarkDetailsTypeMF3 tmDetail) {
        TrademarkInfo tm = new TrademarkInfo();

        tm.setTrademarkDescription(tmDetail.getTradmarkDetails().getMarkDescReference());

        // attachment trademark
        Attachment attachment = new Attachment();
        for (DocumentType doc : tmDetail.getTradmarkDetails().getMarkRepresentations()) {
            attachment.setAttachmentType(new ReferenceCode());
            attachment.getAttachmentType().setCategory(doc.getMediaType().value());
            attachment.setFileName(doc.getName());
            attachment.setFileContent(doc.getContent());
        }
        tm.setTrademarkAttachment(attachment);

        return tm;
    }

    /**
     * o Field VII(v)
     *
     * o List of relevant goods and/or services
     *
     *  List of all Nice Class Codes, WS Numbers and Text from WARES_SERVICES and WARES_SERVICES_TEXTS
     *
     *  Order by Nice Class Code and WS Number
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return
     */
    public static String getCitedNiceClasses(TrademarkDetailsTypeMF3 tmDetail) {
        StringBuffer sb = new StringBuffer();
        for (GoodsServicesClaimsType gs : tmDetail.getGoodsServicesClaimsBag().getGoodsServicesClaims()) {
            if (StringUtils.hasText(gs.getClassification().getClassNumber())) {
                sb.append(gs.getClassification().getClassNumber());
                sb.append(MtsStringUtil.SPACE);
            }
            if (gs.getStatement() != null && gs.getStatement().getStatementDescription() != null
                && StringUtils.hasText(gs.getStatement().getStatementDescription().getValue())) {
                sb.append(gs.getStatement().getStatementDescription().getValue());
                sb.append(MtsStringUtil.DOUBLE_LINE_CHANGE);
            }

        }
        return sb.toString();
    }

    /**
     * o Field VIII
     *
     * o If the Authority Id from TASKS table is ‘Madrid TM Examiner’:
     *
     * o Leave area blank. User will enter the appropriate information
     *
     * o If the Authority Id from TASKS table is ‘TMOB Operator’:
     *
     * o Display the Section Text from OPPOSITION_GROUNDS_SUBSECTIONS table based on the Opposition Grounds listed in
     * Field VI
     *
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return
     */
    public static String getOppositionGroundsSectionDetails(TrademarkDetailsTypeMF3 tmDetail, String lang,
                                                            int oppositionCaseNum) {
        StringBuffer sb = new StringBuffer();

        for (OppositionGroundsType grounds : tmDetail.getOppositionGroundsBag().getOppositionGrounds()) {
            if (grounds.getOppositionCaseNumber().intValue() == oppositionCaseNum
                && grounds.getOppositionGroundsSubsection() != null) {
                for (OppositionGroundsSubsectionType subSection : grounds.getOppositionGroundsSubsection()
                    .getOppositionGroundsSubsection()) {
                    if (subSection.getSectionText() != null && subSection.getLanguage().value().equals(lang)) {
                        sb.append(subSection.getSectionText().getValue());
                        sb.append(MtsStringUtil.LINE_CHANGE);
                        sb.append(subSection.getDetails().getValue());
                        sb.append(MtsStringUtil.DOUBLE_LINE_CHANGE);
                    }
                }
            }

        }
        return sb.toString();
    }

    public static ReviewOrFileAppeal getReviewOrFileAppeal(boolean isExaminer, TrademarkDetailsTypeMF3 tmDetail,
                                                           OppositionCaseMarkEventType oppCaseAction, String lang) {
        ReviewOrFileAppeal review = new ReviewOrFileAppeal();
        review.setTimeLimitDate(ManualReportUtil.getMaximumResponseDate(isExaminer, tmDetail, oppCaseAction));
        review.setRegistrarAuthority(ManualReportUtil.getMF3RegistrarAuthority(lang));
        review.setCorrespondanceLanguage(ManualReportUtil.getCorrespondanceLanguage(lang));
        review.setOtherRequirements(MtsStringUtil.EMPTY);
        return review;
    }

    /**
     * Field VII
     *
     * @return
     */
    public static String getMF9CancellationDeclaration(String lang) {
        return getReportMessageValue("mf9.cancellation_declaration", lang);// In accordance with Article 6(4) of the
                                                                           // Madrid Protocol, the undersigned Office
                                                                           // hereby requests the cancellation of the
                                                                           // international registration to the extent
                                                                           // indicated under item VI.
    }

    /**
     * Field IX - ii
     *
     * @return
     */
    public static String getMF3RegistrarAuthority(String lang) {
        return getReportMessageValue("mf3.registrar_of_trademarks", lang);// "Registrar
                                                                          // of
                                                                          // Trademarks";
    }

    /**
     * Field VIII - ii
     *
     * @return
     */
    public static String getMF13RegistrarAuthority(String lang) {
        return getReportMessageValue("mf13.registrar_of_trademarks", lang);// "Registrar
                                                                           // of
                                                                           // Trademarks";
    }

    /**
     * Field VIII - ii
     *
     * @return
     */
    public static String getMF9RegistrarAuthority(String lang) {
        return getReportMessageValue("mf9.registrar_of_trademarks", lang);// "Registrar
                                                                          // of
                                                                          // Trademarks";
    }

    /**
     * Field IX - ii
     *
     * @return
     */
    public static String getMF13Declaration(String lang) {
        return getReportMessageValue("mf13.declaration", lang);// "Registration is final and no longer subject to review
                                                               // or appeal";
    }

    /**
     * Field IX - iii
     *
     * @return
     */
    private static String getCorrespondanceLanguage(String lang) {
        return getReportMessageValue("mf3.correspondance_language", lang);// "Correspondance
                                                                          // must be in
                                                                          // English or
                                                                          // French";
    }

    public static String getGoodsAndServicesLimitation(GoodsAndServiceMeta gsMeta, String lang) {
        StringBuffer sb = new StringBuffer();
        if (GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT.equals(gsMeta.getUserSelectType())) {
            sb.append(getReportMessageValue("mf13.declaration_limitation", lang));// This declaration affects only the
                                                                                  // goods and/or services of the
                                                                                  // international registration that
                                                                                  // were the subject of the limitation
                                                                                  // and that are listed below:
            sb.append(MtsStringUtil.LINE_CHANGE);
            for (GoodsServicesClassificationType gs : gsMeta.getMergedGoodServices().getTaskListBag()) {
                sb.append(MtsStringUtil.LEFT_BRACKET + gs.getClassNumber() + MtsStringUtil.RIGHT_BRACKET
                    + MtsStringUtil.EMPTY);
                sb.append(getLocalizedOrderedMessage(gs.getClassTitleText(), lang));
                sb.append(MtsStringUtil.DOUBLE_LINE_CHANGE);
            }
        } else if (GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT.equals(gsMeta.getUserSelectType())) {
            sb.append(getReportMessageValue("mf13.declaration_no_effect", lang));// This declaration affects all the
                                                                                 // goods and/or services of the
                                                                                 // international registration that were
                                                                                 // the subject of the limitation
        }
        return sb.toString();
    }

    public static String getGoodsAndServicesCeasing(GoodsAndServiceMeta gsMeta, String lang) {
        StringBuffer sb = new StringBuffer();
        if (gsMeta.getMergedGoodServices() == null || gsMeta.getMergedGoodServices().getTaskListBag().isEmpty()) {
            sb.append(getReportMessageValue("mf9.total_cancellation", lang));// Total cancellation: The facts and
                                                                             // decisions affect all the goods
                                                                             // and/or
                                                                             // services of the international
                                                                             // registration
        } else {
            sb.append(getReportMessageValue("mf9.partial_cancellation", lang));// Partial cancellation: The facts
                                                                               // and
                                                                               // decisions do not affect the goods
                                                                               // and/or services of the
                                                                               // international
                                                                               // registration listed below.
            sb.append(MtsStringUtil.LINE_CHANGE);
            for (GoodsServicesClassificationType gs : gsMeta.getMergedGoodServices().getTaskListBag()) {
                // sb.append(gs.getClassificationVersion());
                // sb.append(MtsStringUtil.SPACE + MtsStringUtil.LEFT_BRACKET +
                // gs.getClassNumber()+MtsStringUtil.RIGHT_BRACKET + MtsStringUtil.SPACE);
                sb.append(MtsStringUtil.LEFT_BRACKET + gs.getClassNumber() + MtsStringUtil.RIGHT_BRACKET
                    + MtsStringUtil.SPACE);
                sb.append(getLocalizedOrderedMessage(gs.getClassTitleText(), lang));
                sb.append(MtsStringUtil.LINE_CHANGE);
            }
        }
        return sb.toString();
    }

    public static String getResponseToIrregularity(String lang) {
        return getReportMessageValue("mc.response.to.irregularity", lang);
    }

    public static String getResponseToIrregularityMcKey() {
        return "mc.response.to.irregularity";
    }
}
