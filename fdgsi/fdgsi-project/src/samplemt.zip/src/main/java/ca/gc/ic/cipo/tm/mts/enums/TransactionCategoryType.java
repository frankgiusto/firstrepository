package ca.gc.ic.cipo.tm.mts.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;

/**
 * <p>
 * Java class for TransactionCategoryType.
 *
 *
 */
@XmlType(name = "TransactionCategoryType")
@XmlEnum
public enum TransactionCategoryType {
    // @formatter:off
    PROCESS_IR_DESIGNATION, PROCESS_IR_RENEWAL, PROCESS_IR_NON_RENEWAL, PROCESS_IR_CEASING_OF_EFFECT_TOTAL, PROCESS_IR_OWNERSHIP_CHANGE_TOTAL, PROCESS_IR_CANCELLATION_TOTAL, PROCESS_IR_CANCELLATION_PARTIAL, PROCESS_IR_LIMITATION, PROCESS_IR_CEASING_OF_EFFECT_PARTIAL, PROCESS_IR_HOLDER_NAME_ADDRESS_CHANGE, PROCESS_IR_RENUNCIATION, PROCESS_IR_CREATION, PROCESS_IR_OWNERSHIP_CHANGE_MERGER, PROCESS_IR_OWNERSHIP_CHANGE_PARTIAL, PROCESS_NOTIFICATION, PROCESS_IRREGULARITY, PROCESS_CORRECTION, PROCESS_ABANDONMENT_NOTIFICATION, PROCESS_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL, PROCESS_COMPLETED_PROCESSING, INVALID_TRANSACTION_TYPE;
    // @formatter:on

    public String value() {
        return name();
    }

    public static TransactionCategoryType fromValue(String v) {
        return valueOf(v);
    }

    public static TransactionCategoryType fromSpecificType(TransactionCategory transactionCategory) {

        if (transactionCategory == TransactionCategory.MD_REGISTRATION
            || transactionCategory == TransactionCategory.MD_SUBSEQUENT_DESIGNATION) {
            return TransactionCategoryType.PROCESS_IR_DESIGNATION;

        } else if (transactionCategory == TransactionCategory.MR_COMPLEMENTARY_RENEWAL
            || transactionCategory == TransactionCategory.MR_RENEWAL) {
            return TransactionCategoryType.PROCESS_IR_RENEWAL;

        } else if (transactionCategory == TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK
            || transactionCategory == TransactionCategory.MDT_NON_RENEWAL_OF_CONTRACTING_PARTY) {
            return TransactionCategoryType.PROCESS_IR_NON_RENEWAL;

        } else if (transactionCategory == TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT) {
            return TransactionCategoryType.PROCESS_IR_CEASING_OF_EFFECT_TOTAL;

        } else if (transactionCategory == TransactionCategory.MHR_CHANGE_OF_OWNER) {
            return TransactionCategoryType.PROCESS_IR_OWNERSHIP_CHANGE_TOTAL;

        } else if (transactionCategory == TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION
            || transactionCategory == TransactionCategory.DESIGNATION_TERMINATION) {
            return TransactionCategoryType.PROCESS_IR_OWNERSHIP_CHANGE_PARTIAL;

        } else if (transactionCategory == TransactionCategory.MDT_TOTAL_CANCELLATION) {
            return TransactionCategoryType.PROCESS_IR_CANCELLATION_TOTAL;

        } else if (transactionCategory == TransactionCategory.MPR_PARTIAL_CANCELLATION) {
            return TransactionCategoryType.PROCESS_IR_CANCELLATION_PARTIAL;

        } else if (transactionCategory == TransactionCategory.MPR_LIMITATION) {
            return TransactionCategoryType.PROCESS_IR_LIMITATION;

        } else if (transactionCategory == TransactionCategory.MPR_PARTIAL_CEASING_OF_EFFECT) {
            return TransactionCategoryType.PROCESS_IR_CEASING_OF_EFFECT_PARTIAL;

        } else if (transactionCategory == TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS) {
            return TransactionCategoryType.PROCESS_IR_HOLDER_NAME_ADDRESS_CHANGE;

        } else if (transactionCategory == TransactionCategory.MDT_RENUNCIATION) {
            return TransactionCategoryType.PROCESS_IR_RENUNCIATION;

        } else if (transactionCategory == TransactionCategory.MIR_REGISTRATION) {
            return TransactionCategoryType.PROCESS_IR_CREATION;

        } else if (transactionCategory == TransactionCategory.MBR_APPLICATION_CHANGE
            || transactionCategory == TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE) {
            return TransactionCategoryType.PROCESS_NOTIFICATION;

        } else if (transactionCategory == TransactionCategory.MI_IRREGULARITY_NOTIFICATION) {
            return TransactionCategoryType.PROCESS_IRREGULARITY;

        } else if (transactionCategory == TransactionCategory.MC_CORRECTION) {
            return TransactionCategoryType.PROCESS_CORRECTION;

        } else if (transactionCategory == TransactionCategory.MADRID_ABANDONMENT_NOTIFICATION) {
            return TransactionCategoryType.PROCESS_ABANDONMENT_NOTIFICATION;

        } else if (transactionCategory == TransactionCategory.MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL) {
            return TransactionCategoryType.PROCESS_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL;

        } else if (transactionCategory == TransactionCategory.MCP_NO_CATEGORY) {
            return TransactionCategoryType.PROCESS_COMPLETED_PROCESSING;

        } else {
            return TransactionCategoryType.INVALID_TRANSACTION_TYPE;
        }

    }

}
