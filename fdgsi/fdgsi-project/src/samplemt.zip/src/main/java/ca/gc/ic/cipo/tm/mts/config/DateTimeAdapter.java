/*
 * Copyright (c) 2017 CIPO Created on Nov 28, 2017
 */
package ca.gc.ic.cipo.tm.mts.config;

import java.sql.Timestamp;
import java.util.Calendar;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 * This simple adapter class allows a 'dateTime' type defined in a WSDL to be converted into a java.sql.Timestamp rather
 * than a XMLGregorianCalendar. This eliminates the step of conversion typically sprinkled throughout the service code.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public class DateTimeAdapter extends XmlAdapter<String, Timestamp> {

    @Override
    public String marshal(Timestamp value) throws Exception {
        // Note: org.apache.cxf.tools.common.DataTypeAdapter.printDate(value) is
        // deprecated
        if (value == null) {
            return null;
        }
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(value.getTime());
        return DatatypeConverter.printDateTime(c);
    }

    @Override
    public Timestamp unmarshal(String value) throws Exception {
        // Note: org.apache.cxf.tools.common.DataTypeAdapter.parseDate(value) is
        // deprecated
        if (value == null) {
            return null;
        }
        return new Timestamp(DatatypeConverter.parseDateTime(value).getTimeInMillis());
    }
}
