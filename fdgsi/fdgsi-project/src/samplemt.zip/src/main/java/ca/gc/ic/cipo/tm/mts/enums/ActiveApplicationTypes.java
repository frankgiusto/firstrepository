package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;

public enum ActiveApplicationTypes {

    // @formatter:off

    MADRID_ACTIVE_APPLICATION_TYPES(
        TradeMarkStatusType.REGISTERED,
        TradeMarkStatusType.PRE_FORMALIZED,
        TradeMarkStatusType.FORMALIZED,
        TradeMarkStatusType.DEFAULT_SEARCHED,
        TradeMarkStatusType.APPROVED,
        TradeMarkStatusType.ADVERTISED,
        TradeMarkStatusType.OPPOSED,
        TradeMarkStatusType.ALLOWED,
        TradeMarkStatusType.REGISTRATION_PENDING,
        TradeMarkStatusType.DEFAULT_ALLOWED,
        TradeMarkStatusType.SEARCHED,
        TradeMarkStatusType.DEFAULT_PRE_FORMALIZED,
        TradeMarkStatusType.DEFAULT_FORMALIZED,
        TradeMarkStatusType.REFUSED_AWAITING_APPEAL,
        TradeMarkStatusType.REFUSED_APPEAL_IN_PROGRESS,
        TradeMarkStatusType.PROPOSED_OPPOSITION,
        TradeMarkStatusType.DEFAULT_REGISTRATION_PENDING);

    // @formatter:on
    // TODO waiting for this to be added to intrepid - TradeMarkStatusType.REGISTRATION_PENDING,

    private final Set<TradeMarkStatusType> activeTransactionStatus;

    private ActiveApplicationTypes(TradeMarkStatusType... activeTransactionStatus) {
        this.activeTransactionStatus = EnumSet.copyOf(Arrays.asList(activeTransactionStatus));
    }

    public Set<TradeMarkStatusType> getActiveTransactionStatus() {
        return activeTransactionStatus;
    }

    public Boolean isActiveStatus(TradeMarkStatusType status) {

        if (getActiveTransactionStatus().contains(status)) {
            return true;
        }
        return false;
    }
}
