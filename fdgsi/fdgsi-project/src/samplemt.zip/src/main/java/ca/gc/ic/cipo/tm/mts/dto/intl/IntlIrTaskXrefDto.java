package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.math.BigDecimal;

public class IntlIrTaskXrefDto implements java.io.Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 3725150296801017822L;

    private IntlIrTaskDto intlIrTaskDto;

    private BigDecimal irTranId;

    public BigDecimal getIrTranId() {
        return irTranId;
    }

    public void setIrTranId(BigDecimal irTranId) {
        this.irTranId = irTranId;
    }

    public IntlIrTaskDto getIntlIrTaskDto() {
        return intlIrTaskDto;
    }

    public void setIntlIrTaskDto(IntlIrTaskDto intlIrTaskDto) {
        this.intlIrTaskDto = intlIrTaskDto;
    }

    @Override
    public String toString() {
        return "IntlIrTaskXrefDto [intlIrTaskDto=" + intlIrTaskDto + ", irTranId=" + irTranId + "]";
    }

}
