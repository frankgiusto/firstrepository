package ca.gc.ic.cipo.tm.mts.util;

import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.sql.rowset.serial.SerialBlob;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;
import org.springframework.context.MessageSource;

import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlEventTypeCode;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridServiceApplicationCode;
import ca.gc.ic.cipo.tm.intl.model.IntlEventType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlProcessEvent;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.AbstractMtsService;

public class ProcessEventUtil extends AbstractMtsService {

    protected static final Logger logger = Logger.getLogger(ProcessEventUtil.class);

    public static final String PROCESS_EVENT_BUNDLE_NAME = "processevents";

    protected static PropertyResourceBundle processEventsEnBundle;

    protected static PropertyResourceBundle processEventsFrBundle;

    static {
        processEventsEnBundle = (PropertyResourceBundle) ResourceBundle.getBundle(PROCESS_EVENT_BUNDLE_NAME,
            Locale.ENGLISH);
        processEventsFrBundle = (PropertyResourceBundle) ResourceBundle.getBundle(PROCESS_EVENT_BUNDLE_NAME,
            Locale.FRENCH);
    }

    public static ProcessEventUtil getInstance() {
        return new ProcessEventUtil();
    }

    public static ServiceFaultDetails getFaultDetails(int reasonCode, int returnCode, MessageSource messageSource) {

        ServiceFaultDetails details = new ServiceFaultDetails();

        String key = MtsStringUtil.EMPTY + returnCode + MtsStringUtil.DOT + reasonCode;
        details.setComponentAcronym("MTS");
        details.setEnErrorMsg(messageSource.getMessage(key, null, Locale.CANADA));
        details.setFrErrorMsg(messageSource.getMessage(key, null, Locale.CANADA_FRENCH));
        details.setReasonCode(reasonCode);
        details.setReturnCode(returnCode);
        details.setServiceName("Madrid Package Service ");

        return details;
    }

    public static ServiceFaultDetails getFaultDetails(int reasonCode, int returnCode, String addInfo,
                                                      MessageSource messageSource) {

        ServiceFaultDetails details = getFaultDetails(reasonCode, returnCode, messageSource);

        details.setStackTrace(addInfo);
        return details;

    }

    /**
     * Convenience method to add an ERROR process event to an existing International Transaction. This method does *not*
     * persist the change it simply adds it to the Transactions Process Event collection.
     * <p>
     * The additional information in this case will be the stack trace of the exception provided.
     *
     * @param pkg the international package
     * @param irTran the international transaction
     * @param msgKey the message key to look up the English and French Descriptions of the Process Event
     * @param ex the exception to record the stack trace from
     * @param msgArgs an optional number of arguments to substitute into the messages
     * @throws MTSServiceFault
     */
    public void addProcessErrorEvent(IntlPkg pkg, IntlIrTran irTran, String msgKey, Throwable ex, Object... msgArgs)
        throws MTSServiceFault {
        // Convert the stack trace into a string - this becomes the "additional
        // information"
        String additionalInfo = null;
        if (ex != null) {
            additionalInfo = ExceptionUtils.getFullStackTrace(ex);
        }
        // Chain the call
        addProcessEvent(pkg, irTran, IntlEventTypeCode.ERROR, msgKey, additionalInfo, msgArgs);
    }

    /**
     * Convenience method to add an INFORMATION process event to an existing International Transaction. This method does
     * *not* persist the change it simply adds it to the Transactions Process Event collection.
     *
     * @param pkg the international package
     * @param irTran the international transaction
     * @param msgKey the message key to look up the English and French Descriptions of the Process Event
     * @param additionalInfo any additional details
     * @param msgArgs an optional number of arguments to substitute into the messages
     * @throws MTSServiceFault
     */
    public void addProcessInfoEvent(IntlPkg pkg, IntlIrTran irTran, String msgKey, String additionalInfo,
                                    Object... msgArgs)
        throws MTSServiceFault {
        // Chain the call
        addProcessEvent(pkg, irTran, IntlEventTypeCode.INFORMATION, msgKey, additionalInfo, msgArgs);
    }

    public void addProcessEvent(IntlIrTran irTran, IntlEventTypeCode eventTypeCode, String msgKey,
                                String additionalInfo, Object... msgArgs)
        throws MTSServiceFault {

        IntlProcessEvent event = new IntlProcessEvent();
        event.setIntlIrTran(irTran);
        // For HTS there will be no Package reference

        // Convert the enumerated code type into a model class
        IntlEventType eventType = new IntlEventType();
        eventType.setEventCtgryId(new BigDecimal(eventTypeCode.codeValue()));
        event.setIntlEventType(eventType);

        event.setTmstmp(new Timestamp(System.currentTimeMillis()));
        event.setComponent("MTS");

        try {
            event.setNode(InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            logger.warn("Could not get local host name", e);
            event.setNode("unknown");
        }

        // Look up the descriptions from the resource bundle
        String descBaseEn = processEventsEnBundle.getString(msgKey);
        String descBaseFr = processEventsFrBundle.getString(msgKey);

        // Substitute parameters where provided. Escape single quotes as well
        if (msgArgs != null && msgArgs.length > 0) {
            // All single quotes must be escaped to be preserved, temporarily
            // double them
            descBaseEn = descBaseEn.replaceAll("'", "''");
            descBaseEn = MessageFormat.format(descBaseEn, msgArgs);
            descBaseEn = descBaseEn.replaceAll("''", "'");

            descBaseFr = descBaseFr.replaceAll("'", "''");
            descBaseFr = MessageFormat.format(descBaseFr, msgArgs);
            descBaseFr = descBaseFr.replaceAll("''", "'");

        }
        event.setDescEn(descBaseEn);
        event.setDescFr(descBaseFr);

        // If additional info is provided, convert it to a Blob and set it on
        // the event
        if (StringUtils.isNotBlank(additionalInfo)) {
            Blob addIntoBlob = null;
            try {
                addIntoBlob = new SerialBlob(additionalInfo.getBytes());
            } catch (SQLException sqe) {
                throwMTSServiceFault("mts.blob.serialize.error", ExceptionReasonCode.RETRYABLE_ERROR);
            }
            event.setAddtnlInfo(addIntoBlob);
        }

        irTran.getIntlProcessEvents().add(event);
    }

    /**
     * Convenience method to add a WARNING process event to an existing International Transaction. This method does
     * *not* persist the change it simply adds it to the Transactions Process Event collection.
     *
     * @param pkg the international package
     * @param irTran the international transaction
     * @param msgKey the message key to look up the English and French Descriptions of the Process Event
     * @param additionalInfo any additional details
     * @param msgArgs an optional number of arguments to substitute into the messages
     * @throws MTSServiceFault
     */
    public void addProcessWarningEvent(IntlPkg pkg, IntlIrTran irTran, String msgKey, String additionalInfo,
                                       Object... msgArgs)
        throws MTSServiceFault {
        // Chain the call
        addProcessEvent(pkg, irTran, IntlEventTypeCode.WARNING, msgKey, additionalInfo, msgArgs);
    }

    /**
     * Convenience method to add an ERROR process event to an existing International Transaction. This method does *not*
     * persist the change it simply adds it to the Transactions Process Event collection.
     * <p>
     * The additional information in this case will be the stack trace of the exception provided.
     *
     * @param irTran the international transaction
     * @param msgKey the message key to look up the English and French Descriptions of the Process Event
     * @param ex the exception to record the stack trace from
     * @param msgArgs an optional number of arguments to substitute into the messages
     * @throws MTSServiceFault
     */
    public void addProcessErrorEvent(IntlIrTran irTran, String msgKey, Throwable ex, Object... msgArgs)
        throws MTSServiceFault {
        // Convert the stack trace into a string - this becomes the "additional
        // information"
        String additionalInfo = null;
        if (ex != null) {
            additionalInfo = ExceptionUtils.getFullStackTrace(ex);
        }
        // Chain the call
        addProcessEvent(irTran, IntlEventTypeCode.ERROR, msgKey, additionalInfo, msgArgs);
    }

    /**
     * Convenience method to add a Process Event to an existing International Transaction. This method does *not*
     * persist the change it simply adds a new Process Event to the Transaction's collection.
     * <p>
     * The English and French descriptions for the event are looked up by msgKey in the rescource bundle
     * "processevents.properties". Optionally, arguments can be substituted into the message using the variable
     * 'msgArgs' parameters.
     * <p>
     * The 'additionalInfo' can be used to supply more detailed information about the event, typically a stack trace in
     * the case of errors.
     *
     * @param pkg the international package
     * @param irTran the International Transaction
     * @param eventTypeCode the event type code
     * @param msgKey the message key to look up the English and French Descriptions of the Process Event
     * @param additionalInfo further detail of Process Event
     * @param msgArgs an optional number of arguments to substitute into the messages
     * @throws MTSServiceFault
     */
    public void addProcessEvent(IntlPkg pkg, IntlIrTran irTran, IntlEventTypeCode eventTypeCode, String msgKey,
                                String additionalInfo, Object... msgArgs)
        throws MTSServiceFault {

        IntlProcessEvent event = new IntlProcessEvent();
        if (pkg != null) {
            event.setIntlPkg(pkg);
        }

        if (irTran != null) {
            event.setIntlIrTran(irTran);
        }

        // Convert the enumerated code type into a model class
        IntlEventType eventType = new IntlEventType();
        eventType.setEventCtgryId(new BigDecimal(eventTypeCode.codeValue()));
        event.setIntlEventType(eventType);

        event.setTmstmp(new Timestamp(System.currentTimeMillis()));
        event.setComponent(MadridServiceApplicationCode.MPS.name());

        try {
            event.setNode(InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            logger.warn("Could not get local host name", e);
            event.setNode("unknown");
        }

        // Look up the descriptions from the resource bundle
        String descBaseEn = processEventsEnBundle.getString(msgKey);
        String descBaseFr = processEventsFrBundle.getString(msgKey);

        // Substitute parameters where provided. Escape single quotes as well
        if (msgArgs != null && msgArgs.length > 0) {
            // All single quotes must be escaped to be preserved, temporarily
            // double them
            descBaseEn = descBaseEn.replaceAll("'", "''");
            descBaseEn = MessageFormat.format(descBaseEn, msgArgs);
            descBaseEn = descBaseEn.replaceAll("''", "'");

            descBaseFr = descBaseFr.replaceAll("'", "''");
            descBaseFr = MessageFormat.format(descBaseFr, msgArgs);
            descBaseFr = descBaseFr.replaceAll("''", "'");

        }
        event.setDescEn(descBaseEn);
        event.setDescFr(descBaseFr);

        // If additional info is provided, convert it to a Blob and set it on
        // the event
        if (StringUtils.isNotBlank(additionalInfo)) {
            Blob addIntoBlob = null;
            try {
                addIntoBlob = new SerialBlob(additionalInfo.getBytes());
            } catch (SQLException sqe) {
                throwMTSServiceFault("mts.blob.serialize.error", ExceptionReasonCode.RETRYABLE_ERROR);
            }
            event.setAddtnlInfo(addIntoBlob);
        }

        if (pkg != null) {

            pkg.getIntlProcessEvents().add(event);
        }

        if (irTran != null) {
            irTran.getIntlProcessEvents().add(event);
        }
    }

}
