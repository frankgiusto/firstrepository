package ca.gc.ic.cipo.tm.mts.util;

import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;

/**
 *
 * This map servers to map user task type to groupId.
 *
 */
public class NotificationTaskAuthorityUtil {

    private static final Map<UserTaskType, SectionAuthority> NOTIFICATION_TASK_AUTHORITY_MAP = new HashMap<>();

    static {
        NOTIFICATION_TASK_AUTHORITY_MAP.put(UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED,
            SectionAuthority.MC_TMOB_SUPERVISOR);
        NOTIFICATION_TASK_AUTHORITY_MAP.put(UserTaskType.ADDRESS_EXCEEDED_LIMIT, SectionAuthority.MC_TM_OPERATOR);
        NOTIFICATION_TASK_AUTHORITY_MAP.put(UserTaskType.IR_TOTAL_CANCELLATION, SectionAuthority.MC_TMOB_SUPERVISOR);
        NOTIFICATION_TASK_AUTHORITY_MAP.put(UserTaskType.TOTAL_CEASING_OF_EFFECT_DO,
            SectionAuthority.MC_TMOB_SUPERVISOR);

        NOTIFICATION_TASK_AUTHORITY_MAP.put(UserTaskType.REVIEW_PARTIAL_OWNERSHIP_CHANGE,
            SectionAuthority.MC_TM_SUPERVISOR);
    }

    public static SectionAuthority getSectionAuthority(UserTaskType userTaskType) {
        SectionAuthority sectionAuthority = NOTIFICATION_TASK_AUTHORITY_MAP.get(userTaskType);

        return sectionAuthority;
    }

}
