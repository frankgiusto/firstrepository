package ca.gc.ic.cipo.tm.mts.service;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;

public abstract class TransactionMgr
{
	public abstract AutomatedProcessResponse processTransaction(TransactionRequest transaction) throws CIPOServiceFault;

	public abstract ManualProcessResponse processManualTransaction(TransactionRequest transactionRequest) throws CIPOServiceFault;

	public abstract AutomatedProcessResponse processOwnershipChangeMerger(TransactionPairRequest transaction) throws CIPOServiceFault;
}
