package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class IntlPkgDto implements Serializable {

    private BigDecimal pkgId;

    private Timestamp currStatusTmstmp;

    private String intlPblctnId;

    private Date intlPblctnDt;

    private Timestamp createdTmstmp;

    private Timestamp updatedTmstmp;

    private String pkgFileName;

    private BigDecimal pkgFileSizeBytes;

    public BigDecimal getPkgId() {
        return pkgId;
    }

    public void setPkgId(BigDecimal pkgId) {
        this.pkgId = pkgId;
    }

    public Timestamp getCurrStatusTmstmp() {
        return currStatusTmstmp;
    }

    public void setCurrStatusTmstmp(Timestamp currStatusTmstmp) {
        this.currStatusTmstmp = currStatusTmstmp;
    }

    public String getIntlPblctnId() {
        return intlPblctnId;
    }

    public void setIntlPblctnId(String intlPblctnId) {
        this.intlPblctnId = intlPblctnId;
    }

    public Date getIntlPblctnDt() {
        return intlPblctnDt;
    }

    public void setIntlPblctnDt(Date intlPblctnDt) {
        this.intlPblctnDt = intlPblctnDt;
    }

    public Timestamp getCreatedTmstmp() {
        return createdTmstmp;
    }

    public void setCreatedTmstmp(Timestamp createdTmstmp) {
        this.createdTmstmp = createdTmstmp;
    }

    public Timestamp getUpdatedTmstmp() {
        return updatedTmstmp;
    }

    public void setUpdatedTmstmp(Timestamp updatedTmstmp) {
        this.updatedTmstmp = updatedTmstmp;
    }

    public String getPkgFileName() {
        return pkgFileName;
    }

    public void setPkgFileName(String pkgFileName) {
        this.pkgFileName = pkgFileName;
    }

    public BigDecimal getPkgFileSizeBytes() {
        return pkgFileSizeBytes;
    }

    public void setPkgFileSizeBytes(BigDecimal pkgFileSizeBytes) {
        this.pkgFileSizeBytes = pkgFileSizeBytes;
    }

    @Override
    public String toString() {
        return "IntlPkgDto [pkgId=" + pkgId + ", currStatusTmstmp=" + currStatusTmstmp + ", intlPblctnId="
            + intlPblctnId + ", intlPblctnDt=" + intlPblctnDt + ", createdTmstmp=" + createdTmstmp + ", updatedTmstmp="
            + updatedTmstmp + ", pkgFileName=" + pkgFileName + ", pkgFileSizeBytes=" + pkgFileSizeBytes + "]";
    }

}
