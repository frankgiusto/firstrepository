package ca.gc.ic.cipo.tm.mts.dto.intl;

public enum NfsFileTypeDto {

    OUTBOUND_ONLY("OutboundOnly", 0),

    STANDARD_CHARACTERS_ONLY("StandardCharcterOnly", 1),

    COURTESY_LETTER_ONLY("CourtesyLetterOnly", 0),

    OTHERS("Others", 3);

    private String nfsFileType;

    private Integer nfsFileTypeCtgryId;

    private NfsFileTypeDto(String nfsFileType, Integer nfsFileTypeCtgryId) {
        this.nfsFileType = nfsFileType;
        this.nfsFileTypeCtgryId = nfsFileTypeCtgryId;
    }

    public String getValue() {
        return this.nfsFileType;
    }

    public Integer getTaskSubjectCtgryId() {
        return this.nfsFileTypeCtgryId;
    }
}
