package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridRenewalType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * @author giustof
 *
 *         The Class IRRenewalService is responsible for creating and or updating applications in the Intrepid database
 *         with wipo international transaction information.
 */
@Service(value = "irRenewal")
public class IRRenewalService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(IRRenewalService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing IR Renewal: Intl Record Id:" + intlIrTran.getIntlRecordId());
        Map<ApplicationDto, UserTaskType> notificationTypes = new HashMap<>();
        MadridRenewalType madridRenewalType = (MadridRenewalType) transType;

        // Get all applications matching transactions international registration number.

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }
                // Record Applications with the same IR Number
                notificationTypes.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    actionDao.saveAction(createAction(madridRenewalType, application, ActionCode.IR_RENEWED,
                        SectionAuthority.MADRID.name(), null));

                    // Process Action - Print IR Renewal Acknowledgement’
                    processActionsDao.saveProcessActions(createProcessAction(application,
                        ProcessActionsType.PRINT_IR_RENEWAL_ACKNOWLEDGEMENT, SectionAuthority.MADRID.name()));

                    checkNumberOfNiceClasses(madridRenewalType, application, notificationTypes);

                }
            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return notificationTypes;
    }

    private void checkNumberOfNiceClasses(MadridRenewalType madridRenewalType, Application application,
                                          Map<ApplicationDto, UserTaskType> notificationTypes)
        throws MTSServiceFault {

        BigInteger renewalNiceClasse = madridRenewalType.getActiveClassTotalQuantity();
        logger.debug("ActiveClassTotalQuantity: " + renewalNiceClasse.intValue());

        if (application.getIrNumber() == null) {
            logger.error("IR Number is null!");
            return;
        }

        Set<Integer> uniqueNiceClasses = new HashSet<Integer>();
        List<Application> apps = applicationDao.getApplicationByIrNumber(application.getIrNumber());
        if (CollectionUtils.isNotEmpty(apps)) {
            for (Application app : apps) {
                Set<Integer> otherNiceClasses = getNiceClasses(app);
                for (Integer nc : otherNiceClasses) {
                    uniqueNiceClasses.add(nc);
                }
            }
        }

        logger.debug("uniqueNiceClasses: " + uniqueNiceClasses.size());
        if (renewalNiceClasse.intValue() != uniqueNiceClasses.size()) {
            // create notification
            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_SUPERVISOR.name());
            notificationTypes.put(applicationDto, UserTaskType.NUMBER_OF_CLASSES_MISMATCH);
        }
    }

    private Set<Integer> getNiceClasses(Application app) {
        Set<GoodService> goodsServices = app.getGoodsServices();

        Set<Integer> niceClasses = new HashSet<Integer>();
        Iterator<GoodService> iterator = goodsServices.iterator();
        while (iterator.hasNext()) {
            niceClasses.add(iterator.next().getNiceClassCode());
        }

        return niceClasses;
    }

    @Override
    public String getServiceName() {
        return "IRRenewalService";
    }

}
