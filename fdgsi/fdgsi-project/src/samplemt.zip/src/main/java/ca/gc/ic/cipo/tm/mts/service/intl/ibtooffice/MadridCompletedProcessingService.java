package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridCompletedProcessingType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;

/**
 *
 *
 */
@Service(value = "madridCompletedProcessing")
public class MadridCompletedProcessingService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private IInternationalService internationalService;

    private static Logger logger = Logger.getLogger(MadridCompletedProcessingService.class.getName());

    // This transaction manager is for the madrid international database only.
    @Transactional(value = "tmIntlTransactionManager")
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTranDto, T transType)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
        MadridCompletedProcessingType madridCompletedProcessingType = (MadridCompletedProcessingType) transType;

        logger.debug("Processing CompletedProcessing: OfficeReferenceIdentifier:"
            + madridCompletedProcessingType.getOfficeReferenceIdentifier().getValue());

        // Use the Office Reference Identifier which contains the value of the INTL_IR_TRAN ir_tran_id .
        long transId = Long.parseLong(madridCompletedProcessingType.getOfficeReferenceIdentifier().getValue());

        // Update the transaction status to "closed - processed". This status already exists.
        internationalService.updateTransactionStatus(BigDecimal.valueOf(transId), StatusType.PROCESSED);

        return statusTypeResults;
    }

    @Override
    public String getServiceName() {
        return "MadridCompletedProcessingService";
    }

}
