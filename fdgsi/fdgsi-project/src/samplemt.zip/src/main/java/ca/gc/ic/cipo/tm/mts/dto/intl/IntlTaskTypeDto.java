package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

public class IntlTaskTypeDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -8146384295958143565L;

    private BigDecimal taskCtgryId;

    private BigDecimal taskSubjectCtgryId;

    private String taskCtgry;

    public BigDecimal getTaskCtgryId() {
        return taskCtgryId;
    }

    public void setTaskCtgryId(BigDecimal taskCtgryId) {
        this.taskCtgryId = taskCtgryId;
    }

    public BigDecimal getTaskSubjectCtgryId() {
        return taskSubjectCtgryId;
    }

    public void setTaskSubjectCtgryId(BigDecimal taskSubjectCtgryId) {
        this.taskSubjectCtgryId = taskSubjectCtgryId;
    }

    public String getTaskCtgry() {
        return taskCtgry;
    }

    public void setTaskCtgry(String taskCtgry) {
        this.taskCtgry = taskCtgry;
    }

}
