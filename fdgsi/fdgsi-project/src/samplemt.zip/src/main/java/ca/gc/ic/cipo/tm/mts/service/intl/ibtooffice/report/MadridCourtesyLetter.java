package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report;

import java.io.InputStream;
import java.util.List;

public class MadridCourtesyLetter {

    private String address;

    private String date;

    private String yourFileNumber;

    private String myFileNumber;

    private String irNumber;

    private String tradeMark;

    private String applicant;

    private String imageFileName;

    private String imageFileStoredDir;

    private String reportFileName;

    private List<InputStream> imageList;

    public MadridCourtesyLetter() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getYourFileNumber() {
        return yourFileNumber;
    }

    public void setYourFileNumber(String yourFileNumber) {
        this.yourFileNumber = yourFileNumber;
    }

    public String getMyFileNumber() {
        return myFileNumber;
    }

    public void setMyFileNumber(String myFileNumber) {
        this.myFileNumber = myFileNumber;
    }

    public String getIrNumber() {
        return irNumber;
    }

    public void setIrNumber(String irNumber) {
        this.irNumber = irNumber;
    }

    public String getTradeMark() {
        return tradeMark;
    }

    public void setTradeMark(String tradeMark) {
        this.tradeMark = tradeMark;
    }

    public String getApplicant() {
        return applicant;
    }

    public void setApplicant(String applicant) {
        this.applicant = applicant;
    }

    public String getImageFileName() {
        return imageFileName;
    }

    public void setImageFileName(String imageFileName) {
        this.imageFileName = imageFileName;
    }

    public String getImageFileStoredDir() {
        return imageFileStoredDir;
    }

    public void setImageFileStoredDir(String imageFileStoredDir) {
        this.imageFileStoredDir = imageFileStoredDir;
    }

    public List<InputStream> getImageList() {
        return imageList;
    }

    public void setImageList(List<InputStream> imageList) {
        this.imageList = imageList;
    }

    public String getReportFileName() {
        return reportFileName;
    }

    public void setReportFileName(String reportFileName) {
        this.reportFileName = reportFileName;
    }

}
