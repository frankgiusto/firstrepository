package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class IntlTaskAddtnlInfoDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 4222078996751448082L;

    private BigDecimal taskAddtnlInfoId;

    private BigDecimal taskId;

    private IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto;

    private String addtnlInfo;

    private Timestamp createdTmstmp;

    public BigDecimal getTaskAddtnlInfoId() {
        return taskAddtnlInfoId;
    }

    public void setTaskAddtnlInfoId(BigDecimal taskAddtnlInfoId) {
        this.taskAddtnlInfoId = taskAddtnlInfoId;
    }

    public String getAddtnlInfo() {
        return addtnlInfo;
    }

    public void setAddtnlInfo(String addtnlInfo) {
        this.addtnlInfo = addtnlInfo;
    }

    public Timestamp getCreatedTmstmp() {
        return createdTmstmp;
    }

    public void setCreatedTmstmp(Timestamp createdTmstmp) {
        this.createdTmstmp = createdTmstmp;
    }

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public IntlTaskAddtnlInfoTypeDto getIntlTaskAddtnlInfoTypeDto() {
        return intlTaskAddtnlInfoTypeDto;
    }

    public void setIntlTaskAddtnlInfoTypeDto(IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto) {
        this.intlTaskAddtnlInfoTypeDto = intlTaskAddtnlInfoTypeDto;
    }

}
