package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.mts.enums.NfsFileType;

public class NfsFilenameDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -891258695641294650L;

    private String fileName;

    private BigDecimal fileNumber;

    private String extensionCounter;

    private NfsFileType fileType;

    private BigDecimal atchmtId;

    private BigDecimal irTranId;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public BigDecimal getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(BigDecimal fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(String extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public BigDecimal getAtchmtId() {
        return atchmtId;
    }

    public void setAtchmtId(BigDecimal atchmtId) {
        this.atchmtId = atchmtId;
    }

    public NfsFileType getFileType() {
        return fileType;
    }

    public void setFileType(NfsFileType fileType) {
        this.fileType = fileType;
    }

    public BigDecimal getIrTranId() {
        return irTranId;
    }

    public void setIrTranId(BigDecimal irTranId) {
        this.irTranId = irTranId;
    }

}
