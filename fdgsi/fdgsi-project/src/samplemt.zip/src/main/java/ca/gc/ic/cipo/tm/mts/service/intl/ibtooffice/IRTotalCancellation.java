package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

/**
 * @author giustof
 *
 *         The Class IRTotalCancellationService is responsible for performing a total cancellation on intrepid
 *         applications. The applications are identified by the IR Number(INTL-REG-NO) of the applicable transaction.
 *         Total cancellations can be performed on the following transaction types. - MadridDesignationTermination
 *         transaction with Category: Cancellation (normal process) - MadridProtectionRestriction transaction with
 *         Category: Partial Cancellation resulting in no Goods/Services remaining on the mark (also see SUC 2.7.2
 *         Process IR Cancellation Partial) - MadridProtectionRestriction transaction with Category: Limitation
 *         resulting in no Goods/Services remaining on the mark (also see SUC 2.11 Process IR G&S Limitation)
 *
 *         Total Cancellation on a Madrid Designation Termination may also apply to a OO office type. This class handles
 *         this case as well.
 *
 */
@Service(value = "irTotalCancellation")
public class IRTotalCancellation extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private MadridApplicationDao madridApplicationsDao;

    @Autowired
    MadridApplicationActionDao madridApplicationActionDao;

    private static Logger logger = Logger.getLogger(IRTotalCancellation.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        Object objType = transType;

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        // Get all applications matching transactions international registration number.
        if (intlIrTran != null && intlIrTran.getIntlIrTaskList() != null && intlIrTran.getIntlIrTaskList().size() > 0) {
            for (IntlIrTaskDto intlIrTaskDto : intlIrTran.getIntlIrTaskList()) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                processApplication(application, statusTypeResults, objType);

            }
        } else {
            MadridDesignationTerminationType madridDesignationTermination = (MadridDesignationTerminationType) transType;

            processOOTransaction(madridDesignationTermination, statusTypeResults);

        }
        return statusTypeResults;
    }

    private void processApplication(Application application, Map<ApplicationDto, UserTaskType> statusTypeResults,
                                    Object objType)
        throws MTSServiceFault {

        // Record Applications with the same IR Number
        statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.OO), null);

        if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
            .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

            if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {

                // Cancel application
                application.setStatusCode(TradeMarkStatusType.CANCELLED_BY_OWNER.getValue());

                actionDao.saveAction(createAction(objType, application, ActionCode.CANCELLED_BY_OWNER,
                    SectionAuthority.MADRID.name(), null));

                // Action action = createAction(objType, application, ActionCode.CANCELLED_BY_OWNER,
                // SectionAuthority.EXAMINATION.name());
                // actionDao.saveAction(action);

                // Process Action - Print Cancelled by Owner Notification’ ’
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processOppositionCases(application, registeredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTERED)) {

                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.OO),
                        UserTaskType.IR_TOTAL_CANCELLATION);
                }

                applicationDao.saveApplication(application);

            } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                // Not Registered
                // Withdraw application
                application.setStatusCode(TradeMarkStatusType.WITHDRAWN_OWNER.getValue());

                actionDao.saveAction(createAction(objType, application, ActionCode.WITHDRAWN_BY_OWNER,
                    SectionAuthority.MADRID.name(), null));

                // Action action = createAction(objType, application, ActionCode.WITHDRAWN_BY_OWNER,
                // SectionAuthority.EXAMINATION.name());
                // actionDao.saveAction(action);

                // Process Action - Print Withdrawn by Owner Notification
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processOppositionCases(application, unRegisteredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTRATION_PENDING)) {

                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.OO),
                        UserTaskType.IR_TOTAL_CANCELLATION);
                }

                applicationDao.saveApplication(application);
            }

        } else {
            logger.error(
                "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
        }
    }

    private boolean processOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                           TradeMarkStatusType tradeMarkStatusType) {

        boolean open = false;
        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    open = true;

                    oppositionCase.setOppStatusCode(OppositionCaseStatus.CLOSED.getValue());

                    oppositionCaseDao.saveOppositionCase(oppositionCase);

                    OppositionCaseAction oppositionCaseAction = createOppositionCaseAction(application, oppositionCase,
                        tradeMarkStatusType, SectionAuthority.OPPS45.name());

                    oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
                    oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
                    applicationDao.saveApplication(application);

                    // Notify the requestor(s) (registered), Notify Opponents (Pending)
                    processActionsDao.saveProcessActions(createProcessAction(application,
                        (tradeMarkStatusType == TradeMarkStatusType.REGISTERED
                            ? ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION
                            : ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION),
                        oppositionCase.getOppCaseNumber(), SectionAuthority.MADRID.name()));
                }
            }
        }
        return open;
    }

    private void processOOTransaction(MadridDesignationTerminationType madridDesignationTermination,
                                      Map<ApplicationDto, UserTaskType> statusTypeResults)
        throws MTSServiceFault {

        MadridApplication madridApplication = null;
        String wipoReferenceNumber = madridDesignationTermination.getOfficeReferenceIdentifier() != null
            ? madridDesignationTermination.getOfficeReferenceIdentifier().getValue() : null;

        if (!StringUtils.isBlank(wipoReferenceNumber)) {
            madridApplication = madridApplicationsDao.getMadridApplicationByReferenceNumber(wipoReferenceNumber);
        }
        if (madridApplication == null
            && (!StringUtils.isBlank((madridDesignationTermination.getInternationalRegistrationNumber())))) {
            List<MadridApplication> madridApps = madridApplicationsDao
                .getMadridApplicationByIrNumber(madridDesignationTermination.getInternationalRegistrationNumber());
            if (!CollectionUtils.isEmpty(madridApps)) {
                madridApplication = madridApps.get(0);
            }
        }

        if (null == madridApplication) {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }

        madridApplication.setStatusCode(MadridApplicationStatus.CLOSED.getValue());
        madridApplicationsDao.saveMadridApplication(madridApplication);

        // create new Action for Madrid Application
        createMadridApplicationAction(madridApplication, madridDesignationTermination);
    }

    @Override
    public String getServiceName() {
        return "IRTotalCancellationService";
    }

}
