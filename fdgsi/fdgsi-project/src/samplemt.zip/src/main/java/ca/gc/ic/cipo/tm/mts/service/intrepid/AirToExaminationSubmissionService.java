package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.mts.AirToExaminationRequest;
import ca.gc.ic.cipo.tm.mts.ApplicationNumber;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

@Service
public class AirToExaminationSubmissionService extends MadridTransactionService
    implements IAirToExaminationSubmissionService {

    private static Logger logger = Logger.getLogger(AirToExaminationSubmissionService.class.getName());

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionDao;

    @Autowired
    private ApplicationDao applicationDao;

    private final static Integer MADRID_APPLICATION_STATUS = 1;// pending

    private final static Integer MADRID_ACTION_CODE_STATUS = 6;// created

    @Value("#{environment['mts.madrid.application.action.authority']}")
    private String authorityId;

    @Override
    @Transactional
    public void storeAirToExaminationSubmissionInfo(AirToExaminationRequest airToExaminationRequest)
        throws CIPOServiceFault {

        if (null != madridApplicationDao
            .getMadridApplicationByReferenceNumber(airToExaminationRequest.getWipoRefNumber())) {
            logger.warn("WIPO Reference number " + airToExaminationRequest.getWipoRefNumber()
                + " already exists, ignoring this request");
            return;
            // throwMTSServiceFault("mts.madrid.application.exists", ExceptionReasonCode.OBJECT_EXISTS);
        }

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber(airToExaminationRequest.getIrNumber());
        madridApplication.setStatusCode(MADRID_APPLICATION_STATUS);
        madridApplication.setWipoReferenceNumber(airToExaminationRequest.getWipoRefNumber());

        // Madrid Application Action
        MadridApplicationAction madridApplicationActions = new MadridApplicationAction();
        madridApplicationActions.setActionCode(MADRID_ACTION_CODE_STATUS);
        madridApplicationActions.setActionDate(new Date());
        madridApplicationActions.setAuthorityId(authorityId);
        madridApplicationActions.setWipoReferenceNumber(airToExaminationRequest.getWipoRefNumber());
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationActions.setMadridApplicationActionsSeqNumber(madridApplicationActionId);

        madridApplicationActions.setMadridApplication(madridApplication);

        madridApplication.getMadridApplicationActions().add(madridApplicationActions);

        List<ApplicationNumber> barNumberList = airToExaminationRequest.getBarNumberList();

        // Create Madrid Application Xref

        for (ApplicationNumber applicationNumber : barNumberList) {

            Application application = applicationDao.getApplication(applicationNumber.getFileNumber().intValue(),
                Integer.valueOf(applicationNumber.getExtensionCounter()));
            if (null == application) {
                throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
            }
            MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
            madridApplicationXref.setMadridApplication(madridApplication);
            madridApplicationXref.setExtensionCounter(Integer.valueOf(applicationNumber.getExtensionCounter()));
            madridApplicationXref.setFileNumber(applicationNumber.getFileNumber().intValue());
            madridApplicationXref.setWipoReferenceNumber(airToExaminationRequest.getWipoRefNumber());

            madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);
        }

        madridApplicationDao.saveMadridApplication(madridApplication);

        logger.debug("Stored Air to Examination Submission Info");

    }

    @Override
    @Transactional
    public void updateMadridApplicationXREF(String IR_number, List<ApplicationNumber> barNumberList)
        throws CIPOServiceFault {

        List<MadridApplication> result = madridApplicationDao.getMadridApplicationByIrNumber(IR_number);
        if (result.isEmpty()) {
            throwMTSServiceFault("mts.missing.madrid.application", ExceptionReasonCode.MARK_NOT_FOUND);
        }

        // Get Madrid Application
        MadridApplication madridApplication = result.get(0);

        madridApplication.getMadridApplicationXrefs().clear();
        // Update Madrid Application Xref
        for (ApplicationNumber applicationNumber : barNumberList) {

            Application application = applicationDao.getApplication(applicationNumber.getFileNumber().intValue(),
                Integer.valueOf(applicationNumber.getExtensionCounter()));
            if (null == application) {
                throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
            }
            MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
            madridApplicationXref.setMadridApplication(madridApplication);
            madridApplicationXref.setExtensionCounter(Integer.valueOf(applicationNumber.getExtensionCounter()));
            madridApplicationXref.setFileNumber(applicationNumber.getFileNumber().intValue());
            madridApplicationXref.setWipoReferenceNumber(madridApplication.getWipoReferenceNumber());

            madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);
        }

        // Save or Update Madrid Application
        madridApplicationDao.saveMadridApplication(madridApplication);

        logger.debug("Update Madrid Application XREF ");

    }

    @Override
    public void addMadridApplication(String irNumber, MadridApplicationActionStatus madridApplicationActionStatus)
        throws CIPOServiceFault {

        List<MadridApplication> madridApplicationList = madridApplicationDao.getMadridApplicationByIrNumber(irNumber);
        if (CollectionUtils.isEmpty(madridApplicationList)) {
            throwMTSServiceFault("mts.missing.madrid.application", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        // Get Madrid Application
        MadridApplication madridApplication = madridApplicationList.get(0);
        Set<MadridApplicationAction> madridApplications = madridApplication.getMadridApplicationActions();
        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setActionCode(madridApplicationActionStatus.getValue());
        madridApplicationAction.setActionDate(new Date());
        madridApplicationAction.setAuthorityId(SectionAuthority.OPPS45.name());
        madridApplicationAction.setWipoReferenceNumber(madridApplication.getWipoReferenceNumber());

        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);
        madridApplications.add(madridApplicationAction);

        logger.debug("Added madrid application action");
    }
}
