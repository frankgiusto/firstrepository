package ca.gc.ic.cipo.tm.mts.dto.intl;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingPairCriteria;

public class MergerTransactionDto implements java.io.Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -56836889125923733L;

    private AutomaticProcessingPairCriteria automaticProcessingPairCriteria;

    private AutomatedProcessResponse automatedProcessResponse;

    public AutomaticProcessingPairCriteria getAutomaticProcessingPairCriteria() {
        return automaticProcessingPairCriteria;
    }

    public void setAutomaticProcessingPairCriteria(AutomaticProcessingPairCriteria automaticProcessingPairCriteria) {
        this.automaticProcessingPairCriteria = automaticProcessingPairCriteria;
    }

    public AutomatedProcessResponse getAutomatedProcessResponse() {
        return automatedProcessResponse;
    }

    public void setAutomatedProcessResponse(AutomatedProcessResponse automatedProcessResponse) {
        this.automatedProcessResponse = automatedProcessResponse;
    }

}
