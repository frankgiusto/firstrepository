package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class IntlAtchmtDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 6330610491693111072L;

    private BigDecimal atchmtId;

    private BigDecimal irTranId;

    private BigDecimal pkgId;

    private BigDecimal atchmtCtgryId;

    private BigDecimal fileFrmtId;

    private String fileFrmtCtgry;

    private String fileName;

    private Timestamp createdTmstmp;

    public BigDecimal getAtchmtId() {
        return atchmtId;
    }

    public void setAtchmtId(BigDecimal atchmtId) {
        this.atchmtId = atchmtId;
    }

    public BigDecimal getIrTranId() {
        return irTranId;
    }

    public void setIrTranId(BigDecimal irTranId) {
        this.irTranId = irTranId;
    }

    public BigDecimal getPkgId() {
        return pkgId;
    }

    public void setPkgId(BigDecimal pkgId) {
        this.pkgId = pkgId;
    }

    public BigDecimal getAtchmtCtgryId() {
        return atchmtCtgryId;
    }

    public void setAtchmtCtgryId(BigDecimal atchmtCtgryId) {
        this.atchmtCtgryId = atchmtCtgryId;
    }

    public BigDecimal getFileFrmtId() {
        return fileFrmtId;
    }

    public void setFileFrmtId(BigDecimal fileFrmtId) {
        this.fileFrmtId = fileFrmtId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileFrmtCtgry() {
        return fileFrmtCtgry;
    }

    public void setFileFrmtCtgry(String fileFrmtCtgry) {
        this.fileFrmtCtgry = fileFrmtCtgry;
    }

    public Timestamp getCreatedTmstmp() {
        return createdTmstmp;
    }

    public void setCreatedTmstmp(Timestamp createdTmstmp) {
        this.createdTmstmp = createdTmstmp;
    }

    @Override
    public String toString() {
        return "IntlAtchmtDto [atchmtId=" + atchmtId + ", irTranId=" + irTranId + ", pkgId=" + pkgId
            + ", atchmtCtgryId=" + atchmtCtgryId + ", fileFrmtId=" + fileFrmtId + ", fileFrmtCtgry=" + fileFrmtCtgry
            + ", fileName=" + fileName + ", createdTmstmp=" + createdTmstmp + "]";
    }

}
