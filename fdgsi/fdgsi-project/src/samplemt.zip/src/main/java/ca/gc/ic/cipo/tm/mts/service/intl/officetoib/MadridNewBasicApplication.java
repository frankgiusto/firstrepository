package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridNewBasicApplicationType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public class MadridNewBasicApplication extends OfficeToIbBase implements IOutboundTransaction {

    private static Logger log = Logger.getLogger(MadridNewBasicApplication.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = null;

    public MadridNewBasicApplication(MadridOutboundTransactionType madridOutboundTransactionType) {
        this.madridOutboundTransactionType = madridOutboundTransactionType;
    }

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        MadridNewBasicApplicationType transaction = objectFactory.createMadridNewBasicApplicationType();
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Holder Bag
        transaction.setHolderBag(super.mapHolder(
            outboundTransactionDto.getProcessActionApplication().getTmInterestedPartyTypeList(), notificationLanguage));

        // Basic Registration Application Bag
        transaction.setBasicRegistrationApplicationBag(
            basicRegistrationApplication(outboundTransactionDto.getMadridApplicationActionDetails()));

        JAXBElement<MadridNewBasicApplicationType> madridobject = objectFactory
            .createMadridNewBasicApplication(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public boolean isPdfRequired() {
        return false;
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }

}
