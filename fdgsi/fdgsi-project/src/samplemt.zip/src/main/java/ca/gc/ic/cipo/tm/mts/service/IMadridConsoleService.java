/*
 *
 */
package ca.gc.ic.cipo.tm.mts.service;

import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GetManualReportRequest;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessIrregularitySubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportResponse;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;

public interface IMadridConsoleService {

    /**
     * Process goods and services.
     *
     * @param gsInfo the gs info
     * @return the goods and services changes response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public GoodsAndServicesChangesResponse processGoodsAndServicesChanges(GoodsAndServiceMeta gsInfo,
                                                                          ActionCode actionCode)
        throws CIPOServiceFault;

    /**
     * Process partial ownership request for a Partial Ownership Change.
     *
     * @param irTaskId the ir task id
     * @param notificationLanguage the notification language
     * @param designation the designation
     * @param restriction the restriction
     * @return the goods and services changes response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public GoodsAndServicesChangesResponse processPartialOwnershipRequest(BigDecimal irTaskId,
                                                                          String notificationLanguage,
                                                                          PartialOwnershipMeta designation,
                                                                          PartialOwnershipMeta restriction)
        throws CIPOServiceFault;

    /**
     * Gets the manual report. Information for the madrid console manual task is provided to be used in populating mf
     * forms
     *
     * @param request the request
     * @return the manual report
     * @throws MTSServiceFault the MTS service fault
     */
    public ProcessManualReportRequest getManualReport(GetManualReportRequest request) throws MTSServiceFault;

    /**
     * Process manual report. Madrid console request to complete user task which results in generating a mf form via
     * rgs.
     *
     * @param manualReportRequest the manual report request
     * @return the process manual report response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public ProcessManualReportResponse processManualReport(ProcessManualReportRequest manualReportRequest)
        throws CIPOServiceFault;

    /**
     * Process irregularity submission. Creates an irregularity outbound transaction.
     *
     * @param irregularitySubmissionRequest the irregularity submission request
     * @throws CIPOServiceFault the CIPO service fault
     */
    public void processIrregularitySubmission(ProcessIrregularitySubmissionRequest irregularitySubmissionRequest)
        throws CIPOServiceFault;

    /**
     * Process IR correction submission. Creates actions.
     *
     * @param request
     * @throws CIPOServiceFault
     */
    public void processIRCorrectionSubmission(ProcessIRCorrectionSubmissionRequest request) throws CIPOServiceFault;

    /**
     * Process modified representative address submission. Creates actions.
     *
     * @param request
     * @throws CIPOServiceFault
     */
    public void processModifiedRepAddressSubmission(ProcessModifiedRepAddressSubmissionRequest request)
        throws CIPOServiceFault;
}
