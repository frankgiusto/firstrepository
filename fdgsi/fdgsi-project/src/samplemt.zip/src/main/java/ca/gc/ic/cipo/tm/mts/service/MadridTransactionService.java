package ca.gc.ic.cipo.tm.mts.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;

import _int.wipo.standards.xmlschema.st96.common.madrid.AddressLineTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.CorrespondenceAddressType;
import _int.wipo.standards.xmlschema.st96.common.madrid.EntityNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.common.madrid.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrganizationNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PersonNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PhraseType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType;
import _int.wipo.standards.xmlschema.st96.common.madrid.RepresentativeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridAbandonmentNotificationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridBasicRegistrationApplicationChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridInternationalRegistrationCreationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridRenewalType;
import ca.gc.ic.cipo.report.RuntimeJobState;
import ca.gc.ic.cipo.tm.dao.CountryProvinceLookupDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.enumerator.CorrespondenceType;
import ca.gc.ic.cipo.tm.enumerator.FileType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.MailModeType;
import ca.gc.ic.cipo.tm.enumerator.MailType;
import ca.gc.ic.cipo.tm.enumerator.OppositionActionType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsProcessType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlAtchmtTypeCode;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfo;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.CountryProvince;
import ca.gc.ic.cipo.tm.model.FigurativeElement;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlAtchmtDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFileTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFilenameDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.RepresentativeAddressDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.LanguageIndicator;
import ca.gc.ic.cipo.tm.mts.enums.MailTypeTransactionCategory;
import ca.gc.ic.cipo.tm.mts.enums.NfsFileName;
import ca.gc.ic.cipo.tm.mts.enums.NfsFileType;
import ca.gc.ic.cipo.tm.mts.enums.OriginalIndicator;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.ValidateWipoTransactionUtil;
import ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;

/**
 * This is the base abstract class for the Madrid Transaction Service (MTS).
 */
public abstract class MadridTransactionService extends AbstractMtsService {

    private static Logger logger = Logger.getLogger(MadridTransactionService.class.getName());

    private static final String CONTACT_NAME_DELIMETER = "; ";

    private static final String COUNTRY_CODE_CANADA = "CA";

    protected static final int MAIL_INDICATOR_AUTOMATED = 1;

    protected static final int MAIL_INDICATOR_MANUAL = 0;

    protected static final int MAIL_PROCESSED_INDICATOR = 1;

    protected final static String VIENNA_CATEGORY = "28";

    protected final static String VIENNA_DIVISION = "11";

    protected final static int LIMITATION_LIST_CODE_EXAMINED = 2;

    protected final static int LIMITATION_LIST_CODE_NOTEXAMINED = 1;

    private final static int OPP_STAGE_CODE_301 = 301;

    private final static int OPP_STAGE_CODE_1 = 1;

    private final static String WHITE_SPACE = " ";

    private final static String NEW_LINE = "\n";

    private final static String COUNTRYCODE_CANADA = "CA";

    protected final static String PNG_EXT = "png";

    protected final static String PDF_EXT = "pdf";

    protected final static String FILE_BASE_NAME = "_Ctsy";

    protected final static int DEFAULT_EXTENSION_COUNTER = 0;

    protected final EnumSet<OppositionCaseType> registeredOppositionCaseTypes = EnumSet.of(
        OppositionCaseType.SECTION_44, OppositionCaseType.SECTION_45,
        OppositionCaseType.SECTION_45_REQUESTED_BY_REGISTRAR);

    protected final EnumSet<OppositionCaseType> unRegisteredOppositionCaseTypes = EnumSet
        .of(OppositionCaseType.OPPOSITION);

    protected final EnumSet<OppositionCaseStatus> openStatusTypes = EnumSet.of(OppositionCaseStatus.ACTIVE,
        OppositionCaseStatus.PENDING, OppositionCaseStatus.AWAITING_DECISION,
        OppositionCaseStatus.DECIDED_PENDING_APPEAL, OppositionCaseStatus.APPEL_IN_PROGRESS,
        OppositionCaseStatus.ACTIVE_POST_APPEAL);

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private CountryProvinceLookupDao countryProvinceLookupDao;

    @Autowired
    private MailDao mailDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionDao;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Value("#{environment['mts.tm.information.retrieval.services.host.name']}")
    private String tmirServiceHost;

    @Value("#{environment['mts.rgs.polling.attempts']}")
    private Integer pollingAttempts;

    /**
     *
     */
    public MadridTransactionService() {

    }

    protected LanguageType getApplicationLanguage(ISOLanguageCodeType transactionLanguage) {
        if (transactionLanguage == ISOLanguageCodeType.EN || transactionLanguage == ISOLanguageCodeType.ES) {
            return LanguageType.ENGLISH;
        } else {
            return LanguageType.FRENCH;
        }
    }

    protected ProcessAction createProcessAction(Application application, ProcessActionsType processActionsType,
                                                Integer oppositionCaseNumber, String authorityId) {

        ProcessAction processActions = initProcessAction(application, processActionsType, authorityId);

        processActions.setOppositionCaseNumber(oppositionCaseNumber);

        return processActions;
    }

    protected ProcessAction createProcessAction(Application application, ProcessActionsType processActionsType,
                                                String authorityId, String additionalInfo) {

        ProcessAction processActions = initProcessAction(application, processActionsType, authorityId);
        processActions.setAdditionalInfo(additionalInfo);

        return processActions;
    }

    protected ProcessAction createProcessAction(Application application, ProcessActionsType processActionsType,
                                                String authorityId) {

        ProcessAction processActions = initProcessAction(application, processActionsType, authorityId);

        return processActions;
    }

    protected ProcessAction createCourtestLetterProcessAction(Application application,
                                                              ProcessActionsType processActionsType, String authorityId,
                                                              String fileName) {

        ProcessAction processActions = initProcessAction(application, processActionsType, authorityId);
        if (fileName != null) {
            processActions.setAdditionalInfo(fileName);
        }

        return processActions;
    }

    private ProcessAction initProcessAction(Application application, ProcessActionsType processActionsType,
                                            String authorityId) {

        ProcessAction processActions = new ProcessAction();
        processActions.setFileNumber(application.getFileNumber());
        processActions.setExtensionCounter(application.getExtensionCounter());
        processActions.setProcessType(ProcessActionsProcessType.BATCH.getValue());
        processActions.setProcessCode(processActionsType.getValue());
        processActions.setAuthorityId(authorityId);
        processActions.setIrNumber(application.getIrNumber());
        processActions.setApplication(application);
        processActions.setProcessDate(new Date());
        application.getProcessActions().add(processActions);

        return processActions;
    }

    protected Action createAction(Application application, ActionCode actionCode, String authorityId,
                                  String additionalInfo) {

        Action action = this.createAction(application, actionCode, authorityId);
        action.setAdditionalInfo(additionalInfo);
        return action;
    }

    protected Action createAction(Application application, ActionCode actionCode, String authorityId) {
        Action action = new Action();

        action.setApplication(application);
        action.setFileNumber(application.getFileNumber());
        action.setExtensionCounter(application.getExtensionCounter());
        action.setActionCode(actionCode.getValue());
        action.setActionDate(new Timestamp(new Date().getTime()));
        action.setAuthorityId(authorityId);
        application.getActions().add(action);

        return action;
    }

    protected Action createAction(Object objType, Application application, ActionCode actionCode, String authorityId,
                                  String message) {
        Action action = new Action();

        action.setApplication(application);
        action.setFileNumber(application.getFileNumber());
        action.setExtensionCounter(application.getExtensionCounter());
        action.setActionCode(actionCode.getValue());
        action.setAuthorityId(authorityId);
        action.setActionDate(new Timestamp(new Date().getTime()));

        if (objType instanceof MadridBasicRegistrationApplicationChangeType && message != null) {
            action.setAdditionalInfo(message.trim());

        } else if (objType instanceof MadridHolderRepresentativeChangeType && message != null) {
            if (actionCode == ActionCode.IR_NOTIFICATION_FILED) { // only apply
                                                                  // to
                                                                  // IRNotificationService
                action.setAdditionalInfo(message.trim());
                // (message + " - " +
                // TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE.name()).trim());
            } else {
                action.setAdditionalInfo(message.trim());
            }
        } else {
            action.setAdditionalInfo("DP:" + getFormattedSystemDate());
        }

        if (objType instanceof MadridRenewalType) {
            MadridRenewalType madridRenewalType = (MadridRenewalType) objType;
            setActionDate(action, madridRenewalType.getRenewalDate(), "MadridRenewalType");

            // set responseDate(BF Date)
            if (madridRenewalType.getExpiryDate() != null) {
                try {
                    action.setResponseDate(DateFormats.getISOSDF().parse(madridRenewalType.getExpiryDate()));
                } catch (ParseException e) {
                    logger.error("Could not parse expiry date: " + madridRenewalType.getExpiryDate(), e);
                }
            }
        } else if (objType instanceof MadridDesignationTerminationType) {
            MadridDesignationTerminationType terminationType = (MadridDesignationTerminationType) objType;
            setActionDate(action, terminationType.getExpiryDate(), "MadridDesignationTerminationType");

        } else if (objType instanceof MadridProtectionRestrictionType) {
            MadridProtectionRestrictionType protectionType = (MadridProtectionRestrictionType) objType;
            setActionDate(action, protectionType.getRecordEffectiveDate(), "MadridProtectionRestrictionType");
        }
        application.getActions().add(action);

        return action;
    }

    private void setActionDate(Action action, String dateFromType, String type) {
        if (dateFromType == null) {
            logger.error("Date is null!");
        } else {
            try {
                action.setActionDate(DateFormats.getISOSDF().parse(dateFromType));
            } catch (ParseException e) {
                logger.error(
                    "Could not parse expiry or renewal or record notification date: " + dateFromType + " from " + type,
                    e);
            }
        }
    }

    protected OppositionCaseAction createOppositionCaseAction(Application application, OppositionCase oppositionCase,
                                                              TradeMarkStatusType tradeMarkStatusType,
                                                              String authorityId) {

        List<OppositionCaseAction> caseActions = oppositionCase.getOppositionCaseActions();
        logger.debug("caseActions: " + caseActions.size());

        OppositionCaseAction oppositionCaseAction = new OppositionCaseAction();
        oppositionCaseAction.setFileNumber(application.getFileNumber());
        oppositionCaseAction.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseAction.setActionDate(new Date());
        // OppositionCaseAction lastCaseAction = getLastCaseAction(caseActions);
        // logger.debug("lastCaseAction: " + lastCaseAction);
        // oppositionCaseAction.setOppStageCode(lastCaseAction.getOppStageCode());

        oppositionCaseAction.setOppCaseNumber(oppositionCase.getOppCaseNumber());

        if (tradeMarkStatusType == TradeMarkStatusType.REGISTERED) {
            oppositionCaseAction.setOppActionCode(OppositionCaseActionCodeType.CLOSED_BY_TMO.getValue());
            oppositionCaseAction.setOppStageCode(OPP_STAGE_CODE_301);
        } else {
            oppositionCaseAction.setOppActionCode(OppositionCaseActionCodeType.CASE_CLOSED_BY_TMO.getValue());
            oppositionCaseAction.setOppStageCode(OPP_STAGE_CODE_1);
        }
        logger.debug("OppActionCode: " + oppositionCaseAction.getOppActionCode());

        // oppositionCaseAction.setOppActionType(1);
        oppositionCaseAction.setOppActionType(OppositionActionType.SYSTEM_GENERATED.getValue());
        logger.debug("OppActionType: " + oppositionCaseAction.getOppActionType());

        oppositionCaseAction.setAuthorityId(authorityId);
        oppositionCaseAction.setOppositionCase(oppositionCase);

        return oppositionCaseAction;
    }

    /**
     * Gets the next interested party sequence.
     *
     * @param interestedParties the interested parties
     * @return the next interested party sequence
     */
    protected Integer getNextInterestedPartySequence(Set<InterestedParty> interestedParties) {

        TreeSet<InterestedParty> sortedSet = new TreeSet<>(getInterestedPartyComparator());
        sortedSet.addAll(interestedParties);

        return sortedSet.last().getIpNumber() + 1;
    }

    protected Integer getNextFootnoteSequence(Set<Footnote> interestedParties) {

        TreeSet<Footnote> sortedSet = new TreeSet<>(getFootnoteComparator());
        sortedSet.addAll(interestedParties);

        if (CollectionUtils.isEmpty(sortedSet)) {
            return 1;
        }
        return sortedSet.last().getSequenceNumber() + 1;
    }

    /**
     * Gets the interested party name. Names for each contact is concatenated into the result. This method is used if
     * the interested party exists in Intrepid but we are just updating the name.
     *
     * @param applicantList the applicant list
     * @return the interested party name
     */
    protected String getInterestedPartyName(List<ApplicantType> applicantList) {

        StringBuilder contactName = new StringBuilder();

        for (ApplicantType holder : applicantList) {
            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    break;
                }
            }
            if (null == contact) {
                logger.error("Holder does not contain a contact");
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                logger.error("Contact does not have a NameType.");
                continue;
            }
            InterestedParty interestedPartyHolder = getInterestedPartyContact(contact, holder);

            if (contactName.length() > 0) {
                contactName.append(CONTACT_NAME_DELIMETER);
            }
            contactName.append(interestedPartyHolder.getContact().getName());

        }

        return contactName.toString();
    }

    /**
     * Gets the interested party contact from the WIPO transaction.
     *
     * @param contact the contact
     * @param holder the holder
     * @return the interested party contact
     */
    private InterestedParty getInterestedPartyContact(ContactType contact, ApplicantType holder) {
        InterestedParty interestedPartyHolder = new InterestedParty();

        IPContact nameContact = null;
        IPContact businessContact = null;
        IPContact entityContact = null;

        for (Object personNameOrOrganizationNameOrEntityName : contact.getName()
            .getPersonNameOrOrganizationNameOrEntityName()) {

            if (personNameOrOrganizationNameOrEntityName instanceof PersonNameType) {

                nameContact = new IPContact();
                nameContact.setName(((PersonNameType) personNameOrOrganizationNameOrEntityName).getPersonFullName());

                interestedPartyHolder.setContact(nameContact);

            } else if (personNameOrOrganizationNameOrEntityName instanceof OrganizationNameType) {
                businessContact = new IPContact();

                OrganizationNameType organizationNameType = (OrganizationNameType) personNameOrOrganizationNameOrEntityName;
                PhraseType orgStandardName = organizationNameType.getOrganizationStandardName();
                StringBuilder standardNameBuffer = new StringBuilder();
                for (Serializable standardName : orgStandardName.getContent()) {
                    if (standardNameBuffer.length() > 0) {
                        standardNameBuffer.append(";");
                    }
                    standardNameBuffer.append(standardName);
                }
                // TODO adjust once I see example data for this.
                businessContact.setName(standardNameBuffer.toString());

                interestedPartyHolder.setBusinessContact(businessContact);

            } else if (personNameOrOrganizationNameOrEntityName instanceof EntityNameType) {
                entityContact = new IPContact();
                entityContact.setName(((EntityNameType) personNameOrOrganizationNameOrEntityName).getValue());
            }
            break; // Primary Address only required
        }
        // Name is mandatory.
        if (null == interestedPartyHolder.getContact()) {
            if (null != entityContact) {
                interestedPartyHolder.setContact(entityContact);
            } else {
                interestedPartyHolder.setContact(businessContact);
            }
        }
        return interestedPartyHolder;

    }

    protected void setInterestedPartyContact(LanguageType applicationLanguage, List<ApplicantType> holderList,
                                             Application application, InterestedParty interestedParty) {

        this.setInterestedPartyContact(applicationLanguage, holderList, application, interestedParty, false);
    }

    /**
     * Sets the interested party contact. This method is called if we are creating a new interested party in Intrepid
     *
     * @param holderList the holder list
     * @param application the application
     * @param interestedParty the interested party
     */
    protected void setInterestedPartyContact(LanguageType applicationLanguage, List<ApplicantType> holderList,
                                             Application application, InterestedParty interestedParty,
                                             boolean validateOnly) {

        StringBuilder contactName = new StringBuilder();

        int idx = 0;
        for (ApplicantType holder : holderList) {
            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    break;
                }
            }
            if (null == contact) {
                logger.error("Holder does not contain a contact");
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                logger.error("Contact does not have a NameType.");
                continue;
            }
            InterestedParty interestedPartyHolder = createInterestedPartyContact(contact);
            if (idx == 0) {
                interestedParty.setContact(interestedPartyHolder.getContact());
                interestedParty.getContact().setLanguage(applicationLanguage.getValue());
                idx++;
            }
            if (contactName.length() > 0) {
                contactName.append(CONTACT_NAME_DELIMETER);
            }
            contactName.append(interestedPartyHolder.getContact().getName());

        }
        if (!validateOnly) {
            logger.debug("Save interested party contact for " + interestedParty.getIpNumber());

            interestedParty.getContact().setName(contactName.toString());
            interestedPartyDao.saveInterestedParty(interestedParty);
        }

    }

    /**
     * Creates the interested party contact. This extracts the contact from the WIPO transaction.
     *
     * @param contact the contact
     * @return the interested party
     */
    protected InterestedParty createInterestedPartyContact(ContactType contact) {

        IPContact nameContact = null;
        IPContact businessContact = null;
        IPContact entityContact = null;
        InterestedParty interestedPartyHolder = new InterestedParty();

        for (Object personNameOrOrganizationNameOrEntityName : contact.getName()
            .getPersonNameOrOrganizationNameOrEntityName()) {

            if (personNameOrOrganizationNameOrEntityName instanceof PersonNameType) {
                nameContact = new IPContact();

                nameContact.setName(((PersonNameType) personNameOrOrganizationNameOrEntityName).getPersonFullName());
                interestedPartyHolder.setContact(nameContact);

            } else if (personNameOrOrganizationNameOrEntityName instanceof OrganizationNameType) {
                businessContact = new IPContact();

                OrganizationNameType organizationNameType = (OrganizationNameType) personNameOrOrganizationNameOrEntityName;
                PhraseType orgStandardName = organizationNameType.getOrganizationStandardName();
                StringBuilder standardNameBuffer = new StringBuilder();
                for (Serializable standardName : orgStandardName.getContent()) {
                    if (standardNameBuffer.length() > 0) {
                        standardNameBuffer.append(CONTACT_NAME_DELIMETER);
                    }
                    standardNameBuffer.append(standardName);
                }

                businessContact.setName(standardNameBuffer.toString());

            } else if (personNameOrOrganizationNameOrEntityName instanceof EntityNameType) {
                entityContact = new IPContact();

                entityContact.setName(((EntityNameType) personNameOrOrganizationNameOrEntityName).getValue());

            }
            break; // Primary Address only required
        }
        // Name is mandatory.
        if (null == interestedPartyHolder.getContact()) {
            if (null != entityContact) {
                interestedPartyHolder.setContact(entityContact);
            } else {
                interestedPartyHolder.setContact(businessContact);
            }
        }
        return interestedPartyHolder;
    }

    /**
     * Creates the interested party address.
     *
     * @param application the application
     * @param wipoContact the wipo contact
     * @param interestedParty the interested party
     * @param addressType the address type
     * @return the interested parties addresses
     * @throws MTSServiceFault
     */
    private InterestedPartiesAddresses createInterestedPartyAddress(Application application, ContactType wipoContact,
                                                                    InterestedParty interestedParty,
                                                                    AddressType addressType) {

        logger.debug("createInterestedPartyAddress");

        InterestedPartiesAddresses interestedPartyAdress = null;
        // try {
        interestedParty.setCorrespondenceType(CorrespondenceType.PAPER_MAIL.getValue());

        // Postal Code, Country Code
        if (null != wipoContact.getPostalAddressBag()) {
            List<PostalAddressType> postalAddress = wipoContact.getPostalAddressBag().getPostalAddress();
            for (PostalAddressType address : postalAddress) {
                interestedPartyAdress = new InterestedPartiesAddresses();
                interestedPartyAdress.setExtensionCounter(application.getExtensionCounter());
                interestedPartyAdress.setFileNumber(application.getFileNumber());
                interestedPartyAdress.setIpNumber(interestedParty.getIpNumber());
                interestedPartyAdress.setCountryProvince(address.getPostalStructuredAddress().getCountryCode());

                String postalCode = address.getPostalStructuredAddress().getPostalCode();
                String countryCode = address.getPostalStructuredAddress().getCountryCode();
                // set postal code only for Canada
                if (StringUtils.isNotBlank(postalCode) && countryCode.equalsIgnoreCase(COUNTRY_CODE_CANADA)) {
                    interestedPartyAdress.setPostalCode(postalCode);
                }

                StringBuilder addressText = new StringBuilder();

                for (AddressLineTextType addressLineText : address.getPostalStructuredAddress().getAddressLineText()) {

                    addressText.append(addressLineText.getValue()).append("\r\n");
                }
                if (addressType == AddressType.MAILING && StringUtils.isNotBlank(countryCode)) {
                    if (null != address.getPostalStructuredAddress()
                        && null != address.getPostalStructuredAddress().getCountryCode()) {

                        String cCode = null;

                        CountryProvince countryProvince = countryProvinceLookupDao.getCountry(
                            address.getPostalStructuredAddress().getCountryCode(), LanguageType.ENGLISH.getValue());

                        if (null != countryProvince) {
                            cCode = countryProvince.getDescription();
                            addressText.append(cCode).append(" ");
                        } else {
                            logger.error(
                                "Cannot find country for: " + address.getPostalStructuredAddress().getCountryCode());
                        }
                    }
                }

                // concatenate postal code in main address only for foreign
                // countries
                if (addressType == AddressType.PRIMARY && StringUtils.isNotBlank(postalCode)
                    && !countryCode.equalsIgnoreCase(COUNTRY_CODE_CANADA)) {
                    addressText.append(address.getPostalStructuredAddress().getPostalCode());
                }

                interestedPartyAdress.setAddress(addressText.toString().trim());
                interestedPartyAdress.setAddressType(addressType.getValue());

                break;
            }
        }

        return interestedPartyAdress;

    }

    /**
     * Sets the interested party address.
     *
     * @param applicantList the applicant list
     * @param application the application
     * @param interestedParty the interested party
     * @throws MTSServiceFault
     */
    protected void setInterestedPartyAddress(List<ApplicantType> applicantList, Application application,
                                             InterestedParty interestedParty, Object obj)
        throws MTSServiceFault {

        for (ApplicantType holder : applicantList) {
            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    break;
                }
            }
            if (null == contact) {
                logger.error("Holder does not contain a contact");
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                logger.error("Contact does not have a NameType.");
                continue;
            }

            interestedParty.getContact()
                .setInterestedPartiesAddresses(getInterestedPartyAddress(application, interestedParty, contact, obj));

            break; // first holder
        }

    }

    private InterestedPartiesAddresses createMailingAddress(Application application, InterestedParty interestedParty,
                                                            ContactType contact)
        throws MTSServiceFault {

        InterestedPartiesAddresses ipMailingAddress = createInterestedPartyAddress(application, contact,
            interestedParty, AddressType.MAILING);

        StringBuilder mailingAddress = new StringBuilder();
        if (StringUtils.isNotEmpty(interestedParty.getContact().getName())) {
            mailingAddress.append(interestedParty.getContact().getName()).append("\r\n")
                .append(ipMailingAddress.getAddress());
        } else {
            mailingAddress.append(ipMailingAddress.getAddress());
        }

        ipMailingAddress.setAddress(mailingAddress.toString());

        return ipMailingAddress;
    }

    private Set<InterestedPartiesAddresses> getInterestedPartyAddress(Application application,
                                                                      InterestedParty interestedParty,
                                                                      ContactType mainContact, Object obj)
        throws MTSServiceFault {

        logger.debug("Which type: " + obj);

        // check CorrespondenceAddress
        boolean isDifferentAddress = false;
        CorrespondenceAddressType caType = getCorrsponseTypeAddressByType(obj);

        ContactType caContact = null;
        if (caType != null && !compareCorrespondenceAndMainAddress(obj)) {
            logger.debug("CorrespondenceAddress exists and differs from Holder Address");

            caContact = getContactTypeByType(obj);
            isDifferentAddress = true;
        }

        Set<InterestedPartiesAddresses> interestedPartiesAddresses = new HashSet<>(0);
        for (Object name : mainContact.getName().getPersonNameOrOrganizationNameOrEntityName()) {

            if (name instanceof PersonNameType || name instanceof OrganizationNameType
                || name instanceof EntityNameType) {

                // set address properties and mailing address
                setIPAndMailingAddressesByOption(application, interestedParty, mainContact, caContact,
                    isDifferentAddress, interestedPartiesAddresses);
            }

            break; // Primary Address only required
        }

        return interestedPartiesAddresses;
    }

    protected void addNameToken(StringBuilder representativeAddress, String token) {
        if (representativeAddress.length() > 0) {
            representativeAddress.append(";");
        }
        representativeAddress.append(token);
    }

    protected boolean openOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes) {

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    return true;

                }
            }
        }
        return false;
    }

    protected InterestedParty createMHRInterestedParty(Application application, int ipNumber) {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(application.getFileNumber());
        interestedParty.setIpNumber(ipNumber);
        interestedParty.setApplication(application);

        interestedParty.setExtensionCounter(application.getExtensionCounter());
        interestedParty.setRelationshipType(RelationshipType.OWNER.getValue());
        interestedParty.setCorrespondenceType(CorrespondenceType.PAPER_MAIL.getValue());
        interestedParty.setApplicantInd(0);
        interestedParty.setRegistrantInd(0);

        return interestedParty;
    }

    protected void buildGSText(List<OrderedTextType> textList, Set<GoodServiceText> goodsServicesText,
                               GoodService goodsService, Application application, LanguageType applicationLanguage) {

        StringBuilder gsDescriptionTextEnglish = new StringBuilder();
        StringBuilder gsDescriptionTextFrench = new StringBuilder();

        for (LocalizedTextType localizedTextType : textList) {

            if (null != localizedTextType.getLanguageCode()) {
                if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.EN.value())) {
                    gsDescriptionTextEnglish.append(localizedTextType.getValue());
                } else if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.FR.value())) {
                    gsDescriptionTextFrench.append(localizedTextType.getValue());
                }
            } else {
                gsDescriptionTextEnglish.append(localizedTextType.getValue());
            }

        }

        if (gsDescriptionTextEnglish.length() > 0) {
            goodsServicesText.add(createGoodServiceText(application, goodsService, gsDescriptionTextEnglish.toString(),
                ISOLanguageCodeType.EN, applicationLanguage));
        }

        if (gsDescriptionTextFrench.length() > 0) {
            goodsServicesText.add(createGoodServiceText(application, goodsService, gsDescriptionTextFrench.toString(),
                ISOLanguageCodeType.FR, applicationLanguage));
        }
    }

    protected GoodServiceType goodsOrService(String classNumberString) throws MTSServiceFault {

        Integer classNumber = null;
        try {
            classNumber = Integer.valueOf(classNumberString);
            if (classNumber == 0) {
                throwMTSServiceFault("mts.invalid.gs.class.number", ExceptionReasonCode.INVALID_CLASS_NUMBER);
            }
        } catch (Exception e) {

            throwMTSServiceFault("mts.invalid.gs.class.number", ExceptionReasonCode.INVALID_CLASS_NUMBER);

        }
        if (classNumber > 0 && classNumber < 35) {
            return GoodServiceType.GOODS;
        }

        return GoodServiceType.SERVICES;
    }

    protected GoodServiceText createGoodServiceText(Application application, GoodService goodsService, String gsText,
                                                    ISOLanguageCodeType textLanguage,
                                                    LanguageType applicationLanguage) {

        GoodServiceText goodServiceText = new GoodServiceText();

        goodServiceText.setFileNumber(application.getFileNumber());
        goodServiceText.setExtensionCounter(application.getExtensionCounter());
        goodServiceText.setNumber(goodsService.getNumber());
        goodServiceText.setType(goodsService.getType());
        goodServiceText.setOriginalInd(getGSOriginalIndicator(textLanguage, applicationLanguage));
        goodServiceText.setModifiedTimestamp(new Date());
        goodServiceText.setLanguage(getGSLanguageIndicator(textLanguage, applicationLanguage));

        goodServiceText.setText(gsText);

        return goodServiceText;
    }

    protected Integer getGSLanguageIndicator(ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        if (applicationLanguage == LanguageType.ENGLISH) {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return LanguageIndicator.APP_ENGLISH_GOODS_SERVICES_ENGLISH.getLanguage();
            } else {
                return LanguageIndicator.APP_ENGLISH_GOODS_SERVICES_FRENCH.getLanguage();
            }
        } else {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return LanguageIndicator.APP_FRENCH_GOODS_SERVICES_ENGLISH.getLanguage();
            } else {
                return LanguageIndicator.APP_FRENCH_GOODS_SERVICES_FRENCH.getLanguage();
            }
        }
    }

    private Integer getGSOriginalIndicator(ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        if (applicationLanguage == LanguageType.ENGLISH) {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return OriginalIndicator.APP_ENGLISH_GOODS_SERVICES_ENGLISH.getOrininalInd();
            } else {
                return OriginalIndicator.APP_ENGLISH_GOODS_SERVICES_FRENCH.getOrininalInd();
            }
        } else {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return OriginalIndicator.APP_FRENCH_GOODS_SERVICES_ENGLISH.getOrininalInd();
            } else {
                return OriginalIndicator.APP_FRENCH_GOODS_SERVICES_FRENCH.getOrininalInd();
            }
        }
    }

    protected Comparator<GoodService> getGoodServiceComparator() {
        Comparator<GoodService> goodServiceList = new Comparator<GoodService>() {

            @Override
            public int compare(GoodService left, GoodService right) {
                return left.getNumber() - right.getNumber();
            }
        };
        return goodServiceList;
    }

    protected Comparator<OppositionCaseAction> getOppositionCaseComparator() {
        Comparator<OppositionCaseAction> getOppositionCaseList = new Comparator<OppositionCaseAction>() {

            @Override
            public int compare(OppositionCaseAction left, OppositionCaseAction right) {
                return left.getOppCaseNumber() - right.getOppCaseNumber();
            }
        };
        return getOppositionCaseList;
    }

    protected Comparator<InterestedParty> getInterestedPartyComparator() {
        Comparator<InterestedParty> getInterestedPartyList = new Comparator<InterestedParty>() {

            @Override
            public int compare(InterestedParty left, InterestedParty right) {
                return left.getIpNumber() - right.getIpNumber();
            }
        };
        return getInterestedPartyList;
    }

    protected Comparator<Footnote> getFootnoteComparator() {
        Comparator<Footnote> getFootnoteList = new Comparator<Footnote>() {

            @Override
            public int compare(Footnote left, Footnote right) {
                return left.getSequenceNumber().intValue() - right.getSequenceNumber().intValue();
            }
        };
        return getFootnoteList;
    }

    protected boolean mailingAddressLengthNotification(List<ApplicantType> holderList,
                                                       InterestedParty interestedParty) {

        ValidateWipoTransactionUtil validateWipoTransactionUtil = ValidateWipoTransactionUtil.getInstance();
        int totalLines = validateWipoTransactionUtil.getMailingAddressTotalLines(holderList);

        if (totalLines > ValidateWipoTransactionUtil.LINE_LIMIT) {
            // No need to check length of text ad there are too many lines.
            logger.debug("Mailing Address length exceeds limit of 8 lines. Lines received: " + totalLines);
            return true;
        }

        IPContact contact = interestedParty.getContact();

        int contactNameLength = contact.getName().length();
        int mailingAddressTextLength = 0;

        // Save the new address
        for (InterestedPartiesAddresses eachAddress : interestedParty.getContact().getInterestedPartiesAddresses()) {
            if (eachAddress.getAddressType().intValue() == AddressType.MAILING.getValue().intValue()) {
                mailingAddressTextLength = eachAddress.getAddress().length();

                break;
            }
        }

        if (contactNameLength + mailingAddressTextLength > ValidateWipoTransactionUtil.ADDRESS_LIMIT) {
            logger.debug("Mailing Address text exceeds limit of " + ValidateWipoTransactionUtil.ADDRESS_LIMIT
                + ". Total size received: " + (contactNameLength + mailingAddressTextLength));
            return true;
        }
        return false;
    }

    protected List<NfsFilenameDto> setNFSFilename(List<IntlAtchmtDto> attachments, String fileNamePrefix,
                                                  BigDecimal fileNumber, String extensionCounter, BigDecimal irTranId,
                                                  NfsFileTypeDto nfsFileType)
        throws MTSServiceFault {

        List<NfsFilenameDto> nfsFilenameList = new ArrayList<>();
        String systemDate = getSystemDate();
        int otherAttachmentSequence = 1;

        // Transaction XML file.
        NfsFilenameDto transactionXMLFileDto = getTransactionXMLfileNameDto(fileNamePrefix, fileNumber,
            extensionCounter, irTranId, systemDate, otherAttachmentSequence);
        nfsFilenameList.add(transactionXMLFileDto);

        boolean courtesyLetterOnly = false;
        // Attachment Filenames
        for (IntlAtchmtDto intlAtchmtDto : attachments) {
            StringBuilder nfsFileName = new StringBuilder();
            String fileformat = intlAtchmtDto.getFileFrmtCtgry();

            NfsFileType fileType = null;
            if (IntlAtchmtTypeCode.TRANSACTION_REPRESENTATION.codeValue()
                .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {

                fileType = NfsFileType.TRANSACTION_REPRESENTATION;

                nfsFileName.append(fileNamePrefix).append(MtsStringUtil.UNDER_SCORE).append(systemDate)
                    .append(MtsStringUtil.DOT).append(fileformat);

            } else if (IntlAtchmtTypeCode.TRANSACTION_REPRESENTATION_IMAGES.codeValue()
                .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {

                if (NfsFileTypeDto.STANDARD_CHARACTERS_ONLY.name().equals(nfsFileType.name())) {
                    fileType = NfsFileType.OTHER_ATTACHMENT;
                } else {
                    fileType = NfsFileType.PRIMARY_DESIGN;
                }
                nfsFileName.append(fileNamePrefix).append(MtsStringUtil.UNDER_SCORE).append(systemDate)
                    .append(MtsStringUtil.UNDER_SCORE).append("design").append(MtsStringUtil.DOT).append(fileformat);

            } else if (IntlAtchmtTypeCode.IB_TO_OFFICE_REPRESENTATION_ORIG.codeValue()
                .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {

                fileType = NfsFileType.OTHER_ATTACHMENT;

                nfsFileName.append(fileNamePrefix).append(MtsStringUtil.UNDER_SCORE).append(systemDate)
                    .append("_attach_").append(irTranId.toString()).append(MtsStringUtil.DOT).append(fileformat);

            } else if (IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS.codeValue()
                .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {

                fileType = NfsFileType.OUTBOUND;

                nfsFileName.append(fileNamePrefix).append(MtsStringUtil.UNDER_SCORE).append(systemDate)
                    .append("_attach_").append(irTranId.toString()).append(MtsStringUtil.DOT).append(fileformat);

            } else if (IntlAtchmtTypeCode.COURTESY_LETTER_PDF.codeValue()
                .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {

                fileType = NfsFileType.OUTBOUND;
                nfsFileName.append(intlAtchmtDto.getFileName());
                courtesyLetterOnly = true;
            } else {
                logger.debug("Ignoring attachment type: " + intlAtchmtDto.getAtchmtCtgryId());
                continue;
            }

            if (courtesyLetterOnly) {
                nfsFilenameList.clear();
                nfsFilenameList.add(internationalDTOFactory.createNfsFilenameDto(nfsFileName.toString(), fileNumber,
                    extensionCounter, fileType, intlAtchmtDto.getAtchmtId(), null));
            } else {
                nfsFilenameList.add(internationalDTOFactory.createNfsFilenameDto(nfsFileName.toString(), fileNumber,
                    extensionCounter, fileType, intlAtchmtDto.getAtchmtId(), null));
            }
        }
        return nfsFilenameList;
    }

    /**
     * Return Transaction XML file Name
     *
     */
    private NfsFilenameDto getTransactionXMLfileNameDto(String fileNamePrefix, BigDecimal fileNumber,
                                                        String extensionCounter, BigDecimal irTranId, String systemDate,
                                                        int otherAttachmentSequence) {
        StringBuilder nfsFileName = new StringBuilder();
        if (irTranId != null) {
            nfsFileName.append(fileNamePrefix).append(MtsStringUtil.UNDER_SCORE).append(systemDate).append("_attach_")
                .append(irTranId.toString()).append(XML_EXTENTION);
            NfsFilenameDto nfsFilenameDto = internationalDTOFactory.createNfsFilenameDto(nfsFileName.toString(),
                fileNumber, extensionCounter, NfsFileType.OTHER_ATTACHMENT, null, irTranId);
            return nfsFilenameDto;
        }
        return null;
    }

    protected void createMail(Application application, IntlIrTranDto intlIrTran, int processType)
        throws MTSServiceFault {

        BigDecimal categoryId = intlIrTran.getIntlPkgTranType() != null
            ? intlIrTran.getIntlPkgTranType().getPkgTranCtgryId() : null;

        TransactionCategory transactionCategory = TransactionCategory.getTransactionCategoryByValue(categoryId);

        logger.debug("Call processMail from transactionCategory " + transactionCategory);
        processMail(transactionCategory, application, intlIrTran, processType);

    }

    protected Mail createMailModel(TransactionCategory transactionCategory, Application application,
                                   IntlIrTranDto intlIrTran, int processType, Calendar calendar) {

        Mail mail = createMailCommonAttributes(application, intlIrTran, processType, transactionCategory, calendar);

        setMailTypeByCategory(transactionCategory, mail);

        return mail;
    }

    protected void createMail(MadridDesignationType madridDesignation, Application application,
                              IntlIrTranDto intlIrTran, int processType)
        throws MTSServiceFault {

        TransactionCategory transactionCategory = (madridDesignation
            .getMadridDesignationCategory() == MadridDesignationCategoryType.REGISTRATION
                ? TransactionCategory.MD_REGISTRATION : TransactionCategory.MD_SUBSEQUENT_DESIGNATION);

        logger.debug("Call processMail from MadridDesignationType " + transactionCategory);
        processMail(transactionCategory, application, intlIrTran, processType);

    }

    private Mail createMailCommonAttributes(Application application, IntlIrTranDto intlIrTran, int processType,
                                            Object transactionCategory, Calendar calendar) {
        Mail mail = new Mail();

        mail.setAuthorityId(SectionAuthority.FORMALITIES.name());
        mail.setFileNumber(application.getFileNumber());
        mail.setFileType(FileType.TRADE_MARK.getValue());

        mail.setMailAttachedInd(processType); // processing type 'Auto' or manual

        String from = null;
        if (transactionCategory instanceof TransactionCategory) {
            from = " for " + transactionCategory;
            mail.setMailTimestamp(getIncrementedTime(true, calendar));
        } else {
            from = " for Madrid Designation";
            mail.setMailTimestamp(getIncrementedTime(true, calendar));
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

        logger.debug("create mail record with file number: " + application.getFileNumber() + from);
        logger.debug("create mail record with file type: " + mail.getFileType() + from);
        logger.debug("create mail record with attached id: " + mail.getMailAttachedInd() + from);
        String mailTimeStampe = sdf.format(mail.getMailTimestamp());
        logger.debug("create mail record with timestamp: " + mailTimeStampe + from);

        mail.setMailMode(MailModeType.ELECTRONIC.getValue());
        mail.setProcessedByAuthorityID(SectionAuthority.MADRID.name());
        mail.setProcessedDate(new Date());

        Timestamp stamp = intlIrTran.getIntlPkg().getCreatedTmstmp();
        Date createDate = new Date(stamp.getTime());
        mail.setMailRoomDate(createDate);

        return mail;
    }

    private Date getIncrementedTime(boolean addExtraSecond, Calendar calendar) {
        if (addExtraSecond) {
            calendar.add(Calendar.SECOND, 1);
        }

        return calendar.getTime();
    }

    private void setMailTypeByCategory(TransactionCategory transactionCategory, Mail mail) {
        Integer typeId = 0;

        MailType type = MailTypeTransactionCategory.transactionMailTypeMap.get(transactionCategory);
        logger.debug("Mail type: " + type);
        if (type != null) {
            typeId = type.getValue();
            mail.setMailType(typeId);
        }
    }

    protected String getFormattedSystemDate() {
        Calendar calendar = Calendar.getInstance();
        StringBuilder systemDate = new StringBuilder();
        systemDate.append(calendar.get(Calendar.YEAR)).append(MtsStringUtil.DASH)
            .append(String.format("%02d", calendar.get(Calendar.MONTH) + 1)).append(MtsStringUtil.DASH);
        systemDate.append(String.format("%02d", calendar.get(Calendar.DAY_OF_MONTH)));

        return systemDate.toString();
    }

    protected String getSystemDate() {
        Calendar calendar = Calendar.getInstance();
        StringBuilder systemDate = new StringBuilder();
        systemDate.append(calendar.get(Calendar.YEAR)).append(String.format("%02d", calendar.get(Calendar.MONTH) + 1));
        systemDate.append(String.format("%02d", calendar.get(Calendar.DAY_OF_MONTH)));

        return systemDate.toString();
    }

    protected String getSystemDateInMilliSec() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

        String systemDateString = sdf.format(new Date());

        return systemDateString;
    }

    protected String getSystemDateInSec() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

        String systemDateString = sdf.format(new Date());

        return systemDateString;
    }

    protected Integer getLastGoodsSequence(Application application) throws MTSServiceFault {
        Set<GoodService> goodsServicesSet = application.getGoodsServices();
        if (null != goodsServicesSet) {
            Iterator<GoodService> iterator = goodsServicesSet.iterator();
            while (iterator.hasNext()) {
                GoodService gs = iterator.next();

                if (this.goodsOrService(gs.getNiceClassCode().toString()) == GoodServiceType.GOODS) {

                }
            }
        }

        return 0;
    }

    protected String getCountryCode(MadridDesignationType madridDesignation) {
        String countryCode = null;

        // check tmk:OfficeOriginCode in the Country of Origin of Trademark
        if (null != madridDesignation.getOfficeOriginCode()) {
            // check if the country code is valid / existed
            CountryProvince code = countryProvinceLookupDao.getCountry(madridDesignation.getOfficeOriginCode(),
                LanguageType.ENGLISH.getValue());

            if (code != null) {
                countryCode = madridDesignation.getOfficeOriginCode();
            } else {
                countryCode = getCountryCodefromHolder(madridDesignation);
            }
        }

        return countryCode;
    }

    protected String getCountryCodefromHolder(MadridDesignationType madridDesignation) {
        String countryCode = null;

        List<ApplicantType> holderList = madridDesignation.getHolderBag().getHolder();

        for (ApplicantType holder : holderList) {
            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    break;
                }
            }
            if (null == contact) {
                logger.error("Holder does not contain a contact");
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                logger.error("Contact does not have a NameType.");
                continue;
            }

            if (null != contact.getPostalAddressBag()) {
                List<PostalAddressType> postalAddress = contact.getPostalAddressBag().getPostalAddress();
                for (PostalAddressType address : postalAddress) {
                    countryCode = address.getPostalStructuredAddress().getCountryCode();
                }
            }
            break; // first holder
        }
        return countryCode;
    }

    protected void createMadridApplicationAction(MadridApplication madridApplication, Object objType) {
        createMadridApplicationAction(madridApplication, objType, null);
    }

    protected void createMadridApplicationAction(MadridApplication madridApplication, Object objType,
                                                 IntlIrTranDto intlIrTran) {
        // create new Action for Madrid Application
        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setWipoReferenceNumber(madridApplication.getWipoReferenceNumber());
        madridApplicationAction.setAuthorityId(SectionAuthority.MADRID.name());

        String madridDate = null;
        if (objType instanceof MadridDesignationTerminationType) {
            madridDate = ((MadridDesignationTerminationType) objType).getExpiryDate();
            madridApplicationAction.setAdditionalInfo("DP:" + getFormattedSystemDate());
            madridApplicationAction.setActionCode(MadridApplicationActionStatus.CLOSED.getValue());

        } else if (objType instanceof MadridInternationalRegistrationCreationType) {
            madridDate = ((MadridInternationalRegistrationCreationType) objType).getRecordEffectiveDate();
            madridApplicationAction.setActionCode(MadridApplicationActionStatus.IR_REGISTERED.getValue());
        }

        try {
            if (madridDate != null) {
                madridApplicationAction.setActionDate(DateFormats.getISOSDF().parse(madridDate));
            }
        } catch (ParseException e) {
            logger.error("Error setting action date when processing " + objType + " for WipoReferenceNumber: "
                + madridApplication.getWipoReferenceNumber() + " in createMadridApplicationAction");
        }
        if (intlIrTran != null) {
            madridApplicationAction.setIrTranId(intlIrTran.getIrTranId().longValue());
        }
        // need to generate id before save
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationAction.setMadridApplicationActionsSeqNumber(madridApplicationActionId);

        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);
    }

    protected void saveMadridApplicationAction(MadridApplication madridApplication, String authorityId,
                                               String additionalInfo) {
        // create new Action for Madrid Application
        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setWipoReferenceNumber(madridApplication.getWipoReferenceNumber());
        madridApplicationAction.setAuthorityId(authorityId);

        madridApplicationAction.setActionDate(new Date());
        madridApplicationAction.setAdditionalInfo(additionalInfo);

        // need to generate id before save
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationAction.setMadridApplicationActionsSeqNumber(madridApplicationActionId);

        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);

    }

    protected boolean validateMadridMarkForAbandonment(BigDecimal irTranId) throws Exception {
        boolean markValidated = false;

        MadridAbandonmentNotificationType madridAbandonmentNotification = marshallingService
            .unmarshallTransaction(irTranId);
        IdentifierType officeReferenceIdentifier = madridAbandonmentNotification.getOfficeReferenceIdentifier();
        String wipoReferenceNumber = officeReferenceIdentifier.getValue();

        MadridApplication madridApplication = madridApplicationDao
            .getMadridApplicationByReferenceNumber(wipoReferenceNumber);

        if (madridApplication != null) {
            markValidated = true;
        }

        return markValidated;
    }

    protected Calendar getLatestMailTimestamp(Application application) {
        Calendar calendar = Calendar.getInstance();

        List<Mail> mails = mailDao.getMailByFileId(application.getFileNumber());

        if (CollectionUtils.isNotEmpty(mails)) {
            Set<Date> dates = new HashSet<Date>();

            for (Mail mail : mails) {
                dates.add(mail.getMailTimestamp());
            }
            // reset the calendar
            calendar.setTime(Collections.max(dates));
        }
        logger.debug("The latest mailDate: " + calendar.getTime());
        return calendar;
    }

    /**
     * Create additional info object
     *
     * @param taskId the task id of the task you want to add the additional info to
     * @param addtnlInfo the addtnl info string that you want to add
     * @param intlTaskAddtnlInfoType the intl task addtnl info type. Get this Entity prior to calling this.
     * @return the intl task addtnl info
     */
    protected IntlTaskAddtnlInfo createAdditonalInfoObject(BigDecimal taskId, String addtnlInfo,
                                                           IntlTaskAddtnlInfoType intlTaskAddtnlInfoType) {

        Timestamp timestamp = new Timestamp(new Date().getTime());

        IntlTaskAddtnlInfo intlTaskAddtnlInfo = new IntlTaskAddtnlInfo();
        intlTaskAddtnlInfo.setAddtnlInfo(addtnlInfo);
        intlTaskAddtnlInfo.setCreatedTmstmp(timestamp);
        intlTaskAddtnlInfo.setTaskId(taskId);
        intlTaskAddtnlInfo.setTaskAddtnlInfoCtgry(intlTaskAddtnlInfoType);

        return intlTaskAddtnlInfo;
    }

    protected String getMessageText(String messageKey, LanguageType applicationLanguage) {
        String message = null;
        if (applicationLanguage == LanguageType.ENGLISH) {
            message = messageSource.getMessage(messageKey, null, Locale.ENGLISH);
        } else {
            message = messageSource.getMessage(messageKey, null, Locale.FRANCE);
        }

        logger.debug("Message from message.properties: " + message);
        return message;
    }

    protected void processMail(TransactionCategory transactionCategory, Application application,
                               IntlIrTranDto intlIrTran, int processType)
        throws MTSServiceFault {

        boolean mailCreated = false;

        String fileNamePrefixKey = null;
        if (NfsFileName.transactionFilenameMap.containsKey(transactionCategory)) {
            fileNamePrefixKey = NfsFileName.transactionFilenameMap.get(transactionCategory);
        } else {
            throwMTSServiceFault("mts.nfs.filename.map.transaction.missing", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        try {
            Calendar calendar = getLatestMailTimestamp(application);

            List<IntlAtchmtDto> attachmentList = intlIrTran.getIntlAtchmtDtoList();
            if (CollectionUtils.isNotEmpty(attachmentList)) {

                boolean markIsStandardCharacters = (application.getTradeMarkType()
                    .intValue() == TradeMarkType.STANDARD_CHARACTERS.getValue());

                List<NfsFilenameDto> nfsFilenameList = new ArrayList<NfsFilenameDto>();
                if (markIsStandardCharacters) {
                    nfsFilenameList.addAll(setNFSFilename(attachmentList, fileNamePrefixKey,
                        BigDecimal.valueOf(application.getFileNumber()), application.getExtensionCounter().toString(),
                        intlIrTran.getIrTranId(), NfsFileTypeDto.STANDARD_CHARACTERS_ONLY));

                } else {
                    nfsFilenameList.addAll(setNFSFilename(attachmentList, fileNamePrefixKey,
                        BigDecimal.valueOf(application.getFileNumber()), application.getExtensionCounter().toString(),
                        intlIrTran.getIrTranId(), NfsFileTypeDto.OTHERS));
                }

                for (NfsFilenameDto nfsFilenameDto : nfsFilenameList) {
                    if (nfsFilenameDto.getFileType() == NfsFileType.TRANSACTION_REPRESENTATION) { // pdf file

                        logger.debug("Create Mail record for PDF attachment.");
                        mailCreated = createMailRecord(transactionCategory, application, intlIrTran, processType,
                            calendar, nfsFilenameDto);

                        break;
                    }
                }
            }
            logger.debug("mailCreated: " + mailCreated);

            if (!mailCreated) {
                String systemDate = getSystemDate();
                int otherAttachmentSequence = 1;

                // Transaction XML file.
                NfsFilenameDto transactionXMLFileDto = getTransactionXMLfileNameDto(fileNamePrefixKey,
                    BigDecimal.valueOf(application.getFileNumber()), application.getExtensionCounter().toString(),
                    intlIrTran.getIrTranId(), systemDate, otherAttachmentSequence);

                if (transactionXMLFileDto != null) {
                    logger.debug("Create Mail record for XML file without attachment.");
                    createMailRecord(transactionCategory, application, intlIrTran, processType, calendar,
                        transactionXMLFileDto);
                }
            }

        } catch (Exception e) {
            logger.error("Error creating MAIL for madridDesignation:", e);
            throwMTSServiceFault("mts.processing.designation", ExceptionReasonCode.DESIGNATION_ERROR);
        }
    }

    private boolean createMailRecord(TransactionCategory transactionCategory, Application application,
                                     IntlIrTranDto intlIrTran, int processType, Calendar calendar,
                                     NfsFilenameDto nfsFilenameDto) {

        Mail mail = createMailModel(transactionCategory, application, intlIrTran, processType, calendar);

        logger.debug("file name: " + nfsFilenameDto.getFileName());
        mail.setAttachmentFileName(nfsFilenameDto.getFileName());

        logger.debug("mailDate after createMailmodel: " + mail.getMailTimestamp());

        mailDao.saveMail(mail);

        return true;
    }

    protected Set<String> checkDuplicateElements(Set<FigurativeElement> figurativeElements) {
        Set<String> duplcateMsg = new HashSet<String>();

        int n = figurativeElements.size();
        FigurativeElement arr[] = new FigurativeElement[n];
        arr = figurativeElements.toArray(arr);

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i].getCategoryCode() == arr[j].getCategoryCode()
                    && arr[i].getDivisionCode() == arr[j].getDivisionCode()
                    && arr[i].getSectionCode() == arr[j].getSectionCode()) {

                    String message = "category code: " + arr[i].getCategoryCode() + "; devision code: "
                        + arr[i].getDivisionCode() + "; section code: " + arr[i].getSectionCode();
                    duplcateMsg.add(message);

                    // break;
                }
            }
        }
        return duplcateMsg;
    }

    protected void checkAddressSize(RepresentativeAddressDto address, Application application,
                                    Map<ApplicationDto, UserTaskType> notificationTypes,
                                    RepresentativeType representative)
        throws MTSServiceFault {

        // RepresentativeType representative, RepresentativeAddressDto address
        boolean wordOverLimit = isWordLengthExceedLimitLines(representative, address);

        String addressString = getCompleteAddress(address);
        String[] lines = addressString.split(NEW_LINE);

        ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);// ????
        applicationDto.setCourtesyLetterRequired(true);
        applicationDto.setAddress(addressString);
        applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
        if ((lines.length > ValidateWipoTransactionUtil.LINE_LIMIT) || wordOverLimit) {
            if (wordOverLimit) {
                logger.debug("number of characters per worrd exceeds limits ("
                    + ValidateWipoTransactionUtil.MAX_LINE_LENGTH + ")");
            } else {
                logger.debug("lines of address (" + lines.length + ") exceeds limits ("
                    + ValidateWipoTransactionUtil.LINE_LIMIT + ")");
            }

            // Manual task to adjust address required
            notificationTypes.put(applicationDto, UserTaskType.UPDATE_ADDRESS_CREATE_COURTESYLATTER);
        } else {
            // Create courtesy letter - size within limits
            logger.debug("lines of address (" + lines.length + ") within limits ("
                + ValidateWipoTransactionUtil.LINE_LIMIT + ")");

            notificationTypes.put(applicationDto, UserTaskType.REPRESENTATIVE_COURTESY_LETTER);
        }
    }

    private String getCompleteAddress(RepresentativeAddressDto address) throws MTSServiceFault {

        ValidateWipoTransactionUtil validateWipoTransactionUtil = ValidateWipoTransactionUtil.getInstance();

        StringBuilder completeAddress = new StringBuilder();

        try {
            // name
            completeAddress.append(validateWipoTransactionUtil.splitString(address.getRepresentativeName(),
                ValidateWipoTransactionUtil.MAX_LINE_LENGTH));
            // address
            Iterator<String> it = address.getRepresentativeAddress().iterator();
            if (it.hasNext()) {
                completeAddress.append(
                    validateWipoTransactionUtil.splitString(it.next(), ValidateWipoTransactionUtil.MAX_LINE_LENGTH));
                while (it.hasNext()) {
                    completeAddress.append(validateWipoTransactionUtil.splitString(it.next(),
                        ValidateWipoTransactionUtil.MAX_LINE_LENGTH));
                }
            }

            // country, province
            CountryProvince countryProvince = countryProvinceLookupDao.getCountry(address.getCountryProvince(),
                LanguageType.ENGLISH.getValue());

            completeAddress.append(validateWipoTransactionUtil.splitString(countryProvince.getDescription(),
                ValidateWipoTransactionUtil.MAX_LINE_LENGTH));
            // postal code
            completeAddress.append((address.getZipPostalCode() != null ? address.getZipPostalCode() : ""));

            logger.debug("Complete address: " + NEW_LINE + completeAddress.toString());

        } catch (Exception e) {
            logger.error("Country not found: " + address.getCountryProvince() + " - " + e.getMessage());
            throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
        return completeAddress.toString();
    }

    protected boolean checkCountryCanada(String country, LanguageType languageType) throws MTSServiceFault {
        logger.debug("Country: " + country);

        try {
            CountryProvince countryProvince = countryProvinceLookupDao.getCountry(country, languageType.getValue());
            if (countryProvince != null && countryProvince.getCode().equalsIgnoreCase(COUNTRYCODE_CANADA)) {
                return true;
            }
        } catch (Exception e) {
            logger.error("Country not found: " + country + " - " + e.getMessage());
            throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
        return false;
    }

    private boolean isWordLengthExceedLimitLines(RepresentativeType representative, RepresentativeAddressDto address) {

        StringBuilder sb = new StringBuilder().append(address.getRepresentativeName().trim());
        if (address.getCountryProvince() != null) {
            sb.append(WHITE_SPACE).append(address.getCountryProvince());
        }

        if (address.getCityName() != null) {
            sb.append(WHITE_SPACE).append(address.getCountryProvince());
        }

        for (String pas : address.getRepresentativeAddress()) {
            sb.append(WHITE_SPACE).append(pas.trim());
        }

        String[] words = StringUtils.split(sb.toString(), WHITE_SPACE);
        for (String aWord : words) {
            if (aWord.length() > ValidateWipoTransactionUtil.MAX_LINE_LENGTH) {
                return true;
            }
        }

        return false;
    }

    /**
     * To create console task when address size exceeds limits; to create a courtesy letter
     *
     * @param intlIrTransaction
     * @param notifications
     * @param transactionCategory
     * @throws MTSServiceFault
     */
    public boolean isRequiredCreateCourtesyLetter(IntlIrTranDto intlIrTransaction,
                                                  Map<ApplicationDto, UserTaskType> notifications)
        throws MTSServiceFault {

        if ((notifications == null) || notifications.isEmpty()) {
            return false;
        }
        for (Map.Entry<ApplicationDto, UserTaskType> entry : notifications.entrySet()) {
            logger.debug("ApplicationDto: " + entry.getKey().isCourtesyLetterRequired() + "UserTaskType: "
                + entry.getValue().name());
            if (entry.getKey().isCourtesyLetterRequired()
                && entry.getValue() == UserTaskType.REPRESENTATIVE_COURTESY_LETTER) {
                return true;
            }
        }
        return false;

    }

    protected void monitorRGSReportCompletion(int pollingAttempts, MadridReportResponse madridReportResponse,
                                              String reportServiceHost)
        throws ca.gc.ic.cipo.tm.mts.CIPOServiceFault {

        int MAX_POLL_ATTEMPTS = pollingAttempts;
        int pollTrys = 0;
        boolean completed = false;

        try {
            for (pollTrys = 0; pollTrys < MAX_POLL_ATTEMPTS; pollTrys++) {
                Thread.sleep(1000);
                // Poll for completion
                RuntimeJobState reportJobState = pollReportService(madridReportResponse.getJobId(), reportServiceHost);
                if (reportJobState == RuntimeJobState.COMPLETE) {
                    logger.debug("Poll attempts before report completed: " + pollTrys);
                    completed = true;
                    break;
                }
            }
            if (!completed) {
                logger.error("RGS report did not complete in configured poll attempts");
                throwMTSServiceFault("mts.poll.rgs.report.error", ExceptionReasonCode.RETRYABLE_ERROR);

            }
        } catch (Exception exception) {
            logger.error("Error in monitorRGSReportCompletion", exception);
            throwCIPOFault(exception);
        }
    }

    /**
     * Wraps the web service operation in RGS that polls for the completion of a given report job.
     *
     * @param reportJobId the ID of the report job to check
     * @return The complex object containing the job status
     * @throws CIPOServiceFault
     * @throws ca.gc.ic.cipo.tm.mts.CIPOServiceFault
     */
    protected RuntimeJobState pollReportService(String reportJobId, String reportServiceHost)
        throws ca.gc.ic.cipo.tm.mts.CIPOServiceFault {
        RuntimeJobState rgsJobState = null;
        ReportGenerationWsClient rgsClient = new ReportGenerationWsClient(reportServiceHost);
        try {
            logger.debug("--> Calling WSO : getJobStatus for reportJobId " + reportJobId);
            rgsJobState = rgsClient.getJobStatus(reportJobId);
            logger.debug("-->         WSO : getJobStatus - returned with status " + rgsJobState);

            if (rgsJobState == null) {
                logger.error("Error polling RGS report. Null state returned. Report id:" + reportJobId);
                throwMTSServiceFault("mts.poll.rgs.report.error", ExceptionReasonCode.RETRYABLE_ERROR);
            } else {
                switch (rgsJobState) {
                    case COMPLETE:
                        break;
                    case WAITING:
                    case EXECUTING:
                    case INITIALIZING:
                        break;
                    case ERROR:
                        logger.error("RGS returned the state: [" + rgsJobState.name() + "] for reportJobId ["
                            + reportJobId + "]");
                        throwMTSServiceFault("mts.poll.rgs.report.error", ExceptionReasonCode.RETRYABLE_ERROR);
                        break;
                    default:
                        logger.error("RGS returned the state: [" + rgsJobState.name() + "] for reportJobId ["
                            + reportJobId + "]");
                        throwMTSServiceFault("mts.poll.rgs.report.error", ExceptionReasonCode.RETRYABLE_ERROR);

                }
            }

        } catch (Exception exception) {
            logger.error("Error polling RGS report with report id:" + reportJobId, exception);
            throwCIPOFault(exception);
        }
        return rgsJobState;
    }

    public String getFileNamePrefix(TransactionCategory transactionCategory) throws MTSServiceFault {
        String fileNamePrefixKey = null;

        if (NfsFileName.transactionFilenameMap.containsKey(transactionCategory)) {
            fileNamePrefixKey = NfsFileName.transactionFilenameMap.get(transactionCategory);
        } else {
            throwMTSServiceFault("mts.nfs.filename.map.transaction.missing", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        return fileNamePrefixKey;
    }

    /**
     *
     * To send file to Intrepid server
     *
     * @param intlIrTran
     * @param notifications
     * @param transactionCategory
     * @param courtesyLetterOnly
     * @throws MTSServiceFault
     */
    // TODO will merge this method with sendAttachmentsToIntrepidNfs
    public void sendCourtesyLetterAttachmentToIntrepidNfs(IntlIrTranDto intlIrTran,
                                                          Map<ApplicationDto, UserTaskType> notifications,
                                                          TransactionCategory transactionCategory,
                                                          boolean courtesyLetterOnly)
        throws MTSServiceFault {

        // Store designs and/or electronic representations in the folder
        // structure
        Set<ApplicationDto> applicationDto = notifications.keySet();

        Iterator<ApplicationDto> iterator = applicationDto.iterator();
        while (iterator.hasNext()) {
            ApplicationDto intrepidApplication = iterator.next();

            if (null != intrepidApplication.getFileNumber()) {
                ApplicationDto application = intrepidCommonService
                    .getApplication(Integer.valueOf(intrepidApplication.getFileNumber()));

                // If the Trade_Mark_Type is being set to Standard Character
                // (previous item) and ViennaCategory and
                // ViennaDivision of 28 and 11 respectively existed, do not load
                // the Design/Image file for this mark
                if (application != null) {
                    boolean markIsStandardCharacters = (application.getTradeMarkType()
                        .intValue() == TradeMarkType.STANDARD_CHARACTERS.getValue());

                    if (markIsStandardCharacters) {
                        internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                            BigDecimal.valueOf(intrepidApplication.getFileNumber()),
                            intrepidApplication.getExtensionCounter(), NfsFileTypeDto.STANDARD_CHARACTERS_ONLY);
                    } else {
                        internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                            BigDecimal.valueOf(intrepidApplication.getFileNumber()),
                            intrepidApplication.getExtensionCounter(), NfsFileTypeDto.OTHERS);
                    }
                }
            }

            break; // All items in collection refer to the same application
        }
    }

    // TODO: merge this method with
    // validateWipoTransactionUtil.getMailingAddressTotalLines(holderList);
    protected boolean getAddressTotalLines(List<RepresentativeType> addressList) {

        int idx = 0;
        int contactLineCount = 0;
        ContactType firstContact = null;

        for (RepresentativeType holder : addressList) {

            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    if (idx == 0) {
                        firstContact = contact;
                    }
                    break;
                }
            }
            if (null == contact) {
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                continue;
            }
            contactLineCount += contact.getName().getPersonNameOrOrganizationNameOrEntityName().size();
        }

        int countryProvPostalCount = 0, addressLineCount = 0;

        countryProvPostalCount = firstContact.getPostalAddressBag().getPostalAddress().size();

        // Postal Code, Country Code
        if (null != firstContact.getPostalAddressBag()) {
            List<PostalAddressType> postalAddress = firstContact.getPostalAddressBag().getPostalAddress();
            for (PostalAddressType address : postalAddress) {
                if (address.getPostalStructuredAddress().getAddressLineText()
                    .size() > ValidateWipoTransactionUtil.MAX_LINE_LENGTH) {
                    return true;
                }
                addressLineCount += address.getPostalStructuredAddress().getAddressLineText().size();

                if (StringUtils.isNotBlank(address.getPostalStructuredAddress().getCountryCode())
                    || StringUtils.isNotBlank(address.getPostalStructuredAddress().getPostalCode())) {
                    // Put country / postal on its own line.
                    addressLineCount += 1;
                }

                // break; // first address
            }
        }

        int totalAddressLines = contactLineCount + countryProvPostalCount + addressLineCount;

        return (totalAddressLines > ValidateWipoTransactionUtil.LINE_LIMIT);
    }

    /************************************ CorrespondenceAddress *********************************************/
    /**
     * To compare two addresses
     *
     * @param contact
     * @param transType
     * @return boolean true is the same between Main address and CorrespondenceAddress; otherwise is different
     * @throws MTSServiceFault
     */
    protected boolean compareCorrespondenceAndMainAddress(Object transType) throws MTSServiceFault {

        logger.debug("Compare addresses between CorrespondenceAddress and Holder/Main address");

        List<Serializable> caList = new ArrayList<Serializable>();
        CorrespondenceAddressType csType = getCorrsponseTypeAddressByType(transType);
        if (csType != null) {
            caList = csType.getPartyIdentifierOrContact();
            logger.debug("CorrespondenceAddress List " + caList.size());
        }

        List<ApplicantType> holderList = getHolderListByType(transType);
        logger.debug("HolderList " + holderList.size());

        return compareResult(caList, holderList);
    }

    /**
     * To set interestedParty properties
     *
     * @param application
     * @param ipNumber
     * @param fileRef
     * @return
     */
    protected InterestedParty createMDInterestedParty(Application application, int ipNumber, String fileRef) {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(application.getFileNumber());
        interestedParty.setIpNumber(ipNumber);
        interestedParty.setApplication(application);

        interestedParty.setExtensionCounter(application.getExtensionCounter());
        interestedParty.setRelationshipType(RelationshipType.OWNER.getValue());
        interestedParty.setApplicantInd(1);
        interestedParty.setRegistrantInd(0);
        interestedParty.setPrimaryIndicator(1);
        interestedParty.setReference(fileRef);

        return interestedParty;
    }

    /******************************
     * HELPERS FOR CORRESPONDENCE ADDRESS
     **********************************/
    private boolean compareResult(List<Serializable> csList, List<ApplicantType> holderList) throws MTSServiceFault {

        if (CollectionUtils.isEmpty(csList) || CollectionUtils.isEmpty(holderList)) {
            logger.debug("A list is null or empty!");
            return true;
        }

        String csAddress = null;
        String holdAddress = null;
        if (CollectionUtils.isNotEmpty(csList)) {
            csAddress = getCorrespondenceAddress(csList);
        }
        if (CollectionUtils.isNotEmpty(holderList)) {
            holdAddress = getHolderAddress(holderList);
        }

        if (StringUtils.isNotEmpty(csAddress) && StringUtils.isNotEmpty(holdAddress)) {
            if (csAddress.equalsIgnoreCase(holdAddress)) {
                logger.debug("Addresses between CorrespondenceAddressType and HolderBagType is the same!");
                return true;
            } else {
                logger.debug("Addresses between CorrespondenceAddressType and HolderBagType is the different!");
                return false;
            }
        } else {
            return true; // should not happen
        }
    }

    private String getCorrespondenceAddress(List<Serializable> cslist) throws MTSServiceFault {
        ContactType contact = null;
        for (Object aType : cslist) {
            if (aType instanceof ContactType) {
                contact = (ContactType) aType;
                break;
            }
        }
        if (contact != null) {
            logger.debug("Contact in CorrespondenceAddress: " + contact.getName());

            return processingAddress(contact);

        } else {
            logger.error("CorrespondenceAddress does not contain a contact");
        }

        return null;
    }

    private String getHolderAddress(List<ApplicantType> list) throws MTSServiceFault {
        String address = null;
        for (ApplicantType holder : list) {
            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    break;
                }
            }
            if (null == contact) {
                logger.error("Holder does not contain a contact");
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                logger.error("Contact does not have a NameType.");
                continue;
            }
            logger.debug("Contact in Holder: " + contact.getName());

            address = processingAddress(contact);

            break; // first holder
        }
        return address;
    }

    private String processingAddress(ContactType contact) throws MTSServiceFault {

        if (contact == null) {
            logger.error("No contact!");
            return null;
        }
        StringBuffer addressAndName = new StringBuffer();
        if (contact != null) {
            PostalAddressBagType postBag = contact.getPostalAddressBag();
            List<PostalAddressType> postAddress = postBag.getPostalAddress();
            for (PostalAddressType ps : postAddress) {
                addressAndName.append(setAddress(ps, contact.getLanguageCode()));
                break;
            }
        }
        logger.debug("Address String is: " + addressAndName.toString());
        return addressAndName.toString();
    }

    private String setAddress(PostalAddressType address, String languageCode) throws MTSServiceFault {

        StringBuilder addressText = new StringBuilder();

        for (AddressLineTextType addressLineText : address.getPostalStructuredAddress().getAddressLineText()) {
            addressText.append(addressLineText.getValue()).append("\r\n");
        }
        logger.debug("addressText: " + addressText);

        if (null != address.getPostalStructuredAddress()) {
            String countryCode = null;
            // check country
            if (null != address.getPostalStructuredAddress().getCountryCode()) {
                CountryProvince countryProvince = countryProvinceLookupDao
                    .getCountry(address.getPostalStructuredAddress().getCountryCode(), LanguageType.ENGLISH.getValue());

                if (null != countryProvince) {
                    countryCode = countryProvince.getDescription();
                    addressText.append(countryCode).append(" ");
                } else {
                    logger.error("Cannot find country for: " + address.getPostalStructuredAddress().getCountryCode());
                }
                logger.debug("Country Code: " + countryCode);
            }
            // check city
            if (StringUtils.isNotBlank(address.getPostalStructuredAddress().getCityName())) {
                addressText.append(address.getPostalStructuredAddress().getCityName());

                logger.debug("City: " + address.getPostalStructuredAddress().getCityName());
            }
            // concatenate postal code in main address only for foreign
            // countries
            if (StringUtils.isNotBlank(address.getPostalStructuredAddress().getPostalCode())
                && !countryCode.equalsIgnoreCase(COUNTRY_CODE_CANADA)) {
                addressText.append(address.getPostalStructuredAddress().getPostalCode());

                logger.debug("Post code: " + address.getPostalStructuredAddress().getPostalCode());
            }
        }
        logger.debug("completed addressText: " + addressText);
        return addressText.toString();
    }

    private void setIPAndMailingAddressesByOption(Application application, InterestedParty interestedParty,
                                                  ContactType mainContact, ContactType caContact,
                                                  boolean isDifferentAddress,
                                                  Set<InterestedPartiesAddresses> interestedPartiesAddresses)
        throws MTSServiceFault {

        logger.debug("isDifferentAddress " + isDifferentAddress);
        InterestedPartiesAddresses ipMailingAddress = null;
        InterestedPartiesAddresses caIPAddresses = null;

        // always add main address from holder
        InterestedPartiesAddresses ipAddress = createInterestedPartyAddress(application, mainContact, interestedParty,
            AddressType.PRIMARY);

        if (null != ipAddress) {
            interestedPartiesAddresses.add(ipAddress);
        }

        if (isDifferentAddress && caContact != null) {
            // add CorrespondenceAddress
            caIPAddresses = createInterestedPartyAddress(application, caContact, interestedParty,
                AddressType.CORRESPONDENCE);

            if (caIPAddresses != null) {
                interestedPartiesAddresses.add(caIPAddresses);

                // add mailing address using CorrespondenceAddress
                ipMailingAddress = createMailingAddress(application, interestedParty, caContact);
                interestedPartiesAddresses.add(ipMailingAddress);
            }
        } else {
            if (null != ipAddress) {
                ipMailingAddress = createMailingAddress(application, interestedParty, mainContact);
                interestedPartiesAddresses.add(ipMailingAddress);
            }
        }
    }

    private CorrespondenceAddressType getCorrsponseTypeAddressByType(Object transType) throws MTSServiceFault {
        if (transType == null) {
            return null;
        }

        CorrespondenceAddressType csType = null;
        if (transType instanceof MadridDesignationType) {
            csType = ((MadridDesignationType) transType).getCorrespondenceAddress();

        } else if (transType instanceof MadridHolderRepresentativeChangeType) {
            csType = ((MadridHolderRepresentativeChangeType) transType).getCorrespondenceAddress();

        } else if (transType instanceof MadridPartialChangeOwnershipType) {
            csType = ((MadridPartialChangeOwnershipType) transType).getMadridDesignation().getCorrespondenceAddress();
        }

        logger.debug("CorrespondenceAddressType " + csType);
        return csType;
    }

    private List<ApplicantType> getHolderListByType(Object transType) throws MTSServiceFault {
        if (transType == null) {
            return null;
        }

        if (transType instanceof MadridDesignationType) {
            return ((MadridDesignationType) transType).getHolderBag().getHolder();

        } else if (transType instanceof MadridHolderRepresentativeChangeType) {
            return ((MadridHolderRepresentativeChangeType) transType).getHolderChangeBag().getHolderBag().getHolder();

        } else if (transType instanceof MadridPartialChangeOwnershipType) {
            return ((MadridPartialChangeOwnershipType) transType).getMadridDesignation().getHolderBag().getHolder();
        }
        return new ArrayList<ApplicantType>();
    }

    private ContactType getContactTypeByType(Object transType) throws MTSServiceFault {
        if (transType == null) {
            return null;
        }
        CorrespondenceAddressType type = getCorrsponseTypeAddressByType(transType);

        ContactType caType = null;
        for (Object aType : type.getPartyIdentifierOrContact()) {
            if (aType instanceof ContactType) {
                caType = (ContactType) aType;

                if (caType == null || caType.getName() == null) {
                    logger.error("CorrespondenceAddress has no contact or no name!");
                }
                break;
            }
        }
        logger.debug("Contact type " + caType);
        return caType;
    }

}
