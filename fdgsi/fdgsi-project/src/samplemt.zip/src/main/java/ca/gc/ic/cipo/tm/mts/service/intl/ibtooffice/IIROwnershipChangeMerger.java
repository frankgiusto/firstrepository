package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;

public interface IIROwnershipChangeMerger {

    /**
     * Process ir change ownership merger.
     *
     * @param transactionPairDto the transaction pair dto
     * @return the map
     * @throws MTSServiceFault the MTS service fault
     */
    public Map<ApplicationDto, UserTaskType> processIRChangeOwnershipMerger(TransactionPairDto transactionPairDto)
        throws MTSServiceFault;
}
