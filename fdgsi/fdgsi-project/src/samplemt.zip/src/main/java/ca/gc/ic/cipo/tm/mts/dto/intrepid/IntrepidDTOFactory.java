package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionsResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoTypeDto;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionsMap;

@Component
public class IntrepidDTOFactory implements IIntrepidDTOFactory {

    @Override
    public ApplicationDto getApplicationDto(Application application, OfficeType officeType) {

        ApplicationDto applicationDto = new ApplicationDto();
        BeanUtils.copyProperties(application, applicationDto);
        applicationDto.setFileNumber(application.getFileNumber());
        applicationDto.setExtensionCounter(application.getExtensionCounter().toString());
        applicationDto.setTaskStatusCode(TaskStatusType.UNPROCESSED.getValue());
        applicationDto.setOfficeType(officeType.name());

        return applicationDto;
    }

    @Override
    public ApplicationDto getApplicationDto(Application application) {

        ApplicationDto applicationDto = new ApplicationDto();
        BeanUtils.copyProperties(application, applicationDto);
        applicationDto.setFileNumber(application.getFileNumber());
        applicationDto.setExtensionCounter(application.getExtensionCounter().toString());

        return applicationDto;
    }

    @Override
    public ApplicationDto getApplicationDto(String irNumber, OfficeType officeType) {

        ApplicationDto applicationDto = new ApplicationDto();
        applicationDto.setExtensionCounter(null);
        applicationDto.setFileNumber(null);
        applicationDto.setIrNumber(irNumber);
        applicationDto.setOfficeType(officeType.name());

        return applicationDto;
    }

    @Override
    public List<ProcessActionsResponse> getProcessActionResultsDto(List<ProcessAction> processActionResults,
                                                                   ProcessActionCategoryType processActionType) {

        List<ProcessActionsResponse> processActionResultDtoList = new ArrayList<>();

        for (ProcessAction processActionResult : processActionResults) {

            processActionResultDtoList.add(initProcessActionResultDto(processActionResult, processActionType));

        }
        return processActionResultDtoList;
    }

    @Override
    public ProcessActionsResponse getProcessActionResultDto(ProcessAction processActionResult,
                                                            ProcessActionCategoryType processActionType) {

        ProcessActionsResponse processActionResultDto = initProcessActionResultDto(processActionResult,
            processActionType);

        return processActionResultDto;
    }

    @Override
    public ProcessActionsResponse getProcessActionResultDto(ProcessAction processActionResult,
                                                            ProcessActionCategoryType processActionType,
                                                            String authorityId) {

        ProcessActionsResponse processActionResultDto = initProcessActionResultDto(processActionResult,
            processActionType);

        processActionResultDto.getProcessActionsMeta().setAuthorityId(authorityId);

        return processActionResultDto;
    }

    @Override
    public ConsoleTaskList getConsoleTaskList(ProcessActionsMeta processActionsMeta) {

        ConsoleTaskList consoleTask = new ConsoleTaskList();
        ConsoleTaskMeta consoleTaskMeta = new ConsoleTaskMeta();
        consoleTaskMeta.setAuthorityId(processActionsMeta.getAuthorityId());
        consoleTaskMeta.setExtensionCounter(processActionsMeta.getExtensionCounter());
        consoleTaskMeta.setWipoReferenceNumber(processActionsMeta.getWipoReferenceNumber());
        consoleTaskMeta.setFileNumber(processActionsMeta.getFileNumber());
        consoleTaskMeta.setIrNumber(processActionsMeta.getIrNumber());
        consoleTaskMeta.setOfficeType(
            ProcessActionsMap.allProcessActionCodesMap.get(processActionsMeta.getProcessCode()).getOfficeType().name());

        if (StringUtils.isNotBlank(processActionsMeta.getAdditionalInfo())) {
            IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
            IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
            intlTaskAddtnlInfoTypeDto.setTaskAddtnlInfoCtgryId(
                BigDecimal.valueOf(TaskAddtnlInfoType.PROCESS_ACTION_ADDITIONAL_INFO.getValue()));
            intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
            intlTaskAddtnlInfoDto.setAddtnlInfo(processActionsMeta.getAdditionalInfo());
            consoleTaskMeta.getAdditionalInfos().add(intlTaskAddtnlInfoDto);
        }

        consoleTask.getTaskListBag().add(consoleTaskMeta);

        return consoleTask;
    }

    private ProcessActionsResponse initProcessActionResultDto(ProcessAction processActionResult,
                                                              ProcessActionCategoryType processActionType) {
        ProcessActionsResponse processActionResultDto = new ProcessActionsResponse();

        ProcessActionsMeta processActionsMeta = new ProcessActionsMeta();
        BeanUtils.copyProperties(processActionResult, processActionsMeta);
        processActionsMeta.setFileNumber(BigDecimal.valueOf(processActionResult.getFileNumber()));
        processActionsMeta.setExtensionCounter(processActionResult.getExtensionCounter().toString());
        processActionsMeta.setProcessActionId(BigDecimal.valueOf(processActionResult.getProcessActionId()));

        if (processActionType == ProcessActionCategoryType.AUTOMATIC) {
            if (ProcessActionsMap.automatedProcessActionCodesMap.containsKey(processActionsMeta.getProcessCode())) {
                processActionsMeta.setProcessActionCodeType(ProcessActionsMap.automatedProcessActionCodesMap
                    .get(processActionsMeta.getProcessCode()).getProcessActionCodeType());
                processActionResultDto.setProcessActionsMeta(processActionsMeta);

            }
        } else if (processActionType == ProcessActionCategoryType.MANUAL) {
            if (ProcessActionsMap.manualProcessActionCodesMap.containsKey(processActionsMeta.getProcessCode())) {

                processActionsMeta.setProcessActionCodeType(ProcessActionsMap.manualProcessActionCodesMap
                    .get(processActionsMeta.getProcessCode()).getProcessActionCodeType());
                processActionResultDto.setProcessActionsMeta(processActionsMeta);

            } else {
                processActionsMeta.setProcessActionCodeType(ProcessActionsMap.notificationProcessActionCodesMap
                    .get(processActionsMeta.getProcessCode()).getProcessActionCodeType());
                processActionResultDto.setProcessActionsMeta(processActionsMeta);
            }
        } else {
            if (ProcessActionsMap.allProcessActionCodesMap.containsKey(processActionsMeta.getProcessCode())) {
                processActionsMeta.setProcessActionCodeType(ProcessActionsMap.allProcessActionCodesMap
                    .get(processActionsMeta.getProcessCode()).getProcessActionCodeType());
                processActionResultDto.setProcessActionsMeta(processActionsMeta);

            }
        }

        return processActionResultDto;
    }

    @Override
    public List<Integer> getProcessActionCodes(ProcessActionCategoryType processActionCategoryType) {

        List<Integer> processActionCodes = new ArrayList<>();
        if (processActionCategoryType == ProcessActionCategoryType.AUTOMATIC) {
            processActionCodes.addAll(ProcessActionsMap.automatedProcessActionCodesMap.keySet());

        } else if (processActionCategoryType == ProcessActionCategoryType.MANUAL) {
            processActionCodes.addAll(ProcessActionsMap.manualProcessActionCodesMap.keySet());
            processActionCodes.addAll(ProcessActionsMap.notificationProcessActionCodesMap.keySet());

        } else {
            processActionCodes.addAll(ProcessActionsMap.allProcessActionCodesMap.keySet());
        }

        return processActionCodes;
    }

}
