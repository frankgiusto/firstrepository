package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridAbandonmentNotificationType;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationStatus;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;

@Service(value = "abandonmentNotification")
public class MadridAbandonmentNotification extends MadridTransactionService implements IInboundTransaction {

    private static Logger logger = Logger.getLogger(MadridAbandonmentNotification.class.getName());

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    MadridApplicationActionDao madridApplicationActionDao;

    @Override
    @Transactional
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {
        logger.debug("Processing MadridAbandonmentNotification for Intl Record Id: " + intlIrTran.getIntlRecordId()
            + ", Transaction ID : " + intlIrTran.getIrTranId());

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
        MadridAbandonmentNotificationType transaction = (MadridAbandonmentNotificationType) transType;

        IdentifierType officeReferenceIdentifier = transaction.getOfficeReferenceIdentifier();
        String wipoReferenceNumber = officeReferenceIdentifier.getValue();

        String mailDate = transaction.getMailDate();
        Date actionDate = null;
        try {
            actionDate = DateFormats.getISOSDF().parse(mailDate);
        } catch (ParseException e) {
            logger.error("Error setting action date");
        }

        // Update Madrid Application Status
        MadridApplication madridApplication = madridApplicationDao
            .getMadridApplicationByReferenceNumber(wipoReferenceNumber);
        madridApplication.setStatusCode(MadridApplicationStatus.CLOSED.getValue());
        madridApplicationDao.saveMadridApplication(madridApplication);

        // clear all process Action on Hold
        List<ProcessAction> processActions = processActionsDao.getProcessActionsByReferenceNumber(wipoReferenceNumber);
        for (ProcessAction pa : processActions) {
            processActionsDao.deleteProcessAction(pa);
        }

        // create new Action for Madrid Application
        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setWipoReferenceNumber(wipoReferenceNumber);
        madridApplicationAction.setActionCode(MadridApplicationActionStatus.CLOSED.getValue());
        madridApplicationAction.setAuthorityId("MADRID");
        madridApplicationAction.setActionDate(actionDate);
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationAction.setMadridApplicationActionsSeqNumber(madridApplicationActionId);
        Long irTranId = intlIrTran.getIrTranId() != null ? intlIrTran.getIrTranId().longValue() : null;
        madridApplicationAction.setIrTranId(irTranId);

        // madridApplicationAction.setAdditionalInfo(null);
        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);

        return statusTypeResults;
    }

}
