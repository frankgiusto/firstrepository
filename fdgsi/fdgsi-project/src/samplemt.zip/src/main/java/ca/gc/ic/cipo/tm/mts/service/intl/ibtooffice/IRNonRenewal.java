package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

/**
 * @author giustof
 *
 *         The Class IRNonRenewalService is responsible for creating and or updating applications in the Intrepid
 *         database with wipo international transaction information.
 */
@Service(value = "irNonRenewal")
public class IRNonRenewal extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(IRNonRenewal.class.getName());

    @Override
    @Transactional
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transactionType)
        throws MTSServiceFault {

        logger.debug("Processing IR Non Renewal: Intl Record Id:" + intlIrTran.getIntlRecordId());

        MadridDesignationTerminationType nonRenewalType = (MadridDesignationTerminationType) transactionType;

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        // Get all applications matching transactions international registration number.

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                // Record Applications with the same IR Number
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue()
                        .intValue()) {

                        // Expunge application
                        application.setStatusCode(TradeMarkStatusType.EXPUNGED.getValue());

                        actionDao.saveAction(createAction(nonRenewalType, application,
                            ActionCode.EXPUNGED_FAILURE_TO_RENEW, SectionAuthority.AAR.name(), null));

                        // Process Action - Print Expunge for Failure to Renew Notification’
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.PRINT_EXPUNGE_FAILURE_RENEW_NOTIFICATION,
                            SectionAuthority.MADRID.name()));

                        if (processOppositionCases(application, registeredOppositionCaseTypes,
                            TradeMarkStatusType.REGISTERED)) {
                            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                                OfficeType.DO);
                            applicationDto.setAuthorityId(SectionAuthority.MC_TMOB_OPERATOR.name());
                            statusTypeResults.put(applicationDto, UserTaskType.IR_NON_RENEWAL_OCCURRED);

                        }

                        applicationDao.saveApplication(application);

                    } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                        .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                        // Not Registered

                        // Process Action - Print Expunge for Failure to Renew Notification’
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.PRINT_WITHDRAWN_FAILURE_RENEW_NOTIFICATION,
                            SectionAuthority.MADRID.name()));

                        // Withdraw application
                        application.setStatusCode(TradeMarkStatusType.WITHDRAWN.getValue());

                        actionDao.saveAction(createAction(nonRenewalType, application,
                            ActionCode.WITHDRAWN_FAILURE_TO_RENEW, SectionAuthority.AAR.name(), null));

                        if (processOppositionCases(application, unRegisteredOppositionCaseTypes,
                            TradeMarkStatusType.REGISTRATION_PENDING)) {
                            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                                OfficeType.DO);
                            applicationDto.setAuthorityId(SectionAuthority.MC_TMOB_OPERATOR.name());
                            statusTypeResults.put(applicationDto, UserTaskType.IR_NON_RENEWAL_OCCURRED);
                        }

                        applicationDao.saveApplication(application);
                    }

                } else {
                    logger.error(
                        "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
                    throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
                }

            }
        } else {
            // Madrid Mark does not exist - manual
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    private boolean processOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                           TradeMarkStatusType tradeMarkStatusType) {

        boolean open = false;
        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    open = true;

                    oppositionCase.setOppStatusCode(OppositionCaseStatus.CLOSED.getValue());

                    oppositionCaseDao.saveOppositionCase(oppositionCase);

                    OppositionCaseAction oppositionCaseAction = createOppositionCaseAction(application, oppositionCase,
                        tradeMarkStatusType, SectionAuthority.OPPS45.name());

                    oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
                    oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
                    applicationDao.saveApplication(application);

                    // Notify the requestor(s) or opponents(s)
                    processActionsDao.saveProcessActions(createProcessAction(application,
                        (tradeMarkStatusType == TradeMarkStatusType.REGISTERED
                            ? ProcessActionsType.PRINT_EXPUNGE_FAILURE_RENEW_NOTIFICATION
                            : ProcessActionsType.PRINT_WITHDRAWN_FAILURE_RENEW_NOTIFICATION),
                        oppositionCase.getOppCaseNumber(), SectionAuthority.MADRID.name()));

                }
            }
        }
        return open;
    }

    @Override
    public String getServiceName() {
        return "IRNonRenewalService";
    }

}
