package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ProcessActionMapBean;

public class ProcessActionsMap {

    public static final Map<Integer, ProcessActionMapBean> automatedProcessActionCodesMap;
    static {
        // status_ctgry_id=508 and pkg_tran_ctgry_id in (10,11,20,21,30,53,54,51,62,52,75,60,61,50,40,71)
        Map<Integer, ProcessActionMapBean> aMap = new HashMap<>();
        aMap.put(242, new ProcessActionMapBean(ProcessActionCodeType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF_1,
            OfficeType.DO));
        aMap.put(226, new ProcessActionMapBean(ProcessActionCodeType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF_2,
            OfficeType.DO));

        aMap.put(228, new ProcessActionMapBean(ProcessActionCodeType.MADRID_GRANT_PROTECTION_MF_4, OfficeType.DO));
        aMap.put(229, new ProcessActionMapBean(ProcessActionCodeType.MADRID_FINAL_DECISION_MF_5, OfficeType.DO));
        aMap.put(230, new ProcessActionMapBean(ProcessActionCodeType.MADRID_FINAL_DECISION_MF_6, OfficeType.DO));
        aMap.put(224, new ProcessActionMapBean(ProcessActionCodeType.MADRID_INVALIDATION_FULL_MF_10, OfficeType.DO));
        aMap.put(225, new ProcessActionMapBean(ProcessActionCodeType.MADRID_INVALIDATION_PARTIAL_MF_10, OfficeType.DO));
        aMap.put(204, new ProcessActionMapBean(ProcessActionCodeType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL,
            OfficeType.DO));
        aMap.put(205, new ProcessActionMapBean(ProcessActionCodeType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL,
            OfficeType.DO));
        aMap.put(222, new ProcessActionMapBean(ProcessActionCodeType.MADRID_CORRECTION_REQUEST, OfficeType.BOTH));
        // aMap.put(211, new ProcessActionMapBean(ProcessActionCodeType.MADRID_POTENTIAL_CEASING_EFFECT,
        // OfficeType.OO));
        aMap.put(217, new ProcessActionMapBean(ProcessActionCodeType.REACTIVATE_TASKS, OfficeType.DO));

        aMap.put(261, new ProcessActionMapBean(ProcessActionCodeType.IRREGULARITY_RESPONSE_SENT, OfficeType.DO));

        automatedProcessActionCodesMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<Integer, ProcessActionMapBean> manualProcessActionCodesMap;
    static {
        Map<Integer, ProcessActionMapBean> aMap = new HashMap<>();
        aMap.put(212,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL, OfficeType.OO));
        aMap.put(227, new ProcessActionMapBean(ProcessActionCodeType.MADRID_PROVISIONAL_REFUSAL_MF_3, OfficeType.DO));
        aMap.put(231, new ProcessActionMapBean(ProcessActionCodeType.MADRID_FURTHER_DECISION_MF_7, OfficeType.DO));
        aMap.put(213, new ProcessActionMapBean(ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9, OfficeType.OO));
        aMap.put(208,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_DIVISION, OfficeType.OO));
        aMap.put(209,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER, OfficeType.OO));
        aMap.put(210,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT, OfficeType.OO));

        manualProcessActionCodesMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<Integer, ProcessActionMapBean> notificationProcessActionCodesMap;
    static {
        Map<Integer, ProcessActionMapBean> aMap = new HashMap<>();
        aMap.put(201,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_READY_FOR_EXAMINATION_MANUAL, OfficeType.DO));
        aMap.put(206,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_NOTIFY_IB_MF_6_REMOVAL_MANUAL, OfficeType.DO));
        aMap.put(207, new ProcessActionMapBean(ProcessActionCodeType.MADRID_IR_NOT_RENEWED_MANUAL, OfficeType.DO));
        aMap.put(216, new ProcessActionMapBean(ProcessActionCodeType.MADRID_IR_REPLACEMENT_MANUAL, OfficeType.DO));
        aMap.put(220,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_REVIEW_CORESPONDENCE_MANUAL, OfficeType.DO));
        aMap.put(215, new ProcessActionMapBean(
            ProcessActionCodeType.MADRID_NOTIFY_WIPO_CLARIFICATION_REQUEST_OUTSTANDING, OfficeType.DO));
        aMap.put(249,
            new ProcessActionMapBean(ProcessActionCodeType.MADRID_NOTIFY_IB_IV_REMOVAL_MANUAL, OfficeType.DO));
        aMap.put(244, new ProcessActionMapBean(ProcessActionCodeType.MADRID_NOTIFY_WIPO_REGISTRATION_REMOVAL_MANUAL,
            OfficeType.DO));
        aMap.put(246, new ProcessActionMapBean(ProcessActionCodeType.MADRID_NOTIFY_IR_CANDIDATE_REGISTRATION_MANUAL,
            OfficeType.DO));
        aMap.put(247, new ProcessActionMapBean(ProcessActionCodeType.NOTIFY_IR_CANDIDATEFOR_EXAM_ABANDOMENT_MANUAL,
            OfficeType.DO));
        aMap.put(250, new ProcessActionMapBean(ProcessActionCodeType.NOTIFY_SUP_PENDING_REGISTRATION_CANDIDATE_MANUAL,
            OfficeType.DO));
        aMap.put(251, new ProcessActionMapBean(ProcessActionCodeType.NOTIFY_EXAM_SUP_PROTOCOLAPPS_17_MONTHS_MANUAL,
            OfficeType.DO));

        notificationProcessActionCodesMap = Collections.unmodifiableMap(aMap);
    }

    /**
     * KEEP THIS HERE AS THE THREE MAPS MUST BE DEFINED BEFORE THE ALL PROCESS ACTION CODE MAP
     */
    public static final Map<Integer, ProcessActionMapBean> allProcessActionCodesMap;
    static {
        Map<Integer, ProcessActionMapBean> aMap = new HashMap<>();
        aMap.putAll(automatedProcessActionCodesMap);
        aMap.putAll(manualProcessActionCodesMap);
        aMap.putAll(notificationProcessActionCodesMap);

        allProcessActionCodesMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<Integer, ActionCode> actionProcessActionMap;
    static {
        Map<Integer, ActionCode> aMap = new HashMap<>();
        aMap.put(204, ActionCode.IR_REPLACEMENT);
        aMap.put(205, ActionCode.IR_REPLACEMENT);
        aMap.put(242, ActionCode.MF1_SENT);
        aMap.put(226, ActionCode.MF2_SENT);
        aMap.put(227, ActionCode.MF3_SENT);
        aMap.put(228, ActionCode.MF4_SENT);
        aMap.put(229, ActionCode.MF5_SENT);
        aMap.put(230, ActionCode.MF6_SENT);
        aMap.put(231, ActionCode.MF7_SENT);
        aMap.put(224, ActionCode.INVALIDATION_TOTAL_SENT);
        aMap.put(225, ActionCode.INVALIDATION_PARTIAL_SENT);
        aMap.put(261, ActionCode.IRREGULARITY_RESPONSE_SENT);

        actionProcessActionMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<Integer, ActionCode> reverseActionProcessActionMap;
    static {
        Map<Integer, ActionCode> aMap = new HashMap<>();
        aMap.put(204, ActionCode.REPLACED_BY_IR_MARK);
        aMap.put(205, ActionCode.REPLACED_BY_IR_MARK);

        reverseActionProcessActionMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<Integer, String> actionProcessActionAdditionalInfoMap;
    static {
        Map<Integer, String> aMap = new HashMap<>();
        aMap.put(204, "Full IR Replacement of ##VALUE##");
        aMap.put(205, "Partial IR Replacement of ##VALUE##");

        actionProcessActionAdditionalInfoMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<Integer, String> reverseActionProcessActionAdditionalInfoMap;
    static {
        Map<Integer, String> aMap = new HashMap<>();
        aMap.put(204, "Full Replaced by ##VALUE##");
        aMap.put(205, "Partial Replaced by ##VALUE##");

        reverseActionProcessActionAdditionalInfoMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<MadridOutboundTransactionType, Integer> packageTransactionTypeProcessActionMap;
    static {

        Map<MadridOutboundTransactionType, Integer> aMap = new HashMap<>();
        aMap.put(MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1, 242);
        aMap.put(MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF2, 226);
        aMap.put(MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3, 227);
        aMap.put(MadridOutboundTransactionType.MADRID_GRANT_PROTECTION_MF4, 228);
        aMap.put(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5, 229);
        aMap.put(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF6, 230);
        aMap.put(MadridOutboundTransactionType.MADRID_FURTHER_DECISION_MF7, 231);
        aMap.put(MadridOutboundTransactionType.MADRID_INVALIDATION_FULL_MF10, 224);
        aMap.put(MadridOutboundTransactionType.MADRID_INVALIDATION_PARTIAL_MF10, 225);
        aMap.put(MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL, 204);
        aMap.put(MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL, 205);
        aMap.put(MadridOutboundTransactionType.MADRID_CORRECTION_REQUEST, 222);
        aMap.put(MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9, 213);
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_DIVISION, 208);
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER, 209);
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT, 210);
        aMap.put(MadridOutboundTransactionType.IRREGULARITY_RESPONSE_SENT, 261);

        packageTransactionTypeProcessActionMap = Collections.unmodifiableMap(aMap);
    }

    public static boolean isManualTask(Integer processCode) {

        if (manualProcessActionCodesMap.containsKey(processCode)) {
            return true;
        }
        return false;
    }

}
