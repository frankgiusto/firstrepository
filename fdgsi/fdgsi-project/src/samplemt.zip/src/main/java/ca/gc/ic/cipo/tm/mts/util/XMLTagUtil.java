package ca.gc.ic.cipo.tm.mts.util;

public class XMLTagUtil {

    private static final String START_TAG = "<";

    private static final String CLOSING_START_TAG = "</";

    private static final String END_TAG = ">";

    private static final String CLOSING_END_TAG = "/>";

    public static void appendTagStart(StringBuilder xml, String tagName) {
        xml.append(START_TAG).append(tagName).append(END_TAG);
    }

    public static void appendTagClose(StringBuilder xml, String tagName) {
        xml.append(CLOSING_START_TAG).append(tagName).append(END_TAG);
    }

    public static void appendTag(StringBuilder xml, String tagName, String value) {
        xml.append(START_TAG).append(tagName).append(END_TAG).append(value).append(CLOSING_START_TAG).append(tagName)
            .append(END_TAG);
    }

    public static void appendTag(StringBuilder xml, String tagName) {
        xml.append(START_TAG).append(tagName).append(CLOSING_END_TAG);
    }

}
