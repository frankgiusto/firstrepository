package ca.gc.ic.cipo.tm.mts.service.intl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;

public interface ITaskService {

    /**
     * Gets the user task information which the MWE will use to create a user task.
     *
     * @param intlIrTranId the intl ir tran id
     * @param applicationDto the application dto
     * @param userTaskType the user task type
     * @return the user task information
     */
    // public ConsoleTaskMeta getUserTaskInformation(BigDecimal intlIrTranId, ApplicationDto applicationDto,
    // UserTaskType userTaskType);

    /**
     * Gets the user task information which the MWE will use to create a user task.
     *
     * @param intlIrTranId - the intl ir tran id
     * @param userTaskTypes - a collection of applications and the user task types
     * @return the user task information
     */
    public List<ConsoleTaskResponse> getUserTaskInformation(BigDecimal intlIrTranId,
                                                            Map<ApplicationDto, UserTaskType> userTaskTypes);

    /**
     * Gets the user task information which the MWE will use to create a user task. This method addresses a task
     * associated to 2 wipo transactions.
     *
     * @param transactionPairDto the transaction pair dto. A designation and a restriction transaction.
     * @param userTaskTypes the user task types
     * @return the user task information
     */
    public List<ConsoleTaskResponse> getUserTaskInformation(TransactionPairDto transactionPairDto,
                                                            Map<ApplicationDto, UserTaskType> userTaskTypes);

    /**
     * Creates the user task from automatically processing inbound transactions from WIPO.
     *
     * @param consoleTaskList the console task list
     * @return List of console task ids that have been created with associated authority id
     */
    public List<ConsoleTaskResponse> createUserTask(ConsoleTaskList consoleTaskList);

    /**
     * Gets the user tasks by transaction id.
     *
     * @param irTranId the ir tran id
     * @return the tasks by transaction id
     */
    public List<IntlIrTaskDto> getTasksByTransactionId(BigDecimal irTranId);

    /**
     * Update console task. The MWE will associate the console task with the activit task id.
     *
     * @param taskReferenceId the task reference id
     * @param consoleTaskId the console task id
     * @return void
     */
    public void updateConsoleTaskReference(String taskReferenceId, BigDecimal consoleTaskId);

    /**
     * Update console task status. Activiti will notify that it has completed its task.
     *
     * @param consoleTaskId the console task id
     * @param consoleTaskStatus the console task status
     */
    public void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType consoleTaskStatus);

    /**
     * Gets the workflow task list.
     *
     * @param request the request
     * @return the workflow task list
     * @throws CIPOServiceFault the CIPO service fault
     */
    WorkflowTaskListResponse getWorkflowTaskList(WorkflowTaskListSearchCriteria request) throws CIPOServiceFault;

    /**
     * Gets the ir task by id.
     *
     * @param taskId the task id
     * @return the ir task by id
     */
    public IntlIrTaskDto getIrTaskById(BigDecimal taskId);

    /**
     * Returns the list of Descriptions for the provided search Criteria
     *
     * @param taskDescriptionListSearchCriteria the provided search Criteria
     * @return the list of Descriptions for the provided search Criteria
     * @throws CIPOServiceFault the CIPO service fault
     */
    public TaskDescriptionListResponse getTaskDescriptionList(TaskDescriptionListSearchCriteria taskDescriptionListSearchCriteria)
        throws CIPOServiceFault;

    /**
     * Reactivate tasks with provided file number
     *
     * @param fileNumber the file number
     *
     */
    public void reactivateTasks(BigDecimal fileNumber);
}
