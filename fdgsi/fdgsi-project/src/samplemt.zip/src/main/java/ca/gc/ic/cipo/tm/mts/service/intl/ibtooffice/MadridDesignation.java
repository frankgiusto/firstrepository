package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.common.madrid.FigurativeElementClassificationBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ViennaClassificationBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ViennaClassificationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MarkCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MarkFeatureCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.PriorityBagType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.PriorityType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ApplicationTextDao;
import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.dao.FigurativeElementsDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesTextDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.PhysicalFilesDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.dao.TrademarkDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.ApplicationTextType;
import ca.gc.ic.cipo.tm.enumerator.ClaimType;
import ca.gc.ic.cipo.tm.enumerator.DisclaimerCodeType;
import ca.gc.ic.cipo.tm.enumerator.FileType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.MadridDesignationCategory;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.CipoServiceFault;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.mfs.client.TMMadridFinancialFeeServiceFactory;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationText;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.FigurativeElement;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.GoodServiceComparator;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.PhysicalFiles;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.FeatureCategoryTrademarkType;
import ca.gc.ic.cipo.tm.mts.enums.LanguageIndicator;
import ca.gc.ic.cipo.tm.mts.enums.OriginalIndicator;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.ICourtesyLetterService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * @author giustof
 *
 *         The Class MadridDesignationService is responsible for creating and or updating applications in the Intrepid
 *         database with wipo international transaction information.
 */
@Service(value = "madridDesignation")
public class MadridDesignation extends MadridTransactionService implements IInboundTransaction {

    private final static Integer NICE_CLASS_DEFAULT = null;

    private final static boolean VALIDATE_ONLY = true;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private PhysicalFilesDao physicalFilesDao;

    @Autowired
    private GoodsServicesDao goodsServicesDao;

    @Autowired
    private GoodsServicesTextDao goodsServicesTextDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private TrademarkDao trademarkDao;

    @Autowired
    private FigurativeElementsDao figurativeElementsDao;

    @Autowired
    private ApplicationTextDao applicationTextDao;

    @Autowired
    private GoodsServicesClaimDao goodsServicesClaimDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private ICourtesyLetterService courtestyLetterService;

    @Autowired
    private ClaimDao claimDao;

    @Autowired
    private MailDao mailDao;

    // @Autowired
    // private HibernateTransactionManager transactionManager;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private final static String EMPTY_ADDITIONAL_INFO = null;

    private final static int MAX_APPLICATION_NUMBER_TEXT = 20;

    private final static String LANGUAGE_TYPE_SPANISH = "Spanish";

    private final static String FILE_EXTENSION_PDF = "pdf";

    private TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = null;

    private static Logger logger = Logger.getLogger(MadridDesignation.class.getName());

    // TODO:: to use "https://www-cipodev.ic.gc.ca"
    @Value("#{environment['mts.financial.fee.service.host.name']}")
    private String madridFinancialEndpoint;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing Madrid Designation: Intl Record Id:" + intlIrTran.getIntlRecordId());

        Map<ApplicationDto, UserTaskType> notificationTypes = new HashMap<>();

        MadridDesignationType madridDesignation = (MadridDesignationType) transType;

        LanguageType applicationLanguage = this.getApplicationLanguage(madridDesignation.getNotificationLanguage());

        // Validate transaction
        this.validateTransaction(madridDesignation, applicationLanguage);

        // Create application
        Application application = createApplication(madridDesignation, notificationTypes);

        // Check if a courtesy letter is required
        int arNum = 0;
        if (null != madridDesignation.getRepresentative()) {
            arNum = courtestyLetterService.checkIsCourtesyLetterRequired(madridDesignation, application,
                applicationLanguage, notificationTypes);
        }

        // Interested Parties
        createInterestedParty(madridDesignation, application, applicationLanguage, notificationTypes, false, arNum);

        // Goods and Services
        createGoodsAndServices(madridDesignation, application, applicationLanguage, notificationTypes, false);

        // Trademarks
        createTrademarks(madridDesignation, application, applicationLanguage, notificationTypes, false);
        
        // Application Texts
        createApplicationText(madridDesignation, application, applicationLanguage);

        // Physical Files
        createPhysicalFiles(application);
        
        // Mail
        createMail(madridDesignation, application, intlIrTran, MAIL_INDICATOR_AUTOMATED);

        // Actions
        createActions(madridDesignation, application);

        // Process Actions
        createProcessActions(application, getFileNameByFileNumber(application), madridDesignation);

        // Save the application
        applicationDao.saveApplication(application);

        logger.debug("Application Saved " + application.getFileNumber());

        // If more than 1 Interested Party Holder, then create a notification
        if (madridDesignation.getHolderBag().getHolder().size() > 1) {
            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
            notificationTypes.put(applicationDto, UserTaskType.REVIEW_OWNER_NAME);
        }

        if (notificationTypes.size() == 0) {
            notificationTypes.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);
        }

        return notificationTypes;

    }

    private String getFileNameByFileNumber(Application application) {
        String filename = null;
        BigDecimal fnum = BigDecimal.valueOf(application.getFileNumber());
        List<Mail> mails = mailDao.getMailByFileId(fnum.intValue());
        for (Mail mail : mails) { // only one
            // check if the file name extension
            String ext = FilenameUtils.getExtension(mail.getAttachmentFileName());

            // set the file name only with pdf extension
            if (StringUtils.isNotEmpty(ext) && ext.equalsIgnoreCase(FILE_EXTENSION_PDF)) {
                filename = mail.getAttachmentFileName();
                logger.debug("file name: " + filename);
            }
        }
        return filename;
    }

    private void validateTransaction(MadridDesignationType madridDesignation, LanguageType applicationLanguage)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> notificationTypes = new HashMap<>();

        Application application = new Application();
        application.setExtensionCounter(0);

        // Trade Marks
        createTrademarks(madridDesignation, application, applicationLanguage, notificationTypes, VALIDATE_ONLY);

        // Interested Parties
        createInterestedParty(madridDesignation, application, applicationLanguage, notificationTypes, VALIDATE_ONLY, 0);

        // Goods and Services
        createGoodsAndServices(madridDesignation, application, applicationLanguage, notificationTypes, VALIDATE_ONLY);

    }

    private Application createApplication(MadridDesignationType madridDesignation,
                                          Map<ApplicationDto, UserTaskType> notificationTypes) {

        Application application = new Application();

        application.setFileNumber(applicationDao.getNextApplicationNumber().intValue());
        application.setExtensionCounter(0);
        application.setIrNumber(madridDesignation.getInternationalRegistrationNumber());
        application.setIntlFilingRecordId(madridDesignation.getRecordIdentifier().getValue());
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        if (madridDesignation.getMadridDesignationCategory() == MadridDesignationCategoryType.REGISTRATION) {
            application
                .setMadridDesignationCategory(MadridDesignationCategory.MADRID_DESIGNATION_REGISTRATION.getValue());
        } else {
            application.setMadridDesignationCategory(
                MadridDesignationCategory.MADRID_DESIGNATION_SUBSEQUENT_DESIGNATION.getValue());
        }

        application.setLegislation(LegislationType.TMA.getValue());

        // Trademark Class
        if (null != madridDesignation.getMarkCategory()
            && (madridDesignation.getMarkCategory() == MarkCategoryType.CERTIFICATION_MARK
                || madridDesignation.getMarkCategory() == MarkCategoryType.COLLECTIVE_MARK
                || madridDesignation.getMarkCategory() == MarkCategoryType.COLLECTIVE_TRADEMARK
                || madridDesignation.getMarkCategory() == MarkCategoryType.COLLECTIVE_SERVICE_MARK
                || madridDesignation.getMarkCategory() == MarkCategoryType.COLLECTIVE_MEMBERSHIP_MARK)) {

            application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        } else {
            application.setTradeMarkClass(TradeMarkClassType.TRADEMARK.getValue());
        }

        // Trademark Type
        setApplicationTradeMarkType(madridDesignation, application);

        if (application.getTradeMarkType().intValue() == TradeMarkType.TRACER.getValue()
            || application.getTradeMarkType().intValue() == TradeMarkType.OTHER.getValue()) {

            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
            notificationTypes.put(applicationDto, UserTaskType.REVIEW_MARK_TYPE);
        }

        // set disclaimerCode when getMarkDisclaimerBag is not null
        if (null != madridDesignation.getMarkDisclaimerBag()) {
            application.setDisclaimerCode(DisclaimerCodeType.DISCLAIMER_ENTIRE_TEXT.getValue());
        }

        // change from tmk:OfficeOriginCode to from the Holder’s Address
        application.setCountryOfOrigin(getCountryCodefromHolder(madridDesignation));

        application.setModifiedDate(new Date());

        // Save the application
        applicationDao.saveApplication(application);

        return application;
    }

    private void createInterestedParty(MadridDesignationType madridDesignation, Application application,
                                       LanguageType applicationLanguage,
                                       Map<ApplicationDto, UserTaskType> notificationTypes, boolean validateOnly,
                                       int arNum)
        throws MTSServiceFault {

        int ipNumber = 1;

        List<ApplicantType> holderList = madridDesignation.getHolderBag().getHolder();

        if (CollectionUtils.isEmpty(holderList)) {
            logger.error("madridDesignationType.getHolderBag() is empty!");
            return;
        }

        // Create Designation Interested Party
        // ApplicantFileReference to be loaded in Interested_Parties.Reference
        String fileRef = madridDesignation.getApplicantFileReference();
        InterestedParty interestedParty = createMDInterestedParty(application, ipNumber, fileRef);

        // Create the Contact Information
        setInterestedPartyContact(applicationLanguage, holderList, application, interestedParty, validateOnly);

        // update InterestedParty and also use it when setting mailing address
        setInterestedPartyAddress(holderList, application, interestedParty, madridDesignation);

        if (mailingAddressLengthNotification(holderList, interestedParty)) {
            // Notification that address > 8 lines by 40 chars
            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);

            // set AuthorityId to MC_TMOB_OPERATOR
            applicationDto.setAuthorityId(SectionAuthority.MC_TM_OPERATOR.name());
            notificationTypes.put(applicationDto, UserTaskType.ADDRESS_EXCEEDED_LIMIT);
        }

        if (!validateOnly) {
            for (InterestedPartiesAddresses eachAddress : interestedParty.getContact()
                .getInterestedPartiesAddresses()) {
                interestedPartiesAddressesDao.saveInterestedPartiesAddresses(eachAddress);
            }
            // set ar_number
            if (arNum != 0) {
                interestedParty.setAgentNumber(arNum);
            }
            application.getInterestedParties().add(interestedParty);
            interestedPartyDao.saveInterestedParty(interestedParty);
        }
    }

    private void createGoodsAndServices(MadridDesignationType madridDesignation, Application application,
                                        LanguageType applicationLanguage,
                                        Map<ApplicationDto, UserTaskType> notificationTypes, boolean validateOnly)
        throws MTSServiceFault {

        if (null == madridDesignation.getGoodsServicesBag()) {
            logger.debug("Transaction does not contain a goodsServicesBag");
            return;
        }

        // JIRA:TMMADCON-2013 : ClassificationVersion from GoodServices should be used for all classDescription and
        // Limitation. Note: GoodServicesLimitation does not have classificationVersion at GoodServiceLimitationLevel)
        String classificationVersion = null;
        for (GoodsServicesType goodsServices : madridDesignation.getGoodsServicesBag().getGoodsServices()) {
            if (goodsServices != null) {
                classificationVersion = goodsServices.getClassificationVersion();
            }
        }

        // Good and Services
        createMainOrLimitGoodAndServices(madridDesignation, application, applicationLanguage, classificationVersion,
            notificationTypes, validateOnly);

        // Claims
        createClaims(madridDesignation, application, applicationLanguage, classificationVersion, notificationTypes,
            validateOnly);

        // create notification for review for TMOperator
        if (checkExistGSDescriptionText(madridDesignation, application)) {
            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
            notificationTypes.put(applicationDto, UserTaskType.REVIEW_GOOD_SERVICE);
        }

        // Number of Nice Classes at Filing
        Set<GoodService> goodsServices = application.getGoodsServices();
        Iterator<GoodService> iterator = goodsServices.iterator();
        Set<Integer> niceClasses = new HashSet<>();

        while (iterator.hasNext()) {
            niceClasses.add(iterator.next().getNiceClassCode());
        }
        application.setNiceClassesAtFiling(niceClasses.size());

        // add notification
        for (GoodService gs : goodsServices) {
            if (gs.getNiceEdition() == null) {
                // create notification
                ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_EXAMINER.name());
                notificationTypes.put(applicationDto, UserTaskType.REVIEW_NICE_EDITION); // create Review Nice Edition
                break;
            }
        }

        BigDecimal filingFee = calculateFilingFeeAmount(madridDesignation);
        if (filingFee != null) {
            if (filingFee.intValue() <= 9999) {
                application.setFilingFeeAmount(filingFee.intValue());
            } else {
                logger.error("Error calculating fee. Fee Amount to large for db: " + filingFee);
            }
        }

    }

    private void createMainOrLimitGoodAndServices(MadridDesignationType madridDesignation, Application application,
                                                  LanguageType applicationLanguage, String classificationVersion,
                                                  Map<ApplicationDto, UserTaskType> notificationTypes,
                                                  boolean validateOnly)
        throws MTSServiceFault {

        // check if tmk:GoodsServicesLimitationBag exists. If yes, process it; if not process GoodServices / Main list
        _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationBagType gslb = madridDesignation
            .getGoodsServicesLimitationBag();

        if (gslb != null) {
            // if GoodsServicesLimitationBag, there are rules to follow:
            // 1). if there is only CommentText, processing main Good and Services as well as notification
            // 2). if there are both CommentText and G&S in limitation, processing main G&S as well as notification
            // 3). if there is NO CommentText, but G&S in limitation, do the following:
            // Don't process main G&S
            // process G&S in the limitation
            // and set indicator to 1

            logger.debug("processing GoodsServicesLimitationBagType");

            List<GoodsServicesLimitationType> wipsGSLTypes = gslb.getGoodsServicesLimitation();

            boolean commentText = false;
            for (GoodsServicesLimitationType gsl : wipsGSLTypes) {
                for (Object obj : gsl
                    .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag()) {

                    logger.debug("GoodsServicesLimitationType: " + obj);
                    if (obj instanceof OrderedTextType) {
                        commentText = true;
                        break;

                    } else if (obj instanceof ClassDescriptionBagType) {
                        List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) obj).getClassDescription();
                        for (ClassDescriptionType classDescription : classTypes) {
                            this.createGoodsOrServices(application, applicationLanguage, classDescription,
                                classificationVersion, true, notificationTypes, validateOnly);
                        }
                    }
                }
            }
            logger.debug("commentText: " + commentText);
            if (commentText) {
                // processing the main G&S
                logger.debug(
                    "createMainGoodServices with GoodsServicesLimitationBagType and commentText is " + commentText);
                createMainGoodServices(madridDesignation, application, applicationLanguage, notificationTypes,
                    classificationVersion, validateOnly, true);

                ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                applicationDto.setAuthorityId(SectionAuthority.MC_TM_EXAMINER.name());
                notificationTypes.put(applicationDto, UserTaskType.DESIGNATION_LIMITATION);
            }
        } else {
            // processing the main G&S
            logger.debug("createMainGoodServices without GoodsServicesLimitationBagType");
            createMainGoodServices(madridDesignation, application, applicationLanguage, notificationTypes,
                classificationVersion, validateOnly, false);
        }
    }

    private void createMainGoodServices(MadridDesignationType madridDesignation, Application application,
                                        LanguageType applicationLanguage,
                                        Map<ApplicationDto, UserTaskType> notificationTypes,
                                        String classificationVersion, boolean validateOnly, boolean isLimitation)
        throws MTSServiceFault {
        // according to xsd, must exist.
        for (GoodsServicesType goodsServicesType : madridDesignation.getGoodsServicesBag().getGoodsServices()) {
            // Goods and Services Text
            List<ClassDescriptionType> classDesTypes = goodsServicesType.getClassDescriptionBag().getClassDescription();
            if (CollectionUtils.isNotEmpty(classDesTypes)) {
                for (ClassDescriptionType classDescription : classDesTypes) {

                    logger.debug("classDescription: " + classDescription.getClassNumber());
                    this.createGoodsOrServices(application, applicationLanguage, classDescription,
                        classificationVersion, isLimitation, notificationTypes, validateOnly);
                }
            }
        }
    }

    private BigDecimal calculateFilingFeeAmount(MadridDesignationType madridDesignation) throws MTSServiceFault {
        BigDecimal filingFeeAmount = null;

        Date feeCalculationDate = null;
        try {
            feeCalculationDate = DateFormats.getISOSDF().parse(madridDesignation.getFeeCalculationDate());
        } catch (Exception e) {
            logger.error("Error parsing madridDesignation.getFeeCalculationDate():", e);
        }
        GoodsAndServicesClasses goodsAndServicesClasses = new GoodsAndServicesClasses();
        // If there is a GoodsServicesLimitationBag, we need to use the classes in it instead of the ones in the
        // GoodsServicesBag
        // See TMMADCON-1786 for more details
        // The getGoodsServicesLimitationBag may not always contain a ClassDescriptionBagType, so we need to
        // validate that it does
        boolean limitationsFound = false;
        if (madridDesignation.getGoodsServicesLimitationBag() != null
            && madridDesignation.getGoodsServicesLimitationBag().getGoodsServicesLimitation() != null
            && madridDesignation.getGoodsServicesLimitationBag().getGoodsServicesLimitation().size() > 0) {
            GoodsServicesLimitationType goodsServicesLimitationType = madridDesignation.getGoodsServicesLimitationBag()
                .getGoodsServicesLimitation().get(0);

            if (goodsServicesLimitationType
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag() != null
                && goodsServicesLimitationType
                    .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag().size() > 1) {
                Object obj = goodsServicesLimitationType
                    .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag().get(1);
                if (obj instanceof ClassDescriptionBagType) {
                    ClassDescriptionBagType classDescriptionBagType = (ClassDescriptionBagType) obj;

                    limitationsFound = true;
                    for (ClassDescriptionType classDescription : classDescriptionBagType.getClassDescription()) {
                        goodsAndServicesClasses.getGoodsAndServicesClasses()
                            .add(Integer.valueOf(classDescription.getClassNumber()));
                    }
                }
            }
        }

        if (!limitationsFound) {
            for (GoodsServicesType goodsServicesType : madridDesignation.getGoodsServicesBag().getGoodsServices()) {
                for (ClassDescriptionType classDescription : goodsServicesType.getClassDescriptionBag()
                    .getClassDescription()) {
                    goodsAndServicesClasses.getGoodsAndServicesClasses()
                        .add(Integer.valueOf(classDescription.getClassNumber()));
                }
            }
        }

        if (madridFinancialFeeServiceClient == null) {
            madridFinancialFeeServiceClient = TMMadridFinancialFeeServiceFactory.createClient(madridFinancialEndpoint);
        }

        // Determine the type of fee either subsequent designation or designation.
        MadridDesignationCategoryType madridDesignationCategoryType = madridDesignation.getMadridDesignationCategory();

        MadridFinancialTransactionCategoryType madridFinancialTransactionCategoryType = madridDesignationCategoryType == MadridDesignationCategoryType.SUBSEQUENT_DESIGNATION
            ? MadridFinancialTransactionCategoryType.SUBSEQUENT_DESIGNATION
            : MadridFinancialTransactionCategoryType.DESIGNATION;

        try {
            filingFeeAmount = madridFinancialFeeServiceClient.calculateFee(madridFinancialTransactionCategoryType,
                goodsAndServicesClasses, feeCalculationDate);
        } catch (CipoServiceFault e) {
            logger.error("Error calculating fee amount.", e);
        }

        return filingFeeAmount;
    }

    private boolean checkExistGSDescriptionText(MadridDesignationType madridDesignation, Application application) {
        // If the tmk: PriorityPartialGoodsServices and tmk:GoodsServicesDescriptionText exist
        // in the tmk:Priority then create an additional Good or Service.
        // System must create a new “Notify” task for “TM Madrid Operator” as Type ‘Review Goods/Services’
        if (null != madridDesignation.getPriorityBag()) {
            PriorityBagType priorityBag = madridDesignation.getPriorityBag();
            if (priorityBag != null && priorityBag.getPriority().size() > 0) {
                Iterator<PriorityType> pt = priorityBag.getPriority().iterator();
                while (pt.hasNext()) {
                    PriorityType priorityType = pt.next();
                    if (priorityType.getPriorityPartialGoodsServices() != null) {
                        if (priorityType.getPriorityPartialGoodsServices().getClassDescriptionBag() != null) {
                            Iterator<ClassDescriptionType> cdt = priorityType.getPriorityPartialGoodsServices()
                                .getClassDescriptionBag().getClassDescription().iterator();
                            while (cdt.hasNext()) {
                                ClassDescriptionType classDescriptionType = cdt.next();
                                if (classDescriptionType != null
                                    && classDescriptionType.getGoodsServicesDescriptionText().size() > 0) {
                                    List<OrderedTextType> texts = classDescriptionType
                                        .getGoodsServicesDescriptionText();
                                    for (OrderedTextType text : texts) {
                                        if (StringUtils.isNotEmpty(text.getValue())) {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private GoodService getLastGoodService(Set<GoodService> goodServices, GoodServiceType goodServiceType) {

        GoodService goodService = null;
        if (CollectionUtils.isEmpty(goodServices)) {
            goodService = new GoodService();
            goodService.setNumber(0);
            return goodService;
        }
        Set<GoodService> specificGS = new HashSet<>();
        for (GoodService gs : goodServices) {
            if (gs.getType() == goodServiceType.getValue()) {
                specificGS.add(gs);
            }
        }
        TreeSet<GoodService> sortedSet = new TreeSet<>(getGoodServiceComparator());
        if (specificGS.size() == 0) {
            goodService = new GoodService();
            goodService.setNumber(0);
            return goodService;
        }
        sortedSet.addAll(specificGS);

        return sortedSet.last();
    }

    private GoodService createGoodsOrServices(Application application, LanguageType applicationLanguage,
                                              ClassDescriptionType classDescription, String classificationVersion,
                                              boolean isLimitListCode,
                                              Map<ApplicationDto, UserTaskType> notificationTypes, boolean validateOnly)
        throws MTSServiceFault {

        Integer goodsSequence = 0;
        Integer serviceSequence = 0;
        Set<GoodService> goodsServicesSet = new TreeSet<>(new GoodServiceComparator());
        Set<GoodServiceText> goodsServicesText = new HashSet<>();

        goodsServicesSet.addAll(application.getGoodsServices());

        // New GoodService
        GoodService goodsService = new GoodService();
        try {
            goodsService.setFileNumber(application.getFileNumber());
            goodsService.setExtensionCounter(application.getExtensionCounter());
            goodsService.setType(goodsOrService(classDescription.getClassNumber()).getValue());

            if (goodsService.getType().equals(GoodServiceType.GOODS.getValue())) {
                GoodService lastGoodService = getLastGoodService(goodsServicesSet, GoodServiceType.GOODS);
                goodsSequence = lastGoodService.getNumber() + 1;
                goodsService.setNumber(goodsSequence);
            } else {
                GoodService lastGoodService = getLastGoodService(goodsServicesSet, GoodServiceType.SERVICES);
                serviceSequence = lastGoodService.getNumber() + 1;
                goodsService.setNumber(serviceSequence);
            }

            goodsService.setNiceClassCode(Integer.valueOf(classDescription.getClassNumber()));
            if (StringUtils.isBlank(classificationVersion)) {
                // Set to default
                goodsService.setNiceEdition(NICE_CLASS_DEFAULT);
            } else {
                goodsService.setNiceEdition(MtsStringUtil.formatNiceClassificationVersion(classificationVersion));
            }

            // Goods Service Text
            buildGSText(classDescription.getGoodsServicesDescriptionText(), goodsServicesText, goodsService,
                application, applicationLanguage);

            goodsService.setGoodServiceTexts(goodsServicesText);

            goodsServicesSet.add(goodsService);

            if (!validateOnly) {
                goodsServicesDao.saveGoodsServices(goodsService);
                for (GoodServiceText goodServiceText : goodsServicesText) {
                    goodsServicesTextDao.saveGoodServiceText(goodServiceText);
                }
            }
            if (isLimitListCode) {
                application.setLimitationListCode(LIMITATION_LIST_CODE_NOTEXAMINED);
            }
            application.setGoodsServices(goodsServicesSet);

        } catch (Exception e) {
            logger.error("Error createGoodsOrServices");
            throwMTSServiceFault("mts.designation.gs.claims", ExceptionReasonCode.DESIGNATION_ERROR);
        }

        return goodsService;
    }

    private Integer getAppTextLanguageIndicator(ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        if (applicationLanguage == LanguageType.ENGLISH) {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return LanguageIndicator.APP_ENGLISH_APP_TEXT_ENGLISH.getLanguage();
            } else {
                return LanguageIndicator.APP_ENGLISH_APP_TEXT_FRENCH.getLanguage();
            }
        } else {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return LanguageIndicator.APP_FRENCH_APP_TEXT_ENGLISH.getLanguage();
            } else {
                return LanguageIndicator.APP_FRENCH_APP_TEXT_FRENCH.getLanguage();
            }
        }
    }

    private Integer getAppTextOriginalIndicator(ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        if (applicationLanguage == LanguageType.ENGLISH) {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return OriginalIndicator.APP_ENGLISH_APP_TEXT_ENGLISH.getOrininalInd();
            } else {
                return OriginalIndicator.APP_ENGLISH_APP_TEXT_FRENCH.getOrininalInd();
            }
        } else {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return OriginalIndicator.APP_FRENCH_APP_TEXT_ENGLISH.getOrininalInd();
            } else {
                return OriginalIndicator.APP_FRENCH_APP_TEXT_FRENCH.getOrininalInd();
            }
        }
    }

    private void createClaims(MadridDesignationType madridDesignation, Application application,
                              LanguageType applicationLanguage, String classificationVersion,
                              Map<ApplicationDto, UserTaskType> notificationTypes, boolean validateOnly)
        throws MTSServiceFault {

        if (null != madridDesignation.getPriorityBag()) {
            PriorityBagType priorityBag = madridDesignation.getPriorityBag();
            if (CollectionUtils.isEmpty(priorityBag.getPriority())) {
                return;
            }
            int claimNumber = 1;
            for (PriorityType priorityType : priorityBag.getPriority()) {

                Claim claim = new Claim();
                claim.setApplication(application);
                claim.setFileNumber(application.getFileNumber());
                claim.setExtensionCounter(application.getExtensionCounter());
                claim.setClaimType(ClaimType.PRIORITY_FILING.getValue());
                claim.setClaimNumber(claimNumber);

                if (null != priorityType.getApplicationNumber() && priorityType.getApplicationNumber()
                    .getApplicationNumberText().trim().length() <= MAX_APPLICATION_NUMBER_TEXT) {
                    claim.setForeignRegistrationNumber(
                        priorityType.getApplicationNumber().getApplicationNumberText().trim());
                } else {
                    logger.error("Application number text is to large for ForeignRegistrationNumber in Claims table:"
                        + priorityType.getApplicationNumber().getApplicationNumberText());
                }

                try {
                    Date claimDate = DateFormats.getISOSDF().parse(priorityType.getPriorityApplicationFilingDate());
                    claim.setClaimDate(String.valueOf(DateFormats.getDataSDF().format(claimDate)));

                } catch (ParseException e) {
                    logger.error("Could not format claim date:" + priorityType.getPriorityApplicationFilingDate());
                }
                claim.setClaimCountry(priorityType.getPriorityCountryCode());
                claim.setLanguage(applicationLanguage.getValue()); // TODO see if there is more to this like GS Text.

                if (!validateOnly) {
                    claimDao.saveClaim(claim);

                    application.getClaims().add(claim);
                }

                if (null != priorityType.getPriorityPartialGoodsServices()) {
                    processPriorityPartialGoodsServices(priorityType, claim, application, applicationLanguage,
                        classificationVersion, notificationTypes, validateOnly);

                } else {
                    // SUC 2.1 BR#7: case 1
                    Set<GoodService> goodsServicesSet = application.getGoodsServices();
                    Set<GoodServiceClaim> goodServiceClaims = new HashSet<>();

                    Iterator<GoodService> iterator = goodsServicesSet.iterator();
                    while (iterator.hasNext()) {
                        GoodService goodService = iterator.next();

                        GoodServiceClaim goodsServiceClaim = createGoodServiceClaim(application,
                            goodsOrService(goodService.getNiceClassCode().toString()), claimNumber,
                            goodService.getNumber());

                        goodServiceClaims.add(goodsServiceClaim);
                        goodsServiceClaim.setClaim(claim);
                        if (!validateOnly) {
                            goodsServicesClaimDao.saveGoodServiceClaim(goodsServiceClaim);
                        }
                    }
                    if (!validateOnly) {
                        claim.setGoodServiceClaims(goodServiceClaims);
                        claimDao.saveClaim(claim);
                    }
                }

                claimNumber++;
            }

        }
    }

    private void processPriorityPartialGoodsServices(PriorityType priorityType, Claim claim, Application application,
                                                     LanguageType applicationLanguage, String classificationVersion,
                                                     Map<ApplicationDto, UserTaskType> notificationTypes,
                                                     boolean validateOnly)
        throws MTSServiceFault {

        boolean matchedGS = true;
        GoodsServicesType priorityPartialGoodsServices = priorityType.getPriorityPartialGoodsServices();
        if (null != priorityPartialGoodsServices.getClassDescriptionBag()) {
            ClassDescriptionBagType classDescriptionBag = priorityPartialGoodsServices.getClassDescriptionBag();

            Set<GoodServiceClaim> goodServiceClaims = new HashSet<>();
            for (ClassDescriptionType classDescriptionType : classDescriptionBag.getClassDescription()) {
                logger.debug("Class number: " + classDescriptionType.getClassNumber());
                // check if there is DescriptionText
                boolean hasGoodsServicesDescriptionText = hasDescriptionText(
                    classDescriptionType.getGoodsServicesDescriptionText());
                GoodService goodsService = null;

                // SUC 2.1 BR#7: case 3
                if (hasGoodsServicesDescriptionText) {
                    goodsService = this.createGoodsOrServices(application, applicationLanguage, classDescriptionType,
                        classificationVersion, false, notificationTypes, validateOnly);
                } else {
                    // SUC 2.1 BR#7: case 2
                    goodsService = this.findGoodsServices(application, classDescriptionType);
                }
                if (null == goodsService) {
                    // handle Limitation list case
                    if (application.getLimitationListCode() == 1) {
                        matchedGS = false;
                        continue;
                    } else {
                        logger.error("Error finding goodsService for madridDesignation in createClaims.");
                        throwMTSServiceFault("mts.designation.gs.claims", ExceptionReasonCode.DESIGNATION_ERROR);
                    }
                } else {
                    matchedGS = true;
                }
                GoodServiceClaim goodsServiceClaim = createGoodServiceClaim(application,
                    goodsOrService(classDescriptionType.getClassNumber()), claim.getClaimNumber(),
                    goodsService.getNumber());

                goodServiceClaims.add(goodsServiceClaim);
                goodsServiceClaim.setClaim(claim);
                if (!validateOnly) {
                    goodsServicesClaimDao.saveGoodServiceClaim(goodsServiceClaim);
                }

            }
            if (!matchedGS) {
                logger.error(
                    "Error: the Nice Class Code is equal to the Nice Class Code from the priorityPartialGoodsServices for madridDesignation in createClaims.");
                throwMTSServiceFault("mts.designation.gs.claims", ExceptionReasonCode.DESIGNATION_ERROR);
            }

            if (!goodServiceClaims.isEmpty()) {
                claim.setGoodServiceClaims(goodServiceClaims);
                if (!validateOnly) {
                    claimDao.saveClaim(claim);
                }
            }

        }
    }

    // SUC 2.1, BR# 7
    private boolean hasDescriptionText(List<OrderedTextType> textList) {

        if ((null == textList) || textList.isEmpty()) {
            return false;
        } else {
            for (LocalizedTextType localizedTextType : textList) {
                if ((null == localizedTextType.getValue()) || localizedTextType.getValue().isEmpty()) {
                    return false;
                }
            }
        }

        return true;
    }

    // SUC 2.1, BR# 7
    private GoodService findGoodsServices(Application application, ClassDescriptionType classDescription) {
        GoodService goodsService = null;
        Set<GoodService> goodServiceSet = application.getGoodsServices();
        Iterator<GoodService> goodServiceIter = goodServiceSet.iterator();
        while (goodServiceIter.hasNext()) {
            GoodService goodService = goodServiceIter.next();

            if (goodService.getNiceClassCode().intValue() == Integer.valueOf(classDescription.getClassNumber())) {
                return goodService;
            }
        }

        return goodsService;
    }

    private GoodServiceClaim createGoodServiceClaim(Application application, GoodServiceType goodServiceType,
                                                    Integer claimNumber, Integer goodsServiceNumber) {

        GoodServiceClaim goodsServiceClaim = new GoodServiceClaim();

        goodsServiceClaim.setFileNumber(application.getFileNumber());
        goodsServiceClaim.setExtensionCounter(application.getExtensionCounter());
        goodsServiceClaim.setType(goodServiceType.getValue());
        goodsServiceClaim.setClaimType(ClaimType.PRIORITY_FILING.getValue());
        goodsServiceClaim.setNumber(goodsServiceNumber);
        goodsServiceClaim.setClaimNumber(claimNumber);

        return goodsServiceClaim;

    }

    private void createApplicationText(MadridDesignationType madridDesignation, Application application,
                                       LanguageType applicationLanguage)
        throws MTSServiceFault {

        Set<ApplicationText> applicationTexts = new HashSet<>();

        // Trademark Description
        if (null != madridDesignation.getMarkDescriptionTextBag()) {
            applicationTexts.addAll(buildApplicationText(application,
                madridDesignation.getMarkDescriptionTextBag().getMarkDescriptionText(),
                ApplicationTextType.DESCRIPTION_OF_MARK, applicationLanguage, false));
        }
        if (null != madridDesignation.getMarkImageColourClaimedTextBag()
            && null != madridDesignation.getMarkImageColourPartClaimedTextBag()) {// its valid, but should not
                                                                                  // happen
            applicationTexts.addAll(buildApplicationText(application, getMergeredLists(madridDesignation),
                ApplicationTextType.COLOUR_CLAIM, applicationLanguage, true));

        } else {
            if (null != madridDesignation.getMarkImageColourClaimedTextBag()) {// Color Claim Text
                applicationTexts.addAll(buildApplicationText(application,
                    madridDesignation.getMarkImageColourClaimedTextBag().getMarkImageColourClaimedText(),
                    ApplicationTextType.COLOUR_CLAIM, applicationLanguage, false));
            } else if (null != madridDesignation.getMarkImageColourPartClaimedTextBag()) { // Color Part Claim Text
                applicationTexts.addAll(buildApplicationText(application,
                    madridDesignation.getMarkImageColourPartClaimedTextBag().getMarkImageColourPartClaimedText(),
                    ApplicationTextType.COLOUR_CLAIM, applicationLanguage, false));
            }
        }
        // Disclaimer Text
        if (null != madridDesignation.getMarkDisclaimerBag()) {

            applicationTexts.addAll(
                buildApplicationText(application, madridDesignation.getMarkDisclaimerBag().getMarkDisclaimerText(),
                    ApplicationTextType.DISCLAIMER, applicationLanguage, false));

        }
        // Translation Text
        if (null != madridDesignation.getMarkTranslationTextBag()) {

            applicationTexts.addAll(buildApplicationText(application,
                madridDesignation.getMarkTranslationTextBag().getMarkTranslationText(),
                ApplicationTextType.FOREIGN_CHARACTER_TRANSLATION, applicationLanguage, false));
        }
        // Transliteration Text
        if (null != madridDesignation.getMarkTransliteration()) {
            // add a check
            if (applicationLanguage == LanguageType.FRENCH) {
                applicationTexts.add(createApplicationText(application.getFileNumber(),
                    application.getExtensionCounter(), ApplicationTextType.FOREIGN_CHARACTER_TRANSLITERATION,
                    madridDesignation.getMarkTransliteration().getValue(), ISOLanguageCodeType.FR,
                    applicationLanguage));

            } else {
                applicationTexts.add(createApplicationText(application.getFileNumber(),
                    application.getExtensionCounter(), ApplicationTextType.FOREIGN_CHARACTER_TRANSLITERATION,
                    madridDesignation.getMarkTransliteration().getValue(), ISOLanguageCodeType.EN,
                    applicationLanguage));
            }
        }
        for (ApplicationText applicationText : applicationTexts) {
            applicationTextDao.saveApplicationText(applicationText);
        }
        application.setApplicationTexts(applicationTexts);
    }

    private Set<ApplicationText> buildApplicationText(Application application,
                                                      List<? extends LocalizedTextType> textList,
                                                      ApplicationTextType applicationTextType,
                                                      LanguageType applicationLanguage, boolean isMergered) {

        StringBuilder textEnglish = new StringBuilder();
        StringBuilder textFrench = new StringBuilder();
        Set<ApplicationText> applicationTexts = new HashSet<>();

        for (LocalizedTextType orderedTextType : textList) {

            if (null != orderedTextType.getLanguageCode()) {
                if (orderedTextType.getLanguageCode().equals(ISOLanguageCodeType.EN.value())) {
                    textEnglish.append(orderedTextType.getValue());
                    if (isMergered) {
                        textEnglish.append(" ");
                    }
                } else if (orderedTextType.getLanguageCode().equals(ISOLanguageCodeType.FR.value())) {
                    textFrench.append(orderedTextType.getValue());
                    if (isMergered) {
                        textFrench.append(" ");
                    }
                }
            } else {
                textEnglish.append(orderedTextType.getValue());
            }
        }

        if (textEnglish.length() > 0) {

            applicationTexts.add(createApplicationText(application.getFileNumber(), application.getExtensionCounter(),
                applicationTextType, textEnglish.toString().trim(), ISOLanguageCodeType.EN, applicationLanguage));
        }
        if (textFrench.length() > 0) {

            applicationTexts.add(createApplicationText(application.getFileNumber(), application.getExtensionCounter(),
                applicationTextType, textFrench.toString().trim(), ISOLanguageCodeType.FR, applicationLanguage));
        }
        return applicationTexts;
    }

    private ApplicationText createApplicationText(Integer fileNumber, Integer extensionCounter,
                                                  ApplicationTextType applicationTextType, String text,
                                                  ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        ApplicationText applicationText = new ApplicationText();
        applicationText.setFileNumber(fileNumber);
        applicationText.setExtensionCounter(extensionCounter);
        applicationText.setLanguage(this.getAppTextLanguageIndicator(textLanguage, applicationLanguage));
        applicationText.setModifiedTimestamp(new Date());
        applicationText.setText(text);
        applicationText.setTextType(applicationTextType.getValue());
        applicationText.setOriginalInd(this.getAppTextOriginalIndicator(textLanguage, applicationLanguage));

        return applicationText;
    }

    private void createTrademarks(MadridDesignationType madridDesignation, Application application,
                                  LanguageType applicationLanguage, Map<ApplicationDto, UserTaskType> notificationTypes,
                                  boolean validateOnly)
        throws MTSServiceFault {
        TradeMark trademark = new TradeMark();
        if (!validateOnly) {
            trademark.setFileNumber(application.getFileNumber());
        }

        if (application.getTradeMarkType() == TradeMarkType.STANDARD_CHARACTERS.getValue()
            && madridDesignation.getMarkVerbalElementText() != null) {

            trademark.setText(madridDesignation.getMarkVerbalElementText().getValue());
        } else {
            if (null != madridDesignation.getMarkSignificantVerbalElementText()) {
                trademark.setText(madridDesignation.getMarkSignificantVerbalElementText().getValue());

            } else if (madridDesignation.getMarkVerbalElementText() != null) {

                trademark.setText(madridDesignation.getMarkVerbalElementText().getValue());

            } else {
                // use message.properties to store key-value
                trademark.setText(getMessageText("mts.md.tm.text", applicationLanguage));

                // create notification for review
                ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
                notificationTypes.put(applicationDto, UserTaskType.REVIEW_TRADEMARK);
            }
        }

        Set<FigurativeElement> figurativeElements = createFigurativeElements(madridDesignation, application,
            validateOnly);
        if (CollectionUtils.isNotEmpty(figurativeElements)) {
            if (validateOnly) {
                if (!checkDuplicateElements(figurativeElements).isEmpty()) {
                    for (String msg : checkDuplicateElements(figurativeElements)) {
                        logger.error("Duplication element(s) foun: " + msg);
                    }
                    throwMTSServiceFault("mts.madrid.mark.duplicate.found", ExceptionReasonCode.DUPLICATE_DESIGNATION);
                }
            } else {
                trademark.setFigurativeElements(figurativeElements);
            }
        }

        if (!validateOnly) {
            trademarkDao.saveTrademark(trademark);
            for (FigurativeElement figurativeElement : figurativeElements) {
                figurativeElementsDao.saveFigurativeElement(figurativeElement);
            }

            application.setTrademarks(trademark);
        }
    }

    private Set<FigurativeElement> createFigurativeElements(MadridDesignationType madridDesignation,
                                                            Application application, boolean validateOnly) {

        Set<FigurativeElement> figurativeElements = new HashSet<>();

        FigurativeElementClassificationBagType figureBag = null;
        if (null != madridDesignation.getMarkImageClassification()) {
            figureBag = madridDesignation.getMarkImageClassification().getFigurativeElementClassificationBag();
            List<Serializable> figureList = figureBag
                .getViennaClassificationBagOrNationalFigurativeElementClassificationBag();

            int groupId = 1;
            for (Object object : figureList) {

                if (object instanceof ViennaClassificationBagType) {
                    ViennaClassificationBagType viennaClassification = (ViennaClassificationBagType) object;

                    List<Serializable> viennaList = viennaClassification
                        .getViennaClassificationOrViennaClassificationText();
                    int sequenceNumber = 1;

                    for (Object viennaObject : viennaList) {

                        if (viennaObject instanceof ViennaClassificationType) {
                            FigurativeElement figurativeElement = new FigurativeElement();
                            ViennaClassificationType viennaClassificationType = (ViennaClassificationType) viennaObject;

                            if (StringUtils.isBlank(viennaClassificationType.getViennaCategory())) {
                                logger.error("No Vienna Category. skipping this record");
                                continue;
                            }

                            // if (StringUtils.isBlank(viennaClassificationType.getViennaSection())) {
                            // logger.error("No Vienna Section. skipping this record");
                            // continue;
                            // }

                            if (StringUtils.isBlank(viennaClassificationType.getViennaDivision())) {
                                logger.error("No Vienna Division. skipping this record");
                                continue;
                            }

                            if (application.getTradeMarkType() == TradeMarkType.STANDARD_CHARACTERS.getValue()
                                && viennaClassificationType.getViennaCategory().equals(VIENNA_CATEGORY)
                                && viennaClassificationType.getViennaDivision().equals(VIENNA_DIVISION)) {

                                logger.error(
                                    "Vienna Category value is 28 and Vienna Division value is 11. skipping this record");
                                continue;
                            }

                            if (!validateOnly) {
                                figurativeElement.setFileNumber(application.getFileNumber());
                            }

                            // TODO note. table columns Integer / xml type is String....
                            figurativeElement
                                .setCategoryCode(Integer.valueOf(viennaClassificationType.getViennaCategory()));
                            figurativeElement
                                .setDivisionCode(Integer.valueOf(viennaClassificationType.getViennaDivision()));

                            // ViennaSection is not mandatory from wipo, but it is in Intrepid.
                            // if there is no value, set it to 0
                            if (StringUtils.isBlank(viennaClassificationType.getViennaSection())) {
                                figurativeElement.setSectionCode(0);

                            } else {
                                figurativeElement
                                    .setSectionCode(Integer.valueOf(viennaClassificationType.getViennaSection()));
                            }

                            figurativeElement.setGroupId(groupId);
                            figurativeElement.setSequenceNumber(sequenceNumber);

                            figurativeElements.add(figurativeElement);

                            sequenceNumber++;
                        }
                    }
                }
                groupId++;
            }

        }
        return figurativeElements;

    }

    private void createPhysicalFiles(Application application) {

        PhysicalFiles physicalFiles = new PhysicalFiles();

        physicalFiles.setLocationAuthorityId(SectionAuthority.FORMALITIES.name());
        physicalFiles.setFileNumber(application.getFileNumber());
        physicalFiles.setFileType(FileType.TRADE_MARK.getValue());

        physicalFilesDao.savePhysicalFiles(physicalFiles);

    }

    /*
     * private void createMail(MadridDesignationType madridDesignation, Application application, IntlIrTranDto
     * intlIrTran) throws MTSServiceFault {
     *
     * boolean mailCreated = false;
     *
     * try { List<IntlAtchmtDto> attachmentList = intlIrTran.getIntlAtchmtDtoList(); if
     * (CollectionUtils.isNotEmpty(attachmentList)) {
     *
     * String fileNamePrefixKey = null; TransactionCategory transactionCategory = (madridDesignation
     * .getMadridDesignationCategory() == MadridDesignationCategoryType.REGISTRATION ?
     * TransactionCategory.MD_REGISTRATION : TransactionCategory.MD_SUBSEQUENT_DESIGNATION);
     *
     * if (NfsFileName.transactionFilenameMap.containsKey(transactionCategory)) { fileNamePrefixKey =
     * NfsFileName.transactionFilenameMap.get(transactionCategory); } else {
     * throwMTSServiceFault("mts.nfs.filename.map.transaction.missing", ExceptionReasonCode.RETRYABLE_ERROR); }
     *
     * List<NfsFilenameDto> nfsFilenameList = setNFSFilename(attachmentList, fileNamePrefixKey,
     * BigDecimal.valueOf(application.getFileNumber()), application.getExtensionCounter().toString());
     *
     * for (NfsFilenameDto nfsFilenameDto : nfsFilenameList) {
     *
     * if (nfsFilenameDto.getFileType() == NfsFileType.TRANSACTION_REPRESENTATION) { Mail mail =
     * createMailModel(madridDesignation, application, intlIrTran);
     *
     * mail.setAttachmentFileName(nfsFilenameDto.getFileName());
     *
     * mailDao.saveMail(mail); mailCreated = true; break; } } }
     *
     * if (!mailCreated) { mailDao.saveMail(createMailModel(madridDesignation, application, intlIrTran)); }
     *
     * } catch (Exception e) { logger.error("Error creating MAIL for madridDesignation:", e);
     * throwMTSServiceFault("mts.processing.designation", ExceptionReasonCode.DESIGNATION_ERROR); }
     *
     * }
     */

    /*
     * private Mail createMailModel(MadridDesignationType madridDesignation, Application application, IntlIrTranDto
     * intlIrTran) {
     *
     * Mail mail = new Mail();
     *
     * mail.setAuthorityId(SectionAuthority.FORMALITIES.name()); mail.setFileNumber(application.getFileNumber());
     * mail.setFileType(FileType.TRADE_MARK.getValue()); mail.setMailTimestamp(new Date()); logger.debug(
     * "create mail record with timestamp: " + mail.getMailTimestamp().toString()); //
     * mail.setMailRoomDate(intlIrTran.getIntlPkg().getCreatedTmstmp());
     * mail.setMailAttachedInd(MAIL_INDICATOR_AUTOMATED); // processing type 'Auto'
     * mail.setMailMode(MailModeType.ELECTRONIC.getValue()); if (madridDesignation.getMadridDesignationCategory() ==
     * MadridDesignationCategoryType.REGISTRATION) {
     * mail.setMailType(MailType.MADRID_DESIGNATION_REGISTRATION.getValue()); } else {
     * mail.setMailType(MailType.MADRID_DESIGNATION_SUBSEQUENT_DESIGNATION.getValue()); } try { Date mailRoomDate =
     * dateFormat.parse(madridDesignation.getRecordEffectiveDate()); mail.setMailRoomDate(mailRoomDate); } catch
     * (ParseException pe) { logger.error("Could not parse mail room date: " +
     * madridDesignation.getRecordEffectiveDate()); }
     *
     * mail.setProcessedByAuthorityID(SectionAuthority.MADRID.name()); mail.setProcessedDate(new Date()); return mail; }
     */

    private void createActions(MadridDesignationType madridDesignation, Application application) {

        actionDao.saveAction(createAction(madridDesignation, application, ActionCode.CREATED,
            SectionAuthority.MADRID.name(), EMPTY_ADDITIONAL_INFO));
        actionDao.saveAction(createAction(madridDesignation, application, ActionCode.APPLICATION_FILED,
            SectionAuthority.MADRID.name(), madridDesignation.getMadridDesignationCategory().value()));
        actionDao.saveAction(createAction(madridDesignation, application, ActionCode.FORMALIZED,
            SectionAuthority.MADRID.name(), EMPTY_ADDITIONAL_INFO));
        actionDao.saveAction(createAction(madridDesignation, application, ActionCode.MADRID_DESIGNATION_NOTIFICATION,
            SectionAuthority.MADRID.name(), EMPTY_ADDITIONAL_INFO));
        actionDao.saveAction(createAction(madridDesignation, application, ActionCode.INTERNATIONAL_REGISTRATION,
            SectionAuthority.MADRID.name(), EMPTY_ADDITIONAL_INFO));
        // create action for IRRenewed only for subsequent designation
        if (madridDesignation.getRenewalDate() != null && madridDesignation.getMadridDesignationCategory().name()
            .equalsIgnoreCase(TransactionCategory.MD_SUBSEQUENT_DESIGNATION.getWipoCategoryName())) {
            actionDao.saveAction(createAction(madridDesignation, application, ActionCode.IR_RENEWED,
                SectionAuthority.MADRID.name(), EMPTY_ADDITIONAL_INFO));
        }

        actionDao.saveAction(createAction(madridDesignation, application, ActionCode.FILING_FEE_PAYMENT_DATE,
            SectionAuthority.MADRID.name(), EMPTY_ADDITIONAL_INFO));

    }

    private Action createAction(MadridDesignationType madridDesignation, Application application, ActionCode actionCode,
                                String authorityId, String additionalInfo) {
        Action action = new Action();

        action.setApplication(application);
        action.setFileNumber(application.getFileNumber());
        action.setExtensionCounter(application.getExtensionCounter());
        action.setActionCode(actionCode.getValue());
        action.setAuthorityId(authorityId);
        action.setAdditionalInfo(additionalInfo);

        // set dates based on action code
        setActionDate(action, actionCode, madridDesignation);

        if (actionCode == ActionCode.IR_RENEWED) {
            action.setAdditionalInfo("DP:" + getFormattedSystemDate());
        }
        application.getActions().add(action);
        return action;
    }

    private void setActionDate(Action action, ActionCode actionCode, MadridDesignationType madridDesignation) {

        logger.debug("ActionCode: " + actionCode);

        action.setActionDate(new Date());

        if (actionCode == ActionCode.APPLICATION_FILED) {
            try {
                action.setActionDate(DateFormats.getISOSDF().parse(madridDesignation.getRecordEffectiveDate()));
            } catch (ParseException e) {
                logger.error("Could not parse record effective date: " + madridDesignation.getRecordEffectiveDate());
            }
        } else if (actionCode == ActionCode.INTERNATIONAL_REGISTRATION) {
            try {
                String intlRegDateStr = madridDesignation.getInternationalRegistrationDate();
                if (intlRegDateStr != null) {
                    action.setActionDate(DateFormats.getISOSDF().parse(intlRegDateStr));
                    action.setResponseDate(DateUtils.addYears(DateFormats.getISOSDF().parse(intlRegDateStr), 10));
                }

            } catch (ParseException e) {
                logger.error("Could not parse international registration effective date: "
                    + madridDesignation.getInternationalRegistrationDate());
            }
        } else if (actionCode == ActionCode.MADRID_DESIGNATION_NOTIFICATION) {

            try {
                action.setActionDate(DateFormats.getISOSDF().parse(madridDesignation.getRecordNotificationDate()));

                Date responseDate = DateUtils.addMonths(action.getActionDate(), 18);

                action.setResponseDate(responseDate);
            } catch (ParseException e) {
                logger.error("Could not parse madrid designation notification date: "
                    + madridDesignation.getRecordNotificationDate());
            }

        } else if (actionCode == ActionCode.IR_RENEWED) {
            try {
                action.setActionDate(DateFormats.getISOSDF().parse(madridDesignation.getRenewalDate()));
                action.setResponseDate(DateFormats.getISOSDF().parse(madridDesignation.getExpiryDate()));
            } catch (ParseException e) {
                logger.error("Could not parse madrid renewal date: " + madridDesignation.getRenewalDate()
                    + ", expiry date: " + madridDesignation.getExpiryDate());
            }
        } else if (actionCode == ActionCode.FILING_FEE_PAYMENT_DATE) {
            try {
                action.setActionDate(DateFormats.getISOSDF().parse(madridDesignation.getFeeCalculationDate()));
            } catch (ParseException e) {
                logger.error("Could not parse madrid desgination fee calculation date: "
                    + madridDesignation.getFeeCalculationDate() + ", fee calculation date: "
                    + madridDesignation.getFeeCalculationDate());
            }
        }
    }

    private void createProcessActions(Application application, String additionalInfo,
                                      MadridDesignationType madridDesignation) {

        processActionsDao.saveProcessActions(
            createProcessAction(application, ProcessActionsType.FILE_COVER_LABEL, SectionAuthority.MADRID.name()));

        if (madridDesignation.getNotificationLanguage() == ISOLanguageCodeType.ES) { // Spanish
            processActionsDao.saveProcessActions(createProcessAction(application,
                ProcessActionsType.ACKNOWLEDGEMENT_NOTICE, SectionAuthority.MADRID.name(), LANGUAGE_TYPE_SPANISH));
        } else {
            processActionsDao.saveProcessActions(createProcessAction(application,
                ProcessActionsType.ACKNOWLEDGEMENT_NOTICE, SectionAuthority.MADRID.name()));
        }
        processActionsDao.saveProcessActions(
            createProcessAction(application, ProcessActionsType.CLIENT_PROOF_SHEET, SectionAuthority.MADRID.name()));
        processActionsDao.saveProcessActions(
            createProcessAction(application, ProcessActionsType.RESEARCH_SHEET, SectionAuthority.MADRID.name()));
        if (additionalInfo != null && !additionalInfo.isEmpty()) {
            processActionsDao.saveProcessActions(createProcessAction(application,
                ProcessActionsType.PRINT_NOTIFICATION_OF_DESIGNATION, SectionAuthority.MADRID.name(), additionalInfo));
        }

        // resolve TMHOTFIX-86
        processActionsDao.saveProcessActions(createProcessAction(application,
            ProcessActionsType.EXTRACT_APP_FOR_INDEX_HEADING, SectionAuthority.MADRID.name()));

    }

    private ArrayList<LocalizedTextType> getMergeredLists(MadridDesignationType madridDesignation) {
        ArrayList<LocalizedTextType> mergedList = new ArrayList<LocalizedTextType>();

        List<? extends LocalizedTextType> colorClaims = madridDesignation.getMarkImageColourClaimedTextBag()
            .getMarkImageColourClaimedText();
        List<? extends LocalizedTextType> colorPartClaims = madridDesignation.getMarkImageColourPartClaimedTextBag()
            .getMarkImageColourPartClaimedText();

        for (LocalizedTextType text : colorClaims) {
            mergedList.add(text);
        }

        for (LocalizedTextType text : colorPartClaims) {
            mergedList.add(text);
        }

        return mergedList;
    }

    private void setApplicationTradeMarkType(MadridDesignationType madridDesignation, Application application) {

        Iterator<MarkFeatureCategoryType> iterator = madridDesignation.getMarkFeatureCategoryBag()
            .getMarkFeatureCategory().iterator();

        while (iterator.hasNext()) {
            MarkFeatureCategoryType categoryType = iterator.next();

            logger.debug("categoryType: " + categoryType);
            if (categoryType == MarkFeatureCategoryType.WORD) {
                if (madridDesignation.isMarkStandardCharacterIndicator() != null) {
                    // isMarkStandardCharacterIndicator is true, more check...
                    if (madridDesignation.isMarkStandardCharacterIndicator()) {
                        setTradeMarkTypeWhenMSCI(madridDesignation, application);

                        if (application.getTradeMarkType().intValue() == TradeMarkType.DESIGN.getValue()) {
                            application.setDesignSampleFiledInd(1);
                        }
                    } else { // isMarkStandardCharacterIndicator is false
                        application.setTradeMarkType(TradeMarkType.DESIGN.getValue());
                        application.setDesignSampleFiledInd(1);
                    }
                } else {
                    application.setTradeMarkType(TradeMarkType.DESIGN.getValue());
                    application.setDesignSampleFiledInd(1);
                }
            } else {
                application.setTradeMarkType(
                    FeatureCategoryTrademarkType.valueOf(categoryType.name()).getTrademark().getValue());
                application.setDesignSampleFiledInd(1);

                break;
            }
            logger.debug("TradeMarkType: " + application.getTradeMarkType());
        }
    }

    private void setTradeMarkTypeWhenMSCI(MadridDesignationType madridDesignation, Application application) {
        if (((madridDesignation.getMarkDescriptionTextBag() != null
            || madridDesignation.getMarkImageColourClaimedTextBag() != null
            || madridDesignation.getMarkImageColourPartClaimedTextBag() != null))
            && madridDesignation.getMarkImageClassification() == null) {

            application.setTradeMarkType(TradeMarkType.DESIGN.getValue());

        } else if (((madridDesignation.getMarkDescriptionTextBag() != null
            || madridDesignation.getMarkImageColourClaimedTextBag() != null
            || madridDesignation.getMarkImageColourPartClaimedTextBag() != null))
            && !checkViennaClassificationIs28And11(madridDesignation)) {

            application.setTradeMarkType(TradeMarkType.DESIGN.getValue());

        } else if ((madridDesignation.getMarkDescriptionTextBag() == null
            && madridDesignation.getMarkImageColourClaimedTextBag() == null
            && madridDesignation.getMarkImageColourPartClaimedTextBag() == null)
            && !checkViennaClassificationIs28And11(madridDesignation)) {

            application.setTradeMarkType(TradeMarkType.STANDARD_CHARACTERS.getValue());

        } else {
            application.setTradeMarkType(TradeMarkType.STANDARD_CHARACTERS.getValue());
        }
    }

    private boolean checkViennaClassificationIs28And11(MadridDesignationType madridDesignation) {

        boolean is28_And_11 = false;
        if (null != madridDesignation.getMarkImageClassification()) {
            FigurativeElementClassificationBagType figureBag = madridDesignation.getMarkImageClassification()
                .getFigurativeElementClassificationBag();
            List<Serializable> figureList = figureBag
                .getViennaClassificationBagOrNationalFigurativeElementClassificationBag();

            for (Object object : figureList) {
                if (object instanceof ViennaClassificationBagType) {
                    ViennaClassificationBagType viennaClassification = (ViennaClassificationBagType) object;
                    List<Serializable> viennaList = viennaClassification
                        .getViennaClassificationOrViennaClassificationText();

                    if (CollectionUtils.isNotEmpty(viennaList)) {
                        if (viennaList.size() == 1) {
                            for (Object viennaObject : viennaList) {
                                if (viennaObject instanceof ViennaClassificationType) {
                                    ViennaClassificationType viennaClassificationType = (ViennaClassificationType) viennaObject;

                                    String viennaCategory = viennaClassificationType.getViennaCategory();
                                    String viennaDivision = viennaClassificationType.getViennaDivision();
                                    if (!StringUtils.isBlank(viennaCategory) && !StringUtils.isBlank(viennaDivision)) {
                                        if (viennaCategory.equals(VIENNA_CATEGORY)
                                            && viennaDivision.equals(VIENNA_DIVISION)) { // 28.11

                                            is28_And_11 = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return is28_And_11;
    }

    @Override
    public String getServiceName() {
        return "MadridDesignationService";
    }

}
