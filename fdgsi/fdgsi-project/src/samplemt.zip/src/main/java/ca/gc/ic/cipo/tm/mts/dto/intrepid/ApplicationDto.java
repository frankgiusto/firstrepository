package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;

public class ApplicationDto implements Serializable {

    private static final long serialVersionUID = 7882795806677138456L;

    private Integer fileNumber;

    private String extensionCounter;

    private Integer statusCode;

    private Integer taskStatusCode;

    private String irNumber;

    private String wipoReferenceNumber;

    private String officeType;

    private String additionalInfo;

    private String intlFilingRecordId;

    private boolean courtesyLetterRequired;

    private Integer tradeMarkType;

    private String address;

    /**
     * The authority id. In some cases, we will not know who to assign the user task too until the transaction is
     * processed. In this situation, authorityId will be populated.
     */
    private String authorityId;

    public Integer getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(Integer fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(String extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public String getIrNumber() {
        return irNumber;
    }

    public void setIrNumber(String irNumber) {
        this.irNumber = irNumber;
    }

    public String getIntlFilingRecordId() {
        return intlFilingRecordId;
    }

    public void setIntlFilingRecordId(String intlFilingRecordId) {
        this.intlFilingRecordId = intlFilingRecordId;
    }

    public String getWipoReferenceNumber() {
        return wipoReferenceNumber;
    }

    public void setWipoReferenceNumber(String wipoReferenceNumber) {
        this.wipoReferenceNumber = wipoReferenceNumber;
    }

    public String getOfficeType() {
        return officeType;
    }

    public void setOfficeType(String officeType) {
        this.officeType = officeType;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getAuthorityId() {
        return authorityId;
    }

    public void setAuthorityId(String authorityId) {
        this.authorityId = authorityId;
    }

    public boolean isCourtesyLetterRequired() {
        return courtesyLetterRequired;
    }

    public void setCourtesyLetterRequired(boolean courtesyLetterRequired) {
        this.courtesyLetterRequired = courtesyLetterRequired;
    }

    public Integer getTaskStatusCode() {
        return taskStatusCode;
    }

    public void setTaskStatusCode(Integer taskStatusCode) {
        this.taskStatusCode = taskStatusCode;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Integer getTradeMarkType() {
        return tradeMarkType;
    }

    public void setTradeMarkType(Integer tradeMarkType) {
        this.tradeMarkType = tradeMarkType;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
