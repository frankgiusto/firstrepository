package ca.gc.ic.cipo.tm.mts.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.common.madrid.AddressLineTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType;
import _int.wipo.standards.xmlschema.st96.common.madrid.RepresentativeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFileTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.InterestedPartyDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.RepresentativeAddressDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.NfsFileName;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.CourtesyLetter;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridCourtesyLetter;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IProcessActionsService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.tirs.common.TMInfoRetrievalCommonServicePortType;
import ca.gc.ic.cipo.tm.tirs.common.TrademarkInfoRetrievalCommonServiceFactory;
import ca.gc.ic.cipo.xmlschema.common.AgentAdvancedSearchCriterionType;
import ca.gc.ic.cipo.xmlschema.common.CitySearchCriterionType;
import ca.gc.ic.cipo.xmlschema.common.NameOrEntitySearchCriterionType;
import ca.gc.ic.cipo.xmlschema.common.SearchMethodType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.AgentBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.AgentType;

@Service
public class CourtesyLetterService extends MadridTransactionService implements ICourtesyLetterService {

    private static Logger logger = Logger.getLogger(MadridTransactionService.class.getName());

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IProcessActionsService processActionsService;

    @Value("#{environment['mts.reporting.service.host.name']}")
    private String reportServiceHost;

    @Value("#{environment['mts.rgs.polling.attempts']}")
    private Integer pollingAttempts;

    @Value("#{environment['mts.ws.common.temp.folder']}")
    private String commonTempFolder;

    @Value("#{environment['mts.tm.information.retrieval.services.host.name']}")
    private String tmirServiceHost;

    private String pdfFilePathName;

    protected final static HashMap<String, String> pdfEnFrDate;

    static {
        pdfEnFrDate = new HashMap<String, String>();
        pdfEnFrDate.put("01", "janv/Jan");
        pdfEnFrDate.put("02", "fév/Feb");
        pdfEnFrDate.put("03", "mars/Mar");
        pdfEnFrDate.put("04", "avr/Apr");
        pdfEnFrDate.put("05", "mai/May");
        pdfEnFrDate.put("06", "juin/Jun");
        pdfEnFrDate.put("07", "juil/Jul");
        pdfEnFrDate.put("08", "août/Aug");
        pdfEnFrDate.put("09", "sept/Sep");
        pdfEnFrDate.put("10", "oct/Oct");
        pdfEnFrDate.put("11", "nov/Nov");
        pdfEnFrDate.put("12", "déc/Dec");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void processCourtesyLetter(IntlIrTranDto intlIrTransaction, Map<ApplicationDto, UserTaskType> notifications,
                                      TransactionCategory transactionCategory)
        throws CIPOServiceFault {

        if (MapUtils.isEmpty(notifications)) {
            return;
        }
        try {
            // boolean isCourtesyLetterRequired = false;
            for (Map.Entry<ApplicationDto, UserTaskType> entry : notifications.entrySet()) {
                ApplicationDto appDto = entry.getKey();
                UserTaskType ut = entry.getValue();
                if (appDto.isCourtesyLetterRequired() && ut == UserTaskType.REPRESENTATIVE_COURTESY_LETTER) {
                    // isCourtesyLetterRequired = true;

                    // set file name prefix
                    String fileNamePrefixKey = NfsFileName.COURTESY_LETTER_PREFIX;

                    // create PDF for courtesy letter and new process action
                    processCourtesyLetterAndProcessAction(intlIrTransaction, appDto, fileNamePrefixKey);
                }
            }
        } catch (Exception e) {
            logger.error("Error in submitRGSReport in processCourtesyLetter of IboundTransactionService ", e);
            throwCIPOFault(e);
        }
    }

    /**
     * Shared method with MadridConsoleService:
     *
     * 1. create a courtesy letter; 2. send it to IntrepidNfs; 3. create ProcessAction for it
     *
     * @param intlIrTransaction
     * @param notifications
     * @param transactionCategory
     * @throws Exception
     * @throws Throwable
     */

    @Override
    public void processCourtesyLetterAndProcessAction(IntlIrTranDto intlIrTransaction, ApplicationDto appDto,
                                                      String fileNamePrefixKey)
        throws Exception {

        logger.debug("createAndProcessCourtesyLetter for " + intlIrTransaction.getIrTranId());
        if (intlIrTransaction.getIrTranId() == null || appDto.getAddress() == null) {
            return;
        }

        MadridCourtesyLetter madridCourtesyLetter = setMadridCourtesyLetterProperties(intlIrTransaction, appDto,
            fileNamePrefixKey);

        if (madridCourtesyLetter == null) {
            return;
        }

        CourtesyLetter courtesyLetter = new CourtesyLetter();
        // Add the jobId to the response.
        // TODO remove reportId from officeToIb response as MWE will not be
        // doing the polling.
        MadridReportResponse madridReportResponse;
        try {
            madridReportResponse = courtesyLetter.generateReport(null, null, null, reportServiceHost,
                madridCourtesyLetter);

            logger.debug("submmited report request having job id: " + madridReportResponse.getJobId());

            monitorRGSReportCompletion(pollingAttempts, madridReportResponse, reportServiceHost);

            internationalService.generateReportNotification(madridReportResponse, intlIrTransaction.getIrTranId());

            internationalService.sendFileToIntrepidNFS(intlIrTransaction.getIrTranId(),
                BigDecimal.valueOf(appDto.getFileNumber()), appDto.getExtensionCounter(),
                NfsFileTypeDto.COURTESY_LETTER_ONLY);

            // create new process action in process_action table
            processActionsService.createProcessAction(
                createCourtestLetterProcessAction(intrepidCommonService.getApplicationModel(appDto.getFileNumber()),
                    ProcessActionsType.SENT_COURTESY_LETTER_TO_REPRESENTATIVE, SectionAuthority.MADRID.name(),
                    ("0/" + madridCourtesyLetter.getReportFileName())));

        } catch (Exception exception) {
            logger.error("Error in submitRGSReport", exception);
            throwCIPOFault(exception);
        }
    }

    private MadridCourtesyLetter setMadridCourtesyLetterProperties(IntlIrTranDto intlIrTransaction,
                                                                   ApplicationDto appDto, String fileNamePrefixKey)
        throws Exception {

        InterestedPartyDto interestedParty = intrepidCommonService.getInterestedParty(appDto);

        if (interestedParty == null) {
            return null;
        }

        // create new PDF
        MadridCourtesyLetter madridCourtesyLetter = new MadridCourtesyLetter();

        String tradeMarkText = intrepidCommonService.getTradeMark(appDto);

        StringBuffer nfsFileName = new StringBuffer();
        nfsFileName.append(fileNamePrefixKey).append(MtsStringUtil.UNDER_SCORE).append(intlIrTransaction.getIrTranId())
            .append(MtsStringUtil.UNDER_SCORE).append(getSystemDateInSec()).append(FILE_BASE_NAME)
            .append(MtsStringUtil.DOT).append(PDF_EXT);

        madridCourtesyLetter.setReportFileName(nfsFileName.toString());
        madridCourtesyLetter.setAddress(appDto.getAddress());
        madridCourtesyLetter.setApplicant(interestedParty.getInterestedPartyContactName()); // holder
        madridCourtesyLetter.setDate(formatPDFDateString(DateFormats.getISOSDF().format(new Date())));
        madridCourtesyLetter.setIrNumber(intlIrTransaction.getIntlRegNo());
        madridCourtesyLetter.setMyFileNumber(appDto.getFileNumber().toString());
        madridCourtesyLetter.setTradeMark(tradeMarkText);// text from TM
        String ref = interestedParty.getInterestedPartyReference() != null
            ? interestedParty.getInterestedPartyReference() : "";
        madridCourtesyLetter.setYourFileNumber(ref);// ref from IP

        if ((commonTempFolder == null) || commonTempFolder.isEmpty()) {
            commonTempFolder = "/sharedata/cipo/ecomm/private/ws/tmp/";
        }

        madridCourtesyLetter.setImageFileName(null);
        madridCourtesyLetter.setImageFileStoredDir(null);

        pdfFilePathName = commonTempFolder + File.separator + "_RGSreport";
        Path path = Paths.get(pdfFilePathName);

        Files.createDirectories(path);

        OutputStream os = null;
        InputStream is = null;

        String imageFileName = null;
        try {
            List<IntlAtchmt> intlAtchmts = internationalService.getAtchmtListByTranId(intlIrTransaction.getIrTranId());
            for (IntlAtchmt intlAtchmt : intlAtchmts) {
                String ext = FilenameUtils.getExtension(intlAtchmt.getFileName().toLowerCase());
                if (ext.equalsIgnoreCase(PNG_EXT)) {
                    imageFileName = intlAtchmt.getFileName();
                    os = new FileOutputStream(new File(pdfFilePathName + File.separator + imageFileName));
                    if (intlAtchmt.getFileContent() != null) {
                        is = intlAtchmt.getFileContent().getBinaryStream();
                        if (is != null) {
                            // write content to file
                            IOUtils.copy(is, os);
                        }
                    }
                    madridCourtesyLetter.setImageList(setTradeMarkImage(commonTempFolder, pdfFilePathName));
                    break;
                }
            }
            madridCourtesyLetter.setImageFileName(imageFileName);
            madridCourtesyLetter.setImageFileStoredDir(pdfFilePathName);
        } catch (Exception e) {
            throw new Exception("Error to convert trademark design to file.", e);
        } finally {
            IOUtils.closeQuietly(os);
            IOUtils.closeQuietly(is);
        }

        return madridCourtesyLetter;

    }

    private List<InputStream> setTradeMarkImage(String tempFolder, String tempFileDir) throws Exception {

        List<InputStream> reproductionMarksZipList = new ArrayList<InputStream>();

        File imagesZip = null;

        try {
            imagesZip = zipTradeMarkImage(tempFolder, tempFileDir);
            if (imagesZip != null) {

                // Add the ZIP file to an array of streams for passing to RGS.
                reproductionMarksZipList.add(new FileInputStream(imagesZip));
            }

        } catch (Exception e) {
            logger.debug("Report service failed to create ZIP file: ", e);
        }

        return reproductionMarksZipList;
    }

    private File zipTradeMarkImage(String tempFolder, String tempFileDir) throws Exception {

        File zippedFile = new File(tempFolder + File.separator + "tradeMarkImage_.zip");

        FileOutputStream fileOutputStream = null;
        ZipOutputStream zipOutputStream = null;
        FileInputStream fileInputStream = null;
        try {
            fileOutputStream = new FileOutputStream(zippedFile);
            zipOutputStream = new ZipOutputStream(fileOutputStream);

            File markFileDir = new File(tempFileDir);
            File[] markFiles = markFileDir.listFiles();

            for (File markFile : markFiles) {
                zipOutputStream.putNextEntry(new ZipEntry(markFile.getName()));

                fileInputStream = new FileInputStream(markFile);
                byte[] buf = new byte[1024];
                int bytesRead = 0;

                while ((bytesRead = fileInputStream.read(buf)) > 0) {
                    zipOutputStream.write(buf, 0, bytesRead);
                }

                zipOutputStream.closeEntry();
                fileInputStream.close();
            }

        } finally {
            IOUtils.closeQuietly(zipOutputStream);
            IOUtils.closeQuietly(fileOutputStream);
            IOUtils.closeQuietly(fileInputStream);
        }

        return zippedFile;
    }

    private String formatPDFDateString(String strDate) {
        StringBuilder rtnValue = new StringBuilder();
        String _space = " ";
        String[] splitString = strDate.split("-");
        if (splitString.length == 3) {
            rtnValue.append(splitString[2]).append(_space).append(pdfEnFrDate.get(splitString[1])).append(_space);
            if (splitString[0].length() == 2) {
                rtnValue.append("20");
            }

            rtnValue.append(splitString[0]);
        }

        return rtnValue.toString();
    }

    /***********************************************
     * FOR COURTEST LETTER
     *******************************************************/
    /**
     * 1. To check if the country code is CA; if yes, 2. check if its an existing agent; if yes, get its AU_Number; if
     * not, 3. check the address size if exceeding the limits. if yes, set setCourtesyLetterRequired to true and set
     * UserTaskType.ADDRESS_SIZE_LIMIT_EXCEEDED; if not, set setCourtesyLetterRequired to true and set
     * UserTaskType.REPRESENTATIVE_COURTESY_LETTER.
     *
     * Shared method for MadridDesignation and other required category types
     *
     * @param transType
     * @param application
     * @param notificationTypes
     * @throws MTSServiceFault
     */
    @Override
    public int checkIsCourtesyLetterRequired(Object transType, Application application, LanguageType languageType,
                                             Map<ApplicationDto, UserTaskType> notificationTypes)
        throws MTSServiceFault {

        logger.debug("Transaction type: " + transType);
        RepresentativeAddressDto addressDto = new RepresentativeAddressDto();
        RepresentativeType representative = null;
        int arNum = 0;

        if (transType instanceof MadridDesignationType) {
            representative = ((MadridDesignationType) transType).getRepresentative();

        } else if (transType instanceof MadridPartialChangeOwnershipType) {
            representative = ((MadridPartialChangeOwnershipType) transType).getMadridDesignation().getRepresentative();

        } else if (transType instanceof MadridHolderRepresentativeChangeType) {
            representative = ((MadridHolderRepresentativeChangeType) transType).getRepresentative();
        }

        if (representative != null) {
            addressDto = getRepresentativeAddressDto(representative);

            addressDto.setFileNumber(BigDecimal.valueOf(application.getFileNumber()));
            addressDto.setExtensionCounter(application.getExtensionCounter().toString());

            if (addressDto.getCountryProvince() != null) {
                // check if the country is Canada
                if (checkCountryCanada(addressDto.getCountryProvince(), languageType)) {
                    // if Canada and then check if this representative is
                    // existing agent by using tmirServiceHost - searchAgentsByName()
                    AgentBagType rep = lookupAgentRes(addressDto);

                    if (!rep.getAgents().isEmpty()) {
                        // Yes, its existing agent and update INTERESTED_PARTIES table next
                        List<AgentType> agents = rep.getAgents();
                        for (AgentType t : agents) {
                            if (t.getName().getEntityName().trim().equals(addressDto.getRepresentativeName().trim())) {
                                arNum = t.getARNumber();
                                break;
                            }
                        }
                    } else {
                        // No agent found, check the size of address
                        checkAddressSize(addressDto, application, notificationTypes, representative);
                    }
                } else {
                    // Not Canada, check the size of address
                    checkAddressSize(addressDto, application, notificationTypes, representative);
                }
            }
        } else {
            logger.error("No representative found for application file number: " + application.getFileNumber());
        }

        return arNum;
    }

    private AgentBagType lookupAgentRes(RepresentativeAddressDto address) throws MTSServiceFault {

        AgentBagType agent = new AgentBagType();

        try {
            TMInfoRetrievalCommonServicePortType infoRetrievalClient = TrademarkInfoRetrievalCommonServiceFactory
                .createClient(tmirServiceHost);

            NameOrEntitySearchCriterionType name = new NameOrEntitySearchCriterionType();
            name.setLegalEntity(address.getRepresentativeName());
            name.setSearchMethod(SearchMethodType.CONTAINS);

            logger.debug("searchAgentsByName: " + name);

            // agent = infoRetrievalClient.searchAgentsByName(name);

            // TODO other API to search Agent
            AgentAdvancedSearchCriterionType searchType = new AgentAdvancedSearchCriterionType();
            searchType.setNameLegalEntity(name);

            CitySearchCriterionType city = new CitySearchCriterionType();
            String repAddr = null;
            if (!CollectionUtils.isEmpty(address.getRepresentativeAddress())) {
                repAddr = address.getRepresentativeAddress().get(0);
            }
            city.setCity(repAddr);
            // city.setCity(getCompleteAddress(address));
            city.setSearchMethod(SearchMethodType.CONTAINS);
            searchType.setCity(city);

            // searchType.setSearchOperator(SearchOperatorType.AND);
            agent = infoRetrievalClient.searchAgents(searchType);

            logger.debug("Found? " + agent.getAgents().size());

        } catch (Exception e) {
            logger.error("Error to call tmirServiceHost: " + e.getMessage());
            throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        return agent;
    }

    private RepresentativeAddressDto getRepresentativeAddressDto(RepresentativeType representative) {

        logger.debug("representative legal name: " + representative.getLegalEntityNameOrPartyIdentifierOrContact());

        StringBuilder nameBuffer = new StringBuilder();
        RepresentativeAddressDto representativeAddress = new RepresentativeAddressDto();

        ContactType contact = null;
        for (Object aType : representative.getLegalEntityNameOrPartyIdentifierOrContact()) {
            if (aType instanceof ContactType) {
                contact = (ContactType) aType;
                InterestedParty interestedParty = createInterestedPartyContact(contact);

                addNameToken(nameBuffer, interestedParty.getContact().getName());
            }
        }
        representativeAddress.setRepresentativeName(nameBuffer.toString());

        // Now Address. check all contacts for a postalAddress.
        for (Object aType : representative.getLegalEntityNameOrPartyIdentifierOrContact()) {
            if (aType instanceof ContactType) {
                contact = (ContactType) aType;

                createRepresentativeAddress(representativeAddress, contact);

                if (!CollectionUtils.isEmpty(representativeAddress.getRepresentativeAddress())) {
                    break;
                }
            }
        }
        return representativeAddress;
    }

    private void createRepresentativeAddress(RepresentativeAddressDto representativeAddress, ContactType wipoContact) {

        // Address, Postal Code, Country Code
        if (null != wipoContact.getPostalAddressBag()) {
            List<PostalAddressType> postalAddress = wipoContact.getPostalAddressBag().getPostalAddress();
            for (PostalAddressType address : postalAddress) {
                if (address.getPostalStructuredAddress().getCountryCode() != null) {
                    representativeAddress.setCountryProvince(address.getPostalStructuredAddress().getCountryCode());
                }
                if (address.getPostalStructuredAddress().getPostalCode() != null) {
                    representativeAddress.setZipPostalCode(address.getPostalStructuredAddress().getPostalCode());
                }
                if (address.getPostalStructuredAddress().getCityName() != null) {
                    representativeAddress.setCityName(address.getPostalStructuredAddress().getCityName());
                }
                for (AddressLineTextType addressLineText : address.getPostalStructuredAddress().getAddressLineText()) {
                    representativeAddress.getRepresentativeAddress().add(addressLineText.getValue());
                }
                break;
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void processCourtesyLetterAndProcessActions(ProcessModifiedRepAddressSubmissionRequest request,
                                                       IntlIrTranDto intlIrTransaction)
        throws CIPOServiceFault {

        ApplicationDto applicationDto = intrepidCommonService.getApplication(request.getFileNumber().intValue());
        applicationDto.setAddress(request.getRepresentativeAddress());
        try {
            // set file name prefixintlIrTransaction
            TransactionCategory transactionCategory = TransactionCategory
                .getTransactionCategoryByName(intlIrTransaction.getIntlPkgTranType().getTranCtgry());

            String fileNamePrefixKey = NfsFileName.COURTESY_LETTER_PREFIX;

            // create PDF for courtesy letter and new process action
            processCourtesyLetterAndProcessAction(intlIrTransaction, applicationDto, fileNamePrefixKey);

        } catch (Exception e) {
            logger.error("Error in submitRGSReport in processCourtesyLetterAndProcessActions ", e);
            throwCIPOFault(e);
        }
    }
}
