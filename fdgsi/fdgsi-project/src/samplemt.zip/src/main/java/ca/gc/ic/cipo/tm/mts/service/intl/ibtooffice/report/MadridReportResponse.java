package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report;

import java.math.BigDecimal;
import java.util.Date;

import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;

public class MadridReportResponse {

    private String jobId;

    private String reportName;

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getUniqueReportName(BigDecimal irTranId, IntlFileFrmtTypeEnum fileFormat) {
        StringBuilder reportName = new StringBuilder();

        reportName.append(getReportName()).append("_").append(irTranId).append("_").append(new Date().getTime());
        reportName.append(MtsStringUtil.DOT).append(fileFormat.name().toLowerCase());

        return reportName.toString();
    }

}
