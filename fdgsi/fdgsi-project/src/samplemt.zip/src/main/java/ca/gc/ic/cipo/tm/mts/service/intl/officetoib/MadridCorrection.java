package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.common.madrid.InternationalRegistrationNumberBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridCorrectionRequestType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public class MadridCorrection extends OfficeToIbBase implements IOutboundTransaction {

    private static Logger log = Logger.getLogger(MadridCorrection.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_CORRECTION_REQUEST;

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();
        _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        MadridCorrectionRequestType transaction = objectFactory.createMadridCorrectionRequestType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // mandidate field
        IdentifierType idType = new IdentifierType();
        idType.setValue(intlIrTranDto.getIntlRecordId());
        transaction.setRecordIdentifier(idType);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // International Registration Number Bag
        InternationalRegistrationNumberBagType internationalRegistrationNumberBagType = commonObjectFactory
            .createInternationalRegistrationNumberBagType();

        // Registration Number
        internationalRegistrationNumberBagType.getInternationalRegistrationNumber()
            .add(outboundTransactionDto.getIntlRegNo());

        // transaction
        transaction.setInternationalRegistrationNumberBag(internationalRegistrationNumberBagType);

        // include Holder Bag only for DO
        if (StringUtils.isBlank(outboundTransactionRequest.getWipoReferenceNumber())) {
            transaction.setHolderBag(
                super.mapHolder(processActionApplication.getTmInterestedPartyTypeList(), notificationLanguage));
        }

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Comments - Process Action additional info
        OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
        orderedTextType.setLanguageCode(notificationLanguage.value());
        orderedTextType.setSequenceNumber("1");
        orderedTextType.setValue(formatValue(outboundTransactionRequest.getAdditionalInfo()));
        transaction.setCommentText(orderedTextType);

        JAXBElement<MadridCorrectionRequestType> madridobject = objectFactory
            .createMadridCorrectionRequest(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return false;
    }

}
