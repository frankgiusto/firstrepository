package ca.gc.ic.cipo.tm.mts.enums;

public enum NfsFileType {

    TRANSACTION_REPRESENTATION(3),

    PRIMARY_DESIGN(4),

    OUTBOUND(50),

    OTHER_ATTACHMENT(99);

    private Integer nfsFileType;

    private NfsFileType(Integer nfsFileType) {
        this.setNfsFileType(nfsFileType);
    }

    public Integer getNfsFileType() {
        return nfsFileType;
    }

    public void setNfsFileType(Integer nfsFileType) {
        this.nfsFileType = nfsFileType;
    }

}
