package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

public enum InboundTransactionTypes {

    PROCESS_IR_DESIGNATION {

        @Override
        public String getInboundTransactionId() {
            return "madridDesignation";
        }
    },
    PROCESS_IR_CEASING_OF_EFFECT_TOTAL {

        @Override
        public String getInboundTransactionId() {
            return "irCeasingOfEffectTotal";
        }
    },
    PROCESS_IR_HOLDER_NAME_ADDRESS_CHANGE {

        @Override
        public String getInboundTransactionId() {
            return "irHolderNameAddressChange";
        }
    },
    PROCESS_NOTIFICATION {

        @Override
        public String getInboundTransactionId() {
            return "irNotification";
        }
    },
    PROCESS_IR_OWNERSHIP_CHANGE_TOTAL {

        @Override
        public String getInboundTransactionId() {
            return "irOwnershipChangeTotal";
        }
    },
    PROCESS_IR_RENUNCIATION {

        @Override
        public String getInboundTransactionId() {
            return "irRenunciation";
        }
    },
    PROCESS_IR_CANCELLATION_TOTAL {

        @Override
        public String getInboundTransactionId() {
            return "irTotalCancellation";
        }
    },
    PROCESS_IR_CREATION {

        @Override
        public String getInboundTransactionId() {
            return "madridIRCreation";
        }
    },
    PROCESS_IR_RENEWAL {

        @Override
        public String getInboundTransactionId() {
            return "irRenewal";
        }
    },
    PROCESS_IR_NON_RENEWAL {

        @Override
        public String getInboundTransactionId() {
            return "irNonRenewal";
        }
    },
    // Yes, the next 3 return the same id.
    PROCESS_IR_CEASING_OF_EFFECT_PARTIAL {

        @Override
        public String getInboundTransactionId() {
            return "protectionRestriction";
        }
    },
    PROCESS_IR_CANCELLATION_PARTIAL {

        @Override
        public String getInboundTransactionId() {
            return "protectionRestriction";
        }
    },
    PROCESS_IR_LIMITATION {

        @Override
        public String getInboundTransactionId() {
            return "protectionRestriction";
        }
    },
    PROCESS_IRREGULARITY {

        @Override
        public String getInboundTransactionId() {
            return "irregularity";
        }
    },
    PROCESS_CORRECTION {

        @Override
        public String getInboundTransactionId() {
            return "madridCorrection";
        }
    },
    PROCESS_IR_OWNERSHIP_CHANGE_PARTIAL {

        @Override
        public String getInboundTransactionId() {
            return "partialOwnershipChange";
        }
    },
    PROCESS_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL {

        @Override
        public String getInboundTransactionId() {
            return "holdersRightDisposal";
        }
    },
    PROCESS_ABANDONMENT_NOTIFICATION {

        @Override
        public String getInboundTransactionId() {
            return "abandonmentNotification";
        }
    },
    PROCESS_COMPLETED_PROCESSING {

        @Override
        public String getInboundTransactionId() {
            return "madridCompletedProcessing";
        }
    };

    public static Set<InboundTransactionTypes> getInboundTransactionTypes() {
        EnumSet<InboundTransactionTypes> inboundTransactionTypes = EnumSet
            .copyOf(Arrays.asList(InboundTransactionTypes.values()));
        return inboundTransactionTypes;
    }

    public abstract String getInboundTransactionId();
}
