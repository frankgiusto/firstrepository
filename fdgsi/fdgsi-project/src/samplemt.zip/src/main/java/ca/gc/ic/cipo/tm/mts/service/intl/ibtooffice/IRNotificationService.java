package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

/**
 * @author giustof
 *
 */
@Service(value = "irNotification")
public class IRNotificationService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(IRNotificationService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing International Transaction: OfficeReferenceIdentifier:" + intlIrTran.getIntlRegNo());
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        Object objType = transType;

        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByName(intlIrTran.getIntlPkgTranType().getTranCtgry());

        String transactionCategoryName = null;

        if (transactionCategory == TransactionCategory.MBR_APPLICATION_CHANGE) {
            transactionCategoryName = "Madrid Basic Registration Application Change";
        } else {
            MadridHolderRepresentativeChangeType holderType = (MadridHolderRepresentativeChangeType) transType;
            transactionCategoryName = "Madrid Holder Representative Change - "
                + holderType.getMadridHolderRepresentativeChangeCategory().value();
        }

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                // Record Applications with the same IR Number
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    actionDao.saveAction(createAction(objType, application, ActionCode.IR_NOTIFICATION_FILED,
                        SectionAuthority.MADRID.name(), transactionCategoryName));
                    applicationDao.saveApplication(application);

                } else {
                    logger.error(
                        "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
                    throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
                }
            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    @Override
    public String getServiceName() {
        return "IRNotificationService";
    }

}
