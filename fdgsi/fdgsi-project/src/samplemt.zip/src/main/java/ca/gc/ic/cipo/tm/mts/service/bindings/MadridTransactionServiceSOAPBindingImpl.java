package ca.gc.ic.cipo.tm.mts.service.bindings;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.mts.AcquireTrademarkLockRequest;
import ca.gc.ic.cipo.tm.mts.AcquireTrademarkLockResponse;
import ca.gc.ic.cipo.tm.mts.AirToExaminationRequest;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.DuplicateIrregularResponse;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.GetManualReportRequest;
import ca.gc.ic.cipo.tm.mts.GetTransactionByIntlRecordIdRequest;
import ca.gc.ic.cipo.tm.mts.GetTransactionByIntlRecordIdResponse;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.LanguageType;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.MailTransactionType;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.OfficeToIbProcessActions;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsCountRequest;
import ca.gc.ic.cipo.tm.mts.ProcessActionsCountResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessIrregularitySubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ReleaseTrademarkLockRequest;
import ca.gc.ic.cipo.tm.mts.ReleaseTrademarkLockResponse;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateRequest;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionListForHolderDetailsRequest;
import ca.gc.ic.cipo.tm.mts.TransactionListForHolderDetailsResponse;
import ca.gc.ic.cipo.tm.mts.UpdateHolderContactDetailsRequest;
import ca.gc.ic.cipo.tm.mts.UpdateHolderContactDetailsResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;

@javax.jws.WebService(endpointInterface = "ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType", targetNamespace = "http://cipo.ic.gc.ca/tm/mts", serviceName = "MadridTransactionService", portName = "MadridTransactionServicePort")
@javax.xml.ws.BindingType(value = javax.xml.ws.soap.SOAPBinding.SOAP11HTTP_MTOM_BINDING)
public class MadridTransactionServiceSOAPBindingImpl extends SpringBeanAutowiringSupport {

    private static Logger logger = Logger.getLogger(MadridTransactionServiceSOAPBindingImpl.class.getName());

    @Autowired
    private MadridTransactionServicePortType madridTransactionService;

    public String getCountryProvince(String countryProvinceCode, LanguageType language) throws CIPOServiceFault {

        return madridTransactionService.getCountryProvince(countryProvinceCode, language);
    }

    public void setMadridTransactionService(MadridTransactionServicePortType madridTransactionService) {
        this.madridTransactionService = madridTransactionService;
    }

    public WorkflowTaskListResponse getWorkflowTaskList(WorkflowTaskListSearchCriteria parameter)
        throws CIPOServiceFault {

        logger.debug("MTS received request getWorkflowTaskList..............");
        return madridTransactionService.getWorkflowTaskList(parameter);

    }

    public TaskDescriptionListResponse getTaskDescriptionList(TaskDescriptionListSearchCriteria taskDescriptionListSearchCriteria)
        throws CIPOServiceFault {
        logger.debug("MTS received request getTaskDescriptionList..............");
        return madridTransactionService.getTaskDescriptionList(taskDescriptionListSearchCriteria);
    }

    public AutomatedProcessResponse processAutomatedTransaction(AutomaticProcessingCriteria parameter)
        throws CIPOServiceFault {

        return madridTransactionService.processAutomatedTransaction(parameter);
    }

    public ManualProcessResponse processManualTransaction(ManualProcessingCriteria parameter) throws CIPOServiceFault {

        return madridTransactionService.processManualTransaction(parameter);
    }

    public GoodsAndServicesChangesResponse processGoodsAndServicesChanges(GoodsAndServiceMeta parameter)
        throws CIPOServiceFault {

        return madridTransactionService.processGoodsAndServicesChanges(parameter);
    }

    public GoodsAndServicesChangesResponse processPartialOwnership(BigDecimal taskId, String notificationLanguage,
                                                                   PartialOwnershipMeta designation,
                                                                   PartialOwnershipMeta restriction)
        throws CIPOServiceFault {

        return madridTransactionService.processPartialOwnership(taskId, notificationLanguage, designation, restriction);
    }

    public TransactionDetail getTransaction(BigDecimal transactionId, boolean includeXmlContent,
                                            boolean includeAttachmentContent)
        throws CIPOServiceFault {

        return madridTransactionService.getTransaction(transactionId, includeXmlContent, includeAttachmentContent);
    }

    public GetTransactionByIntlRecordIdResponse getTransactionByIntlRecordId(GetTransactionByIntlRecordIdRequest parameters)
        throws CIPOServiceFault {

        return madridTransactionService.getTransactionByIntlRecordId(parameters);
    }

    public AttachmentDetail getTransactionAttachment(BigDecimal request) throws CIPOServiceFault {

        return madridTransactionService.getTransactionAttachment(request);
    }

    public List<TransactionDetail> getTransactionList(TransactionCriteria transactionCriteria) throws CIPOServiceFault {

        return madridTransactionService.getTransactionList(transactionCriteria);
    }

    public ExistingMarkResponse checkExistingMark(ExistingMarkRequest parameter) throws CIPOServiceFault {

        return madridTransactionService.checkExistingMark(parameter);
    }

    public List<ConsoleTaskResponse> checkForNotifications(CheckForNotificationsRequest parameter)
        throws CIPOServiceFault {

        return madridTransactionService.checkForNotifications(parameter);
    }

    public HeartbeatResponseType getHeartbeat() throws CIPOServiceFault {

        return madridTransactionService.getHeartbeat();

    }

    public OfficeToIbProcessActions getOfficeToIbProcessActions(ProcessActionCategoryType processActionType)
        throws CIPOServiceFault {

        return madridTransactionService.getOfficeToIbProcessActions(processActionType);

    }

    public DuplicateIrregularResponse duplicateIrregularTransaction(BigDecimal irTranId, String authorityId)
        throws CIPOServiceFault {

        return madridTransactionService.duplicateIrregularTransaction(irTranId, authorityId);
    }

    public void updateConsoleTaskReference(String taskReferenceId, BigDecimal consoleTaskId) throws CIPOServiceFault {

        madridTransactionService.updateConsoleTaskReference(taskReferenceId, consoleTaskId);
    }

    public void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType consoleTaskStatus)
        throws CIPOServiceFault {

        madridTransactionService.updateConsoleTaskStatus(consoleTaskId, consoleTaskStatus);
    }

    public void updateMailProcessedStatus(BigDecimal fileNumber, String processedByAuthorityId,
                                          MailTransactionType mailTransactionType)
        throws CIPOServiceFault {
        madridTransactionService.updateMailProcessedStatus(fileNumber, processedByAuthorityId, mailTransactionType);
    }

    public OfficeToIbTransactionResponse createOfficeToIbTransaction(ProcessActionsMeta processActionsMeta)
        throws CIPOServiceFault {

        return madridTransactionService.createOfficeToIbTransaction(processActionsMeta);

    }

    public ManualProcessResponse createOfficeToIbManualTask(ProcessActionsMeta parameters) throws CIPOServiceFault {

        return madridTransactionService.createOfficeToIbManualTask(parameters);

    }

    public void storeAirToExaminationSubmissionInfo(AirToExaminationRequest parameters) throws CIPOServiceFault {
        madridTransactionService.storeAirToExaminationSubmissionInfo(parameters);
    }

    public ProcessManualReportRequest getManualReport(GetManualReportRequest parameters) throws CIPOServiceFault {
        return madridTransactionService.getManualReport(parameters);
    }

    public void processManualReport(ProcessManualReportRequest parameters) throws CIPOServiceFault {
        madridTransactionService.processManualReport(parameters);
    }

    public void processIrregularitySubmission(ProcessIrregularitySubmissionRequest irregularitySubmissionRequest)
        throws CIPOServiceFault {
        madridTransactionService.processIrregularitySubmission(irregularitySubmissionRequest);
    }

    public void processIRCorrectionSubmission(ProcessIRCorrectionSubmissionRequest request) throws CIPOServiceFault {
        madridTransactionService.processIRCorrectionSubmission(request);
    }

    public ResponseDueDateResponse getResponseDueDate(ResponseDueDateRequest request) throws CIPOServiceFault {
        return madridTransactionService.getResponseDueDate(request);
    }

    public UpdateHolderContactDetailsResponse updateHolderContactDetails(UpdateHolderContactDetailsRequest request)
        throws CIPOServiceFault {
        return madridTransactionService.updateHolderContactDetails(request);
    }

    public TransactionListForHolderDetailsResponse getTransactionListForHolderDetails(TransactionListForHolderDetailsRequest parameters)
        throws CIPOServiceFault {
        return madridTransactionService.getTransactionListForHolderDetails(parameters);
    }

    public AcquireTrademarkLockResponse acquireTrademarkLock(AcquireTrademarkLockRequest parameters)
        throws CIPOServiceFault {
        return madridTransactionService.acquireTrademarkLock(parameters);
    }

    public ReleaseTrademarkLockResponse releaseTrademarkLock(ReleaseTrademarkLockRequest parameters)
        throws CIPOServiceFault {
        return madridTransactionService.releaseTrademarkLock(parameters);
    }

    public ProcessActionsCountResponse processActionsCount(ProcessActionsCountRequest parameters)
        throws CIPOServiceFault {
        return madridTransactionService.processActionsCount(parameters);
    }

    public void processModifiedRepAddressSubmission(ProcessModifiedRepAddressSubmissionRequest modifiedRepAddressSubmission)
        throws CIPOServiceFault {

        madridTransactionService.processModifiedRepAddressSubmission(modifiedRepAddressSubmission);

    }
}