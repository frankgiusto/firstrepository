package ca.gc.ic.cipo.tm.mts.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.userprofile.client.UserProfileServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileService;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;

@Service
public class MadridCacheService implements IMadridCacheService {

    @Value("#{environment['mts.tm.user.profile.services.host.name']}")
    private String tupsHostName;

    @Override
    @Cacheable(value = "madridUsers", cacheManager = "cacheManager")
    public UserProfile getUserProfile(String userId) throws CIPOServiceFault {

        UserProfileType userProfileType = new UserProfileType();
        userProfileType.setAuthorityId(userId);
        userProfileType.setParentUserName(userId);
        UserProfileService tupsClient = UserProfileServiceFactory.createClient(tupsHostName);

        return tupsClient.getUserProfile(userProfileType);
    }
}
