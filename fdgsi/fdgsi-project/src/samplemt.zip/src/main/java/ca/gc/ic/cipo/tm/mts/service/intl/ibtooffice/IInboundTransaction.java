package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;

public interface IInboundTransaction {

    /**
     * Process inbound transaction.
     *
     * @param <T> the generic inbound transaction type
     * @param intlIrTran the intl ir tran
     * @param transType the trans type
     * @return the map of notifications
     * @throws MTSServiceFault the MTS service fault
     */
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault;

}
