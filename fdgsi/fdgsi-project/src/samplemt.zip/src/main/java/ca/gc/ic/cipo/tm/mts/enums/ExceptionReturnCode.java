package ca.gc.ic.cipo.tm.mts.enums;

/**
 * The Enum ExceptionReturnCode defines the severity of the Exception
 *
 * @author giustof
 */
public enum ExceptionReturnCode {

    FATAL(-99),

    RECOVERABLE(1);

    private Integer returnCode;

    private ExceptionReturnCode(Integer returnCode) {
        this.returnCode = returnCode;
    }

    public Integer getReturnCode() {
        return this.returnCode;
    }

}
