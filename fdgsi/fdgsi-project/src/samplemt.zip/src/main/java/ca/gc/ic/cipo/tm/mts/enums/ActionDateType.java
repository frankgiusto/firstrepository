package ca.gc.ic.cipo.tm.mts.enums;

/**
 * The Enum ActionDateType. These correspond to Intrepid action codes
 */
public enum ActionDateType {

    ADVERTISED_DATE(42), RECORD_FEDERAL_COURT_PROCEEDING(173);

    private Integer actionCode;

    private ActionDateType(Integer actionCode) {
        this.actionCode = actionCode;
    }

    public Integer getActionCode() {
        return actionCode;
    }
}
