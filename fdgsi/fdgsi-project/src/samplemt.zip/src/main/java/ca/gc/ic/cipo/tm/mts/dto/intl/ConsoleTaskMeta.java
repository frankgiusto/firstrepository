package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ConsoleTaskMeta implements Serializable {

    private final static long serialVersionUID = 1L;

    protected String taskReferenceId;

    protected String extensionCounter;

    protected BigDecimal fileNumber;

    protected String irNumber;

    protected String intlFilingRecordId;

    protected String wipoReferenceNumber;

    protected int userTaskType;

    protected int userTaskStatus;

    protected List<IntlTaskAddtnlInfoDto> additionalInfos;

    protected String officeType;

    protected String authorityId;

    protected List<BigDecimal> transactionIds;

    protected Date processActionDate;

    /**
     * Gets the value of the taskReferenceId property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getTaskReferenceId() {
        return taskReferenceId;
    }

    /**
     * Sets the value of the taskReferenceId property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setTaskReferenceId(String value) {
        this.taskReferenceId = value;
    }

    /**
     * Gets the value of the extensionCounter property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getExtensionCounter() {
        return extensionCounter;
    }

    /**
     * Sets the value of the extensionCounter property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setExtensionCounter(String value) {
        this.extensionCounter = value;
    }

    /**
     * Gets the value of the fileNumber property.
     *
     * @return possible object is {@link BigDecimal }
     *
     */
    public BigDecimal getFileNumber() {
        return fileNumber;
    }

    /**
     * Sets the value of the fileNumber property.
     *
     * @param value allowed object is {@link BigDecimal }
     *
     */
    public void setFileNumber(BigDecimal value) {
        this.fileNumber = value;
    }

    /**
     * Gets the value of the irNumber property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getIrNumber() {
        return irNumber;
    }

    /**
     * Sets the value of the irNumber property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setIrNumber(String value) {
        this.irNumber = value;
    }

    /**
     * Gets the value of the intlFilingRecordId property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getIntlFilingRecordId() {
        return intlFilingRecordId;
    }

    /**
     * Sets the value of the intlFilingRecordId property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setIntlFilingRecordId(String value) {
        this.intlFilingRecordId = value;
    }

    /**
     * Gets the value of the wipoReferenceNumber property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getWipoReferenceNumber() {
        return wipoReferenceNumber;
    }

    /**
     * Sets the value of the wipoReferenceNumber property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setWipoReferenceNumber(String value) {
        this.wipoReferenceNumber = value;
    }

    /**
     * Gets the value of the userTaskType property.
     *
     */
    public int getUserTaskType() {
        return userTaskType;
    }

    /**
     * Sets the value of the userTaskType property.
     *
     */
    public void setUserTaskType(int value) {
        this.userTaskType = value;
    }

    /**
     * Gets the value of the userTaskStatus property.
     *
     */
    public int getUserTaskStatus() {
        return userTaskStatus;
    }

    /**
     * Sets the value of the userTaskStatus property.
     *
     */
    public void setUserTaskStatus(int value) {
        this.userTaskStatus = value;
    }

    /**
     * Gets the value of the officeType property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getOfficeType() {
        return officeType;
    }

    public List<IntlTaskAddtnlInfoDto> getAdditionalInfos() {
        if (additionalInfos == null) {
            additionalInfos = new ArrayList<>();
        }
        return additionalInfos;
    }

    public void setAdditionalInfos(List<IntlTaskAddtnlInfoDto> additionalInfos) {
        this.additionalInfos = additionalInfos;
    }

    /**
     * Sets the value of the officeType property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setOfficeType(String value) {
        this.officeType = value;
    }

    /**
     * Gets the value of the authorityId property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getAuthorityId() {
        return authorityId;
    }

    /**
     * Sets the value of the authorityId property.
     *
     * @param value allowed object is {@link String }
     *
     */
    public void setAuthorityId(String value) {
        this.authorityId = value;
    }

    /**
     * Gets the value of the transactionIds property.
     *
     * <p>
     * This accessor method returns a reference to the live list, not a snapshot. Therefore any modification you make to
     * the returned list will be present inside the JAXB object. This is why there is not a <CODE>set</CODE> method for
     * the transactionIds property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     *
     * <pre>
     * getTransactionIds().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list {@link BigDecimal }
     *
     *
     */
    public List<BigDecimal> getTransactionIds() {
        if (transactionIds == null) {
            transactionIds = new ArrayList<BigDecimal>();
        }
        return this.transactionIds;
    }

    public Date getProcessActionDate() {
        return processActionDate;
    }

    public void setProcessActionDate(Date processActionDate) {
        this.processActionDate = processActionDate;
    }

}
