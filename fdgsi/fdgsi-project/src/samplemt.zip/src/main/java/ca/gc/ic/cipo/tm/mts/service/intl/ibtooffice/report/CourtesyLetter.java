package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import ca.gc.ic.cipo.report.CipoServiceFault;
import ca.gc.ic.cipo.report.ReportType;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IReportingService;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;

public class CourtesyLetter implements IReportingService {

    private static Logger log = Logger.getLogger(CourtesyLetter.class.getName());

    private final static String reportBaseName = "MADRID_COURTESY_LETTER";

    private final String xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";

    private final String reportXpath = "mfReportRoot";

    private static String xmltagName_address = "address";

    private static String xmltagName_date = "date";

    private static String xmltagName_yourFileNumber = "yourFileNumber";

    private static String xmltagName_myFileNumber = "myFileNumber";

    private static String xmltagName_IR = "irNumber";

    private static String xmltagName_tradeMark = "tradeMark";

    private static String xmltagName_applicant = "applicant";

    private static String xmltagName_imageFileName = "imageFileName";

    public CourtesyLetter() {
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        MadridCourtesyLetter madridCourtesyLetter = (MadridCourtesyLetter) inObject;

        String xmlDataSource = generateReport(madridCourtesyLetter, reportServiceHost);

        String jobId = null;
        try {
            jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(), reportXpath, reportBaseName,
                madridCourtesyLetter.getImageList());

        } catch (Exception e) {
            throw new Exception("Error shedudling report for madrid coutesy letter.", e);
        }
        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setReportName(madridCourtesyLetter.getReportFileName());
        madridReportResponse.setJobId(jobId);
        return madridReportResponse;
    }

    private String scheduleReport(String reportServiceHost, String xmlDataSource, String reportXpath, String reportName,
                                  List<InputStream> imageList)
        throws ParserConfigurationException, IllegalArgumentException, SAXException, IOException, CipoServiceFault {

        String jobId = null;

        Document doc = null;
        DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(xmlDataSource));
        doc = docBuilder.parse(is);

        ReportGenerationWsClient rgsClient = new ReportGenerationWsClient(reportServiceHost);
        rgsClient.setOutReportType(ReportType.PDF);

        jobId = rgsClient.scheduleReportGenerationWithDocument(reportName, null, doc, reportXpath, null, imageList,
            Locale.CANADA, null);

        return jobId;
    }

    public String generateReport(MadridCourtesyLetter inObject, String reportServiceHost) {

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, reportXpath);

        String tagName = xmltagName_address;
        String value = StringEscapeUtils.escapeXml(inObject.getAddress());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_date;
        value = inObject.getDate();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_yourFileNumber;
        value = inObject.getYourFileNumber();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_myFileNumber;
        value = inObject.getMyFileNumber();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_IR;
        value = inObject.getIrNumber();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_tradeMark;
        value = StringEscapeUtils.escapeXml(inObject.getTradeMark());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_applicant;
        value = StringEscapeUtils.escapeXml(inObject.getApplicant());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = xmltagName_imageFileName;
        value = inObject.getImageFileName();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        XMLTagUtil.appendTagClose(xmlDataSource, reportXpath);
        log.debug(xmlDataSource.toString());

        return xmlDataSource.toString();
    }
}
