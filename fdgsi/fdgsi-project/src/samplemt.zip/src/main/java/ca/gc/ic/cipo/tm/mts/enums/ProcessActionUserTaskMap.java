package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;

public class ProcessActionUserTaskMap {

    public static final Map<ProcessActionCodeType, UserTaskType> processActionUserTaskMap;
    static {
        Map<ProcessActionCodeType, UserTaskType> aMap = new HashMap<>();

        aMap.put(ProcessActionCodeType.MADRID_PROVISIONAL_REFUSAL_MF_3, UserTaskType.MADRID_PROVISIONAL_REFUSAL_MF3A);
        aMap.put(ProcessActionCodeType.MADRID_FURTHER_DECISION_MF_7, UserTaskType.MADRID_FURTHER_DECISION_MF7);
        aMap.put(ProcessActionCodeType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL,
            UserTaskType.PARTIAL_CEASING_OF_EFFECT_OO);
        aMap.put(ProcessActionCodeType.MADRID_IR_REPLACEMENT_MANUAL, UserTaskType.IR_REPLACEMENT_REQUEST);
        aMap.put(ProcessActionCodeType.MADRID_REVIEW_CORESPONDENCE_MANUAL, UserTaskType.REVIEW_INCOMING_CORRESPONDENCE);
        aMap.put(ProcessActionCodeType.MADRID_IR_NOT_RENEWED_MANUAL, UserTaskType.IR_NOT_RENEWED);
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_IB_MF_6_REMOVAL_MANUAL, UserTaskType.NOTIFY_IB_OF_MF_6_REMOVAL);
        aMap.put(ProcessActionCodeType.MADRID_READY_FOR_EXAMINATION_MANUAL, UserTaskType.READY_FOR_MADRID_EXAMINATION);
        aMap.put(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_DIVISION, UserTaskType.BASIC_APPLICATION_LIST);
        aMap.put(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER, UserTaskType.BASIC_APPLICATION_LIST);
        aMap.put(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT, UserTaskType.BASIC_APPLICATION_LIST);
        aMap.put(ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9, UserTaskType.TOTAL_CEASING_OF_EFFECT_OO);
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_WIPO_CLARIFICATION_REQUEST_OUTSTANDING,
            UserTaskType.NOTIFY_WIPO_CLARIFICATION_REQUEST_OUTSTANDING);
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_IB_IV_REMOVAL_MANUAL,
            UserTaskType.MADRID_NOTIFY_IB_IV_REMOVAL_MANUAL);
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_WIPO_REGISTRATION_REMOVAL_MANUAL,
            UserTaskType.MADRID_NOTIFY_WIPO_REGISTRATION_REMOVAL_MANUAL);
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_IR_CANDIDATE_REGISTRATION_MANUAL,
            UserTaskType.MADRID_NOTIFY_IR_CANDIDATE_REGISTRATION_MANUAL);
        aMap.put(ProcessActionCodeType.NOTIFY_IR_CANDIDATEFOR_EXAM_ABANDOMENT_MANUAL,
            UserTaskType.NOTIFY_IR_CANDIDATEFOR_EXAM_ABANDOMENT_MANUAL);
        aMap.put(ProcessActionCodeType.NOTIFY_SUP_PENDING_REGISTRATION_CANDIDATE_MANUAL,
            UserTaskType.NOTIFY_SUP_PENDING_REGISTRATION_CANDIDATE_MANUAL);
        aMap.put(ProcessActionCodeType.NOTIFY_EXAM_SUP_PROTOCOLAPPS_17_MONTHS_MANUAL,
            UserTaskType.NOTIFY_EXAM_SUP_PROTOCOLAPPS_17_MONTHS_MANUAL);

        processActionUserTaskMap = Collections.unmodifiableMap(aMap);
    }
}
