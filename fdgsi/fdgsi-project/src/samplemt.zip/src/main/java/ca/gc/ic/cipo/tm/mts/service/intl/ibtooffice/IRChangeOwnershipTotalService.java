package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.ICourtesyLetterService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

@Service(value = "irOwnershipChangeTotal")
public class IRChangeOwnershipTotalService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private FootNotesDao footnotesDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private ICourtesyLetterService courtestyLetterService;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(IRChangeOwnershipTotalService.class.getName());

    @Override
    @Transactional
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing IR Change Ownership total -  Intl Record Id:" + intlIrTran.getIntlRecordId());
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChangeType = (MadridHolderRepresentativeChangeType) transType;

        // Get all applications matching transactions international registration number.

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                StringBuilder ownerChange = new StringBuilder();

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    Set<InterestedParty> interestedParties = application.getInterestedParties();
                    LanguageType applicationLanguage = null;
                    if (CollectionUtils.isNotEmpty(interestedParties)) {
                        for (InterestedParty interestedParty : interestedParties) {
                            if (interestedParty.getRelationshipType().intValue() == RelationshipType.OWNER.getValue()
                                .intValue()) {

                                // update owner name
                                ownerChange.append("From: ").append(interestedParty.getContact().getName())
                                    .append(" To: ");

                                interestedParty.setRelationshipType(RelationshipType.OLD_OWNER.getValue());
                                applicationLanguage = LanguageType
                                    .getByValue(interestedParty.getLanguageOfPreference());

                                interestedPartyDao.saveInterestedParty(interestedParty);
                            }
                        }

                        List<ApplicantType> holderList = madridHolderRepresentativeChangeType.getHolderChangeBag()
                            .getHolderBag().getHolder();
                        if (CollectionUtils.isEmpty(holderList)) {
                            logger.error("madridHolderRepresentativeChangeType.getHolderChangeBag() is empty!");
                            continue;
                        }

                        if (holderList.size() > 1) {
                            // Notification to review ownership change
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
                            statusTypeResults.put(appDto, UserTaskType.REVIEW_OWNER_NAME);
                        }
                        InterestedParty interestedParty = createMHRInterestedParty(application,
                            getNextInterestedPartySequence(interestedParties));

                        // Create the Contact Information
                        setInterestedPartyContact(applicationLanguage, holderList, application, interestedParty);

                        // Record the new owner name for footnote
                        ownerChange.append(interestedParty.getContact().getName());

                        // Update the Interested Party Address
                        setInterestedPartyAddress(holderList, application, interestedParty,
                            madridHolderRepresentativeChangeType);

                        if (mailingAddressLengthNotification(holderList, interestedParty)) {
                            // Notification that address > 8 lines by 40 chars
                            // set AuthorityId to MC_TMOB_OPERATOR
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
                            statusTypeResults.put(appDto, UserTaskType.ADDRESS_EXCEEDED_LIMIT);
                        }

                        // check if a courtesy letter required
                        int arNum = 0;
                        if (null != madridHolderRepresentativeChangeType.getRepresentative()) {
                            logger.debug("checkAndProcessCourtesyLetter in IRChangeOwnershipTotalService");

                            arNum = courtestyLetterService.checkIsCourtesyLetterRequired(
                                madridHolderRepresentativeChangeType, application, applicationLanguage,
                                statusTypeResults);

                            logger.debug("AgentNumber: " + arNum);
                        }

                        // Save the new address
                        for (InterestedPartiesAddresses eachAddress : interestedParty.getContact()
                            .getInterestedPartiesAddresses()) {
                            interestedPartiesAddressesDao.saveInterestedPartiesAddresses(eachAddress);
                        }
                        application.getInterestedParties().add(interestedParty);
                        if (arNum != 0) {
                            interestedParty.setAgentNumber(arNum);
                        }
                        interestedPartyDao.saveInterestedParty(interestedParty);

                        // Footnote
                        Footnote footnote = new Footnote();
                        footnote.setApplication(application);
                        footnote.setFileNumber(application.getFileNumber());
                        footnote.setExtensionCounter(application.getExtensionCounter());
                        footnote.setSequenceNumber(getNextFootnoteSequence(application.getFootnotes()));
                        footnote.setType(FootnoteType.CHANGE_OF_OWNERSHIP_INTERNATIONAL_REGISTRATION.getValue());
                        footnote.setDateRegistered(new Date());
                        try {
                            footnote.setDateOfChange(DateFormats.getISOSDF()
                                .parse(madridHolderRepresentativeChangeType.getRecordEffectiveDate()));
                        } catch (ParseException e) {
                            logger.error("Could not parse record effective date:"
                                + madridHolderRepresentativeChangeType.getRecordEffectiveDate());
                        }
                        footnote.setText(ownerChange.toString());

                        footnotesDao.saveFootNote(footnote);

                        application.getFootnotes().add(footnote);

                        // Process Action - Print Confirmation of Change – Partial Ownership
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE_TOTAL,
                            SectionAuthority.MADRID.name()));

                        actionDao.saveAction(createAction(madridHolderRepresentativeChangeType, application,
                            ActionCode.CHANGE_OF_TITLE_REGISTERED, SectionAuthority.MADRID.name(),
                            ownerChange.toString()));

                        applicationDao.saveApplication(application);
                    }

                    if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue()
                        .intValue()) {

                        applicationDao.saveApplication(application);

                        // process open section 45 cases
                        if (openOppositionCases(application, registeredOppositionCaseTypes)) {
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            statusTypeResults.put(appDto, UserTaskType.TOTAL_OWNERSHIP_CHANGED_OCCURRED);
                        }

                    } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                        .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                        // process opposition cases
                        if (openOppositionCases(application, unRegisteredOppositionCaseTypes)) {
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            // This is for creating notifications
                            statusTypeResults.put(appDto, UserTaskType.TOTAL_OWNERSHIP_CHANGED_OCCURRED);
                        }
                    }

                } else {
                    // Inactive Intrepid Application.
                    logger.error(
                        "Madrid Mark in Inactive - This should not happen since CheckForExistingMark should have been called previously");
                    throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
                }

            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    @Override
    public <T> T unmarshallTransaction(IntlIrTranDto intlIrTran) throws JAXBException, SQLException {
        return marshallingService.unmarshallTransaction(intlIrTran.getIrTranId());
    }

    @Override
    public String getServiceName() {
        return "IRChangeOwnershipTotalService";
    }
}
