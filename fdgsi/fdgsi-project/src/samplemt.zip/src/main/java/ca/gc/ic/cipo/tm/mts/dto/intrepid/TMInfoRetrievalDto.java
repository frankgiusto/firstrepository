package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;
import java.util.List;

import ca.gc.ic.cipo.tm.tirs.types.TrademarkActionType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;

public class TMInfoRetrievalDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    //
    private boolean registeredApplication = true;

    private TrademarkApplicationType trademarkApplicationType;

    private List<TMInterestedPartyType> tmInterestedPartyTypeList;

    private TrademarkApplicationDetailsType trademarkApplicationDetailsType;

    private List<TrademarkActionType> trademarkActionTypes;

    private List<GoodsServicesType> goodsAndServices;

    public TrademarkApplicationType getTrademarkApplicationType() {
        return trademarkApplicationType;
    }

    public void setTrademarkApplicationType(TrademarkApplicationType trademarkApplicationType) {
        this.trademarkApplicationType = trademarkApplicationType;
    }

    public List<TMInterestedPartyType> getTmInterestedPartyTypeList() {
        return tmInterestedPartyTypeList;
    }

    public void setTmInterestedPartyTypeList(List<TMInterestedPartyType> tmInterestedPartyTypeList) {
        this.tmInterestedPartyTypeList = tmInterestedPartyTypeList;
    }

    public TrademarkApplicationDetailsType getTrademarkApplicationDetailsType() {
        return trademarkApplicationDetailsType;
    }

    public void setTrademarkApplicationDetailsType(TrademarkApplicationDetailsType trademarkApplicationDetailsType) {
        this.trademarkApplicationDetailsType = trademarkApplicationDetailsType;
    }

    public List<GoodsServicesType> getGoodsAndServices() {
        return goodsAndServices;
    }

    public void setGoodsAndServices(List<GoodsServicesType> goodsAndServices) {
        this.goodsAndServices = goodsAndServices;
    }

    public List<TrademarkActionType> getTrademarkActionTypes() {
        return trademarkActionTypes;
    }

    public void setTrademarkActionTypes(List<TrademarkActionType> trademarkActionTypes) {
        this.trademarkActionTypes = trademarkActionTypes;
    }

    public boolean isRegisteredApplication() {
        return registeredApplication;
    }

    public void setRegisteredApplication(boolean registeredApplication) {
        this.registeredApplication = registeredApplication;
    }
}
