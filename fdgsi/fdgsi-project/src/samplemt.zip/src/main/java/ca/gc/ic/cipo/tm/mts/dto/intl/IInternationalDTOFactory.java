/*
 *
 */
package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTask;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.enums.NfsFileType;
import ca.gc.ic.cipo.tm.mts.enums.TransactionCategoryType;

public interface IInternationalDTOFactory {

    /**
     * Gets the intl ir tran dto.
     *
     * @param intlIrTran the intl ir tran
     * @return the intl ir tran dto
     */
    public IntlIrTranDto getIntlIrTranDto(IntlIrTran intlIrTran);

    /**
     * Gets the IR task dto.
     *
     * @param intlIrTask the intl ir task
     * @return the IR task dto
     */
    public IntlIrTaskDto getIRTaskDto(IntlIrTask intlIrTask);

    /**
     * Gets the IR task list dto. Takes a list of Task Entities and produces a dto list.
     *
     * @param intlIrTaskList the intl ir task list
     * @return the IR task list dto
     */
    public List<IntlIrTaskDto> getIRTaskListDto(List<IntlIrTask> intlIrTaskList);

    /**
     * Gets the automated transaction categories.
     *
     * @return the automated transaction categories
     */
    public List<BigDecimal> getAutomatedTransactionCategories();

    /**
     * Gets the manual transaction categories.
     *
     * @return the manual transaction categories
     */
    public List<BigDecimal> getManualTransactionCategories();

    /**
     * Gets the paired transaction type.
     *
     * @param transactionCategory the transaction category
     * @return the paired transaction type
     */
    public TransactionCategoryType getPairedTransactionType(TransactionCategory transactionCategory);

    /**
     * Gets the automated transaction pair categories.
     *
     * @return the automated transaction pair categories
     */
    public List<BigDecimal> getAutomatedTransactionPairCategories();

    /**
     * Gets the status types.
     *
     * @param transactionCriteria the transaction criteria
     * @return the status types
     */
    public List<BigDecimal> getStatusTypes(TransactionCriteria transactionCriteria);

    /**
     * Gets the transaction types.
     *
     * @param transactionCriteria the transaction criteria
     * @return the transaction types
     */
    public List<BigDecimal> getTransactionTypes(TransactionCriteria transactionCriteria);

    /**
     * Map to xsd.
     *
     * @param transactionModel the transaction model
     * @param includeXmlContent the include xml content
     * @param includeAttachmentContent the include attachment content
     * @return the transaction detail
     * @throws CIPOServiceFault the CIPO service fault
     * @throws SQLException the SQL exception
     */
    public TransactionDetail mapToXsd(final IntlIrTran transactionModel, final boolean includeXmlContent,
                                      final boolean includeAttachmentContent)
        throws CIPOServiceFault, SQLException;

    /**
     * Map to xsd.
     *
     * @param attachment the attachment
     * @param includeAttachmentContent the include attachment content
     * @return the attachment detail
     * @throws CIPOServiceFault the CIPO service fault
     * @throws SQLException the SQL exception
     */
    public AttachmentDetail mapToXsd(final IntlAtchmt attachment, final boolean includeAttachmentContent)
        throws CIPOServiceFault, SQLException;

    /**
     * Map to transaction xsd. We don't want all the details here
     *
     * @param transactionModel the transaction model
     * @return the transaction detail
     * @throws CIPOServiceFault the CIPO service fault
     */
    public TransactionDetail mapToTransactionXsd(final IntlIrTran transactionModel) throws CIPOServiceFault;

    /**
     * Map transaction pairs to xsd.
     *
     * @param transList the trans list
     * @param transactionDetailList the transaction detail list
     * @throws CIPOServiceFault the CIPO service fault
     * @throws SQLException the SQL exception
     */
    // public void mapTransactionPairsToXsd(List<IntlIrTran> transList, List<TransactionDetail> transactionDetailList)
    // throws CIPOServiceFault, SQLException;

    /**
     * Gets the atchmt dto.
     *
     * @param attachments the attachments
     * @return the atchmt dto
     */
    public List<IntlAtchmtDto> getAtchmtDto(Set<IntlAtchmt> attachments);

    /**
     * Creates a new NfsFilenameDto object.
     *
     * @param fileName the file name
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @param fileType the file type
     * @param atchmntId the atchmnt id
     * @param irTranId the ir tran id
     * @return the nfs filename dto
     */
    public NfsFilenameDto createNfsFilenameDto(String fileName, BigDecimal fileNumber, String extensionCounter,
                                               NfsFileType fileType, BigDecimal atchmntId, BigDecimal irTranId);

    /**
     * Gets the intl ir tran no children dto. Dont want the related task/transaction xref in this case
     *
     * @param intlIrTran the intl ir tran
     * @return the intl ir tran no children dto
     */
    public IntlIrTranDto getIntlIrTranNoChildrenDto(IntlIrTran intlIrTran);

    /**
     * File number to task dto list.
     *
     * @param fileNumberList the file number list
     * @param irNumber the ir number
     * @return the list
     */
    public List<IntlIrTaskDto> fileNumberToTaskDtoList(List<Integer> fileNumberList, String irNumber);
}
