package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;

/**
 * The Class ProcessActionUserGroupMap maps a process action code to the user group that it should be assigned to.
 */
public class ProcessActionUserGroupMap {

    public static final Map<ProcessActionCodeType, String> processActionUserGroupMap;
    static {
        Map<ProcessActionCodeType, String> aMap = new HashMap<>();

        aMap.put(ProcessActionCodeType.MADRID_READY_FOR_EXAMINATION_MANUAL, SectionAuthority.MC_TM_SUPERVISOR.name()); // TODO
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_IB_MF_6_REMOVAL_MANUAL, SectionAuthority.MC_TM_SUPERVISOR.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_IR_NOT_RENEWED_MANUAL, SectionAuthority.MC_TM_SUPERVISOR.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_IR_REPLACEMENT_MANUAL, SectionAuthority.MC_TM_SUPERVISOR.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_REVIEW_CORESPONDENCE_MANUAL, SectionAuthority.MC_TM_SUPERVISOR.name()); // verifed
                                                                                                                      // default
                                                                                                                      // with
                                                                                                                      // mail
                                                                                                                      // override
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_IB_IV_REMOVAL_MANUAL, SectionAuthority.MC_TM_SUPERVISOR.name());
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_WIPO_REGISTRATION_REMOVAL_MANUAL,
            SectionAuthority.MC_TM_SUPERVISOR.name());
        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_IR_CANDIDATE_REGISTRATION_MANUAL,
            SectionAuthority.MC_TM_SUPERVISOR.name());
        aMap.put(ProcessActionCodeType.NOTIFY_IR_CANDIDATEFOR_EXAM_ABANDOMENT_MANUAL,
            SectionAuthority.MC_TM_SUPERVISOR.name());
        aMap.put(ProcessActionCodeType.NOTIFY_SUP_PENDING_REGISTRATION_CANDIDATE_MANUAL,
            SectionAuthority.MC_TM_SUPERVISOR.name());
        aMap.put(ProcessActionCodeType.NOTIFY_EXAM_SUP_PROTOCOLAPPS_17_MONTHS_MANUAL,
            SectionAuthority.MC_TM_SUPERVISOR.name());

        aMap.put(ProcessActionCodeType.MADRID_NOTIFY_WIPO_CLARIFICATION_REQUEST_OUTSTANDING,
            SectionAuthority.MC_TM_SUPERVISOR.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9, SectionAuthority.MC_TM_EXAMINER.name()); // verified

        // more
        aMap.put(ProcessActionCodeType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL, SectionAuthority.MC_TM_EXAMINER.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_PROVISIONAL_REFUSAL_MF_3, SectionAuthority.MC_TM_EXAMINER.name()); // TODO
        aMap.put(ProcessActionCodeType.MADRID_FURTHER_DECISION_MF_7, SectionAuthority.MC_TM_EXAMINER.name()); // TODO
        aMap.put(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_DIVISION, SectionAuthority.MC_TM_EXAMINER.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER, SectionAuthority.MC_TM_EXAMINER.name()); // verified
        aMap.put(ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT, SectionAuthority.MC_TM_EXAMINER.name()); // verified

        processActionUserGroupMap = Collections.unmodifiableMap(aMap);
    }

}