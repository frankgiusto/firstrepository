package ca.gc.ic.cipo.tm.mts.service.intl;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.DuplicateIrregularResponse;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ProcessActionMapBean;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionsMap;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;

@Component
public class DuplicateTransaction extends MadridTransactionService implements IDuplicateTransaction {

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private MadridTransactionServicePortType madridTransactionService;

    @Autowired
    private IMarshallingService marshallingService;

    private static Logger logger = Logger.getLogger(DuplicateTransaction.class.getName());

    @Override
    public DuplicateIrregularResponse duplicateIrregularTransaction(BigDecimal irTranId, String authorityId)
        throws CIPOServiceFault {

        DuplicateIrregularResponse duplicateIrregularResponse = new DuplicateIrregularResponse();

        // 1) Get Transaction
        IntlIrTranDto intlIrTranDto = internationalService.getTransactionsByIrTranId(irTranId);

        // validate that this is an Irregularity Transaction
        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(intlIrTranDto.getIntlPkgTranType().getPkgTranCtgryId());
        if (transactionCategory != TransactionCategory.MI_IRREGULARITY_NOTIFICATION) {
            logger.error("Expecting an Irregularity transaction...");
            throwMTSServiceFault("mts.invalid.transaction.category", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        try {
            MadridIrregularityNotificationType madridIrregularityNotificationType = marshallingService
                .unmarshallTransaction(irTranId);

            Integer officeReferenceIdentifier = Integer
                .valueOf(madridIrregularityNotificationType.getOfficeReferenceIdentifier().getValue());

            IntlIrTranDto originalTransactionDto = internationalService
                .getTransactionsByIrTranId(BigDecimal.valueOf(officeReferenceIdentifier));

            MadridOutboundTransactionType originalTransactionCategory = MadridOutboundTransactionType
                .getTransactionTypeByValue(originalTransactionDto.getIntlPkgTranType().getPkgTranCtgryId());

            // Map outbound transaction type with Process Code.
            if (!ProcessActionsMap.packageTransactionTypeProcessActionMap.containsKey(originalTransactionCategory)) {
                logger.error("Can't find transaction mapping for " + originalTransactionCategory.toString());
                throwMTSServiceFault("mts.invalid.transaction.category", ExceptionReasonCode.RETRYABLE_ERROR);
            } else {

                /*
                 * Note from Fei Fei. TODO: The opposition case number needs to pass into createOfficeToIbManualTask It
                 * requires to modify the processActionMeta interface which is very aggressive change. I will wait after
                 * CIF-1 sprint. The change needs to coordinate with MWE to get the modified xsd and MTS client.
                 *
                 * The following code is rough work. Uncomment it once the processActionMeta interface changed.
                 */
                // The opposition case number is persisted in additional info of the MF3 console task.
                // if (originalTransactionCategory == MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3) {
                // Integer oppoCaseNum = null;
                //
                // if (CollectionUtils.isNotEmpty(originalTransactionDto.getIntlIrTaskXrefDtoList())) {
                // for (IntlIrTaskXrefDto intlIrTaskXrefDto : originalTransactionDto.getIntlIrTaskXrefDtoList()) {
                // IntlIrTaskDto intlIrTaskDto = intlIrTaskXrefDto.getIntlIrTaskDto();
                // if (CollectionUtils.isNotEmpty(intlIrTaskDto.getIntlTaskAddtnlInfoDto())) {
                // for (IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto : intlIrTaskDto
                // .getIntlTaskAddtnlInfoDto()) {
                // if (intlTaskAddtnlInfoDto.getIntlTaskAddtnlInfoTypeDto().getTaskAddtnlInfoCtgryId()
                // .intValue() == TaskAddtnlInfoType.OPPOSITION_CASE_NUMBER.getValue()) {
                // oppoCaseNum = Integer.parseInt(intlTaskAddtnlInfoDto.getAddtnlInfo());
                // }
                //
                // }
                // }
                // }
                // }
                //
                // }
                // ---------------------------------------------------------------------

                // 2) Figure out process action code
                Integer processActionCode = ProcessActionsMap.packageTransactionTypeProcessActionMap
                    .get(originalTransactionCategory);

                // Create Outbound Transaction
                // if (CollectionUtils.isEmpty(originalTransactionDto.getIntlIrTaskXrefDtoList())) {
                // throwMTSServiceFault("mts.irregularity.transaction.reference", ExceptionReasonCode.RETRYABLE_ERROR);
                // }
                // BigDecimal fileNumber = BigDecimal.valueOf(Integer.valueOf(
                // originalTransactionDto.getIntlIrTaskXrefDtoList().get(0).getIntlIrTaskDto().getFileNumber()));
                ProcessActionsMeta processActionMeta = new ProcessActionsMeta();
                processActionMeta.setFileNumber(new BigDecimal(originalTransactionDto.getDmstcApltnNbr()));
                processActionMeta.setProcessCode(processActionCode);
                processActionMeta.setExtensionCounter("0");
                processActionMeta.setIrNumber(intlIrTranDto.getIntlRegNo());
                processActionMeta.setProcessActionCodeType(
                    ProcessActionsMap.allProcessActionCodesMap.get(processActionCode).getProcessActionCodeType());
                processActionMeta.setIrregularityResend(true);
                processActionMeta.setAuthorityId(authorityId);
                String lang = madridIrregularityNotificationType.getNotificationLanguage().value();
                processActionMeta.setAdditionalInfo(ManualReportUtil.getResponseToIrregularityMcKey()
                    + ManualReportUtil.getResponseToIrregularity(lang));
                processActionMeta.setWipoReferenceNumber(originalTransactionDto.getOfficeRefId());

                // 3) Process - re-Use
                if (isManual(processActionMeta)) {

                    // checkIfMF3a(processActionMeta, originalTransactionDto);

                    ManualProcessResponse manualProcessResponse = madridTransactionService
                        .createOfficeToIbManualTask(processActionMeta);

                    duplicateIrregularResponse.getConsoleTaskBag().addAll(manualProcessResponse.getConsoleTaskBag());
                } else {
                    madridTransactionService.createOfficeToIbTransaction(processActionMeta);
                }
            }

        } catch (Exception e) {
            logger.error("Error processing irregularity transaction duplication.");
            throwMTSServiceFault("mts.irregularity.transaction.reference", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        return duplicateIrregularResponse;
    }

    /*
     * private void checkIfMF3a(ProcessActionsMeta processActionMeta, IntlIrTranDto originalTransactionDto) {
     *
     * if (processActionMeta.getProcessActionCodeType() == ProcessActionCodeType.MADRID_PROVISIONAL_REFUSAL_MF_3) {
     *
     * // Assign the duplicated manual task based on the type of report, statement of opposition, or // examiners
     * report, that was received with the original manual task List<IntlAtchmtDto> atchmtDtoList =
     * originalTransactionDto.getIntlAtchmtDtoList(); for (IntlAtchmtDto intlAtchmtDto : atchmtDtoList) { if
     * (IntlAtchmtTypeCode.getAtchmtTypeByValue(intlAtchmtDto.getAtchmtCtgryId() .toString()) ==
     * IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS_RECEIVED) {
     *
     * if (intlAtchmtDto.getFileName().toUpperCase().contains("SO_")) {
     * processActionMeta.setAuthorityId(SectionAuthority.MC_TMOB_OPERATOR.name()); } else {
     * processActionMeta.setAuthorityId(SectionAuthority.MC_TM_EXAMINER.name()); } } } } }
     */
    private boolean isManual(ProcessActionsMeta processActionMeta) {
        ProcessActionMapBean processActionMapBean = null;
        if (ProcessActionsMap.manualProcessActionCodesMap
            .containsKey(Integer.valueOf(processActionMeta.getProcessCode()))) {

            processActionMapBean = ProcessActionsMap.manualProcessActionCodesMap
                .get(Integer.valueOf(processActionMeta.getProcessCode()));

            processActionMeta.setProcessActionCodeType(processActionMapBean.getProcessActionCodeType());

        } else if (ProcessActionsMap.notificationProcessActionCodesMap
            .containsKey(Integer.valueOf(processActionMeta.getProcessCode()))) {

            processActionMapBean = ProcessActionsMap.notificationProcessActionCodesMap
                .get(Integer.valueOf(processActionMeta.getProcessCode()));
        }

        if (null != processActionMapBean) {
            processActionMeta.setProcessActionCodeType(processActionMapBean.getProcessActionCodeType());
            return true;
        }
        return false;
    }
}
