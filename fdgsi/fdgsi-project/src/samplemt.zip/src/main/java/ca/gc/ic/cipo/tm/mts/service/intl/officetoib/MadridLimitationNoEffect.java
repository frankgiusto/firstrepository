package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridLimitationNoEffectType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.LimitationNoEffectMF13Type;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;

public class MadridLimitationNoEffect extends OfficeToIbBase implements IOutboundTransaction, IReportingService {

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_LIMITATION_NO_EFFECT;

    private static Logger log = Logger.getLogger(MadridLimitationNoEffect.class.getName());

    private final static String reportName = "MADRID_MF13";

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        MadridLimitationNoEffectType transaction = objectFactory.createMadridLimitationNoEffectType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // International Registration Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // International Registration Date. Must be format of yyyy-MM-dd string.
        if (outboundTransactionRequest.getInternationalRegistrationDate() != null) {
            String dateString = DateFormats.getISOSDF().format(outboundTransactionRequest.getInternationalRegistrationDate());
            transaction.setInternationalRegistrationDate(dateString);
        }

        // Holder Bag
        transaction.setHolderBag(
            super.mapHolder(processActionApplication.getTmInterestedPartyTypeList(), notificationLanguage));

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Document Included Bag
        List<String> documents = new ArrayList<>();
        String includedDocName = getUniqueReportName(reportName, outboundTransactionDto.getIntlRegNo(),
            intlIrTranDto.getIrTranId().toString());

        StringBuilder documentName = createDocument(includedDocName);
        documents.add(documentName.toString());
        transaction.setDocumentIncludedBag(super.mapDocumentBag(documents));

        JAXBElement<MadridLimitationNoEffectType> madridobject = objectFactory
            .createMadridLimitationNoEffect(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {

        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return true;
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        ProcessManualReportRequest manualReportRequest = (ProcessManualReportRequest) inObject;

        LimitationNoEffectMF13Type notificationType = manualReportRequest.getManualReportForm()
            .getLimitationNoEffectMF13Type();

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(OfficeToIbBase.xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, OfficeToIbBase.reportXpath);

        String tagName = OfficeToIbBase.xmltagName_ORID;
        String value = formatValue(manualReportRequest.getIpOffice());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        MadridLimitationNoEffectType transObj = marshallingService.unmarshallOutboundTransaction(tranId);
        tagName = OfficeToIbBase.xmltagName_NL;
        value = transObj.getNotificationLanguage().value();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_IR;
        value = formatValue(manualReportRequest.getIrNumber());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_HOLDER;
        value = manualReportRequest.getOwnerName();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // IV
        tagName = "ReasonsForLimitationNoEffect";
        value = formatValue(notificationType.getReasonsForLimitation());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // V
        tagName = "CorrespondingEssentialProvisions";
        value = formatValue(notificationType.getEssentialProvisionsLaw());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // VI (tbd affetced all or partial)
        tagName = "AffectedText";
        value = formatValue(notificationType.getGoodsAndServicesLimitation());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // VII static text

        tagName = OfficeToIbBase.xmltagName_SIGN;
        XMLTagUtil.appendTag(xmlDataSource, tagName);

        tagName = OfficeToIbBase.xmltagName_IBNDate;
        value = formatValue(manualReportRequest.getSystemDate().toString());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        XMLTagUtil.appendTagClose(xmlDataSource, OfficeToIbBase.reportXpath);
        log.debug(xmlDataSource.toString());

        Locale locale = ((manualReportRequest.getLanguageCode().equalsIgnoreCase(LOCAL_EN)) ? Locale.CANADA
            : Locale.CANADA_FRENCH);

        String jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(),
            (MtsStringUtil.SLASH + OfficeToIbBase.reportXpath), reportName, null, locale);

        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);
        String includedDocName = getUniqueReportName(reportName, manualReportRequest.getIrNumber(),
            manualReportRequest.getTransactionId().toString());
        madridReportResponse.setReportName(includedDocName);

        return madridReportResponse;

    }

}
