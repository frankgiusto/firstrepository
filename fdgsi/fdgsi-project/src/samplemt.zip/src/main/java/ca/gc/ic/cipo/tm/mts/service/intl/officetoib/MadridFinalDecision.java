package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridFinalDecisionType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MarkDisclaimerBagType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;

public class MadridFinalDecision extends OfficeToIbBase implements IOutboundTransaction, IReportingService {

    private static Logger log = Logger.getLogger(MadridFinalDecision.class.getName());

    private boolean pdfRequired = true;

    private final static String reportNameMf5 = "MADRID_MF5";

    private final static String reportNameMf6 = "MADRID_MF6";

    private MadridOutboundTransactionType madridOutboundTransactionType = null;

    public MadridFinalDecision(MadridOutboundTransactionType madridOutboundTransactionType) {
        this.madridOutboundTransactionType = madridOutboundTransactionType;
    }

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        TrademarkApplicationDetailsType trademarkApplicationDetailsType = processActionApplication
            .getTrademarkApplicationDetailsType();
        MadridFinalDecisionType transaction = objectFactory.createMadridFinalDecisionType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Holder Bag
        transaction.setHolderBag(
            super.mapHolder(processActionApplication.getTmInterestedPartyTypeList(), notificationLanguage));

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Document Included Bag
        List<String> documents = new ArrayList<>();

        String includedDocName = null;
        if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5) {
            // transaction.setSe
            transaction.setGrantProtectionIndicator(new Boolean(true));

            // Disclaimer
            transaction.setMarkDisclaimerBag(setDisclaimer(trademarkApplicationDetailsType.getTradmarkDetails()));

            // Partial Goods Services Bag - John email june 19, 2018
            transaction.setPartialGoodsServicesBag(mapGoodsServices(processActionApplication.getGoodsAndServices()));

            includedDocName = getUniqueReportName(reportNameMf5, outboundTransactionDto.getIntlRegNo(),
                intlIrTranDto.getIrTranId().toString());

        } else if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF6) {
            transaction.setAllGoodsServicesIndicator(new Boolean(true));
            transaction.setRefusalProtectionIndicator(new Boolean(true));

            includedDocName = getUniqueReportName(reportNameMf6, outboundTransactionDto.getIntlRegNo(),
                intlIrTranDto.getIrTranId().toString());
        }

        StringBuilder documentName = createDocument(includedDocName);
        documents.add(documentName.toString());

        // Referring to the doc SUC 1.3, no document is attached to the task or the form from Intrepid.
        // This report comes from Intrepid.
        if (StringUtils.isNotBlank(outboundTransactionRequest.getAdditionalInfo()) && !outboundTransactionRequest
            .getAdditionalInfo().startsWith(ManualReportUtil.getResponseToIrregularityMcKey())) {
            String[] additionalInfos = MtsStringUtil.splitDocName(outboundTransactionRequest.getAdditionalInfo());
            for (String additionalInfo : additionalInfos) {
                documentName = createDocument(additionalInfo.trim(), intlIrTranDto.getIrTranId());
                documents.add(documentName.toString());
            }
        }

        transaction.setDocumentIncludedBag(super.mapDocumentBag(documents));

        JAXBElement<MadridFinalDecisionType> madridobject = objectFactory.createMadridFinalDecision(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        MadridFinalDecisionType notificationType = marshallingService.unmarshallOutboundTransaction(tranId);

        Locale locale = ((notificationType.getNotificationLanguage().value().equalsIgnoreCase(LOCAL_EN)) ? Locale.CANADA
            : Locale.CANADA_FRENCH);

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(OfficeToIbBase.xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, OfficeToIbBase.reportXpath);

        String tagName = OfficeToIbBase.xmltagName_ORID;
        String value = formatValue(notificationType.getOfficeReferenceIdentifier().getValue());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_NL;
        value = formatValue(notificationType.getNotificationLanguage().value());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_IR;
        value = formatValue(notificationType.getInternationalRegistrationNumber());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_HOLDER;
        value = buildHolderValue(notificationType.getHolderBag());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        String reportName = (this.madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5
            ? reportNameMf5 : reportNameMf6);

        if (reportName.equalsIgnoreCase(reportNameMf5)) {

            // build IV
            value = buildTagIVValue(notificationType.getPartialGoodsServicesBag(), locale);
            xmlDataSource.append(value);

            // build V
            value = buildTagVValue(notificationType.getMarkDisclaimerBag(), locale);
            xmlDataSource.append(value);

        }

        tagName = OfficeToIbBase.xmltagName_SIGN;
        XMLTagUtil.appendTag(xmlDataSource, tagName);

        tagName = OfficeToIbBase.xmltagName_IBNDate;
        value = formatValue(notificationType.getRecordNotificationDate());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // close tag
        XMLTagUtil.appendTagClose(xmlDataSource, OfficeToIbBase.reportXpath);
        log.debug(xmlDataSource.toString());

        String jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(),
            (MtsStringUtil.SLASH + OfficeToIbBase.reportXpath), reportName, null, locale);

        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);
        String includedDocName = getUniqueReportName(reportName, notificationType.getInternationalRegistrationNumber(),
            tranId.toString());
        madridReportResponse.setReportName(includedDocName);

        return madridReportResponse;
    }

    // @formatter:off
    /**
     *
     * @param locale
     * @return list of <GoodService> NICE_CLASS_CODE, SEQUENCE NUMBER, TEXT VALUE</GoodService>
     *
     */
    // @formatter:oon
    private String buildTagIVValue(GoodsServicesBagType goodsServicesBag, Locale locale) {
        StringBuilder rtnValue = new StringBuilder();

        String tagIV = "GoodServiceCodeText";
        if (goodsServicesBag == null) {
            return OfficeToIbBase.buildEmptyTag(tagIV);
        }

        List<GoodsServicesType> goodsServices = goodsServicesBag.getGoodsServices();
        if ((goodsServices == null) || goodsServices.isEmpty()) {
            return OfficeToIbBase.buildEmptyTag(tagIV);
        }
        XMLTagUtil.appendTagStart(rtnValue, tagIV);
        for (GoodsServicesType goodsService : goodsServices) {
            ClassDescriptionBagType classDescriptionBag = goodsService.getClassDescriptionBag();
            if (classDescriptionBag == null) {
                continue;
            }

            List<ClassDescriptionType> classDescriptions = classDescriptionBag.getClassDescription();
            if (classDescriptions == null || classDescriptions.isEmpty()) {
                continue;
            }

            for (ClassDescriptionType classDescription : classDescriptions) {

                List<OrderedTextType> orderedTexts = classDescription.getGoodsServicesDescriptionText();
                if (orderedTexts == null || orderedTexts.isEmpty()) {
                    continue;
                }

                for (OrderedTextType orderedText : orderedTexts) {

                    if (orderedText.getLanguageCode().equals(locale.getLanguage())) {
                        String classnumber = classDescription.getClassNumber();
                        String textValue = orderedText.getValue();

                        if ((classnumber != null && !classnumber.isEmpty()) || (textValue != null && !textValue.isEmpty())) {

                            if (classnumber != null) {
                                rtnValue.append(formatValue(MtsStringUtil.LEFT_BRACKET));
                                rtnValue.append(formatValue(classnumber));
                                rtnValue.append(formatValue(MtsStringUtil.RIGHT_BRACKET));
                            } else {
                                rtnValue.append(MtsStringUtil.EMPTY);
                            }

                            if (textValue != null) {
                                rtnValue.append(formatValue(MtsStringUtil.SPACE));
                                rtnValue.append(formatValue(textValue));
                            }

                            rtnValue.append(MtsStringUtil.DOUBLE_LINE_CHANGE);

                        }
                    }

                }
            }

        }
        XMLTagUtil.appendTagClose(rtnValue, tagIV);
        return ((rtnValue.length() < 1) ? OfficeToIbBase.buildEmptyTag(tagIV): rtnValue.toString());
    }

    // @formatter:off
    /**
     *
     * @param locale
     * @return list of <DisclaimerCodeText> SEQUENCE NUMBER, TEXT</DisclaimerCodeText>
     */
    // @formatter:oon
    private String buildTagVValue(MarkDisclaimerBagType markDisclaimerType, Locale locale) {
        StringBuilder rtnValue = new StringBuilder();

        String tagV = "DisclaimerCodeText";

        if (markDisclaimerType == null) {
            return OfficeToIbBase.buildEmptyTag(tagV);
        }

        List<OrderedTextType> markDisclaimerTexts = markDisclaimerType.getMarkDisclaimerText();

        if ((markDisclaimerTexts == null) || markDisclaimerTexts.isEmpty()) {
            return OfficeToIbBase.buildEmptyTag(tagV);
        }

        XMLTagUtil.appendTagStart(rtnValue, tagV);

        for (OrderedTextType markDisclaimerText : markDisclaimerTexts) {
            if ( (markDisclaimerText == null) || markDisclaimerText.getValue().isEmpty()) {
                continue;
            }
            if (markDisclaimerText.getLanguageCode().equals(locale.getLanguage())) {
                String codeValue = markDisclaimerText.getSequenceNumber();
                String codeText = markDisclaimerText.getValue();

                if ((codeValue != null && !codeValue.isEmpty()) || (codeText != null && !codeText.isEmpty())) {
                    if (codeValue != null) {
                        rtnValue.append(formatValue(codeValue));
                    } else {
                        rtnValue.append(MtsStringUtil.EMPTY);
                    }

                    if (codeText != null) {
                        rtnValue.append(formatValue(", "));
                        rtnValue.append(formatValue(codeText));
                    } else {
                        rtnValue.append(MtsStringUtil.EMPTY);
                    }

                }
                rtnValue.append(MtsStringUtil.DOUBLE_LINE_CHANGE);
            }

        }
        XMLTagUtil.appendTagClose(rtnValue, tagV);

        return ((rtnValue.length() < 1) ? OfficeToIbBase.buildEmptyTag(tagV) : rtnValue.toString());
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return pdfRequired;
    }

}
