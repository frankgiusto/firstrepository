package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;

public class MadridApplicationXrefDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    //
    private Integer fileNumber;

    private Integer extensionCounter;

    public Integer getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(Integer fileNumber) {
        this.fileNumber = fileNumber;
    }

    public Integer getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(Integer extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

}
