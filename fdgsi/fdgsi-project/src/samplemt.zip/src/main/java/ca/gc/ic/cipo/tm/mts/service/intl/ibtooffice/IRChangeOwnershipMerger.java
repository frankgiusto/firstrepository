/*
 *
 */
package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

@Service(value = "irOwnershipChangeMerger")
public class IRChangeOwnershipMerger extends MadridTransactionService implements IIROwnershipChangeMerger {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private FootNotesDao footnotesDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(IRChangeOwnershipMerger.class.getName());

    @Override
    @Transactional
    public Map<ApplicationDto, UserTaskType> processIRChangeOwnershipMerger(TransactionPairDto ownershipChangePartial)
        throws MTSServiceFault {

        logger.debug("Processing IR Change Merger -  Intl Record Id:"
            + ownershipChangePartial.getMadridDesignationTransaction().getIntlRecordId());
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        // Get all applications matching transactions international registration number of the Designation Termination.

        List<IntlIrTaskDto> taskList = ownershipChangePartial.getIntlIrTaskList();

        if (CollectionUtils.isNotEmpty(ownershipChangePartial.getIntlIrTaskList())) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                // Record Applications with the same IR Number
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    // Update IR Number with the ir number of designation Merger
                    application.setIrNumber(ownershipChangePartial.getMadridDesignationTransaction().getIntlRegNo());
                    applicationDao.saveApplication(application);

                    actionDao.saveAction(
                        createAction(application, ActionCode.OWNERSHIP_CHANGE_MERGER, SectionAuthority.AAR.name()));

                    if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue()
                        .intValue()) {

                        Footnote footnote = new Footnote();
                        footnote.setApplication(application);
                        footnote.setFileNumber(application.getFileNumber());
                        footnote.setExtensionCounter(application.getExtensionCounter());
                        footnote.setSequenceNumber(getNextFootnoteSequence(application.getFootnotes()));
                        footnote.setType(FootnoteType.OWNERSHIP_CHANGE_MERGER.getValue());
                        footnote.setDateRegistered(new Date());
                        footnote.setText("IR Onwership Merger"); // TODO confirm

                        footnotesDao.saveFootNote(footnote);

                        application.getFootnotes().add(footnote);
                        applicationDao.saveApplication(application);

                        // process opposition cases
                        if (openOppositionCases(application, registeredOppositionCaseTypes)) {
                            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                                OfficeType.DO);
                            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            statusTypeResults.put(applicationDto, UserTaskType.OWNERSHIP_CHANGE_MERGER_OCCURRED);
                        }

                    } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                        .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                        // process opposition cases
                        if (openOppositionCases(application, unRegisteredOppositionCaseTypes)) {

                            // This is for creating notifications
                            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                                OfficeType.DO);
                            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());

                            statusTypeResults.put(applicationDto, UserTaskType.OWNERSHIP_CHANGE_MERGER_OCCURRED);
                        }
                    }

                }

            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    @Override
    public String getServiceName() {
        return "IRChangeOwnershipPartialService";
    }

}
