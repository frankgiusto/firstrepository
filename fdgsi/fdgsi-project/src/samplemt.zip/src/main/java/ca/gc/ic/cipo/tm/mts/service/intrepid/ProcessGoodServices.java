package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesTextDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationXrefDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.NiceReferenceDao;
import ca.gc.ic.cipo.tm.dao.PhysicalFilesDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.CorrespondenceType;
import ca.gc.ic.cipo.tm.enumerator.FileType;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationStatus;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.GoodServiceComparator;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.NiceReference;
import ca.gc.ic.cipo.tm.model.PhysicalFiles;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType;
import ca.gc.ic.cipo.tm.mts.LocalizedTextType;
import ca.gc.ic.cipo.tm.mts.OrderedTextType;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.GoodsServiceAction;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.ICourtesyLetterService;
import ca.gc.ic.cipo.tm.mts.service.MadridConsoleService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;

@Service
public class ProcessGoodServices extends MadridTransactionService implements IRProcessGoodServices {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private MailDao mailDao;

    @Autowired
    private GoodsServicesClaimDao goodsServicesClaimDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private GoodsServicesDao goodsServicesDao;

    @Autowired
    NiceReferenceDao niceReferenceDao;

    @Autowired
    private PhysicalFilesDao physicalFilesDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private FootNotesDao footnotesDao;

    @Autowired
    private GoodsServicesTextDao goodsServicesTextDao;

    @Autowired
    private ClaimDao claimDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Autowired
    MadridApplicationXrefDao madridApplicationXrefDao;

    @Autowired
    private ICourtesyLetterService courtestyLetterService;

    private static final boolean ADJUSTMENT = true;

    private static final boolean NO_ADJUSTMENT = false;

    private static final boolean ACCEPT_ALL = true;

    private static final boolean NOT_ACCEPT_ALL = false;

    private static Logger logger = Logger.getLogger(MadridConsoleService.class.getName());

    @Override
    @Transactional(rollbackFor = Exception.class)
    public GoodsServiceAction processDOPartialCeasingEffect(GoodsAndServiceMeta gsInfo, String recordEffectiveDate)
        throws CIPOServiceFault {

        GoodsServiceAction goodsServiceAction = GoodsServiceAction.NO_ACTION;
        Application application = getApplicationfromGsInfo(gsInfo);
        String authorityId = gsInfo.getAuthorityId();

        LanguageType applicationLanguage = this
            .getApplicationLanguage(ISOLanguageCodeType.fromValue(gsInfo.getNotificationLanguage()));

        if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT) {
            // Action 'Partial Ceasing Effect Received-No Effect' is created
            Action action = createNewAction(application, ActionCode.PARTIAL_CEASING_OF_EFFECT_RECEIVED_NOEFFECT,
                recordEffectiveDate);
            action.setAuthorityId(authorityId);
            actionDao.saveAction(action);

        } else if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT) {
            if (gsInfo.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())) {

                Action action = createAction(application, ActionCode.PARTIAL_CANCELLATION,
                    ActionCode.PARTIAL_WITHDRAWAL, recordEffectiveDate);
                action.setAuthorityId(authorityId);
                actionDao.saveAction(action);

                updateDeleteAddGoodsServices(gsInfo.getMergedGoodServices().getTaskListBag(), application,
                    applicationLanguage, ADJUSTMENT, ACCEPT_ALL);

                // applicationDao.saveApplication(application);

            } else {
                // To do create task for SUC2.6.1 Ceasing Effect Total
                goodsServiceAction = GoodsServiceAction.TOTAL_CEASING_EFFECT;
            }

        } else if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_ALL) {

            Action action = createAction(application, ActionCode.PARTIAL_CANCELLATION, ActionCode.PARTIAL_WITHDRAWAL,
                recordEffectiveDate);
            action.setAuthorityId(authorityId);
            actionDao.saveAction(action);

            if (gsInfo.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())) {

                updateDeleteAddGoodsServices(gsInfo.getMergedGoodServices().getTaskListBag(), application,
                    applicationLanguage, NO_ADJUSTMENT, ACCEPT_ALL);

                applicationDao.saveApplication(application);
            } else {
                // To do create task for SUC2.6.1 Ceasing Effect Total
                goodsServiceAction = GoodsServiceAction.TOTAL_CEASING_EFFECT;
            }
        }
        return goodsServiceAction;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public GoodsServiceAction processDOPartialCancelation(GoodsAndServiceMeta gsInfo, String recordEffectiveDate)
        throws CIPOServiceFault {
        Application application = getApplicationfromGsInfo(gsInfo);
        GoodsServiceAction goodsServiceAction = GoodsServiceAction.NO_ACTION;

        LanguageType applicationLanguage = this
            .getApplicationLanguage(ISOLanguageCodeType.fromValue(gsInfo.getNotificationLanguage()));

        if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT) {
            Action action = createNewAction(application, ActionCode.PARTIAL_CANCELLATION_RECEIVED_NO_ADJUSTMENT,
                recordEffectiveDate);
            action.setAuthorityId(gsInfo.getAuthorityId());
            actionDao.saveAction(action);

        } else if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT) {

            if (gsInfo.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())) {

                Action action = createAction(application, ActionCode.PARTIAL_CANCELLATION_OWNERS_REQUEST,
                    ActionCode.PARTIAL_WITHDRAWAL_OWNERS_REQUEST, recordEffectiveDate);
                action.setAuthorityId(gsInfo.getAuthorityId());
                actionDao.saveAction(action);

                updateDeleteAddGoodsServices(gsInfo.getMergedGoodServices().getTaskListBag(), application,
                    applicationLanguage, ADJUSTMENT, ACCEPT_ALL);

                // applicationDao.saveApplication(application);

            } else {
                goodsServiceAction = GoodsServiceAction.TOTAL_CANCELLATION;
            }

        } else if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_ALL) {

            Action action = createAction(application, ActionCode.PARTIAL_CANCELLATION_OWNERS_REQUEST,
                ActionCode.PARTIAL_WITHDRAWAL_OWNERS_REQUEST, recordEffectiveDate);
            action.setAuthorityId(gsInfo.getAuthorityId());
            actionDao.saveAction(action);

            if (gsInfo.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())) {

                updateDeleteAddGoodsServices(gsInfo.getMergedGoodServices().getTaskListBag(), application,
                    applicationLanguage, NO_ADJUSTMENT, ACCEPT_ALL);

                applicationDao.saveApplication(application);
            } else {
                goodsServiceAction = GoodsServiceAction.TOTAL_CANCELLATION;
            }
        }
        return goodsServiceAction;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public GoodsServiceAction processDOGoodServiceLimitation(GoodsAndServiceMeta gsInfo, String recordEffectiveDate,
                                                             ActionCode actionCode)
        throws CIPOServiceFault {

        logger.debug("gsInfo.getTaskType: " + gsInfo.getTaskType().value());

        Application application = getApplicationfromGsInfo(gsInfo);
        GoodsServiceAction goodsServiceAction = GoodsServiceAction.NO_ACTION;

        if (actionCode != null) {
            Action actionToUpdate = createNewAction(application, actionCode, null);
            actionToUpdate.setAuthorityId(gsInfo.getAuthorityId());
            actionDao.saveAction(actionToUpdate);
        }

        LanguageType applicationLanguage = this
            .getApplicationLanguage(ISOLanguageCodeType.fromValue(gsInfo.getNotificationLanguage()));

        if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT) {

            if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.GOOD_SERVICE_LIMITATION.value())) {

                Action action = createNewAction(application, ActionCode.LIMITATION_NOEFFECT, recordEffectiveDate);
                action.setAuthorityId(gsInfo.getAuthorityId());
                actionDao.saveAction(action);

                applicationDao.saveApplication(application);
            }

            goodsServiceAction = GoodsServiceAction.MADRID_LIMITATION_NO_EFFECT;

        } else if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT) {

            if (gsInfo.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())) {

                if (recordEffectiveDate != null
                    && gsInfo.getTaskType().value().equals(GoodServiceTaskType.GOOD_SERVICE_LIMITATION.value())) {

                    Action action = createNewAction(application, ActionCode.PARTIAL_GOODSSERVICES_LIMITATION,
                        recordEffectiveDate);
                    action.setAuthorityId(gsInfo.getAuthorityId());
                    actionDao.saveAction(action);

                    if (TradeMarkStatusType.REGISTERED == TradeMarkStatusType.getByValue(application.getStatusCode())) {
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.REGISTRATION_PAGES, gsInfo.getAuthorityId()));
                    } else {
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.CLIENT_PROOF_SHEET, SectionAuthority.MADRID.name())); // TMMADCON-2142

                    }
                }

                // The console passed all merged GS and their translations. MTS just store as is.
                updateDeleteAddGoodsServices(gsInfo.getMergedGoodServices().getTaskListBag(), application,
                    applicationLanguage, ADJUSTMENT, ACCEPT_ALL);

                // applicationDao.saveApplication(application);

                goodsServiceAction = GoodsServiceAction.MADRID_LIMITATION_NO_EFFECT;

            } else {
                goodsServiceAction = GoodsServiceAction.TOTAL_CANCELLATION;
            }

        } else if (gsInfo.getUserSelectType() == GoodServiceSelectionType.ACCEPT_ALL) {

            Action action = createNewAction(application, ActionCode.TOTAL_GOODSSERVICES_LIMITATION,
                recordEffectiveDate);
            action.setAuthorityId(gsInfo.getAuthorityId());
            actionDao.saveAction(action);

            if (gsInfo.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())) {

                updateDeleteAddGoodsServices(gsInfo.getMergedGoodServices().getTaskListBag(), application,
                    applicationLanguage, NO_ADJUSTMENT, ACCEPT_ALL);

            } else {
                goodsServiceAction = GoodsServiceAction.TOTAL_CANCELLATION;
            }
            applicationDao.saveApplication(application);
        }
        return goodsServiceAction;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Integer processPartialOwnership(IntlIrTranDto intlIrTransaction, String notificationLanguage,
                                           PartialOwnershipMeta designation, PartialOwnershipMeta restriction)
        throws CIPOServiceFault {

        MadridPartialChangeOwnershipType madridPartialChangeOwnershipType = null;

        try {
            madridPartialChangeOwnershipType = unmarshallTransaction(intlIrTransaction);
        } catch (Exception exception) {
            throwCIPOFault(exception);
        }
        // Get application language
        LanguageType applicationLanguage = getApplicationLanguage(
            madridPartialChangeOwnershipType.getMadridDesignation().getNotificationLanguage());

        // Create new application from original designation an apply required updates
        Application newApplication = updateNewApplication(madridPartialChangeOwnershipType.getMadridDesignation(),
            designation.getFileNumber(), designation.getExtensioncounter(), designation.getAuthorityId());

        applicationDao.saveApplication(newApplication);

        // Get the original application
        Application originalApplication = applicationDao.getApplication(restriction.getFileNumber().intValue(),
            Integer.valueOf(restriction.getExtensioncounter()));

        // Update the original application
        updateOriginalApplication(originalApplication, madridPartialChangeOwnershipType,
            newApplication.getFileNumber().toString(), designation.getAuthorityId());

        // Update Goods and Services for the new file if the merged goods/serivces is not empty.
        if (designation.getMergedGoodServices() != null && designation.getMergedGoodServices().getTaskListBag() != null
            && !designation.getMergedGoodServices().getTaskListBag().isEmpty()) {
            updateDeleteAddGoodsServices(designation.getMergedGoodServices().getTaskListBag(), newApplication,
                applicationLanguage, ADJUSTMENT, ACCEPT_ALL);
        }

        // Update Goods and Services for the original file if the merged goods/services is not empty.
        if (restriction.getMergedGoodServices() != null && restriction.getMergedGoodServices().getTaskListBag() != null
            && !restriction.getMergedGoodServices().getTaskListBag().isEmpty()) {
            updateDeleteAddGoodsServices(restriction.getMergedGoodServices().getTaskListBag(), originalApplication,
                applicationLanguage, ADJUSTMENT, ACCEPT_ALL);
        }

        applicationDao.copyFiles(newApplication.getFileNumber(), newApplication.getExtensionCounter(),
            originalApplication.getFileNumber(), originalApplication.getExtensionCounter());

        return newApplication.getFileNumber();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void processIRCorrectionActions(ProcessIRCorrectionSubmissionRequest request, String recordEffecitiveDate,
                                           String recordNotificationDate)
        throws CIPOServiceFault {

        Application application = getApplicationfromRequest(request);

        if (request.isIsResetMonthPeriod()) { // yes

            // create action with action code = IR Correction
            Action action1 = createNewAction(application, ActionCode.IR_CORRECTION, recordEffecitiveDate);
            action1.setAuthorityId(request.getAuthorityId());
            actionDao.saveAction(action1);

            // create action with action code = MADRID_DESIGNATION_NOTIFICATION
            Action action2 = createNewAction(application, ActionCode.MADRID_DESIGNATION_NOTIFICATION,
                recordNotificationDate);
            action2.setAuthorityId(request.getAuthorityId());
            actionDao.saveAction(action2);

        } else {// no
            // create action with action code = IR Correction
            Action action = createNewAction(application, ActionCode.IR_CORRECTION, recordEffecitiveDate);
            action.setAuthorityId(request.getAuthorityId());
            actionDao.saveAction(action);

        }
        applicationDao.saveApplication(application);
    }

    @Override
    @Transactional
    public List<MadridApplicationXref> getMadridApplicationXREFList(String IR_number) throws CIPOServiceFault {
        List<MadridApplication> result = madridApplicationDao.getMadridApplicationByIrNumber(IR_number);
        if (result.isEmpty()) {
            throwMTSServiceFault("mts.missing.madrid.application", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        MadridApplication madridApplication = result.get(0);
        List<MadridApplicationXref> xrefList = madridApplication.getMadridApplicationXrefs();
        xrefList.size();
        return xrefList;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateMadridApplicationXREF(String IR_number,
                                            List<ca.gc.ic.cipo.tm.mts.ApplicationNumber> barNumberList)
        throws CIPOServiceFault {

        List<MadridApplication> result = madridApplicationDao.getMadridApplicationByIrNumber(IR_number);
        if (result.isEmpty()) {
            throwMTSServiceFault("mts.missing.madrid.application", ExceptionReasonCode.MARK_NOT_FOUND);
        }

        // Get Madrid Application
        MadridApplication madridApplication = result.get(0);
        List<MadridApplicationXref> xrefList = madridApplication.getMadridApplicationXrefs();

        // Remove Xref not in the mark list
        List<MadridApplicationXref> xrefToRemoveList = new ArrayList<MadridApplicationXref>();
        for (MadridApplicationXref xref : xrefList) {
            boolean xrefFound = false;

            for (ca.gc.ic.cipo.tm.mts.ApplicationNumber bar : barNumberList) {
                if (bar.getFileNumber() != null && bar.getFileNumber().intValue() == xref.getFileNumber()
                    && bar.getExtensionCounter() != null
                    && Integer.parseInt(bar.getExtensionCounter()) == xref.getExtensionCounter()) {
                    xrefFound = true;
                    break;
                }
            }

            if (!xrefFound) {
                xrefToRemoveList.add(xref);
            }
        }

        for (MadridApplicationXref xref : xrefToRemoveList) {
            madridApplicationXrefDao.deleteMadridApplicationXref(xref.getFileNumber(), xref.getExtensionCounter(),
                xref.getWipoReferenceNumber());
        }

        logger.debug("Update Madrid Application XREF ");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addNewMadridApplicationAction(String internationalRegistrationNumber, String authorityId,
                                              BigDecimal irTranId,
                                              MadridApplicationActionStatus madridApplicationActionStatus)
        throws CIPOServiceFault {
        addNewMadridApplicationAction(internationalRegistrationNumber, authorityId, irTranId,
            madridApplicationActionStatus, false);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addNewMadridApplicationAction(String internationalRegistrationNumber, String authorityId,
                                              BigDecimal irTranId,
                                              MadridApplicationActionStatus madridApplicationActionStatus,
                                              boolean closeAIR)
        throws CIPOServiceFault {

        List<MadridApplication> madridApplicationList = madridApplicationDao
            .getMadridApplicationByIrNumber(internationalRegistrationNumber);
        if (CollectionUtils.isEmpty(madridApplicationList)) {
            throwMTSServiceFault("mts.missing.madrid.application", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        // Get Madrid Application
        MadridApplication madridApplication = madridApplicationList.get(0);
        String wipoReferenceNumber = madridApplication.getWipoReferenceNumber();
        Date actionDate = new Date();

        MadridApplicationAction madridApplicationAction = createNewMadridApplicationAction(wipoReferenceNumber,
            authorityId, actionDate, irTranId, madridApplicationActionStatus);

        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);
        if (closeAIR) {
            madridApplication.setStatusCode(MadridApplicationStatus.CLOSED.getValue());
            madridApplicationDao.saveMadridApplication(madridApplication);
            List<ProcessAction> processActions = processActionsDao
                .getProcessActionsByReferenceNumber(wipoReferenceNumber);
            for (ProcessAction pa : processActions) {
                processActionsDao.deleteProcessAction(pa);
            }
        }

        madridApplicationList = madridApplicationDao.getMadridApplicationByIrNumber(internationalRegistrationNumber);
        logger.debug("Added madrid application action");
    }

    private MadridApplicationAction createNewMadridApplicationAction(String wipoReferenceNumber, String authorityId,
                                                                     Date actionDate, BigDecimal irTranId,
                                                                     MadridApplicationActionStatus madridApplicationActionStatus) {
        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setActionCode(madridApplicationActionStatus.getValue());
        madridApplicationAction.setActionDate(actionDate);
        madridApplicationAction.setAuthorityId(authorityId);
        madridApplicationAction.setWipoReferenceNumber(wipoReferenceNumber);
        if (irTranId != null) {
            madridApplicationAction.setIrTranId(irTranId.longValue());
        }

        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationAction.setMadridApplicationActionsSeqNumber(madridApplicationActionId);

        return madridApplicationAction;
    }

    private void updateOriginalApplication(Application originalApplication,
                                           MadridPartialChangeOwnershipType madridPartialChangeOwnershipType,
                                           String additionalInfo, String consoleUserId) {
        // Create Action
        String actionAdditionalInfo = "File Number: " + additionalInfo;
        actionDao.saveAction(
            createAction(originalApplication, ActionCode.PARTIAL_OWNERSHIP, consoleUserId, actionAdditionalInfo));

        // Footnote
        logger.debug("New file number for footnote in update original : " + additionalInfo);

        Footnote footnote = this.createFootnote(originalApplication,
            madridPartialChangeOwnershipType.getMadridDesignation());

        footnote.setText("File Number: " + (additionalInfo != null ? additionalInfo : ""));
        originalApplication.getFootnotes().add(footnote);

        footnotesDao.saveFootNote(footnote);

        // Process actions
        processActionsDao.saveProcessActions(createProcessAction(originalApplication,
            ProcessActionsType.CLIENT_PROOF_SHEET, SectionAuthority.MADRID.name(), additionalInfo));
        processActionsDao.saveProcessActions(createProcessAction(originalApplication,
            ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE, SectionAuthority.MADRID.name(), additionalInfo));

        // System updates the Mail Attached Indicator to specify that the mail has been processed in each file
        List<Mail> mailList = mailDao.getMailByFileId(originalApplication.getFileNumber());
        if (CollectionUtils.isNotEmpty(mailList)) {
            for (Mail mail : mailList) {
                mail.setMailAttachedInd(MAIL_PROCESSED_INDICATOR);
                mailDao.saveMail(mail);
            }

        }
    }

    private Application updateNewApplication(MadridDesignationType madridDesignation, BigDecimal originalFileNumber,
                                             String extensionCounter, String consoleUserId)
        throws MTSServiceFault {

        LanguageType applicationLanguage = getApplicationLanguage(madridDesignation.getNotificationLanguage());

        ApplicationNumber newApplicationNumber = applicationDao.copyMark(originalFileNumber.intValue(),
            Integer.valueOf(extensionCounter));

        Application newApplication = applicationDao.getApplication(newApplicationNumber);

        // Add Physical File
        PhysicalFiles physicalFiles = new PhysicalFiles();

        physicalFiles.setLocationAuthorityId(SectionAuthority.EXAMINATION.name());
        physicalFiles.setFileNumber(newApplicationNumber.getFileNumber());
        physicalFiles.setFileType(FileType.TRADE_MARK.getValue());

        physicalFilesDao.savePhysicalFiles(physicalFiles);

        // Interested Party - Set current owner to old owner
        Set<InterestedParty> interestedParties = newApplication.getInterestedParties();
        if (CollectionUtils.isNotEmpty(interestedParties)) {
            for (InterestedParty interestedParty : interestedParties) {
                if (interestedParty.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {

                    // update owner name
                    interestedParty.setRelationshipType(RelationshipType.OLD_OWNER.getValue());
                    applicationLanguage = LanguageType.getByValue(interestedParty.getLanguageOfPreference());

                    interestedPartyDao.saveInterestedParty(interestedParty);
                }
            }
        }
        // Interested Party - create new owner
        InterestedParty newOwnerInterestedParty = createPartialOwnershipChangeInterestedParty(newApplication,
            getNextInterestedPartySequence(interestedParties), applicationLanguage);

        // Create the Contact Information
        setInterestedPartyContact(applicationLanguage, madridDesignation.getHolderBag().getHolder(), newApplication,
            newOwnerInterestedParty);

        // Update the Interested Party Address
        setInterestedPartyAddress(madridDesignation.getHolderBag().getHolder(), newApplication, newOwnerInterestedParty,
            madridDesignation);

        for (InterestedPartiesAddresses eachAddress : newOwnerInterestedParty.getContact()
            .getInterestedPartiesAddresses()) {
            interestedPartiesAddressesDao.saveInterestedPartiesAddresses(eachAddress);
        }

        // update International Registration Number
        newApplication.setIrNumber(madridDesignation.getInternationalRegistrationNumber());

        // Create Action
        String actionAdditionalInfo = "File Number: " + originalFileNumber.intValue();
        actionDao.saveAction(
            createAction(newApplication, ActionCode.PARTIAL_OWNERSHIP, consoleUserId, actionAdditionalInfo));

        // Process actions
        processActionsDao.saveProcessActions(createProcessAction(newApplication, ProcessActionsType.FILE_COVER_LABEL,
            SectionAuthority.MADRID.name(), newApplication.getFileNumber().toString()));
        processActionsDao.saveProcessActions(createProcessAction(newApplication, ProcessActionsType.CLIENT_PROOF_SHEET,
            SectionAuthority.MADRID.name(), newApplication.getFileNumber().toString()));
        processActionsDao.saveProcessActions(createProcessAction(newApplication, ProcessActionsType.EDIT_SHEETS,
            SectionAuthority.MADRID.name(), newApplication.getFileNumber().toString()));
        processActionsDao.saveProcessActions(
            createProcessAction(newApplication, ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE,
                SectionAuthority.MADRID.name(), newApplication.getFileNumber().toString()));

        // Create Footnote
        logger.debug("Original file number for footnote in update new app : " + originalFileNumber);

        Footnote footnote = this.createFootnote(newApplication, madridDesignation);
        footnote.setText("File Number: " + (originalFileNumber != null ? originalFileNumber.intValue() : ""));
        newApplication.getFootnotes().add(footnote);

        footnotesDao.saveFootNote(footnote);

        // System updates the Mail Attached Indicator to specify that the mail has been processed in each file
        List<Mail> mailList = mailDao.getMailByFileId(newApplication.getFileNumber());
        if (CollectionUtils.isNotEmpty(mailList)) {
            for (Mail mail : mailList) {
                mail.setMailAttachedInd(MAIL_PROCESSED_INDICATOR);
                mailDao.saveMail(mail);
            }

        }

        // set LimitationListCode to 2: Limited List - Reviewed
        if (hasGSLimitations(madridDesignation)) {
            newApplication.setLimitationListCode(LIMITATION_LIST_CODE_EXAMINED);
        }

        return newApplication;
    }

    private Footnote createFootnote(Application application, MadridDesignationType madridDesignation) {
        // Create Footnote TODO put in base
        Footnote footnote = new Footnote();
        footnote.setApplication(application);
        footnote.setFileNumber(application.getFileNumber());
        footnote.setExtensionCounter(application.getExtensionCounter());
        footnote.setSequenceNumber(getNextFootnoteSequence(application.getFootnotes()));
        footnote.setType(FootnoteType.PARTIAL_ASSIGNEMENT.getValue());
        footnote.setDateRegistered(new Date());
        try {
            footnote.setDateOfChange(DateFormats.getISOSDF().parse(madridDesignation.getRecordEffectiveDate()));
        } catch (ParseException e) {
            logger.error("Could not parse record effective date:" + madridDesignation.getRecordEffectiveDate());
        }

        return footnote;
    }

    // TODO consolidate similar method in base classes
    private InterestedParty createPartialOwnershipChangeInterestedParty(Application application, int ipNumber,
                                                                        LanguageType applicationLanguage) {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(application.getFileNumber());
        interestedParty.setIpNumber(ipNumber);
        interestedParty.setApplication(application);

        interestedParty.setLanguageOfPreference(applicationLanguage.getValue());
        interestedParty.setExtensionCounter(application.getExtensionCounter());
        interestedParty.setRelationshipType(RelationshipType.OWNER.getValue());
        interestedParty.setCorrespondenceType(CorrespondenceType.PAPER_MAIL.getValue());
        interestedParty.setApplicantInd(1);
        interestedParty.setRegistrantInd(0);

        return interestedParty;
    }

    @Transactional
    private Application getApplicationfromGsInfo(GoodsAndServiceMeta gsInfo) {
        ApplicationNumber appNumber = new ApplicationNumber();
        Integer iFileNum = gsInfo.getFileNumber().intValue();
        appNumber.setFileNumber(iFileNum);
        Integer iCounter = gsInfo.getExtensioncounter() == null ? 0 : Integer.valueOf(gsInfo.getExtensioncounter());
        appNumber.setExtensionCounter(iCounter);
        Application application = applicationDao.getApplication(appNumber);
        return application;
    }

    @Transactional
    private Application getApplicationfromRequest(ProcessIRCorrectionSubmissionRequest request) {
        ApplicationNumber appNumber = new ApplicationNumber();
        Integer iFileNum = request.getFileNumber().intValue();
        appNumber.setFileNumber(iFileNum);
        Integer iCounter = request.getExtensioncounter() == null ? 0 : Integer.valueOf(request.getExtensioncounter());
        appNumber.setExtensionCounter(iCounter);
        Application application = applicationDao.getApplication(appNumber);
        return application;
    }

    private void updateGoodsServiceText(Application application, GoodService goodsService,
                                        GoodsServicesClassificationType goodsServicesClassificationType,
                                        boolean adjustment, boolean acceptAll) {

        List<OrderedTextType> clasTextList = goodsServicesClassificationType.getClassTitleText();

        StringBuilder gsDescriptionTextEnglish = new StringBuilder();
        StringBuilder gsDescriptionTextFrench = new StringBuilder();

        for (LocalizedTextType localizedTextType : clasTextList) {
            if (StringUtils.isNotBlank(localizedTextType.getLanguageCode())) {
                if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.EN.value())) {
                    gsDescriptionTextEnglish.append(localizedTextType.getValue());

                } else if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.FR.value())) {
                    gsDescriptionTextFrench.append(localizedTextType.getValue());

                }
            } else {
                gsDescriptionTextEnglish.append(localizedTextType.getValue());
            }
        }

        List<GoodServiceText> removeStatementTextList = new ArrayList<>();
        boolean englishUpdated = false;
        boolean frenchUpdated = false;
        GoodServiceText englishGSText = null;
        GoodServiceText frenchGSText = null;

        if (gsDescriptionTextEnglish.length() > 0) {
            for (GoodServiceText gsText : goodsService.getGoodServiceTexts()) {
                if (gsText.getNumber().intValue() == goodsService.getNumber().intValue()
                    && gsText.getType().intValue() == goodsService.getType().intValue()
                    && gsText.getLanguage() == LanguageType.ENGLISH.getValue()) {// English

                    if (goodsServicesClassificationType.isModified()) {
                        gsText.setModifiedTimestamp(new Date());
                    }
                    gsText.setText(gsDescriptionTextEnglish.toString());
                    goodsServicesTextDao.saveGoodServiceText(gsText);

                    englishUpdated = true;

                    frenchGSText = createGoodAndService(gsText);
                    frenchGSText.setLanguage(LanguageType.FRENCH.getValue());

                    if (goodsServicesClassificationType.isModified()) {
                        frenchGSText.setModifiedTimestamp(new Date());
                    }

                    frenchGSText.setText(gsDescriptionTextFrench.toString());

                }

            }
        } else {
            // This is for ADJUSTMENTS. Only update the language received and delete the other language text.
            if (adjustment) {
                for (GoodServiceText goodServiceText : goodsService.getGoodServiceTexts()) {
                    if (goodServiceText.getNumber().intValue() == goodsService.getNumber().intValue()
                        && goodServiceText.getType().intValue() == goodsService.getType().intValue()
                        && goodServiceText.getLanguage() == LanguageType.ENGLISH.getValue()) { // English

                        goodsServicesTextDao.deleteGoodServiceText(goodServiceText);
                        removeStatementTextList.add(goodServiceText);
                    }
                }
                for (GoodServiceText goodServiceText : removeStatementTextList) {
                    goodsService.getGoodServiceTexts().remove(goodServiceText);
                }
            }
        }

        removeStatementTextList = new ArrayList<>();

        if (gsDescriptionTextFrench.length() > 0) {
            for (GoodServiceText gsText : goodsService.getGoodServiceTexts()) {
                if (gsText.getNumber().intValue() == goodsService.getNumber().intValue()
                    && gsText.getType().intValue() == goodsService.getType().intValue()
                    && gsText.getLanguage().intValue() == LanguageType.FRENCH.getValue()) { // French

                    if (goodsServicesClassificationType.isModified()) {
                        gsText.setModifiedTimestamp(new Date());
                    }
                    gsText.setText(gsDescriptionTextFrench.toString());
                    goodsServicesTextDao.saveGoodServiceText(gsText);

                    frenchUpdated = true;

                    englishGSText = createGoodAndService(gsText);
                    englishGSText.setLanguage(LanguageType.ENGLISH.getValue());
                    if (goodsServicesClassificationType.isModified()) {
                        englishGSText.setModifiedTimestamp(new Date());
                    }

                    englishGSText.setText(gsDescriptionTextEnglish.toString());

                }
            }
        } else {
            // This is for ADJUSTMENTS. Only update the language received and delete the other language text.
            if (adjustment) {
                for (GoodServiceText goodServiceText : goodsService.getGoodServiceTexts()) {
                    if (goodServiceText.getNumber().intValue() == goodsService.getNumber().intValue()
                        && goodServiceText.getType().intValue() == goodsService.getType().intValue()
                        && goodServiceText.getLanguage().intValue() == LanguageType.FRENCH.getValue()) {

                        goodsServicesTextDao.deleteGoodServiceText(goodServiceText);
                        removeStatementTextList.add(goodServiceText);
                    }
                }
                for (GoodServiceText goodServiceText : removeStatementTextList) {
                    goodsService.getGoodServiceTexts().remove(goodServiceText);
                }
            }
        }

        if (acceptAll) {
            if (englishUpdated && frenchUpdated) {
                // do nothing if both English and French Updated..

                // Save French text as well in addition to English.
            } else if (englishUpdated && frenchGSText != null && StringUtils.isNotBlank(frenchGSText.getText())) {
                goodsServicesTextDao.saveGoodServiceText(frenchGSText);

                // Save English text in addition to French.
            } else if (frenchUpdated && englishGSText != null && StringUtils.isNotBlank(englishGSText.getText())) {
                goodsServicesTextDao.saveGoodServiceText(englishGSText);
            }

        }

        // Reset the edition from either WIPO or Intrepid depends what Console passed into MTS.
        if (StringUtils.isNotBlank(goodsServicesClassificationType.getClassificationVersion())) {

            Integer niceClassFromWipo = Integer.parseInt(goodsServicesClassificationType.getClassificationVersion());

            List<NiceReference> supportedNiceEditions = niceReferenceDao.getCurrentNiceReferences();
            for (NiceReference niceReference : supportedNiceEditions) {
                if (niceReference.getId().getNiceEdition() == niceClassFromWipo) {
                    goodsService.setNiceEdition(niceClassFromWipo);
                    break;
                }
            }

        }
        goodsServicesDao.saveGoodsServices(goodsService);
    }

    private GoodServiceText createGoodAndService(GoodServiceText gsText) {
        GoodServiceText goodServiceText = new GoodServiceText();
        goodServiceText.setExtensionCounter(gsText.getExtensionCounter());
        goodServiceText.setFileNumber(gsText.getFileNumber());
        goodServiceText.setLanguage(gsText.getLanguage());
        goodServiceText.setModifiedTimestamp(gsText.getModifiedTimestamp());
        goodServiceText.setGoodService(gsText.getGoodService());
        goodServiceText.setNumber(gsText.getNumber());
        goodServiceText.setOriginalInd(gsText.getOriginalInd() == 1 ? 0 : 1);
        goodServiceText.setPickListInd(gsText.getPickListInd());
        goodServiceText.setText(gsText.getText());
        goodServiceText.setTranslationStatus(gsText.getTranslationStatus());
        goodServiceText.setType(gsText.getType());

        return goodServiceText;

    }

    private List<_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType> setOrderedText(List<OrderedTextType> classTitleText) {
        // Goods Service Text
        List<_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType> mtsOrderedTextList = new ArrayList<>();

        for (OrderedTextType mtsOrderedTextType : classTitleText) {
            _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType commonOrderedTextType = new _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType();
            commonOrderedTextType.setLanguageCode(mtsOrderedTextType.getLanguageCode());
            commonOrderedTextType.setSequenceNumber(mtsOrderedTextType.getSequenceNumber());
            commonOrderedTextType.setValue(mtsOrderedTextType.getValue());

            mtsOrderedTextList.add(commonOrderedTextType);
        }
        return mtsOrderedTextList;
    }

    private Action createAction(Application application, ActionCode registeredAction, ActionCode pendingAction,
                                String recordNotificationDate)
        throws MTSServiceFault {

        Action action = null;
        if (TradeMarkStatusType.REGISTERED == TradeMarkStatusType.getByValue(application.getStatusCode())) {
            // If registered,the Action Partial Cancellation is created
            action = createNewAction(application, registeredAction, recordNotificationDate);

        } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
            .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
            // if pending,the Action Partial Withdraw is created
            action = createNewAction(application, pendingAction, recordNotificationDate);

        } else {
            // Inactive Intrepid Application. TODO throw exception
            logger.error(
                "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);

        }
        return action;
    }

    private GoodService buildGoodService(Application application,
                                         GoodsServicesClassificationType goodsServicesClassificationType,
                                         GoodServiceType goodsOrServiceType)
        throws MTSServiceFault {
        GoodService goodService = new GoodService();
        goodService.setType(goodsOrServiceType.getValue());
        goodService.setApplication(application);
        goodService.setFileNumber(application.getFileNumber());
        goodService.setExtensionCounter(application.getExtensionCounter());
        goodService.setNiceClassCode(Integer.valueOf(goodsServicesClassificationType.getClassNumber()));

        // Reset the edition from either WIPO or Intrepid depends what Console passed into MTS.
        if (StringUtils.isNotBlank(goodsServicesClassificationType.getClassificationVersion())) {
            Integer niceClassFromWipo = Integer.parseInt(goodsServicesClassificationType.getClassificationVersion());

            List<NiceReference> supportedNiceEditions = niceReferenceDao.getCurrentNiceReferences();
            for (NiceReference niceReference : supportedNiceEditions) {
                if (niceReference.getId().getNiceEdition() == niceClassFromWipo) {
                    goodService.setNiceEdition(niceClassFromWipo);
                    break;
                }
            }

        }

        return goodService;
    }

    @Transactional
    private Action createNewAction(Application application, ActionCode actionCode, String recordDate) {
        Action action = new Action();
        action.setApplication(application);
        action.setFileNumber(application.getFileNumber());
        action.setExtensionCounter(application.getExtensionCounter());
        action.setActionCode(actionCode.getValue());
        try {
            if (null == recordDate) {
                action.setActionDate(new Timestamp(new Date().getTime()));
            } else {
                action.setActionDate(DateFormats.getISOSDF().parse(recordDate));

                if (actionCode == ActionCode.MADRID_DESIGNATION_NOTIFICATION) {
                    // BD date as recordEffectiveDate + 18 months
                    action.setResponseDate(DateUtils.addMonths(DateFormats.getISOSDF().parse(recordDate), 18));
                }
            }
        } catch (ParseException e) {
            logger.error("Error parsing record notification date:" + recordDate);
        }
        if (actionCode != ActionCode.MF13_SENT) {
            action.setAdditionalInfo("DP:" + getFormattedSystemDate());
        }

        application.getActions().add(action);

        return action;
    }

    // The following need to be done where ready
    @Transactional
    private boolean createTotalCancellationTask(GoodsAndServiceMeta gsInfo) {

        return true;
    }

    // The following need to be done where ready
    @Transactional
    private boolean replaceGoodService(GoodsAndServiceMeta gsInfo) {

        return true;
    }

    /*************************** NEW remove existing statements METHOD ********************************/
    private void updateDeleteAddGoodsServices(List<GoodsServicesClassificationType> consoleGoodsServicesList,
                                              Application application, LanguageType applicationLanguage,
                                              boolean adjustment, boolean acceptAll)
        throws CIPOServiceFault {

        Set<GoodService> addedUpdatedGS = new HashSet<>();

        // update
        application = applicationDao.getApplication(application.getFileNumber(), 0);
        updateExistingStatements(application, applicationLanguage, consoleGoodsServicesList, addedUpdatedGS, adjustment,
            acceptAll);
        applicationDao.saveApplication(application);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        // add new
        application = applicationDao.getApplication(application.getFileNumber(), 0);
        addNewStatements(application, applicationLanguage, consoleGoodsServicesList, addedUpdatedGS);
        applicationDao.saveApplication(application);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        // delete
        application = applicationDao.getApplication(application.getFileNumber(), 0);
        removeExistingStatements(application, consoleGoodsServicesList, addedUpdatedGS);
        applicationDao.saveApplication(application);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        // update claim
        application = applicationDao.getApplication(application.getFileNumber(), 0);
        updateExistingClaims(application);
        applicationDao.saveApplication(application);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        application = applicationDao.getApplication(application.getFileNumber(), 0);

        // working around solution
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(application);

    }

    private void updateExistingStatements(Application application, LanguageType applicationLanguage,
                                          List<GoodsServicesClassificationType> consoleGoodsServicesList,
                                          Set<GoodService> addedUpdatedGS, boolean adjustment, boolean acceptAll) {

        Set<GoodService> gsList = new TreeSet<>(new GoodServiceComparator());
        gsList.addAll(application.getGoodsServices());

        for (GoodService goodService : gsList) {

            for (GoodsServicesClassificationType goodsServicesClassificationType : consoleGoodsServicesList) {
                if (goodService.getNumber().intValue() == goodsServicesClassificationType.getWsNumber()
                    && goodService.getType().intValue() == goodsServicesClassificationType.getWsType()) {

                    // Update GS
                    updateGoodsServiceText(application, goodService, goodsServicesClassificationType, adjustment,
                        acceptAll);

                    addedUpdatedGS.add(goodService);
                }
            }
        }
    }

    private void removeExistingStatements(Application application,
                                          List<GoodsServicesClassificationType> consoleGoodsServicesList,
                                          Set<GoodService> addedUpdatedGSList) {

        List<GoodService> removeStatementList = new ArrayList<>();

        Set<GoodService> gsList = new TreeSet<>(new GoodServiceComparator());
        gsList.addAll(application.getGoodsServices());

        // List<GoodsServicesClaimsType> removeStatementList = new ArrayList<>();
        // determine which statements need to be removed
        for (GoodService gs : gsList) {
            boolean wipoCipoMatch = false;
            boolean addedUpdated = false;

            for (GoodsServicesClassificationType goodsServicesClassificationType : consoleGoodsServicesList) {
                if (gs.getNumber().intValue() == goodsServicesClassificationType.getWsNumber()
                    && gs.getType().intValue() == goodsServicesClassificationType.getWsType()) {
                    wipoCipoMatch = true;
                }
            }

            for (GoodService addedUpdatedGS : addedUpdatedGSList) {
                if (gs.getNumber().intValue() == addedUpdatedGS.getNumber().intValue()
                    && gs.getType().intValue() == addedUpdatedGS.getType().intValue()) {
                    addedUpdated = true;
                }
            }

            if (!wipoCipoMatch && !addedUpdated) { // WIPO withheld a statement that exists in Intrepid so we remove
                                                   // statement from
                // Intrepid
                removeStatementList.add(gs);
            }
        }

        Collections.sort(removeStatementList, new GoodServiceNumberComparator());
        // must sort the list from greatest to less in order to use CFDELETE_WS sp properly
        Collections.reverse(removeStatementList);

        for (GoodService deleteGS : removeStatementList) {
            // checked if statement to be removed is associated to a claim and remove reference if it does.
            removeStatementBySP(application, deleteGS.getNumber(), deleteGS.getType());
        }
    }

    private void removeStatementBySP(Application application, Integer wsNumber, Integer wsType) {

        Set<GoodService> goodsServicesSet = application.getGoodsServices();
        List<GoodService> deletedGoodsServices = new ArrayList<>();

        for (GoodService goodsService : goodsServicesSet) {

            if (goodsService.getNumber().intValue() == wsNumber.intValue()
                && goodsService.getType().intValue() == wsType.intValue()) {

                deletedGoodsServices.add(goodsService);
            }
        }
        for (GoodService deletedStatement : deletedGoodsServices) {
            removeRelationshipFromClaim(application, deletedStatement);
            application.getGoodsServices().remove(deletedStatement);
            // goodsServicesDao.deleteGoodsServices(deletedStatement);
            deleteAndResequency(deletedStatement);
        }
    }

    private void deleteAndResequency(GoodService deletedStatement) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(
            SessionFactoryUtils.getDataSource(transactionManager.getSessionFactory()));

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("CFDELETE_WS")
            .withoutProcedureColumnMetaDataAccess().declareParameters(new SqlParameter("NFILE_NBR", Types.NUMERIC))
            .declareParameters(new SqlParameter("NEXTN_CNTR", Types.NUMERIC))
            .declareParameters(new SqlParameter("NWS_TYP", Types.NUMERIC))
            .declareParameters(new SqlParameter("NWS_NBR", Types.NUMERIC))
            .declareParameters(new SqlOutParameter("NERR_NBR", Types.NUMERIC));

        Map<String, Object> input = new HashMap<String, Object>();
        input.put("NFILE_NBR", deletedStatement.getFileNumber());
        input.put("NEXTN_CNTR", deletedStatement.getExtensionCounter());
        input.put("NWS_TYP", deletedStatement.getType());
        input.put("NWS_NBR", deletedStatement.getNumber());

        Map<String, Object> out = jdbcCall.execute(input);
        Object output = (out.get("NERR_NBR"));

        if (output != null) {
            logger.info("Execute SP success!");
        } else {
            logger.error("Execute SP failed!");
        }
    }

    private void removeRelationshipFromClaim(Application application, GoodService deletedStatement) {
        Set<Claim> claimsList = application.getClaims();
        for (Claim existingClaim : claimsList) {

            logger.info("size before remove: " + existingClaim.getGoodServiceClaims().size());
            List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application,
                deletedStatement);

            if (CollectionUtils.isNotEmpty(results)) {
                for (GoodServiceClaim cl : results) {
                    if (cl.getClaim().getClaimNumber().intValue() == existingClaim.getClaimNumber().intValue()
                        && cl.getClaim().getClaimType().intValue() == existingClaim.getClaimType().intValue()) {
                        existingClaim.getGoodServiceClaims().remove(cl);
                    }
                }
            }
            logger.info("size after remove: " + existingClaim.getGoodServiceClaims().size());
        }
    }

    private void updateExistingClaims(Application application) {
        // After updates above, check statements to see if there are any claims associated to it. If not, remove the
        // claim itself.
        Set<Claim> claimsList = application.getClaims();

        Set<Claim> toRemove = new HashSet<>();

        for (Claim existingClaim : claimsList) {
            boolean used = false;

            Set<GoodServiceClaim> results = existingClaim.getGoodServiceClaims();
            if (CollectionUtils.isNotEmpty(results)) {
                for (GoodServiceClaim cl : results) {
                    if (cl.getClaim().getClaimNumber().intValue() == existingClaim.getClaimNumber().intValue()
                        && cl.getClaim().getClaimType().intValue() == existingClaim.getClaimType().intValue()) {
                        used = true;
                        break;
                    }
                }
            }
            if (!used) {
                toRemove.add(existingClaim);
                claimDao.deleteClaim(existingClaim);
            }
        }

        application.getClaims().removeAll(toRemove);

    }

    private void addNewStatements(Application application, LanguageType applicationLanguage,
                                  List<GoodsServicesClassificationType> consoleGoodsServicesList,
                                  Set<GoodService> addedUpdatedGS)
        throws MTSServiceFault {

        // TIRS getClaimsByGoodsService sorts by WS Type and Ws Number, so looking at last entry for each will give
        // me the next ws number used.
        Set<GoodService> gsList = new TreeSet<>(new GoodServiceComparator());
        gsList.addAll(application.getGoodsServices());

        Integer goodsSequence = getNextWsNumber(gsList, GoodServiceType.GOODS);
        Integer serviceSequence = getNextWsNumber(gsList, GoodServiceType.SERVICES);

        for (GoodsServicesClassificationType goodsServicesClassificationType : consoleGoodsServicesList) {

            Set<GoodServiceText> goodsServicesText = new HashSet<>();

            if (goodsServicesClassificationType.getWsNumber() == 0
                && goodsServicesClassificationType.getWsType() == 0) {

                GoodServiceType statementType = goodsOrService(goodsServicesClassificationType.getClassNumber());
                GoodService goodsService = buildGoodService(application, goodsServicesClassificationType,
                    goodsOrService(goodsServicesClassificationType.getClassNumber()));

                if (statementType == GoodServiceType.GOODS) {
                    goodsService.setNumber(goodsSequence);
                    goodsSequence++;

                } else {
                    goodsService.setNumber(serviceSequence);
                    serviceSequence++;
                }

                // Goods Service Text
                buildGSText(setOrderedText(goodsServicesClassificationType.getClassTitleText()), goodsServicesText,
                    goodsService, application, applicationLanguage);
                goodsService.setGoodServiceTexts(goodsServicesText);

                goodsServicesDao.saveGoodsServices(goodsService);
                for (GoodServiceText goodServiceText : goodsServicesText) {
                    goodsServicesTextDao.saveGoodServiceText(goodServiceText);
                }

                application.getGoodsServices().add(goodsService);
                addedUpdatedGS.add(goodsService);
            }
        }
    }

    private Integer getNextWsNumber(Set<GoodService> goodsServices, GoodServiceType statementType) {

        Set<Integer> wsNumbers = new HashSet<Integer>();
        for (GoodService gs : goodsServices) {
            if (gs.getType().intValue() == statementType.getValue().intValue()) {
                wsNumbers.add(gs.getNumber());
            }
        }
        if (wsNumbers.size() > 0) {
            int maxNum = Collections.max(wsNumbers);
            return maxNum + 1;
        }

        return wsNumbers.size() + 1;
    }

    public class GoodServiceNumberComparator implements Comparator<GoodService> {

        @Override
        public int compare(GoodService x, GoodService y) {
            // TODO: Handle null x or y values
            int startComparison = compare(x.getNumber().intValue(), y.getNumber().intValue());
            return startComparison != 0 ? startComparison : compare(x.getNumber().intValue(), y.getNumber().intValue());
        }

        private int compare(int a, int b) {
            return a < b ? -1 : a > b ? 1 : 0;
        }
    }

    public boolean hasGSLimitations(MadridDesignationType madridDesignation) {
        if (madridDesignation != null && madridDesignation.getGoodsServicesLimitationBag() != null && CollectionUtils
            .isNotEmpty(madridDesignation.getGoodsServicesLimitationBag().getGoodsServicesLimitation())) {
            return true;

        }

        return false;

    }
}
