package ca.gc.ic.cipo.tm.mts.service.intrepid;

import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionList;

public interface IProcessActionsService {

    public ProcessActionList getProcessActionList(ProcessActionCategoryType processActionType);

    public ProcessAction getById(Integer processActionId);

    public void createProcessAction(ProcessAction processAction);
}
