package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * @author giustof
 *
 */
@Service(value = "irRenunciation")
public class IRRenunciationService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private ProcessActionsDao processActionsDao;

    private static Logger logger = Logger.getLogger(IRRenunciationService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing IRHolderNameAddressChangeService: Intl Record Id:" + intlIrTran.getIntlRecordId());

        // Get all applications matching transactions international registration number.
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        MadridDesignationTerminationType transtype = (MadridDesignationTerminationType) transType;

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                // Record Applications with the same IR Number
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    if (application.getStatusCode() == TradeMarkStatusType.REGISTERED.getValue()) {

                        // Cancel application
                        application.setStatusCode(TradeMarkStatusType.CANCELLED_BY_OWNER.getValue());

                        actionDao.saveAction(createAction(transtype, application, ActionCode.CANCELLED_BY_OWNER,
                            SectionAuthority.MADRID.name(), null));

                        // Process Action - Print Cancelled by Owner Notification’ ’
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION, SectionAuthority.MADRID.name()));

                        // process open section 45 cases
                        if (processOppositionCases(application, registeredOppositionCaseTypes,
                            TradeMarkStatusType.REGISTERED)) {

                            // Notify requestor
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            statusTypeResults.put(appDto, UserTaskType.IR_RENUNCIATION);
                        }

                        applicationDao.saveApplication(application);

                    } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                        .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                        // Withdraw application
                        application.setStatusCode(TradeMarkStatusType.WITHDRAWN_OWNER.getValue());

                        actionDao.saveAction(createAction(transtype, application, ActionCode.WITHDRAWN_BY_OWNER,
                            SectionAuthority.MADRID.name(), null));

                        // Process Action - Print Withdrawn by Owner Notification ’
                        processActionsDao.saveProcessActions(createProcessAction(application,
                            ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION, SectionAuthority.MADRID.name()));

                        if (processOppositionCases(application, unRegisteredOppositionCaseTypes,
                            TradeMarkStatusType.REGISTRATION_PENDING)) {
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            statusTypeResults.put(appDto, UserTaskType.IR_RENUNCIATION);
                        }

                        applicationDao.saveApplication(application);

                    }
                } else {
                    logger.error(
                        "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
                    throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
                }
            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    private boolean processOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                           TradeMarkStatusType tradeMarkStatusType) {

        boolean open = false;

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    open = true;

                    oppositionCase.setOppStatusCode(OppositionCaseStatus.CLOSED.getValue());

                    oppositionCaseDao.saveOppositionCase(oppositionCase);

                    OppositionCaseAction oppositionCaseAction = createOppositionCaseAction(application, oppositionCase,
                        tradeMarkStatusType, SectionAuthority.OPPS45.name());

                    oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
                    oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
                    applicationDao.saveApplication(application);

                    // Notify the requestor(s)
                    processActionsDao.saveProcessActions(createProcessAction(application,
                        (tradeMarkStatusType == TradeMarkStatusType.REGISTERED
                            ? ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION
                            : ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION),
                        oppositionCase.getOppCaseNumber(), SectionAuthority.MADRID.name()));

                }
            }
        }
        return open;
    }

    @Override
    public String getServiceName() {
        return "IRHolderNameAddressChangeService";
    }

}
