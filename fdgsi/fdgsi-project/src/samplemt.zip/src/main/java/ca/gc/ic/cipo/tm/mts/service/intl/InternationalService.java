package ca.gc.ic.cipo.tm.mts.service.intl;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.rowset.serial.SerialBlob;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationType;
import ca.gc.ic.cipo.tm.intl.dao.IntlAtchmtDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlAtchmtTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlFileFrmtTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskAddtnlInfoDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskAddtnlInfoTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlAtchmtTypeCode;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlPkgSchmaVrsnType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.exception.IDIntlNotFoundException;
import ca.gc.ic.cipo.tm.intl.model.ActHiIdentityLink;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTask;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTaskXref;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfo;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskType;
import ca.gc.ic.cipo.tm.mts.AddtnlInfoMeta;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualAutoCategoryType;
import ca.gc.ic.cipo.tm.mts.ObjectFactory;
import ca.gc.ic.cipo.tm.mts.TaskAddtnlInfoTypeMeta;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionList;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionType;
import ca.gc.ic.cipo.tm.mts.TaskTransactionMeta;
import ca.gc.ic.cipo.tm.mts.TransactionAttachmentMeta;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskMeta;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskMetaList;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlAtchmtDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskXrefDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IrregularityDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFileTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFilenameDto;
import ca.gc.ic.cipo.tm.mts.enums.DelimeterType;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.NfsFileName;
import ca.gc.ic.cipo.tm.mts.enums.OutboundTransactionMap;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.IMadridCacheService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;

@Service
public class InternationalService extends MadridTransactionService implements IInternationalService {

    @Autowired
    private IntlPkgTranTypeDao intlPackageTranTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao intlPackageSchemaVersionDao;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IntlIrTaskDao intlIrTaskDao;

    @Autowired
    private IntlAtchmtTypeDao intlAtchmtTypeDao;

    @Autowired
    private IntlFileFrmtTypeDao intlFileFrmtTypeDao;

    @Autowired
    private IntlTaskAddtnlInfoDao intlTaskAddtnlInfoDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlTaskStatusTypeDao intlTaskStatusTypeDao;

    @Autowired
    private IMadridCacheService madridCacheService;

    @Autowired
    private IntlAtchmtDao intlAtchmtDao;

    @Autowired
    private IntlTaskAddtnlInfoTypeDao intlTaskAddtnlInfoTypeDao;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private IMarshallingService marshallingService;

    @Value("#{environment['mts.reporting.service.host.name']}")
    private String reportServiceHost;

    private static Logger logger = Logger.getLogger(InternationalService.class.getName());

    @Transactional(value = "tmIntlTransactionManager")
    @Override
    public List<TransactionDetail> getTransactionList(TransactionCriteria transactionCriteria) throws CIPOServiceFault {
        logger.debug("MTS received request to getTransactionList");
        long startTime = System.currentTimeMillis();
        List<TransactionDetail> transactionDetailList = new ArrayList<TransactionDetail>();

        // First of all, ensure at least one piece of criteria was provided

        if (CollectionUtils.isEmpty(transactionCriteria.getTransactionIdList())
            && CollectionUtils.isEmpty(transactionCriteria.getPackageIdList())
            && CollectionUtils.isEmpty(transactionCriteria.getStatusCodeList())
            && CollectionUtils.isEmpty(transactionCriteria.getTransactionTypeCodeList())
            && CollectionUtils.isEmpty(transactionCriteria.getIntlRegistrationNumberList())
            && CollectionUtils.isEmpty(transactionCriteria.getDomesticAppNumberList())
            && transactionCriteria.getCreatedStartDate() == null && transactionCriteria.getCreatedEndDate() == null
            && transactionCriteria.getTransactionManualAutoCategory() == null) {

            // No criteria provided - throw an exception
            // (The 'orderBy' boolean doesn't count as criteria)
            super.throwMTSServiceFault("mts.missing.request.parameters", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        // The XSD enumerations for TransactionStatus and TransactionType (if exists) need to be converted into
        // lists of unique type code IDs (not the actual code type, just the ID)
        // Note: this strategy relies on the fact that the XSD enumeration name is the same as the Intl Model
        // enumeration name
        List<BigDecimal> statusTypeCodeIds = internationalDTOFactory.getStatusTypes(transactionCriteria);

        List<BigDecimal> transTypeCodeIds = internationalDTOFactory.getTransactionTypes(transactionCriteria);

        List<IntlIrTran> transList = intlIrTranDao.getTransactionsByCriteria(transactionCriteria.getTransactionIdList(),
            transactionCriteria.getPackageIdList(), statusTypeCodeIds, transTypeCodeIds,
            transactionCriteria.getIntlRegistrationNumberList(), transactionCriteria.getDomesticAppNumberList(),
            (null != transactionCriteria.getCreatedStartDate() ? transactionCriteria.getCreatedStartDate() : null),
            (null != transactionCriteria.getCreatedEndDate() ? transactionCriteria.getCreatedEndDate() : null));

        logger.debug("Retrieved " + transList.size() + " Transactions matching provided criteria");

        // Map the collection to an XSD model for return in the SOAP response
        for (IntlIrTran model : transList) {
            try {

                if (CollectionUtils.isNotEmpty(transactionCriteria.getPackageIdList())) {
                    transactionDetailList.add(internationalDTOFactory.mapToXsd(model, false, false));
                } else {
                    BigDecimal tranCtgryId = model.getIntlPkgTranType().getPkgTranCtgryId();

                    if (MadridTransactionType.getAutomatedTransactionCategories()
                        .contains(TransactionCategory.getTransactionCategoryByValue(tranCtgryId))) {

                        // automated
                        TransactionDetail transactionDetail = internationalDTOFactory.mapToTransactionXsd(model);
                        transactionDetail.setTransactionManualAutoCategory(ManualAutoCategoryType.AUTOMATED);
                        transactionDetailList.add(transactionDetail);

                    } else if (MadridTransactionType.pairedTransactionTypes
                        .contains(TransactionCategory.getTransactionCategoryByValue(tranCtgryId))) {

                        // automated
                        TransactionDetail transactionDetail = internationalDTOFactory.mapToXsd(model, false, false);
                        transactionDetail.setTransactionManualAutoCategory(ManualAutoCategoryType.AUTOMATED);

                        transactionDetailList.add(transactionDetail);

                    } else {
                        // manual
                        TransactionDetail transactionDetail = internationalDTOFactory.mapToXsd(model, false, false);
                        transactionDetail.setTransactionManualAutoCategory(ManualAutoCategoryType.MANUAL);

                        transactionDetailList.add(transactionDetail);
                    }
                }
            } catch (Exception exception) {
                logger.error("Error in getTransactionList", exception);
                throwCIPOFault(exception);
            }
        }

        logger.trace("Completed getTransactionList request in " + (System.currentTimeMillis() - startTime) + " ms");
        return transactionDetailList;
    }

    /**
     * Filter Automated and Manual Transactions. The Partial Change of Ownership transaction can contain one of two
     * pairs. 1) A Designation/Termination - Automated processing 2) A Designation/Restriction - Manual processing
     *
     * We must examine the contents of the xml transaction to determine whether the contents are for manual or automated
     * to ensure we return the correct results.
     *
     * @param transactionDetailList the transaction detail list
     * @param transactionCriteria the transaction criteria
     * @return the list
     * @throws CIPOServiceFault
     */
    /*
     * private List<TransactionDetail> filterAutomatedManualTransactions(List<TransactionDetail> transactionDetailList,
     * TransactionCriteria transactionCriteria) throws CIPOServiceFault {
     *
     * List<TransactionDetail> filteredTransactionList = new ArrayList<>();
     *
     * try { for (TransactionDetail transaction : transactionDetailList) {
     *
     * if (null == transaction.getTransactionManualAutoCategory()) {
     *
     * filteredTransactionList.add(transaction);
     *
     * } else { if (transaction.getTransactionManualAutoCategory() == ManualAutoCategoryType.AUTOMATED) {
     *
     * TransactionDetail irTransaction = getTransaction(transaction.getTransactionId(), false, false);
     *
     * if ( (irTransaction.getTransactionType().getId() ==
     * TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION.getTransactionCategoryId()) ||
     * (irTransaction.getTransactionType().getId() ==
     * TransactionCategory.DESIGNATION_TERMINATION.getTransactionCategoryId()) ) {
     *
     * MadridPartialChangeOwnershipType xmlTransaction = unmarshallTransaction( transaction.getTransactionId()); if
     * (null == xmlTransaction.getMadridProtectionRestriction() && null !=
     * xmlTransaction.getMadridDesignationTermination()) { // This is an automated task, so add this transaction to list
     * of unprocessed automated // transactions filteredTransactionList.add(transaction); }
     *
     * } else {
     *
     * filteredTransactionList.add(transaction); }
     *
     * } else if (transaction.getTransactionManualAutoCategory() == ManualAutoCategoryType.MANUAL) {
     *
     * TransactionDetail irTransaction = getTransaction(transaction.getTransactionId(), false, false);
     *
     * if (irTransaction.getTransactionType().getId() == TransactionCategory.PARTIAL_CHANGE_OWNERSHIP
     * .getTransactionCategoryId()) {
     *
     * MadridPartialChangeOwnershipType xmlTransaction = unmarshallTransaction( transaction.getTransactionId()); if
     * (null == xmlTransaction.getMadridDesignationTermination() && null !=
     * xmlTransaction.getMadridProtectionRestriction()) { // This is an automated task, so add this transaction to list
     * of unprocessed automated // transactions filteredTransactionList.add(transaction); }
     *
     * } else { filteredTransactionList.add(transaction); }
     *
     * } } } } catch (Exception exception) { logger.error("Error filter transactions", exception);
     * throwCIPOFault(exception); }
     *
     * return filteredTransactionList; }
     */

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<BigDecimal> getTransactionsHavingActiveTasks(String intlRegNo, BigDecimal fileNumber, BigDecimal taskId,
                                                             Date intlRecordEfdt) {

        return intlIrTranDao.getTransactionsHavingActiveTasks(intlRegNo, fileNumber, taskId, intlRecordEfdt);

    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTaskDto getConsoleTaskById(BigDecimal taskId) throws CIPOServiceFault {

        return internationalDTOFactory.getIRTaskDto(intlIrTaskDao.getById(taskId));

    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public WorkflowTaskMetaList getConsoleTasks(WorkflowTaskListSearchCriteria request) throws CIPOServiceFault {

        java.util.Date startDate = null;
        java.util.Date endDate = null;
        Integer taskStatus = null;

        if (null != request.getTaskStartDate()) {
            startDate = request.getTaskStartDate();
        }

        if (null != request.getTaskEndDate()) {
            endDate = request.getTaskEndDate();
        }

        if (null != request.getTaskStatus()) {
            taskStatus = TaskStatusType.getTaskStatusTypeByName(request.getTaskStatus().name()).getValue();
        }

        // Get tasks from database
        List<IntlIrTask> internationalTasks = intlIrTaskDao.getTasks(request.getStartRow(), request.getRowsPerPage(),
            request.getSortColumn(), request.getSortDirection(), startDate, endDate, request.getDmstcApltnFileNbr(),
            request.getIntlRegNo(), request.getUserId(), request.getGroupId(), request.getTaskSubjectCategory().name(),
            request.getTaskRequestType().name(), taskStatus, request.getRecordEffectiveStartDate(),
            request.getRecordEffectiveEndDate(), request.getTaskCategoryDescriptionEnglish(),
            request.getTaskCategoryDescriptionFrench());

        WorkflowTaskMetaList workflowTaskMetaList = new WorkflowTaskMetaList();

        Map<String, UserProfile> madridUserProfile = new HashMap<>();

        decorateTasks(madridUserProfile, internationalTasks, request);

        // populate the response objects.
        for (IntlIrTask task : internationalTasks) {
            workflowTaskMetaList.getTaskListBag().add(populateTasks(task, madridUserProfile));

        }

        return workflowTaskMetaList;
    }

    private WorkflowTaskMeta populateTasks(IntlIrTask task, Map<String, UserProfile> madridUserProfile) {

        ObjectFactory mtsObjectFactory = new ObjectFactory();

        WorkflowTaskMeta workflowTaskMeta = new WorkflowTaskMeta();
        workflowTaskMeta.setTaskId(task.getTaskId());
        workflowTaskMeta.setActRuTaskId(task.getActHiTaskInstId());
        workflowTaskMeta.setIntlRegNo(task.getIntlRegNo());
        workflowTaskMeta.setWipoRefNbr(task.getWipoRefNbr());

        if (CollectionUtils.isNotEmpty(task.getIntlTaskAddtnlInfo())) {
            Set<IntlTaskAddtnlInfo> additionalInfoSet = task.getIntlTaskAddtnlInfo();
            for (IntlTaskAddtnlInfo intlTaskAddtnlInfo : additionalInfoSet) {
                AddtnlInfoMeta addtnlInfoMeta = new AddtnlInfoMeta();
                TaskAddtnlInfoTypeMeta taskAddtnlInfoTypeMeta = new TaskAddtnlInfoTypeMeta();
                taskAddtnlInfoTypeMeta
                    .setTaskAddtnlInfoCtgryId(intlTaskAddtnlInfo.getTaskAddtnlInfoCtgry().getTaskAddtnlInfoCtgryId());
                taskAddtnlInfoTypeMeta
                    .setTaskAddtnlInfoCtgry(intlTaskAddtnlInfo.getTaskAddtnlInfoCtgry().getTaskAddtnlInfoCtgry());
                taskAddtnlInfoTypeMeta.setDescEn(intlTaskAddtnlInfo.getTaskAddtnlInfoCtgry().getDescEn());
                taskAddtnlInfoTypeMeta.setDescFr(intlTaskAddtnlInfo.getTaskAddtnlInfoCtgry().getDescFr());

                addtnlInfoMeta.setAddtnlInfo(intlTaskAddtnlInfo.getAddtnlInfo());
                addtnlInfoMeta.setCreatedTmstmp(intlTaskAddtnlInfo.getCreatedTmstmp());
                addtnlInfoMeta.setTaskAddtnlInfoId(intlTaskAddtnlInfo.getTaskAddtnlInfoId());
                addtnlInfoMeta.setTaskId(intlTaskAddtnlInfo.getTaskId());
                addtnlInfoMeta.setIntlTaskAddtnlInfoTypeMeta(
                    mtsObjectFactory.createAddtnlInfoMetaIntlTaskAddtnlInfoTypeMeta(taskAddtnlInfoTypeMeta));

                workflowTaskMeta.getAddtnlInfoListBag().add(addtnlInfoMeta);

            }
        }

        workflowTaskMeta.setAssignedUserId(task.getActHiTaskInst().getAssignee());

        // If we have a user profile, populate username / email.
        if (madridUserProfile.containsKey(task.getActHiTaskInst().getAssignee())) {

            // name
            workflowTaskMeta.setUserName(madridUserProfile.get(task.getActHiTaskInst().getAssignee()).getName());

            // email
            workflowTaskMeta.setUserEmail(madridUserProfile.get(task.getActHiTaskInst().getAssignee()).getEmail());
        }
        Set<ActHiIdentityLink> hiIdentities = task.getActHiTaskInst().getTaskIdentities();

        // Info not available for closed process. Get from history table if the info is required to display in console
        // for closed process
        if (hiIdentities != null && hiIdentities.size() > 0) {
            ActHiIdentityLink actRuIdentityLink = hiIdentities.iterator().next();
            workflowTaskMeta.setAssignedUserGroup(actRuIdentityLink.getGroupId());
        }

        workflowTaskMeta.setDmstcApltnFileNbr(
            (task.getDmstcApltnFileNbr() != null ? BigDecimal.valueOf(task.getDmstcApltnFileNbr()) : null));

        workflowTaskMeta.setDmstcApltnFileExtn(task.getDmstcApltnFileExtn());

        workflowTaskMeta.setOfficeType(task.getIntlIrOfficeType().getIrOfficeCtgry());

        workflowTaskMeta.setStatusTaskId(
            task.getIntlTaskStatusType() == null ? null : task.getIntlTaskStatusType().getTaskStatusCtgryId());

        workflowTaskMeta
            .setStatusCategoryId(task.getIntlTaskType() == null ? null : task.getIntlTaskType().getTaskCtgryId());

        workflowTaskMeta.setTaskDescEn(task.getIntlTaskType().getDescEn());
        workflowTaskMeta.setTaskDescFr(task.getIntlTaskType().getDescFr());

        workflowTaskMeta.setTaskCreateDate(task.getCreatedTmstmp());

        workflowTaskMeta.setTaskUpdatedDate(task.getUpdatedTmstmp());

        // Set transaction information
        for (IntlIrTaskXref taskXref : task.getIntlIrTaskXrefs()) {

            workflowTaskMeta.getTransactionListBag().add(populateTaskTransaction(taskXref));
        }

        return workflowTaskMeta;
    }

    private TaskTransactionMeta populateTaskTransaction(IntlIrTaskXref taskXref) {

        IntlIrTran intlIrTran = taskXref.getIntlIrTran();

        TaskTransactionMeta taskTransactionMeta = new TaskTransactionMeta();
        taskTransactionMeta.setIrTranId(taskXref.getIrTranId());
        taskTransactionMeta.setPkgTranCtgryId(taskXref.getIntlIrTran().getIntlPkgTranType().getPkgTranCtgryId());
        taskTransactionMeta.setTranCtgry(taskXref.getIntlIrTran().getIntlPkgTranType().getTranCtgry());
        taskTransactionMeta.setTranCtgryDescEn(taskXref.getIntlIrTran().getIntlPkgTranType().getDescEn());
        taskTransactionMeta.setTranCtgryDescFr(taskXref.getIntlIrTran().getIntlPkgTranType().getDescFr());
        taskTransactionMeta.setIntlRecordEfctvDt(intlIrTran.getIntlRecordEfctvDt());

        // Set attachment information
        for (IntlAtchmt atchmt : intlIrTran.getIntlAtchmts()) {
            TransactionAttachmentMeta transactionAttachmentMeta = new TransactionAttachmentMeta();

            transactionAttachmentMeta.setAtchmtId(atchmt.getAtchmtId());
            transactionAttachmentMeta.setAtchmtCtgry(atchmt.getIntlAtchmtType().getAtchmtCtgry());
            transactionAttachmentMeta.setFileFrmtCtgry(atchmt.getIntlFileFrmtType().getFileFrmtCtgry());
            transactionAttachmentMeta.setFileName(atchmt.getFileName());

            taskTransactionMeta.getAttachmentListBag().add(transactionAttachmentMeta);
        }

        return taskTransactionMeta;
    }

    // Provide the full user name
    private void decorateTasks(Map<String, UserProfile> activitiUserProfile, List<IntlIrTask> internationalTasks,
                               WorkflowTaskListSearchCriteria request)
        throws CIPOServiceFault {

        if (CollectionUtils.isNotEmpty(internationalTasks)) {

            Set<String> uniqueUserIds = new HashSet<>();

            for (IntlIrTask task : internationalTasks) {
                if (null != task.getActHiTaskInst().getAssignee()) {
                    uniqueUserIds.add(task.getActHiTaskInst().getAssignee());
                }
            }

            if (uniqueUserIds.size() > 0) {

                Iterator<String> userIdIterator = uniqueUserIds.iterator();
                String userId = null;
                while (userIdIterator.hasNext()) {
                    userId = userIdIterator.next();

                    UserProfile userProfile;
                    try {
                        userProfile = madridCacheService.getUserProfile(userId);
                        activitiUserProfile.put(userId, userProfile);
                    } catch (Exception e) {
                        throwCIPOFault(e);
                    }
                }
            }
        }
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void updateTransactionStatus(BigDecimal irTranId, StatusType intlStatus) {

        IntlIrTran intlIrTran = intlIrTranDao.getIrTranById(irTranId);

        // create status history before updating transaction status
        Timestamp timestamp = new Timestamp(new Date().getTime());

        // Update the transaction status
        intlIrTran.setIntlStatusType(intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(intlStatus.getValue())));
        intlIrTran.setUpdatedTmstmp(timestamp);
        intlIrTranDao.save(intlIrTran);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void updateTransactionContent(BigDecimal irTranId, ByteArrayOutputStream os) throws MTSServiceFault {

        IntlIrTran intlIrTran = intlIrTranDao.getIrTranById(irTranId);

        try {
            Timestamp timestamp = new Timestamp(new Date().getTime());
            Blob blob = new SerialBlob(os.toByteArray());
            // create status history before updating transaction status
            // Update the transaction status
            intlIrTran.setXmlContent(blob);
            intlIrTran.setUpdatedTmstmp(timestamp);
            intlIrTranDao.save(intlIrTran);

        } catch (Exception e) {
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
    }

    @Transactional(value = "tmIntlTransactionManager")
    public IntlStatusType getTransactionStatus(BigDecimal statusId) {
        return intlStatusTypeDao.getStatusTypeById(statusId);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public Long getTotalTasks(WorkflowTaskListSearchCriteria request) {

        java.util.Date startDate = null;
        java.util.Date endDate = null;
        Integer taskStatus = null;

        if (null != request.getTaskStartDate()) {
            startDate = request.getTaskStartDate();
        }

        if (null != request.getTaskEndDate()) {
            endDate = request.getTaskEndDate();
        }
        if (null != request.getTaskStatus()) {
            taskStatus = TaskStatusType.getTaskStatusTypeByName(request.getTaskStatus().name()).getValue();
        }
        return intlIrTaskDao.getTotalTasks(request.getStartRow(), request.getRowsPerPage(), request.getSortColumn(),
            request.getSortDirection(), startDate, endDate, request.getDmstcApltnFileNbr(), request.getIntlRegNo(),
            request.getUserId(), request.getGroupId(), request.getTaskSubjectCategory().name(),
            request.getTaskRequestType().name(), taskStatus, request.getRecordEffectiveStartDate(),
            request.getRecordEffectiveEndDate(), request.getTaskCategoryDescriptionEnglish(),
            request.getTaskCategoryDescriptionFrench());
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public TaskDescriptionList getTaskDescriptionList(TaskDescriptionListSearchCriteria taskDescriptionListSearchCriteria) {
        TaskDescriptionList taskDescriptionList = new TaskDescriptionList();

        String taskCategoryName = taskDescriptionListSearchCriteria.getTaskSubjectCategory() != null
            ? taskDescriptionListSearchCriteria.getTaskSubjectCategory().name() : null;

        List<IntlTaskType> intlTaskTypes = intlIrTaskDao.getIntlTaskTypes(taskCategoryName);

        for (IntlTaskType taskType : intlTaskTypes) {
            taskDescriptionList.getTaskListBag().add(getTaskDescriptionType(taskType));
        }

        return taskDescriptionList;
    }

    private TaskDescriptionType getTaskDescriptionType(IntlTaskType taskType) {
        TaskDescriptionType taskDescription = new TaskDescriptionType();
        taskDescription.setTaskCtgryDescEn(taskType.getDescEn());
        taskDescription.setTaskCtgryDescFr(taskType.getDescFr());
        return taskDescription;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public TransactionDetail getTransaction(BigDecimal transactionId, boolean includeXmlContent,
                                            boolean includeAttachmentContent)
        throws CIPOServiceFault {

        logger.debug("MTS received request to getTransaction ID: " + transactionId);
        long startTime = System.currentTimeMillis();
        TransactionDetail responseDetail = new TransactionDetail();
        IntlIrTran transactionModel = null;

        // A Transaction ID is a required parameter
        // if (transactionId == null || transactionId.intValue() < 1) {
        // throwMTSServiceFault("mts.error.retrieving.attachment", ExceptionReasonCode.SYSTEM_ERROR);
        // }

        transactionModel = intlIrTranDao.getById(transactionId);
        // if (transactionModel == null) {
        // throw new MissingTransactionException(-10, 3, transactionId);
        // }

        // Call the utility method to map the Intl model to the XSD model
        try {
            responseDetail = internationalDTOFactory.mapToXsd(transactionModel, includeXmlContent,
                includeAttachmentContent);
        } catch (SQLException e) {
            super.throwMTSServiceFault("-99.2", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        logger.trace("Completed GET request for Transaction ID: " + transactionId + " in "
            + (System.currentTimeMillis() - startTime) + " ms");

        return responseDetail;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public TransactionDetail getTransactionByIntlRecordId(String recordIdentifier, String irNumber,
                                                          boolean isCorrectionTypeTransactionOnly,
                                                          boolean includeXmlContent, boolean includeAttachmentContent)
        throws CIPOServiceFault {

        logger.debug("MTS received request to getTransaction for recordIdentifier : " + recordIdentifier
            + ", irNumber : " + irNumber + ",  isCorrectionTypeTransactionOnly : " + isCorrectionTypeTransactionOnly);
        long startTime = System.currentTimeMillis();

        List<TransactionCategory> transactionCategories = null;
        if (isCorrectionTypeTransactionOnly) {
            // Transaction list for correction according to JIRA:1444
            transactionCategories = new ArrayList<TransactionCategory>();

            // MadridBasicRegistrationApplicationChange
            transactionCategories.add(TransactionCategory.MBR_APPLICATION_CHANGE);

            // MadridDesignation //TODO:: only to have correct one
            transactionCategories.add(TransactionCategory.MD_REGISTRATION);
            transactionCategories.add(TransactionCategory.MD_SUBSEQUENT_DESIGNATION);
            transactionCategories.add(TransactionCategory.MD_MERGER);

            // MadridRenewal //TODO::
            transactionCategories.add(TransactionCategory.MR_RENEWAL);
            // transactionCategories.add(TransactionCategory.MR_COMPLEMENTARY_RENEWAL);

            // MadridCorrection
            transactionCategories.add(TransactionCategory.MC_CORRECTION);

            // MadridInternationalRegistrationCreation
            transactionCategories.add(TransactionCategory.MIR_REGISTRATION);

            // MadridDesignationTermination //TODO::
            transactionCategories.add(TransactionCategory.MDT_RENUNCIATION);
            transactionCategories.add(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT);
            transactionCategories.add(TransactionCategory.MDT_TOTAL_CANCELLATION);
            transactionCategories.add(TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK);
            transactionCategories.add(TransactionCategory.MDT_NON_RENEWAL_OF_CONTRACTING_PARTY);
            transactionCategories.add(TransactionCategory.MDT_MERGER);

            // MadridHolderRepresentativeChange //TODO::
            transactionCategories.add(TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE);
            // transactionCategories.add(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS);
            // transactionCategories.add(TransactionCategory.MHR_CHANGE_OF_OWNER);

            // MadridProtectionRestriction //TODO::
            transactionCategories.add(TransactionCategory.MPR_PARTIAL_CEASING_OF_EFFECT);
            transactionCategories.add(TransactionCategory.MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL);
            transactionCategories.add(TransactionCategory.MPR_LIMITATION);
            transactionCategories.add(TransactionCategory.MPR_PARTIAL_CANCELLATION);

            // MadridPartialChangeOwnership
            transactionCategories.add(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION);
            transactionCategories.add(TransactionCategory.DESIGNATION_TERMINATION);

            // MadridAbandonmentNotification
            transactionCategories.add(TransactionCategory.MADRID_ABANDONMENT_NOTIFICATION);

            // MadridCompletedProcessing
            transactionCategories.add(TransactionCategory.MCP_NO_CATEGORY);

            // MadridIrregularityNotification
            transactionCategories.add(TransactionCategory.MI_IRREGULARITY_NOTIFICATION);

            /**
             * TODO::
             */
            // MadridLicenseeRecordChange //TODO::
            // transactionCategories.add(TransactionCategory.??);

            // Remaining InboutTransaction not used (or listed in JIRA)
            // TransactionCategory.INVALID_TRANSACTION_TYPE
            // TransactionCategory.MADRID_FEE
            // TransactionCategory.IFMS_FINANCIAL_FEEDBACK
            // TransactionCategory.ACCOUNTS_RECEIVABLE
            // TransactionCategory.REVENUE_RECOGNITION

        }

        TransactionDetail responseDetail = null;

        try {
            List<IntlIrTran> transactions = intlIrTranDao.getTransactionsByIntlRecordIdAndIntlRegNo(recordIdentifier,
                irNumber, transactionCategories);

            IntlIrTran transactionModel = null;
            if (transactions != null && transactions.size() > 0) {
                transactionModel = transactions.get(0);
            }

            if (transactionModel != null) {
                responseDetail = new TransactionDetail();
                responseDetail = internationalDTOFactory.mapToXsd(transactionModel, includeXmlContent,
                    includeAttachmentContent);
            }

        } catch (SQLException e) {
            super.throwMTSServiceFault("-99.2", ExceptionReasonCode.SYSTEM_ERROR);
        }

        logger.trace("Completed GET request for recordIdentifier: " + recordIdentifier + " in "
            + (System.currentTimeMillis() - startTime) + " ms");

        return responseDetail;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public AttachmentDetail getTransactionAttachment(BigDecimal attachmentId) throws CIPOServiceFault {
        logger.debug("MTS received request to get Attachment ID: " + attachmentId);
        long startTime = System.currentTimeMillis();

        AttachmentDetail response = null;
        IntlAtchmt attachment = null;

        // Start be fetching the Attachment
        // try {
        attachment = intlAtchmtDao.getById(attachmentId);
        // } catch (Exception nfe) {
        // throw new MissingTransactionException(-10, 20, nfe, attachmentId);
        // }

        // Call the utility method to map the Intl model to the XSD model
        // This operation always returns the binary content
        try {
            response = internationalDTOFactory.mapToXsd(attachment, true);
        } catch (SQLException e) {
            super.throwMTSServiceFault("-99.2", ExceptionReasonCode.SYSTEM_ERROR);
        }

        logger.trace("Completed request for Attachment ID: " + attachmentId + " in "
            + (System.currentTimeMillis() - startTime) + " ms");

        // At this point everything has succeeded, send a valid response (1,1)
        return response;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public boolean existingIrNumberOk(List<String> intlRegNumber, List<BigDecimal> statusTypeCodeIds) {

        List<IntlIrTran> transList = intlIrTranDao.getTransactionsByCriteria(null, null, statusTypeCodeIds, null,
            intlRegNumber, null, null, null);

        if (CollectionUtils.isNotEmpty(transList)) {
            return false;
        }
        return true;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<IntlIrTranDto> getTransactionByTaskId(BigDecimal irTaskId) {

        List<IntlIrTranDto> transactionList = new ArrayList<>();

        IntlIrTask intlIrTask = intlIrTaskDao.getIrTaskById(irTaskId);

        Set<IntlIrTaskXref> xrefList = intlIrTask.getIntlIrTaskXrefs();
        if (CollectionUtils.isNotEmpty(xrefList)) {
            Iterator<IntlIrTaskXref> xref = xrefList.iterator();
            while (xref.hasNext()) {
                IntlIrTaskXref intlIrTaskXref = xref.next();

                transactionList.add(internationalDTOFactory
                    .getIntlIrTranNoChildrenDto(intlIrTranDao.getById(intlIrTaskXref.getIrTranId())));
            }
        }
        return transactionList;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void updatePartialOwnershipTask(BigDecimal irTaskId, Integer fileNumber) {

        StringBuilder newFileInfo = new StringBuilder();

        IntlIrTask intlIrTask = intlIrTaskDao.getIrTaskById(irTaskId);
        newFileInfo.append(DelimeterType.PARTIAL_OWNERSHIP_NEW_MARK_ID.getDelimeter()).append(fileNumber);

        IntlTaskAddtnlInfo intlTaskAddtnlInfo = null;
        if (CollectionUtils.isNotEmpty(intlIrTask.getIntlTaskAddtnlInfo())) {
            for (IntlTaskAddtnlInfo intlTaskAddtnlInfoo : intlIrTask.getIntlTaskAddtnlInfo()) {
                if (intlTaskAddtnlInfoo.getTaskAddtnlInfoCtgry().getTaskAddtnlInfoCtgryId()
                    .intValue() == TaskAddtnlInfoType.PARTIAL_OWNERSHIP_CHANGE_NEW_FILE_NUM.getValue()) {
                    intlTaskAddtnlInfo = intlTaskAddtnlInfoo;

                    intlTaskAddtnlInfo.setAddtnlInfo(newFileInfo.toString());
                    intlTaskAddtnlInfo.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
                    break;

                }
            }

        }

        if (intlTaskAddtnlInfo == null) {
            intlTaskAddtnlInfo = this.createAdditonalInfo(irTaskId,
                TaskAddtnlInfoType.PARTIAL_OWNERSHIP_CHANGE_NEW_FILE_NUM, newFileInfo.toString());
        }

        intlIrTask.getIntlTaskAddtnlInfo().add(intlTaskAddtnlInfo);

        intlIrTaskDao.save(intlIrTask);

        intlTaskAddtnlInfoDao.save(intlTaskAddtnlInfo);

    }

    public IntlTaskAddtnlInfo createAdditonalInfo(BigDecimal taskId, TaskAddtnlInfoType taskAddtnlInfoType,
                                                  String additionalInfoText) {

        // Get the additional info type you want to add some additional info for.
        IntlTaskAddtnlInfoType additionalInfoType = intlTaskAddtnlInfoTypeDao
            .getTaskAddtnlInfoTypeById(BigDecimal.valueOf(taskAddtnlInfoType.getValue()));

        IntlTaskAddtnlInfo additionalInfo = this.createAdditonalInfoObject(taskId, additionalInfoText,
            additionalInfoType);

        return additionalInfo;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTranDto getTransactionsByIrTranId(BigDecimal irTranId) {
        return internationalDTOFactory.getIntlIrTranDto(intlIrTranDao.getIrTranById(irTranId));
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTranDto getIrTran(BigDecimal irTranId) {
        IntlIrTran intlIrTran = intlIrTranDao.getIrTransactionById(irTranId);
        if (intlIrTran == null) {
            return null;
        }
        return internationalDTOFactory.getIntlIrTranDto(intlIrTran);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTranDto getTransactionRecordByIrTranId(BigDecimal irTranId) {
        return internationalDTOFactory.getIntlIrTranNoChildrenDto(intlIrTranDao.getIrTranById(irTranId));
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void updateTaskStatus(BigDecimal intlIrTaskId, TaskStatusType statusType) {

        IntlIrTask intlIrTask = intlIrTaskDao.getIrTaskById(intlIrTaskId);
        intlIrTask.setIntlTaskStatusType(
            intlTaskStatusTypeDao.getTaskStatusTypeById(BigDecimal.valueOf(statusType.getValue())));
        intlIrTaskDao.save(intlIrTask);
    }

    // TODO what package / what schema version.
    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTranDto storeTransaction(ByteArrayOutputStream os, IntlPkg intlPkg, StatusType transactionStatus,
                                          TransactionCategory transactionCategory, String recordIdentifier,
                                          String registrationNumber, String recordEffectiveDate)
        throws MTSServiceFault {

        IntlIrTran intlTransaction = new IntlIrTran();
        try {
            Timestamp timestamp = new Timestamp(new Date().getTime());

            Blob blob = new SerialBlob(os.toByteArray());

            intlTransaction.setCreatedTmstmp(timestamp);
            intlTransaction.setIntlPkg(intlPkg);
            intlTransaction.setIntlRegNo(registrationNumber);
            if (recordEffectiveDate != null) {
                intlTransaction.setIntlRecordEfctvDt(DateFormats.getISOSDF().parse(recordEffectiveDate));
            } else {
                intlTransaction
                    .setIntlRecordEfctvDt(DateFormats.getISOSDF().parse(DateFormats.getISOSDF().format(new Date())));
            }

            intlTransaction.setIntlRecordId(recordIdentifier);
            intlTransaction.setIntlPkgTranType(intlPackageTranTypeDao
                .getTranTypeById(BigDecimal.valueOf(transactionCategory.getTransactionCategoryId())));
            intlTransaction.setIntlPkgSchmaVrsn(intlPackageSchemaVersionDao
                .getPkgSchmaVrsnById(BigDecimal.valueOf(IntlPkgSchmaVrsnType.IB_TO_OFFICE_TRANSACTION_V3.getValue())));
            intlTransaction.setIntlStatusType(
                intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(transactionStatus.getValue())));
            intlTransaction.setXmlContent(blob);

            intlIrTranDao.save(intlTransaction);

        } catch (Exception e) {
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
        return internationalDTOFactory.getIntlIrTranDto(intlTransaction);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void sendFileToIntrepidNFS(BigDecimal irTranId, BigDecimal fileNumber, String extensionCounter,
                                      NfsFileTypeDto nfsFileType)
        throws MTSServiceFault {

        IntlIrTranDto intlIrTransaction = getTransactionsByIrTranId(irTranId);
        String fileNamePrefixKey = null;

        if (NfsFileTypeDto.OUTBOUND_ONLY.name().equals(nfsFileType.name())) {
            MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType
                .getTransactionTypeByValue(intlIrTransaction.getIntlPkgTranType().getPkgTranCtgryId());

            if (NfsFileName.outboundTransactionFilenameMap.containsKey(madridOutboundTransactionType)) {
                fileNamePrefixKey = NfsFileName.outboundTransactionFilenameMap.get(madridOutboundTransactionType);
            }
        } else if (NfsFileTypeDto.COURTESY_LETTER_ONLY.name().equals(nfsFileType.name())) {
            fileNamePrefixKey = NfsFileName.COURTESY_LETTER_PREFIX;
        } else {
            TransactionCategory transactionCategory = TransactionCategory
                .getTransactionCategoryByValue(intlIrTransaction.getIntlPkgTranType().getPkgTranCtgryId());

            if (NfsFileName.transactionFilenameMap.containsKey(transactionCategory)) {
                fileNamePrefixKey = NfsFileName.transactionFilenameMap.get(transactionCategory);
            }
        }
        if (null == fileNamePrefixKey) {
            logger.debug("No fileNamePrefixKey for outbound filename. Throw exception after demo.");
            return;
        }

        List<IntlAtchmtDto> requestedAttachmentList = new ArrayList<>();
        Set<IntlAtchmt> attachments = intlIrTranDao.getById(irTranId).getIntlAtchmts();

        if (CollectionUtils.isNotEmpty(attachments)) {
            List<IntlAtchmtDto> attachmentList = internationalDTOFactory.getAtchmtDto(attachments);
            if (NfsFileTypeDto.OUTBOUND_ONLY.name().equals(nfsFileType.name())) {
                for (IntlAtchmtDto intlAtchmtDto : attachmentList) {
                    if (IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS.codeValue()
                        .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {
                        requestedAttachmentList.add(intlAtchmtDto);
                    }
                }

            } else {
                for (IntlAtchmtDto intlAtchmtDto : attachmentList) {
                    if (NfsFileTypeDto.COURTESY_LETTER_ONLY.name().equals(nfsFileType.name())) {
                        if (IntlAtchmtTypeCode.COURTESY_LETTER_PDF.codeValue()
                            .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {
                            requestedAttachmentList.add(intlAtchmtDto);
                        }
                    } else if (!IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS.codeValue()
                        .equals(intlAtchmtDto.getAtchmtCtgryId().toString())
                        && !IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS_RECEIVED.codeValue()
                            .equals(intlAtchmtDto.getAtchmtCtgryId().toString())) {
                        requestedAttachmentList.add(intlAtchmtDto);
                    }
                }
            }
        }

        List<NfsFilenameDto> nfsFilenameList = setNFSFilename(requestedAttachmentList, fileNamePrefixKey, fileNumber,
            extensionCounter, irTranId, nfsFileType);

        try {
            for (NfsFilenameDto nfsFilenameDto : nfsFilenameList) {

                logger.debug("Sending file to NFS: " + nfsFilenameDto.getFileName().toString() + ", fileType: "
                    + nfsFilenameDto.getFileType());
                intlAtchmtDao.storeFileOnNFS(fileNumber, Integer.valueOf(extensionCounter),
                    nfsFilenameDto.getFileName().toString(), nfsFilenameDto.getFileType().getNfsFileType(),
                    nfsFilenameDto.getAtchmtId(), nfsFilenameDto.getIrTranId());

            }
        } catch (Exception e) {
            logger.error("Error sending file to NFS", e);
            throwMTSServiceFault("mts.nfs.file.send.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
    }

    @Transactional(value = "tmIntlTransactionManager")
    @Override
    public List<IntlIrTaskXrefDto> getTransactionListForHolderDetails() throws CIPOServiceFault {
        logger.debug("MTS received request to getTransactionListForHolderDetails");
        List<IntlIrTaskXrefDto> trans_Tasks_Ids_list = new ArrayList<>();
        List<IntlIrTask> tasks_list = intlIrTaskDao.getTasksByUserTaskType(UserTaskType.HOLDER_CONTACT_DETAILS_TASK,
            TaskStatusType.UNPROCESSED);
        for (IntlIrTask task : tasks_list) {
            IntlIrTaskDto intlIrTaskDto = internationalDTOFactory.getIRTaskDto(task);
            for (IntlIrTaskXref intTaskXref : task.getIntlIrTaskXrefs()) {
                IntlIrTaskXrefDto taskXrefDto = new IntlIrTaskXrefDto();
                taskXrefDto.setIntlIrTaskDto(intlIrTaskDto);
                taskXrefDto.setIrTranId(intTaskXref.getIrTranId());
                trans_Tasks_Ids_list.add(taskXrefDto);
            }

        }
        return trans_Tasks_Ids_list;
    }

    @Transactional(value = "tmIntlTransactionManager")
    @Override
    public IrregularityDto getIrregularityInbound(IntlIrTranDto transaction) throws CIPOServiceFault {
        try {
            MadridIrregularityNotificationType madridIrregularityNotification = marshallingService
                .unmarshallTransaction(transaction.getIrTranId());
            int outBoundTranId = Integer
                .parseInt(madridIrregularityNotification.getOfficeReferenceIdentifier().getValue());

            IntlIrTranDto outBoundTransaction = this.getTransactionsByIrTranId(BigDecimal.valueOf(outBoundTranId));

            IrregularityDto irregularityDto = new IrregularityDto();
            irregularityDto.setIrTranId(BigDecimal.valueOf(outBoundTranId));
            irregularityDto.setWipoRefNum(outBoundTransaction.getOfficeRefId());

            MadridOutboundTransactionType outboundTransactionType = MadridOutboundTransactionType
                .getTransactionTypeByValue(outBoundTransaction.getIntlPkgTranType().getPkgTranCtgryId());

            OfficeType officeType = OutboundTransactionMap.outboundTransactionOfficeTypeMap
                .get(outboundTransactionType);

            if (null != officeType && officeType == OfficeType.OO) {
                irregularityDto.setOfficeType(OfficeType.OO);
                outBoundTransaction.setOfficeType(OfficeType.OO);

            } else {

                irregularityDto.setOfficeType(OfficeType.DO);
                outBoundTransaction.setOfficeType(OfficeType.DO);
            }
            irregularityDto.setReferencedIrTranDto(outBoundTransaction);

            return irregularityDto;
        } catch (IDIntlNotFoundException e) {
            logger.error("Referenced outbound transaciton not found. However this will not block MWE process", e);
            return null;

        } catch (Exception exception) {
            logger.error("Error in getIrregularityInbound", exception);
            throwCIPOFault(exception);
        }
        return null;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public void generateReportNotification(MadridReportResponse madridReportResponse, BigDecimal irTranId)
        throws CIPOServiceFault {

        // This method will be called when an RGS report (by Job ID) has
        // completed. In most
        // cases MTS will retrieve the report and store it as an attachment to
        // either a Transaction or Package
        logger.debug(String.format(
            "MTS received notification that RGS report Job ID %s for Transaction ID: %s is ready for storage",
            madridReportResponse.getJobId(), irTranId));

        IntlIrTran irTransaction = intlIrTranDao.getIrTranById(irTranId);

        // Create the Attachment
        IntlAtchmt intlAtchmt = this.createAttachment(irTransaction, getReportBlob(madridReportResponse.getJobId()),
            madridReportResponse.getReportName(), IntlFileFrmtTypeEnum.PDF, IntlAtchmtTypeCode.COURTESY_LETTER_PDF);

        // save the transaction
        irTransaction.getIntlAtchmts().add(intlAtchmt);
        intlIrTranDao.save(irTransaction);

    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public IntlAtchmt createAttachment(IntlIrTran irTransaction, Blob document, String fileName,
                                       IntlFileFrmtTypeEnum fileFormat, IntlAtchmtTypeCode attachmentType) {
        // Create the Attachment
        IntlAtchmt intlAtchmt = new IntlAtchmt();
        intlAtchmt.setIntlIrTran(irTransaction);
        intlAtchmt.setFileContent(document);

        intlAtchmt.setFileName(fileName);

        intlAtchmt.setIntlAtchmtType(intlAtchmtTypeDao.getAtchmtTypeById(Long.valueOf(attachmentType.codeValue())));

        // The file format will be PDF or DOC
        intlAtchmt.setIntlFileFrmtType(intlFileFrmtTypeDao.getFileFrmtTypeById(Long.valueOf(fileFormat.codeValue())));
        intlAtchmt.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));

        // save the attachment
        intlAtchmtDao.save(intlAtchmt);

        return intlAtchmt;
    }

    private Blob getReportBlob(String reportJobId) throws CIPOServiceFault {
        // The RGS host is looked up from the configuration
        ReportGenerationWsClient rgsClient = new ReportGenerationWsClient(reportServiceHost);
        Blob blob = null;

        // Get the completed report.
        try {
            InputStream myReport = rgsClient.getGeneratedReport(reportJobId);
            byte[] buffer = new byte[myReport.available()];
            myReport.read(buffer);

            // Add the report to the blob type
            blob = new SerialBlob(buffer);

        } catch (Exception exception) {
            logger.error("Error in getReportBlob", exception);
            throwCIPOFault(exception);
        }
        return blob;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTran getById(BigDecimal transId) throws CIPOServiceFault {

        return intlIrTranDao.getIrTranById(transId);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<IntlAtchmt> getAtchmtListByTranId(BigDecimal tranId) throws CIPOServiceFault {
        return intlAtchmtDao.getAtchmtListByTranId(tranId);
    }
}
