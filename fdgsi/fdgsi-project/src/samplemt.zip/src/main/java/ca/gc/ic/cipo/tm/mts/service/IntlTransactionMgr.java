package ca.gc.ic.cipo.tm.mts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;

@Service
public class IntlTransactionMgr extends TransactionMgr
{
	@Autowired
	IntrepidTransactionMgr intrepidTransactionMgr;

	@Override
	@Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
	public AutomatedProcessResponse processTransaction(TransactionRequest transaction) throws CIPOServiceFault
	{
		return intrepidTransactionMgr.processTransaction(transaction);
	}

	@Override
	@Transactional(value = "transactionManager", rollbackFor = Exception.class)
	public ManualProcessResponse processManualTransaction(TransactionRequest transactionRequest) throws CIPOServiceFault
	{
		return intrepidTransactionMgr.processManualTransaction(transactionRequest);
	}
	
	@Override
	@Transactional(value = "transactionManager", rollbackFor = Exception.class)
	public AutomatedProcessResponse processOwnershipChangeMerger(TransactionPairRequest transaction) throws CIPOServiceFault
	{
		return intrepidTransactionMgr.processOwnershipChangeMerger(transaction);
	}

}
