package ca.gc.ic.cipo.tm.mts.service;

import java.math.BigDecimal;

public interface IProcessEventService {

    public void insertProcessEvent(BigDecimal irTranId, String msgKey, Throwable ex, Object... msgArgs);
}
