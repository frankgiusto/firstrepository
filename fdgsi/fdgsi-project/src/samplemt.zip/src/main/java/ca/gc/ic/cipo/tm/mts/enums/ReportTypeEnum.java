package ca.gc.ic.cipo.tm.mts.enums;

/**
 * Report Type
 *
 */
public enum ReportTypeEnum {

    MF_1("MF1"),

    MF_2("MF2"),

    MF_3_A("MF3A"),

    MF_4("MF4"),

    MF_5("MF5"),

    MF_6("MF6"),

    MF_7("MF7"),

    MF_9("MF9"),

    MF_13("MF13"),

    COURTESY_LETTER("COURTESY_LETTER");

    private final String value;

    ReportTypeEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ReportTypeEnum fromValue(String v) {
        for (ReportTypeEnum c : ReportTypeEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
