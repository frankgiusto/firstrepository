package ca.gc.ic.cipo.tm.mts.service.intl;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public interface IMarshallingService {

    /**
     * Marshal it.
     *
     * @param <T> the generic type
     * @param marshaller the marshaller
     * @param madridObject the madrid object
     * @return the byte array output stream
     * @throws JAXBException the JAXB exception
     */
    <T> ByteArrayOutputStream marshalIt(Marshaller marshaller, JAXBElement<T> madridObject) throws Exception;

    /**
     * Marshal it invoked by export transaction
     *
     **/
    <T> ByteArrayOutputStream marshalExportMessageWithValidation(Marshaller marshaller, JAXBElement<T> madridObject)
        throws Exception;

    /**
     * Unmarshall transaction.
     *
     * @param <T> the generic type
     * @param intlIrTranId the intl ir tran id
     * @return the t
     * @throws JAXBException the JAXB exception
     * @throws SQLException the SQL exception
     */
    public <T> T unmarshallTransaction(BigDecimal intlIrTranId) throws JAXBException, SQLException;

    /**
     * Unmarshall outbound transaction.
     *
     * @param <T> the generic type
     * @param intlIrTranId the intl ir tran id
     * @return the t
     * @throws JAXBException the JAXB exception
     * @throws SQLException the SQL exception
     */
    public <T> T unmarshallOutboundTransaction(BigDecimal intlIrTranId) throws JAXBException, SQLException;

    /**
     * Gets the madrid jaxb context.
     *
     * @return the madrid jaxb context
     */
    public JAXBContext getMadridJAXBContext();

    /**
     * Gets the madrid outbound jaxb context.
     *
     * @return the madrid outbound jaxb context
     */
    public JAXBContext getMadridOutboundJAXBContext();

    /**
     * Prints the request or response.
     *
     * @param request the request
     * @throws JAXBException the JAXB exception
     */
    public void printRequestResponse(Object request) throws JAXBException;
}
