package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridInvalidationType;
import ca.gc.ic.cipo.common.service.CalendarUtils;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.enums.ActionDateType;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;
import ca.gc.ic.cipo.tm.tirs.types.TrademarkActionType;

public class MadridInvalidation extends OfficeToIbBase implements IOutboundTransaction, IReportingService {

    private static Logger log = Logger.getLogger(MadridInvalidation.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = null;

    private final static String reportName = "MADRID_MF10";

    // Full or Partial
    public MadridInvalidation(MadridOutboundTransactionType madridOutboundTransactionType) {
        this.madridOutboundTransactionType = madridOutboundTransactionType;
    }

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        MadridInvalidationType transaction = objectFactory.createMadridInvalidationType();
        TMInfoRetrievalDto tirsDto = outboundTransactionDto.getProcessActionApplication();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(tirsDto);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Refusal Pronounced Date TODO does this date exist in Intrepid?
        transaction.setRefusalPronouncedDate(calRefusalPronouncedDate(tirsDto.getTrademarkActionTypes()));

        // Holder Bag
        transaction.setHolderBag(super.mapHolder(tirsDto.getTmInterestedPartyTypeList(), notificationLanguage));

        if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_INVALIDATION_FULL_MF10) {
            // Goods Services Indicator
            transaction.setAllGoodsServicesIndicator(true);

        } else if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_INVALIDATION_PARTIAL_MF10) {
            // transaction.setAllGoodsServicesIndicator(false);
            // Goods Services Bag
            transaction.setGoodsServicesBag(mapGoodsServices(tirsDto.getGoodsAndServices()));

        }

        // Document Included Bag
        List<String> documents = new ArrayList<>();
        String includedDocName = getUniqueReportName(reportName, outboundTransactionDto.getIntlRegNo(),
            intlIrTranDto.getIrTranId().toString());
        StringBuilder documentName = createDocument(includedDocName);
        documents.add(documentName.toString());

        // Referring to the doc SUC 1.3, no document is attached to the task or the form from Intrepid.
        // This report comes from Intrepid.
        if (StringUtils.isNotBlank(outboundTransactionRequest.getAdditionalInfo()) && !outboundTransactionRequest
            .getAdditionalInfo().startsWith(ManualReportUtil.getResponseToIrregularityMcKey())) {

            documentName = createDocument(outboundTransactionRequest.getAdditionalInfo(), intlIrTranDto.getIrTranId());
            documents.add(documentName.toString());
        }

        transaction.setDocumentIncludedBag(super.mapDocumentBag(documents));

        JAXBElement<MadridInvalidationType> madridobject = objectFactory.createMadridInvalidation(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        OutboundTransactionDto outboundTransactionDto = (OutboundTransactionDto) inObject;

        MadridInvalidationType notificationType = marshallingService.unmarshallOutboundTransaction(tranId);

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(OfficeToIbBase.xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, OfficeToIbBase.reportXpath);

        String tagName = OfficeToIbBase.xmltagName_ORID;
        String value = formatValue(notificationType.getOfficeReferenceIdentifier().getValue());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_NL;
        value = notificationType.getNotificationLanguage().value();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_IR;
        value = notificationType.getInternationalRegistrationNumber();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // III
        List<TrademarkActionType> trademarkActionTypes = outboundTransactionDto.getProcessActionApplication()
            .getTrademarkActionTypes();

        tagName = "DateNotificationByWIPO";
        value = getMaxActionDate(trademarkActionTypes);
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_HOLDER;
        value = buildHolderValue(notificationType.getHolderBag());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // V static field

        // VI
        tagName = "RefusalPronouncedDate";
        value = notificationType.getRefusalPronouncedDate().toString();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // build VII
        tagName = "TotalInvalidation";
        value = (((notificationType.isAllGoodsServicesIndicator() != null)
            && notificationType.isAllGoodsServicesIndicator()) ? "true" : "false");
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        if ((notificationType.isAllGoodsServicesIndicator() == null)
            || !notificationType.isAllGoodsServicesIndicator()) {
            tagName = "PartialInvalidation";
            value = getPartialInvalidation(notificationType.getGoodsServicesBag());
            XMLTagUtil.appendTag(xmlDataSource, tagName, value);
        }

        tagName = OfficeToIbBase.xmltagName_SIGN;
        XMLTagUtil.appendTag(xmlDataSource, tagName);

        tagName = OfficeToIbBase.xmltagName_IBNDate;
        value = ManualReportUtil.getSystemDate();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        XMLTagUtil.appendTagClose(xmlDataSource, OfficeToIbBase.reportXpath);
        log.debug(xmlDataSource.toString());

        Locale locale = ((notificationType.getNotificationLanguage().value().equalsIgnoreCase(LOCAL_EN)) ? Locale.CANADA
            : Locale.CANADA_FRENCH);

        String jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(),
            (MtsStringUtil.SLASH + OfficeToIbBase.reportXpath), reportName, null, locale);

        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);

        String includedDocName = getUniqueReportName(reportName, notificationType.getInternationalRegistrationNumber(),
            tranId.toString());
        madridReportResponse.setReportName(includedDocName);

        return madridReportResponse;
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return true;
    }

    private String getMaxActionDate(List<TrademarkActionType> trademarkActionTypes) {

        if ((trademarkActionTypes == null) || trademarkActionTypes.isEmpty()) {
            return MtsStringUtil.EMPTY;
        }

        SimpleDateFormat sdf = DateFormats.getISOSDF();
        Date maxDate = null;
        Date curDate = null;
        for (TrademarkActionType trademarkActionType : trademarkActionTypes) {
            if (trademarkActionType.getActionCode() == ActionCode.MADRID_DESIGNATION_NOTIFICATION.getValue()
                .intValue()) {

                curDate = trademarkActionType.getActionDate().toGregorianCalendar().getTime();

                if ((maxDate == null) || (maxDate.before(curDate))) {
                    maxDate = curDate;
                }
            }
        }

        return ((maxDate != null) ? sdf.format(maxDate) : MtsStringUtil.EMPTY);
    }

    private XMLGregorianCalendar calRefusalPronouncedDate(List<TrademarkActionType> trademarkActionTypes)
        throws DatatypeConfigurationException {
        TreeMap<String, String> actionDates = new TreeMap<>();
        Calendar cal = Calendar.getInstance();

        if (null != trademarkActionTypes) {
            for (TrademarkActionType trademarkActionType : trademarkActionTypes) {
                if (trademarkActionType.getActionCode() == ActionDateType.RECORD_FEDERAL_COURT_PROCEEDING
                    .getActionCode()) {
                    System.out.println(trademarkActionType.getActionDate().toString());
                    actionDates.put(trademarkActionType.getActionDate().toString(),
                        trademarkActionType.getAdditionalInfo());
                }
            }

            if (actionDates.size() > 0) {
                String addInfo = actionDates.lastEntry().getValue();
                int colonPos = addInfo.lastIndexOf(MtsStringUtil.COLON);
                if (colonPos > 0) {
                    String dateInfo = addInfo.substring(colonPos + 1).trim().replace("/", "-");
                    cal.setTime(convertStringToDate(dateInfo, log));
                }

            } else {
                cal = CalendarUtils.getToday();
            }
        }

        XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);

        return xmlDate;
    }

    private String getPartialInvalidation(GoodsServicesBagType gsBag) {
        StringBuffer sb = new StringBuffer();

        if (gsBag == null) {
            return MtsStringUtil.EMPTY;
        }
        List<GoodsServicesType> listGoodsServicesType = gsBag.getGoodsServices();
        if ((listGoodsServicesType == null) || listGoodsServicesType.isEmpty()) {
            return MtsStringUtil.EMPTY;
        }

        for (GoodsServicesType goodsServicesType : listGoodsServicesType) {
            ClassDescriptionBagType classDescriptionBagType = goodsServicesType.getClassDescriptionBag();

            List<ClassDescriptionType> listGoodsServicesClassification = classDescriptionBagType.getClassDescription();
            for (ClassDescriptionType gdType : listGoodsServicesClassification) {

                List<OrderedTextType> listOrderedText = gdType.getGoodsServicesDescriptionText();
                for (OrderedTextType orderedText : listOrderedText) {
                    sb.append(MtsStringUtil.LEFT_BRACKET);
                    sb.append(gdType.getClassNumber());
                    sb.append(MtsStringUtil.RIGHT_BRACKET);
                    sb.append(MtsStringUtil.SPACE);
                    sb.append(orderedText.getValue());
                    sb.append(MtsStringUtil.DOUBLE_LINE_CHANGE);
                }
            }
        }

        return formatValue(sb.toString());
    }

}
