package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

public class IntlStatusTypeDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -8146384295958143565L;

    private BigDecimal statusCtgryId;

    private String statusCtgry;

    public BigDecimal getStatusCtgryId() {
        return statusCtgryId;
    }

    public void setStatusCtgryId(BigDecimal statusCtgryId) {
        this.statusCtgryId = statusCtgryId;
    }

    public String getStatusCtgry() {
        return statusCtgry;
    }

    public void setStatusCtgry(String statusCtgry) {
        this.statusCtgry = statusCtgry;
    }

    @Override
    public String toString() {
        return "IntlStatusTypeDto [statusCtgryId=" + statusCtgryId + ", statusCtgry=" + statusCtgry + "]";
    }

}
