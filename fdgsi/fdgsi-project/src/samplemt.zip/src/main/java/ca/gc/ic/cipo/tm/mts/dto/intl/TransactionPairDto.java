package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.util.List;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;

public class TransactionPairDto implements ITransactionPairDto {

    private IntlIrTranDto madridDesignationTransaction;

    private IntlIrTranDto pairedTransaction;

    private TransactionCategory transactionCategory;

    private List<IntlIrTaskDto> intlIrTaskList;

    private List<Integer> lockedFileList;

    private String authorityId;

    private boolean valid = false;

    @Override
    public IntlIrTranDto getMadridDesignationTransaction() {
        return madridDesignationTransaction;
    }

    @Override
    public IntlIrTranDto getPairedTransaction() {
        return pairedTransaction;
    }

    @Override
    public TransactionCategory getPairedTransactionType() {
        return transactionCategory;
    }

    @Override
    public void setMadridDesignationTransaction(IntlIrTranDto intlIrTranDto) {
        this.madridDesignationTransaction = intlIrTranDto;

    }

    @Override
    public void setPairedTransaction(IntlIrTranDto intlIrTranDto) {
        this.pairedTransaction = intlIrTranDto;
    }

    @Override
    public void setPairedTransactionType(TransactionCategory transactionCategory) {
        this.transactionCategory = transactionCategory;

    }

    @Override
    public String getAuthorityId() {
        return authorityId;
    }

    @Override
    public void setAuthorityId(String authorityId) {
        this.authorityId = authorityId;
    }

    @Override
    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    @Override
    public List<IntlIrTaskDto> getIntlIrTaskList() {
        return intlIrTaskList;
    }

    @Override
    public void setIntlIrTaskList(List<IntlIrTaskDto> intlIrTaskList) {
        this.intlIrTaskList = intlIrTaskList;
    }

    public List<Integer> getLockedFileList() {
        return lockedFileList;
    }

    public void setLockedFileList(List<Integer> lockedFileList) {
        this.lockedFileList = lockedFileList;
    }

}
