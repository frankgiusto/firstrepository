/*
 *
 */
package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.util.List;

import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionsResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;

public interface IIntrepidDTOFactory {

    /**
     * Gets the application dto using intrepid application.
     *
     * @param application the application
     * @param officeType the office type
     * @return the application dto
     */
    public ApplicationDto getApplicationDto(Application application, OfficeType officeType);

    /**
     * Gets the application dto using irNumber.
     *
     * @param irNumber the ir number
     * @param officeType the office type
     * @return the application dto
     */
    public ApplicationDto getApplicationDto(String irNumber, OfficeType officeType);

    /**
     * Gets the application dto. Not concerned with office type in this case.
     *
     * @param application the application
     * @return the application dto
     */
    public ApplicationDto getApplicationDto(Application application);

    /**
     * Gets the process action results dto.
     *
     * @param processActionResults the process action results
     * @param processActionType the process action type
     * @return the process action results dto
     */
    public List<ProcessActionsResponse> getProcessActionResultsDto(List<ProcessAction> processActionResults,
                                                                   ProcessActionCategoryType processActionType);

    /**
     * Gets the process action result dto.
     *
     * @param processActionResult the process action result
     * @param processActionType the process action type
     * @param authorityId the authority id
     * @return the process action result dto
     */
    public ProcessActionsResponse getProcessActionResultDto(ProcessAction processActionResult,
                                                            ProcessActionCategoryType processActionType,
                                                            String authorityId);

    /**
     * Gets the process action result dto.
     *
     * @param processActionResult the process action result
     * @param processActionType the process action type
     * @return the process action result dto
     */
    public ProcessActionsResponse getProcessActionResultDto(ProcessAction processActionResult,
                                                            ProcessActionCategoryType processActionType);

    /**
     * Gets the process action codes used to retrieve Intrepid process actions.
     *
     * @param processActionCategoryType the process action category type
     * @return the process action codes
     */
    public List<Integer> getProcessActionCodes(ProcessActionCategoryType processActionCategoryType);

    /**
     * Gets the console task list.
     *
     * @param processActionsMeta the process actions meta
     * @return the console task list
     */
    public ConsoleTaskList getConsoleTaskList(ProcessActionsMeta processActionsMeta);
}
