package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

public class IntlTaskStatusTypeDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -8146384295958143565L;

    private BigDecimal taskStatusCtgryId;

    private String taskStatusCtgry;

    public BigDecimal getTaskStatusCtgryId() {
        return taskStatusCtgryId;
    }

    public void setTaskStatusCtgryId(BigDecimal taskStatusCtgryId) {
        this.taskStatusCtgryId = taskStatusCtgryId;
    }

    public String getTaskStatusCtgry() {
        return taskStatusCtgry;
    }

    public void setTaskStatusCtgry(String taskStatusCtgry) {
        this.taskStatusCtgry = taskStatusCtgry;
    }

}
