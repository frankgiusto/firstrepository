package ca.gc.ic.cipo.tm.mts.util;

import org.apache.commons.lang3.StringUtils;

import ca.gc.ic.cipo.tm.enumerator.LegislationType;

public class CitedRegistrationNumberUtil {

    public static String getCitedRegNumber(Integer legislation, Integer registrationNumber) {
        StringBuffer citedRegistrationNumber = new StringBuffer();

        if (legislation != null && registrationNumber != null) {
            String regNumberStr = String.valueOf(registrationNumber);

            if (LegislationType.TMA.isEqualTo(legislation)) {

                // 10 digit
                String tmaStr = StringUtils.leftPad(regNumberStr, 6, MtsStringUtil.ZERO);
                citedRegistrationNumber.append(LegislationType.TMA.name()).append(tmaStr.substring(0, 3))
                    .append(MtsStringUtil.COMMA).append(tmaStr.substring(3));

            } else if (LegislationType.UCA.isEqualTo(legislation)) {

                // 8 digit
                citedRegistrationNumber.append(LegislationType.UCA.name())
                    .append(StringUtils.leftPad(regNumberStr, 5, MtsStringUtil.ZERO));

            } else if (LegislationType.TMDA.isEqualTo(legislation)) {

                // 9 digit
                citedRegistrationNumber.append(LegislationType.TMDA.name())
                    .append(StringUtils.leftPad(regNumberStr, 5, MtsStringUtil.ZERO));

            } else if (LegislationType.NFLD.isEqualTo(legislation)) {

                // 8 digit
                citedRegistrationNumber.append(LegislationType.NFLD.name())
                    .append(StringUtils.leftPad(regNumberStr, 4, MtsStringUtil.ZERO));
            }
        }

        return citedRegistrationNumber.toString();

    }

}