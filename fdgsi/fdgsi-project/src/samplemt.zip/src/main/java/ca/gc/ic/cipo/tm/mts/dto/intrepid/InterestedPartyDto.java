package ca.gc.ic.cipo.tm.mts.dto.intrepid;

public class InterestedPartyDto implements java.io.Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 6294195399080801473L;

    private String interestedPartyContactName;

    private String interestedPartyReference;

    public String getInterestedPartyContactName() {
        return interestedPartyContactName;
    }

    public void setInterestedPartyContactName(String interestedPartyContactName) {
        this.interestedPartyContactName = interestedPartyContactName;
    }

    public String getInterestedPartyReference() {
        return interestedPartyReference;
    }

    public void setInterestedPartyReference(String interestedPartyReference) {
        this.interestedPartyReference = interestedPartyReference;
    }

}
