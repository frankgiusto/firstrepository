package ca.gc.ic.cipo.tm.mts.clients;

import java.util.Map;

import javax.xml.ws.BindingProvider;

import wipo.FindHolder;
import wipo.FindHolderImplService;

public class WipoHolderServiceFactory {

    public static FindHolder createWipoHolderClient() {

        FindHolderImplService service = new FindHolderImplService();
        FindHolder port = service.getFindHolderImplPort();

        String endpointUrl = "https://www3.wipo.int:443/madrid/webservice/FindHolder";

        BindingProvider bp = (BindingProvider) port;
        Map<String, Object> ctx = ((BindingProvider) port).getRequestContext();
        ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

        // Enable MTOM using the SOAPBinding
        // SOAPBinding binding = (SOAPBinding) bp.getBinding();
        // binding.setMTOMEnabled(true);

        return port;
    }

}
