package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.AuthoritiesDao;
import ca.gc.ic.cipo.tm.dao.CountryProvinceLookupDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.dao.TradeMarkLockDao;
import ca.gc.ic.cipo.tm.dao.TrademarkDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationStatus;
import ca.gc.ic.cipo.tm.enumerator.MailType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.CountryProvince;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.LanguageType;
import ca.gc.ic.cipo.tm.mts.NotificationStatusType;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.UpdateHolderContactDetailsResponse;
import ca.gc.ic.cipo.tm.mts.clients.WipoHolderServiceFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IrregularityDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.InterestedPartyDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionsMap;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.util.CitedRegistrationNumberUtil;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.NotificationTaskAuthorityUtil;
import ca.gc.ic.cipo.tm.mts.util.ValidateWipoTransactionUtil;
import ca.gc.ic.cipo.tm.tirs.common.TMInfoRetrievalCommonServicePortType;
import ca.gc.ic.cipo.tm.tirs.common.TrademarkInfoRetrievalCommonServiceFactory;
import ca.gc.ic.cipo.tm.tirs.regrenewal.TMInfoRetrievalRegistrationRenewalServicePortType;
import ca.gc.ic.cipo.tm.tirs.regrenewal.TrademarkInfoRetrievalRegistrationRenewalServiceFactory;
import ca.gc.ic.cipo.tm.tirs.types.ActionSearchCriterionType;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyBagType;
import wipo.AddressBookType;
import wipo.ApplicantType;
import wipo.ContactInformationDetailsType;
import wipo.FindHolder;
import wipo.HolderInfo;

@Service
public class IntrepidCommonService extends MadridTransactionService implements IIntrepidCommonService {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private ITaskService taskService;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MailDao mailDao;

    @Autowired
    private AuthoritiesDao authoritiesDao;

    @Autowired
    TradeMarkLockDao tradeMarkLockDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private TrademarkDao trademarkDao;

    @Autowired
    private CountryProvinceLookupDao countryProvinceLookupDao;

    @Value("#{environment['mts.tm.information.retrieval.services.host.name']}")
    private String tmirServiceHost;

    private static Logger logger = Logger.getLogger(IntrepidCommonService.class.getName());

    /** {@inheritDoc} */
    @Override
    @Transactional
    public List<ConsoleTaskResponse> checkforExistingMarks(BigDecimal irTranId) throws CIPOServiceFault {
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        if (null == irTranId) {
            logger.error("irTranId are mandatory: ");
            throw new java.lang.IllegalArgumentException("irTranId is mandatory");
        }
        IntlIrTranDto transaction = internationalService.getTransactionsByIrTranId(irTranId);
        String intlRegNo = transaction.getIntlRegNo();
        TransactionCategory processType = TransactionCategory
            .getTransactionCategoryByValue(transaction.getIntlPkgTranType().getPkgTranCtgryId());

        // For irregularity notification.
        if (processType == TransactionCategory.MI_IRREGULARITY_NOTIFICATION) {
            checkIrregularityForExistingMarks(processType, transaction, statusTypeResults);

        } else if (processType == TransactionCategory.MCP_NO_CATEGORY) {
            validateOfficeRefId(transaction, statusTypeResults);
        } else if (StringUtils.isEmpty(intlRegNo)) {
            logger.debug("This is for office type O/O processType: " + processType + ", irTranId: " + irTranId);
            checkForExistingMarksByWipoReferenceNumber(processType, transaction, statusTypeResults);
        } else {
            // office type D/O
            logger.debug("This is for both office type D/O and O/O irTranId: " + irTranId);

            checkForExistingMarksByRegNo(processType, transaction, statusTypeResults);
        }

        return taskService.getUserTaskInformation(irTranId, statusTypeResults);
    }

    private void validateOfficeRefId(IntlIrTranDto transaction, Map<ApplicationDto, UserTaskType> statusTypeResults) {
        logger.debug("Validate office reference id <" + transaction.getOfficeRefId() + "> for transaction <"
            + transaction.getIrTranId() + ">");

        BigDecimal outboundTransactionId = BigDecimal.valueOf(Integer.parseInt(transaction.getOfficeRefId()));

        IntlIrTranDto outboundTransaction = internationalService.getIrTran(outboundTransactionId);

        if (outboundTransaction == null) {
            logger.error("office Reference id <" + transaction.getOfficeRefId()
                + "> does not exist. Will create a notification to the console user.");
            statusTypeResults.put(intrepidDTOFactory.getApplicationDto(transaction.getIntlRegNo(), OfficeType.DO),
                UserTaskType.IR_TRANSACTION_NOT_FOUND);
        }

    }

    private void checkIrregularityForExistingMarks(TransactionCategory processType, IntlIrTranDto transaction,
                                                   Map<ApplicationDto, UserTaskType> statusTypeResults)
        throws CIPOServiceFault {
        try {

            IrregularityDto irregularityDto = internationalService.getIrregularityInbound(transaction);

            if (irregularityDto == null) {
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(transaction.getIntlRegNo(), OfficeType.DO),
                    UserTaskType.IR_TRANSACTION_NOT_FOUND);
            } else {

                if (irregularityDto.getReferencedIrTranDto().getOfficeType() == OfficeType.OO) {

                    logger.debug("This is for office type O/O irTranId: "
                        + irregularityDto.getReferencedIrTranDto().getIrTranId().intValue());

                    List<MadridApplication> madridApplications = madridApplicationDao
                        .getMadridApplicationByIrNumber(transaction.getIntlRegNo());

                    if (CollectionUtils.isEmpty(madridApplications)) {
                        statusTypeResults.put(
                            intrepidDTOFactory.getApplicationDto(transaction.getIntlRegNo(), OfficeType.OO),
                            UserTaskType.MARK_NOT_FOUND);
                    }

                } else {

                    TransactionCategory outboundProcessType = TransactionCategory.getTransactionCategoryByValue(
                        irregularityDto.getReferencedIrTranDto().getIntlPkgTranType().getPkgTranCtgryId());

                    // This is DO outbound transaction.
                    logger.debug("This is for office type D/O irTranId: "
                        + irregularityDto.getReferencedIrTranDto().getIrTranId());

                    checkForExistingMarksByRegNo(outboundProcessType, irregularityDto.getReferencedIrTranDto(),
                        statusTypeResults);
                }

            }

        } catch (Exception e) {
            logger.error("Error checking for existing marks", e);
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
    }

    private void checkForExistingMarksByWipoReferenceNumber(TransactionCategory processType, IntlIrTranDto transaction,
                                                            Map<ApplicationDto, UserTaskType> statusTypeResults)
        throws CIPOServiceFault {
        try {
            String wipoReferenceNumber = transaction.getOfficeRefId();
            MadridApplication madridApplication = madridApplicationDao
                .getMadridApplicationByReferenceNumber(wipoReferenceNumber);

            if (madridApplication == null) {
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(transaction.getIntlRegNo(), OfficeType.OO),
                    UserTaskType.PROTOCOL_APPLICATION_NOT_FOUND);
            }
        } catch (Exception e) {
            logger.error("Error checking for existing marks by WIPO refernece number", e);
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
    }

    private void checkForExistingMarksByRegNo(TransactionCategory processType, IntlIrTranDto transaction,
                                              Map<ApplicationDto, UserTaskType> statusTypeResults)
        throws CIPOServiceFault {

        if (transaction.getIntlRegNo() == null) {
            return;
        }

        List<Application> applications = applicationDao.getApplicationByIrNumber(transaction.getIntlRegNo());

        if (CollectionUtils.isEmpty(applications)) {
            try {
                // may be for OO
                String wipoReferenceNumber = transaction.getOfficeRefId();

                MadridApplication madridApplication = null;
                if (!StringUtils.isBlank(wipoReferenceNumber)) {
                    madridApplication = madridApplicationDao.getMadridApplicationByReferenceNumber(wipoReferenceNumber);
                } else if (processType == TransactionCategory.MDT_TOTAL_CANCELLATION) {
                    List<MadridApplication> madridApps = madridApplicationDao
                        .getMadridApplicationByIrNumber(transaction.getIntlRegNo());
                    if (!CollectionUtils.isEmpty(madridApps)) {
                        madridApplication = madridApps.get(0);
                    }
                }

                if (madridApplication == null) {
                    statusTypeResults.put(
                        intrepidDTOFactory.getApplicationDto(transaction.getIntlRegNo(), OfficeType.OO),
                        UserTaskType.PROTOCOL_APPLICATION_NOT_FOUND);
                } else {
                    if ((processType == TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION)
                        || (processType == TransactionCategory.DESIGNATION_TERMINATION)) {

                        ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(transaction.getIntlRegNo(),
                            OfficeType.OO);
                        Integer fileNum = CollectionUtils.isNotEmpty(madridApplication.getMadridApplicationXrefs())
                            ? madridApplication.getMadridApplicationXrefs().get(0).getFileNumber() : null;
                        applicationDto.setFileNumber(fileNum);
                        statusTypeResults.put(applicationDto, UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED_OO);
                    }
                }
            } catch (Exception e) {
                logger.error("Error checking for existing marks by IR number", e);
                throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
            }
        }

    }

    @Override
    @Transactional
    public Map<ApplicationDto, UserTaskType> getIntrepidFiles(IntlIrTranDto intlIrTran) {
        List<Application> applications = applicationDao.getApplicationByIrNumber(intlIrTran.getIntlRegNo());
        Map<ApplicationDto, UserTaskType> filesByIrNumber = new HashMap<>();

        if (CollectionUtils.isNotEmpty(applications)) {
            for (Application application : applications) {

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    filesByIrNumber.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);
                } else {
                    filesByIrNumber.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                        UserTaskType.MESSAGE_RECEIVED_FOR_INACTIVE_MARK);

                }
            }
        }
        return filesByIrNumber;
    }

    @Override
    @Transactional
    public List<Integer> getLockedIntrepidFiles(String irNumber) {
        List<Application> applications = applicationDao.getApplicationByIrNumber(irNumber);
        List<Integer> lockedFileList = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(applications)) {
            for (Application application : applications) {

                try {
                    // Lock the application we are about to process
                    acquireTrademarkLock(application.getFileNumber(), 0, SectionAuthority.MADRID.name());
                    lockedFileList.add(application.getFileNumber());
                } catch (Exception e) {

                    // We cannot lock the application, so we will put it in a wait state
                    logger.debug("Unable to lock application with file number: " + application.getFileNumber(), e);
                }
            }
        }
        return lockedFileList;
    }

    @Override
    @Transactional
    public List<ConsoleTaskResponse> checkforInactiveMarks(String irNumber, BigDecimal irTranId) {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        List<Application> applications = applicationDao.getApplicationByIrNumber(irNumber);

        if (CollectionUtils.isEmpty(applications)) {
            return new ArrayList<>();
        }

        for (Application application : applications) {
            if (!ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_SUPERVISOR.name());
                statusTypeResults.put(applicationDto, UserTaskType.MESSAGE_RECEIVED_FOR_INACTIVE_MARK);

            }
        }

        return taskService.getUserTaskInformation(irTranId, statusTypeResults);
    }

    @Override
    @Transactional
    public List<Integer> getFileNumbers(String irNumber) {

        List<Integer> fileNumbers = new ArrayList<>();

        List<Application> applications = applicationDao.getApplicationByIrNumber(irNumber);
        for (Application application : applications) {

            fileNumbers.add(application.getFileNumber());

        }
        return fileNumbers;
    }

    @Override
    @Transactional
    public List<Integer> checkforMarks(String irNumber, BigDecimal irTranId) {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
        List<Integer> lockList = new ArrayList<>();

        List<Application> applications = applicationDao.getApplicationByIrNumber(irNumber);

        if (CollectionUtils.isEmpty(applications)) {
            return new ArrayList<>();
        }

        for (Application application : applications) {

            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);

            try {
                // Lock the application we are about to process
                acquireTrademarkLock(application.getFileNumber(), 0, SectionAuthority.MADRID.name());

                lockList.add(application.getFileNumber());

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    // check for active console tasks.
                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                        UserTaskType.AUTOMATED_TASK);
                } else {
                    applicationDto.setTaskStatusCode(TaskStatusType.ON_HOLD.getValue());
                    statusTypeResults.put(applicationDto, UserTaskType.AUTOMATED_TASK);
                }
            } catch (Exception e) {

                // We cannot lock the application, so we will put it in a wait state
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                    UserTaskType.AUTOMATED_TASK);
                applicationDto.setTaskStatusCode(TaskStatusType.WAITING.getValue());
            }
        }
        // TODO better name for this method or refactor. Tasks are created in here.
        taskService.getUserTaskInformation(irTranId, statusTypeResults);

        return lockList;
    }

    @Override
    @Transactional
    public boolean lockApplicationForTask(Integer fileNumber) {

        Application application = null;

        try {
            application = applicationDao.getApplication(fileNumber, 0);
            acquireTrademarkLock(application.getFileNumber(), 0, SectionAuthority.MADRID.name());
            return true;

        } catch (Exception e) {

            logger.debug("Unable to lock application " + application.getFileNumber(), e);

            return false;
        }
    }

    @Override
    @Transactional
    public boolean unlockApplicationForTask(Integer fileNumber) {

        Application application = null;

        try {
            application = applicationDao.getApplication(fileNumber, 0);
            releaseTrademarkLock(application.getFileNumber(), 0);
            return true;

        } catch (Exception e) {

            logger.debug("Unable to un-lock application " + application.getFileNumber(), e);

            return false;
        }
    }

    @Override
    @Transactional
    public void unlockApplicationForTasks(List<Integer> lockedFileList) {

        for (Integer lockedFile : lockedFileList) {

            try {
                Application application = applicationDao.getApplication(lockedFile, 0);

                releaseTrademarkLock(application.getFileNumber(), 0);
            } catch (Exception e) {

                logger.debug("Unable to un-lock application " + lockedFile, e);

            }
        }
    }

    @Override
    @Transactional
    public List<ConsoleTaskResponse> findDuplicateMark(String irNumber, String recordIdentifier, BigDecimal irTranId) {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        List<Application> applications = applicationDao.getApplicationByIds(irNumber, recordIdentifier);
        if (!CollectionUtils.isEmpty(applications)) {
            // Error - Application must not already exist.

            statusTypeResults.put(intrepidDTOFactory.getApplicationDto(applications.get(0), OfficeType.DO),
                UserTaskType.DUPLICATE_DESIGNATION_OCCURRED);

        }
        return taskService.getUserTaskInformation(irTranId, statusTypeResults);
    }

    @Override
    @Transactional
    public Application getApplicationByIrId(String irNumber, String recordIdentifier) throws MTSServiceFault {

        List<Application> applications = applicationDao.getApplicationByIds(irNumber, recordIdentifier);

        if (CollectionUtils.isEmpty(applications)) {
            throwMTSServiceFault("mts.holder.contact.missing.application", ExceptionReasonCode.DATABASE_DATA_INTEGRITY);
        }
        return applications.get(0);
    }

    @Override
    @Transactional
    public OutboundTransactionDto getMadridApplicationDetails(ProcessActionsMeta processActionsMeta)
        throws CIPOServiceFault {

        logger.debug("Getting application details for fileNumber: " + processActionsMeta.getFileNumber());

        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();

        OfficeType officeType = ProcessActionsMap.allProcessActionCodesMap.get(processActionsMeta.getProcessCode())
            .getOfficeType();

        if (officeType == OfficeType.OO
            || officeType == OfficeType.BOTH && !StringUtils.isBlank(processActionsMeta.getWipoReferenceNumber())) {

            MadridApplication madridApplication = null;

            if (StringUtils.isBlank(processActionsMeta.getWipoReferenceNumber())) {

                throwMTSServiceFault("mts.missing.wipo.reference", ExceptionReasonCode.RETRYABLE_ERROR);
            }

            madridApplication = madridApplicationDao
                .getMadridApplicationByReferenceNumber(processActionsMeta.getWipoReferenceNumber());

            String irNumber = null;

            if (null == madridApplication) {
                // madrid application not found
                throwMTSServiceFault("mts.missing.madrid.application", ExceptionReasonCode.INVALID_PROCESS_ACTION);
            } else {

                irNumber = madridApplication.getIrNumber();
            }

            List<TMInfoRetrievalDto> tirsDtoList = new ArrayList<>();

            if (madridApplication.getStatusCode().intValue() != MadridApplicationStatus.REGISTERED.getValue()
                .intValue()) {

                outboundTransactionDto.setRegisteredApplication(false);

                return outboundTransactionDto;
            }

            // If Registered, then an IR Number must exist.
            if (null == irNumber) {
                throwMTSServiceFault("mts.missing.ir.number", ExceptionReasonCode.INVALID_PROCESS_ACTION);
            }

            outboundTransactionDto.setIntlRegNo(madridApplication.getIrNumber());

            outboundTransactionDto.setOfficeType(officeType);
            outboundTransactionDto.setProcessActionApplication(
                getIntrepidApplication(processActionsMeta.getFileNumber(), processActionsMeta.getExtensionCounter()));

            List<MadridApplicationXref> madridApplicationXrefs = madridApplication.getMadridApplicationXrefs();
            for (MadridApplicationXref xref : madridApplicationXrefs) {
                // if (xref.getFileNumber() != processActionsMeta.getFileNumber().intValue()) {
                tirsDtoList.add(this.getIntrepidApplication(BigDecimal.valueOf(xref.getFileNumber()),
                    String.valueOf(xref.getExtensionCounter())));
                // }
            }

            outboundTransactionDto.setMadridApplicationActionDetails(tirsDtoList);

        } else {
            // DO
            this.getApplicationDetails(processActionsMeta.getFileNumber(), processActionsMeta.getExtensionCounter(),
                outboundTransactionDto);
        }
        return outboundTransactionDto;
    }

    @Override
    @Transactional
    public OutboundTransactionDto getMadridApplicationDetails(String irNumber, BigDecimal fileNumber,
                                                              String extensionCounter,
                                                              List<ca.gc.ic.cipo.tm.mts.ApplicationNumber> basicMarkList)
        throws CIPOServiceFault {

        logger.debug("Getting application details for fileNumber: " + fileNumber);

        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();
        List<TMInfoRetrievalDto> tirsDtoList = new ArrayList<>();

        outboundTransactionDto.setIntlRegNo(irNumber);
        outboundTransactionDto.setProcessActionApplication(getIntrepidApplication(fileNumber, extensionCounter));

        for (ca.gc.ic.cipo.tm.mts.ApplicationNumber xref : basicMarkList) {
            tirsDtoList
                .add(this.getIntrepidApplication(xref.getFileNumber(), String.valueOf(xref.getExtensionCounter())));
        }

        // check for specific action code - such as Potential Ceasing of Effect record
        boolean isPotentialCERecord = checkMatchedActionCode(irNumber);
        if (isPotentialCERecord) {
            outboundTransactionDto.setHasMatchedActionCode(true);
        }

        outboundTransactionDto.setMadridApplicationActionDetails(tirsDtoList);
        return outboundTransactionDto;
    }

    @Override
    @Transactional
    public OutboundTransactionDto getMadridApplicationDetails(BigDecimal fileNumber, String extensionCounter)
        throws CIPOServiceFault {

        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();

        this.getApplicationDetails(fileNumber, extensionCounter, outboundTransactionDto);

        return outboundTransactionDto;
    }

    private void getApplicationDetails(BigDecimal fileNumber, String extensionCounter,
                                       OutboundTransactionDto outboundTransactionDto)
        throws NumberFormatException, CIPOServiceFault {

        try {
            TMInfoRetrievalDto tmInfoRetrievalDto = this.getIntrepidApplication(fileNumber, extensionCounter);

            if (null == tmInfoRetrievalDto || StringUtils.isBlank(
                tmInfoRetrievalDto.getTrademarkApplicationDetailsType().getInternationalRegistrationNumber())) {

                throwMTSServiceFault("mts.missing.ir.number", ExceptionReasonCode.INVALID_PROCESS_ACTION);
            }
            outboundTransactionDto.setIntlRegNo(
                tmInfoRetrievalDto.getTrademarkApplicationDetailsType().getInternationalRegistrationNumber());

            outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalDto);

        } catch (CIPOServiceFault e) {

            logger.error("getApplicationDetails: fileNumber: " + fileNumber, e);
            throwMTSServiceFault("mts.create.outbound.transaction.error", ExceptionReasonCode.INVALID_PROCESS_ACTION);
        }

    }

    private TMInfoRetrievalDto getIntrepidApplication(BigDecimal fileNumber, String extensionCounter)
        throws CIPOServiceFault {

        TMInfoRetrievalDto tmInfoRetrievalBean = new TMInfoRetrievalDto();

        TMInfoRetrievalRegistrationRenewalServicePortType regRenewalClient = TrademarkInfoRetrievalRegistrationRenewalServiceFactory
            .createClient(tmirServiceHost);

        TMInfoRetrievalCommonServicePortType infoRetrievalClient = TrademarkInfoRetrievalCommonServiceFactory
            .createClient(tmirServiceHost);

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber.intValue());
        applicationNumber.setExtensionCounter(Integer.valueOf(extensionCounter));

        try {
            tmInfoRetrievalBean.setTrademarkApplicationDetailsType(
                infoRetrievalClient.getTrademarkApplicationDetails(applicationNumber));
            tmInfoRetrievalBean
                .setTrademarkApplicationType(infoRetrievalClient.getApplicationByNumber(applicationNumber));

            TMInterestedPartyBagType tmInterestedPartyBagType = infoRetrievalClient
                .getInterestedPartiesByApplication(applicationNumber);

            tmInfoRetrievalBean.setTmInterestedPartyTypeList(tmInterestedPartyBagType.getTMInterestedParty());
            GoodsServicesBagType goodsServicesBagType = infoRetrievalClient.getGoodsServices(applicationNumber);
            tmInfoRetrievalBean.setGoodsAndServices(goodsServicesBagType.getGoodsServices());

        } catch (ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault e) {

            logger.error("Error getting intrepid information from TrademarkInfoRetrievalCommonService.", e);
            throwMTSServiceFault("mts.create.outbound.transaction.error", ExceptionReasonCode.INVALID_PROCESS_ACTION);
        }

        try {
            ActionSearchCriterionType actionSearchCriterionType = new ActionSearchCriterionType();
            actionSearchCriterionType.setApplicationNumber(applicationNumber);
            tmInfoRetrievalBean.setTrademarkActionTypes(
                regRenewalClient.getActionsByApplicationNumber(actionSearchCriterionType).getActionsBag());

        } catch (ca.gc.ic.cipo.tm.tirs.regrenewal.CIPOServiceFault e) {
            logger.error("Error getting intrepid information from TMInfoRetrievalRegistrationRenewalService.", e);
            throwMTSServiceFault("mts.create.outbound.transaction.error", ExceptionReasonCode.INVALID_PROCESS_ACTION);
        }

        return tmInfoRetrievalBean;
    }

    @Override
    @Transactional
    public List<GoodsServicesClaimsType> getClaimsByGoodsServices(BigDecimal fileNumber, String extensionCounter)
        throws CIPOServiceFault {

        TMInfoRetrievalCommonServicePortType infoRetrievalClient = TrademarkInfoRetrievalCommonServiceFactory
            .createClient(tmirServiceHost);

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber.intValue());
        applicationNumber.setExtensionCounter(Integer.valueOf(extensionCounter));

        List<GoodsServicesClaimsType> claimsByGoods = new ArrayList<>();
        try {
            GoodsServicesClaimsBagType goodsServicesClaimsBagType = infoRetrievalClient
                .getClaimsByGoodsService(applicationNumber);

            claimsByGoods = goodsServicesClaimsBagType.getGoodsServicesClaims();

        } catch (ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault e) {
            logger.error("Error getting ClaimsByGoodsService information from TMInfoRetrievalCommonService.", e);
            throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
        return claimsByGoods;
    }

    @Override
    @Transactional
    public List<ConsoleTaskResponse> checkBeforeAutomatedProcess(BigDecimal irTranId) throws CIPOServiceFault {

        if (null == irTranId) {
            logger.error("irTranId are mandatory: ");
            throw new java.lang.IllegalArgumentException("irTranId is mandatory");
        }
        IntlIrTranDto transaction = internationalService.getTransactionsByIrTranId(irTranId);
        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(transaction.getIntlPkgTranType().getPkgTranCtgryId());

        // Ensure this is an automated transaction
        if (!MadridTransactionType.getAutomatedTransactionCategories().contains(transactionCategory)) {
            throwMTSServiceFault("mts.invalid.transaction.category", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        List<ConsoleTaskResponse> consoleTasks = new ArrayList<>();
        List<ConsoleTaskResponse> duplicateMark = new ArrayList<>();
        List<ConsoleTaskResponse> existingMark = new ArrayList<>();

        if (transactionCategory == TransactionCategory.MD_REGISTRATION
            || transactionCategory == TransactionCategory.MD_SUBSEQUENT_DESIGNATION) {

            duplicateMark = findDuplicateMark(transaction.getIntlRegNo(), transaction.getIntlRecordId(), irTranId);

        } else {
            existingMark = checkforExistingMarks(irTranId);
        }

        consoleTasks.addAll(existingMark);
        consoleTasks.addAll(duplicateMark);

        return consoleTasks;
    }

    @Override
    @Transactional
    public void completeProcessAction(ProcessActionsMeta processActionsMeta) {

        ProcessAction processAction = null;
        if (processActionsMeta.getProcessActionId() != null) {
            processAction = processActionDao
                .getById(Integer.valueOf(processActionsMeta.getProcessActionId().intValue()));
        }

        if (processActionsMeta.getProcessActionCodeType() == ProcessActionCodeType.MADRID_CANCELLATION) {
            return;
        }
        if (ProcessActionsMap.actionProcessActionMap.containsKey(processActionsMeta.getProcessCode())) {

            Application application = applicationDao.getApplication(processActionsMeta.getFileNumber().intValue(),
                Integer.valueOf(processActionsMeta.getExtensionCounter()));

            ActionCode actionCode = ProcessActionsMap.actionProcessActionMap.get(processActionsMeta.getProcessCode());
            String authorityId = getAuthorityId(processActionsMeta);
            Action action = createAction(application, actionCode, authorityId);
            action.setAdditionalInfo(processActionsMeta.getAdditionalInfo());
            if (processActionsMeta.getAdditionalInfo() != null) {
                if (processActionsMeta.getAdditionalInfo()
                    .startsWith(ManualReportUtil.getResponseToIrregularityMcKey())) {
                    String addInfo = processActionsMeta.getAdditionalInfo()
                        .replace(ManualReportUtil.getResponseToIrregularityMcKey(), "");
                    action.setAdditionalInfo(addInfo);
                } else if (processActionsMeta.getAdditionalInfo().startsWith("~")) {
                    action.setAdditionalInfo("");
                } else if (ProcessActionsMap.actionProcessActionAdditionalInfoMap
                    .containsKey(processActionsMeta.getProcessCode())) {
                    action.setAdditionalInfo(
                        ProcessActionsMap.actionProcessActionAdditionalInfoMap.get(processActionsMeta.getProcessCode())
                            .replaceFirst("##VALUE##", processActionsMeta.getAdditionalInfo()));
                }
            }
            if (processAction != null && action.getActionCode().equals(ActionCode.MF3_SENT.getValue())) {
                action.setResponseDate(getMF3ResponseDate(application, processAction));
            }

            actionDao.saveAction(action);
            applicationDao.saveApplication(application);
        }

        if (ProcessActionsMap.reverseActionProcessActionMap.containsKey(processActionsMeta.getProcessCode())) {
            ActionCode actionCode = ProcessActionsMap.reverseActionProcessActionMap
                .get(processActionsMeta.getProcessCode());
            String authorityId = getAuthorityId(processActionsMeta);
            String processMetaFileNumber = String.valueOf(processActionsMeta.getFileNumber().intValue());
            String procesMetaAdditionalInfo = processActionsMeta.getAdditionalInfo();

            String actionFileNumberStr = procesMetaAdditionalInfo;
            String actionAdditionalInfo = null;

            if (ProcessActionsMap.reverseActionProcessActionAdditionalInfoMap
                .containsKey(processActionsMeta.getProcessCode())) {
                actionAdditionalInfo = ProcessActionsMap.reverseActionProcessActionAdditionalInfoMap
                    .get(processActionsMeta.getProcessCode()).replaceFirst("##VALUE##", processMetaFileNumber);
            } else {
                actionAdditionalInfo = processMetaFileNumber;
            }

            if (StringUtils.isNumeric(actionFileNumberStr)) {
                int fileNumber = Integer.parseInt(actionFileNumberStr);
                Application application = applicationDao.getApplication(fileNumber, 0);
                Action action = createAction(application, actionCode, authorityId);
                action.setAdditionalInfo(actionAdditionalInfo);
                actionDao.saveAction(action);
                applicationDao.saveApplication(application);
            } else {
                logger.error(
                    "Unable to create action " + actionCode.getValue() + " for invalid file number in Additional info '"
                        + actionFileNumberStr + "' for processAction id: " + processActionsMeta.getProcessActionId());
            }

        }

        // Remove the process action from Intrepid as processing is complete.
        if (processAction != null) {
            processActionDao.deleteProcessAction(processAction);
        }

    }

    /**
     * Sets the error process action. So that same process action is not re-processed after an exception found
     *
     * @param processActionsMeta the new error process action
     */
    @Override
    @Transactional
    public void setErrorProcessAction(ProcessActionsMeta processActionsMeta) {
        ProcessAction processAction = null;
        // Get process action if it's available
        if (processActionsMeta.getProcessActionId() != null) {
            processAction = processActionDao
                .getById(Integer.valueOf(processActionsMeta.getProcessActionId().intValue()));

            processAction.setAdditionalInfo(
                processActionsMeta.getAdditionalInfo() + " PA:" + processActionsMeta.getProcessCode());
            processAction.setProcessCode(999);

            processActionDao.saveProcessActions(processAction);
        }

    }

    private Date getMF3ResponseDate(Application application, ProcessAction processAction) {
        Date responseDate = null;

        boolean isExaminer = processAction.getOppositionCaseNumber() == null;

        if (isExaminer) {
            List<Action> actions = actionDao.getActions(application.getFileNumber(), application.getExtensionCounter());

            for (Action action : actions) {
                if (action.getResponseDate() != null) {
                    if (action.getActionCode().equals(ActionCode.APPLICATION_CREATED.getValue())) {
                        Date actionDate = action.getResponseDate();
                        if (responseDate == null) {
                            responseDate = actionDate;
                        } else if (actionDate != null && responseDate.before(actionDate)) {
                            responseDate = actionDate;
                        }
                    }
                    if (action.getActionCode().equals(ActionCode.EXAMINER_FIRST_REPORT.getValue())) {// examiner
                                                                                                     // first
                                                                                                     // report
                        Date actionDate = action.getResponseDate();
                        if (responseDate == null) {
                            responseDate = actionDate;
                        } else if (actionDate != null && responseDate.before(actionDate)) {
                            responseDate = actionDate;
                        }
                    }
                }

            }
        } else {
            ca.gc.ic.cipo.tm.model.ApplicationNumber applicationNum = new ca.gc.ic.cipo.tm.model.ApplicationNumber(
                application.getFileNumber(), application.getExtensionCounter());
            OppositionCaseAction oppositionCaseAction = oppositionCaseActionDao.getOppositionCaseAction(applicationNum,
                processAction.getOppositionCaseNumber(),
                OppositionCaseActionCodeType.DEADLINE_TO_FILE_COUNTER_STATEMENT.getValue());

            if (oppositionCaseAction != null && oppositionCaseAction.getEffectiveDate() != null) {
                responseDate = oppositionCaseAction.getEffectiveDate();
            }

        }

        return responseDate;

    }

    private String getAuthorityId(ProcessActionsMeta processActionsMeta) {

        if (processActionsMeta.getAuthorityId() != null) {
            return processActionsMeta.getAuthorityId();
        } else {
            return SectionAuthority.MADRID.name();
        }

    }

    @Override
    @Transactional
    public List<ConsoleTaskResponse> checkForPartialOwnershipChangeNotifications(CheckForNotificationsRequest request,
                                                                                 Integer originalApplicationFileNumber,
                                                                                 Integer newApplicationFileNumber) {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        ValidateWipoTransactionUtil validateWipoTransactionUtil = ValidateWipoTransactionUtil.getInstance();

        Application newApplication = applicationDao.getApplication(newApplicationFileNumber, 0); // original application

        Application originalApplication = applicationDao.getApplication(originalApplicationFileNumber,
            Integer.valueOf(0));

        if (newApplication != null) {
            ApplicationDto newApplicationDto = intrepidDTOFactory.getApplicationDto(newApplication, OfficeType.DO);

            Set<InterestedParty> interestedParties = newApplication.getInterestedParties();

            // check mailing address ON NEW FILE already created from the manual task submission.
            for (InterestedParty interestedParty : interestedParties) {
                if (interestedParty.getContact() != null
                    && !statusTypeResults.containsValue(UserTaskType.ADDRESS_EXCEEDED_LIMIT)) {

                    Set<InterestedPartiesAddresses> interestedPartyAddressSet = interestedParty.getContact()
                        .getInterestedPartiesAddresses();

                    for (InterestedPartiesAddresses mailingAddress : interestedPartyAddressSet) {
                        if (mailingAddress.getAddressType().intValue() == AddressType.MAILING.getValue().intValue()) {

                            // validate the address size
                            if (validateWipoTransactionUtil
                                .mailingAddressLengthNotification(mailingAddress.getAddress())) {
                                logger.info("Mailing address for this application file number <"
                                    + newApplication.getFileNumber()
                                    + "> exceed line limit or max line length. Notification is generated to user task.");
                                // Setup notification
                                statusTypeResults.put(newApplicationDto, UserTaskType.ADDRESS_EXCEEDED_LIMIT);
                            }
                            break;
                        }
                    }

                }
            }

        }
        // Check opposition cases for original and new application
        Map<ApplicationDto, UserTaskType> newApplicationNotifications = checkOppositionCases(newApplication,
            ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE, SectionAuthority.OPPS45);

        Map<ApplicationDto, UserTaskType> originalApplicationNotifications = checkOppositionCases(originalApplication,
            ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE, SectionAuthority.OPPS45);

        // Notify TMB Supervisor to Review Partial Change of Ownership
        if (request.getNotificationStatusType() != null) {
            switch (request.getNotificationStatusType()) {
                case PART_OWNERSHIP_DESIGNATION:
                    logger.info(
                        "Notification to review partial ownership change for designation application file number <"
                            + newApplication.getFileNumber() + ">");
                    newApplicationNotifications.put(intrepidDTOFactory.getApplicationDto(newApplication, OfficeType.DO),
                        UserTaskType.REVIEW_PARTIAL_OWNERSHIP_CHANGE);
                    break;
                case PART_OWNERSHIP_RESTRICTION:
                    logger.info(
                        "Notification to review partial ownership change for restriction application file number <"
                            + originalApplication.getFileNumber() + ">");
                    originalApplicationNotifications.put(
                        intrepidDTOFactory.getApplicationDto(originalApplication, OfficeType.DO),
                        UserTaskType.REVIEW_PARTIAL_OWNERSHIP_CHANGE);
                    break;
                case PART_OWNERSHIP_BOTH:
                    logger.info("Notification to review partial ownership change for both designation file number <"
                        + newApplication.getFileNumber() + "> and restriction file number <"
                        + originalApplication.getFileNumber() + ">");
                    newApplicationNotifications.put(intrepidDTOFactory.getApplicationDto(newApplication, OfficeType.DO),
                        UserTaskType.REVIEW_PARTIAL_OWNERSHIP_CHANGE);
                    originalApplicationNotifications.put(
                        intrepidDTOFactory.getApplicationDto(originalApplication, OfficeType.DO),
                        UserTaskType.REVIEW_PARTIAL_OWNERSHIP_CHANGE);

                    break;
                default:

                    break;

            }
        }

        statusTypeResults.putAll(newApplicationNotifications);
        statusTypeResults.putAll(originalApplicationNotifications);

        List<ConsoleTaskResponse> consoleTasks = taskService.getUserTaskInformation(request.getIrTranId(),
            statusTypeResults);

        List<ConsoleTaskResponse> consoleResponseList = new ArrayList<>();

        for (ConsoleTaskResponse consoleTaskResponse : consoleTasks) {
            ConsoleTaskResponse consoleTaskDesc = new ConsoleTaskResponse();
            consoleTaskDesc.setConsoleTaskId(consoleTaskResponse.getConsoleTaskId());
            UserTaskType taskType = UserTaskType
                .getStatusTypeByValue(new BigDecimal(consoleTaskResponse.getUserTaskType()));
            SectionAuthority sectionAuthority = NotificationTaskAuthorityUtil.getSectionAuthority(taskType);

            consoleTaskDesc.setConsoleTaskGroupId(sectionAuthority.toString());

            logger.info("Console task Id <" + consoleTaskResponse.getConsoleTaskId() + "> was created. Task type <"
                + taskType + "> assigned to group <" + sectionAuthority + ">");
            consoleResponseList.add(consoleTaskDesc);
        }

        return consoleResponseList;

    }

    @Override
    @Transactional
    public List<ConsoleTaskResponse> checkForNotifications(CheckForNotificationsRequest request,
                                                           Integer applicationFileNumber, IntlIrTranDto intlIrTranDto,
                                                           Object transaction, UserTaskType userTaskType)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        Application application = applicationDao.getApplication(applicationFileNumber, Integer.valueOf(0));

        // Total cancellation/ceasing/limitation.
        if (request.getNotificationStatusType() != null
            && request.getNotificationStatusType().equals(NotificationStatusType.TOTAL_AND_NOTIFICATION)) {

            logger.info("This IR Trsansaction <" + request.getIrTranId()
                + "> is total cancellation/ceasing/limitation. Total cancellation actions are being processed");

            if (userTaskType == UserTaskType.IR_TOTAL_CANCELLATION) {
                Map<ApplicationDto, UserTaskType> applicationNotifications = processTotalCancellationApplication(
                    application, transaction, userTaskType);
                statusTypeResults.putAll(applicationNotifications);
            } else if (userTaskType == UserTaskType.TOTAL_CEASING_OF_EFFECT_DO) {
                Map<ApplicationDto, UserTaskType> applicationNotifications = processTotalCeasingOfEffectDO(application,
                    transaction, userTaskType);
                statusTypeResults.putAll(applicationNotifications);
            }

        } else {
            logger.info(
                "This IR Trsansaction <" + request.getIrTranId() + "> is not total cancellation/ceasing/limitation.");
        }

        // Mail Attached Indicator is set to ‘Processed’
        logger.info("Setting up mail processed indicator...");
        List<Mail> mailList = mailDao.getMailByFileId(application.getFileNumber());
        if (CollectionUtils.isNotEmpty(mailList)) {
            for (Mail mail : mailList) {
                mail.setMailAttachedInd(MAIL_PROCESSED_INDICATOR);
                mailDao.saveMail(mail);
            }

        }

        List<ConsoleTaskResponse> consoleTasks = taskService.getUserTaskInformation(request.getIrTranId(),
            statusTypeResults);

        List<ConsoleTaskResponse> consoleResponseList = new ArrayList<>();

        for (ConsoleTaskResponse consoleTaskResponse : consoleTasks) {
            ConsoleTaskResponse consoleTaskDesc = new ConsoleTaskResponse();
            consoleTaskDesc.setConsoleTaskId(consoleTaskResponse.getConsoleTaskId());
            UserTaskType taskType = UserTaskType
                .getStatusTypeByValue(new BigDecimal(consoleTaskResponse.getUserTaskType()));
            SectionAuthority sectionAuthority = NotificationTaskAuthorityUtil.getSectionAuthority(taskType);

            consoleTaskDesc.setConsoleTaskGroupId(sectionAuthority.toString());

            logger.info("Console task Id <" + consoleTaskResponse.getConsoleTaskId() + " was created. Task type <"
                + taskType + "> assigned to group <" + sectionAuthority + ">");
            consoleResponseList.add(consoleTaskDesc);

        }

        return consoleResponseList;

    }

    @Override
    @Transactional
    public String checkOppositionCase(BigDecimal fileNumber) {
        boolean openOppositionCaseExists = false;

        Application application = getApplicationModel(fileNumber.intValue());

        if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {

            openOppositionCaseExists = oppositionCasesExist(application, registeredOppositionCaseTypes,
                TradeMarkStatusType.REGISTERED);

        } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
            .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

            openOppositionCaseExists = oppositionCasesExist(application, unRegisteredOppositionCaseTypes,
                TradeMarkStatusType.REGISTRATION_PENDING);
        }

        if (openOppositionCaseExists) {
            // Assign the Task to ‘TMOB Operator’
            return IntlAuthorityRole.MC_TMOB_OPERATOR.name();
        } else {
            // Assign the Task to ‘Madrid TM Examiner’
            return IntlAuthorityRole.MC_TM_EXAMINER.name();
        }
    }

    private boolean oppositionCasesExist(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                         TradeMarkStatusType nonRenewalType) {

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    return true;

                }
            }
        }
        return false;
    }

    private Map<ApplicationDto, UserTaskType> checkOppositionCases(Application application,
                                                                   ProcessActionsType processActionsType,
                                                                   SectionAuthority sectionAuthority) {

        Map<ApplicationDto, UserTaskType> notificationTypeResults = new HashMap<>();

        if (application.getStatusCode() == TradeMarkStatusType.REGISTERED.getValue()) {

            // process open section 45 cases
            if (processOppositionCases(application, registeredOppositionCaseTypes, TradeMarkStatusType.REGISTERED,
                processActionsType, sectionAuthority)) {

                logger.info("Application file number <" + application.getFileNumber() + ">. Status <"
                    + TradeMarkStatusType.getByValue(application.getStatusCode())
                    + "> has open opposition case. TMOB Notification is created.");
                notificationTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                    UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED);

            }
        } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
            .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

            if (processOppositionCases(application, unRegisteredOppositionCaseTypes,
                TradeMarkStatusType.REGISTRATION_PENDING, processActionsType, sectionAuthority)) {

                logger.info("Application file number <" + application.getFileNumber() + ">. Status <"
                    + TradeMarkStatusType.getByValue(application.getStatusCode())
                    + "> has open opposition case. TMOB Notification is created.");
                // create same user task as registered...
                notificationTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                    UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED);

            }
        }
        return notificationTypeResults;
    }

    // For partial ownership
    private boolean processOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                           TradeMarkStatusType tradeMarkStatusType,
                                           ProcessActionsType processActionsType, SectionAuthority sectionAuthority) {

        boolean open = false;
        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    open = true;

                    // Notify the requestor(s) or opponents(s)
                    processActionDao.saveProcessActions(createProcessAction(application, processActionsType,
                        oppositionCase.getOppCaseNumber(), sectionAuthority.name()));

                }
            }
        }
        return open;
    }

    private boolean processAndCloseOppositionCases(Application application,
                                                   EnumSet<OppositionCaseType> oppositionCaseTypes,
                                                   TradeMarkStatusType tradeMarkStatusType) {
        boolean open = false;
        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    open = true;

                    oppositionCase.setOppStatusCode(OppositionCaseStatus.CLOSED.getValue());

                    oppositionCaseDao.saveOppositionCase(oppositionCase);

                    OppositionCaseAction oppositionCaseAction = createOppositionCaseAction(application, oppositionCase,
                        tradeMarkStatusType, SectionAuthority.OPPS45.name());

                    oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
                    oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
                    applicationDao.saveApplication(application);

                }
            }
        }
        return open;
    }

    private Map<ApplicationDto, UserTaskType> processTotalCancellationApplication(Application application,
                                                                                  Object transaction,
                                                                                  UserTaskType userTaskType)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        // Record Applications with the same IR Number
        statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

        if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
            .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

            if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {

                // Cancel application
                application.setStatusCode(TradeMarkStatusType.CANCELLED_BY_OWNER.getValue());

                actionDao.saveAction(createAction(transaction, application, ActionCode.CANCELLED_BY_OWNER,
                    SectionAuthority.MADRID.name(), null));

                // Process Action - Print Cancelled by Owner Notification’ ’
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processAndCloseOppositionCases(application, registeredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTERED)) {

                    logger.info("Application file number <" + application.getFileNumber() + ">. Status <"
                        + TradeMarkStatusType.getByValue(application.getStatusCode())
                        + "> has open opposition case. TMOB Notification is created.");

                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                        userTaskType);
                }

                applicationDao.saveApplication(application);

            } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                // Not Registered
                // Withdraw application
                application.setStatusCode(TradeMarkStatusType.WITHDRAWN_OWNER.getValue());

                actionDao.saveAction(createAction(transaction, application, ActionCode.WITHDRAWN_BY_OWNER,
                    SectionAuthority.MADRID.name(), null));

                // Process Action - Print Withdrawn by Owner Notification
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processAndCloseOppositionCases(application, unRegisteredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTRATION_PENDING)) {

                    logger.info("Application file number <" + application.getFileNumber() + ">. Status <"
                        + TradeMarkStatusType.getByValue(application.getStatusCode())
                        + "> has open opposition case. TMOB Notification is created.");

                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                        userTaskType);
                }

                applicationDao.saveApplication(application);
            }

        } else {
            logger.error(
                "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
        }
        return statusTypeResults;
    }

    private Map<ApplicationDto, UserTaskType> processTotalCeasingOfEffectDO(Application application, Object transaction,
                                                                            UserTaskType userTaskType)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        // Record Applications with the same IR Number
        statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

        if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
            .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

            if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {

                // Cancel application
                application.setStatusCode(TradeMarkStatusType.CANCELLED.getValue());

                actionDao.saveAction(
                    createAction(transaction, application, ActionCode.CANCELLED, SectionAuthority.MADRID.name(), null));

                // Process Action - Print Cancelled Notification’ ’
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_CANCELLED_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processAndCloseOppositionCases(application, registeredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTERED)) {

                    logger.info("Application file number <" + application.getFileNumber() + ">. Status <"
                        + TradeMarkStatusType.getByValue(application.getStatusCode())
                        + "> has open opposition case. TMOB Notification is created.");

                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                        userTaskType);
                }

                applicationDao.saveApplication(application);

            } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                // Not Registered
                // Withdraw application
                application.setStatusCode(TradeMarkStatusType.WITHDRAWN.getValue());

                actionDao.saveAction(
                    createAction(transaction, application, ActionCode.WITHDRAWN, SectionAuthority.MADRID.name(), null));

                // Process Action - Print Withdrawn by Owner Notification
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_WITHDRAWN_NOTIFICATION, SectionAuthority.MADRID.name()));

                if (processAndCloseOppositionCases(application, unRegisteredOppositionCaseTypes,
                    TradeMarkStatusType.REGISTRATION_PENDING)) {

                    logger.info("Application file number <" + application.getFileNumber() + ">. Status <"
                        + TradeMarkStatusType.getByValue(application.getStatusCode())
                        + "> has open opposition case. TMOB Notification is created.");

                    statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                        userTaskType);
                }

                applicationDao.saveApplication(application);
            }

        } else {
            logger.error(
                "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
        }
        return statusTypeResults;
    }

    @Override
    @Transactional
    public ApplicationDto getApplication(Integer fileNumber) {
        return intrepidDTOFactory.getApplicationDto(applicationDao.getApplication(fileNumber, 0));
    }

    @Override
    @Transactional
    public Application getApplicationModel(Integer fileNumber) {
        return applicationDao.getApplication(fileNumber, 0);
    }

    @Override
    @Transactional
    public Date getInternationRegistrationDate(int fileNum, Integer extensioncounter) {
        Date internationalRegDate = null;

        Application application = applicationDao.getApplication(fileNum,
            extensioncounter == null ? 0 : extensioncounter);

        if (application != null) {
            List<Action> actions = actionDao.getActions(application);
            if (actions != null && !actions.isEmpty()) {
                for (Action action : actions) {
                    if (Integer.compare(action.getActionCode(),
                        ActionCode.INTERNATIONAL_REGISTRATION.getValue()) == 0) {
                        internationalRegDate = action.getActionDate();
                    }

                }
            }
        }
        return internationalRegDate;

    }

    @Override
    @Transactional
    public void updateMailProcessedStatus(BigDecimal fileNumber, MailType mailType, String authorityId) {

        if (fileNumber == null) {
            throw new IllegalArgumentException(
                "Must provide a fileNumber to update the Mail Record for mailType :" + mailType);
        }

        List<Mail> mailList = mailDao.getMailByFileId(fileNumber.intValue());

        boolean mailFound = false;
        if (CollectionUtils.isNotEmpty(mailList)) {
            for (Mail mail : mailList) {
                if ((mailType == null || mailType.getValue().equals(mail.getMailType()))
                    && mail.getMailAttachedInd().intValue() == 0) {
                    mailFound = true;
                    if (mailType == null) {
                        mailDao.updateMailAttachedIndicatorWithAuthority(fileNumber.intValue(), authorityId,
                            mail.getFileType());
                    } else {
                        mailDao.updateMailAttachedIndicatorWithAuthority(fileNumber.intValue(), authorityId,
                            mail.getFileType(), mailType.getValue());
                    }
                }
            }
        }

        if (!mailFound) {
            logger.info("No Mail found that can be updated for fileNumber : " + fileNumber.intValue()
                + (mailType == null ? "." : ", MailType : " + mailType.name() + "."));
        }

    }

    @Override
    public HolderInfo getHolderInfoFromWipo(String intlRegNumber) throws CIPOServiceFault {
        FindHolder wipoHolderService = WipoHolderServiceFactory.createWipoHolderClient();
        HolderInfo info = null;
        try {
            info = wipoHolderService.retreiveHolderRequest(intlRegNumber);
        } catch (Exception e) {
            logger.error("updateHolderContactDetails: intlRegNumber: " + intlRegNumber, e);

            throwMTSServiceFault("mts.holder.contact.wipo", ExceptionReasonCode.SYSTEM_ERROR); // so we tell MWE to
            // not
        } // call us again as WIPO
          // is down
        return info;

    }

    @Override
    @Transactional
    public UpdateHolderContactDetailsResponse updateHolderContactDetails(BigDecimal irTranId, BigDecimal taskId)
        throws CIPOServiceFault {
        logger.debug("Updating Holder Contact Details for TransactionId: " + irTranId + ", TaskId " + taskId);

        IntlIrTranDto intlIrTranDto = internationalService.getTransactionsByIrTranId(irTranId);
        String intlRegNumber = intlIrTranDto.getIntlRegNo();
        HolderInfo info = getHolderInfoFromWipo(intlRegNumber);

        String phone = null;
        String email = null;
        HolderInfo.ApplicantDetails applicantDetails = info.getApplicantDetails();
        if (applicantDetails != null) {
            List<ApplicantType> applicant = applicantDetails.getApplicant();
            if (applicant != null && !applicant.isEmpty()) {
                ApplicantType appType = applicant.get(0); // get the first one as primary one
                AddressBookType addrBookType = appType.getApplicantAddressBook();
                if (addrBookType != null) {
                    ContactInformationDetailsType contactDetailsType = addrBookType.getContactInformationDetails();
                    if (contactDetailsType != null) {
                        phone = contactDetailsType.getPhone();
                        email = contactDetailsType.getEmail();
                    }
                }

            }
        }
        if (phone == null && email == null) {
            internationalService.updateTaskStatus(taskId, TaskStatusType.PROCESSED);
            return new UpdateHolderContactDetailsResponse();
        }

        List<Application> applications_lists = applicationDao.getApplicationByIrNumber(intlRegNumber);
        if (applications_lists == null || applications_lists.isEmpty()) {
            throwMTSServiceFault("mts.holder.contact.missing.application", ExceptionReasonCode.DATABASE_DATA_INTEGRITY);
        }
        for (Application application : applications_lists) {
            for (InterestedParty interestedParty : application.getInterestedParties()) {
                if (interestedParty.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {
                    IPContact contact = interestedParty.getContact();
                    contact.setEmailAddress(email);
                    contact.setPhoneNumber(phone);
                }

            }
            applicationDao.saveApplication(application);
        }
        if (taskId != null) {
            internationalService.updateTaskStatus(taskId, TaskStatusType.PROCESSED);
        }
        return new UpdateHolderContactDetailsResponse();
    }

    private boolean checkMatchedActionCode(String irNumber) {
        List<MadridApplication> madridApplicationsList = madridApplicationDao.getMadridApplicationByIrNumber(irNumber);

        if (!CollectionUtils.isEmpty(madridApplicationsList)) {
            for (MadridApplication madridApplication : madridApplicationsList) {
                Set<MadridApplicationAction> actions = madridApplication.getMadridApplicationActions();

                for (MadridApplicationAction action : actions) {
                    Integer actionCode = action.getActionCode();
                    if (actionCode.intValue() == MadridApplicationActionStatus.POTENTIAL_CEASING_EFFECT_RECORD
                        .getValue()) {

                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW) //Use separate transaction to make sure the lock commits immeditaly
    public void acquireTrademarkLock(Integer fileNumber, Integer extensionCounter, String userName) {

        StringBuilder lockMsg = new StringBuilder();
        lockMsg.append("Locking application ").append(fileNumber);
        logger.debug(lockMsg.toString());

        tradeMarkLockDao.acquireLock(fileNumber, extensionCounter, userName);
    }

    @Override
    @Transactional
    public void releaseTrademarkLock(Integer fileNumber, Integer extensionCounter) {

        StringBuilder lockMsg = new StringBuilder();
        lockMsg.append("Unlocking application ").append(fileNumber);
        logger.debug(lockMsg.toString());

        tradeMarkLockDao.releaseLock(fileNumber, extensionCounter);
    }

    @Override
    @Transactional
    public int getProcessActionCount() throws Exception {
        return processActionDao.getCount(ProcessActionsMap.allProcessActionCodesMap.keySet());
    }

    @Override
    @Transactional
    public String getSectionAuthorityId(String userId) throws CIPOServiceFault {
        logger.debug("getSectionAuthorityId for userId: " + userId);

        return authoritiesDao.getAuthoritiesInformationByAuthorityUserId(userId).getSectionAuthorityId();
    }

    @Override
    @Transactional
    public void completeIrregularityProcessAction(ProcessActionsMeta processActionsMeta) {
        ActionCode actionCode = ProcessActionsMap.actionProcessActionMap.get(processActionsMeta.getProcessCode());
        String authorityId = getAuthorityId(processActionsMeta);

        // DO
        if (processActionsMeta.getFileNumber() != null) {
            Application application = applicationDao.getApplication(processActionsMeta.getFileNumber().intValue(),
                Integer.valueOf(processActionsMeta.getExtensionCounter()));

            Action action = createAction(application, actionCode, authorityId);
            action.setAdditionalInfo(processActionsMeta.getAdditionalInfo());
            actionDao.saveAction(action);
            applicationDao.saveApplication(application);

        } else if (StringUtils.isNotBlank(processActionsMeta.getWipoReferenceNumber())) { // OO
            MadridApplication madridApplication = madridApplicationDao
                .getMadridApplicationByReferenceNumber(processActionsMeta.getWipoReferenceNumber());

            String additionalInfo = "Response text: " + processActionsMeta.getAdditionalInfo();
            saveMadridApplicationAction(madridApplication, authorityId, additionalInfo);

        }

    }

    @Override
    @Transactional
    public String countryLookup(String country, LanguageType languageType) throws MTSServiceFault {

        CountryProvince countryProvince = null;
        Integer language = ca.gc.ic.cipo.tm.enumerator.LanguageType.ENGLISH.getValue(); // english
        if (languageType == LanguageType.FRENCH) {
            language = ca.gc.ic.cipo.tm.enumerator.LanguageType.FRENCH.getValue(); // french
        }
        try {
            countryProvince = countryProvinceLookupDao.getCountry(country, language);

        } catch (Exception e) {
            logger.error("Country not found: " + country + " - " + e.getMessage());
            throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
        }
        return countryProvince.getDescription();
    }

    @Override
    @Transactional
    public InterestedPartyDto getInterestedParty(ApplicationDto applicationDto) throws MTSServiceFault {

        InterestedParty interestedParty = interestedPartyDao.getApplicant(applicationDto.getFileNumber(), 0);

        InterestedPartyDto interestedPartyDto = new InterestedPartyDto();
        interestedPartyDto.setInterestedPartyContactName(interestedParty.getContact().getName());
        interestedPartyDto.setInterestedPartyReference(interestedParty.getReference());

        return interestedPartyDto;
    }

    @Override
    @Transactional
    public String getTradeMark(ApplicationDto application) throws MTSServiceFault {
        String tradeMarkText = "";
        TradeMark tm = trademarkDao.getTrademark(application.getFileNumber());
        if (tm != null) {
            tradeMarkText = tm.getText();
        }

        return tradeMarkText;
    }

    @Override
    @Transactional
    public void createMailInProgress(List<IntlIrTaskDto> taskList, BigDecimal irTranId) throws MTSServiceFault {

        for (IntlIrTaskDto task : taskList) {

            Application application = applicationDao.getApplication(task.getFileNumber().intValue(), 0);

            IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(irTranId);

            TransactionCategory transactionCategory = TransactionCategory
                .getTransactionCategoryByValue(intlIrTran.getIntlPkgTranType().getPkgTranCtgryId());

            int mailIndicator = MAIL_INDICATOR_AUTOMATED;

            if (transactionCategory == TransactionCategory.MC_CORRECTION
                || transactionCategory == TransactionCategory.MI_IRREGULARITY_NOTIFICATION
                || transactionCategory == TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION
                || transactionCategory == TransactionCategory.MPR_PARTIAL_CEASING_OF_EFFECT
                || transactionCategory == TransactionCategory.MPR_PARTIAL_CANCELLATION
                || transactionCategory == TransactionCategory.MPR_LIMITATION) {

                mailIndicator = MAIL_INDICATOR_MANUAL;
            }

            // create Mail object
            createMail(application, intlIrTran, mailIndicator);

        }
    }

    @Override
    @Transactional
    public String getCitedRegistrationNumber(int fileNumber, int extensionCounter) {
        String citedRegistrationNumber = MtsStringUtil.EMPTY;

        Application application = applicationDao.getApplication(fileNumber, extensionCounter);

        if (application != null) {
            Integer legislation = application.getLegislation();
            Integer registrationNumber = application.getRegistrationNumber();
            citedRegistrationNumber = CitedRegistrationNumberUtil.getCitedRegNumber(legislation, registrationNumber);
        }

        return citedRegistrationNumber;
    }

}
