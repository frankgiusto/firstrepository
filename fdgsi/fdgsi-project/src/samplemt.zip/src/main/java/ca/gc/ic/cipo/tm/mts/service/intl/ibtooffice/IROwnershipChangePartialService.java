package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.ICourtesyLetterService;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * @author giustof
 *
 */
@Service(value = "partialOwnershipChange")
public class IROwnershipChangePartialService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private FootNotesDao footnotesDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private ICourtesyLetterService courtestyLetterService;

    private static Logger logger = Logger.getLogger(IROwnershipChangePartialService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
        MadridPartialChangeOwnershipType madridPartialChangeOwnership = (MadridPartialChangeOwnershipType) transType;

        String irNumber = madridPartialChangeOwnership.getMadridProtectionRestriction() != null
            ? madridPartialChangeOwnership.getMadridProtectionRestriction().getInternationalRegistrationNumber()
            : madridPartialChangeOwnership.getMadridDesignationTermination().getInternationalRegistrationNumber();

        List<MadridApplication> madridApplications = madridApplicationDao.getMadridApplicationByIrNumber(irNumber);
        int arNum = 0;

        logger.debug("madridApplications has elements of <" + madridApplications + ">.");

        // check if courtesy letter is required
        if (null != madridPartialChangeOwnership.getMadridDesignation()) {
            logger.debug("getRepresentative != null in getMadridDesignation "
                + madridPartialChangeOwnership.getMadridDesignation().getRepresentative());

            // check if a courtesy letter required
            if (null != madridPartialChangeOwnership.getMadridDesignation().getRepresentative()) {
                arNum = checkAndProcessCourtesyLetter(intlIrTran, statusTypeResults, madridPartialChangeOwnership);
            }
        }

        // CIPO is the OO for this IR. Notification will be based on an OO application
        if (CollectionUtils.isNotEmpty(madridApplications)) {
            logger.info("Partial Ownership change: the IR Number <" + irNumber + "> for the IR transaction <"
                + intlIrTran.getIrTranId()
                + "> exists from Intrepid Madrid Applications. Therefor will treat CIPO as Office of Origin.");
            processNotification(irNumber, madridApplications, statusTypeResults);

            // DO notification for Protection Restriction transaction.
        } else if (null != madridPartialChangeOwnership.getMadridProtectionRestriction()) {
            logger.info("Partial Ownership change: the IR Number <" + irNumber + "> for the IR transaction <"
                + intlIrTran.getIrTranId() + "> is protection restriction type.");
            this.processIRChangeOwnershipPartial(madridPartialChangeOwnership, intlIrTran,
                madridPartialChangeOwnership.getMadridProtectionRestriction().getInternationalRegistrationNumber(),
                statusTypeResults);

            // DO notification for Designation Termination transaction.
        } else if (null != madridPartialChangeOwnership.getMadridDesignationTermination()) {
            logger.info("Partial Ownership change: the IR Number <" + irNumber + "> for the IR transaction <"
                + intlIrTran.getIrTranId() + "> is designation termination type.");
            this.processIRChangeOwnershipPartial(madridPartialChangeOwnership, intlIrTran,
                getApplicationLanguage(madridPartialChangeOwnership.getMadridDesignation().getNotificationLanguage()),
                statusTypeResults, arNum);
        }

        return statusTypeResults;
    }

    public Map<ApplicationDto, UserTaskType> processIRChangeOwnershipPartial(MadridPartialChangeOwnershipType madridPartialChangeOwnership,
                                                                             IntlIrTranDto intlIrTran,
                                                                             LanguageType applicationLanguage,
                                                                             Map<ApplicationDto, UserTaskType> statusTypeResults,
                                                                             int arNum)
        throws MTSServiceFault {

        logger.debug("Processing IR Change Ownership partial (designation / termination) -  Intl Reg Num:"
            + madridPartialChangeOwnership.getMadridDesignation().getInternationalRegistrationNumber());

        TaskStatusType taskStatusType = null;

        // Get all applications matching transactions international registration number of the Designation Termination.
        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    taskStatusType = TaskStatusType.UNPROCESSED;
                } else {
                    taskStatusType = TaskStatusType.ON_HOLD;
                }

                Set<InterestedParty> interestedParties = application.getInterestedParties();

                if (CollectionUtils.isNotEmpty(interestedParties)) {
                    for (InterestedParty interestedParty : interestedParties) {
                        if (interestedParty.getRelationshipType().intValue() == RelationshipType.OWNER.getValue()
                            .intValue()) {

                            interestedParty.setRelationshipType(RelationshipType.OLD_OWNER.getValue());

                            interestedPartyDao.saveInterestedParty(interestedParty);
                        }
                    }

                    List<ApplicantType> holderList = madridPartialChangeOwnership.getMadridDesignation().getHolderBag()
                        .getHolder();

                    if (CollectionUtils.isEmpty(holderList)) {
                        logger.error("madridDesignationType.getHolderBag() is empty!");
                        continue;
                    }
                    if (holderList.size() > 1) {
                        // Notification to review ownership change
                        statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                            UserTaskType.IR_HOLDER_NAME_ADDRESS_CHANGE_OCCURRED);
                    }
                    InterestedParty interestedParty = createCOPInterestedParty(application,
                        getNextInterestedPartySequence(interestedParties));

                    // Create the Contact Information
                    setInterestedPartyContact(applicationLanguage, holderList, application, interestedParty);

                    // Update the Interested Party Address
                    setInterestedPartyAddress(holderList, application, interestedParty, madridPartialChangeOwnership);

                    if (mailingAddressLengthNotification(holderList, interestedParty)) {
                        // Notification that address > 8 lines by 40 chars
                        statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO),
                            UserTaskType.ADDRESS_EXCEEDED_LIMIT);
                    }

                    // Save the new address
                    for (InterestedPartiesAddresses eachAddress : interestedParty.getContact()
                        .getInterestedPartiesAddresses()) {

                        interestedPartiesAddressesDao.saveInterestedPartiesAddresses(eachAddress);
                    }
                    application.getInterestedParties().add(interestedParty);
                    if (arNum != 0) {
                        interestedParty.setAgentNumber(arNum);
                    }
                    interestedPartyDao.saveInterestedParty(interestedParty);

                    // Update IR Number with the ir number of designation termination
                    application.setIrNumber(
                        madridPartialChangeOwnership.getMadridDesignation().getInternationalRegistrationNumber());
                    applicationDao.saveApplication(application);

                    actionDao.saveAction(
                        createAction(application, ActionCode.PARTIAL_OWNERSHIP, SectionAuthority.AAR.name()));
                } else {
                    logger.error("Could not find Interested Parties");
                    throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
                }

                Footnote footnote = new Footnote();
                footnote.setApplication(application);
                footnote.setFileNumber(application.getFileNumber());
                footnote.setExtensionCounter(application.getExtensionCounter());
                footnote.setSequenceNumber(getNextFootnoteSequence(application.getFootnotes()));
                footnote.setType(FootnoteType.PARTIAL_ASSIGNEMENT.getValue());
                footnote.setDateRegistered(new Date());
                footnote.setText("IR Onwership Change Partial"); // TODO confirm

                footnotesDao.saveFootNote(footnote);

                application.getFootnotes().add(footnote);

                // Process Action - Print Confirmation of Change – Partial Ownership
                processActionsDao.saveProcessActions(createProcessAction(application,
                    ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE, SectionAuthority.MADRID.name()));

                applicationDao.saveApplication(application);

                if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {
                    // process opposition cases
                    if (processOppositionCases(application, registeredOppositionCaseTypes)) {

                        ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                            OfficeType.DO);
                        applicationDto.setTaskStatusCode(taskStatusType.getValue());

                        statusTypeResults.put(applicationDto, UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED);
                    }

                } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                    .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                    // process opposition cases
                    if (processOppositionCases(application, unRegisteredOppositionCaseTypes)) {

                        ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                            OfficeType.DO);
                        applicationDto.setTaskStatusCode(taskStatusType.getValue());

                        // This is for creating notifications
                        statusTypeResults.put(applicationDto, UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED);
                    }
                }

            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    public Map<ApplicationDto, UserTaskType> processIRChangeOwnershipPartial(MadridPartialChangeOwnershipType madridPartialChangeOwnership,
                                                                             IntlIrTranDto intlIrTran, String intlRegNo,
                                                                             Map<ApplicationDto, UserTaskType> statusTypeResults)
        throws MTSServiceFault {

        logger.debug("Processing IR Change Ownership partial (designation / restriction) -  Intl Reg No:" + intlRegNo);

        // Get all applications matching transactions international registration number.

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_EXAMINER.name());

                if (!ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    applicationDto.setTaskStatusCode(TaskStatusType.ON_HOLD.getValue());

                }
                statusTypeResults.put(applicationDto, UserTaskType.PARTIAL_OWNERSHIP_CHANGE_DESIGNATION_RESTRICTION);
            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }

        return statusTypeResults;
    }

    private boolean processOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes) {

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        boolean caseFound = false;

        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    // Notify the requestor(s) / or opponent if pending
                    processActionsDao.saveProcessActions(
                        createProcessAction(application, ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE,
                            oppositionCase.getOppCaseNumber(), SectionAuthority.MADRID.name()));

                    caseFound = true;
                }
            }
        }
        return caseFound;

    }

    private InterestedParty createCOPInterestedParty(Application application, int ipNumber) {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(application.getFileNumber());
        interestedParty.setIpNumber(ipNumber);

        interestedParty.setExtensionCounter(application.getExtensionCounter());
        interestedParty.setRelationshipType(RelationshipType.OWNER.getValue());
        interestedParty.setApplicantInd(0);
        interestedParty.setRegistrantInd(0);

        return interestedParty;
    }

    private void processNotification(String irNumber, List<MadridApplication> madridApplications,
                                     Map<ApplicationDto, UserTaskType> notification)
        throws MTSServiceFault {

        for (MadridApplication madridApplication : madridApplications) {
            List<MadridApplicationXref> references = madridApplication.getMadridApplicationXrefs();

            if (!CollectionUtils.isEmpty(references)) {
                MadridApplicationXref reference = references.get(0);
                if (reference != null) {
                    Integer filenum = reference.getFileNumber();
                    if (filenum.intValue() > 0) {
                        Application application = applicationDao.getApplication(new ApplicationNumber(filenum, 0));

                        if (application != null) {
                            ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application,
                                OfficeType.OO);
                            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_SUPERVISOR.name());
                            notification.put(applicationDto, UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED_OO);
                        } else {
                            logger.error("Application not found for file number: " + filenum);
                            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                        }
                    }
                }
            }
        }
    }

    private int checkAndProcessCourtesyLetter(IntlIrTranDto intlIrTran,
                                              Map<ApplicationDto, UserTaskType> statusTypeResults,
                                              MadridPartialChangeOwnershipType madridPartialChangeOwnership)
        throws MTSServiceFault {

        logger.debug("checkAndProcessCourtesyLetter in IROwnershipChangePartialService");

        int arNum = 0;
        LanguageType applicationLanguage = this
            .getApplicationLanguage(madridPartialChangeOwnership.getMadridDesignation().getNotificationLanguage());

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                arNum = courtestyLetterService.checkIsCourtesyLetterRequired(madridPartialChangeOwnership, application,
                    applicationLanguage, statusTypeResults);

                logger.debug("AgentNumber: " + arNum);
            }
        }
        return arNum;
    }

    @Override
    public String getServiceName() {
        return "IROwnershipChangePartialService";
    }

}
