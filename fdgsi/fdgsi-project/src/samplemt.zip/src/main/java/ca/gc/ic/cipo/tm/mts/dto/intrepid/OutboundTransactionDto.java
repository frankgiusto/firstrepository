package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;

public class OutboundTransactionDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private boolean registeredApplication = true;

    /** The intl reg no will be populated from the Madrid_Applications for OO, or Applications for DO */
    private String intlRegNo;

    private String intlRecordId;

    private OfficeType officeType;

    private TMInfoRetrievalDto processActionApplication;

    private List<TMInfoRetrievalDto> madridApplicationActionDetails;

    /** Date used to generate unique report output filename */
    private Date dateStamp;

    /** generated attachment filename based on dateStamp, irTranId, and MF form name being generated */
    private String uniqueAtachmentName;

    // Provided by Madrid Console Irregularity manual task.
    private String responseText;

    private boolean hasMatchedActionCode;

    public boolean isRegisteredApplication() {
        return registeredApplication;
    }

    public void setRegisteredApplication(boolean registeredApplication) {
        this.registeredApplication = registeredApplication;
    }

    public String getIntlRegNo() {
        return intlRegNo;
    }

    public void setIntlRegNo(String intlRegNo) {
        this.intlRegNo = intlRegNo;
    }

    public OfficeType getOfficeType() {
        return officeType;
    }

    public void setOfficeType(OfficeType officeType) {
        this.officeType = officeType;
    }

    public TMInfoRetrievalDto getProcessActionApplication() {
        return processActionApplication;
    }

    public void setProcessActionApplication(TMInfoRetrievalDto processActionApplication) {
        this.processActionApplication = processActionApplication;
    }

    public List<TMInfoRetrievalDto> getMadridApplicationActionDetails() {
        return madridApplicationActionDetails;
    }

    public void setMadridApplicationActionDetails(List<TMInfoRetrievalDto> madridApplicationActionDetails) {
        this.madridApplicationActionDetails = madridApplicationActionDetails;
    }

    public String getResponseText() {
        return responseText;
    }

    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }

    public Date getDateStamp() {
        return dateStamp;
    }

    public void setDateStamp(Date dateStamp) {
        this.dateStamp = dateStamp;
    }

    public String getUniqueAtachmentName() {
        return uniqueAtachmentName;
    }

    public void setUniqueAtachmentName(String uniqueAtachmentName) {
        this.uniqueAtachmentName = uniqueAtachmentName;
    }

    public String getIntlRecordId() {
        return intlRecordId;
    }

    public void setIntlRecordId(String intlRecordId) {
        this.intlRecordId = intlRecordId;
    }

    public boolean isHasMatchedActionCode() {
        return hasMatchedActionCode;
    }

    public void setHasMatchedActionCode(boolean hasMatchedActionCode) {
        this.hasMatchedActionCode = hasMatchedActionCode;
    }

}
