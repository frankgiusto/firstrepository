package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;

public class IrregularityDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -340781527932172205L;

    private OfficeType officeType;

    private BigDecimal irTranId;

    private String wipoRefNum;

    private IntlIrTranDto referencedIrTranDto;

    public OfficeType getOfficeType() {
        return officeType;
    }

    public void setOfficeType(OfficeType officeType) {
        this.officeType = officeType;
    }

    public BigDecimal getIrTranId() {
        return irTranId;
    }

    public void setIrTranId(BigDecimal irTranId) {
        this.irTranId = irTranId;
    }

    public String getWipoRefNum() {
        return wipoRefNum;
    }

    public void setWipoRefNum(String wipoRefNum) {
        this.wipoRefNum = wipoRefNum;
    }

    public IntlIrTranDto getReferencedIrTranDto() {
        return referencedIrTranDto;
    }

    public void setReferencedIrTranDto(IntlIrTranDto referencedIrTranDto) {
        this.referencedIrTranDto = referencedIrTranDto;
    }

}
