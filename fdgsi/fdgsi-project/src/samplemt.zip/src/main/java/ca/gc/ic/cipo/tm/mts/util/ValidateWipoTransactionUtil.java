package ca.gc.ic.cipo.tm.mts.util;

import java.io.Serializable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.EntityNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrganizationNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PersonNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PhraseType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ApplicantType;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedParty;

public class ValidateWipoTransactionUtil {

    public static final int ADDRESS_LIMIT = 320;

    public static final int LINE_LIMIT = 8;

    public static final int MAX_LINE_LENGTH = 40;

    public static ValidateWipoTransactionUtil getInstance() {
        return new ValidateWipoTransactionUtil();
    }

    public int getMailingAddressTotalLines(List<ApplicantType> holderList) {

        int idx = 0;
        int contactLineCount = 0;
        ContactType firstContact = null;

        for (ApplicantType holder : holderList) {

            ContactType contact = null;
            for (Object aType : holder.getLegalEntityNameOrPartyIdentifierOrContact()) {
                if (aType instanceof ContactType) {
                    contact = (ContactType) aType;
                    if (idx == 0) {
                        firstContact = contact;
                    }
                    break;
                }
            }
            if (null == contact) {
                continue;
            }

            // Name - one of above.
            if (null == contact.getName()) {
                continue;
            }
            contactLineCount += contact.getName().getPersonNameOrOrganizationNameOrEntityName().size();

        }
        int countryProvPostalCount = 0, addressLineCount = 0;

        countryProvPostalCount = firstContact.getPostalAddressBag().getPostalAddress().size();

        // Postal Code, Country Code
        if (null != firstContact.getPostalAddressBag()) {
            List<PostalAddressType> postalAddress = firstContact.getPostalAddressBag().getPostalAddress();
            for (PostalAddressType address : postalAddress) {
                addressLineCount += address.getPostalStructuredAddress().getAddressLineText().size();

                if (StringUtils.isNotBlank(address.getPostalStructuredAddress().getCountryCode())
                    || StringUtils.isNotBlank(address.getPostalStructuredAddress().getPostalCode())) {
                    // Put country / postal on its own line.
                    addressLineCount += 1;
                }

                break; // first address
            }
        }

        int totalAddressLines = contactLineCount + countryProvPostalCount + addressLineCount;

        return totalAddressLines;
    }

    public boolean mailingAddressLengthNotification(String mailingAddress) {

        String token = "\r\n";

        if (null != mailingAddress) {
            String[] addressTokens = mailingAddress.split(token);

            if (null != addressTokens) {
                if (addressTokens.length > LINE_LIMIT) {
                    return true;
                }
                for (String line : addressTokens) {
                    if (line.trim().length() > MAX_LINE_LENGTH) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    protected int createInterestedPartyContact(ContactType contact) {

        IPContact nameContact = null;
        IPContact businessContact = null;
        IPContact entityContact = null;
        InterestedParty interestedPartyHolder = new InterestedParty();

        int ownerNameLineCount = 0;

        contact.getName().getPersonNameOrOrganizationNameOrEntityName().size();

        for (Object personNameOrOrganizationNameOrEntityName : contact.getName()
            .getPersonNameOrOrganizationNameOrEntityName()) {

            ownerNameLineCount++;

            if (personNameOrOrganizationNameOrEntityName instanceof PersonNameType) {
                nameContact = new IPContact();

                nameContact.setName(((PersonNameType) personNameOrOrganizationNameOrEntityName).getPersonFullName());
                interestedPartyHolder.setContact(nameContact);

            } else if (personNameOrOrganizationNameOrEntityName instanceof OrganizationNameType) {
                businessContact = new IPContact();

                OrganizationNameType organizationNameType = (OrganizationNameType) personNameOrOrganizationNameOrEntityName;
                PhraseType orgStandardName = organizationNameType.getOrganizationStandardName();

                StringBuilder standardNameBuffer = new StringBuilder();
                for (Serializable standardName : orgStandardName.getContent()) {
                    if (standardNameBuffer.length() > 0) {
                        standardNameBuffer.append(";");
                    }
                    standardNameBuffer.append(standardName);
                }

                businessContact.setName(standardNameBuffer.toString());

            } else if (personNameOrOrganizationNameOrEntityName instanceof EntityNameType) {
                entityContact = new IPContact();

                entityContact.setName(((EntityNameType) personNameOrOrganizationNameOrEntityName).getValue());
            }
            break; // Primary Address only required
        }
        return ownerNameLineCount;
    }

    public String splitString(String msg, int lineSize) {

        StringBuilder strBuilder = new StringBuilder();
        Pattern p = Pattern.compile("\\b.{1," + (lineSize - 1) + "}\\b\\W?");
        Matcher m = p.matcher(msg);

        while (m.find()) {
            strBuilder.append(m.group());
            strBuilder.append("\n");
        }
        return strBuilder.toString();
    }

}
