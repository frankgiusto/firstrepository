package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;

public class ProcessActionMapBean {

    private ProcessActionCodeType processActionCodeType;

    private OfficeType officeType;

    public ProcessActionMapBean(ProcessActionCodeType processActionCodeType, OfficeType officeType) {
        this.processActionCodeType = processActionCodeType;
        this.officeType = officeType;
    }

    public ProcessActionCodeType getProcessActionCodeType() {
        return processActionCodeType;
    }

    public void setProcessActionCodeType(ProcessActionCodeType processActionCodeType) {
        this.processActionCodeType = processActionCodeType;
    }

    public OfficeType getOfficeType() {
        return officeType;
    }

    public void setOfficeType(OfficeType officeType) {
        this.officeType = officeType;
    }
}
