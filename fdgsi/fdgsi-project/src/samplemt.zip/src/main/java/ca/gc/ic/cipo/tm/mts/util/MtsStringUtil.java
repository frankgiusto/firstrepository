package ca.gc.ic.cipo.tm.mts.util;

/**
 * This class is created to hold string constant. All string should be created from here instead of
 * "newing/concatenated" in other local scope.
 *
 * @author wangf
 *
 */
public class MtsStringUtil {

    public static final String EMPTY = "";

    public static final String SPACE = " ";

    public static final String LINE_CHANGE = "\n";

    public static final String DOUBLE_LINE_CHANGE = "\n\n";

    public static final String LEFT_BRACKET = "(";

    public static final String RIGHT_BRACKET = ")";

    public static final String COMMA_SPACE = ", ";

    public static final String UNDER_SCORE = "_";

    public static final String DOT = ".";

    public static final String COMMA = ",";

    public static final String SLASH = "/";

    public static final String DASH = "-";

    public static final String COLON = ":";

    public static final String SEMI_COMMA = ";";

    public static final char ZERO = '0';

    /**
     * Clean the string buff.
     *
     * @param sb
     */
    public static void flushStringBuff(StringBuffer sb) {
        sb.delete(0, sb.length());
    }

    public static Integer formatNiceClassificationVersion(String valueFromXml) {
        String rtnValue = valueFromXml;

        String[] splitValueFromXml = valueFromXml.split(DASH);

        for (int i = 0; i < splitValueFromXml[0].length(); i++) {
            if (splitValueFromXml[0].charAt(i) != '0') {
                rtnValue = splitValueFromXml[0].substring(i, splitValueFromXml[0].length());
                break;
            }
        }

        return Integer.valueOf(rtnValue);
    }

    public static String[] splitDocName(String inValue) {
        return inValue.split(SEMI_COMMA);
    }

}
