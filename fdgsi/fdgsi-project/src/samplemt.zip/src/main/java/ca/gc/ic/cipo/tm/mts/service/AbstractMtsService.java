package ca.gc.ic.cipo.tm.mts.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Locale;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import ca.gc.ic.cipo.common.service.AbstractCipoService;
import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReturnCode;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public abstract class AbstractMtsService extends AbstractCipoService {

    private static Logger logger = Logger.getLogger(MadridTransactionService.class.getName());

    protected static final String XML_EXTENTION = ".xml";

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private MessageSource messageSource;

    /**
     *
     */
    public AbstractMtsService() {

    }

    @Override
    protected ServiceFaultDetails handleExceptions(Throwable t) {
        ServiceFaultDetails faultDetails = initializeServiceFaultDetails();

        if (t instanceof MTSServiceFault) {
            MTSServiceFault mts = (MTSServiceFault) t;

            // For now these will be logged as errors and not warnings...
            logger.error("MTS Service error: " + mts.getMessage() + " Sending return-reason ["
                + mts.getFaultInfo().getReturnCode() + "." + mts.getFaultInfo().getReasonCode() + "]", mts);

            setFaultInfo(mts, faultDetails);

        } else if (t.getCause() != null && t.getCause() instanceof MTSServiceFault) {

            MTSServiceFault mts = (MTSServiceFault) t.getCause();
            logger.error("MTS Service error: " + mts.getMessage() + " Sending return-reason ["
                + mts.getFaultInfo().getReturnCode() + "." + mts.getFaultInfo().getReasonCode() + "]", mts);

            setFaultInfo(mts, faultDetails);

        } else if (t instanceof CIPOServiceFault) {

            logger.error(t.getMessage(), t);
            faultDetails.setEnErrorMsg(messageSource.getMessage("mts.system.error", null, Locale.CANADA));
            faultDetails.setFrErrorMsg(messageSource.getMessage("mts.system.error", null, Locale.CANADA_FRENCH));
            faultDetails.setStackTrace(stackTraceToString(t));

        } else {

            // Handle all other exceptions an unexpected general errors
            logger.error(t.getMessage(), t);
            faultDetails.setReturnCode(-99);
            faultDetails.setReasonCode(1);
            faultDetails.setEnErrorMsg(messageSource.getMessage("-99.1", null, Locale.CANADA));
            faultDetails.setFrErrorMsg(messageSource.getMessage("-99.1", null, Locale.CANADA_FRENCH));
            faultDetails.setStackTrace(stackTraceToString(t));

        }
        return faultDetails;
    }

    private void setFaultInfo(MTSServiceFault mts, ServiceFaultDetails faultDetails) {

        // Set the values in the response accordingly
        faultDetails.setReturnCode(mts.getFaultInfo().getReturnCode());
        faultDetails.setReasonCode(mts.getFaultInfo().getReasonCode());
        faultDetails.setEnErrorMsg(mts.getFaultInfo().getEnErrorMsg());
        faultDetails.setFrErrorMsg(mts.getFaultInfo().getFrErrorMsg());
        faultDetails.setStackTrace(stackTraceToString(mts));

    }

    protected void throwMTSServiceFault(String errorKey, ExceptionReasonCode exceptionReasonCode)
        throws MTSServiceFault {

        ExceptionReturnCode exceptionReturnCode = null;
        if (ExceptionReasonCode.SYSTEM_ERROR == exceptionReasonCode) {
            exceptionReturnCode = ExceptionReturnCode.FATAL;
        } else {
            exceptionReturnCode = ExceptionReturnCode.RECOVERABLE;
        }
        throw new MTSServiceFault("System Error",
            setServiceDetails(errorKey, exceptionReasonCode, exceptionReturnCode));
    }

    protected ServiceFaultDetails setServiceDetails(String errorKey, ExceptionReasonCode exceptionReasonCode,
                                                    ExceptionReturnCode returnCode) {

        ServiceFaultDetails serviceFaultDetails = initializeServiceFaultDetails();
        serviceFaultDetails.setEnErrorMsg(messageSource.getMessage(errorKey, null, Locale.CANADA));
        serviceFaultDetails.setFrErrorMsg(messageSource.getMessage(errorKey, null, Locale.CANADA_FRENCH));
        serviceFaultDetails.setReasonCode(exceptionReasonCode.getReasonCode());
        serviceFaultDetails.setReturnCode(returnCode.getReturnCode());

        logger.error(serviceFaultDetails.getEnErrorMsg());

        return serviceFaultDetails;
    }

    protected CIPOServiceFault throwCIPOFault(MTSServiceFault exception) throws CIPOServiceFault {
        CIPOServiceFault cipoServiceFault = new CIPOServiceFault(exception.getMessage(), exception.getFaultInfo(),
            exception);
        throw cipoServiceFault;
    }

    protected CIPOServiceFault throwCIPOFault(Exception exception) throws CIPOServiceFault {
        CIPOServiceFault cipoServiceFault = new CIPOServiceFault(exception.getMessage(), null, exception);
        throw cipoServiceFault;
    }

    protected CIPOServiceFault throwCIPOFault(Exception exception, ServiceFaultDetails serviceFaultDetails)
        throws CIPOServiceFault {
        CIPOServiceFault cipoServiceFault = new CIPOServiceFault(exception.getMessage(), serviceFaultDetails,
            exception);
        throw cipoServiceFault;
    }

    protected ServiceFaultDetails initializeServiceFaultDetails() {
        ServiceFaultDetails faultDetails = new ServiceFaultDetails();
        faultDetails.setComponentAcronym(getComponentAcronym());
        faultDetails.setServiceName(getServiceName());

        return faultDetails;
    }

    /**
     * Convenience method to convert the stack trace of a given Throwable object into a string. Unfortunately due to the
     * 'private' declaration on the parent class this code is duplicated here.
     *
     * @param e The Throwable object.
     * @return The String stack trace.
     */
    protected String stackTraceToString(Throwable e) {
        String retValue = null;
        StringWriter sw = null;
        PrintWriter pw = null;
        try {
            sw = new StringWriter();
            pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            retValue = sw.toString();
        } finally {
            try {
                if (pw != null) {
                    pw.close();
                }
                if (sw != null) {
                    sw.close();
                }
            } catch (IOException ignore) {
            }
        }
        return retValue;
    }

    public <T> T unmarshallTransaction(IntlIrTranDto intlIrTran) throws JAXBException, SQLException {
        return marshallingService.unmarshallTransaction(intlIrTran.getIrTranId());
    }

    public <T> T unmarshallTransaction(BigDecimal irTranId) throws JAXBException, SQLException {
        return marshallingService.unmarshallTransaction(irTranId);
    }

    @Override
    public String getComponentAcronym() {
        return "tm";
    }

    @Override
    public String getServiceAcronym() {
        return "mts";
    }

    @Override
    public String getServiceName() {
        return "MadridTransactionService";
    }
}
