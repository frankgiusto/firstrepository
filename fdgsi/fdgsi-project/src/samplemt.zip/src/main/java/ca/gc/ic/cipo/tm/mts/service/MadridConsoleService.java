package ca.gc.ic.cipo.tm.mts.service;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridCorrectionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.MailType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.mops.MOPSClient;
import ca.gc.ic.cipo.tm.mops.MOPSServiceFactory;
import ca.gc.ic.cipo.tm.mops.MOPSServiceResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CeasingOfEffectMF9Type;
import ca.gc.ic.cipo.tm.mts.GetManualReportRequest;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType;
import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;
import ca.gc.ic.cipo.tm.mts.GroundsOfOppositionList;
import ca.gc.ic.cipo.tm.mts.LimitationNoEffectMF13Type;
import ca.gc.ic.cipo.tm.mts.MailTransactionType;
import ca.gc.ic.cipo.tm.mts.OrderedTextType;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessIrregularitySubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest.ManualReportForm;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportResponse;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProvisionalRefusalDetail;
import ca.gc.ic.cipo.tm.mts.ProvisionalRefusalMF3AType;
import ca.gc.ic.cipo.tm.mts.ReviewOrFileAppeal;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.GoodsServiceAction;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionsMap;
import ca.gc.ic.cipo.tm.mts.enums.ReportTypeEnum;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridNewBasicApplication;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IRProcessGoodServices;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.tirs.common.TMInfoRetrievalCommonServicePortType;
import ca.gc.ic.cipo.tm.tirs.common.TrademarkInfoRetrievalCommonServiceFactory;
import ca.gc.ic.cipo.tm.tirs.tmob.TMInfoRetrievalTMOBServicePortType;
import ca.gc.ic.cipo.tm.tirs.tmob.TrademarkInfoRetrievalTMOBServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.client.UserProfileServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileService;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.common.RoleCategoryType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.CitedLinksType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.CitedLinksTypeBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionCaseMarkEventType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionCitedMarksType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionCitedMarksTypeBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionGroundsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.OppositionGroundsTypeBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsTypeMF3;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsTypeMF3BagType;

@Service
public class MadridConsoleService extends MadridTransactionService implements IMadridConsoleService {

    private static Logger logger = Logger.getLogger(MadridConsoleService.class.getName());

    @Value("#{environment['mts.tm.information.retrieval.services.host.name']}")
    private String tmirServiceHost;

    @Value("#{environment['mts.tm.user.profile.services.host.name']}")
    private String tupsServiceHost;

    @Value("#{environment['mts.mops.wipo.service.host.name']}")
    private String mopsServiceHost;

    @Value("#{environment['mts.irreg.comment.text.size']}")
    private Integer COMMENT_TEXT_SIZE;

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IRProcessGoodServices intrepidProcessGoodServices;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IOutboundTransactionService outboundTransactionService;

    @Autowired
    private ICourtesyLetterService courtestyLetterService;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private ITaskService taskService;

    private final static int MADRID_LIMITATION_NO_EFFECT = 1;

    private void createLimitationNoEffect(GoodsAndServiceMeta gsMeta, ProcessManualReportRequest manualReportRequest)
        throws CIPOServiceFault {

        IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(gsMeta.getTaskId());

        OutboundTransactionDto outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(
            new BigDecimal(intlIrTaskDto.getFileNumber()), intlIrTaskDto.getExtensionCounter());

        outboundTransactionService.createOutboundTransaction(this.initLimitationNoEffectRequest(gsMeta),
            outboundTransactionDto, manualReportRequest);

    }

    private OutboundTransactionRequest initLimitationNoEffectRequest(GoodsAndServiceMeta gsMeta)
        throws CIPOServiceFault {

        IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(gsMeta.getTaskId());

        // Update Outbound Transaction
        OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
        outboundTransactionRequest.setFileNumber(BigDecimal.valueOf(intlIrTaskDto.getFileNumber()));
        outboundTransactionRequest.setExtensionCounter(Integer.toString(DEFAULT_EXTENSION_COUNTER));
        outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_LIMITATION_NO_EFFECT);

        Date intRegDate = intrepidCommonService.getInternationRegistrationDate(gsMeta.getFileNumber().intValue(),
            Integer.valueOf(gsMeta.getExtensioncounter()));

        if (null == intRegDate) {
            logger.error("Missing International Registration Date");
            throwMTSServiceFault("mts.missing.registration.date", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        outboundTransactionRequest.setInternationalRegistrationDate(intRegDate);

        return outboundTransactionRequest;
    }

    @Override
    public GoodsAndServicesChangesResponse processGoodsAndServicesChanges(GoodsAndServiceMeta gsInfo,
                                                                          ActionCode actionCode)
        throws CIPOServiceFault {
        GoodsAndServicesChangesResponse response = new GoodsAndServicesChangesResponse();

        if ((gsInfo.getTaskType().value().equals(GoodServiceTaskType.GOOD_SERVICE_LIMITATION.value()))
            || (gsInfo.getTaskType().value().equals(GoodServiceTaskType.DESIGNATION_LIMITATION.value()))) {

            logger.debug("gsInfo.getTaskType: " + gsInfo.getTaskType().value());
            GoodsServiceAction goodsServiceAction = null;

            try {
                if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.GOOD_SERVICE_LIMITATION.value())) {
                    MadridProtectionRestrictionType xmlTransaction = getTaskTransaction(gsInfo);
                    updateGoodsAndServiceFromWIPO(gsInfo, xmlTransaction);

                    goodsServiceAction = intrepidProcessGoodServices.processDOGoodServiceLimitation(gsInfo,
                        xmlTransaction.getRecordEffectiveDate(), actionCode);

                } else if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.DESIGNATION_LIMITATION.value())) {

                    goodsServiceAction = intrepidProcessGoodServices.processDOGoodServiceLimitation(gsInfo, null,
                        actionCode);
                }
            } catch (Exception e) {

                logger.error("Error processing processDOGoodServiceLimitation from console.", e);

                throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
            }

            if (goodsServiceAction == GoodsServiceAction.TOTAL_CANCELLATION) {

                try {
                    totalCancellation(gsInfo);
                } catch (Exception e) {

                    logger.error("Error processing totalCancellation ", e);

                    throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
                }
            } else if (goodsServiceAction == GoodsServiceAction.MADRID_LIMITATION_NO_EFFECT) {

                response.setGsStatus(MADRID_LIMITATION_NO_EFFECT);

            }

            if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.GOOD_SERVICE_LIMITATION.value())) {
                // update mail status
                MailType mailType = MailType.valueOf(MailTransactionType.MADRID_LIMITATION.name());
                updateMailProcessedStatusForApplication(mailType, gsInfo);
            }

            // change task status to processed
            TaskStatusType statusType = TaskStatusType.PROCESSED;
            internationalService.updateTaskStatus(gsInfo.getTaskId(), statusType);
            response.setStatus(HttpStatus.OK.value());

        } else if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.PARTIAL_CANCELLATION.value())) {

            MadridProtectionRestrictionType xmlTransaction = getTaskTransaction(gsInfo);
            updateGoodsAndServiceFromWIPO(gsInfo, xmlTransaction);

            try {
                GoodsServiceAction goodsServiceAction = intrepidProcessGoodServices.processDOPartialCancelation(gsInfo,
                    xmlTransaction.getRecordEffectiveDate());

                if (goodsServiceAction == GoodsServiceAction.TOTAL_CANCELLATION) {

                    totalCancellation(gsInfo);
                }
            } catch (Exception e) {

                logger.error("Error processing processDOPartialCancelation from console.", e);

                throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
            }

            // update mail status
            MailType mailType = MailType.valueOf(MailTransactionType.MADRID_CANCELLATION_PARTIAL.name());
            updateMailProcessedStatusForApplication(mailType, gsInfo);

            // change task status to processed
            TaskStatusType statusType = TaskStatusType.PROCESSED;
            internationalService.updateTaskStatus(gsInfo.getTaskId(), statusType);
            response.setStatus(HttpStatus.OK.value());

        } else if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.PARTIAL_CEASING_EFFECT.value())) {

            MadridProtectionRestrictionType xmlTransaction = getTaskTransaction(gsInfo);
            updateGoodsAndServiceFromWIPO(gsInfo, xmlTransaction);
            GoodsServiceAction goodsServiceAction = null;

            try {
                goodsServiceAction = intrepidProcessGoodServices.processDOPartialCeasingEffect(gsInfo,
                    xmlTransaction.getRecordEffectiveDate());

                if (goodsServiceAction == GoodsServiceAction.TOTAL_CEASING_EFFECT) {
                    ByteArrayOutputStream transactionOS = this.createTotalCeasingEffectTransaction(gsInfo);

                    IntlIrTranDto intlIrTranDto = internationalService.storeTransaction(transactionOS, null,
                        StatusType.MPS_IMPORT_COMPLETE, TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT,
                        gsInfo.getTaskId().toString(), gsInfo.getInternationalRegistrationNumber(), null);

                    if (null != intlIrTranDto) {
                        response.setIrTranId(intlIrTranDto.getIrTranId());
                    }
                }
            } catch (Exception e) {

                logger.error("Error processing processDOPartialCeasingEffect from console.", e);

                throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
            }

            // update mail status
            MailType mailType = MailType.valueOf(MailTransactionType.MADRID_CEASING_OF_EFFECT_PARTIAL_DO.name());
            updateMailProcessedStatusForApplication(mailType, gsInfo);

            // change task status to processed
            internationalService.updateTaskStatus(gsInfo.getTaskId(), TaskStatusType.PROCESSED);
            response.setStatus(HttpStatus.OK.value());

        } else if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.NANR_PARTIAL_CEASING_EFFECT.value())) {
            if (gsInfo.getUserSelectType().equals(GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT)) {
                // change task status to processed
                internationalService.updateTaskStatus(gsInfo.getTaskId(), TaskStatusType.CLOSED_UNPROCESSED);
                response.setStatus(HttpStatus.OK.value());
            } else if (gsInfo.getUserSelectType().equals(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT)) {
                List<IntlIrTranDto> transactionList = internationalService.getTransactionByTaskId(gsInfo.getTaskId());
                IntlIrTranDto irTranDto = transactionList.get(0);

                try {
                    // Create new Madrid Action and check nulls.
                    if (CollectionUtils.isNotEmpty(gsInfo.getMergedGoodServices().getTaskListBag())
                        && gsInfo.getMergedGoodServices().getTaskListBag().size() > 0) {// partial
                        // Update Intrepid with new list of marks
                        intrepidProcessGoodServices.updateMadridApplicationXREF(
                            gsInfo.getInternationalRegistrationNumber(), gsInfo.getBasicMarkList());

                        intrepidProcessGoodServices.addNewMadridApplicationAction(
                            gsInfo.getInternationalRegistrationNumber(), gsInfo.getAuthorityId(),
                            irTranDto.getIrTranId(), MadridApplicationActionStatus.PARTIAL_CEASING_EFFECT_SENT);
                    } else {// total
                        intrepidProcessGoodServices.addNewMadridApplicationAction(
                            gsInfo.getInternationalRegistrationNumber(), gsInfo.getAuthorityId(),
                            irTranDto.getIrTranId(), MadridApplicationActionStatus.TOTAL_CEASING_EFFECT_SENT, true);
                    }
                } catch (Exception e) {

                    logger.error("Error processing NANR_PARTIAL_CEASING_EFFECT from console.", e);

                    throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
                }
                // Update Task Status
                internationalService.updateTaskStatus(gsInfo.getTaskId(), TaskStatusType.PROCESSED);
                response.setStatus(HttpStatus.OK.value());
            }

        } else if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.TOTAL_CEASING_EFFECT.value())) {
            List<IntlIrTranDto> transactionList = internationalService.getTransactionByTaskId(gsInfo.getTaskId());
            IntlIrTranDto irTranDto = transactionList.get(0);

            try {
                intrepidProcessGoodServices.addNewMadridApplicationAction(gsInfo.getInternationalRegistrationNumber(),
                    gsInfo.getAuthorityId(), irTranDto.getIrTranId(),
                    MadridApplicationActionStatus.TOTAL_CEASING_EFFECT_SENT, true);
            } catch (Exception e) {

                logger.error("Error processing addNewMadridApplicationAction.", e);

                throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
            }
            // Update Task Status
            internationalService.updateTaskStatus(gsInfo.getTaskId(), TaskStatusType.PROCESSED);
            response.setStatus(HttpStatus.OK.value());

        } else if (gsInfo.getTaskType().value().equals(GoodServiceTaskType.MADRID_NEW_BASIC_APPLICATION.value())) {

            if (gsInfo.getBasicMarkList().size() > 0) {
                try {
                    // Update Intrepid with new list of marks
                    intrepidProcessGoodServices.updateMadridApplicationXREF(gsInfo.getInternationalRegistrationNumber(),
                        gsInfo.getBasicMarkList());
                } catch (Exception e) {

                    logger.error("Error processing updateMadridApplicationXREF.", e);

                    throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
                }
                // Get Transaction for the task
                List<IntlIrTranDto> transactionList = internationalService.getTransactionByTaskId(gsInfo.getTaskId());
                IntlIrTranDto irTranDto = transactionList.get(0);

                MadridOutboundTransactionType outboundTransactioType = MadridOutboundTransactionType
                    .getTransactionTypeByValue(irTranDto.getIntlPkgTranType().getPkgTranCtgryId());

                OutboundTransactionDto outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(
                    gsInfo.getInternationalRegistrationNumber(), gsInfo.getFileNumber(), gsInfo.getExtensioncounter(),
                    gsInfo.getBasicMarkList());

                MadridNewBasicApplication basicApplication = new MadridNewBasicApplication(outboundTransactioType);

                ByteArrayOutputStream xmlOutputStream = null;
                try {
                    xmlOutputStream = basicApplication.createOutboundTransaction(outboundTransactionDto, null,
                        irTranDto, marshallingService);

                    // Update Transaction with updated Transaction XML and update Transaction status
                    outboundTransactionService.updateTransactionXMLWithStatus(xmlOutputStream, irTranDto,
                        StatusType.MPS_READY_FOR_EXPORT);

                    // Create new Madrid Action
                    intrepidProcessGoodServices.addNewMadridApplicationAction(
                        gsInfo.getInternationalRegistrationNumber(), gsInfo.getAuthorityId(), irTranDto.getIrTranId(),
                        MadridApplicationActionStatus.NEW_BASIC_APPLICATION_LIST_SENT);

                } catch (Exception e) {
                    logger.error("Error processing MADRID_NEW_BASIC_APPLICATION.", e);
                    throwMTSServiceFault("mts.general.error", ExceptionReasonCode.RETRYABLE_ERROR);
                }

                // Update Task Status
                internationalService.updateTaskStatus(gsInfo.getTaskId(), TaskStatusType.PROCESSED);
                response.setStatus(HttpStatus.OK.value());
            }

        }

        return response;
    }

    private void updateMailProcessedStatusForApplication(MailType mailType, GoodsAndServiceMeta gsInfo)
        throws CIPOServiceFault {
        try {
            intrepidCommonService.updateMailProcessedStatus(gsInfo.getFileNumber(), mailType, gsInfo.getAuthorityId());

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    private void updateGoodsAndServiceFromWIPO(GoodsAndServiceMeta gsInfo,
                                               MadridProtectionRestrictionType xmlTransaction) {
        if (gsInfo.getUserSelectType().equals(GoodServiceSelectionType.ACCEPT_ALL)
            && xmlTransaction.getGoodsServicesLimitationBag() != null
            && xmlTransaction.getGoodsServicesLimitationBag().getGoodsServicesLimitation() != null
            && xmlTransaction.getGoodsServicesLimitationBag().getGoodsServicesLimitation().get(0) != null
            && xmlTransaction.getGoodsServicesLimitationBag().getGoodsServicesLimitation().get(0)
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag() != null
            && xmlTransaction.getGoodsServicesLimitationBag().getGoodsServicesLimitation().get(0)
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag().get(1) != null
            && (xmlTransaction.getGoodsServicesLimitationBag().getGoodsServicesLimitation().get(0)
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag()
                .get(1) instanceof ClassDescriptionBagType)) {

            logger.debug(
                "Accept all Goods and Services from the WIPO transaction. Will reset merged goods services list from WIPO transaction xml.");
            ClassDescriptionBagType classDescriptionBagType = (ClassDescriptionBagType) xmlTransaction
                .getGoodsServicesLimitationBag().getGoodsServicesLimitation().get(0)
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag().get(1);

            if (classDescriptionBagType.getClassDescription() != null && gsInfo.getMergedGoodServices() != null
                && gsInfo.getMergedGoodServices().getTaskListBag() != null) {
                for (ClassDescriptionType classficationFromWIPO : classDescriptionBagType.getClassDescription()) {
                    for (GoodsServicesClassificationType mergedGsClassification : gsInfo.getMergedGoodServices()
                        .getTaskListBag()) {
                        if (classficationFromWIPO.getClassNumber().equals(mergedGsClassification.getClassNumber())) {
                            // Reset the list with WIPO classification information in muti languages.
                            mergedGsClassification.getClassTitleText().clear();
                            for (_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType orderedTextType : classficationFromWIPO
                                .getGoodsServicesDescriptionText()) {
                                OrderedTextType text = new OrderedTextType();
                                text.setLanguageCode(orderedTextType.getLanguageCode());
                                text.setSequenceNumber(orderedTextType.getSequenceNumber());
                                text.setValue(orderedTextType.getValue());
                                mergedGsClassification.getClassTitleText().add(text);
                            }

                        }

                    }

                }
            }

        }

    }

    @Override
    public GoodsAndServicesChangesResponse processPartialOwnershipRequest(BigDecimal irTaskId,
                                                                          String notificationLanguage,
                                                                          PartialOwnershipMeta designation,
                                                                          PartialOwnershipMeta restriction)
        throws CIPOServiceFault {

        GoodsAndServicesChangesResponse goodsAndServicesChangesResponse = new GoodsAndServicesChangesResponse();

        List<IntlIrTranDto> intlIrTransaction = internationalService.getTransactionByTaskId(irTaskId);
        Integer newApplicationFileNumber = null;

        try {
            newApplicationFileNumber = intrepidProcessGoodServices.processPartialOwnership(intlIrTransaction.get(0),
                notificationLanguage, designation, restriction);

        } catch (Exception e) {

            logger.error("Error processing processPartialOwnership from console.", e);

            throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
        }

        updateMailRecordForPartialOwnershipChange(restriction.getFileNumber(), restriction.getAuthorityId(),
            new BigDecimal(newApplicationFileNumber), designation.getAuthorityId());

        internationalService.updatePartialOwnershipTask(irTaskId, newApplicationFileNumber);

        return goodsAndServicesChangesResponse;
    }

    private void updateMailRecordForPartialOwnershipChange(BigDecimal restrictionFileNumber,
                                                           String restrictionAuthorityId,
                                                           BigDecimal designationFileNumber,
                                                           String designationAuthorityId) {

        MailType mailType = MailType.valueOf(MailTransactionType.MADRID_CHANGE_OF_OWNERSHIP_PARTIAL.name());

        intrepidCommonService.updateMailProcessedStatus(restrictionFileNumber, mailType, restrictionAuthorityId);

        intrepidCommonService.updateMailProcessedStatus(designationFileNumber, mailType, designationAuthorityId);
    }

    @Override
    public ProcessManualReportRequest getManualReport(GetManualReportRequest request) throws MTSServiceFault {
        return getProcessManualReportRequestForTask(request.getTaskId(), request.getTransactionId(),
            request.getGoodsAndServices());
    }

    private MadridProtectionRestrictionType getTaskTransaction(GoodsAndServiceMeta gsInfo) throws MTSServiceFault {
        List<IntlIrTranDto> transactionList = internationalService.getTransactionByTaskId(gsInfo.getTaskId());

        if (CollectionUtils.isEmpty(transactionList)) {
            throw new IllegalArgumentException(
                "Expecting one transaction for Partial Cancellation taskId: " + gsInfo.getTaskId());
        }

        MadridProtectionRestrictionType xmlTransaction = null;
        try {
            xmlTransaction = unmarshallTransaction(transactionList.get(0));

        } catch (Exception exception) {
            throwMTSServiceFault("mts.error.unmarshalling.transaction", ExceptionReasonCode.SYSTEM_ERROR);
        }

        return xmlTransaction;
    }

    @Override
    public ProcessManualReportResponse processManualReport(ProcessManualReportRequest manualReportRequest)
        throws CIPOServiceFault {
        ProcessManualReportResponse response = new ProcessManualReportResponse();

        GoodsAndServiceMeta gsMeta = null;

        if (manualReportRequest.getReportTypeCode().equals(ReportTypeEnum.MF_3_A.value())) {
            // Get the Application information from intrepid using TIRS
            IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(manualReportRequest.getTaskId());
            OutboundTransactionDto outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(
                new BigDecimal(intlIrTaskDto.getFileNumber()), intlIrTaskDto.getExtensionCounter());

            // Update Outbound Transaction
            OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
            outboundTransactionRequest.setFileNumber(new BigDecimal(intlIrTaskDto.getFileNumber()));
            outboundTransactionRequest.setExtensionCounter(intlIrTaskDto.getExtensionCounter());

            // add the general attachments to database
            outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_PROVISIONAL_REFUSAL_MF_3);

            outboundTransactionRequest.setRefusalPronouncedDate(manualReportRequest.getManualReportForm()
                .getProvisionalRefusalMF3AType().getReviewOrFileAppeal().getTimeLimitDate());

            outboundTransactionRequest.setGroundsOfOppositionDescription(manualReportRequest.getManualReportForm()
                .getProvisionalRefusalMF3AType().getGroundsOfOppositionDescription());

            // An intermediate outbound transaction exists, so update it with the information on the form.
            outboundTransactionService.updateManualOutboundTransaction(outboundTransactionRequest,
                outboundTransactionDto, manualReportRequest);

        } else if (manualReportRequest.getReportTypeCode().equals(ReportTypeEnum.MF_9.value())) {
            gsMeta = manualReportRequest.getManualReportForm().getCeasingOfEffectMF9Type().getGoodsAndServices();

            if (gsMeta.getBasicMarkList() == null || gsMeta.getBasicMarkList().size() == 0) {
                List<MadridApplicationXref> madridApplicationXREFList = intrepidProcessGoodServices
                    .getMadridApplicationXREFList(gsMeta.getInternationalRegistrationNumber());
                if (madridApplicationXREFList != null) {
                    for (MadridApplicationXref xref : madridApplicationXREFList) {
                        ca.gc.ic.cipo.tm.mts.ApplicationNumber appNumber = new ca.gc.ic.cipo.tm.mts.ApplicationNumber();
                        appNumber.setFileNumber(new BigDecimal(xref.getFileNumber()));
                        appNumber.setExtensionCounter(new Integer(xref.getExtensionCounter()).toString());
                        gsMeta.getBasicMarkList().add(appNumber);
                    }
                }
            }

            // Get the Application information from intrepid using TIRS
            IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(manualReportRequest.getTaskId());

            OutboundTransactionDto outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(
                gsMeta.getInternationalRegistrationNumber(), gsMeta.getFileNumber(), gsMeta.getExtensioncounter(),
                gsMeta.getBasicMarkList());

            // Update Outbound Transaction
            OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
            outboundTransactionRequest.setFileNumber(new BigDecimal(intlIrTaskDto.getFileNumber()));
            outboundTransactionRequest.setExtensionCounter(intlIrTaskDto.getExtensionCounter());

            if (gsMeta.getMergedGoodServices() != null
                && CollectionUtils.isNotEmpty(gsMeta.getMergedGoodServices().getTaskListBag())) {
                outboundTransactionRequest
                    .setProcessActionCodeType(ProcessActionCodeType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL);
            } else {
                outboundTransactionRequest
                    .setProcessActionCodeType(ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9);
            }
            try {
                logger.debug("ProcessActionCodeType: " + outboundTransactionRequest.getProcessActionCodeType());

                outboundTransactionService.updateManualOutboundTransaction(outboundTransactionRequest,
                    outboundTransactionDto, manualReportRequest);

                processGoodsAndServicesChanges(gsMeta, null);

            } catch (Exception e) {
                // update international transaction to processed in error
                try {
                    logger.error("Error processing MF9 from console.", e);

                    internationalService.updateTransactionStatus(manualReportRequest.getTransactionId(),
                        StatusType.PROCESSED_WITH_ERROR);

                } catch (Exception e2) {
                    logger.error(
                        "Failure in processGoodsAndServicesChanges. Tried to update transaction to Error. Transaction id: "
                            + manualReportRequest.getTransactionId());
                }
                throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
            }

        } else if (manualReportRequest.getReportTypeCode().equals(ReportTypeEnum.MF_13.value())) {
            // Get the Application information from intrepid using TIRS
            IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(manualReportRequest.getTaskId());
            OutboundTransactionDto outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(
                new BigDecimal(intlIrTaskDto.getFileNumber()), intlIrTaskDto.getExtensionCounter());

            // Update Outbound Transaction
            OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
            outboundTransactionRequest.setFileNumber(new BigDecimal(intlIrTaskDto.getFileNumber()));
            outboundTransactionRequest.setExtensionCounter(intlIrTaskDto.getExtensionCounter());

            gsMeta = manualReportRequest.getManualReportForm().getLimitationNoEffectMF13Type().getGoodsAndServices();

            outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_LIMITATION_NO_EFFECT);

            GoodsAndServicesChangesResponse goodsAndServicesChangesResponse = processGoodsAndServicesChanges(gsMeta,
                ActionCode.MF13_SENT);

            if (goodsAndServicesChangesResponse.getGsStatus() == MADRID_LIMITATION_NO_EFFECT) {

                try {
                    this.createLimitationNoEffect(gsMeta, manualReportRequest);

                } catch (Exception e) {

                    logger.error("Error createLimitationNoEffect", e);
                    throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
                }
            }

        }

        // change task status to processed
        TaskStatusType statusType = TaskStatusType.PROCESSED;
        internationalService.updateTaskStatus(manualReportRequest.getTaskId(), statusType);
        return response;
    }

    @Override
    public void processIrregularitySubmission(ProcessIrregularitySubmissionRequest irregularitySubmissionRequest)
        throws CIPOServiceFault {

        IntlIrTaskDto intlIrTaskDto = taskService.getIrTaskById(irregularitySubmissionRequest.getTaskId());
        OfficeType irTaskOfficeType = OfficeType.getOfficeTypeByName(intlIrTaskDto.getOfficeType());

        List<IntlIrTranDto> tranDtos = internationalService
            .getTransactionByTaskId(irregularitySubmissionRequest.getTaskId());
        IntlIrTranDto tranDto = internationalService.getTransactionRecordByIrTranId(tranDtos.get(0).getIrTranId());

        OutboundTransactionDto outboundTransactionDto = null;
        OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
        ProcessActionsMeta processActionsMeta = new ProcessActionsMeta();

        if (irTaskOfficeType == OfficeType.OO) {
            outboundTransactionDto = new OutboundTransactionDto();

        } else {
            // Get the Application information from intrepid using TIRS
            outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(
                BigDecimal.valueOf(intlIrTaskDto.getFileNumber().intValue()), intlIrTaskDto.getExtensionCounter());

            outboundTransactionRequest.setFileNumber(BigDecimal.valueOf(intlIrTaskDto.getFileNumber().intValue()));
            outboundTransactionRequest.setExtensionCounter(intlIrTaskDto.getExtensionCounter());

            processActionsMeta.setFileNumber(BigDecimal.valueOf(intlIrTaskDto.getFileNumber().intValue()));
            processActionsMeta.setExtensionCounter(intlIrTaskDto.getExtensionCounter());

        }

        outboundTransactionDto.setResponseText(irregularitySubmissionRequest.getResponseText());
        outboundTransactionDto.setIntlRecordId(tranDto.getIntlRecordId());
        outboundTransactionDto.setIntlRegNo(tranDto.getIntlRegNo());
        outboundTransactionDto.setOfficeType(irTaskOfficeType);

        outboundTransactionRequest.setWipoReferenceNumber(intlIrTaskDto.getWipoReferenceNumber());
        outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_IRREGULARITY);

        processActionsMeta.setIrregularityResend(true);
        processActionsMeta.setIrNumber(tranDto.getIntlRegNo());
        processActionsMeta.setWipoReferenceNumber(intlIrTaskDto.getWipoReferenceNumber());

        // the max length is 240 defined in intrepid. see madrid-transation-services.properties
        if (StringUtils.isNotBlank(irregularitySubmissionRequest.getResponseText())) {
            if (irregularitySubmissionRequest.getResponseText().length() >= COMMENT_TEXT_SIZE.intValue()) {
                processActionsMeta.setAdditionalInfo(
                    irregularitySubmissionRequest.getResponseText().substring(0, COMMENT_TEXT_SIZE.intValue()));
            } else {
                processActionsMeta.setAdditionalInfo(irregularitySubmissionRequest.getResponseText());
            }
        }

        processActionsMeta.setAuthorityId(irregularitySubmissionRequest.getAuthorityId());

        processActionsMeta.setProcessActionCodeType(ProcessActionCodeType.IRREGULARITY_RESPONSE_SENT);
        processActionsMeta.setProcessCode(ProcessActionsMap.packageTransactionTypeProcessActionMap
            .get(MadridOutboundTransactionType.IRREGULARITY_RESPONSE_SENT));

        try {
            outboundTransactionService.createAutoOutboundTransaction(processActionsMeta, outboundTransactionRequest,
                outboundTransactionDto);
        } catch (Exception e) {
            logger.error("Error processIrregularitySubmission", e);
            throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
        }
        // change task status to processed
        internationalService.updateTaskStatus(irregularitySubmissionRequest.getTaskId(), TaskStatusType.PROCESSED);

        if (irTaskOfficeType != OfficeType.OO && intlIrTaskDto.getFileNumber() != null) {
            try {
                MailType mailType = MailType.valueOf(MailTransactionType.MADRID_IRREGULARITY_NOTIFICATION.name());
                intrepidCommonService.updateMailProcessedStatus(new BigDecimal(intlIrTaskDto.getFileNumber()), mailType,
                    irregularitySubmissionRequest.getAuthorityId());

            } catch (Throwable t) {
                throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
            }
        }

    }

    private void totalCancellation(GoodsAndServiceMeta gsInfo) throws CIPOServiceFault {

        // does not need to create another inbound message type MDT_TOTAL_CANCELLATION because
        // OfficeToIB message (MadridCancellation) has set application to "Withdrawn by Owner" status;
        // if so, MDT_TOTAL_CANCELLATION message is never processed. (see TMMADCON-2062)
        // Create Inbound Transaction
        // ByteArrayOutputStream inboundTransactionOS = this.createTotalCancellationTransaction(gsInfo);

        // internationalService.storeTransaction(inboundTransactionOS, null, StatusType.MPS_IMPORT_COMPLETE,
        // TransactionCategory.MDT_TOTAL_CANCELLATION, gsInfo.getTaskId().toString(),
        // gsInfo.getInternationalRegistrationNumber(), null);

        // Create Outbound Transaction
        // Get the Application information from intrepid using TIRS
        OutboundTransactionDto outboundTransactionDto = intrepidCommonService
            .getMadridApplicationDetails(gsInfo.getFileNumber(), gsInfo.getExtensioncounter());

        OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
        outboundTransactionRequest.setFileNumber(gsInfo.getFileNumber());
        outboundTransactionRequest.setExtensionCounter(gsInfo.getExtensioncounter());
        outboundTransactionRequest.setRecordIdentifier(gsInfo.getTaskId().toString());
        outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_CANCELLATION);

        outboundTransactionService.createAutoOutboundTransaction(outboundTransactionRequest, outboundTransactionDto);
    }

    private ProcessManualReportRequest getProcessManualReportRequestForTask(BigDecimal taskId, BigDecimal transactionId,
                                                                            GoodsAndServiceMeta gsMeta)
        throws MTSServiceFault {
        ProcessManualReportRequest request = null;
        try {
            TransactionDetail transaction = internationalService.getTransaction(transactionId, false, false);
            if (transaction.getTransactionType().getId() == MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3
                .getTransactionTypeId()) {
                request = getProvisionalRefusalMF3aTypeRequest(taskId, transactionId);
            } else if (transaction.getTransactionType()
                .getId() == MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9.getTransactionTypeId()
                || transaction.getTransactionType()
                    .getId() == MadridOutboundTransactionType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL
                        .getTransactionTypeId()
                || transaction.getTransactionType()
                    .getId() == MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_DIVISION
                        .getTransactionTypeId()
                || transaction.getTransactionType()
                    .getId() == MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER.getTransactionTypeId()
                || transaction.getTransactionType()
                    .getId() == MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT
                        .getTransactionTypeId()) {
                request = getCeasingOfEffectMF9TypeRequest(taskId, transactionId, gsMeta);
            } else if (gsMeta != null && (gsMeta.getTaskType().equals(GoodServiceTaskType.GOOD_SERVICE_LIMITATION)
                || gsMeta.getTaskType().equals(GoodServiceTaskType.DESIGNATION_LIMITATION))) {
                request = getLimitationNoEffectMF13TypeRequest(taskId, transactionId, gsMeta);
            }
        } catch (Exception e) {
            logger.error("Error getting intrepid information from TrademarkInfoRetrievalCommonService.", e);
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.SYSTEM_ERROR);
        }
        return request;

    }

    private ProcessManualReportRequest getProvisionalRefusalMF3aTypeRequest(BigDecimal taskId, BigDecimal transactionId)
        throws MTSServiceFault {

        ProcessManualReportRequest request = new ProcessManualReportRequest();
        request.setManualReportForm(new ManualReportForm());
        request.getManualReportForm().setProvisionalRefusalMF3AType(new ProvisionalRefusalMF3AType());
        request.getManualReportForm().getProvisionalRefusalMF3AType()
            .setProvisionalRefusalDetail(new ProvisionalRefusalDetail());
        request.getManualReportForm().getProvisionalRefusalMF3AType().setReviewOrFileAppeal(new ReviewOrFileAppeal());
        request.getManualReportForm().getProvisionalRefusalMF3AType()
            .setGroundsOfOppositionList(new GroundsOfOppositionList());

        UserProfileService tupsClient = UserProfileServiceFactory.createClient(tupsServiceHost);

        try {
            OppositionCaseMarkEventType oppCaseAction = null;

            IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(taskId);

            int oppositionCaseNum = -1;
            boolean opposiitonCaseFound = false;
            if (CollectionUtils.isNotEmpty(intlIrTaskDto.getIntlTaskAddtnlInfoDto())) {
                for (IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto : intlIrTaskDto.getIntlTaskAddtnlInfoDto()) {
                    if (TaskAddtnlInfoType.OPPOSITION_CASE_NUMBER.getValue() == intlTaskAddtnlInfoDto
                        .getIntlTaskAddtnlInfoTypeDto().getTaskAddtnlInfoCtgryId().intValue()) {
                        oppositionCaseNum = Integer.parseInt(intlTaskAddtnlInfoDto.getAddtnlInfo());
                        opposiitonCaseFound = true;
                        break;
                    }
                }
            }

            TMInfoRetrievalCommonServicePortType infoRetrievalClient = TrademarkInfoRetrievalCommonServiceFactory
                .createClient(tmirServiceHost);

            TMInfoRetrievalTMOBServicePortType tmobRetrievalClient = TrademarkInfoRetrievalTMOBServiceFactory
                .createClient(tmirServiceHost);

            // get user assigned to task
            UserProfileType type = new UserProfileType();
            type.setAuthorityId(intlIrTaskDto.getAuthorityId()); // .getActRuTask().getAssignee());
            UserProfile profile = tupsClient.getUserProfile(type);
            boolean isExaminer = ManualReportUtil.hasAuthorityRole(profile.getUserAuthorities(),
                IntlAuthorityRole.MC_TM_EXAMINER);

            // build application number
            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setFileNumber(intlIrTaskDto.getFileNumber());
            applicationNumber.setExtensionCounter(DEFAULT_EXTENSION_COUNTER);

            // get owner interested party
            TrademarkDetailsTypeMF3BagType tmMF3Bag = infoRetrievalClient
                .getTrademarkDetailsForMF3(intlIrTaskDto.getFileNumber(), true);
            TrademarkDetailsTypeMF3 tmMF3 = null;

            if (CollectionUtils.isNotEmpty(tmMF3Bag.getTrademarkDetailsTypeMF3())) {
                for (TrademarkDetailsTypeMF3 tm : tmMF3Bag.getTrademarkDetailsTypeMF3()) {
                    if (tm.getTradmarkDetails().getApplicationNumber()
                        .getExtensionCounter() == DEFAULT_EXTENSION_COUNTER) {
                        tmMF3 = tm;
                        break;
                    }
                }
            }

            // TrademarkDetailsTypeMF3 tmMF3 = infoRetrievalClient.getTrademarkDetailsForMF3(applicationNumber, true);

            TMInterestedPartyType owner = infoRetrievalClient.getInterestedPartyByRelationshipType(applicationNumber,
                RoleCategoryType.OWNER);

            TMInterestedPartyType opponent = null;
            if (opposiitonCaseFound) {
                opponent = tmobRetrievalClient.getOppositionCaseInterestedParties(applicationNumber, oppositionCaseNum)
                    .getTMInterestedParty().get(0);

                try {
                    //  Response Date from OPPOSITION_CASE_ACTIONS table where the Opposition Action ‘Deadline to File
                    // C/S (311)'
                    oppCaseAction = tmobRetrievalClient.getOppositionCaseAction(applicationNumber, oppositionCaseNum,
                        OppositionCaseActionCodeType.DEADLINE_TO_FILE_COUNTER_STATEMENT.getValue());
                } catch (Exception ex) {
                    // No record found for ActionCode.SO_SENT_TO_APPLICANT
                    logger.error(
                        "Issue getting Opposition Case Action  of Application with File number: "
                            + intlIrTaskDto.getFileNumber() + ", opposition case number : " + oppositionCaseNum
                            + ", action code : " + ActionCode.SO_SENT_TO_APPLICANT.getValue() + "\n" + ex.getMessage(),
                        ex);
                    oppCaseAction = null;
                }
            }

            TrademarkApplicationDetailsType tmDetails = infoRetrievalClient
                .getTrademarkApplicationDetails(applicationNumber);

            request.setLanguageCode(ManualReportUtil.getLanguageCodeType(tmDetails).value());
            request.setTaskId(taskId);
            request.setTransactionId(transactionId);
            request.setReportTypeCode(ReportTypeEnum.MF_3_A.value());

            request.getManualReportForm().getProvisionalRefusalMF3AType().setProcessActionInExamination(isExaminer);
            // Field I - o Display ‘Canadian Intellectual Property Office’
            request.setIpOffice(ManualReportUtil.getIpOffice(tmDetails, request.getLanguageCode()));
            // Field II - o Display IR Number from TASKS table
            request.setIrNumber(intlIrTaskDto.getIrNumber());
            // Field III - o Display Owner’s Name
            request.setOwnerName(ManualReportUtil.getOwnerName(owner));
            // Field IV - Display provisional detail
            request.getManualReportForm().getProvisionalRefusalMF3AType().setProvisionalRefusalDetail(
                ManualReportUtil.getProvisionalDetail(isExaminer, tmMF3, opponent, request.getLanguageCode()));
            // • Field V o Display ‘Total provisional refusal affects all goods and/or services’
            request.getManualReportForm().getProvisionalRefusalMF3AType()
                .setProvisionalRefusalScope(ManualReportUtil.getProvisionalRefusalScope(request.getLanguageCode()));
            // • Field VI
            request.getManualReportForm().getProvisionalRefusalMF3AType().setGroundsOfOppositionCodes(ManualReportUtil
                .getOppositionGroundsDescription(isExaminer, tmMF3, request.getLanguageCode(), oppositionCaseNum));

            // • Field VII
            if (isExaminer) {
                CitedLinksTypeBagType citedLinksTypeBagType = tmMF3.getCitedLinksBag();
                if (citedLinksTypeBagType != null && citedLinksTypeBagType.getCitedLinks() != null
                    && !citedLinksTypeBagType.getCitedLinks().isEmpty()) {
                    for (CitedLinksType citedLink : citedLinksTypeBagType.getCitedLinks()) {
                        // get trademark application details
                        TrademarkDetailsTypeMF3BagType citedTmMF3Bag = infoRetrievalClient
                            .getTrademarkDetailsForMF3(citedLink.getCitedFileNumber(), true);
                        TrademarkDetailsTypeMF3 citedTmMF3 = null;
                        if (CollectionUtils.isNotEmpty(citedTmMF3Bag.getTrademarkDetailsTypeMF3())) {
                            for (TrademarkDetailsTypeMF3 citedTm : citedTmMF3Bag.getTrademarkDetailsTypeMF3()) {
                                if (citedTm.getTradmarkDetails().getApplicationNumber()
                                    .getExtensionCounter() == citedLink.getCitedExtensionCounter()) {
                                    citedTmMF3 = citedTm;
                                    break;
                                }
                            }

                        }

                        GroundsOfOpposition e = new GroundsOfOpposition();
                        // o Field VII(i)
                        e.setFilingDate(ManualReportUtil.getCitedLinkFilingDate(citedTmMF3));
                        e.setFilingNumber(ManualReportUtil.getCitedLinkNumber(citedTmMF3));

                        if (citedTmMF3.getGoodsServicesClaimsBag() != null
                            && citedTmMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims() != null
                            && !citedTmMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims().isEmpty()) {
                            e.setPriorityDate(ManualReportUtil.getPriorityDate(
                                citedTmMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims(), logger));
                        }

                        // o Field VII(ii)
                        e.setRegistrationDate(ManualReportUtil.getCitedLinkRegistrationDate(citedTmMF3));
                        e.setRegistrationNumber(intrepidCommonService.getCitedRegistrationNumber(
                            citedLink.getCitedFileNumber(), citedLink.getCitedExtensionCounter()));

                        // o Field VII(iii)
                        e.setNameAndAddress(ManualReportUtil.getCitedLinkNameAndAddress(citedTmMF3));
                        // o Field VII(iv)
                        e.setTrademarkInfo(ManualReportUtil.getTrademarkInfo(citedTmMF3));
                        // o Field VII(v)
                        e.setNiceClassCode(ManualReportUtil.getCitedNiceClasses(citedTmMF3));
                        request.getManualReportForm().getProvisionalRefusalMF3AType().getGroundsOfOppositionList()
                            .getGroundsOfOppositionListBag().add(e);
                    }

                }

            } else {
                List<OppositionCitedMarksType> oppositionCitedMarksTypeList = getOppositionCitedMarksTypeList(tmMF3,
                    oppositionCaseNum);

                // For each opposition cited mark
                for (OppositionCitedMarksType oppoCitedLink : oppositionCitedMarksTypeList) {
                    GroundsOfOpposition e = new GroundsOfOpposition();

                    TrademarkDetailsTypeMF3BagType citedTmMF3Bag = infoRetrievalClient
                        .getTrademarkDetailsForMF3(oppoCitedLink.getCitedFileNumber(), true);
                    TrademarkDetailsTypeMF3 citedTmMF3 = null;
                    if (CollectionUtils.isNotEmpty(citedTmMF3Bag.getTrademarkDetailsTypeMF3())) {
                        for (TrademarkDetailsTypeMF3 citedTm : citedTmMF3Bag.getTrademarkDetailsTypeMF3()) {
                            if (citedTm.getTradmarkDetails().getApplicationNumber()
                                .getExtensionCounter() == oppoCitedLink.getCitedExtensionCounter()) {
                                citedTmMF3 = citedTm;
                                break;
                            }
                        }
                    }

                    // o Field VII(i)
                    e.setFilingDate(ManualReportUtil.getCitedLinkFilingDate(citedTmMF3));

                    e.setFilingNumber(ManualReportUtil.getCitedLinkNumber(citedTmMF3));
                    if (citedTmMF3.getGoodsServicesClaimsBag() != null
                        && citedTmMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims() != null
                        && !citedTmMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims().isEmpty()) {
                        e.setPriorityDate(ManualReportUtil
                            .getPriorityDate(citedTmMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims(), logger));
                    }

                    // o Field VII(ii)
                    e.setRegistrationDate(ManualReportUtil.getCitedLinkRegistrationDate(citedTmMF3));

                    e.setRegistrationNumber(intrepidCommonService.getCitedRegistrationNumber(
                        oppoCitedLink.getCitedFileNumber(), oppoCitedLink.getCitedExtensionCounter()));

                    // o Field VII(iii)
                    e.setNameAndAddress(ManualReportUtil.getCitedLinkNameAndAddress(citedTmMF3));
                    // o Field VII(iv)
                    e.setTrademarkInfo(ManualReportUtil.getTrademarkInfo(citedTmMF3));
                    // o Field VII(v)
                    e.setNiceClassCode(ManualReportUtil.getCitedNiceClasses(citedTmMF3));

                    request.getManualReportForm().getProvisionalRefusalMF3AType().getGroundsOfOppositionList()
                        .getGroundsOfOppositionListBag().add(e);

                }

            }
            // • Field VIII
            if (!isExaminer) {
                request.getManualReportForm().getProvisionalRefusalMF3AType()
                    .setGroundsOfOppositionDescription(ManualReportUtil.getOppositionGroundsSectionDetails(tmMF3,
                        request.getLanguageCode(), oppositionCaseNum));
            }
            // • Field IX
            request.getManualReportForm().getProvisionalRefusalMF3AType().setReviewOrFileAppeal(
                ManualReportUtil.getReviewOrFileAppeal(isExaminer, tmMF3, oppCaseAction, request.getLanguageCode()));
            request.setSystemDate(ManualReportUtil.getSystemDate());

        } catch (Exception e) {
            logger.error("Error getting intrepid information from TrademarkInfoRetrievalCommonService.", e);
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.SYSTEM_ERROR);

        }

        return request;
    }

    private List<OppositionCitedMarksType> getOppositionCitedMarksTypeList(TrademarkDetailsTypeMF3 tmMF3,
                                                                           int oppositionCaseNum) {
        List<OppositionCitedMarksType> OppositionCitedMarksTypeList = new ArrayList<OppositionCitedMarksType>();

        List<Integer> oppositionGroundsSeqList = new ArrayList<Integer>();
        OppositionGroundsTypeBagType oppositionGroundsTypeBagType = tmMF3.getOppositionGroundsBag();

        if (oppositionGroundsTypeBagType != null && oppositionGroundsTypeBagType.getOppositionGrounds() != null
            && !oppositionGroundsTypeBagType.getOppositionGrounds().isEmpty()) {

            for (OppositionGroundsType oppositionGroundsType : oppositionGroundsTypeBagType.getOppositionGrounds()) {
                if (oppositionGroundsType.getOppositionCaseNumber().intValue() == oppositionCaseNum) {
                    oppositionGroundsSeqList.add(oppositionGroundsType.getOppositionGroundsSeq());
                }
            }
        }

        OppositionCitedMarksTypeBagType oppositionCitedMarksTypeBagType = tmMF3.getOppositionCitedMarksBag();
        if (oppositionCitedMarksTypeBagType != null && oppositionCitedMarksTypeBagType.getOppositionCitedMarks() != null
            && !oppositionCitedMarksTypeBagType.getOppositionCitedMarks().isEmpty()) {

            // For each opposition cited mark
            for (OppositionCitedMarksType oppoCitedLink : oppositionCitedMarksTypeBagType.getOppositionCitedMarks()) {

                for (Integer oppositionGroundsSeq : oppositionGroundsSeqList) {
                    if (oppositionGroundsSeq.equals(oppoCitedLink.getOppositionGroundsSeq())) {
                        OppositionCitedMarksTypeList.add(oppoCitedLink);
                        break;
                    }
                }
            }
        }

        return OppositionCitedMarksTypeList;
    }

    private ProcessManualReportRequest getLimitationNoEffectMF13TypeRequest(BigDecimal taskId, BigDecimal transactionId,
                                                                            GoodsAndServiceMeta gsMeta)
        throws MTSServiceFault {

        ProcessManualReportRequest request = new ProcessManualReportRequest();
        request.setManualReportForm(new ManualReportForm());
        request.getManualReportForm().setLimitationNoEffectMF13Type(new LimitationNoEffectMF13Type());
        request.getManualReportForm().getLimitationNoEffectMF13Type().setGoodsAndServices(new GoodsAndServiceMeta());
        if (gsMeta != null) {
            request.getManualReportForm().getLimitationNoEffectMF13Type().setGoodsAndServices(gsMeta);
        }

        try {
            IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(taskId);

            TMInfoRetrievalCommonServicePortType infoRetrievalClient = TrademarkInfoRetrievalCommonServiceFactory
                .createClient(tmirServiceHost);

            // build application number
            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setFileNumber(intlIrTaskDto.getFileNumber());
            applicationNumber.setExtensionCounter(DEFAULT_EXTENSION_COUNTER);

            // get owner interested party
            TrademarkApplicationDetailsType tmDetails = infoRetrievalClient
                .getTrademarkApplicationDetails(applicationNumber);

            TMInterestedPartyType owner = infoRetrievalClient.getInterestedPartyByRelationshipType(applicationNumber,
                RoleCategoryType.OWNER);

            request.setLanguageCode(ManualReportUtil.getLanguageCodeType(tmDetails).value());
            request.setTaskId(taskId);
            request.setTransactionId(transactionId);
            request.setReportTypeCode(ReportTypeEnum.MF_13.value());
            request.getManualReportForm().getLimitationNoEffectMF13Type().setGoodsAndServices(gsMeta);

            // Field I - o Display ‘Canadian Intellectual Property Office’
            request.setIpOffice(ManualReportUtil.getIpOffice(tmDetails, request.getLanguageCode()));
            // Field II - o Display IR Number from TASKS table
            request.setIrNumber(intlIrTaskDto.getIrNumber());
            // Field III - o Display Owner’s Name
            request.setOwnerName(ManualReportUtil.getOwnerName(owner));
            // Field IV - Reasons for which the limitation has no effect:
            request.getManualReportForm().getLimitationNoEffectMF13Type().setReasonsForLimitation(MtsStringUtil.EMPTY);
            // • Field V Corresponding essential provisions of the applicable law:
            request.getManualReportForm().getLimitationNoEffectMF13Type()
                .setEssentialProvisionsLaw(MtsStringUtil.EMPTY);
            // • Field VI Goods and/or services affected by the declaration:
            request.getManualReportForm().getLimitationNoEffectMF13Type()
                .setGoodsAndServicesLimitation(ManualReportUtil.getGoodsAndServicesLimitation(
                    request.getManualReportForm().getLimitationNoEffectMF13Type().getGoodsAndServices(),
                    request.getLanguageCode()));
            // • Field VII o Display ‘This declaration is final and no longer subject to review or appeal.’
            request.getManualReportForm().getLimitationNoEffectMF13Type()
                .setFinalDeclaration(ManualReportUtil.getMF13Declaration(request.getLanguageCode()));
            // • Field VIII o Display ‘Registrar of Trademarks.’
            request.getManualReportForm().getLimitationNoEffectMF13Type()
                .setRegistrarAuthority(ManualReportUtil.getMF13RegistrarAuthority(request.getLanguageCode()));
            // IX. Date of communication to the International Bureau:
            request.setSystemDate(ManualReportUtil.getSystemDate());

        } catch (Exception e) {
            logger.error("Error getting intrepid information from TrademarkInfoRetrievalCommonService.", e);
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.SYSTEM_ERROR);

            // throw new MTSServiceFault(e.getMessage(), e.getFaultInfo());
            // throwCIPOFault(e);
        }

        return request;
    }

    private ProcessManualReportRequest getCeasingOfEffectMF9TypeRequest(BigDecimal taskId, BigDecimal transactionId,
                                                                        GoodsAndServiceMeta gsMeta)
        throws MTSServiceFault {

        ProcessManualReportRequest request = new ProcessManualReportRequest();
        request.setManualReportForm(new ManualReportForm());
        request.getManualReportForm().setCeasingOfEffectMF9Type(new CeasingOfEffectMF9Type());

        if (gsMeta == null) {
            gsMeta = new GoodsAndServiceMeta();
        }

        request.getManualReportForm().getCeasingOfEffectMF9Type().setGoodsAndServices(gsMeta);

        try {
            IntlIrTaskDto intlIrTaskDto = internationalService.getConsoleTaskById(taskId);

            TMInfoRetrievalCommonServicePortType infoRetrievalClient = TrademarkInfoRetrievalCommonServiceFactory
                .createClient(tmirServiceHost);

            // build application number
            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setFileNumber(intlIrTaskDto.getFileNumber());
            applicationNumber.setExtensionCounter(DEFAULT_EXTENSION_COUNTER);

            String officeType = intlIrTaskDto.getOfficeType();
            if (officeType.equalsIgnoreCase(OfficeType.OO.name())) {
                try {
                    MOPSClient mopsClient = MOPSServiceFactory.createClient(mopsServiceHost);
                    MOPSServiceResponse mopsResponse = mopsClient
                        .getMadridRegistrationByIRNumber(intlIrTaskDto.getIrNumber());
                    // Field III - o Display Owner’s Name from MOPS
                    request.setOwnerName(ManualReportUtil.getHolderName(mopsResponse));
                } catch (Exception e) {
                    throwMTSServiceFault("mts.mops.service.error", ExceptionReasonCode.SYSTEM_ERROR);
                }

            } else {
                TMInterestedPartyType owner = infoRetrievalClient
                    .getInterestedPartyByRelationshipType(applicationNumber, RoleCategoryType.OWNER);
                request.setOwnerName(ManualReportUtil.getOwnerName(owner));
            }

            // get owner interested party
            TrademarkApplicationDetailsType tmDetails = infoRetrievalClient
                .getTrademarkApplicationDetails(applicationNumber);

            request.setLanguageCode(ManualReportUtil.getLanguageCodeType(tmDetails).value());
            request.setTaskId(taskId);
            request.setTransactionId(transactionId);
            request.setReportTypeCode(ReportTypeEnum.MF_9.value());

            // Field I - o Display ‘Canadian Intellectual Property Office’
            request.setIpOffice(ManualReportUtil.getIpOffice(tmDetails, request.getLanguageCode()));
            // Field II - o Display IR Number from TASKS table
            request.setIrNumber(intlIrTaskDto.getIrNumber());

            // Field IV - Reasons for which the limitation has no effect:
            request.getManualReportForm().getCeasingOfEffectMF9Type().setCeasingOfEffectDecision(MtsStringUtil.EMPTY);
            // • Field V Effective Date:
            request.getManualReportForm().getCeasingOfEffectMF9Type().setCeasingEffectiveInfo(MtsStringUtil.EMPTY);
            // • Field VI Effective Date:
            request.getManualReportForm().getCeasingOfEffectMF9Type()
                .setGoodsAndServicesCeasing(ManualReportUtil.getGoodsAndServicesCeasing(
                    request.getManualReportForm().getCeasingOfEffectMF9Type().getGoodsAndServices(),
                    request.getLanguageCode()));
            // • Field VII Goods and/or services affected by the declaration:
            request.getManualReportForm().getCeasingOfEffectMF9Type()
                .setRequestForCancellation(ManualReportUtil.getMF9CancellationDeclaration(request.getLanguageCode()));
            // • Field VIII o Display ‘Registrar of Trademarks.’
            request.getManualReportForm().getCeasingOfEffectMF9Type()
                .setRegistrarAuthority(ManualReportUtil.getMF9RegistrarAuthority(request.getLanguageCode()));
            // IX. Date of communication to the International Bureau:
            request.setSystemDate(ManualReportUtil.getSystemDate());

        } catch (Exception e) {
            logger.error("Error getting intrepid information from TrademarkInfoRetrievalCommonService.", e);
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.SYSTEM_ERROR);

            // throw new MTSServiceFault(e.getMessage(), e.getFaultInfo());
            // throwCIPOFault(e);
        }

        return request;
    }

    private ByteArrayOutputStream createTotalCeasingEffectTransaction(GoodsAndServiceMeta gsInfo)
        throws MTSServiceFault {

        _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory();
        _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

        MadridDesignationTerminationType madridDesignationTerminationType = objectFactory
            .createMadridDesignationTerminationType();

        madridDesignationTerminationType
            .setInternationalRegistrationNumber(gsInfo.getInternationalRegistrationNumber());
        madridDesignationTerminationType
            .setMadridDesignationTerminationCategory(MadridDesignationTerminationCategoryType.TOTAL_CEASING_OF_EFFECT);

        IdentifierType identifierType = commonObjectFactory.createIdentifierType();
        identifierType.setValue(gsInfo.getTaskId().toString());
        madridDesignationTerminationType.setRecordIdentifier(identifierType);
        madridDesignationTerminationType.setExpiryDate(DateFormats.getISOSDF().format(new Date()));
        madridDesignationTerminationType.setRecordFilingDate(DateFormats.getISOSDF().format(new Date()));

        ByteArrayOutputStream transactionOutputStream = null;
        JAXBElement<MadridDesignationTerminationType> madridobject = objectFactory
            .createMadridDesignationTermination(madridDesignationTerminationType);
        Marshaller jaxbMarshaller;

        try {
            jaxbMarshaller = marshallingService.getMadridJAXBContext().createMarshaller();
            transactionOutputStream = marshallingService.marshalIt(jaxbMarshaller, madridobject);

        } catch (Exception e) {
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.SYSTEM_ERROR);
        }

        return transactionOutputStream;
    }

    private ByteArrayOutputStream createTotalCancellationTransaction(GoodsAndServiceMeta gsInfo)
        throws MTSServiceFault {

        _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory();
        _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

        MadridDesignationTerminationType madridDesignationTerminationType = objectFactory
            .createMadridDesignationTerminationType();

        madridDesignationTerminationType
            .setInternationalRegistrationNumber(gsInfo.getInternationalRegistrationNumber());
        madridDesignationTerminationType
            .setMadridDesignationTerminationCategory(MadridDesignationTerminationCategoryType.TOTAL_CANCELLATION);

        IdentifierType identifierType = commonObjectFactory.createIdentifierType();
        identifierType.setValue("TODO");
        madridDesignationTerminationType.setRecordIdentifier(identifierType);
        madridDesignationTerminationType.setExpiryDate(DateFormats.getISOSDF().format(new Date()));
        madridDesignationTerminationType.setRecordFilingDate(DateFormats.getISOSDF().format(new Date()));

        ByteArrayOutputStream transactionOutputStream = null;
        JAXBElement<MadridDesignationTerminationType> madridobject = objectFactory
            .createMadridDesignationTermination(madridDesignationTerminationType);
        Marshaller jaxbMarshaller;

        try {
            jaxbMarshaller = marshallingService.getMadridJAXBContext().createMarshaller();
            transactionOutputStream = marshallingService.marshalIt(jaxbMarshaller, madridobject);

        } catch (Exception e) {
            throwMTSServiceFault("mts.create.transaction.error", ExceptionReasonCode.SYSTEM_ERROR);
        }

        return transactionOutputStream;
    }

    @Override
    public void processIRCorrectionSubmission(ProcessIRCorrectionSubmissionRequest request) throws CIPOServiceFault {
        // create new actions
        MadridCorrectionType xmlTransaction = getIRCorrectionTaskTransaction(request);

        String recordEffectiveDate = xmlTransaction.getRecordEffectiveDate();
        String packageNotificationDate = xmlTransaction.getMadridCorrectContent().getMadridDesignation()
            .getRecordNotificationDate();

        try {
            intrepidProcessGoodServices.processIRCorrectionActions(request, recordEffectiveDate,
                packageNotificationDate);
        } catch (Exception e) {

            logger.error("Error processing processIRCorrectionActions from console.", e);

            throwMTSServiceFault("mts.general.error", ExceptionReasonCode.SYSTEM_ERROR);
        }

        try {
            MailType mailType = MailType.valueOf(MailTransactionType.MADRID_CORRECTION.name());
            intrepidCommonService.updateMailProcessedStatus(new BigDecimal(request.getFileNumber().intValue()),
                mailType, request.getAuthorityId());

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }

        // change task status to processed
        internationalService.updateTaskStatus(request.getTaskId(), TaskStatusType.PROCESSED);
    }

    private MadridCorrectionType getIRCorrectionTaskTransaction(ProcessIRCorrectionSubmissionRequest request)
        throws MTSServiceFault {
        List<IntlIrTranDto> transactionList = internationalService.getTransactionByTaskId(request.getTaskId());

        if (CollectionUtils.isEmpty(transactionList)) {
            throw new IllegalArgumentException(
                "Expecting one transaction for Partial Cancellation taskId: " + request.getTaskId());
        }

        MadridCorrectionType xmlTransaction = null;
        try {
            xmlTransaction = unmarshallTransaction(transactionList.get(0));

        } catch (Exception exception) {
            throwMTSServiceFault("mts.error.unmarshalling.transaction", ExceptionReasonCode.RETRYABLE_ERROR);
        }

        return xmlTransaction;
    }

    @Override
    public void processModifiedRepAddressSubmission(ProcessModifiedRepAddressSubmissionRequest request)
        throws MTSServiceFault {
        // create courtesy letter
        List<IntlIrTranDto> transactionList = internationalService.getTransactionByTaskId(request.getTaskId());

        if (CollectionUtils.isEmpty(transactionList)) {
            throw new IllegalArgumentException(
                "Expecting one transaction for Partial Cancellation taskId: " + request.getTaskId());
        }

        for (IntlIrTranDto intlIrTransaction : transactionList) {
            try {
                // create new PDF and process action
                courtestyLetterService.processCourtesyLetterAndProcessActions(request, intlIrTransaction);

            } catch (Exception e) {
                logger.error("Error in processModifiedRepAddressSubmission ", e);
                throwMTSServiceFault("mts.processing.inbound.transaction.error", ExceptionReasonCode.RETRYABLE_ERROR);
            }
        }

        // change task status to processed
        internationalService.updateTaskStatus(request.getTaskId(), TaskStatusType.PROCESSED);
    }
}
