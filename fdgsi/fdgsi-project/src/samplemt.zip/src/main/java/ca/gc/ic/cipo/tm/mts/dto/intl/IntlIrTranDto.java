package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;

public class IntlIrTranDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 5081825994411311582L;

    private BigDecimal irTranId;

    private IntlPkgDto intlPkg;

    private IntlPkgTranTypeDto intlPkgTranType;

    private IntlStatusTypeDto statusTypeDto;

    private List<IntlIrTaskXrefDto> intlIrTaskXrefDtoList;

    private List<IntlAtchmtDto> intlAtchmtDtoList;

    private List<IntlIrTaskDto> intlIrTaskList;

    private List<Integer> lockedFileList;

    private String intlRegNo;

    private String intlRecordId;

    private String dmstcApltnNbr;

    private Timestamp createdTmstmp;

    private Timestamp updatedTmstmp;

    private Date intlRecordEfctvDt;

    private OfficeType officeType;

    private String officeRefId;

    private IrregularityDto irregularityDto;

    public BigDecimal getIrTranId() {
        return irTranId;
    }

    public void setIrTranId(BigDecimal irTranId) {
        this.irTranId = irTranId;
    }

    public String getIntlRegNo() {
        return intlRegNo;
    }

    public void setIntlRegNo(String intlRegNo) {
        this.intlRegNo = intlRegNo;
    }

    public String getIntlRecordId() {
        return intlRecordId;
    }

    public void setIntlRecordId(String intlRecordId) {
        this.intlRecordId = intlRecordId;
    }

    public Timestamp getCreatedTmstmp() {
        return createdTmstmp;
    }

    public void setCreatedTmstmp(Timestamp createdTmstmp) {
        this.createdTmstmp = createdTmstmp;
    }

    public Timestamp getUpdatedTmstmp() {
        return updatedTmstmp;
    }

    public void setUpdatedTmstmp(Timestamp updatedTmstmp) {
        this.updatedTmstmp = updatedTmstmp;
    }

    public IntlPkgDto getIntlPkg() {
        return intlPkg;
    }

    public void setIntlPkg(IntlPkgDto intlPkg) {
        this.intlPkg = intlPkg;
    }

    public IntlPkgTranTypeDto getIntlPkgTranType() {
        return intlPkgTranType;
    }

    public void setIntlPkgTranType(IntlPkgTranTypeDto intlPkgTranType) {
        this.intlPkgTranType = intlPkgTranType;
    }

    public IntlStatusTypeDto getStatusTypeDto() {
        return statusTypeDto;
    }

    public void setStatusTypeDto(IntlStatusTypeDto statusTypeDto) {
        this.statusTypeDto = statusTypeDto;
    }

    public List<IntlIrTaskXrefDto> getIntlIrTaskXrefDtoList() {
        if (null == intlIrTaskXrefDtoList) {
            intlIrTaskXrefDtoList = new ArrayList<>();
        }
        return intlIrTaskXrefDtoList;
    }

    public void setIntlIrTaskXrefDtoList(List<IntlIrTaskXrefDto> intlIrTaskXrefDtoList) {
        this.intlIrTaskXrefDtoList = intlIrTaskXrefDtoList;
    }

    public List<IntlAtchmtDto> getIntlAtchmtDtoList() {
        if (null == intlAtchmtDtoList) {
            intlAtchmtDtoList = new ArrayList<>();
        }
        return intlAtchmtDtoList;
    }

    public void setIntlAtchmtDtoList(List<IntlAtchmtDto> intlAtchmtDtoList) {
        this.intlAtchmtDtoList = intlAtchmtDtoList;
    }

    public Date getIntlRecordEfctvDt() {
        return intlRecordEfctvDt;
    }

    public void setIntlRecordEfctvDt(Date intlRecordEfctvDt) {
        this.intlRecordEfctvDt = intlRecordEfctvDt;
    }

    public String getDmstcApltnNbr() {
        return dmstcApltnNbr;
    }

    public void setDmstcApltnNbr(String dmstcApltnNbr) {
        this.dmstcApltnNbr = dmstcApltnNbr;
    }

    public List<IntlIrTaskDto> getIntlIrTaskList() {
        return intlIrTaskList;
    }

    public void setIntlIrTaskList(List<IntlIrTaskDto> intlIrTaskList) {
        this.intlIrTaskList = intlIrTaskList;
    }

    public String getOfficeRefId() {
        return officeRefId;
    }

    public void setOfficeRefId(String officeRefId) {
        this.officeRefId = officeRefId;
    }

    public List<Integer> getLockedFileList() {
        return lockedFileList;
    }

    public void setLockedFileList(List<Integer> lockedFileList) {
        this.lockedFileList = lockedFileList;
    }

    public OfficeType getOfficeType() {
        return officeType;
    }

    public void setOfficeType(OfficeType officeType) {
        this.officeType = officeType;
    }

    public IrregularityDto getIrregularityDto() {
        return irregularityDto;
    }

    public void setIrregularityDto(IrregularityDto irregularityDto) {
        this.irregularityDto = irregularityDto;
    }

    @Override
    public String toString() {
        return "IntlIrTranDto [irTranId=" + irTranId + ", intlPkg=" + intlPkg + ", intlPkgTranType=" + intlPkgTranType
            + ", statusTypeDto=" + statusTypeDto + ", intlIrTaskXrefDtoList=" + intlIrTaskXrefDtoList
            + ", intlAtchmtDtoList=" + intlAtchmtDtoList + ", intlIrTaskList=" + intlIrTaskList + ", lockedFileList="
            + lockedFileList + ", intlRegNo=" + intlRegNo + ", intlRecordId=" + intlRecordId + ", dmstcApltnNbr="
            + dmstcApltnNbr + ", createdTmstmp=" + createdTmstmp + ", updatedTmstmp=" + updatedTmstmp
            + ", intlRecordEfctvDt=" + intlRecordEfctvDt + ", officeType=" + officeType + ", officeRefId=" + officeRefId
            + ", irregularityDto=" + irregularityDto + "]";
    }

}
