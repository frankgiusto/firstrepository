package ca.gc.ic.cipo.tm.mts.enums;

import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;

/**
 * The Enum FeatureCategoryTrademarkType maps a given ST96 MarkFeatureCategoryType to a TradeMarkType.
 *
 * @author giustof
 */
public enum FeatureCategoryTrademarkType {

    WORD(TradeMarkType.STANDARD_CHARACTERS),

    FIGURATIVE(TradeMarkType.DESIGN),

    COLOUR(TradeMarkType.COLOR),

    THREE_DIMENSIONAL(TradeMarkType.THREE_DIMENSIONAL),

    POSITION(TradeMarkType.POSITIONAL),

    HOLOGRAM(TradeMarkType.HOLOGRAM),

    MOTION(TradeMarkType.MOTION),

    SOUND(TradeMarkType.SOUND),

    TASTE(TradeMarkType.TASTE),

    OLFACTORY(TradeMarkType.SCENT),

    TOUCH(TradeMarkType.TEXTURE),

    STYLIZED_CHARACTERS(TradeMarkType.DESIGN),

    MULTIMEDIA(TradeMarkType.MOTION),

    COMBINED(TradeMarkType.DESIGN),

    TRACER(TradeMarkType.DESIGN),

    OTHER(TradeMarkType.DESIGN);

    private TradeMarkType tradeMark;

    private FeatureCategoryTrademarkType(TradeMarkType tradeMark) {
        this.tradeMark = tradeMark;
    }

    public TradeMarkType getTrademark() {
        return this.tradeMark;
    }

}
