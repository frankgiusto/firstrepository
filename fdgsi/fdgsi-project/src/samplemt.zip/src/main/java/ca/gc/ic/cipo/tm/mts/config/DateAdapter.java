/*
 * Copyright (c) 2017 CIPO Created on Nov 28, 2017
 */
package ca.gc.ic.cipo.tm.mts.config;

import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 * This simple adapter class allows a 'date' type defined in a WSDL to be converted into a java.util.Date rather than a
 * XMLGregorianCalendar. This eliminates the step of conversion typically sprinkled throughout the service code.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public class DateAdapter extends XmlAdapter<String, Date> {

    @Override
    public String marshal(Date value) throws Exception {
        // Note: org.apache.cxf.tools.common.DataTypeAdapter.printDate(value) is
        // deprecated
        if (value == null) {
            return null;
        }
        Calendar c = Calendar.getInstance();
        c.setTime(value);
        return DatatypeConverter.printDate(c);
    }

    @Override
    public Date unmarshal(String value) throws Exception {
        // Note: org.apache.cxf.tools.common.DataTypeAdapter.parseDate(value) is
        // deprecated
        if (value == null) {
            return null;
        }
        return DatatypeConverter.parseDate(value).getTime();
    }
}
