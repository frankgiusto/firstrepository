package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public interface IOutboundTransaction {

    /**
     * Creates the outbound transaction.
     *
     * @param outboundTransactionDto the outbound transaction dto
     * @param outboundTransactionRequest the outbound transaction request
     * @param intlIrTranDto the intl ir tran dto
     * @param marshallingService the marshalling service
     * @return the byte array output stream
     * @throws Exception the exception
     */
    ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                    OutboundTransactionRequest outboundTransactionRequest,
                                                    IntlIrTranDto intlIrTranDto, IMarshallingService marshallingService)
        throws Exception;

    /**
     * Gets the madrid outbound transaction type.
     *
     * @return the madrid outbound transaction type
     */
    MadridOutboundTransactionType getMadridOutboundTransactionType();

    /**
     * Checks if is pdf required.
     *
     * @return true, if is pdf required
     */
    boolean isPdfRequired();

}
