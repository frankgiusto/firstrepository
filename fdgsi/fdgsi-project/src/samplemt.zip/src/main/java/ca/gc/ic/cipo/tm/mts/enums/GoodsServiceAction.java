package ca.gc.ic.cipo.tm.mts.enums;

/**
 * Indicates further action on processing G&S
 *
 * @author giustof
 */
public enum GoodsServiceAction {

    TOTAL_CEASING_EFFECT,

    MADRID_LIMITATION_NO_EFFECT,

    TOTAL_CANCELLATION,

    NO_ACTION;

    private GoodsServiceAction() {

    }

}
