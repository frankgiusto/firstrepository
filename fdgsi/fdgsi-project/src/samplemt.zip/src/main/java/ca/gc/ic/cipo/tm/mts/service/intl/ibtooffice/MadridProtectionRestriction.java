package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * @author giustof
 *
 *         The Class MadridProtectionRestriction is responsible for processing a MadridProtectionRestriction inbound
 *         transaction with a transaction category type of Limitation, Partial Ceasing of Effect, or Partial
 *         Cancellation. A manual notification task will be created.
 */
@Service(value = "protectionRestriction")
public class MadridProtectionRestriction extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(MadridProtectionRestriction.class.getName());

    @Override
    @Transactional(rollbackFor = Exception.class)
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transactionType)
        throws MTSServiceFault {

        logger.debug("Processing protectionRestriction: Intl Record Id:" + intlIrTran.getIntlRecordId());

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        MadridProtectionRestrictionType transaction = (MadridProtectionRestrictionType) transactionType;

        MadridProtectionRestrictionCategoryType categoryType = ((MadridProtectionRestrictionType) transactionType)
            .getMadridProtectionRestrictionCategory();

        // Get all applications matching transactions international registration number.

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                if (categoryType == MadridProtectionRestrictionCategoryType.LIMITATION) {
                    // set LimitationListCode to Limited List - Reviewed
                    application.setLimitationListCode(LIMITATION_LIST_CODE_EXAMINED);
                }

                // Record Applications with the same IR Number
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                boolean openOppositionCaseExists = false;

                if (application.getStatusCode().intValue() == TradeMarkStatusType.REGISTERED.getValue().intValue()) {

                    openOppositionCaseExists = oppositionCasesExist(application, registeredOppositionCaseTypes,
                        TradeMarkStatusType.REGISTERED);

                } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                    .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    openOppositionCaseExists = oppositionCasesExist(application, unRegisteredOppositionCaseTypes,
                        TradeMarkStatusType.REGISTRATION_PENDING);

                }

                ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);

                if (openOppositionCaseExists) {
                    // Assign the Task to ‘TMOB Operator’
                    applicationDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_OPERATOR.name());
                } else {
                    // Assign the Task to ‘Madrid TM Examiner’
                    applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_EXAMINER.name());
                }

                // Set the Manual Task
                if (!ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                    applicationDto.setTaskStatusCode(TaskStatusType.ON_HOLD.getValue());
                }
                statusTypeResults.put(applicationDto, this.setConsoleTask(application, transaction));

            }
        } else {
            // Madrid Mark does not exist - manual
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    private UserTaskType setConsoleTask(Application application, MadridProtectionRestrictionType transaction) {

        if (transaction
            .getMadridProtectionRestrictionCategory() == MadridProtectionRestrictionCategoryType.LIMITATION) {
            return UserTaskType.GOODSERVICE_LIMITATION;
        } else if (transaction
            .getMadridProtectionRestrictionCategory() == MadridProtectionRestrictionCategoryType.PARTIAL_CANCELLATION) {
            return UserTaskType.PARTIAL_CANCELLATION;
        } else if (transaction
            .getMadridProtectionRestrictionCategory() == MadridProtectionRestrictionCategoryType.PARTIAL_CEASING_OF_EFFECT) {
            return UserTaskType.PARTIAL_CEASING_OF_EFFECT_DO;
        }
        throw new IllegalArgumentException("Invalid transaction category in setConsoleTask " + this.getServiceName());
    }

    private boolean oppositionCasesExist(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes,
                                         TradeMarkStatusType nonRenewalType) {

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    return true;

                }
            }
        }
        return false;
    }

    @Override
    public String getServiceName() {
        return "ProtectionRestrictionManual";
    }

}
