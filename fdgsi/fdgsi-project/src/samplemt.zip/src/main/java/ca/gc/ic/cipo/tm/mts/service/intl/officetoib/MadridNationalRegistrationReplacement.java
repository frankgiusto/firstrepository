package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;

import javax.xml.bind.JAXBElement;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ApplicationNumberType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridNationalRegistrationReplacementType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.NationalMarkBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.NationalMarkType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public class MadridNationalRegistrationReplacement extends OfficeToIbBase implements IOutboundTransaction {

    private static Logger log = Logger.getLogger(MadridNationalRegistrationReplacement.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = null;

    // Full or Partial
    public MadridNationalRegistrationReplacement(MadridOutboundTransactionType madridOutboundTransactionType) {
        this.madridOutboundTransactionType = madridOutboundTransactionType;
    }

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();
        _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

        MadridNationalRegistrationReplacementType transaction = objectFactory
            .createMadridNationalRegistrationReplacementType();
        TMInfoRetrievalDto tirsDto = outboundTransactionDto.getProcessActionApplication();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(tirsDto);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Holder Bag
        transaction.setHolderBag(super.mapHolder(tirsDto.getTmInterestedPartyTypeList(), notificationLanguage));

        // NationalMarkBag
        // Set tmk:NationalMarkApplicationNumber to the Domestic File Number stored in the Additional Info field in
        // intrepid Process Action table
        ApplicationNumberType applicationNumberType = commonObjectFactory.createApplicationNumberType();
        // applicationNumberType.setApplicationNumberText(String.valueOf(formatValue(outboundTransactionRequest.getAdditionalInfo())));

        String fileNumber = String.valueOf(outboundTransactionRequest.getAdditionalInfo());
        String fileNumberExt = "00";
        String fileNumberST13 = "30" + "0000" + StringUtils.leftPad(fileNumber, 7, "0") + fileNumberExt;
        applicationNumberType.setST13ApplicationNumber(fileNumberST13);

        NationalMarkBagType nationalMarkBagType = objectFactory.createNationalMarkBagType();
        NationalMarkType nationalMarkType = objectFactory.createNationalMarkType();
        nationalMarkType.setNationalMarkApplicationNumber(applicationNumberType);
        nationalMarkBagType.getNationalMark().add(nationalMarkType);
        transaction.setNationalMarkBag(nationalMarkBagType);

        if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL) {
            // Goods Services Indicator
            transaction.setAllGoodsServicesIndicator(true);

        } else if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL) {
            // transaction.setAllGoodsServicesIndicator(false);
            // TODO. SUC - what does this mean? Include the Goods/Services of the Madrid mark (File Number is equal to
            // the File Number field in Intl_Ir_Task
            // Goods Services Bag
            // transaction.setAllGoodsServicesIndicator(false);
            transaction.setGoodsServicesBag(mapGoodsServices(tirsDto.getGoodsAndServices()));
        }

        JAXBElement<MadridNationalRegistrationReplacementType> madridobject = objectFactory
            .createMadridNationalRegistrationReplacement(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {

        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return false;
    }
}
