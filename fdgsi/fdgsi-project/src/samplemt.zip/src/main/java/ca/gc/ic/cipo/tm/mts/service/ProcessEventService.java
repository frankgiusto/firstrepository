package ca.gc.ic.cipo.tm.mts.service;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.OutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.util.ProcessEventUtil;

@Service
public class ProcessEventService implements IProcessEventService {

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    private static final Logger logger = LoggerFactory.getLogger(OutboundTransactionService.class);

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void insertProcessEvent(BigDecimal irTranId, String msgKey, Throwable exception, Object... msgArgs) {

        IntlIrTran intlIrTran = intlIrTranDao.getById(irTranId);

        try {
            ProcessEventUtil.getInstance().addProcessErrorEvent(intlIrTran, msgKey, exception, msgArgs);
            intlIrTranDao.save(intlIrTran);

        } catch (MTSServiceFault e) {
            logger.error("Tried to store exception in process event");
        }

    }

}
