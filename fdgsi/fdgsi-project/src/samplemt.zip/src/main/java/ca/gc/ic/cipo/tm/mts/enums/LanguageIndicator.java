package ca.gc.ic.cipo.tm.mts.enums;

/**
 * The Enum LanguageIndicator defines component language elements based on current application language.
 *
 * @author giustof
 */
public enum LanguageIndicator {

    // Application language English or Spanish
    APP_ENGLISH_GOODS_SERVICES_ENGLISH(1),

    APP_ENGLISH_GOODS_SERVICES_FRENCH(2),

    APP_ENGLISH_APP_TEXT_ENGLISH(1),

    APP_ENGLISH_APP_TEXT_FRENCH(2),

    // Application language French
    APP_FRENCH_GOODS_SERVICES_ENGLISH(1),

    APP_FRENCH_GOODS_SERVICES_FRENCH(2),

    APP_FRENCH_APP_TEXT_ENGLISH(1),

    APP_FRENCH_APP_TEXT_FRENCH(2);

    private Integer language;

    private LanguageIndicator(Integer language) {
        this.setLanguage(language);
    }

    public Integer getLanguage() {
        return language;
    }

    public void setLanguage(Integer language) {
        this.language = language;
    }

}
