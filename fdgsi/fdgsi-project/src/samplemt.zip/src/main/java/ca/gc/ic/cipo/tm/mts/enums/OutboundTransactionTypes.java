package ca.gc.ic.cipo.tm.mts.enums;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridCancellation;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridCeasingEffect;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridCorrection;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridFinalDecision;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridFurtherDecision;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridGoodsServicesLimitationRequest;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridGrantProtection;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridInvalidation;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridIrregularity;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridLimitationNoEffect;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridNationalRegistrationReplacement;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridNewBasicApplication;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridPossibleOppositionNotification;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridProvisionalRefusal;

public enum OutboundTransactionTypes {

    MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF_1 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridPossibleOppositionNotification(
                MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1);
        }
    },
    MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF_2 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridPossibleOppositionNotification(
                MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF2);
        }
    },
    MADRID_PROVISIONAL_REFUSAL_MF_3 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridProvisionalRefusal();
        }
    },
    MADRID_GRANT_PROTECTION_MF_4 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridGrantProtection();
        }
    },
    MADRID_FINAL_DECISION_MF_5 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridFinalDecision(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5);
        }
    },
    MADRID_FINAL_DECISION_MF_6 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridFinalDecision(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF6);
        }
    },
    MADRID_NEW_BASIC_APPLICATION_MERGER {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridNewBasicApplication(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER);
        }
    },
    MADRID_NEW_BASIC_APPLICATION_DIVISION {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridNewBasicApplication(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_DIVISION);
        }
    },
    MADRID_NEW_BASIC_APPLICATION_MERGER_EXT {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridNewBasicApplication(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT);
        }
    },
    MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridNationalRegistrationReplacement(
                MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL);
        }
    },
    MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridNationalRegistrationReplacement(
                MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL);
        }
    },
    MADRID_INVALIDATION_FULL_MF_10 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridInvalidation(MadridOutboundTransactionType.MADRID_INVALIDATION_FULL_MF10);
        }
    },
    MADRID_INVALIDATION_PARTIAL_MF_10 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridInvalidation(MadridOutboundTransactionType.MADRID_INVALIDATION_PARTIAL_MF10);
        }
    },
    MADRID_CORRECTION_REQUEST {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridCorrection();
        }
    },
    MADRID_CEASING_EFFECT_TOTAL_MF_9 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridCeasingEffect(MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9);
        }
    },
    MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridCeasingEffect(MadridOutboundTransactionType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL);
        }
    },

    /*
     * MADRID_POTENTIAL_CEASING_EFFECT {
     *
     * @Override public IOutboundTransaction createOutboundTransaction() { return new MadridPotentialCeasingEffect(); }
     * },
     */

    MADRID_FURTHER_DECISION_MF_7 {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridFurtherDecision();
        }
    },
    MADRID_CANCELLATION {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridCancellation();
        }
    },
    MADRID_IRREGULARITY {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridIrregularity();
        }
    },

    IRREGULARITY_RESPONSE_SENT {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridIrregularity();
        }
    },
    MADRID_LIMITATION_NO_EFFECT {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridLimitationNoEffect();
        }
    },
    MADRID_GOODS_SERVICES_LIMITATION_REQUEST {

        @Override
        public IOutboundTransaction createOutboundTransaction() {
            return new MadridGoodsServicesLimitationRequest();
        }
    };

    public abstract IOutboundTransaction createOutboundTransaction();
}
