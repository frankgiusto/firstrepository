package ca.gc.ic.cipo.tm.mts.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.enumerator.MailType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.AcquireTrademarkLockRequest;
import ca.gc.ic.cipo.tm.mts.AcquireTrademarkLockResponse;
import ca.gc.ic.cipo.tm.mts.AirToExaminationRequest;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingPairCriteria;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.DuplicateIrregularResponse;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.GetManualReportRequest;
import ca.gc.ic.cipo.tm.mts.GetTransactionByIntlRecordIdRequest;
import ca.gc.ic.cipo.tm.mts.GetTransactionByIntlRecordIdResponse;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.LanguageType;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.MailTransactionType;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.OfficeToIbProcessActions;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionList;
import ca.gc.ic.cipo.tm.mts.ProcessActionsCountRequest;
import ca.gc.ic.cipo.tm.mts.ProcessActionsCountResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessIrregularitySubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ReleaseTrademarkLockRequest;
import ca.gc.ic.cipo.tm.mts.ReleaseTrademarkLockResponse;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateRequest;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionListForHolderDetailsRequest;
import ca.gc.ic.cipo.tm.mts.TransactionListForHolderDetailsResponse;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ic.cipo.tm.mts.TransactionTaskIds;
import ca.gc.ic.cipo.tm.mts.TransactionType;
import ca.gc.ic.cipo.tm.mts.UpdateHolderContactDetailsRequest;
import ca.gc.ic.cipo.tm.mts.UpdateHolderContactDetailsResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskXrefDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.MergerTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ProcessActionMapBean;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.DelimeterType;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReturnCode;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionUserGroupMap;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionsMap;
import ca.gc.ic.cipo.tm.mts.enums.ReportTypeEnum;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.enums.TransactionCategoryType;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IDuplicateTransaction;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.InboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IAirToExaminationSubmissionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IProcessActionsService;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * This class handles all requests made to the Madrid Transaction Service (MTS).
 */
@Component
public class MadridTransactionServiceImpl extends MadridTransactionService implements MadridTransactionServicePortType {

    private static Logger logger = Logger.getLogger(MadridTransactionService.class.getName());
    
    @Autowired
    private IntlTransactionMgr intlTransactionMgr;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IProcessActionsService processActionsService;

    @Autowired
    private IMadridConsoleService consoleService;

    @Autowired
    private IOutboundTransactionService outboundTransactionService;

    @Autowired
    private InboundTransactionService inboundTransactionService;

    @Autowired
    private ITaskService taskService;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private IAirToExaminationSubmissionService airToExaminationSubmissionService;

    @Autowired
    private IProcessEventService processEventService;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private IDuplicateTransaction duplicateTransation;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    public static ThreadLocal<List<Integer>> LOCKED_FILES = new ThreadLocal<List<Integer>>( );
    
    @Override
    public WorkflowTaskListResponse getWorkflowTaskList(WorkflowTaskListSearchCriteria parameter)
        throws CIPOServiceFault {

        try {
            logger.debug("MTS received request getWorkflowTaskList..............");

            marshallingService.printRequestResponse(parameter);

            WorkflowTaskListResponse intlResponse = taskService.getWorkflowTaskList(parameter);

            marshallingService.printRequestResponse(intlResponse);

            return intlResponse;
        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public TaskDescriptionListResponse getTaskDescriptionList(TaskDescriptionListSearchCriteria taskDescriptionListSearchCriteria)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: getTaskDescriptionList");
            marshallingService.printRequestResponse(taskDescriptionListSearchCriteria);

            TaskDescriptionListResponse intlResponse = taskService
                .getTaskDescriptionList(taskDescriptionListSearchCriteria);

            marshallingService.printRequestResponse(intlResponse);

            return intlResponse;
        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public AutomatedProcessResponse processAutomatedTransaction(AutomaticProcessingCriteria mweAutomaticProcessingCriteria)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: processAutomatedTransaction");
            marshallingService.printRequestResponse(mweAutomaticProcessingCriteria);

            IntlIrTranDto intlIrTran = internationalService
                .getTransactionsByIrTranId(mweAutomaticProcessingCriteria.getTransactionRequest().getIrTranId());

            TransactionCategory transactionCategory = TransactionCategory
                .getTransactionCategoryByValue(intlIrTran.getIntlPkgTranType().getPkgTranCtgryId());

            if (transactionCategory == TransactionCategory.MD_MERGER
                || transactionCategory == TransactionCategory.MDT_MERGER) {

                MergerTransactionDto mergerTransaction = this.isMerger(mweAutomaticProcessingCriteria, intlIrTran,
                    transactionCategory);
                if (null == mergerTransaction.getAutomatedProcessResponse()) {

                    AutomatedProcessResponse response = this
                        .processAutomatedTransactionPair(mergerTransaction.getAutomaticProcessingPairCriteria());
                    marshallingService.printRequestResponse(response);
                    return response;
                }

                AutomatedProcessResponse response = mergerTransaction.getAutomatedProcessResponse();
                marshallingService.printRequestResponse(response);
                return response;

            }

            // **** Automated Transaction - Non Merger //

            AutomatedProcessResponse automatedProcessResponse = new AutomatedProcessResponse();

            AutomatedProcessResponse invalidTransResponse = checkInvalidTransaction(
                mweAutomaticProcessingCriteria.getTransactionRequest());
            if (null != invalidTransResponse) {
                return invalidTransResponse;
            }

            List<ConsoleTaskResponse> checkMarkList = intrepidCommonService
                .checkBeforeAutomatedProcess(mweAutomaticProcessingCriteria.getTransactionRequest().getIrTranId());

            if (CollectionUtils.isEmpty(checkMarkList)) {
            	LOCKED_FILES.remove();
                return intlTransactionMgr
                    .processTransaction(mweAutomaticProcessingCriteria.getTransactionRequest());

            } else {
                internationalService.updateTransactionStatus(
                    mweAutomaticProcessingCriteria.getTransactionRequest().getIrTranId(), StatusType.PROCESSED);
            }

            automatedProcessResponse.getConsoleTaskBag().addAll(checkMarkList);

            marshallingService.printRequestResponse(automatedProcessResponse);

            return automatedProcessResponse;
        } catch (Throwable t) {
            processEventService.insertProcessEvent(mweAutomaticProcessingCriteria.getTransactionRequest().getIrTranId(),
                "E3", t);
            internationalService.updateTransactionStatus(mweAutomaticProcessingCriteria.getTransactionRequest().getIrTranId(), StatusType.PROCESSED_WITH_ERROR);
            List<Integer> lockedFiles = LOCKED_FILES.get();
            if ( lockedFiles != null )
            {
            	intrepidCommonService.unlockApplicationForTasks(lockedFiles);
            }

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    private MergerTransactionDto isMerger(AutomaticProcessingCriteria mweAutomaticProcessingCriteria,
                                          IntlIrTranDto intlIrTran, TransactionCategory transactionCategoryIn)
        throws CIPOServiceFault {

        TransactionPairDto transactionDesignationDto = new TransactionPairDto();
        TransactionPairDto transactionTerminationDto = new TransactionPairDto();
        Map<ApplicationDto, UserTaskType> notificationMap = new HashMap<>();
        boolean pairFound = false;

        logger.debug("Madrid Designation Merger found. Look for corresponding Termination transaction.");

        TransactionCriteria searchCriteria = new TransactionCriteria();
        List<TransactionStatusType> statusCodeList = new ArrayList<>();
        List<TransactionType> transactionTypeCodeList = new ArrayList<>();

        String strippedIRNumber = null;
        Integer irNumberMdt = null;

        if (transactionCategoryIn == TransactionCategory.MD_MERGER) {
            transactionTypeCodeList.add(TransactionType.MDT_MERGER);
            strippedIRNumber = intlIrTran.getIntlRegNo();
            transactionDesignationDto.setMadridDesignationTransaction(intlIrTran);
        } else {
            transactionTypeCodeList.add(TransactionType.MD_MERGER);

            strippedIRNumber = intlIrTran.getIntlRegNo().substring(0, intlIrTran.getIntlRegNo().length() - 1);
            try {
                irNumberMdt = Integer.valueOf(strippedIRNumber);
            } catch (Exception e) {
                irNumberMdt = 0;
                logger.error("Invalid ir number for merger: " + intlIrTran.getIntlRegNo());

            }
            transactionTerminationDto
                .setPairedTransaction(internationalService.getTransactionsByIrTranId(intlIrTran.getIrTranId()));
            transactionTerminationDto.setPairedTransactionType(TransactionCategory.MDT_MERGER);
        }

        statusCodeList.add(TransactionStatusType.MPS_IMPORT_COMPLETE);
        statusCodeList.add(TransactionStatusType.PARTIALLY_PROCESSED);
        searchCriteria.getTransactionTypeCodeList().addAll(transactionTypeCodeList);

        List<TransactionDetail> results = internationalService.getTransactionList(searchCriteria);

        for (TransactionDetail detail : results) {
            String irNumber = detail.getIntlRegistrationNumber();

            if (irNumber.contains(strippedIRNumber)) {

                if (detail.getTransactionType().getCategory().equals(TransactionCategory.MDT_MERGER.name())) {
                    try {
                        irNumberMdt = Integer.valueOf(irNumber.substring(0, irNumber.length() - 1));
                    } catch (Exception e) {
                        irNumberMdt = 0;
                        logger.error("Invalid ir number for merger: " + irNumber);

                    }
                }
                if (detail.getCurrentStatus().getCategory().equals(StatusType.MPS_IMPORT_COMPLETE.name())
                    || detail.getCurrentStatus().getCategory().equals(StatusType.PARTIALLY_PROCESSED.name())) {

                    if (irNumberMdt.intValue() == Integer.valueOf(strippedIRNumber).intValue()) {

                        // must be in the same package.
                        if (intlIrTran.getIntlPkg().getPkgId().intValue() == detail.getPackageId().intValue()) {
                            logger.debug("Found Merger Termination transaction. TranId <" + intlIrTran.getIrTranId()
                                + ">. Paired tranId <" + detail.getTransactionId() + ">");

                            if (detail.getTransactionType().getCategory()
                                .equals(TransactionCategory.MDT_MERGER.name())) {
                                transactionTerminationDto.setPairedTransaction(
                                    internationalService.getTransactionsByIrTranId(detail.getTransactionId()));
                                transactionTerminationDto.setPairedTransactionType(TransactionCategory.MDT_MERGER);

                            } else {
                                IntlIrTranDto mdTrans = internationalService
                                    .getTransactionsByIrTranId(detail.getTransactionId());
                                transactionDesignationDto.setMadridDesignationTransaction(mdTrans);

                                if (!mdTrans.getStatusTypeDto().getStatusCtgry()
                                    .equals(StatusType.MPS_IMPORT_COMPLETE.name())
                                    && !mdTrans.getStatusTypeDto().getStatusCtgry()
                                        .equals(StatusType.PARTIALLY_PROCESSED.name())) {
                                    continue;
                                }
                            }

                            pairFound = true;
                            break;
                        }
                    }
                } else if (detail.getCurrentStatus().getCategory().equals(StatusType.PROCESSED.name())) {
                    logger.debug("Found Merger Termination transaction <" + intlIrTran.getIrTranId()
                        + ">. However its paried transaction <" + detail.getTransactionId()
                        + "> is already processed.");

                    return createMergerNotification(notificationMap, intlIrTran.getIrTranId(),
                        intlIrTran.getIntlRegNo(), true);

                }
            }
        }

        if (pairFound) {

            AutomaticProcessingPairCriteria mweAutomaticProcessingPairCriteria = new AutomaticProcessingPairCriteria();
            TransactionPairRequest pairRequest = new TransactionPairRequest();
            pairRequest.setIrTranId(transactionTerminationDto.getPairedTransaction().getIrTranId());
            pairRequest
                .setAssociatedIrTranId(transactionDesignationDto.getMadridDesignationTransaction().getIrTranId());

            mweAutomaticProcessingPairCriteria.setTransactionMeta(pairRequest);
            MergerTransactionDto mergerTransactionDto = new MergerTransactionDto();
            mergerTransactionDto.setAutomaticProcessingPairCriteria(mweAutomaticProcessingPairCriteria);
            return mergerTransactionDto;

        } else {
            logger.debug("Unable to find Merger Termination transaction.");

            return createMergerNotification(notificationMap, intlIrTran.getIrTranId(), intlIrTran.getIntlRegNo(),
                false);
        }
    }

    private MergerTransactionDto createMergerNotification(Map<ApplicationDto, UserTaskType> notificationTypes,
                                                          BigDecimal irTranId, String intlRegNo,
                                                          boolean isMergeCompleted) {
        // create notification
        AutomatedProcessResponse automatedProcessResponse = new AutomatedProcessResponse();
        MergerTransactionDto mergerTransactionDto = new MergerTransactionDto();
        if (!isMergeCompleted) {
            ApplicationDto applicationDto = new ApplicationDto();
            applicationDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
            applicationDto.setOfficeType(OfficeType.DO.name());
            applicationDto.setIrNumber(intlRegNo);
            notificationTypes.put(applicationDto, UserTaskType.MERGER_INCOMPLETE_PAIR);
        }
        List<ConsoleTaskResponse> consoleTaskResults = taskService.getUserTaskInformation(irTranId, notificationTypes);
        automatedProcessResponse.getConsoleTaskBag().addAll(consoleTaskResults);

        mergerTransactionDto.setAutomatedProcessResponse(automatedProcessResponse);

        return mergerTransactionDto;
    }

    private AutomatedProcessResponse checkInvalidTransaction(TransactionRequest transaction) {

        IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(transaction.getIrTranId());

        TransactionCategory transactionCategory = TransactionCategory
            .getTransactionCategoryByValue(intlIrTran.getIntlPkgTranType().getPkgTranCtgryId());

        if (transactionCategory == TransactionCategory.INVALID_TRANSACTION_TYPE) {
            Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
            UserTaskType userTask = UserTaskType.UNSUPPORTED_TRANSACTION_TYPE_TASK;

            internationalService.updateTransactionStatus(intlIrTran.getIrTranId(), StatusType.PROCESSED);

            // Record Applications with the same IR Number
            statusTypeResults.put(intrepidDTOFactory.getApplicationDto(intlIrTran.getIntlRegNo(), OfficeType.DO),
                userTask);

            List<ConsoleTaskResponse> consoleTaskResults = taskService.getUserTaskInformation(intlIrTran.getIrTranId(),
                statusTypeResults);
            AutomatedProcessResponse processTransactionResponse = new AutomatedProcessResponse();
            processTransactionResponse.getConsoleTaskBag().addAll(consoleTaskResults);
            return processTransactionResponse;
        }
        return null;
    }

    private AutomatedProcessResponse processAutomatedTransactionPair(AutomaticProcessingPairCriteria mweAutomaticProcessingCriteria)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: processAutomatedTransactionPair");

            marshallingService.printRequestResponse(mweAutomaticProcessingCriteria);

            IntlIrTranDto transaction = internationalService
                .getTransactionsByIrTranId(mweAutomaticProcessingCriteria.getTransactionMeta().getIrTranId());
            TransactionCategory transactionCategory = TransactionCategory
                .getTransactionCategoryByValue(transaction.getIntlPkgTranType().getPkgTranCtgryId());

            TransactionCategoryType transactionCategorytype = internationalDTOFactory
                .getPairedTransactionType(transactionCategory);

            if (null == transactionCategory || null == transactionCategorytype) {
                ServiceFaultDetails serviceFaultDetails = this.setServiceDetails("mts.invalid.transaction.category",
                    ExceptionReasonCode.SYSTEM_ERROR, ExceptionReturnCode.FATAL);
                throw new MTSServiceFault("Service Fault - processAutomatedTransactionPair: ", serviceFaultDetails);
            }
            // Check that marks exist in intrepid.
            List<ConsoleTaskResponse> parentMarkList = intrepidCommonService
                .checkforExistingMarks(mweAutomaticProcessingCriteria.getTransactionMeta().getIrTranId());

            if (CollectionUtils.isEmpty(parentMarkList)) {

                if (transactionCategorytype == TransactionCategoryType.PROCESS_IR_OWNERSHIP_CHANGE_MERGER) {
                	LOCKED_FILES.remove();
                    return intlTransactionMgr
                        .processOwnershipChangeMerger(mweAutomaticProcessingCriteria.getTransactionMeta());
                } else {
                    ServiceFaultDetails serviceFaultDetails = this.setServiceDetails("mts.invalid.transaction.category",
                        ExceptionReasonCode.SYSTEM_ERROR, ExceptionReturnCode.FATAL);
                    throw new MTSServiceFault("Service Fault - processAutomatedTransactionPair: ", serviceFaultDetails);
                }
            } else {
                internationalService.updateTransactionStatus(
                    mweAutomaticProcessingCriteria.getTransactionMeta().getIrTranId(), StatusType.PROCESSED);
                internationalService.updateTransactionStatus(
                    mweAutomaticProcessingCriteria.getTransactionMeta().getAssociatedIrTranId(), StatusType.PROCESSED);
            }
            AutomatedProcessResponse automatedProcessResponse = new AutomatedProcessResponse();
            automatedProcessResponse.getConsoleTaskBag().addAll(parentMarkList);

            logger.debug("processAutomatedTransactionPair Response");

            marshallingService.printRequestResponse(automatedProcessResponse);

            return automatedProcessResponse;

        } catch (Throwable t) {

            processEventService.insertProcessEvent(mweAutomaticProcessingCriteria.getTransactionMeta().getIrTranId(),
                "E3", t);
        	internationalService.updateTransactionStatus(mweAutomaticProcessingCriteria.getTransactionMeta().getIrTranId(), StatusType.PROCESSED_WITH_ERROR);

            List<Integer> lockedFiles = LOCKED_FILES.get();
            if ( lockedFiles != null )
            {
            	intrepidCommonService.unlockApplicationForTasks(lockedFiles);
            }
            
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public ManualProcessResponse processManualTransaction(ManualProcessingCriteria mweManualProcessingCriteria)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: processManualTransaction");

            marshallingService.printRequestResponse(mweManualProcessingCriteria);

            LOCKED_FILES.remove();
            ManualProcessResponse response = intlTransactionMgr
                .processManualTransaction(mweManualProcessingCriteria.getTransactionRequest());

            marshallingService.printRequestResponse(response);

            return response;

        } catch (Throwable t) {

            processEventService.insertProcessEvent(mweManualProcessingCriteria.getTransactionRequest().getIrTranId(),
                "E3", t);
        	internationalService.updateTransactionStatus(mweManualProcessingCriteria.getTransactionRequest().getIrTranId(), StatusType.PROCESSED_WITH_ERROR);

            List<Integer> lockedFiles = LOCKED_FILES.get();
            if ( lockedFiles != null )
            {
            	intrepidCommonService.unlockApplicationForTasks(lockedFiles);
            }
        	
            // Error logging is taken care of in the "handleExceptions()" method
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public GoodsAndServicesChangesResponse processGoodsAndServicesChanges(GoodsAndServiceMeta parameter)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: processGoodsAndServicesChanges");
            marshallingService.printRequestResponse(parameter);

            GoodsAndServicesChangesResponse response = consoleService.processGoodsAndServicesChanges(parameter, null);

            marshallingService.printRequestResponse(response);

            return response;

        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public List<TransactionDetail> getTransactionList(TransactionCriteria searchCriteria) throws CIPOServiceFault {

        try {
            logger.debug("Operation: getTransactionList");
            marshallingService.printRequestResponse(searchCriteria);

            List<TransactionDetail> transactionList = internationalService.getTransactionList(searchCriteria);
            if (CollectionUtils.isNotEmpty(transactionList)) {
                logger.debug("Total transactions returned: " + transactionList.size());
            } else {
                logger.debug("Total transactions returned: 0");
            }

            return transactionList;

        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public ExistingMarkResponse checkExistingMark(ExistingMarkRequest parameter) throws CIPOServiceFault {

        try {
            logger.debug("Operation: checkExistingMark");
            marshallingService.printRequestResponse(parameter);

            ExistingMarkResponse checkExistingMarkResponse = new ExistingMarkResponse();
            List<ConsoleTaskResponse> markExistList = intrepidCommonService
                .checkforExistingMarks(parameter.getIrTranId());

            if (CollectionUtils.isEmpty(markExistList)) {
                checkExistingMarkResponse.setMarkExists(true);
            } else {
                checkExistingMarkResponse.setMarkExists(false);
                for (ConsoleTaskResponse consoleTask : markExistList) {
                    checkExistingMarkResponse.getConsoleTaskIds().add(consoleTask.getConsoleTaskId());
                }
                internationalService.updateTransactionStatus(parameter.getIrTranId(), StatusType.PROCESSED);
            }
            marshallingService.printRequestResponse(checkExistingMarkResponse);
            return checkExistingMarkResponse;

        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public HeartbeatResponseType getHeartbeat() throws CIPOServiceFault {
        HeartbeatResponseType response = new HeartbeatResponseType();
        String status = MtsStringUtil.EMPTY;
        String ipAddress = MtsStringUtil.EMPTY;
        String nodeName = MtsStringUtil.EMPTY;

        try {
            ipAddress = InetAddress.getLocalHost().getHostAddress();
            nodeName = InetAddress.getLocalHost().getHostName();
            status = "online";
        } catch (UnknownHostException e) {
            logger.error("Error getting the Heartbeat status", e);
            ServiceFaultDetails details = new ServiceFaultDetails();

            details.setComponentAcronym("MTS");
            details.setEnErrorMsg("Error getting the Heartbeat status.");
            details.setFrErrorMsg("Erreur, l'obtention du statut pour le service n'est pas disponible.");
            details.setReasonCode(1);
            details.setReturnCode(-99);
            details.setServiceName("Madrid Transaction Service ");
            details.setStackTrace(Arrays.toString(e.getStackTrace()));

            throw new CIPOServiceFault("Error getting the Heartbeat status", details);
        }

        response.setIpAddress(ipAddress);
        response.setNodeName(nodeName);
        response.setStatus(status);

        logger.trace("Successfully processed JAX-WS getHeartbeat call with IP: " + ipAddress + ", Node name: "
            + nodeName + " and Status: " + status);

        return response;

    }

    @Override
    public OfficeToIbProcessActions getOfficeToIbProcessActions(ProcessActionCategoryType processActionType)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: getOfficeToIbProcessActions");
            marshallingService.printRequestResponse(processActionType);
            ProcessActionList result = processActionsService.getProcessActionList(processActionType);

            OfficeToIbProcessActions intrepidProcessActions = new OfficeToIbProcessActions();
            intrepidProcessActions.setProcessActionList(result);

            return intrepidProcessActions;
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void updateConsoleTaskReference(String taskReferenceId, BigDecimal consoleTaskId) throws CIPOServiceFault {

        try {
            logger.debug(
                "updateConsoleTaskReference: taskReferenceId:" + taskReferenceId + ", consoleTaskId:" + consoleTaskId);

            taskService.updateConsoleTaskReference(taskReferenceId, consoleTaskId);
        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType consoleTaskStatus)
        throws CIPOServiceFault {

        try {
            logger.debug("updateConsoleTaskStatus: consoleTaskId:" + consoleTaskId + ", consoleTaskSatus:"
                + consoleTaskStatus.name());
            if (!isTaskProcessed(consoleTaskId)) {
                taskService.updateConsoleTaskStatus(consoleTaskId, consoleTaskStatus);
            }
        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void updateMailProcessedStatus(BigDecimal fileNumber, String processedByAuthorityId,
                                          MailTransactionType mailTransactionType)
        throws CIPOServiceFault {

        logger.debug(
            "updateMailProcessedStatus: fileNumber:" + fileNumber + ", mailTransactionType:" + mailTransactionType);

        try {
            MailType mailType = mailTransactionType != null ? MailType.valueOf(mailTransactionType.name()) : null;
            intrepidCommonService.updateMailProcessedStatus(fileNumber, mailType, processedByAuthorityId);

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }

        return;
    }

    private boolean isTaskProcessed(BigDecimal consoleTaskId) {
        IntlIrTaskDto task = taskService.getIrTaskById(consoleTaskId);
        if (task.getTaskStatusTypeDto().equals(TaskStatusType.CLOSED_UNPROCESSED)
            || task.getTaskStatusTypeDto().equals(TaskStatusType.PROCESSED)) {
            return true;
        }
        return false;
    }

    @Override
    public OfficeToIbTransactionResponse createOfficeToIbTransaction(ProcessActionsMeta processActionsMeta)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: createOfficeToIbTransaction");
            marshallingService.printRequestResponse(processActionsMeta);

            boolean manualTask = false;
            if (!isValidProcessAction(manualTask, processActionsMeta)) {
                logger.error("Invalid process action.");
                ServiceFaultDetails serviceFaultDetails = this.setServiceDetails("mts.invalid.process.action",
                    ExceptionReasonCode.INVALID_PROCESS_ACTION, ExceptionReturnCode.RECOVERABLE);
                throw new MTSServiceFault("Service Fault - createOfficeToIbTransaction: ", serviceFaultDetails);
            }
            ProcessActionMapBean processActionMapBean = ProcessActionsMap.allProcessActionCodesMap
                .get(Integer.valueOf(processActionsMeta.getProcessCode()));

            if (processActionMapBean.getProcessActionCodeType() == ProcessActionCodeType.REACTIVATE_TASKS) {

                return reactivateTasks(processActionsMeta);

            }

            // Get the Application information from intrepid using TIRS
            OutboundTransactionDto outboundTransactionDto = intrepidCommonService
                .getMadridApplicationDetails(processActionsMeta);

            if (!outboundTransactionDto.isRegisteredApplication()) {
                logger.debug("Process action is not yet registered. Will ignore!");
                return new OfficeToIbTransactionResponse();
            }
            // Get the Opposition Decision, Statement of Opposition, or Examiners Report as required.

            OfficeToIbTransactionResponse officeToIbTransactionResponse = outboundTransactionService
                .createAutoOutboundTransaction(processActionsMeta, outboundTransactionDto);

            marshallingService.printRequestResponse(officeToIbTransactionResponse);

            return officeToIbTransactionResponse;

        } catch (Throwable t) {

            intrepidCommonService.setErrorProcessAction(processActionsMeta);

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    private OfficeToIbTransactionResponse reactivateTasks(ProcessActionsMeta processActionsMeta)
        throws MTSServiceFault {

        // call service which will update all tasks from Hold to Unprocessed for provided File Number, IR
        // Number.
        StringBuilder debugText = new StringBuilder();
        debugText.append("Request to reactivate tasks for fileNumber: ").append(processActionsMeta.getFileNumber());

        logger.debug(debugText.toString());

        ApplicationDto applicationDto = intrepidCommonService
            .getApplication(processActionsMeta.getFileNumber().intValue());

        if (!ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
            .isActiveStatus(TradeMarkStatusType.getByValue(applicationDto.getStatusCode()))) {

            ServiceFaultDetails serviceFaultDetails = this.setServiceDetails("mts.inactive.application",
                ExceptionReasonCode.SYSTEM_ERROR, ExceptionReturnCode.RECOVERABLE);
            throw new MTSServiceFault("Service Fault - reactivateTasks: ", serviceFaultDetails);

        }
        taskService.reactivateTasks(processActionsMeta.getFileNumber());

        // Add an action record if applicable and delete process action
        intrepidCommonService.completeProcessAction(processActionsMeta);

        return new OfficeToIbTransactionResponse();
    }

    private OfficeToIbTransactionResponse createManualOutboundTransaction(ProcessActionsMeta processActionsMeta)
        throws CIPOServiceFault {

        // Get the Application information from intrepid using TIRS
        OutboundTransactionDto outboundTransactionDto = intrepidCommonService
            .getMadridApplicationDetails(processActionsMeta);

        if (!outboundTransactionDto.isRegisteredApplication()) {
            return new OfficeToIbTransactionResponse();
        }
        // Get the Opposition Decision, Statement of Opposition, or Examiners Report as required.

        OfficeToIbTransactionResponse officeToIbTransactionResponse = outboundTransactionService
            .createManualOutboundTransaction(processActionsMeta, outboundTransactionDto);

        // Set IR Number for OO process actions requiring a manual task
        if (processActionsMeta.getProcessActionCodeType() == ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9
            || processActionsMeta
                .getProcessActionCodeType() == ProcessActionCodeType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL
            || processActionsMeta
                .getProcessActionCodeType() == ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_DIVISION
            || processActionsMeta
                .getProcessActionCodeType() == ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER
            || processActionsMeta
                .getProcessActionCodeType() == ProcessActionCodeType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT) {

            processActionsMeta.setIrNumber(outboundTransactionDto.getIntlRegNo());

        }

        // Assign to appropriate user group, if not previously assigned.
        if (StringUtils.isBlank(officeToIbTransactionResponse.getGroupId())) {
            // Assign to appropriate user group.
            String authority = intrepidCommonService.getSectionAuthorityId(processActionsMeta.getAuthorityId());
            if (SectionAuthority.OPPS45.name().equalsIgnoreCase(authority)) {
                officeToIbTransactionResponse.setGroupId(SectionAuthority.MC_TMOB_OPERATOR.name());
            } else if (SectionAuthority.EXAMINATION.name().equalsIgnoreCase(authority)) {
                officeToIbTransactionResponse.setGroupId(SectionAuthority.MC_TM_EXAMINER.name());
            } else if (ProcessActionUserGroupMap.processActionUserGroupMap
                .containsKey(processActionsMeta.getProcessActionCodeType())) {
                officeToIbTransactionResponse.setGroupId(ProcessActionUserGroupMap.processActionUserGroupMap
                    .get(processActionsMeta.getProcessActionCodeType()));
            }
        }

        return officeToIbTransactionResponse;

    }

    @Override
    public ManualProcessResponse createOfficeToIbManualTask(ProcessActionsMeta processActionsMeta)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: createOfficeToIbManualTask");
            marshallingService.printRequestResponse(processActionsMeta);

            boolean manualTask = true;
            BigDecimal irTranId = null;

            if (!isValidProcessAction(manualTask, processActionsMeta)) {
                ServiceFaultDetails serviceFaultDetails = this.setServiceDetails("mts.invalid.process.action",
                    ExceptionReasonCode.INVALID_PROCESS_ACTION, ExceptionReturnCode.RECOVERABLE);
                throw new MTSServiceFault("Service Fault - createOfficeToIbManualTask: ", serviceFaultDetails);
            }

            // Get process action persistence before it get deleted from the database.
            Integer oppCaseNum = null;
            if (processActionsMeta != null && (processActionsMeta.getProcessActionId() != null)) {
                ProcessAction processAction = processActionsService
                    .getById(processActionsMeta.getProcessActionId().intValue());
                if (processAction != null) {
                    oppCaseNum = processAction.getOppositionCaseNumber();
                }
            }

            // Create manual task
            if (ProcessActionsMap.manualProcessActionCodesMap.containsKey(processActionsMeta.getProcessCode())) {

                OfficeToIbTransactionResponse response = createManualOutboundTransaction(processActionsMeta);
                if (StringUtils.isNotBlank(response.getGroupId())) {
                    processActionsMeta.setAuthorityId(response.getGroupId());
                }

                irTranId = response.getIrTranId();
            } else {
                intrepidCommonService.completeProcessAction(processActionsMeta);
            }

            // set specific user group for required ProcessActionCodeType
            if (ProcessActionsMap.notificationProcessActionCodesMap.containsKey(processActionsMeta.getProcessCode())) {
                // set specific user group for required ProcessActionCodeType
                if (processActionsMeta
                    .getProcessActionCodeType() == ProcessActionCodeType.MADRID_REVIEW_CORESPONDENCE_MANUAL) {

                    processActionsMeta
                        .setAuthorityId(intrepidCommonService.checkOppositionCase(processActionsMeta.getFileNumber()));

                } else {
                    // assign to MC_TM_SUPERVISOR - confirmed with John
                    processActionsMeta.setAuthorityId(ProcessActionUserGroupMap.processActionUserGroupMap
                        .get(processActionsMeta.getProcessActionCodeType()));
                }
            }

            if (ProcessActionsMap.manualProcessActionCodesMap.containsKey(processActionsMeta.getProcessCode())) {
                if (irTranId != null) {
                    // This creates a console task when irTranId is not null and also manualProcessAction.
                    ManualProcessResponse response = outboundTransactionService.createConsoleTask(processActionsMeta,
                        irTranId, oppCaseNum);

                    marshallingService.printRequestResponse(response);

                    return response;

                } else {
                    return new ManualProcessResponse();
                }
            } else {
                // This creates a console task when irTranId is null with manual notification process action.
                ManualProcessResponse response = outboundTransactionService.createConsoleTask(processActionsMeta,
                    irTranId, oppCaseNum);

                marshallingService.printRequestResponse(response);

                return response;
            }

        } catch (Throwable t) {
            // Error logging is taken care of in the "handleExceptions()" method
            logger.error("Error creating manual outbound transacion! ");

            intrepidCommonService.setErrorProcessAction(processActionsMeta);

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    private boolean isValidProcessAction(boolean manual, ProcessActionsMeta processActionMeta) {

        if (manual) { // Manual process actions
            ProcessActionMapBean processActionMapBean = null;
            if (ProcessActionsMap.manualProcessActionCodesMap
                .containsKey(Integer.valueOf(processActionMeta.getProcessCode()))) {

                processActionMapBean = ProcessActionsMap.manualProcessActionCodesMap
                    .get(Integer.valueOf(processActionMeta.getProcessCode()));

            } else if (ProcessActionsMap.notificationProcessActionCodesMap
                .containsKey(Integer.valueOf(processActionMeta.getProcessCode()))) {

                processActionMapBean = ProcessActionsMap.notificationProcessActionCodesMap
                    .get(Integer.valueOf(processActionMeta.getProcessCode()));
            }

            if (null != processActionMapBean && processActionMapBean.getProcessActionCodeType().value()
                .equalsIgnoreCase(processActionMeta.getProcessActionCodeType().value())) {
                return true;
            }

        } else { // automated process actions
            ProcessActionMapBean processActionMapBean = null;
            if (ProcessActionsMap.automatedProcessActionCodesMap
                .containsKey(Integer.valueOf(processActionMeta.getProcessCode()))) {

                processActionMapBean = ProcessActionsMap.automatedProcessActionCodesMap
                    .get(Integer.valueOf(processActionMeta.getProcessCode()));

                if (null != processActionMapBean && processActionMapBean.getProcessActionCodeType() == processActionMeta
                    .getProcessActionCodeType()) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public TransactionDetail getTransaction(BigDecimal transactionId, boolean includeXmlContent,
                                            boolean includeAttachmentContent)
        throws CIPOServiceFault {

        try {
            return internationalService.getTransaction(transactionId, includeXmlContent, includeAttachmentContent);
        } catch (Throwable t) {
            // Error logging is taken care of in the "handleExceptions()" method
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public GetTransactionByIntlRecordIdResponse getTransactionByIntlRecordId(GetTransactionByIntlRecordIdRequest parameters)
        throws CIPOServiceFault {

        logger.debug("Operation: getTransactionByIntlRecordId");

        try {
            marshallingService.printRequestResponse(parameters);

            GetTransactionByIntlRecordIdResponse response = new GetTransactionByIntlRecordIdResponse();

            TransactionDetail tranDetail = internationalService.getTransactionByIntlRecordId(
                parameters.getRecordIdentifier(), parameters.getIrNumber(),
                parameters.isCorrectionTypeTransactionOnly(), parameters.isIncludeXmlContent(),
                parameters.isIncludeAttachmentContent());

            if (tranDetail != null) {
                response.setTransactionDetail(tranDetail);
            }
            marshallingService.printRequestResponse(response);
            return response;

        } catch (Throwable t) {
            // Error logging is taken care of in the "handleExceptions()" method
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public AttachmentDetail getTransactionAttachment(BigDecimal attachmentId) throws CIPOServiceFault {
        try {
            return internationalService.getTransactionAttachment(attachmentId);
        } catch (Throwable t) {
            // Error logging is taken care of in the "handleExceptions()" method
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void storeAirToExaminationSubmissionInfo(AirToExaminationRequest request) throws CIPOServiceFault {

        try {
            logger.debug("Operation: storeAirToExaminationSubmissionInfo");

            marshallingService.printRequestResponse(request);

            airToExaminationSubmissionService.storeAirToExaminationSubmissionInfo(request);
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void processManualReport(ProcessManualReportRequest manualReportRequest) throws CIPOServiceFault {
        try {
            logger.debug("processManualReport");
            marshallingService.printRequestResponse(manualReportRequest);

            if (manualReportRequest.getReportTypeCode().equals(ReportTypeEnum.MF_3_A.value())
                || manualReportRequest.getReportTypeCode().equals(ReportTypeEnum.MF_9.value())
                || manualReportRequest.getReportTypeCode().equals(ReportTypeEnum.MF_13.value())) {

                consoleService.processManualReport(manualReportRequest);

            } else {
                logger.error("Called processManualReport for invalid report type"); // debugging
                throwMTSServiceFault("mts.system.error", ExceptionReasonCode.RETRYABLE_ERROR);
            }

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public ProcessManualReportRequest getManualReport(GetManualReportRequest parameter) throws CIPOServiceFault {
        try {
            logger.debug("Operation: getManualReport");

            marshallingService.printRequestResponse(parameter);

            ProcessManualReportRequest response = consoleService.getManualReport(parameter);

            marshallingService.printRequestResponse(response);

            return response;
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void processIrregularitySubmission(ProcessIrregularitySubmissionRequest irregularitySubmission)
        throws CIPOServiceFault {

        try {
            logger.debug("processIrregularitySubmission");
            marshallingService.printRequestResponse(irregularitySubmission);

            consoleService.processIrregularitySubmission(irregularitySubmission);
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public GoodsAndServicesChangesResponse processPartialOwnership(BigDecimal taskId, String notificationLanguage,
                                                                   PartialOwnershipMeta designation,
                                                                   PartialOwnershipMeta restriction)
        throws CIPOServiceFault {

        try {

            logger.debug("Operation: processPartialOwnership");
            logger.debug("taskId: " + taskId.intValue() + ", notificationLanguage: " + notificationLanguage);
            marshallingService.printRequestResponse(designation);
            marshallingService.printRequestResponse(restriction);

            GoodsAndServicesChangesResponse response = consoleService.processPartialOwnershipRequest(taskId,
                notificationLanguage, designation, restriction);

            marshallingService.printRequestResponse(response);

            return response;

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public List<ConsoleTaskResponse> checkForNotifications(CheckForNotificationsRequest request)
        throws CIPOServiceFault {

        try {
            logger.debug("Operation: checkForNotifications");
            marshallingService.printRequestResponse(request);

            List<ConsoleTaskResponse> response = null;

            IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(request.getIrTranId());
            Object transaction = unmarshallTransaction(intlIrTran);

            logger.info("Checking notifications and generate notification tasks for IR TranId <" + request.getIrTranId()
                + ">. Transaction type <" + transaction.getClass().getCanonicalName() + ">. NotificationStatusType <"
                + request.getNotificationStatusType() + ">");
            if (transaction instanceof MadridPartialChangeOwnershipType) {
                IntlIrTaskXrefDto irTask = null;
                List<IntlIrTaskXrefDto> taskList = intlIrTran.getIntlIrTaskXrefDtoList();
                for (IntlIrTaskXrefDto irTaskDto : taskList) {
                    if (irTaskDto.getIntlIrTaskDto().getTaskTypeDto().getTaskCtgryId()
                        .equals(UserTaskType.PARTIAL_OWNERSHIP_CHANGE_DESIGNATION_RESTRICTION.toNumber())) {
                        irTask = irTaskDto;
                        break;
                    }

                }

                Integer originalFileNumber = irTask.getIntlIrTaskDto().getFileNumber();

                String taskAdditionalInfo = null;
                if (CollectionUtils.isNotEmpty(irTask.getIntlIrTaskDto().getIntlTaskAddtnlInfoDto())) {
                    for (IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto : irTask.getIntlIrTaskDto()
                        .getIntlTaskAddtnlInfoDto()) {
                        if (intlTaskAddtnlInfoDto.getIntlTaskAddtnlInfoTypeDto().getTaskAddtnlInfoCtgryId()
                            .intValue() == TaskAddtnlInfoType.PARTIAL_OWNERSHIP_CHANGE_NEW_FILE_NUM.getValue()) {
                            taskAdditionalInfo = intlTaskAddtnlInfoDto.getAddtnlInfo();
                            break;

                        }

                    }
                }

                String newApplicationFileNumber = taskAdditionalInfo
                    .replace(DelimeterType.PARTIAL_OWNERSHIP_NEW_MARK_ID.getDelimeter(), MtsStringUtil.EMPTY);

                response = intrepidCommonService.checkForPartialOwnershipChangeNotifications(request,
                    originalFileNumber, Integer.valueOf(newApplicationFileNumber));
            } else if (transaction instanceof MadridProtectionRestrictionType) {
                List<IntlIrTaskXrefDto> taskList = intlIrTran.getIntlIrTaskXrefDtoList();
                for (IntlIrTaskXrefDto irTask : taskList) {
                    MadridProtectionRestrictionType madridProtectionRestriction = (MadridProtectionRestrictionType) transaction;

                    UserTaskType userTaskType;
                    switch (madridProtectionRestriction.getMadridProtectionRestrictionCategory()) {
                        case PARTIAL_CANCELLATION:
                        case LIMITATION:
                            userTaskType = UserTaskType.IR_TOTAL_CANCELLATION;
                            break;
                        case PARTIAL_CEASING_OF_EFFECT:
                            userTaskType = UserTaskType.TOTAL_CEASING_OF_EFFECT_DO;
                            break;
                        default:
                            userTaskType = UserTaskType.UNSUPPORTED_TRANSACTION_TYPE_TASK;
                            break;

                    }
                    Integer fileNumber = irTask.getIntlIrTaskDto().getFileNumber();
                    response = intrepidCommonService.checkForNotifications(request, fileNumber, intlIrTran, transaction,
                        userTaskType);
                    break;
                }
            }
            marshallingService.printRequestResponse(response);
            return response;

        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public DuplicateIrregularResponse duplicateIrregularTransaction(BigDecimal irTranId, String authorityId)
        throws CIPOServiceFault {
        try {
            logger.debug("Operation: duplicateIrregularTransaction");
            logger.debug("irTranId: " + irTranId.intValue() + ", authorityId: " + authorityId);

            DuplicateIrregularResponse response = duplicateTransation.duplicateIrregularTransaction(irTranId,
                authorityId);
            marshallingService.printRequestResponse(response);

            return response;

        } catch (Throwable t) {

            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public void processIRCorrectionSubmission(ProcessIRCorrectionSubmissionRequest request) throws CIPOServiceFault {
        try {
            logger.debug("Operation: processIRCorrectionSubmission");
            marshallingService.printRequestResponse(request);

            consoleService.processIRCorrectionSubmission(request);
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public ResponseDueDateResponse getResponseDueDate(ResponseDueDateRequest parameters) throws CIPOServiceFault {
        try {
            logger.debug("Operation: getResponseDueDate");
            marshallingService.printRequestResponse(parameters);

            ResponseDueDateResponse response = inboundTransactionService
                .getResponseDueDate(parameters.getTransactionId());

            marshallingService.printRequestResponse(response);

            return response;

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public TransactionListForHolderDetailsResponse getTransactionListForHolderDetails(TransactionListForHolderDetailsRequest parameters)
        throws CIPOServiceFault {
        try {

            logger.debug("Operation: getTransactionListForHolderDetails");
            marshallingService.printRequestResponse(parameters);

            List<IntlIrTaskXrefDto> trans_task_ids = internationalService.getTransactionListForHolderDetails();
            TransactionListForHolderDetailsResponse response = new TransactionListForHolderDetailsResponse();
            for (IntlIrTaskXrefDto taskXrefDto : trans_task_ids) {
                TransactionTaskIds transactionTaskIds = new TransactionTaskIds();
                transactionTaskIds.setTransactionId(taskXrefDto.getIrTranId());
                transactionTaskIds.setTaskId(taskXrefDto.getIntlIrTaskDto().getTaskId());
                response.getTransactionTaskIds().add(transactionTaskIds);
            }

            return response;
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public UpdateHolderContactDetailsResponse updateHolderContactDetails(UpdateHolderContactDetailsRequest request)
        throws CIPOServiceFault {
        try {

            logger.debug("Operation: updateHolderContactDetails");
            marshallingService.printRequestResponse(request);

            UpdateHolderContactDetailsResponse response = intrepidCommonService.updateHolderContactDetails(
                request.getTransactionTaskIds().getTransactionId(), request.getTransactionTaskIds().getTaskId());

            marshallingService.printRequestResponse(response);

            return response;

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
    }

    @Override
    public AcquireTrademarkLockResponse acquireTrademarkLock(AcquireTrademarkLockRequest parameters)
        throws CIPOServiceFault {
        AcquireTrademarkLockResponse response = new AcquireTrademarkLockResponse();
        try {
            logger.debug("Operation: acquireTrademarkLock");
            marshallingService.printRequestResponse(parameters);

            intrepidCommonService.acquireTrademarkLock(parameters.getFileNumber().intValue(),
                parameters.getExtensionCounter().intValue(), parameters.getUserName());
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
        return response;
    }

    @Override
    public ReleaseTrademarkLockResponse releaseTrademarkLock(ReleaseTrademarkLockRequest parameters)
        throws CIPOServiceFault {
        ReleaseTrademarkLockResponse response = new ReleaseTrademarkLockResponse();
        try {
            logger.debug("Operation: releaseTrademarkLock");
            marshallingService.printRequestResponse(parameters);

            intrepidCommonService.releaseTrademarkLock(parameters.getFileNumber().intValue(),
                parameters.getExtensionCounter().intValue());
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
        return response;
    }

    @Override
    public ProcessActionsCountResponse processActionsCount(ProcessActionsCountRequest parameters)
        throws CIPOServiceFault {
        ProcessActionsCountResponse response = new ProcessActionsCountResponse();
        try {
            logger.debug("Operation: processActionsCount");
            marshallingService.printRequestResponse(parameters);

            int count = intrepidCommonService.getProcessActionCount();
            response.setCount(BigInteger.valueOf(count));

            marshallingService.printRequestResponse(response);

        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }
        return response;
    }

    @Override
    public String getCountryProvince(String countryProvinceCode, LanguageType language) throws CIPOServiceFault {

        return intrepidCommonService.countryLookup(countryProvinceCode, language);
    }

    @Override
    public void processModifiedRepAddressSubmission(ProcessModifiedRepAddressSubmissionRequest modifiedRepAddressSubmission)
        throws CIPOServiceFault {
        try {
            logger.debug("Operation: processIRCorrectionSubmission");
            marshallingService.printRequestResponse(modifiedRepAddressSubmission);

            consoleService.processModifiedRepAddressSubmission(modifiedRepAddressSubmission);
        } catch (Throwable t) {
            throw new CIPOServiceFault("Service Fault: " + t.getMessage(), handleExceptions(t), t);
        }

    }

}
