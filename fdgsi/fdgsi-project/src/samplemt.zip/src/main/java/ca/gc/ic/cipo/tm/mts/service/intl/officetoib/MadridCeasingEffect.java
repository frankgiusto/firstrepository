package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import _int.wipo.standards.xmlschema.st96.common.madrid.EntityNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.HolderBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridCeasingEffectRuleCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridCeasingEffectType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.mops.MOPSClient;
import ca.gc.ic.cipo.tm.mops.MOPSServiceFactory;
import ca.gc.ic.cipo.tm.mops.MOPSServiceResponse;
import ca.gc.ic.cipo.tm.mts.CeasingOfEffectMF9Type;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;

public class MadridCeasingEffect extends OfficeToIbBase implements IOutboundTransaction, IReportingService {

    private static Logger log = Logger.getLogger(MadridCeasingEffect.class.getName());

    // private MadridOutboundTransactionType madridOutboundTransactionType =
    // MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9;

    @Value("#{environment['mts.mops.wipo.service.host.name']}")
    private String mopsServiceHost;

    /** MADRID_MF9 */
    private final static String reportName = "MADRID_MF9";

    private final static String CancellationIndicator_Total = "Total Cancellation";

    private final static String CancellationIndicator_Partial = "Partial Cancellation";

    private MadridOutboundTransactionType madridOutboundTransactionType = null;

    public MadridCeasingEffect(MadridOutboundTransactionType madridOutboundTransactionType) {
        this.madridOutboundTransactionType = madridOutboundTransactionType;
    }

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();
        _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

        MadridCeasingEffectType transaction = objectFactory.createMadridCeasingEffectType();

        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        List<TMInfoRetrievalDto> madridApplicationActionList = outboundTransactionDto
            .getMadridApplicationActionDetails();

        // Office Reference Identifier
        transaction.getContent().add(
            commonObjectFactory.createOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString())));

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.getContent().add(commonObjectFactory.createNotificationLanguage(notificationLanguage));

        // IR Number
        transaction.getContent()
            .add(commonObjectFactory.createInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo()));

        // Basic Registration Application Bag
        transaction.getContent().add(objectFactory
            .createBasicRegistrationApplicationBag(basicRegistrationApplication(madridApplicationActionList)));

        // Holder Bag
        String officeType = null;
        if (outboundTransactionDto.getOfficeType() != null) {
            officeType = outboundTransactionDto.getOfficeType().name();
        }

        if ((officeType != null) && officeType.equalsIgnoreCase(OfficeType.DO.name())) {
            transaction.getContent().add(objectFactory.createHolderBag(
                super.mapHolder(processActionApplication.getTmInterestedPartyTypeList(), notificationLanguage)));

        } else {
            MOPSServiceResponse mopsResponse = new MOPSServiceResponse();

            boolean mopsError = false;
            try {
                MOPSClient mopsClient = MOPSServiceFactory.createClient(mopsServiceHost);
                log.debug("IR Number: " + outboundTransactionDto.getIntlRegNo());

                mopsResponse = mopsClient.getMadridRegistrationByIRNumber(outboundTransactionDto.getIntlRegNo());

            } catch (Exception ex) {
                mopsError = true;
                log.error("Error in mopsClient.getMadridRegistrationByIRNumber", ex);
                log.error("Unable to find WIPO information for IR Number:" + outboundTransactionDto.getIntlRegNo());
            }

            HolderBagType holderBagType = objectFactory.createHolderBagType();
            List<ApplicantType> holder = new ArrayList<>();
            ApplicantType applicantType = objectFactory.createApplicantType();

            EntityNameType entityNameType = commonObjectFactory.createEntityNameType();
            if (mopsError) {
                entityNameType.setValue("Holder mame placeholder");
            } else {
                entityNameType.setValue(ManualReportUtil.getHolderName(mopsResponse));
            }
            entityNameType.setLanguageCode(notificationLanguage.value());

            _int.wipo.standards.xmlschema.st96.common.madrid.NameType nameType = commonObjectFactory.createNameType();
            nameType.getPersonNameOrOrganizationNameOrEntityName().add(entityNameType);

            _int.wipo.standards.xmlschema.st96.common.madrid.ContactType internationalContactType = commonObjectFactory
                .createContactType();
            internationalContactType.setName(nameType);
            applicantType.getLegalEntityNameOrPartyIdentifierOrContact().add(internationalContactType);

            holder.add(applicantType);
            holderBagType.getHolder().addAll(holder);
            transaction.getContent().add(objectFactory.createHolderBag(holderBagType));
        }

        ProcessActionCodeType paType = outboundTransactionRequest.getProcessActionCodeType();
        log.debug("ProcessActionCodeType: " + paType);

        if ((paType != null && paType == ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9)
            || (processActionApplication.getGoodsAndServices().isEmpty())) {// total

            transaction.getContent().add(objectFactory.createAllGoodsServicesIndicator(true));

        } else {// partial
            transaction.getContent().add(// partial
                objectFactory.createGoodsServicesBag(mapGoodsServices(processActionApplication.getGoodsAndServices())));
        }

        // Ceasing of Effect Rule Category TODO mandatory. which one? Madrid Rule 22_1_A or Madrid Rule 22_1_C
        // updates: it can identify if it is Rule 22(1)(c) by checking if Potential Ceasing of Effect record exists
        // in the Madrid_Application_Actions table for the particular AIR otherwise it is Rule 22(1)(a).
        if (outboundTransactionDto.isHasMatchedActionCode()) {
            transaction.getContent().add(objectFactory
                .createMadridCeasingEffectRuleCategory(MadridCeasingEffectRuleCategoryType.MADRID_RULE_22_1_C));
        } else {
            transaction.getContent().add(objectFactory
                .createMadridCeasingEffectRuleCategory(MadridCeasingEffectRuleCategoryType.MADRID_RULE_22_1_A));
        }

        // Request Cancellation Indicator
        if ((paType != null && paType == ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9)
            || (processActionApplication.getGoodsAndServices().isEmpty())) {// total

            transaction.getContent().add(objectFactory.createRequestCancellationIndicator(CancellationIndicator_Total));

        } else {// partial
            transaction.getContent()
                .add(objectFactory.createRequestCancellationIndicator(CancellationIndicator_Partial));
        }

        // Record Notification Date
        transaction.getContent().add(
            commonObjectFactory.createRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp())));

        // Document Included Bag
        List<String> documents = new ArrayList<>();
        String includedDocName = getUniqueReportName(reportName, outboundTransactionDto.getIntlRegNo(),
            intlIrTranDto.getIrTranId().toString());
        StringBuilder documentName = createDocument(includedDocName);
        documents.add(documentName.toString());

        transaction.getContent().add(commonObjectFactory.createDocumentIncludedBag(super.mapDocumentBag(documents)));

        JAXBElement<MadridCeasingEffectType> madridobject = objectFactory.createMadridCeasingEffect(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(OfficeToIbBase.xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, OfficeToIbBase.reportXpath);

        ProcessManualReportRequest manualReportRequest = (ProcessManualReportRequest) inObject;
        CeasingOfEffectMF9Type notificationType = manualReportRequest.getManualReportForm().getCeasingOfEffectMF9Type();

        String tagName = OfficeToIbBase.xmltagName_ORID;
        String value = formatValue(manualReportRequest.getIpOffice());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_IR;
        value = formatValue(manualReportRequest.getIrNumber());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        MadridCeasingEffectType transObj = marshallingService.unmarshallOutboundTransaction(tranId);
        List<JAXBElement<?>> mf9Content = transObj.getContent();
        ISOLanguageCodeType langType = null;
        for (JAXBElement<?> element : mf9Content) {
            QName name = element.getName();
            if (name.getLocalPart().equals("NotificationLanguage")) {
                langType = (ISOLanguageCodeType) element.getValue();
                break;
            }
        }

        tagName = OfficeToIbBase.xmltagName_NL;
        value = langType.value();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_HOLDER;
        value = manualReportRequest.getOwnerName();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // IV
        tagName = "CeasingOfEffectDecision";
        value = formatValue(notificationType.getCeasingOfEffectDecision());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // V
        tagName = "CeasingEffeciveInfo";
        value = formatValue(notificationType.getCeasingEffectiveInfo());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // VI
        tagName = "GoodServiceAffectedText";
        value = formatValue(notificationType.getGoodsAndServicesCeasing());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // VII static
        tagName = OfficeToIbBase.xmltagName_SIGN;
        XMLTagUtil.appendTag(xmlDataSource, tagName);

        tagName = OfficeToIbBase.xmltagName_IBNDate;
        value = formatValue(manualReportRequest.getSystemDate().toString());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        XMLTagUtil.appendTagClose(xmlDataSource, OfficeToIbBase.reportXpath);
        log.debug(xmlDataSource.toString());

        Locale locale = ((manualReportRequest.getLanguageCode().equalsIgnoreCase(LOCAL_EN)) ? Locale.CANADA
            : Locale.CANADA_FRENCH);

        String jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(),
            (MtsStringUtil.SLASH + OfficeToIbBase.reportXpath), reportName, null, locale);

        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);
        String includedDocName = getUniqueReportName(reportName, manualReportRequest.getIrNumber(),
            manualReportRequest.getTransactionId().toString());
        madridReportResponse.setReportName(includedDocName);

        return madridReportResponse;
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {

        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return true;
    }

}
