package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.sql.Blob;

import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;

public class IntrepidDocumentDto {

    private String fileName;

    private IntlFileFrmtTypeEnum fileFormat;

    private Blob blob;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Blob getBlob() {
        return blob;
    }

    public void setBlob(Blob blob) {
        this.blob = blob;
    }

    public IntlFileFrmtTypeEnum getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(IntlFileFrmtTypeEnum fileFormat) {
        this.fileFormat = fileFormat;
    }
}
