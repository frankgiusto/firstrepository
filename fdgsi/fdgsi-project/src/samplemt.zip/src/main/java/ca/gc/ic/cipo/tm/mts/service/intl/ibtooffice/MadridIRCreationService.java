package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridInternationalRegistrationCreationType;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationStatus;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

/**
 * @author giustof
 *
 */
@Service(value = "madridIRCreation")
public class MadridIRCreationService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private MadridApplicationDao madridApplicationsDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionsDao;

    private static Logger logger = Logger.getLogger(MadridIRCreationService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();
        MadridInternationalRegistrationCreationType madridInternationalRegistrationCreationType = (MadridInternationalRegistrationCreationType) transType;

        logger.debug("Processing MadridInternationalRegistrationCreationType: OfficeReferenceIdentifier:"
            + madridInternationalRegistrationCreationType.getOfficeReferenceIdentifier().getValue());

        MadridApplication madridApplication = madridApplicationsDao.getMadridApplicationByReferenceNumber(
            madridInternationalRegistrationCreationType.getOfficeReferenceIdentifier().getValue());

        if (null == madridApplication) {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }

        madridApplication.setIrNumber(madridInternationalRegistrationCreationType.getInternationalRegistrationNumber());
        madridApplication.setStatusCode(MadridApplicationStatus.REGISTERED.getValue());
        madridApplicationsDao.saveMadridApplication(madridApplication);

        // create new Action for Madrid Application
        createMadridApplicationAction(madridApplication, madridInternationalRegistrationCreationType, intlIrTran);

        // NOTE:
        // ie. Original Requirement - System updates all Tasks that were ‘On Hold’ for the IA Number in the Task
        //
        // Based on the design decision that we will not create a task on hold (process action) for an application that
        // is not registered, there is no longer a need to do this.

        return statusTypeResults;
    }

    @Override
    public String getServiceName() {
        return "MadridIRCreationService";
    }

}
