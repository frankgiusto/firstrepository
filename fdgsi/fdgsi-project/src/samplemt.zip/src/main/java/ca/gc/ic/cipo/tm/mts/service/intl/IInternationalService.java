package ca.gc.ic.cipo.tm.mts.service.intl;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import ca.gc.ic.cipo.tm.intl.enumerator.IntlAtchmtTypeCode;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionList;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskMetaList;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskXrefDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IrregularityDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFileTypeDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;

public interface IInternationalService {

    /**
     * Update task status.
     *
     * @param intlIrTranId the intl ir tran id
     * @param statusType the status type
     */
    public void updateTaskStatus(BigDecimal intlIrTranId, TaskStatusType statusType);

    /**
     * Gets the transactions by ir tran id.
     *
     * @param irTranId the ir tran id
     * @return the transactions by ir tran id
     */
    public IntlIrTranDto getTransactionsByIrTranId(BigDecimal irTranId);

    /**
     * Gets the total tasks.
     *
     * @param request the request
     * @return the total tasks
     */
    public Long getTotalTasks(WorkflowTaskListSearchCriteria request);

    /**
     * Gets the console tasks.
     *
     * @param request the request
     * @return the console tasks
     * @throws CIPOServiceFault the CIPO service fault
     */
    public WorkflowTaskMetaList getConsoleTasks(WorkflowTaskListSearchCriteria request) throws CIPOServiceFault;

    /**
     * Returns the list of Descriptions for the provided Search Criteria.
     *
     * @param taskDescriptionListSearchCriteria the provided Search Criteria
     * @return the list of Descriptions for the provided task subject type
     */
    public TaskDescriptionList getTaskDescriptionList(TaskDescriptionListSearchCriteria taskDescriptionListSearchCriteria);

    /**
     * Update transaction status.
     *
     * @param intlIrTranId the intl ir tran id
     * @param intlStatus the intl status
     */
    public void updateTransactionStatus(BigDecimal intlIrTranId, StatusType intlStatus);

    /**
     * Store transaction.
     *
     * @param os the os
     * @param intlPkg the intl pkg
     * @param transactionStatus the transaction status
     * @param transactionCategory the transaction category
     * @param recordIdentifier the record identifier
     * @param registrationNumber the registration number
     * @param recordEffectiveDate the record effective date
     * @return the intl ir tran dto
     * @throws MTSServiceFault the MTS service fault
     */
    public IntlIrTranDto storeTransaction(ByteArrayOutputStream os, IntlPkg intlPkg, StatusType transactionStatus,
                                          TransactionCategory transactionCategory, String recordIdentifier,
                                          String registrationNumber, String recordEffectiveDate)
        throws MTSServiceFault;

    /**
     * Gets the transaction list.
     *
     * @param transactionCriteria the transaction criteria
     * @return the transaction list
     * @throws CIPOServiceFault the CIPO service fault
     */
    public List<TransactionDetail> getTransactionList(TransactionCriteria transactionCriteria) throws CIPOServiceFault;

    /**
     * Gets the transaction.
     *
     * @param transactionId the transaction id
     * @param includeXmlContent the include xml content
     * @param includeAttachmentContent the include attachment content
     * @return the transaction
     */
    public TransactionDetail getTransaction(BigDecimal transactionId, boolean includeXmlContent,
                                            boolean includeAttachmentContent)
        throws CIPOServiceFault;

    /**
     * Get the transaction. Returns only the first one, if multiple records found with the criteria
     *
     * @param recordIdentifier
     * @param irNumber
     * @param isCorrectionTypeTransactionOnly
     * @param includeXmlContent
     * @param includeAttachmentContent
     * @return
     * @throws CIPOServiceFault
     */
    public TransactionDetail getTransactionByIntlRecordId(String recordIdentifier, String irNumber,
                                                          boolean isCorrectionTypeTransactionOnly,
                                                          boolean includeXmlContent, boolean includeAttachmentContent)
        throws CIPOServiceFault;

    /**
     * Gets the transaction attachment.
     *
     * @param attachmentId the attachment id
     * @return the transaction attachment
     * @throws CIPOServiceFault the CIPO service fault
     */
    public AttachmentDetail getTransactionAttachment(BigDecimal attachmentId) throws CIPOServiceFault;

    /**
     * Send file to intrepid nfs.
     *
     * @param irTranId the ir tran id
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @param outboundOnly true for outbound generated attachments
     * @throws MTSServiceFault the MTS service fault
     */
    public void sendFileToIntrepidNFS(BigDecimal irTranId, BigDecimal fileNumber, String extensionCounter,
                                      NfsFileTypeDto nfsFileType)
        throws MTSServiceFault;

    /**
     * Existing ir number ok.
     *
     * @param intlRegNumber the intl reg number
     * @param statusTypeCodeIds the status type code ids
     * @return true, if successful
     */
    public boolean existingIrNumberOk(List<String> intlRegNumber, List<BigDecimal> statusTypeCodeIds);

    /**
     * Retrieves the console task by taskId
     *
     * @param taskId
     * @return
     * @throws CIPOServiceFault
     */
    public IntlIrTaskDto getConsoleTaskById(BigDecimal taskId) throws CIPOServiceFault;

    /**
     * Updates the Transaction Content
     *
     * @param irTranId
     * @param os
     */
    public void updateTransactionContent(BigDecimal irTranId, ByteArrayOutputStream os) throws MTSServiceFault;

    /**
     * Gets a list of transactions by task id.
     *
     * @param irTaskId the ir task id
     * @return the list of transactions
     */
    public List<IntlIrTranDto> getTransactionByTaskId(BigDecimal irTaskId);

    /**
     * Update partial ownership task. We need to know the file number of the new Application created by COPYMARK stored
     * procedure in Intrepid. This must be stored somewhere so that the next step in the MWE flow can identify this and
     * apply notifications to the correct application.
     *
     * @param irTaskId the ir task id
     * @param newfileNumber the newfile number
     */
    public void updatePartialOwnershipTask(BigDecimal irTaskId, Integer newfileNumber);

    /**
     * Gets the transactions having active tasks.
     *
     * @param intlRegNo the intl reg no
     * @param fileNumber the file number
     * @param taskId the task id we want to ignore
     * @param intlRecordEfdt the intl record efdt
     * @return the transactions having active tasks
     */
    public List<BigDecimal> getTransactionsHavingActiveTasks(String intlRegNo, BigDecimal fileNumber, BigDecimal taskId,
                                                             Date intlRecordEfdt);

    /**
     * Gets the transaction record by ir tran id. We only populate the transaction dto, not the related xref's in this
     * case.
     *
     * @param irTranId the ir tran id
     * @return the transaction record by ir tran id
     */
    public IntlIrTranDto getTransactionRecordByIrTranId(BigDecimal irTranId);

    /**
     * Returns the list of TasksXref where tasks are raised for holders without contact details (phone and email)
     *
     * @return List of TasksXrefDto
     */

    public List<IntlIrTaskXrefDto> getTransactionListForHolderDetails() throws CIPOServiceFault;

    /**
     * Get Irregulartiy inbound details.
     *
     * @param transaction the transaction
     * @return true, if is OO inbound
     * @throws JAXBException the JAXB exception
     * @throws CIPOServiceFault exception
     */
    public IrregularityDto getIrregularityInbound(IntlIrTranDto transaction) throws CIPOServiceFault;

    public void generateReportNotification(MadridReportResponse madridReportResponse, BigDecimal irTranId)
        throws CIPOServiceFault;

    public IntlAtchmt createAttachment(IntlIrTran irTransaction, Blob document, String fileName,
                                       IntlFileFrmtTypeEnum fileFormat, IntlAtchmtTypeCode attachmentType);

    /**
     *
     *
     * @param transId
     * @return
     * @throws CIPOServiceFault
     */
    public IntlIrTran getById(BigDecimal transId) throws CIPOServiceFault;

    /**
     *
     *
     * @param tranId
     * @return
     * @throws CIPOServiceFault
     */
    public List<IntlAtchmt> getAtchmtListByTranId(BigDecimal tranId) throws CIPOServiceFault;

    /**
     * Gets the transactions by ir tran id with null supported.
     *
     * @param irTranId the ir tran id
     * @return the transactions by ir tran id
     */
    public IntlIrTranDto getIrTran(BigDecimal irTranId);
}
