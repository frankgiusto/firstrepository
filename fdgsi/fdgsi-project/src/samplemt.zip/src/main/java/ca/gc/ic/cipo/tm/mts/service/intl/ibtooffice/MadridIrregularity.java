package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

@Service(value = "irregularity")
public class MadridIrregularity extends MadridTransactionService implements IInboundTransaction {

    private static Logger logger = Logger.getLogger(MadridIrregularity.class.getName());

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing irregularity: Intl Record Id:" + intlIrTran.getIntlRecordId());

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        if (intlIrTran.getOfficeType() == OfficeType.OO) {

            intlIrTran.getOfficeRefId();

            ApplicationDto applicationDto = new ApplicationDto();
            applicationDto.setFileNumber(null);
            applicationDto.setExtensionCounter("0");
            applicationDto.setIrNumber(intlIrTran.getIntlRegNo());
            applicationDto.setTaskStatusCode(TaskStatusType.UNPROCESSED.getValue());
            applicationDto.setOfficeType(OfficeType.OO.name());
            applicationDto.setWipoReferenceNumber(
                intlIrTran.getIrregularityDto() != null ? intlIrTran.getIrregularityDto().getWipoRefNum() : null);

            statusTypeResults.put(applicationDto, UserTaskType.IRREGULARITY);

        } else {

            // DO . Get all applications matching transactions international registration number.

            List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
            if (CollectionUtils.isNotEmpty(taskList)) {
                for (IntlIrTaskDto intlIrTaskDto : taskList) {

                    Application application = applicationDao
                        .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                    if (null == application) {
                        logger.error(
                            "Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                        throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                    }

                    // Set the Manual Task
                    ApplicationDto applicationDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);

                    /*
                     * if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                     * .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {
                     *
                     * applicationDto.setTaskStatusCode(TaskStatusType.UNPROCESSED.getValue());
                     *
                     * } else { applicationDto.setTaskStatusCode(TaskStatusType.ON_HOLD.getValue()); }
                     */
                    applicationDto.setTaskStatusCode(TaskStatusType.UNPROCESSED.getValue());

                    statusTypeResults.put(applicationDto, UserTaskType.IRREGULARITY);
                }
            } else {
                // Madrid Mark does not exist - manual
                logger.error(
                    "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
                throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
            }
        }
        return statusTypeResults;
    }
}
