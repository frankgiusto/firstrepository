package ca.gc.ic.cipo.tm.mts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.InboundTransactionService;

@Service
public class IntrepidTransactionMgr extends TransactionMgr
{
	@Autowired
	private InboundTransactionService inboundTransactionService;

	@Override
	@Transactional(value = "transactionManager", rollbackFor = Exception.class)
	public AutomatedProcessResponse processTransaction(TransactionRequest transaction) throws CIPOServiceFault
	{
		return inboundTransactionService.processTransaction(transaction);
	}
	
	@Override
	@Transactional(value = "transactionManager", rollbackFor = Exception.class)
	public ManualProcessResponse processManualTransaction(TransactionRequest  transactionRequest )
    throws CIPOServiceFault
    {
		return inboundTransactionService.processManualTransaction(transactionRequest);
    }
	
	@Override
	@Transactional(value = "transactionManager", rollbackFor = Exception.class)
	public AutomatedProcessResponse processOwnershipChangeMerger(TransactionPairRequest transaction) throws CIPOServiceFault
	{
		return inboundTransactionService.processOwnershipChangeMerger(transaction);
	}	
}
