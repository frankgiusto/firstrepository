package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;

public class OutboundTransactionMap {

    public static final Map<MadridOutboundTransactionType, OfficeType> outboundTransactionOfficeTypeMap;

    static {
        // status_ctgry_id=508 and pkg_tran_ctgry_id in (10,11,20,21,30,53,54,51,62,52,75,60,61,50,40,71)
        Map<MadridOutboundTransactionType, OfficeType> aMap = new HashMap<>();
        aMap.put(MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF2, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_GRANT_PROTECTION_MF4, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF6, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_FURTHER_DECISION_MF7, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9, OfficeType.OO);
        aMap.put(MadridOutboundTransactionType.MADRID_INVALIDATION_FULL_MF10, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_INVALIDATION_PARTIAL_MF10, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_DIVISION, OfficeType.OO);
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER, OfficeType.OO);
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT, OfficeType.OO);
        aMap.put(MadridOutboundTransactionType.MADRID_CORRECTION_REQUEST, OfficeType.BOTH);
        aMap.put(MadridOutboundTransactionType.IRREGULARITY_RESPONSE_SENT, OfficeType.DO);

        aMap.put(MadridOutboundTransactionType.MADRID_CANCELLATION, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_LIMITATION_NO_EFFECT, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_GOODS_SERVICES_LIMITATION_REQUEST, OfficeType.DO);
        aMap.put(MadridOutboundTransactionType.MADRID_IRREGULARITY, OfficeType.BOTH);

        outboundTransactionOfficeTypeMap = Collections.unmodifiableMap(aMap);
    }

}
