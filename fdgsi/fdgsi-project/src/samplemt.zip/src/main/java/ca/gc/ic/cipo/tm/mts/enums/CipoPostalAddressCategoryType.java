package ca.gc.ic.cipo.tm.mts.enums;

/**
 *
 * Cipo Postal Address Category Type
 *
 */
public enum CipoPostalAddressCategoryType {

    /**
     * Home type
     */
    HOME("Home"),

    /**
     * Business Type
     */
    BUSINESS("Business");

    private String value;

    private CipoPostalAddressCategoryType(String value) {
        this.setValue(value);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
