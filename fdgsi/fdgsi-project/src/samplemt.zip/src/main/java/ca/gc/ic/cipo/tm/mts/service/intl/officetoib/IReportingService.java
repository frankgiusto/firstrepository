package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;

public interface IReportingService {

    /**
     * Generate report using the RGS.
     *
     * @param transactionOutputStream the transaction output stream
     * @param tranId the tran id
     * @param marshallingService the marshalling service
     * @param reportServiceHost the report service host
     * @return the Madrid Report Response
     * @throws Exception the exception
     */
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception;

    /**
     *
     * Generate report using the RGS.
     *
     * @param transactionOutputStream the transaction output stream
     * @param tranId the tran id
     * @param marshallingService the marshalling service
     * @param reportServiceHost the report service host
     * @param manualReportRequest available only when we are processing a manual report
     * @return the Madrid Report Response
     * @throws Exception the exception
     */
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object manualReportRequest)
        throws Exception;

}
