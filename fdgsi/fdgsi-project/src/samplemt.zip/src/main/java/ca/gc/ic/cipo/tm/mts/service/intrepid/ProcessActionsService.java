package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionList;
import ca.gc.ic.cipo.tm.mts.ProcessActionsResponse;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

/**
 * @author giustof
 *
 */
@Service
public class ProcessActionsService extends MadridTransactionService implements IProcessActionsService {

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MailDao mailDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    private static Logger logger = Logger.getLogger(ProcessActionsService.class.getName());

    // Requirement is to get the first email in collection.
    private static int MOST_RECENT_MAIL = 0;

    @Override
    public String getServiceName() {
        return "ProcessActionsService";
    }

    @Transactional
    @Override
    public ProcessActionList getProcessActionList(ProcessActionCategoryType processActionType) {

        logger.debug("getProcessActionList " + processActionType);

        ProcessActionList processActionList = new ProcessActionList();

        List<ProcessAction> processActions = processActionsDao
            .getProcessActionsByCodes(intrepidDTOFactory.getProcessActionCodes(processActionType));

        for (ProcessAction processActionResult : processActions) {
            if (processActionResult.getProcessCode() == ProcessActionsType.REVIEW_INCOMING_CORRESPONDENCE.getValue()
                .intValue()) {

                List<Mail> mailList = mailDao.getMailByFileId(processActionResult.getFileNumber());
                if (CollectionUtils.isNotEmpty(mailList)) {
                    ProcessActionsResponse processAction = intrepidDTOFactory.getProcessActionResultDto(
                        processActionResult, processActionType, mailList.get(MOST_RECENT_MAIL).getAuthorityId());
                    if (null != processAction.getProcessActionsMeta()) {
                        processActionList.getTaskListBag().add(processAction);
                    }
                } else {
                    ProcessActionsResponse processAction = intrepidDTOFactory
                        .getProcessActionResultDto(processActionResult, processActionType);
                    if (null != processAction.getProcessActionsMeta()) {
                        processActionList.getTaskListBag().add(processAction);
                    }

                }

            } else {
                ProcessActionsResponse processAction = intrepidDTOFactory.getProcessActionResultDto(processActionResult,
                    processActionType);
                if (null != processAction.getProcessActionsMeta()) {
                    processActionList.getTaskListBag().add(processAction);
                }
            }
        }

        return processActionList;
    }

    @Transactional
    @Override
    public ProcessAction getById(Integer processActionId) {
        return processActionsDao.getById(processActionId);
    }

    @Transactional
    @Override
    public void createProcessAction(ProcessAction processAction) {
        processActionsDao.saveProcessActions(processAction);
    }
}
