package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.activation.DataHandler;
import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import _int.wipo.standards.xmlschema.st96.common.madrid.DocumentIncludedBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.DocumentType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridProvisionalRefusalType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.Attachment;
import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;
import ca.gc.ic.cipo.tm.mts.GroundsOfOppositionList;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProvisionalRefusalDetail;
import ca.gc.ic.cipo.tm.mts.ProvisionalRefusalMF3AType;
import ca.gc.ic.cipo.tm.mts.TrademarkInfo;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlAtchmtDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;

public class MadridProvisionalRefusal extends OfficeToIbBase implements IOutboundTransaction, IReportingService {

    private static Logger log = Logger.getLogger(MadridProvisionalRefusal.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3;

    private final static String reportName = "MADRID_MF3A";

    @Value("#{environment['mts.ws.common.temp.folder']}")
    private String commonTempFolder;

    private boolean hasMarkImage = false;

    private String markFileSavedDir;

    // TODO This transaction type is initiated as a Manual task. MF3a. The data will come from the Madrid Console
    // update when that is ready.
    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        MadridProvisionalRefusalType transaction = objectFactory.createMadridProvisionalRefusalType();
        TMInfoRetrievalDto tirsDto = outboundTransactionDto.getProcessActionApplication();

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(tirsDto);
        transaction.setNotificationLanguage(notificationLanguage);

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Refusal Pronounced Date Refer to MF3a form field Field IX
        if (StringUtils.isNotBlank(outboundTransactionRequest.getRefusalPronouncedDate())) {
            Date date = convertStringToDate(outboundTransactionRequest.getRefusalPronouncedDate(), log);
            if (date != null) {
                GregorianCalendar gregorianCalendar = new GregorianCalendar();
                gregorianCalendar.setTime(date);
                // XMLGregorianCalendar clendar =
                // DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
                XMLGregorianCalendar clendar = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(
                    gregorianCalendar.get(Calendar.YEAR), gregorianCalendar.get(Calendar.MONTH) + 1,
                    gregorianCalendar.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
                transaction.setRefusalPronouncedDate(clendar);
            }

        }

        // All Goods Services Indicator: Value as ‘True’. Indicates the transaction is for all goods and services on the
        // international registrations concerned
        transaction.setAllGoodsServicesIndicator(true);

        // Record Identifier: The date is recorded in the Application Table and in the International_Transaction table.
        IdentifierType identifierType = new IdentifierType();
        identifierType.setValue(convertDateToString(intlIrTranDto.getIntlRecordEfctvDt()));
        transaction.setRecordIdentifier(identifierType);

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Goods Services Refusal Bag TODO: No requirement yet.
        // GoodsServicesRefusalBagType goodsServicesRefusalBagType = objectFactory.createGoodsServicesRefusalBagType();
        // GoodsServicesRefusalType goodsServicesRefusalType = objectFactory.createGoodsServicesRefusalType();
        //
        // goodsServicesRefusalType.getGoodsServicesRefusalCategoryOrClassDescriptionRefusalBagOrCommentText()
        // .add(GoodsServicesRefusalCategoryType.REFUSED);
        // goodsServicesRefusalBagType.getGoodsServicesRefusal().add(goodsServicesRefusalType);
        // transaction.setGoodsServicesRefusalBag(goodsServicesRefusalBagType);

        // Document Included Bag

        // Document Included Bag
        DocumentIncludedBagType documentBag = new DocumentIncludedBagType();
        List<String> documents = new ArrayList<>();
        String includedDocName = getUniqueReportName(reportName, outboundTransactionDto.getIntlRegNo(),
            intlIrTranDto.getIrTranId().toString());
        StringBuilder documentName = createDocument(includedDocName);
        documents.add(documentName.toString());

        // This report comes from Intrepid.
        if (StringUtils.isNotBlank(outboundTransactionRequest.getAdditionalInfo()) && !outboundTransactionRequest
            .getAdditionalInfo().startsWith(ManualReportUtil.getResponseToIrregularityMcKey())) {
            documentName = createDocument(outboundTransactionRequest.getAdditionalInfo(), intlIrTranDto.getIrTranId());
            documents.add(documentName.toString());
        }

        for (String document : documents) {
            documentBag.getDocumentIncluded().add(getDocumentType(document));
        }

        if (intlIrTranDto.getIntlAtchmtDtoList() != null && !intlIrTranDto.getIntlAtchmtDtoList().isEmpty()) {

            for (IntlAtchmtDto atchmtDto : intlIrTranDto.getIntlAtchmtDtoList()) {
                boolean fileAlreadyIncluded = false;
                for (String initialDocument : documents) {
                    if (initialDocument.contains(atchmtDto.getFileName())) {
                        fileAlreadyIncluded = true;
                        break;

                    }
                }
                if (!fileAlreadyIncluded) {
                    String amendedDoc = createDocument(atchmtDto.getFileName()).toString();
                    documents.add(amendedDoc);
                    DocumentType documentType = getDocumentType(amendedDoc);
                    documentType.setFileName(atchmtDto.getFileName());
                    Date fileCreatedDate = new Date(atchmtDto.getCreatedTmstmp().getTime());
                    documentType.setDocumentDate(convertDateToString(fileCreatedDate));
                    documentBag.getDocumentIncluded().add(documentType);
                }

            }

        }

        if (!documentBag.getDocumentIncluded().isEmpty()) {
            transaction.setDocumentIncludedBag(documentBag);
        }

        JAXBElement<MadridProvisionalRefusalType> madridobject = objectFactory
            .createMadridProvisionalRefusal(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        MadridProvisionalRefusalType transObj = marshallingService.unmarshallOutboundTransaction(tranId);

        ProcessManualReportRequest manualReportRequest = (ProcessManualReportRequest) inObject;

        ProvisionalRefusalMF3AType notificationType = manualReportRequest.getManualReportForm()
            .getProvisionalRefusalMF3AType();

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(OfficeToIbBase.xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, OfficeToIbBase.reportXpath);

        String tagName = OfficeToIbBase.xmltagName_ORID;
        String value = formatValue(manualReportRequest.getIpOffice());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_NL;
        value = transObj.getNotificationLanguage().value();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_IR;
        value = formatValue(manualReportRequest.getIrNumber());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_HOLDER;
        value = formatValue(manualReportRequest.getOwnerName());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        ProvisionalRefusalDetail provisionalRefusalDetail = notificationType.getProvisionalRefusalDetail();

        tagName = "ActionFromExamination";
        if (notificationType.isProcessActionInExamination()) {
            XMLTagUtil.appendTag(xmlDataSource, tagName, "true");
        } else {
            XMLTagUtil.appendTag(xmlDataSource, tagName, "false");

            // build IV (the name and address of the opponent)
            buildTagIVValue(xmlDataSource, provisionalRefusalDetail);
            // field V (static text)

        }

        // build IX
        tagName = "DeadlineDate";
        value = formatValue(notificationType.getReviewOrFileAppeal().getTimeLimitDate());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = "OtherRequirement";
        value = formatValue(notificationType.getReviewOrFileAppeal().getOtherRequirements());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // build VI (Opposition Case Numbe
        tagName = "GroundsForRefusalCodeText";
        value = formatValue(notificationType.getGroundsOfOppositionCodes());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        // build VII (Grounds)
        GroundsOfOppositionList groupList = notificationType.getGroundsOfOppositionList();
        if (groupList != null) {
            List<GroundsOfOpposition> groundsOfOppositionList = groupList.getGroundsOfOppositionListBag();
            if ((groundsOfOppositionList != null) && !groundsOfOppositionList.isEmpty()) {
                buildTagVIIValue(xmlDataSource, groundsOfOppositionList);
            }
        }

        // Field VIII (Corresponding essential provisions of the applicable law)
        tagName = "CorrespondingEssential";
        value = formatValue(notificationType.getGroundsOfOppositionDescription());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_SIGN;
        XMLTagUtil.appendTag(xmlDataSource, tagName);

        tagName = OfficeToIbBase.xmltagName_IBNDate;
        value = formatValue(manualReportRequest.getSystemDate().toString());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        XMLTagUtil.appendTagClose(xmlDataSource, OfficeToIbBase.reportXpath);
        log.debug(xmlDataSource.toString());

        String jobId = null;
        Locale locale = ((manualReportRequest.getLanguageCode().equalsIgnoreCase(LOCAL_EN)) ? Locale.CANADA
            : Locale.CANADA_FRENCH);

        try {
            List<InputStream> imageList = null;

            if (hasMarkImage) {
                imageList = setReproductionMarksForReport(commonTempFolder, markFileSavedDir, log);

                if ((imageList != null) && imageList.isEmpty()) {
                    imageList = null;
                }
            }
            jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(),
                (MtsStringUtil.SLASH + OfficeToIbBase.reportXpath), reportName, imageList, locale);

        } catch (Exception e) {
            throw new Exception("Error shedudling report.", e);
        } finally {
            deleteReproductionMarkTempUploadDir(markFileSavedDir);
        }
        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);

        String includedDocName = getUniqueReportName(reportName, manualReportRequest.getIrNumber(),
            manualReportRequest.getTransactionId().toString());
        madridReportResponse.setReportName(includedDocName);

        return madridReportResponse;
    }

    // @formatter:off
    /**
     * <NameOfOpponent> Name of Opponent</NameOfOpponent> <AddressOfOpponent> Address of Opponent </AddressOfOpponent>
     *
     */
    // @formatter:on
    private void buildTagIVValue(StringBuilder rtnValue, ProvisionalRefusalDetail provisionalRefusalDetail) {
        String tagIV_I = "NameOfOpponent";
        String value = formatValue(provisionalRefusalDetail.getOpponentName());
        XMLTagUtil.appendTag(rtnValue, tagIV_I, value);

        String tagIV_II = "AddressOfOpponent";
        value = formatValue(provisionalRefusalDetail.getOpponentAddress());
        XMLTagUtil.appendTag(rtnValue, tagIV_II, value);
    }

    // @formatter:off
    /**
     *
     * @return list of <EarlierMark> <FillingDateAndNumber> xxxx </FillingDateAndNumber>
     *         <RegistrationDateAndNumber> xxxx </RegistrationDateAndNumber>
     *         <OwnerNameAndAddress> xxxx </OwnerNameAndAddress> <ReproductionMark> xxxx </ReproductionMark>
     *         <ImageFileName> xxxx </ImageFileName>
     *         <ReasonsForLimitationNoEffect> xxxx </ReasonsForLimitationNoEffect> </EarlierMark>
     * @throws Exception
     *
     */
    // @formatter:on
    private void buildTagVIIValue(StringBuilder rtnValue, List<GroundsOfOpposition> groundsOfOppositionList)
        throws Exception {
        String value = MtsStringUtil.EMPTY;
        String tagVII = "EarlierMark";
        String tagVII_I = "FilingDateAndNumber";
        String tagVII_II = "RegistrationDateAndNumber";
        String tagVII_III = "OwnerNameAndAddress";
        String tagVII_IV = "ReproductionMark";
        String tagVII_IV_ImageName = "ImageFileName";
        String tagVII_V = "ReasonsForLimitationNoEffect";

        if ((commonTempFolder == null) || commonTempFolder.isEmpty()) {
            commonTempFolder = "/sharedata/cipo/ecomm/private/ws/tmp/";
        }

        markFileSavedDir = builtReproductionMarkTempUploadFileDir(commonTempFolder);
        if ((groundsOfOppositionList != null) && !groundsOfOppositionList.isEmpty()) {
            for (GroundsOfOpposition groundsOfOpposition : groundsOfOppositionList) {
                XMLTagUtil.appendTagStart(rtnValue, tagVII);

                value = MtsStringUtil.EMPTY;
                if (groundsOfOpposition.getFilingDate() != null) {
                    value = formatValue(convertDateToString(groundsOfOpposition.getFilingDate()));
                }
                if (StringUtils.isNotBlank(groundsOfOpposition.getFilingNumber())) {
                    if (StringUtils.isBlank(value)) {
                        value = groundsOfOpposition.getFilingNumber();
                    } else {
                        value = value + MtsStringUtil.COMMA_SPACE + groundsOfOpposition.getFilingNumber();
                    }

                    value = formatValue(value);
                }
                if (groundsOfOpposition.getPriorityDate() != null) {
                    String priorityDate = formatValue(convertDateToString(groundsOfOpposition.getPriorityDate()));

                    if (StringUtils.isBlank(value)) {
                        value = priorityDate;
                    } else {
                        value = value + MtsStringUtil.COMMA_SPACE + priorityDate;
                    }
                }
                XMLTagUtil.appendTag(rtnValue, tagVII_I, value);

                value = MtsStringUtil.EMPTY;
                if (groundsOfOpposition.getRegistrationDate() != null) {
                    value = formatValue(convertDateToString(groundsOfOpposition.getRegistrationDate()));
                }
                if (StringUtils.isNotBlank(groundsOfOpposition.getRegistrationNumber())) {
                    if (StringUtils.isBlank(value)) {
                        value = groundsOfOpposition.getRegistrationNumber();
                    } else {
                        value = value + MtsStringUtil.COMMA_SPACE + groundsOfOpposition.getRegistrationNumber();
                    }

                    value = formatValue(value);
                }
                XMLTagUtil.appendTag(rtnValue, tagVII_II, value);

                value = formatValue(groundsOfOpposition.getNameAndAddress());
                XMLTagUtil.appendTag(rtnValue, tagVII_III, value);

                TrademarkInfo trademarkInfo = groundsOfOpposition.getTrademarkInfo();
                value = formatValue(
                    trademarkInfo == null ? MtsStringUtil.EMPTY : trademarkInfo.getTrademarkDescription());
                XMLTagUtil.appendTag(rtnValue, tagVII_IV, value);

                // If attachment is empty, just leave this tag to be null. Jasper report will handle the null to be an
                // none printing block.
                Attachment attachement = trademarkInfo == null ? null : trademarkInfo.getTrademarkAttachment();
                if (attachement != null && attachement.getFileContent() != null && attachement.getFileName() != null) {
                    value = formatValue(attachement.getFileName());
                    if ((value != null) && !value.isEmpty()) {
                        XMLTagUtil.appendTag(rtnValue, tagVII_IV_ImageName, value);
                        OutputStream os = null;
                        InputStream is = null;
                        try {
                            os = new FileOutputStream(
                                new File(markFileSavedDir + File.separator + attachement.getFileName()));
                            if (attachement.getFileContent() != null) {
                                DataHandler handler = attachement.getFileContent();
                                is = handler.getInputStream();
                                if (is != null) {
                                    // write content to file
                                    IOUtils.copy(is, os);
                                }
                            }
                        } catch (Exception e) {
                            throw new Exception("Error to convert trademark design to file.", e);
                        } finally {
                            IOUtils.closeQuietly(os);
                            IOUtils.closeQuietly(is);
                        }

                        hasMarkImage = true;
                    }
                }

                value = formatValue(groundsOfOpposition.getNiceClassCode());
                XMLTagUtil.appendTag(rtnValue, tagVII_V, value);

                XMLTagUtil.appendTagClose(rtnValue, tagVII);
            }
        }

    }

    @Override
    public boolean isPdfRequired() {
        return true;
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }

}
