package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;

import javax.xml.bind.JAXBElement;

import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ElectronicBasicSignatureType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ElectronicSignatureType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.NameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PersonNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.SignatureBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.SignatureType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridCancellationType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;

public class MadridCancellation extends OfficeToIbBase implements IOutboundTransaction {

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_CANCELLATION;

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        MadridCancellationType transaction = objectFactory.createMadridCancellationType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // International Registration Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Holder Bag
        transaction.setHolderBag(
            super.mapHolder(processActionApplication.getTmInterestedPartyTypeList(), notificationLanguage));

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // All Goods Services Indicator
        transaction.setAllGoodsServicesIndicator(true);

        // Signature Bag
        // TODO: This bag will be removed from required schema. Once WIPO provide the new schema, CIPO should remove
        // this dummy signature accordingly.
        SignatureBagType signatureBagType = commonObjectFactory.createSignatureBagType();
        SignatureType signatureType = commonObjectFactory.createSignatureType();
        ContactType contactType = commonObjectFactory.createContactType();
        NameType nameType = commonObjectFactory.createNameType();

        PersonNameType personNameType = commonObjectFactory.createPersonNameType();
        personNameType.setPersonFullName(MtsStringUtil.EMPTY);

        nameType.getPersonNameOrOrganizationNameOrEntityName().add(personNameType);

        contactType.setName(nameType);
        signatureType.setContact(contactType);

        ElectronicSignatureType electronicSignatureType = commonObjectFactory.createElectronicSignatureType();
        ElectronicBasicSignatureType electronicBasicSignatureType = commonObjectFactory
            .createElectronicBasicSignatureType();
        electronicBasicSignatureType.setElectronicBasicSignatureText(MtsStringUtil.EMPTY);

        electronicSignatureType.setElectronicBasicSignature(electronicBasicSignatureType);
        signatureType.setElectronicSignature(electronicSignatureType);
        signatureBagType.getSignature().add(signatureType);

        transaction.setSignatureBag(signatureBagType);
        // End of Signature bag.

        JAXBElement<MadridCancellationType> madridobject = objectFactory.createMadridCancellation(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {

        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return false;
    }

}
