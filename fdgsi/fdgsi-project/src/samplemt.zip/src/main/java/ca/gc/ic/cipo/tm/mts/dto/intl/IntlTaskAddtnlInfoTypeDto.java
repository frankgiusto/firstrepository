package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;

public class IntlTaskAddtnlInfoTypeDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -6197058168942628592L;

    private BigDecimal taskAddtnlInfoCtgryId;

    private String taskAddtnlInfoCtgry;

    private String descEn;

    private String descFr;

    public BigDecimal getTaskAddtnlInfoCtgryId() {
        return taskAddtnlInfoCtgryId;
    }

    public void setTaskAddtnlInfoCtgryId(BigDecimal taskAddtnlInfoCtgryId) {
        this.taskAddtnlInfoCtgryId = taskAddtnlInfoCtgryId;
    }

    public String getTaskAddtnlInfoCtgry() {
        return taskAddtnlInfoCtgry;
    }

    public void setTaskAddtnlInfoCtgry(String taskAddtnlInfoCtgry) {
        this.taskAddtnlInfoCtgry = taskAddtnlInfoCtgry;
    }

    public String getDescEn() {
        return descEn;
    }

    public void setDescEn(String descEn) {
        this.descEn = descEn;
    }

    public String getDescFr() {
        return descFr;
    }

    public void setDescFr(String descFr) {
        this.descFr = descFr;
    }
}
