package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;

public class NfsFileName {

    public static final String COURTESY_LETTER_PREFIX = "~Madrid_442";

    public static final Map<TransactionCategory, String> transactionFilenameMap;
    static {
        Map<TransactionCategory, String> aMap = new HashMap<>();
        aMap.put(TransactionCategory.MD_REGISTRATION, "MD-Reg");
        aMap.put(TransactionCategory.MD_SUBSEQUENT_DESIGNATION, "MD-Sub");
        aMap.put(TransactionCategory.MR_RENEWAL, "MRen");
        aMap.put(TransactionCategory.MR_COMPLEMENTARY_RENEWAL, "MRen");
        aMap.put(TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK, "MDT-NonRen");
        aMap.put(TransactionCategory.MDT_NON_RENEWAL_OF_CONTRACTING_PARTY, "MDT-NonRen");
        aMap.put(TransactionCategory.MHR_CHANGE_OF_OWNER, "MHRC-TChgOwn");
        aMap.put(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION, "MPChgOwn");
        aMap.put(TransactionCategory.DESIGNATION_TERMINATION, "MPChgOwn");
        aMap.put(TransactionCategory.MD_MERGER, "MD-Merge");
        aMap.put(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT, "MDT-TCeaseEff");
        aMap.put(TransactionCategory.MPR_PARTIAL_CEASING_OF_EFFECT, "MPR-PCeaseEff");
        aMap.put(TransactionCategory.MDT_TOTAL_CANCELLATION, "MDT-TCan");
        aMap.put(TransactionCategory.MPR_LIMITATION, "MPR-Lim");
        aMap.put(TransactionCategory.MPR_PARTIAL_CANCELLATION, "MPR-PCan");
        aMap.put(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS, "MHRC-ChgNA");
        aMap.put(TransactionCategory.MDT_RENUNCIATION, "MDT-Renun");
        aMap.put(TransactionCategory.MIR_REGISTRATION, "MIRC-Reg");
        aMap.put(TransactionCategory.MBR_APPLICATION_CHANGE, "MBRAC");
        aMap.put(TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE, "MHRC-ChgRep");
        aMap.put(TransactionCategory.MI_IRREGULARITY_NOTIFICATION, "MIrreg");
        aMap.put(TransactionCategory.MC_CORRECTION, "MD-Corr");
        aMap.put(TransactionCategory.MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL, "MD-ROHRD");
        aMap.put(TransactionCategory.MADRID_ABANDONMENT_NOTIFICATION, "MD-Aban");

        transactionFilenameMap = Collections.unmodifiableMap(aMap);
    }

    public static final Map<MadridOutboundTransactionType, String> outboundTransactionFilenameMap;
    static {
        Map<MadridOutboundTransactionType, String> aMap = new HashMap<>();
        aMap.put(MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1, "~Madrid_416");
        aMap.put(MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF2, "~Madrid_417");
        aMap.put(MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3, "~Madrid_418");
        aMap.put(MadridOutboundTransactionType.MADRID_GRANT_PROTECTION_MF4, "~Madrid_419");
        aMap.put(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5, "~Madrid_420");
        aMap.put(MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF6, "~Madrid_421");
        aMap.put(MadridOutboundTransactionType.MADRID_FURTHER_DECISION_MF7, "~Madrid_422");
        aMap.put(MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9, "~Madrid_423");
        aMap.put(MadridOutboundTransactionType.MADRID_INVALIDATION_FULL_MF10, "~Madrid_424");
        aMap.put(MadridOutboundTransactionType.MADRID_INVALIDATION_PARTIAL_MF10, "~Madrid_425");
        aMap.put(MadridOutboundTransactionType.MADRID_LIMITATION_NO_EFFECT, "~Madrid_426");
        aMap.put(MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL, "~Madrid_427");
        aMap.put(MadridOutboundTransactionType.MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL, "~Madrid_428");
        aMap.put(MadridOutboundTransactionType.MADRID_CORRECTION_REQUEST, "~Madrid_429");
        aMap.put(MadridOutboundTransactionType.MADRID_IRREGULARITY, "~Madrid_430");
        aMap.put(MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_DIVISION, "~Madrid_433");
        // aMap.put(MadridOutboundTransactionType.MADRID_POTENTIAL_CEASING_EFFECT, "~Madrid_434");
        aMap.put(MadridOutboundTransactionType.MADRID_IRREGULARITY, "~Madrid_435");

        outboundTransactionFilenameMap = Collections.unmodifiableMap(aMap);
    }
}
