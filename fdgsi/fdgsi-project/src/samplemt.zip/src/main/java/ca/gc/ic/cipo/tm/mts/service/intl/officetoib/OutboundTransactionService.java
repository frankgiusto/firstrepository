package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;
import javax.sql.rowset.serial.SerialBlob;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.intl.dao.IntlAtchmtDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlAtchmtTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlFileFrmtTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlAtchmtTypeCode;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlPkgSchmaVrsnType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.mts.Attachment;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.NfsFileTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IntrepidDocumentDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.enums.OutboundTransactionTypes;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionUserGroupMap;
import ca.gc.ic.cipo.tm.mts.enums.ProcessActionUserTaskMap;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;

@Service
public class OutboundTransactionService extends MadridTransactionService implements IOutboundTransactionService {

    private static final Logger logger = LoggerFactory.getLogger(OutboundTransactionService.class);

    private final static int ONLY_ONE = 0; // There is only 1 task in collection

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IntlPkgTranTypeDao intlPackageTranTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao intlPackageSchemaVersionDao;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IntlAtchmtDao intlAtchmtDao;

    @Autowired
    private IntlAtchmtTypeDao intlAtchmtTypeDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlFileFrmtTypeDao intlFileFrmtTypeDao;

    @Autowired
    private ITaskService taskService;

    @Value("#{environment['mts.reporting.service.host.name']}")
    private String reportServiceHost;

    @Value("#{environment['mts.rgs.polling.attempts']}")
    private Integer pollingAttempts;

    private static final boolean OUTBOUND_ONLY = true;

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public OfficeToIbTransactionResponse createAutoOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                       OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {
        return processOutboundTransaction(processActionsMeta, outboundTransactionDto);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public OfficeToIbTransactionResponse createManualOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                         OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {
        return processOutboundTransaction(processActionsMeta, outboundTransactionDto);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public OfficeToIbTransactionResponse createAutoOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                       OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {
        return processOutboundTransaction(outboundTransactionRequest, outboundTransactionDto);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public OfficeToIbTransactionResponse createManualOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                         OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {
        return processOutboundTransaction(outboundTransactionRequest, outboundTransactionDto);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public OfficeToIbTransactionResponse createOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                   OutboundTransactionDto outboundTransactionDto,
                                                                   ProcessManualReportRequest manualReportRequest)
        throws CIPOServiceFault {

        IOutboundTransaction outboundTransaction = OutboundTransactionTypes
            .valueOf(outboundTransactionRequest.getProcessActionCodeType().name()).createOutboundTransaction();

        OfficeToIbTransactionResponse officeToIbTransactionResponse = new OfficeToIbTransactionResponse();

        // Create International Transaction - INTL_IR_TRAN
        IntlIrTran intlIrTran = null;
        IntlIrTranDto intlIrTranDto = null;
        // Create XML Transaction
        ByteArrayOutputStream transactionOutputStream = null;

        // Process Automatic Transaction
        intlIrTran = createOutboundIntlIrTransaction(outboundTransaction.getMadridOutboundTransactionType(),
            StatusType.MTS_OUTBOUND_TRANSACTION_CREATED, outboundTransactionRequest.getFileNumber(),
            outboundTransactionRequest.getWipoReferenceNumber(), outboundTransactionDto.getIntlRegNo());

        intlIrTranDto = internationalDTOFactory.getIntlIrTranDto(intlIrTran);
        logger.debug("created intlIrTran with transaction id: " + intlIrTranDto.getIrTranId());

        try {
            transactionOutputStream = outboundTransaction.createOutboundTransaction(outboundTransactionDto,
                outboundTransactionRequest, intlIrTranDto, marshallingService);
        } catch (Exception exception) {
            logger.error("Error in createOutboundTransaction", exception);
            throwCIPOFault(exception);
        }

        updateOutboundXml(transactionOutputStream, intlIrTran, StatusType.MPS_READY_FOR_EXPORT);

        intlIrTranDao.save(intlIrTran);

        officeToIbTransactionResponse.setIrTranId(intlIrTranDto.getIrTranId());

        // Generate PDF with reporting service if applicable
        if (outboundTransaction.isPdfRequired()) {
            logger.debug("Generating pdf");

            submitRGSReport(intlIrTranDto, outboundTransaction, manualReportRequest);

            internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                outboundTransactionRequest.getFileNumber(), outboundTransactionRequest.getExtensionCounter(),
                NfsFileTypeDto.OUTBOUND_ONLY);

        }

        return officeToIbTransactionResponse;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public OfficeToIbTransactionResponse updateManualOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                         OutboundTransactionDto outboundTransactionDto,
                                                                         ProcessManualReportRequest manualReportRequest)
        throws CIPOServiceFault {

        IOutboundTransaction outboundTransaction = OutboundTransactionTypes
            .valueOf(outboundTransactionRequest.getProcessActionCodeType().name()).createOutboundTransaction();

        OfficeToIbTransactionResponse officeToIbTransactionResponse = new OfficeToIbTransactionResponse();

        // get outbound transaction
        IntlIrTran intlIrTran = getOutboundIntlIrTransaction(manualReportRequest.getTransactionId());

        StatusType status = StatusType.MPS_READY_FOR_EXPORT;
        updateOutboundStatus(intlIrTran, status);

        // add attachments
        if (manualReportRequest.getAttachmentList() != null
            && manualReportRequest.getAttachmentList().getAttachmentListBag() != null
            && !manualReportRequest.getAttachmentList().getAttachmentListBag().isEmpty()) {
            for (Attachment attachment : manualReportRequest.getAttachmentList().getAttachmentListBag()) {
                boolean attachmentExisted = false;
                List<IntlAtchmt> atchmtList = intlAtchmtDao.getAtchmtListByTranId(intlIrTran.getIrTranId());
                // Check if attachment already existed for this transaction. Or we will just discard it.
                for (IntlAtchmt atchmt : atchmtList) {
                    if (StringUtils.equalsIgnoreCase(atchmt.getFileName(), attachment.getFileName())) {
                        attachmentExisted = true;
                        break;
                    }
                }

                if (!attachmentExisted) {
                    IntlAtchmt intlAtchmt = this.createAttachment(intlIrTran,
                        getDataHandlerBlob(attachment.getFileContent()), attachment.getFileName(),
                        IntlFileFrmtTypeEnum.getFormatByType(attachment.getFileName()
                            .substring(attachment.getFileName().indexOf(MtsStringUtil.DOT) + 1)),
                        IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS);
                    intlIrTran.getIntlAtchmts().add(intlAtchmt);
                }

            }
        }

        if (outboundTransactionRequest
            .getProcessActionCodeType() == (ProcessActionCodeType.MADRID_CEASING_EFFECT_TOTAL_MF_9)) {
            IntlPkgTranType tranType = new IntlPkgTranType();
            tranType.setPkgTranCtgryId(
                new BigDecimal(MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9.getTransactionTypeId()));
            tranType.setTranCtgry(MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9.name());
            intlIrTran.setIntlPkgTranType(tranType);
        }

        intlIrTranDao.save(intlIrTran);

        // Update XML Transaction
        IntlIrTranDto intlIrTranDto = internationalDTOFactory.getIntlIrTranDto(intlIrTran);

        int fileNum = outboundTransactionRequest.getFileNumber().intValue();
        Integer extensioncounter = Integer.parseInt(outboundTransactionRequest.getExtensionCounter());

        Date intRegDate = intrepidCommonService.getInternationRegistrationDate(fileNum, extensioncounter);

        outboundTransactionRequest.setInternationalRegistrationDate(intRegDate);

        ByteArrayOutputStream transactionOutputStream = null;
        try {
            transactionOutputStream = outboundTransaction.createOutboundTransaction(outboundTransactionDto,
                outboundTransactionRequest, intlIrTranDto, marshallingService);
        } catch (Exception exception) {
            logger.error("Error in createOutboundTransaction", exception);
            throwCIPOFault(exception);
        }
        updateOutboundXml(transactionOutputStream, intlIrTran, status);

        officeToIbTransactionResponse.setIrTranId(intlIrTranDto.getIrTranId());

        // Generate PDF with reporting service if applicable
        if (outboundTransaction.isPdfRequired()) {
            logger.debug("Generating pdf");

            submitRGSReport(intlIrTranDto, outboundTransaction, manualReportRequest);

            internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                outboundTransactionRequest.getFileNumber(), outboundTransactionRequest.getExtensionCounter(),
                NfsFileTypeDto.OUTBOUND_ONLY);

        }

        return officeToIbTransactionResponse;
    }

    @Override
    @Transactional
    public void updateTransactionXMLWithStatus(ByteArrayOutputStream xmlOutputStream, IntlIrTranDto transactionDto,
                                               StatusType transactionStatus)
        throws CIPOServiceFault {

        IntlIrTran intlIrTran = intlIrTranDao.getIrTranById(transactionDto.getIrTranId());
        updateOutboundXml(xmlOutputStream, intlIrTran, transactionStatus);
        intlIrTranDao.save(intlIrTran);
    }

    private void submitRGSReport(IntlIrTranDto intlIrTranDto, IOutboundTransaction outboundTransaction, Object inObject)
        throws CIPOServiceFault {

        logger.debug("Generating pdf");

        ByteArrayOutputStream transactionOutputStream = null;
        IReportingService reportingService = (IReportingService) outboundTransaction;

        try {
            // Add the jobId to the response.
            // TODO remove reportId from officeToIb response as MWE will not be doing the polling.
            MadridReportResponse madridReportResponse = reportingService.generateReport(transactionOutputStream,
                intlIrTranDto.getIrTranId(), marshallingService, reportServiceHost, inObject);
            logger.debug("submmited report request having job id: " + madridReportResponse.getJobId());

            monitorRGSReportCompletion(pollingAttempts, madridReportResponse, reportServiceHost);

            generateReportNotification(madridReportResponse, intlIrTranDto.getIrTranId());

        } catch (Exception exception) {
            logger.error("Error in submitRGSReport", exception);
            throwCIPOFault(exception);
        }
    }

    /**
     * Processes the outbound transaction
     *
     * @param processActionsMeta
     * @param outboundTransactionDto the outboundTransaction DTO
     * @param autoTransaction true if the transaction is an automatic or false if manual
     * @return
     * @throws CIPOServiceFault
     */
    private OfficeToIbTransactionResponse processOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                     OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {

        IOutboundTransaction outboundTransaction = OutboundTransactionTypes
            .valueOf(processActionsMeta.getProcessActionCodeType().name()).createOutboundTransaction();

        OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
        outboundTransactionRequest.setFileNumber(processActionsMeta.getFileNumber());
        outboundTransactionRequest.setExtensionCounter(processActionsMeta.getExtensionCounter());
        outboundTransactionRequest.setAdditionalInfo(processActionsMeta.getAdditionalInfo());
        outboundTransactionRequest.setIrregularityResend(processActionsMeta.isIrregularityResend());
        outboundTransactionRequest.setProcessActionDate(processActionsMeta.getProcessDate());
        outboundTransactionRequest.setWipoReferenceNumber(processActionsMeta.getWipoReferenceNumber());
        if (processActionsMeta.getProcessActionCodeType() != null) {
            outboundTransactionRequest.setProcessActionCodeType(processActionsMeta.getProcessActionCodeType());
        }

        OfficeToIbTransactionResponse officeToIbTransactionResponse = this
            .processOutboundTransaction(outboundTransactionRequest, outboundTransaction, outboundTransactionDto);

        // Add an action record if applicable and delete process action
        intrepidCommonService.completeProcessAction(processActionsMeta);

        return officeToIbTransactionResponse;
    }

    @Override
    @Transactional
    public OfficeToIbTransactionResponse createAutoOutboundTransaction(ProcessActionsMeta processActionsMeta,
                                                                       OutboundTransactionRequest outboundTransactionRequest,
                                                                       OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {

        OfficeToIbTransactionResponse officeToIbTransactionResponse = processOutboundTransaction(
            outboundTransactionRequest, outboundTransactionDto);

        // Add an action record if applicable and delete process action
        if (processActionsMeta != null && processActionsMeta.isIrregularityResend()) {
            intrepidCommonService.completeIrregularityProcessAction(processActionsMeta);
        } else {
            intrepidCommonService.completeProcessAction(processActionsMeta);
        }

        return officeToIbTransactionResponse;
    }

    /**
     * Process the outbound transaction
     *
     * @param outboundTransactionRequest
     * @param outboundTransactionDto the outboundTransaction DTO
     * @param autoTransaction true if the transaction is an automatic or false if manual
     * @param transactionId the Transaction ID of the request. Null if we are creating
     * @return
     * @throws CIPOServiceFault
     */
    private OfficeToIbTransactionResponse processOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                     OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {

        IOutboundTransaction outboundTransaction = OutboundTransactionTypes
            .valueOf(outboundTransactionRequest.getProcessActionCodeType().name()).createOutboundTransaction();

        OfficeToIbTransactionResponse officeToIbTransactionResponse = this
            .processOutboundTransaction(outboundTransactionRequest, outboundTransaction, outboundTransactionDto);

        return officeToIbTransactionResponse;
    }

    private OfficeToIbTransactionResponse processOutboundTransaction(OutboundTransactionRequest outboundTransactionRequest,
                                                                     IOutboundTransaction outboundTransaction,
                                                                     OutboundTransactionDto outboundTransactionDto)
        throws CIPOServiceFault {

        OfficeToIbTransactionResponse officeToIbTransactionResponse = new OfficeToIbTransactionResponse();

        List<IntrepidDocumentDto> intrepidDocuments = this.checkIntrepidDocument(outboundTransactionRequest,
            outboundTransaction, officeToIbTransactionResponse);

        // Create International Transaction - INTL_IR_TRAN
        IntlIrTran intlIrTran = null;
        IntlIrTranDto intlIrTranDto = null;
        // Create XML Transaction
        ByteArrayOutputStream transactionOutputStream = null;

        // Process Automatic Transaction
        intlIrTran = createOutboundIntlIrTransaction(outboundTransaction.getMadridOutboundTransactionType(),
            StatusType.MTS_OUTBOUND_TRANSACTION_CREATED, outboundTransactionRequest.getFileNumber(),
            outboundTransactionRequest.getWipoReferenceNumber(), outboundTransactionDto.getIntlRegNo());

        if (outboundTransactionRequest.getProcessActionDate() != null) {
            intlIrTran.setIntlRecordEfctvDt(outboundTransactionRequest.getProcessActionDate());
        } else {
            intlIrTran.setIntlRecordEfctvDt(new Timestamp(System.currentTimeMillis()));
        }
        intlIrTranDto = internationalDTOFactory.getIntlIrTranDto(intlIrTran);
        logger.debug("created intlIrTran with transaction id: " + intlIrTranDto.getIrTranId());

        try {
            transactionOutputStream = outboundTransaction.createOutboundTransaction(outboundTransactionDto,
                outboundTransactionRequest, intlIrTranDto, marshallingService);
        } catch (Exception exception) {
            logger.error("Error creating outbound transaction", exception);
            throwCIPOFault(exception);
        }

        StatusType status = setTransactionStatus(outboundTransaction, officeToIbTransactionResponse);

        updateOutboundXml(transactionOutputStream, intlIrTran, status);

        if (!intrepidDocuments.isEmpty()) {
            // Create the Attachment
            for (IntrepidDocumentDto intrepidDocument : intrepidDocuments) {
                IntlAtchmt intlAtchmt = this.createAttachment(intlIrTran, intrepidDocument.getBlob(),
                    intrepidDocument.getFileName(), intrepidDocument.getFileFormat(),
                    IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS_RECEIVED);

                intlIrTran.getIntlAtchmts().add(intlAtchmt);
            }

        }

        intlIrTranDao.save(intlIrTran);

        officeToIbTransactionResponse.setIrTranId(intlIrTranDto.getIrTranId());

        // Generate PDF with reporting service if applicable
        if (outboundTransaction.isPdfRequired() && status.equals(StatusType.MPS_READY_FOR_EXPORT)) {
            logger.debug("Generating pdf");

            submitRGSReport(intlIrTranDto, outboundTransaction, outboundTransactionDto);

            // Send generated mf form to intrepid nfs TODO - need prefix mapping rules
            internationalService.sendFileToIntrepidNFS(intlIrTran.getIrTranId(),
                outboundTransactionRequest.getFileNumber(), outboundTransactionRequest.getExtensionCounter(),
                NfsFileTypeDto.OUTBOUND_ONLY);
        }

        return officeToIbTransactionResponse;
    }

    /**
     * Check intrepid document. If this is a regeneration of the outbound transaction based on an Irregularity, don't
     * look for the intrepid document name in the additional info as we are not processing from a Process Action record.
     *
     * @param outboundTransactionRequest the outbound transaction request
     * @param outboundTransaction the outbound transaction
     * @param officeToIbTransactionResponse the office to ib transaction response
     * @return the intrepid document dto
     * @throws CIPOServiceFault
     */
    private List<IntrepidDocumentDto> checkIntrepidDocument(OutboundTransactionRequest outboundTransactionRequest,
                                                            IOutboundTransaction outboundTransaction,
                                                            OfficeToIbTransactionResponse officeToIbTransactionResponse)
        throws CIPOServiceFault {

        List<IntrepidDocumentDto> intrepidDocuments = new ArrayList<IntrepidDocumentDto>();
        if (null == outboundTransactionRequest.getIrregularityResend()
            || !outboundTransactionRequest.getIrregularityResend()) {
            // get intrepid document if applicable
            intrepidDocuments = getIntrepidDocumentInfo(outboundTransaction, outboundTransactionRequest);
        }
        return intrepidDocuments;
    }

    private StatusType setTransactionStatus(IOutboundTransaction outboundTransaction,
                                            OfficeToIbTransactionResponse officeToIbTransactionResponse) {

        // TODO add more Manual MF Forms below as required.
        if (outboundTransaction
            .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3
            // why is this here? || outboundTransaction
            // .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_LIMITATION_NO_EFFECT
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_CEASING_EFFECT_MF9
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_DIVISION
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_NEW_BASIC_APPLICATION_MERGER_EXT) {

            return StatusType.IN_PROGRESS_OUTBOUND_TRANSACTION;
        }

        return StatusType.MPS_READY_FOR_EXPORT;
    }

    @Override
    public ManualProcessResponse createConsoleTask(ProcessActionsMeta processActionsMeta, BigDecimal irTranId,
                                                   Integer oppCaseNum) {

        ManualProcessResponse manualProcessResponse = new ManualProcessResponse();
        ConsoleTaskList consoleTask = intrepidDTOFactory.getConsoleTaskList(processActionsMeta);
        ConsoleTaskMeta consoleTaskMeta = consoleTask.getTaskListBag().get(ONLY_ONE);
        if (null != irTranId) {
            consoleTaskMeta.getTransactionIds().add(irTranId);
        }

        if (oppCaseNum != null) {
            IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
            IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
            intlTaskAddtnlInfoTypeDto
                .setTaskAddtnlInfoCtgryId(BigDecimal.valueOf(TaskAddtnlInfoType.OPPOSITION_CASE_NUMBER.getValue()));
            intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
            intlTaskAddtnlInfoDto.setAddtnlInfo(oppCaseNum.toString());
            consoleTaskMeta.getAdditionalInfos().add(intlTaskAddtnlInfoDto);

        }

        consoleTaskMeta.setUserTaskStatus(TaskStatusType.UNPROCESSED.getValue()); // default

        consoleTaskMeta.setProcessActionDate(processActionsMeta.getProcessDate());

        if (ProcessActionUserTaskMap.processActionUserTaskMap
            .containsKey(processActionsMeta.getProcessActionCodeType())) {

            consoleTaskMeta.setUserTaskType(ProcessActionUserTaskMap.processActionUserTaskMap
                .get(processActionsMeta.getProcessActionCodeType()).getValue());

            if ((processActionsMeta.getAdditionalInfo() != null) && processActionsMeta.getAdditionalInfo()
                .startsWith(ManualReportUtil.getResponseToIrregularityMcKey())) {
                processActionsMeta.setAdditionalInfo(ManualReportUtil.getResponseToIrregularityMcKey());
            }

            // Leave what's been set valid as is.
            if (SectionAuthority.contains(processActionsMeta.getAuthorityId())) {
                consoleTaskMeta.setAuthorityId(processActionsMeta.getAuthorityId());
                // Set invalid authorityId which is not Madrid recognized groupId.
            } else {
                consoleTaskMeta.setAuthorityId(ProcessActionUserGroupMap.processActionUserGroupMap
                    .get(processActionsMeta.getProcessActionCodeType()));
            }

        } else {
            logger.error(
                "Cannot find User Task Type for process action: " + processActionsMeta.getProcessActionCodeType());
        }

        manualProcessResponse.getConsoleTaskBag().addAll(taskService.createUserTask(consoleTask));
        return manualProcessResponse;
    }

    @Transactional(value = "tmIntlTransactionManager", rollbackFor = Exception.class)
    public void generateReportNotification(MadridReportResponse madridReportResponse, BigDecimal irTranId)
        throws CIPOServiceFault {

        // This method will be called when an RGS report (by Job ID) has completed. In most
        // cases MTS will retrieve the report and store it as an attachment to either a Transaction or Package
        logger.debug(String.format(
            "MTS received notification that RGS report Job ID %s for Transaction ID: %s is ready for storage",
            madridReportResponse.getJobId(), irTranId));

        IntlIrTran irTransaction = intlIrTranDao.getIrTranById(irTranId);

        // MF6 and MF3a will have intrepid documents already

        // Create the Attachment
        IntlAtchmt intlAtchmt = this.createAttachment(irTransaction, getReportBlob(madridReportResponse.getJobId()),
            madridReportResponse.getReportName(), IntlFileFrmtTypeEnum.PDF, IntlAtchmtTypeCode.OFFICE_TO_IB_DOCUMENTS);

        // save the transaction
        irTransaction.getIntlAtchmts().add(intlAtchmt);
        intlIrTranDao.save(irTransaction);

    }

    private List<IntrepidDocumentDto> getIntrepidDocumentInfo(IOutboundTransaction outboundTransaction,
                                                              OutboundTransactionRequest outboundTransactionRequest)
        throws CIPOServiceFault {

        boolean hasIntrepidDocument = false;
        List<IntrepidDocumentDto> intrepidDocuments = new ArrayList<IntrepidDocumentDto>();
        if (outboundTransaction
            .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_GRANT_PROTECTION_MF4
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF5
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_FINAL_DECISION_MF6
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_PROVISIONAL_REFUSAL_MF3) {

            if (StringUtils.isBlank(outboundTransactionRequest.getAdditionalInfo())) {
                logger.error("Expecting intrepid document in process action additional info!");
                return intrepidDocuments;
            }

            hasIntrepidDocument = true;

        } else if (outboundTransaction
            .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_INVALIDATION_FULL_MF10
            || outboundTransaction
                .getMadridOutboundTransactionType() == MadridOutboundTransactionType.MADRID_INVALIDATION_PARTIAL_MF10) {

            if (StringUtils.isBlank(outboundTransactionRequest.getAdditionalInfo())) {
                logger.info("no intrepid document in process action additional info for MadridInvalidationType");
            } else {
                hasIntrepidDocument = true;
            }
        }

        if (hasIntrepidDocument) {
            IntrepidDocumentDto intrepidDocumentDto = null;
            String orignalAddInfo = outboundTransactionRequest.getAdditionalInfo();
            String[] additionalInfos = MtsStringUtil.splitDocName(outboundTransactionRequest.getAdditionalInfo());
            for (String additionalInfo : additionalInfos) {
                intrepidDocumentDto = new IntrepidDocumentDto();
                intrepidDocumentDto.setFileName(additionalInfo.trim());
                intrepidDocumentDto.setFileFormat(IntlFileFrmtTypeEnum.getFormatByType(intrepidDocumentDto.getFileName()
                    .substring(intrepidDocumentDto.getFileName().indexOf(MtsStringUtil.DOT) + 1)));
                outboundTransactionRequest.setAdditionalInfo(additionalInfo);
                intrepidDocumentDto.setBlob(getIntrepidDocument(outboundTransactionRequest));
                intrepidDocuments.add(intrepidDocumentDto);
            }
            outboundTransactionRequest.setAdditionalInfo(orignalAddInfo);
        }

        return intrepidDocuments;
    }

    @Override
    public IntlAtchmt createAttachment(IntlIrTran irTransaction, Blob document, String fileName,
                                       IntlFileFrmtTypeEnum fileFormat, IntlAtchmtTypeCode attachmentType) {
        // Create the Attachment
        IntlAtchmt intlAtchmt = new IntlAtchmt();
        intlAtchmt.setIntlIrTran(irTransaction);
        intlAtchmt.setFileContent(document);

        intlAtchmt.setFileName(fileName);

        intlAtchmt.setIntlAtchmtType(intlAtchmtTypeDao.getAtchmtTypeById(Long.valueOf(attachmentType.codeValue())));

        // The file format will be PDF or DOC
        intlAtchmt.setIntlFileFrmtType(intlFileFrmtTypeDao.getFileFrmtTypeById(Long.valueOf(fileFormat.codeValue())));
        intlAtchmt.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));

        // save the attachment
        intlAtchmtDao.save(intlAtchmt);

        return intlAtchmt;
    }

    private IntlIrTran getOutboundIntlIrTransaction(BigDecimal transactionId) throws MTSServiceFault {

        IntlIrTran intlTransaction = intlIrTranDao.getById(transactionId);
        intlTransaction.setIntlPkgTranType(
            intlPackageTranTypeDao.getTranTypeById(BigDecimal.valueOf(intlTransaction.getIntlPkgTranType().getId())));
        intlTransaction.setIntlPkgSchmaVrsn(intlPackageSchemaVersionDao
            .getPkgSchmaVrsnById(BigDecimal.valueOf(IntlPkgSchmaVrsnType.IB_TO_OFFICE_TRANSACTION_V3.getValue())));
        intlTransaction.setIntlStatusType(
            intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(intlTransaction.getIntlStatusType().getId())));

        return intlTransaction;
    }

    private IntlIrTran createOutboundIntlIrTransaction(MadridOutboundTransactionType madridOutboundTransactionType,
                                                       StatusType transactionStatus, BigDecimal fileNumber,
                                                       String wipoRefNum, String registrationNumber)
        throws CIPOServiceFault {

        Timestamp timestamp = new Timestamp(new Date().getTime());

        Blob blob = null;

        try {
            blob = new SerialBlob("placeholder".getBytes());
        } catch (Exception exception) {
            logger.error("Error in createOutboundIntlIrTransaction", exception);
            throwCIPOFault(exception);
        }

        IntlIrTran intlTransaction = new IntlIrTran();
        intlTransaction.setCreatedTmstmp(timestamp);
        intlTransaction.setIntlRegNo(registrationNumber);
        intlTransaction.setDmstcApltnNbr(String.valueOf(fileNumber));
        intlTransaction.setIntlPkgTranType(intlPackageTranTypeDao
            .getTranTypeById(BigDecimal.valueOf(madridOutboundTransactionType.getTransactionTypeId())));
        intlTransaction.setIntlPkgSchmaVrsn(intlPackageSchemaVersionDao
            .getPkgSchmaVrsnById(BigDecimal.valueOf(IntlPkgSchmaVrsnType.IB_TO_OFFICE_TRANSACTION_V3.getValue())));
        intlTransaction
            .setIntlStatusType(intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(transactionStatus.getValue())));
        intlTransaction.setXmlContent(blob);
        intlTransaction.setOfficeRefId(wipoRefNum);

        intlIrTranDao.save(intlTransaction);

        return intlTransaction;
    }

    private void updateOutboundStatus(IntlIrTran intlIrTran, StatusType transactionStatus) throws MTSServiceFault {

        intlIrTran
            .setIntlStatusType(intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(transactionStatus.getValue())));
    }

    private void updateOutboundXml(ByteArrayOutputStream xmlOutputStream, IntlIrTran intlIrTran,
                                   StatusType transactionStatus)
        throws CIPOServiceFault {

        Blob blob = null;

        try {
            blob = new SerialBlob(xmlOutputStream.toByteArray());
        } catch (Exception exception) {
            logger.error("Error in updateOutboundXml", exception);
            throwCIPOFault(exception);
        }

        intlIrTran.setXmlContent(blob);
        intlIrTran
            .setIntlStatusType(intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(transactionStatus.getValue())));
    }

    private Blob getDataHandlerBlob(DataHandler dataHandler) throws CIPOServiceFault {
        Blob blob = null;
        // Get the completed report.
        try {
            InputStream myReport = dataHandler.getInputStream();
            byte[] buffer = new byte[myReport.available()];
            myReport.read(buffer);

            // Add the report to the blob type
            blob = new SerialBlob(buffer);

        } catch (Exception exception) {
            logger.error("Error in getDataHandlerBlob", exception);
            throwCIPOFault(exception);
        }
        return blob;
    }

    private Blob getReportBlob(String reportJobId) throws CIPOServiceFault {
        // The RGS host is looked up from the configuration
        ReportGenerationWsClient rgsClient = new ReportGenerationWsClient(reportServiceHost);
        Blob blob = null;

        // Get the completed report.
        try {
            InputStream myReport = rgsClient.getGeneratedReport(reportJobId);
            byte[] buffer = new byte[myReport.available()];
            myReport.read(buffer);

            // Add the report to the blob type
            blob = new SerialBlob(buffer);

        } catch (Exception exception) {
            logger.error("Error in getReportBlob", exception);
            throwCIPOFault(exception);
        }
        return blob;
    }

    private Blob getIntrepidDocument(OutboundTransactionRequest outboundTransactionRequest) throws CIPOServiceFault {

        try {
            return intlAtchmtDao.getIntrepidDocument(outboundTransactionRequest.getFileNumber(),
                Integer.valueOf(outboundTransactionRequest.getExtensionCounter()),
                outboundTransactionRequest.getAdditionalInfo().trim());
        } catch (Exception exception) {
            logger.error("Error in getIntrepidDocument", exception);
            throwCIPOFault(exception);
        }
        return null;

    }

}
