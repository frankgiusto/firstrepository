/*
 *
 */
package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.enumerator.MailType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.LanguageType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.UpdateHolderContactDetailsResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.InterestedPartyDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import wipo.HolderInfo;

// TODO: Auto-generated Javadoc
/**
 * The Interface IIntrepidCommonService.
 */
public interface IIntrepidCommonService {

    /**
     * Find duplicate mark.
     *
     * @param irNumber the ir number
     * @param recordIdentifier the record identifier
     * @param irTranId the ir tran id
     * @return the list of console task ids
     */
    public List<ConsoleTaskResponse> findDuplicateMark(String irNumber, String recordIdentifier, BigDecimal irTranId);

    /**
     * Check for existing marks. This is called for D/O automatic processing flows.
     *
     * @param irTranId the ir tran id
     * @return the list of console task ids
     * @throws CIPOServiceFault the CIPO service fault
     */
    public List<ConsoleTaskResponse> checkforExistingMarks(BigDecimal irTranId) throws CIPOServiceFault;

    /**
     * Check for inactive marks.
     *
     * @param irNumber the ir number
     * @param irTranId the ir tran id
     * @return the list of console task ids
     */
    public List<ConsoleTaskResponse> checkforInactiveMarks(String irNumber, BigDecimal irTranId);

    /**
     * Gets the madrid application details.
     *
     * @param processActionsMeta the process actions meta
     * @return the madrid applications
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OutboundTransactionDto getMadridApplicationDetails(ProcessActionsMeta processActionsMeta)
        throws CIPOServiceFault;

    /**
     * Gets the Madrid Application details populated with provided basic mark list
     *
     * @param irNumber
     * @param fileNumber
     * @param extensionCounter
     * @param basicMarkList
     * @return
     * @throws CIPOServiceFault
     */
    public OutboundTransactionDto getMadridApplicationDetails(String irNumber, BigDecimal fileNumber,
                                                              String extensionCounter,
                                                              List<ca.gc.ic.cipo.tm.mts.ApplicationNumber> basicMarkList)
        throws CIPOServiceFault;

    /**
     * Gets the madrid application details.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @return the madrid application details
     * @throws CIPOServiceFault the CIPO service fault
     */
    public OutboundTransactionDto getMadridApplicationDetails(BigDecimal fileNumber, String extensionCounter)
        throws CIPOServiceFault;

    /**
     * Check before automated process.
     *
     * @param irTranId the ir tran id
     * @return the list
     * @throws CIPOServiceFault the CIPO service fault
     */
    public List<ConsoleTaskResponse> checkBeforeAutomatedProcess(BigDecimal irTranId) throws CIPOServiceFault;

    /**
     * Complete the processing of the process action. This involves creating an Action record depending on the process
     * action code and then deleting the process action record.
     *
     * @param processActionsMeta the process actions meta
     */
    public void completeProcessAction(ProcessActionsMeta processActionsMeta);

    /**
     * Gets the claims by goods services. Simply calls TIRS to return its results.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @return the claims by goods services
     * @throws CIPOServiceFault the CIPO service fault
     */
    public List<GoodsServicesClaimsType> getClaimsByGoodsServices(BigDecimal fileNumber, String extensionCounter)
        throws CIPOServiceFault;

    /**
     * Check for notifications. This is currently being use by Partial Ownership Change only. If other use cases require
     * this, we will update the request object to identify use case making request.
     *
     * @param request the request
     * @param originalApplicationFileNumber the original application file number
     * @param newApplicationFileNumber the new application file number
     * @return the console task ids response
     */
    @Transactional
    public List<ConsoleTaskResponse> checkForPartialOwnershipChangeNotifications(CheckForNotificationsRequest request,
                                                                                 Integer originalApplicationFileNumber,
                                                                                 Integer newApplicationFileNumber);

    /**
     * Check for notifications.
     *
     * @param request the request
     * @param applicationFileNumber the application file number
     * @param intlIrTranDto
     * @param transaction
     * @param userTaskType
     * @return the console task ids response
     * @throws CIPOServiceFault
     */
    @Transactional
    public List<ConsoleTaskResponse> checkForNotifications(CheckForNotificationsRequest request,
                                                           Integer applicationFileNumber, IntlIrTranDto intlIrTranDto,
                                                           Object transaction, UserTaskType userTaskType)
        throws CIPOServiceFault;

    /**
     * Get international registration date where action type is 228 (international registration).
     *
     * @param fileNum
     * @param extensioncounter
     * @return Date
     */
    @Transactional
    public Date getInternationRegistrationDate(int fileNum, Integer extensioncounter);

    /**
     *
     * @param fileNumber
     * @param mailType
     * @param authorityId
     */
    @Transactional
    public void updateMailProcessedStatus(BigDecimal fileNumber, MailType mailType, String authorityId);

    /**
     * get the contact holder info from Wipo
     *
     * @param intlRegNumber the intl ir of the contact
     * @param HolderInfo the holder info of the contact
     */

    public HolderInfo getHolderInfoFromWipo(String intlRegNumber) throws CIPOServiceFault;

    /**
     * Update the contact details for all application holders
     *
     * @param intlIrTran the intl ir tran that needs to be updated
     * @param intlIrTran (optional and can be set to null) the intl ir task whose status needs to be set to processed
     */
    @Transactional
    public UpdateHolderContactDetailsResponse updateHolderContactDetails(BigDecimal irTranId, BigDecimal taskId)
        throws CIPOServiceFault;

    /**
     * Gets the intrepid files for an International Registration Number. Collection identifies which application is
     * active or inactive.
     *
     * @param intlIrTran the intl ir tran
     * @return the intrepid files
     */
    public Map<ApplicationDto, UserTaskType> getIntrepidFiles(IntlIrTranDto intlIrTran);

    /**
     * Gets the intrepid file for an IR Number. Application is locked . Alternate response object.
     *
     * @param irNumber the ir number
     * @return the intrepid locked files
     */
    public List<Integer> getLockedIntrepidFiles(String irNumber);

    /**
     * Check for marks. Returns a list of marks associated to an ir number.
     *
     * @param irNumber the ir number
     * @param irTranId the ir tran id
     * @return the list of applications files locked for processing
     */
    public List<Integer> checkforMarks(String irNumber, BigDecimal irTranId);

    /**
     * Gets the file numbers.
     *
     * @param irNumber the ir number
     * @return the file numbers
     */
    public List<Integer> getFileNumbers(String irNumber);

    /**
     * Gets the application DTO
     *
     * @param fileNumber the file number
     * @return the application
     */
    public ApplicationDto getApplication(Integer fileNumber);

    /**
     * Gets the application model.
     *
     * @param fileNumber the file number
     * @return the application model
     */
    public Application getApplicationModel(Integer fileNumber);

    /**
     * Gets the application by ir id.
     *
     * @param irNumber the ir number
     * @param recordIdentifier the record identifier
     * @return the application by ir id
     * @throws MTSServiceFault the MTS service fault
     */
    public Application getApplicationByIrId(String irNumber, String recordIdentifier) throws MTSServiceFault;

    /**
     * Acquire trademark lock.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @param userName the user name
     */
    public void acquireTrademarkLock(Integer fileNumber, Integer extensionCounter, String userName);

    /**
     * Release trademark lock.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     */
    public void releaseTrademarkLock(Integer fileNumber, Integer extensionCounter);

    /**
     * Check opposition case.
     *
     * @param fileNumber the BigDecimal
     * @return the string
     */
    public String checkOppositionCase(BigDecimal fileNumber);

    /**
     * Gets the process action count.
     *
     * @return the process action count
     * @throws Exception the exception
     */
    public int getProcessActionCount() throws Exception;

    /**
     * Lock application for task.
     *
     * @param fileNumber the file number
     * @return true, if successful
     */
    public boolean lockApplicationForTask(Integer fileNumber);

    /**
     * Unlock application for task.
     *
     * @param fileNumber the file number
     * @return true, if successful
     */
    public boolean unlockApplicationForTask(Integer fileNumber);

    /**
     * Unlock application for tasks.
     *
     * @param taskList the task list
     */
    public void unlockApplicationForTasks(List<Integer> taskList);

    /**
     *
     * @param userId
     * @return section authority id by userID
     * @throws CIPOServiceFault
     */
    public String getSectionAuthorityId(String userId) throws CIPOServiceFault;

    /**
     * Sets the error process action.
     *
     * @param processActionsMeta the new error process action
     */
    public void setErrorProcessAction(ProcessActionsMeta processActionsMeta);

    /**
     * Complete the processing of the process action. This involves creating an Action record depending on the process
     * action code and then deleting the process action record.
     *
     * @param processActionsMeta the process actions meta
     */
    public void completeIrregularityProcessAction(ProcessActionsMeta processActionsMeta);

    /**
     * Country lookup.
     *
     * @param country the country
     * @param languageType the language type
     * @return the string
     * @throws MTSServiceFault the MTS service fault
     */
    public String countryLookup(String country, LanguageType languageType) throws MTSServiceFault;

    /**
     * Gets the interested party.
     *
     * @param applicationDto the application dto
     * @return the interested party
     */
    public InterestedPartyDto getInterestedParty(ApplicationDto applicationDto) throws MTSServiceFault;

    /**
     * Gets the trade mark.
     *
     * @param applicationDto the application dto
     * @return the trade mark
     */
    public String getTradeMark(ApplicationDto applicationDto) throws MTSServiceFault;

    /**
     * Creates the mail in progress.
     *
     * @param taskList the task list
     * @param irTranId the ir tran id
     * @throws MTSServiceFault the MTS service fault
     */
    public void createMailInProgress(List<IntlIrTaskDto> taskList, BigDecimal irTranId) throws MTSServiceFault;

    /**
     *
     * Returns the calculated CitedRegistrationNumber for the given parameters
     *
     * @param fileNumber The file number
     * @param extensionCounter The extension counter
     * @return
     */
    public String getCitedRegistrationNumber(int fileNumber, int extensionCounter);

}
