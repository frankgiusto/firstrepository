package ca.gc.ic.cipo.tm.mts.service.intl;

import java.math.BigDecimal;

import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.DuplicateIrregularResponse;

public interface IDuplicateTransaction {

    /**
     * Duplicate irregular transaction. This is triggered from the Madrid Console when the user select the option to
     * "Resend after correction" The outbound transaction is re-generated.
     *
     * @param irTranId the ir tran id
     * @return the duplicate irregular response
     * @throws CIPOServiceFault the CIPO service fault
     */
    public DuplicateIrregularResponse duplicateIrregularTransaction(BigDecimal irTranId, String authorityId)
        throws CIPOServiceFault;
}
