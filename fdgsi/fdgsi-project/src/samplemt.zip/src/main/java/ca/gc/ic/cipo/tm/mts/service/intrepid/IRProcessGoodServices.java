package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.math.BigDecimal;
import java.util.List;

import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.mts.ApplicationNumber;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.enums.GoodsServiceAction;

public interface IRProcessGoodServices {

    public GoodsServiceAction processDOPartialCeasingEffect(GoodsAndServiceMeta gsInfo, String recordEffectiveDate)
        throws CIPOServiceFault;

    public GoodsServiceAction processDOPartialCancelation(GoodsAndServiceMeta gsInfo, String recordEffectiveDate)
        throws CIPOServiceFault;

    public GoodsServiceAction processDOGoodServiceLimitation(GoodsAndServiceMeta gsInfo, String recordEffectiveDate,
                                                             ActionCode actionCode)
        throws CIPOServiceFault;

    public void processIRCorrectionActions(ProcessIRCorrectionSubmissionRequest request, String recordEffecitiveDate,
                                           String recordNotificationDate)
        throws CIPOServiceFault;

    /**
     * Process partial ownership.
     *
     * @param intlIrTransaction the intl ir transaction
     * @param notificationLanguage the notification language
     * @param designation the designation
     * @param restriction the restriction
     * @return the new Application file number
     * @throws CIPOServiceFault the CIPO service fault
     */
    public Integer processPartialOwnership(IntlIrTranDto intlIrTransaction, String notificationLanguage,
                                           PartialOwnershipMeta designation, PartialOwnershipMeta restriction)
        throws CIPOServiceFault;

    /**
     * Get the Madrid Application from database.
     *
     * @param IR_number
     * @return the Madrid Application XREF List
     * @throws CIPOServiceFault
     */
    public List<MadridApplicationXref> getMadridApplicationXREFList(String IR_number) throws CIPOServiceFault;

    /**
     * Updated Madrid Application Xref's with the provided marks.
     *
     * @param IR_number
     * @param barNumberList
     * @throws CIPOServiceFault
     */
    public void updateMadridApplicationXREF(String IR_number, List<ApplicationNumber> barNumberList)
        throws CIPOServiceFault;

    /**
     * Add a new Madrid Application Action for the Madrid Application with provided authority id and status
     *
     * @param internationalRegistrationNumber
     * @param authorityId
     * @param madridApplicationActionStatus
     * @throws CIPOServiceFault
     */
    public void addNewMadridApplicationAction(String internationalRegistrationNumber, String authorityId,
                                              BigDecimal irTranId,
                                              MadridApplicationActionStatus madridApplicationActionStatus)
        throws CIPOServiceFault;

    /**
     * Add a new Madrid Application Action for the Madrid Application with provided authority id and status
     *
     * @param internationalRegistrationNumber
     * @param authorityId
     * @param madridApplicationActionStatus
     * @param closeAIR indicates if we should close the Madrid Application
     * @throws CIPOServiceFault
     */
    public void addNewMadridApplicationAction(String internationalRegistrationNumber, String authorityId,
                                              BigDecimal irTranId,
                                              MadridApplicationActionStatus madridApplicationActionStatus,
                                              boolean closeAIR)
        throws CIPOServiceFault;

}
