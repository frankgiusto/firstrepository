package ca.gc.ic.cipo.tm.mts.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateFormats
{
	// Wrap SimpleDateFormat in a thread safe class as they are not thread safe objects
	static ThreadLocal<SimpleDateFormat> isoSDFs = new ThreadLocal<SimpleDateFormat>();
	static ThreadLocal<SimpleDateFormat> dataSDFs = new ThreadLocal<SimpleDateFormat>();

	public static synchronized SimpleDateFormat getISOSDF()
	{
		SimpleDateFormat dataSDF = isoSDFs.get();
		if (dataSDF == null)
		{
			dataSDF = new SimpleDateFormat("yyyy-MM-dd");
			dataSDF.setLenient(false);
			isoSDFs.set(dataSDF);
		}
		return dataSDF;
	}
	
	public static synchronized SimpleDateFormat getDataSDF()
    {
        SimpleDateFormat dataSDF = dataSDFs.get();
        if (dataSDF == null)
        {
            dataSDF = new SimpleDateFormat("yyyyMMdd");
            dataSDF.setLenient(false);
            dataSDFs.set(dataSDF);
        }
        return dataSDF;
    }
}
