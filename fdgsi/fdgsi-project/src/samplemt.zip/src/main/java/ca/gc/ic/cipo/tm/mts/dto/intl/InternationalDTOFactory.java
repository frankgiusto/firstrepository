package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.activation.DataHandler;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import ca.gc.ic.cipo.tm.intl.enumerator.LanguageIntegerType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTask;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTaskXref;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfo;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskStatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskType;
import ca.gc.ic.cipo.tm.intl.model.ReferenceCodeInterface;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ManualAutoCategoryType;
import ca.gc.ic.cipo.tm.mts.ReferenceCode;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ic.cipo.tm.mts.TransactionType;
import ca.gc.ic.cipo.tm.mts.enums.NfsFileType;
import ca.gc.ic.cipo.tm.mts.enums.TransactionCategoryType;
import ca.gc.ic.cipo.ws.client.rgs.InputStreamDataSource;

@Component
public class InternationalDTOFactory implements IInternationalDTOFactory {

    private static final Logger log = LoggerFactory.getLogger(InternationalDTOFactory.class);

    @Override
    public IntlIrTranDto getIntlIrTranDto(IntlIrTran intlIrTran) {
        IntlIrTranDto internationalTransaction = createIntlIrTranDto(intlIrTran);
        return internationalTransaction;
    }

    @Override
    public IntlIrTranDto getIntlIrTranNoChildrenDto(IntlIrTran intlIrTran) {
        IntlIrTranDto internationalTransaction = createIntlIrTranNoChildrenDto(intlIrTran);
        return internationalTransaction;
    }

    @Override
    public List<IntlIrTaskDto> getIRTaskListDto(List<IntlIrTask> intlIrTaskList) {

        List<IntlIrTaskDto> intlIrTaskDtoList = new ArrayList<>();
        for (IntlIrTask intlIrTask : intlIrTaskList) {
            intlIrTaskDtoList.add(getIRTaskDto(intlIrTask));
        }
        return intlIrTaskDtoList;
    }

    @Override
    public IntlIrTaskDto getIRTaskDto(IntlIrTask intlIrTask) {
        IntlIrTaskDto intlIrTaskDto = new IntlIrTaskDto();
        if (null != intlIrTask.getDmstcApltnFileNbr()) {
            intlIrTaskDto.setFileNumber(intlIrTask.getDmstcApltnFileNbr().intValue());
        }
        intlIrTaskDto.setExtensionCounter(intlIrTask.getDmstcApltnFileExtn());

        if (CollectionUtils.isNotEmpty(intlIrTask.getIntlTaskAddtnlInfo())) {
            for (IntlTaskAddtnlInfo intlTaskAddtnlInfo : intlIrTask.getIntlTaskAddtnlInfo()) {
                IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
                intlTaskAddtnlInfoDto.setAddtnlInfo(intlTaskAddtnlInfo.getAddtnlInfo());
                intlTaskAddtnlInfoDto.setTaskAddtnlInfoId(intlTaskAddtnlInfo.getTaskAddtnlInfoId());
                intlTaskAddtnlInfoDto.setCreatedTmstmp(intlTaskAddtnlInfo.getCreatedTmstmp());
                intlTaskAddtnlInfoDto.setTaskId(intlTaskAddtnlInfo.getTaskId());
                intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(
                    createIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfo.getTaskAddtnlInfoCtgry()));
                intlTaskAddtnlInfoDto.setTaskAddtnlInfoId(intlTaskAddtnlInfo.getTaskAddtnlInfoId());

                intlIrTaskDto.getIntlTaskAddtnlInfoDto().add(intlTaskAddtnlInfoDto);
            }
        }

        intlIrTaskDto.setIrNumber(intlIrTask.getIntlRegNo());
        intlIrTaskDto.setOfficeType(intlIrTask.getIntlIrOfficeType().getIrOfficeCtgry());
        intlIrTaskDto.setTaskId(intlIrTask.getTaskId());
        intlIrTaskDto.setTaskReferenceId(intlIrTask.getActHiTaskInstId());
        intlIrTaskDto.setWipoReferenceNumber(intlIrTask.getWipoRefNbr());

        if (null != intlIrTask.getActHiTaskInst()) {
            intlIrTaskDto.setAuthorityId(intlIrTask.getActHiTaskInst().getAssignee());
        }

        intlIrTaskDto.setTaskTypeDto(createIntlTaskTypeDto(intlIrTask.getIntlTaskType()));
        intlIrTaskDto.setTaskStatusTypeDto(createIntlTaskStatusTypeDto(intlIrTask.getIntlTaskStatusType()));

        return intlIrTaskDto;
    }

    private IntlTaskAddtnlInfoTypeDto createIntlTaskAddtnlInfoTypeDto(IntlTaskAddtnlInfoType intlTaskAddtnlInfoType) {

        IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();

        intlTaskAddtnlInfoTypeDto.setTaskAddtnlInfoCtgryId(intlTaskAddtnlInfoType.getTaskAddtnlInfoCtgryId());
        intlTaskAddtnlInfoTypeDto.setTaskAddtnlInfoCtgry(intlTaskAddtnlInfoType.getTaskAddtnlInfoCtgry());
        intlTaskAddtnlInfoTypeDto.setDescEn(intlTaskAddtnlInfoType.getDescEn());
        intlTaskAddtnlInfoTypeDto.setDescFr(intlTaskAddtnlInfoType.getDescFr());

        return intlTaskAddtnlInfoTypeDto;
    }

    @Override
    public List<IntlAtchmtDto> getAtchmtDto(Set<IntlAtchmt> attachments) {

        List<IntlAtchmtDto> intlAtchmtDtoList = new ArrayList<>();
        for (IntlAtchmt intlAtchmt : attachments) {

            intlAtchmtDtoList.add(createIntlAtchmtDto(intlAtchmt));

        }

        return intlAtchmtDtoList;
    }

    @Override
    public NfsFilenameDto createNfsFilenameDto(String fileName, BigDecimal fileNumber, String extensionCounter,
                                               NfsFileType fileType, BigDecimal atchmntId, BigDecimal irTranId) {

        NfsFilenameDto nfsFilenameDto = new NfsFilenameDto();
        nfsFilenameDto.setFileName(fileName);
        nfsFilenameDto.setExtensionCounter(extensionCounter);
        nfsFilenameDto.setAtchmtId(atchmntId);
        nfsFilenameDto.setIrTranId(irTranId);
        nfsFilenameDto.setFileNumber(fileNumber);
        nfsFilenameDto.setFileType(fileType);

        return nfsFilenameDto;

    }

    @Override
    public List<IntlIrTaskDto> fileNumberToTaskDtoList(List<Integer> fileNumberList, String irNumber) {

        List<IntlIrTaskDto> taskDtoList = new ArrayList<>();

        for (Integer fileNumber : fileNumberList) {
            IntlIrTaskDto intlIrTaskDto = new IntlIrTaskDto();
            intlIrTaskDto.setFileNumber(fileNumber);
            intlIrTaskDto.setIrNumber(irNumber);
            taskDtoList.add(intlIrTaskDto);
        }
        return taskDtoList;
    }

    private IntlStatusTypeDto createIntlStatusTypeDto(IntlStatusType intlStatusType) {
        IntlStatusTypeDto intlStatusTypeDto = new IntlStatusTypeDto();
        intlStatusTypeDto.setStatusCtgry(intlStatusType.getStatusCtgry());
        intlStatusTypeDto.setStatusCtgryId(intlStatusType.getStatusCtgryId());

        return intlStatusTypeDto;
    }

    private IntlTaskTypeDto createIntlTaskTypeDto(IntlTaskType intlTaskType) {
        IntlTaskTypeDto intlTaskTypeDto = new IntlTaskTypeDto();
        intlTaskTypeDto.setTaskCtgry(intlTaskType.getTaskCtgry());
        intlTaskTypeDto.setTaskCtgryId(intlTaskType.getTaskCtgryId());
        return intlTaskTypeDto;
    }

    private IntlTaskStatusTypeDto createIntlTaskStatusTypeDto(IntlTaskStatusType intlTaskStatusType) {
        IntlTaskStatusTypeDto intlTaskStatusTypeDto = new IntlTaskStatusTypeDto();
        intlTaskStatusTypeDto.setTaskStatusCtgry(intlTaskStatusType.getTaskStatusCtgry());
        intlTaskStatusTypeDto.setTaskStatusCtgryId(intlTaskStatusType.getTaskStatusCtgryId());

        return intlTaskStatusTypeDto;
    }

    private IntlIrTranDto createIntlIrTranNoChildrenDto(IntlIrTran intlIrTran) {
        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        BeanUtils.copyProperties(intlIrTran, intlIrTranDto);

        intlIrTranDto.setIntlPkg(createIntlPkgDto(intlIrTran.getIntlPkg()));
        intlIrTranDto.setIntlPkgTranType(createIntlTranTypeDto(intlIrTran.getIntlPkgTranType()));
        intlIrTranDto.setStatusTypeDto(createIntlStatusTypeDto(intlIrTran.getIntlStatusType()));

        return intlIrTranDto;
    }

    private IntlIrTranDto createIntlIrTranDto(IntlIrTran intlIrTran) {
        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        BeanUtils.copyProperties(intlIrTran, intlIrTranDto);

        intlIrTranDto.setIntlPkg(createIntlPkgDto(intlIrTran.getIntlPkg()));
        intlIrTranDto.setIntlPkgTranType(createIntlTranTypeDto(intlIrTran.getIntlPkgTranType()));
        intlIrTranDto.setStatusTypeDto(createIntlStatusTypeDto(intlIrTran.getIntlStatusType()));
        intlIrTranDto.setOfficeRefId(intlIrTran.getOfficeRefId());

        Set<IntlIrTaskXref> xrefList = intlIrTran.getIntlIrTaskXrefs();
        if (null != xrefList) {
            for (IntlIrTaskXref intlIrTaskXref : xrefList) {
                IntlIrTaskXrefDto intlIrTaskXrefDto = new IntlIrTaskXrefDto();
                intlIrTaskXrefDto.setIrTranId(intlIrTaskXref.getIrTranId());
                intlIrTaskXrefDto.setIntlIrTaskDto(getIRTaskDto(intlIrTaskXref.getIntlIrTask()));
                intlIrTranDto.getIntlIrTaskXrefDtoList().add(intlIrTaskXrefDto);
            }
        }
        Set<IntlAtchmt> intlAtchmtList = intlIrTran.getIntlAtchmts();
        if (null != intlAtchmtList) {
            for (IntlAtchmt intlAtchmt : intlAtchmtList) {

                intlIrTranDto.getIntlAtchmtDtoList().add(createIntlAtchmtDto(intlAtchmt));
            }
        }

        return intlIrTranDto;
    }

    private IntlAtchmtDto createIntlAtchmtDto(IntlAtchmt intlAtchmt) {
        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto
            .setAtchmtCtgryId(BigDecimal.valueOf(intlAtchmt.getIntlAtchmtType().getAtchmtCtgryId().longValue()));
        intlAtchmtDto.setAtchmtId(intlAtchmt.getAtchmtId());
        intlAtchmtDto.setFileName(intlAtchmt.getFileName());
        intlAtchmtDto.setIrTranId(intlAtchmt.getIntlIrTran().getIrTranId());
        intlAtchmtDto.setFileFrmtCtgry(intlAtchmt.getIntlFileFrmtType().getFileFrmtCtgry());
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(intlAtchmt.getIntlFileFrmtType().getFileFrmtId()));
        intlAtchmtDto.setCreatedTmstmp(intlAtchmt.getCreatedTmstmp());

        return intlAtchmtDto;
    }

    private IntlPkgDto createIntlPkgDto(IntlPkg intlPkg) {
        if (null == intlPkg) {
            return null;
        }
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        BeanUtils.copyProperties(intlPkg, intlPkgDto);
        return intlPkgDto;
    }

    private IntlPkgTranTypeDto createIntlTranTypeDto(IntlPkgTranType intlPkgTranType) {
        IntlPkgTranTypeDto intlPkgTranTypeDto = new IntlPkgTranTypeDto();
        BeanUtils.copyProperties(intlPkgTranType, intlPkgTranTypeDto);
        return intlPkgTranTypeDto;
    }

    @Override
    public TransactionCategoryType getPairedTransactionType(TransactionCategory transactionCategory) {
        if (MadridTransactionType.pairedTransactionTypes.contains(transactionCategory)) {
            return TransactionCategoryType.PROCESS_IR_OWNERSHIP_CHANGE_MERGER;
        }
        log.error("Unexpected Paired TransactionCategory:" + transactionCategory);
        return null;
    }

    @Override
    public List<BigDecimal> getAutomatedTransactionCategories() {

        List<BigDecimal> categories = new ArrayList<>();

        Set<TransactionCategory> automatedTransactionTypes = MadridTransactionType.getAutomatedTransactionCategories();
        for (TransactionCategory automatedTransactionType : automatedTransactionTypes) {
            categories.add(BigDecimal.valueOf(automatedTransactionType.getTransactionCategoryId()));
        }

        return categories;
    }

    @Override
    public List<BigDecimal> getAutomatedTransactionPairCategories() {

        List<BigDecimal> categories = new ArrayList<>();

        Set<TransactionCategory> automatedTransactionTypes = MadridTransactionType.pairedTransactionTypes;
        for (TransactionCategory automatedTransactionType : automatedTransactionTypes) {
            categories.add(BigDecimal.valueOf(automatedTransactionType.getTransactionCategoryId()));
        }

        return categories;
    }

    @Override
    public List<BigDecimal> getManualTransactionCategories() {

        List<BigDecimal> categories = new ArrayList<>();

        Set<TransactionCategory> manualTransactionTypes = MadridTransactionType.getManualTransactionCategories();
        for (TransactionCategory manualTransactionType : manualTransactionTypes) {
            categories.add(BigDecimal.valueOf(manualTransactionType.getTransactionCategoryId()));
        }

        return categories;
    }

    @Override
    public List<BigDecimal> getStatusTypes(TransactionCriteria transactionCriteria) {
        List<BigDecimal> statusTypeCodeIds = null;
        if (!CollectionUtils.isEmpty(transactionCriteria.getStatusCodeList())) {
            statusTypeCodeIds = new ArrayList<BigDecimal>();
            for (TransactionStatusType typeXsd : transactionCriteria.getStatusCodeList()) {
                if (typeXsd != null) {
                    statusTypeCodeIds.add(new BigDecimal(StatusType.getStatusTypeByName(typeXsd.name()).getValue()));
                }
            }
        }
        return statusTypeCodeIds;

    }

    @Override
    public List<BigDecimal> getTransactionTypes(TransactionCriteria transactionCriteria) {
        List<BigDecimal> transTypeCodeIds = null;
        if (!CollectionUtils.isEmpty(transactionCriteria.getTransactionTypeCodeList())) {
            transTypeCodeIds = new ArrayList<BigDecimal>();
            for (TransactionType typeXsd : transactionCriteria.getTransactionTypeCodeList()) {
                if (typeXsd != null) {
                    transTypeCodeIds.add(new BigDecimal(
                        TransactionCategory.getTransactionCategoryByName(typeXsd.name()).getTransactionCategoryId()));
                }
            }
        }
        // User specified category of transaction
        if (null != transactionCriteria.getTransactionManualAutoCategory()) {
            if (null == transTypeCodeIds) {
                transTypeCodeIds = new ArrayList<BigDecimal>();
            }
            if (transactionCriteria.getTransactionManualAutoCategory() == ManualAutoCategoryType.AUTOMATED) {

                transTypeCodeIds.addAll(getAutomatedTransactionCategories());

            } else if (transactionCriteria.getTransactionManualAutoCategory() == ManualAutoCategoryType.MANUAL) {

                transTypeCodeIds.addAll(getManualTransactionCategories());
            }
        } else {
            if ((null == transTypeCodeIds) && (CollectionUtils.isEmpty(transactionCriteria.getPackageIdList()))) {
                transTypeCodeIds = new ArrayList<BigDecimal>();
                transTypeCodeIds.addAll(getManualTransactionCategories());
                transTypeCodeIds.addAll(getAutomatedTransactionCategories());
                transTypeCodeIds.addAll(getAutomatedTransactionPairCategories());
            }

        }
        return transTypeCodeIds;
    }

    @Override
    public TransactionDetail mapToXsd(final IntlIrTran transactionModel, final boolean includeXmlContent,
                                      final boolean includeAttachmentContent)
        throws CIPOServiceFault, SQLException {

        TransactionDetail responseDetail = new TransactionDetail();
        // Map some of the details from the Transaction model to the response
        // detail object
        responseDetail.setTransactionId(transactionModel.getIrTranId());
        // Some export messages may not have a Package ID set yet
        if (transactionModel.getIntlPkg() != null) {
            responseDetail.setPackageId(transactionModel.getIntlPkg().getPkgId());
        }

        responseDetail.setTransactionType(mapToReferenceCode(transactionModel.getIntlPkgTranType()));
        responseDetail.setCurrentStatus(mapToReferenceCode(transactionModel.getIntlStatusType()));
        responseDetail.setIntlRegistrationNumber(transactionModel.getIntlRegNo());
        responseDetail.setRecordId(transactionModel.getIntlRecordId());
        responseDetail.setDomesticApplicationNumber(transactionModel.getDmstcApltnNbr());

        responseDetail.setCreatedTimestamp(
            null != transactionModel.getCreatedTmstmp() ? transactionModel.getCreatedTmstmp() : null);
        responseDetail.setUpdatedTimestamp(
            null != transactionModel.getUpdatedTmstmp() ? transactionModel.getUpdatedTmstmp() : null);

        // ST.96 XML of the Transaction is optional
        if (includeXmlContent) {
            Blob xmlBlob = transactionModel.getXmlContent();

            responseDetail.setXmlContent(xmlBlob.getBytes(1, (int) xmlBlob.length()));

        }

        // Metadata about attachments is always returned - the actual binary content is the optional part the user may
        // request
        for (IntlAtchmt attachment : transactionModel.getIntlAtchmts()) {
            responseDetail.getAttachments().add(mapToXsd(attachment, includeAttachmentContent));
        }
        return responseDetail;
    }

    @Override
    public TransactionDetail mapToTransactionXsd(final IntlIrTran transactionModel) throws CIPOServiceFault {

        TransactionDetail responseDetail = new TransactionDetail();
        // Map some of the details from the Transaction model to the response
        responseDetail.setTransactionId(transactionModel.getIrTranId());
        responseDetail.setIntlRegistrationNumber(transactionModel.getIntlRegNo());
        responseDetail.setTransactionType(mapToReferenceCode(transactionModel.getIntlPkgTranType()));
        responseDetail.setCurrentStatus(mapToReferenceCode(transactionModel.getIntlStatusType()));
        if (transactionModel.getIntlPkg() != null) {
            responseDetail.setPackageId(transactionModel.getIntlPkg().getPkgId());
        }
        return responseDetail;
    }

    @Override
    public AttachmentDetail mapToXsd(final IntlAtchmt attachment, final boolean includeAttachmentContent)
        throws CIPOServiceFault, SQLException {
        AttachmentDetail attachDetailXsd = new AttachmentDetail();
        attachDetailXsd.setId(attachment.getAtchmtId());

        // *Either* packageId OR transaction ID will be provided. Set it on the
        // XSD model
        if (attachment.getIntlPkg() != null) {
            attachDetailXsd.setPackageId(attachment.getIntlPkg().getPkgId());
        }
        if (attachment.getIntlIrTran() != null) {
            attachDetailXsd.setTransactionId(attachment.getIntlIrTran().getIrTranId());
        }
        attachDetailXsd.setFileName(attachment.getFileName());
        attachDetailXsd.setCreatedOn(attachment.getCreatedTmstmp());

        attachDetailXsd.setFileFormatType(mapToReferenceCode(attachment.getIntlFileFrmtType()));
        attachDetailXsd.setAttachmentType(mapToReferenceCode(attachment.getIntlAtchmtType()));

        // Only add the binary content if requested
        if (includeAttachmentContent) {
            // Create a DataHandler stream for the attachment
            // try {
            attachDetailXsd.setFileContent(
                new DataHandler(new InputStreamDataSource(attachment.getFileContent().getBinaryStream())));
            // } catch (SQLException e) {
            // throwMTSServiceFault("mts.blob.serialize.error", ExceptionReasonCode.SYSTEM_ERROR);
            // }
        }
        return attachDetailXsd;
    }

    private ReferenceCode mapToReferenceCode(final ReferenceCodeInterface nativeCodeType) {
        ReferenceCode result = null;
        if (nativeCodeType != null) {
            result = new ReferenceCode();
            result.setId((int) nativeCodeType.getId());
            result.setCategory(nativeCodeType.getCategory());
            result.setDescriptionEn(nativeCodeType.getDescription(LanguageIntegerType.ENGLISH.codeValue()));
            result.setDescriptionFr(nativeCodeType.getDescription(LanguageIntegerType.FRENCH.codeValue()));
        }
        return result;
    }
}
