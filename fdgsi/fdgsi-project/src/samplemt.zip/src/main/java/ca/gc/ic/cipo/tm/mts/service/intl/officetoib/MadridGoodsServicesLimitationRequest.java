package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;

import javax.xml.bind.JAXBElement;

import _int.wipo.standards.xmlschema.st96.common.madrid.AmountType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.InternationalRegistrationNumberBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PaymentBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PaymentType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesLimitationBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesLimitationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesLimitationType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridGoodsServicesLimitationRequestType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;

public class MadridGoodsServicesLimitationRequest extends OfficeToIbBase implements IOutboundTransaction {

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_GOODS_SERVICES_LIMITATION_REQUEST;

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto processActionApplication = outboundTransactionDto.getProcessActionApplication();
        MadridGoodsServicesLimitationRequestType transaction = objectFactory
            .createMadridGoodsServicesLimitationRequestType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(processActionApplication);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // International Registration Number Bag
        InternationalRegistrationNumberBagType internationalRegistrationNumberBagType = commonObjectFactory
            .createInternationalRegistrationNumberBagType();

        // Registration Number
        internationalRegistrationNumberBagType.getInternationalRegistrationNumber()
            .add(outboundTransactionDto.getIntlRegNo());

        transaction.setInternationalRegistrationNumberBag(internationalRegistrationNumberBagType);

        // Holder Bag
        transaction.setHolderBag(
            super.mapHolder(processActionApplication.getTmInterestedPartyTypeList(), notificationLanguage));

        // All Contracting Parties Indicator TODO TBD
        transaction.setAllContractingPartiesIndicator(true);

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Goods Services Limitation Bag
        GoodsServicesLimitationBagType goodsServicesLimitationBagType = objectFactory
            .createGoodsServicesLimitationBagType();

        // Goods Services Limitation Type
        // 1) Category
        GoodsServicesLimitationType goodsServicesLimitationType = objectFactory.createGoodsServicesLimitationType();

        // JAXBElement<GoodsServicesLimitationCategoryType> goodsServicesLimitationCategory = objectFactory
        // .createGoodsServicesLimitationCategory(GoodsServicesLimitationCategoryType.LIST_LIMITED_TO);

        // 2) Description Bag
        ClassDescriptionBagType classDescriptionBagType = objectFactory.createClassDescriptionBagType();
        ClassDescriptionType classDescriptionType = objectFactory.createClassDescriptionType();
        classDescriptionType.setClassNumber("class number from console");
        classDescriptionBagType.getClassDescription().add(classDescriptionType);

        // 2.1) Description Text
        OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
        orderedTextType.setLanguageCode(notificationLanguage.value());
        orderedTextType.setSequenceNumber("1");
        orderedTextType.setValue("goods and services text from console");
        classDescriptionType.getGoodsServicesDescriptionText().add(orderedTextType);

        classDescriptionBagType.getClassDescription().add(classDescriptionType);

        // Goods Services Class Description Bag
        // JAXBElement<ClassDescriptionBagType> limitationClassDescriptionBag = objectFactory
        // .createLimitationClassDescriptionBag(classDescriptionBagType);

        // Add Limitation Category and Description Bag
        goodsServicesLimitationType.getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag()
            .add(GoodsServicesLimitationCategoryType.LIST_LIMITED_TO);

        goodsServicesLimitationType.getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag()
            .add(classDescriptionBagType);

        goodsServicesLimitationBagType.getGoodsServicesLimitation().add(goodsServicesLimitationType);

        transaction.setGoodsServicesLimitationBag(goodsServicesLimitationBagType);

        // Payment Bag
        PaymentBagType paymentBagType = commonObjectFactory.createPaymentBagType();
        PaymentType paymentType = commonObjectFactory.createPaymentType();
        AmountType amountType = commonObjectFactory.createAmountType();
        amountType.setValue(BigDecimal.valueOf(0));
        paymentType.setFeePaidTotalAmount(amountType);
        paymentBagType.getPayment().add(paymentType);

        transaction.setPaymentBag(paymentBagType);

        // Signature bag TODO: We need implement the signature block in the transaction. The following is dummy code.
        // SignatureBagType signatureBagType = commonObjectFactory.createSignatureBagType();
        // SignatureType signatureType = commonObjectFactory.createSignatureType();
        // ContactType contactType = commonObjectFactory.createContactType();
        // NameType nameType = commonObjectFactory.createNameType();
        // OrganizationNameType organizationNameType = commonObjectFactory.createOrganizationNameType();
        // PhraseType phraseType = commonObjectFactory.createPhraseType();
        //
        // organizationNameType.setOrganizationStandardName(phraseType);
        // nameType.getPersonNameOrOrganizationNameOrEntityName().add(organizationNameType);
        // contactType.setName(nameType);
        // signatureType.setContact(contactType);
        //
        // ElectronicSignatureType electronicSignatureType = commonObjectFactory.createElectronicSignatureType();
        // ElectronicBasicSignatureType electronicBasicSignatureType = commonObjectFactory
        // .createElectronicBasicSignatureType();
        // electronicBasicSignatureType.setElectronicBasicSignatureClickWrap(true);
        // // electronicBasicSignatureType.setElectronicBasicSignatureText("text");
        // // electronicBasicSignatureType.setElectronicBasicSignatureImageURI("url/aa/aa");
        //
        // electronicSignatureType.setElectronicSignatureDate(paymentType.getPaymentDate());
        // electronicSignatureType.setElectronicBasicSignature(electronicBasicSignatureType);
        // signatureType.setElectronicSignature(electronicSignatureType);
        // signatureBagType.getSignature().add(signatureType);
        // transaction.setSignatureBag(signatureBagType);

        JAXBElement<MadridGoodsServicesLimitationRequestType> madridobject = objectFactory
            .createMadridGoodsServicesLimitationRequest(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);

    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {

        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return false;
    }

}
