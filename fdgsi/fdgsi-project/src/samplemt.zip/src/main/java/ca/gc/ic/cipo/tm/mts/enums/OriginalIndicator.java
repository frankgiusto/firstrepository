package ca.gc.ic.cipo.tm.mts.enums;

/**
 * The Enum OriginalIndicator defines component ORIGINAL_IND elements based on current application language.
 *
 * @author giustof
 */
public enum OriginalIndicator {

    // Application language English or Spanish
    APP_ENGLISH_GOODS_SERVICES_ENGLISH(1),

    APP_ENGLISH_GOODS_SERVICES_FRENCH(0),

    APP_ENGLISH_APP_TEXT_ENGLISH(1),

    APP_ENGLISH_APP_TEXT_FRENCH(0),

    APP_ENGLISH_CLAIM_ENGLISH(1),

    APP_ENGLISH_CLAIM_FRENCH(0),

    // Application language French
    APP_FRENCH_GOODS_SERVICES_ENGLISH(0),

    APP_FRENCH_GOODS_SERVICES_FRENCH(1),

    APP_FRENCH_APP_TEXT_ENGLISH(0),

    APP_FRENCH_APP_TEXT_FRENCH(1),

    APP_FRENCH_CLAIM_ENGLISH(0),

    APP_FRENCH_CLAIM_FRENCH(1);

    private Integer orininalInd;

    private OriginalIndicator(Integer orininalInd) {
        this.setOrininalInd(orininalInd);
    }

    public Integer getOrininalInd() {
        return orininalInd;
    }

    public void setOrininalInd(Integer orininalInd) {
        this.orininalInd = orininalInd;
    }

}
