package ca.gc.ic.cipo.tm.mts.service.intrepid;

import java.util.List;

import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.mts.AirToExaminationRequest;
import ca.gc.ic.cipo.tm.mts.ApplicationNumber;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;

public interface IAirToExaminationSubmissionService {

    public void storeAirToExaminationSubmissionInfo(AirToExaminationRequest parameters) throws CIPOServiceFault;

    public void updateMadridApplicationXREF(String IR_number, List<ApplicationNumber> barNumberList)
        throws CIPOServiceFault;

    /**
     * Adds the madrid application.
     *
     * @param irNumber the ir number
     * @param madridApplicationActionStatus the madrid application action status
     * @throws CIPOServiceFault the CIPO service fault
     */
    public void addMadridApplication(String irNumber, MadridApplicationActionStatus madridApplicationActionStatus)
        throws CIPOServiceFault;
}
