package ca.gc.ic.cipo.tm.mts.service;

import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;

public interface IMadridCacheService {

    /**
     * Gets the user profile. This is cached with @Cacheable
     *
     * @param userId the user id
     * @return the user profile
     * @throws CIPOServiceFault the CIPO service fault
     */
    public UserProfile getUserProfile(String userId) throws CIPOServiceFault;
}
