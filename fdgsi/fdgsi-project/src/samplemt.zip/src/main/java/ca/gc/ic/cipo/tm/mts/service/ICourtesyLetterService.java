package ca.gc.ic.cipo.tm.mts.service;

import java.util.Map;

import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;

public interface ICourtesyLetterService {

    /**
     * Process courtesy letter.
     *
     * @param intlIrTransaction the intl ir transaction
     * @param notifications the notifications
     * @param transactionCategory the transaction category
     * @throws CIPOServiceFault the CIPO service fault
     */
    public void processCourtesyLetter(IntlIrTranDto intlIrTransaction, Map<ApplicationDto, UserTaskType> notifications,
                                      TransactionCategory transactionCategory)
        throws CIPOServiceFault;

    /**
     * Check is courtesy letter required.
     *
     * @param transType the trans type
     * @param application the application
     * @param languageType the language type
     * @param notificationTypes the notification types
     * @return the int
     * @throws MTSServiceFault the MTS service fault
     */
    public int checkIsCourtesyLetterRequired(Object transType, Application application, LanguageType languageType,
                                             Map<ApplicationDto, UserTaskType> notificationTypes)
        throws MTSServiceFault;

    /**
     * Process courtesy letter and process action.
     *
     * @param intlIrTransaction the intl ir transaction
     * @param appDto the app dto
     * @param fileNamePrefixKey the file name prefix key
     * @throws Exception the exception
     */
    public void processCourtesyLetterAndProcessAction(IntlIrTranDto intlIrTransaction, ApplicationDto appDto,
                                                      String fileNamePrefixKey)
        throws Exception;

    /**
     * Process courtesy letter and process actions.
     *
     * @param request the request
     * @param intlIrTransaction the intl ir transaction
     * @throws CIPOServiceFault the CIPO service fault
     */
    public void processCourtesyLetterAndProcessActions(ProcessModifiedRepAddressSubmissionRequest request,
                                                       IntlIrTranDto intlIrTransaction)
        throws CIPOServiceFault;
}
