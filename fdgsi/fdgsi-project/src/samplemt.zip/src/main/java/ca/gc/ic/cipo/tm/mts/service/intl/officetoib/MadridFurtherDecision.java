package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridFinalDecisionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;

public class MadridFurtherDecision extends OfficeToIbBase implements IOutboundTransaction, IReportingService {

    private static Logger log = Logger.getLogger(MadridFurtherDecision.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType = MadridOutboundTransactionType.MADRID_FURTHER_DECISION_MF7;

    private final static String reportName = "MADRID_MF7";

    private final static String reportXpath = "/MadridPossibleOppositionNotification"; // TODO temp

    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        // TODO data for this is coming from Madrid Console as this is initiated by a manual task.

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        // Tirs info
        TMInfoRetrievalDto tirsDto = outboundTransactionDto.getProcessActionApplication();
        MadridFinalDecisionType transaction = objectFactory.createMadridFinalDecisionType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(tirsDto);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Holder Bag
        transaction.setHolderBag(super.mapHolder(tirsDto.getTmInterestedPartyTypeList(), notificationLanguage));

        // Indicators
        transaction.setAllGoodsServicesIndicator(false);
        transaction.setGrantProtectionIndicator(true);
        transaction.setRefusalProtectionIndicator(false);

        // Goods Services Bag
        transaction.setGoodsServicesBag(mapGoodsServices(tirsDto.getGoodsAndServices()));

        // Document Included Bag
        List<String> documents = new ArrayList<>();
        String includedDocName = getUniqueReportName(reportName, outboundTransactionDto.getIntlRegNo(),
            intlIrTranDto.getIrTranId().toString());
        StringBuilder documentName = createDocument(includedDocName);

        documents.add(documentName.toString());

        transaction.setDocumentIncludedBag(super.mapDocumentBag(documents));

        JAXBElement<MadridFinalDecisionType> madridobject = objectFactory.createMadridFinalDecision(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }

    @Override
    public boolean isPdfRequired() {
        return true;
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        MadridFinalDecisionType madridFurtherDecision = marshallingService.unmarshallOutboundTransaction(tranId);

        // TODO transform transaction into jasper data adaptor.
        StringBuilder xmlDataSource = new StringBuilder();

        xmlDataSource.append("<?xml version=\"1.0\"?>");
        xmlDataSource.append("<MadridPossibleOppositionNotification>");
        xmlDataSource.append("<OfficeReferenceIdentifier>79178342</OfficeReferenceIdentifier>");
        xmlDataSource.append("<NotificationLanguage>en</NotificationLanguage>");
        xmlDataSource.append("<InternationalRegistrationNumber>1278267</InternationalRegistrationNumber>");
        xmlDataSource.append("<Holder>ENTERTAINMENT ONE UK LIMITED, ENTERTAINMENT TWO UK LIMITED</Holder> ");
        xmlDataSource.append("<Signature>This is my signature, His signature</Signature>");
        xmlDataSource.append("<OppositionPeriodEndDate>2017-09-19</OppositionPeriodEndDate>");
        xmlDataSource.append("<OppositionPeriodStartDate>2017-09-19</OppositionPeriodStartDate>");
        xmlDataSource.append("<RecordNotificationDate>2017-09-20</RecordNotificationDate>");
        xmlDataSource.append("</MadridPossibleOppositionNotification>");

        String jobId = null;
        try {
            jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(), reportXpath, reportName, null, null);
        } catch (Exception e) {
            throw new Exception("Error shedudling report.");
        }
        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);
        madridReportResponse.setReportName(reportName);

        return madridReportResponse;
    }
}
