package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;

public class OutboundTransactionRequest implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5247827732228043772L;

    private BigDecimal fileNumber;

    private String extensionCounter;

    private String additionalInfo;

    private String wipoReferenceNumber;

    private String recordIdentifier;

    private Boolean irregularityResend;

    private ProcessActionCodeType processActionCodeType;

    private Date internationalRegistrationDate;

    private Date processActionDate;

    private String refusalPronouncedDate;

    private String groundsOfOppositionDescription;

    public BigDecimal getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(BigDecimal fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(String extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public ProcessActionCodeType getProcessActionCodeType() {
        return processActionCodeType;
    }

    public void setProcessActionCodeType(ProcessActionCodeType processActionCodeType) {
        this.processActionCodeType = processActionCodeType;
    }

    public String getWipoReferenceNumber() {
        return wipoReferenceNumber;
    }

    public void setWipoReferenceNumber(String wipoReferenceNumber) {
        this.wipoReferenceNumber = wipoReferenceNumber;
    }

    public String getRecordIdentifier() {
        return recordIdentifier;
    }

    public void setRecordIdentifier(String recordIdentifier) {
        this.recordIdentifier = recordIdentifier;
    }

    public Date getInternationalRegistrationDate() {
        return internationalRegistrationDate;
    }

    public void setInternationalRegistrationDate(Date internationalRegistrationDate) {
        this.internationalRegistrationDate = internationalRegistrationDate;
    }

    public Boolean getIrregularityResend() {
        return irregularityResend;
    }

    public void setIrregularityResend(Boolean irregularityResend) {
        this.irregularityResend = irregularityResend;
    }

    public String getRefusalPronouncedDate() {
        return refusalPronouncedDate;
    }

    public void setRefusalPronouncedDate(String refusalPronouncedDate) {
        this.refusalPronouncedDate = refusalPronouncedDate;
    }

    public Date getProcessActionDate() {
        return processActionDate;
    }

    public void setProcessActionDate(Date processActionDate) {
        this.processActionDate = processActionDate;
    }

    public String getGroundsOfOppositionDescription() {
        return groundsOfOppositionDescription;
    }

    public void setGroundsOfOppositionDescription(String groundsOfOppositionDescription) {
        this.groundsOfOppositionDescription = groundsOfOppositionDescription;
    }

}
