package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;

public interface IAutomatedPairProcessingService {

    AutomatedProcessResponse processTransaction(TransactionPairRequest transaction) throws CIPOServiceFault;
}
