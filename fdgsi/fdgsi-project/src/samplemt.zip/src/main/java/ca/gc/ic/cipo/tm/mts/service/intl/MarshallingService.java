package ca.gc.ic.cipo.tm.mts.service.intl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.namespace.QName;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;

@Service
public class MarshallingService implements IMarshallingService {

    private static final Logger logger = LoggerFactory.getLogger(MarshallingService.class);

    private static final JAXBContext jaxbMadridContext = initMadridContext();

    private static final JAXBContext jaxbMadridOutboundContext = initMadridOutboundContext();

    @Value("#{environment['madrid.schema.location']}")
    private String madridSchemaLocation;

    @Value("#{environment['mts.ws.resource.folder']}")
    private String resourceLocation;

    @Value("#{environment['mts.st96.officetoib.xsd.name']}")
    private String xsdFileName;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    private static JAXBContext initMadridContext() {
        try {

            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid",
                _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory.class.getClassLoader());

        } catch (JAXBException e) {
            logger.error("An error occurred while getting JAXBMadridContext instance", e);
        }
        return null;

    }

    private static JAXBContext initMadridOutboundContext() {
        try {

            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid",
                _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory.class.getClassLoader());

        } catch (JAXBException e) {
            logger.error("An error occurred while getting JAXBMadridContext instance", e);
        }
        return null;

    }

    private static JAXBContext initMadridServiceContext(Object object) {
        try {

            return JAXBContext.newInstance(object.getClass(), object.getClass());
        } catch (JAXBException e) {
            logger.error("An error occurred while getting JAXBMadridContext instance", e);
        }
        return null;

    }

    @Override
    public <T> ByteArrayOutputStream marshalIt(Marshaller marshaller, JAXBElement<T> madridObject)
        throws JAXBException {

        ByteArrayOutputStream os = new ByteArrayOutputStream();

        @SuppressWarnings({"unchecked", "rawtypes"})
        JAXBElement jaxbElement = new JAXBElement(madridObject.getName(), madridObject.getClass(),
            madridObject.getValue());
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "utf-8");
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.marshal(jaxbElement, os);

        return os;
    }

    @Override
    public void printRequestResponse(Object request) throws JAXBException {

        try {
            JAXBContext jaxbMadridServiceContext = initMadridServiceContext(request);
            Marshaller m = jaxbMadridServiceContext.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            JAXBElement jx = new JAXBElement(new QName(request.getClass().getName()), request.getClass(), request);

            StringWriter stringWriter = new StringWriter();
            m.marshal(jx, stringWriter);
            logger.debug(stringWriter.toString());
            try {
                stringWriter.flush();
                stringWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (JAXBException ex) {
            logger.error("An error occurred in printRequestResponse", ex);
        }
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public <T> T unmarshallTransaction(BigDecimal intlIrTranId) throws JAXBException, SQLException {

        Unmarshaller unmarshallerRoot = jaxbMadridContext.createUnmarshaller();

        IntlIrTran intlIrTran = intlIrTranDao.getIrTranById(intlIrTranId);
        @SuppressWarnings("unchecked")
        JAXBElement<T> transactionType = (JAXBElement<T>) unmarshallerRoot
            .unmarshal(intlIrTran.getXmlContent().getBinaryStream());

        return transactionType.getValue();
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public <T> T unmarshallOutboundTransaction(BigDecimal intlIrTranId) throws JAXBException, SQLException {

        Unmarshaller unmarshallerRoot = jaxbMadridOutboundContext.createUnmarshaller();

        IntlIrTran intlIrTran = intlIrTranDao.getIrTranById(intlIrTranId);
        @SuppressWarnings("unchecked")
        JAXBElement<T> transactionType = (JAXBElement<T>) unmarshallerRoot
            .unmarshal(intlIrTran.getXmlContent().getBinaryStream());

        return transactionType.getValue();
    }

    @Override
    public JAXBContext getMadridJAXBContext() {
        return jaxbMadridContext;
    }

    @Override
    public JAXBContext getMadridOutboundJAXBContext() {
        return jaxbMadridOutboundContext;
    }

    @Override
    public <T> ByteArrayOutputStream marshalExportMessageWithValidation(Marshaller marshaller,
                                                                        JAXBElement<T> madridObject)
        throws Exception {

        Resource resource = new ClassPathResource("messages.properties");
        String absFileRootPath = resource.getFile().getParent() + File.separator + "schemas" + File.separator + "xsd"
            + File.separator + "wipo" + File.separator;

        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = sf.newSchema(new File(absFileRootPath + xsdFileName));
        marshaller.setSchema(schema);
        marshaller.setEventHandler(new ValidationEventHandler() {

            @Override
            public boolean handleEvent(ValidationEvent event) {
                logger.error("Error attempting to validate export message: ", event.getMessage());
                throw new RuntimeException(event.getMessage(), event.getLinkedException());
            }
        });

        return marshalIt(marshaller, madridObject);
    }

}
