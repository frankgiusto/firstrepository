package ca.gc.ic.cipo.tm.mts.service.intrepid;

import org.apache.log4j.Logger;

import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
// import ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault;
import ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault;
import ca.gc.ic.cipo.tm.tirs.common.TMInfoRetrievalCommonServicePortType;
import ca.gc.ic.cipo.tm.tirs.common.TrademarkInfoRetrievalCommonServiceFactory;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyBagType;

public class IntrepidTIRSApplicationService {

    private static Logger log = Logger.getLogger(IntrepidTIRSApplicationService.class.getName());

    private String tmirServiceHost;

    public IntrepidTIRSApplicationService(String tmirServiceHost) {
        this.tmirServiceHost = tmirServiceHost;
    }

    public TMInfoRetrievalDto getIntrepidApplication(ProcessActionsMeta processActionsMeta) {

        TMInfoRetrievalDto tmInfoRetrievalBean = new TMInfoRetrievalDto();

        TMInfoRetrievalCommonServicePortType client = TrademarkInfoRetrievalCommonServiceFactory
            .createClient(tmirServiceHost);

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(processActionsMeta.getFileNumber().intValue());
        applicationNumber.setExtensionCounter(Integer.valueOf(processActionsMeta.getExtensionCounter()));

        try {
            tmInfoRetrievalBean
                .setTrademarkApplicationDetailsType(client.getTrademarkApplicationDetails(applicationNumber));
            tmInfoRetrievalBean.setTrademarkApplicationType(client.getApplicationByNumber(applicationNumber));

            TMInterestedPartyBagType tmInterestedPartyBagType = client
                .getInterestedPartiesByApplication(applicationNumber);

            tmInfoRetrievalBean.setTmInterestedPartyTypeList(tmInterestedPartyBagType.getTMInterestedParty());

        } catch (CIPOServiceFault e) {
            log.error("Error getting intrepid information from TrademarkInfoRetrievalCommonService.", e);

        }
        return tmInfoRetrievalBean;
    }
}
