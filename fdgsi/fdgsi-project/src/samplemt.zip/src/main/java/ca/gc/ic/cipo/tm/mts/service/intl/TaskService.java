package ca.gc.ic.cipo.tm.mts.service.intl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskXrefDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlOfficeTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskAddtnlInfoDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskAddtnlInfoTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTask;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTaskXref;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfo;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionList;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskMetaList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;

@Service
public class TaskService extends MadridTransactionService implements ITaskService {

    @Autowired
    private IntlIrTaskDao intlIrTaskDao;

    @Autowired
    private IntlIrTaskXrefDao intlIrTaskXrefDao;

    @Autowired
    private IntlTaskAddtnlInfoDao intlTaskAddtnlInfoDao;

    @Autowired
    private IntlTaskAddtnlInfoTypeDao intlTaskAddtnlInfoTypeDao;

    @Autowired
    private IntlOfficeTypeDao intlOfficeTypeDao;

    @Autowired
    private IntlTaskTypeDao intlTaskTypeDao;

    @Autowired
    private IntlTaskStatusTypeDao intlTaskStatusTypeDao;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    private static Logger logger = Logger.getLogger(TaskService.class.getName());

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<ConsoleTaskResponse> getUserTaskInformation(BigDecimal intlIrTranId,
                                                            Map<ApplicationDto, UserTaskType> userTaskTypes) {

        if (null == userTaskTypes || userTaskTypes.size() == 0) {
            return new ArrayList<>();
        }

        ConsoleTaskList consoleTaskList = new ConsoleTaskList();
        Set<ApplicationDto> applications = userTaskTypes.keySet();
        Iterator<ApplicationDto> applicationIterator = applications.iterator();

        while (applicationIterator.hasNext()) {

            ApplicationDto applicationDto = applicationIterator.next();
            UserTaskType userTaskType = userTaskTypes.get(applicationDto);

            // boolean inactive = false;
            if (null != userTaskType) {
                // This will be sent back to MWE
                ConsoleTaskMeta userTaskInfo = getUserTaskInformation(intlIrTranId, applicationDto, userTaskType);

                // SUC 2.4.3
                // 4.1 Notify TMB Supervisor to Review Partial Change of Ownership
                if (userTaskType.equals(UserTaskType.REVIEW_PARTIAL_OWNERSHIP_CHANGE)) {

                    // FIXME: Use actual message from properties instead of hardcoding???
                    // TODO yes --> FIXME: Use actual message from properties instead of hardcoding?
                    IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
                    IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
                    intlTaskAddtnlInfoTypeDto.setTaskAddtnlInfoCtgryId(
                        BigDecimal.valueOf(TaskAddtnlInfoType.PARTIAL_OWNERSHIP_CHANGE_BEING_PROCESSED.getValue()));
                    intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
                    intlTaskAddtnlInfoDto
                        .setAddtnlInfo("Partial Ownership Change - Designation/Restriction Task being processed");
                    userTaskInfo.getAdditionalInfos().add(intlTaskAddtnlInfoDto);

                }

                consoleTaskList.getTaskListBag().add(userTaskInfo);

            }
        }
        return this.createUserTask(consoleTaskList);
    }

    private ConsoleTaskMeta getUserTaskInformation(BigDecimal intlIrTranId, ApplicationDto applicationDto,
                                                   UserTaskType userTaskType) {
        ConsoleTaskMeta consoleTaskMeta = new ConsoleTaskMeta();
        consoleTaskMeta.setExtensionCounter(applicationDto.getExtensionCounter());
        consoleTaskMeta.setFileNumber(
            (applicationDto.getFileNumber() != null ? BigDecimal.valueOf(applicationDto.getFileNumber()) : null));
        consoleTaskMeta.setIntlFilingRecordId(applicationDto.getIntlFilingRecordId());
        consoleTaskMeta.setIrNumber(applicationDto.getIrNumber());
        consoleTaskMeta.setUserTaskType(userTaskType.getValue());
        if (null == applicationDto.getTaskStatusCode()) {
            consoleTaskMeta.setUserTaskStatus(TaskStatusType.UNPROCESSED.getValue());
        } else {
            consoleTaskMeta.setUserTaskStatus(applicationDto.getTaskStatusCode());
        }
        consoleTaskMeta.setOfficeType(applicationDto.getOfficeType());
        consoleTaskMeta.setWipoReferenceNumber(applicationDto.getWipoReferenceNumber());

        if (StringUtils.isNotBlank(applicationDto.getAdditionalInfo())) {
            IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
            IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
            intlTaskAddtnlInfoTypeDto.setTaskAddtnlInfoCtgryId(
                BigDecimal.valueOf(TaskAddtnlInfoType.APPLICATION_ADDITIONAL_INFO.getValue()));
            intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
            intlTaskAddtnlInfoDto.setAddtnlInfo(applicationDto.getAdditionalInfo());
            consoleTaskMeta.getAdditionalInfos().add(intlTaskAddtnlInfoDto);
        }

        consoleTaskMeta.getTransactionIds().add(intlIrTranId);

        if (StringUtils.isEmpty(applicationDto.getAuthorityId())) {

            IntlIrTranDto transaction = internationalService.getTransactionsByIrTranId(intlIrTranId);
            TransactionCategory transactionCategory = TransactionCategory
                .getTransactionCategoryByValue(transaction.getIntlPkgTranType().getPkgTranCtgryId());

            // Is this an automated transaction? if so, group assignment should have already been done.
            if (MadridTransactionType.getAutomatedTransactionCategories().contains(transactionCategory)) {

                logger.debug("Task group not assigned... Why? Setting to TM OPERATOR for now.");
                consoleTaskMeta.setAuthorityId(SectionAuthority.MC_TM_OPERATOR.name());
            }

        } else {
            consoleTaskMeta.setAuthorityId(applicationDto.getAuthorityId());
        }
        return consoleTaskMeta;
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<ConsoleTaskResponse> getUserTaskInformation(TransactionPairDto ownershipChangePartial,
                                                            Map<ApplicationDto, UserTaskType> userTaskTypes) {

        Set<ApplicationDto> applications = userTaskTypes.keySet();
        Iterator<ApplicationDto> applicationIterator = applications.iterator();

        ConsoleTaskList consoleTaskList = new ConsoleTaskList();

        while (applicationIterator.hasNext()) {
            ApplicationDto applicationDto = applicationIterator.next();
            UserTaskType userTaskType = userTaskTypes.get(applicationDto);

            // This will be sent back to MWE
            ConsoleTaskMeta consoleTask = getUserTaskInformation(
                ownershipChangePartial.getPairedTransaction().getIrTranId(), applicationDto, userTaskType);

            // add the seconds transaction id
            consoleTask.getTransactionIds().add(ownershipChangePartial.getMadridDesignationTransaction().getIrTranId());
            consoleTaskList.getTaskListBag().add(consoleTask);

        }
        return this.createUserTask(consoleTaskList);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<ConsoleTaskResponse> createUserTask(ConsoleTaskList consoleTaskList) {

        Timestamp timestamp = new Timestamp(new Date().getTime());
        List<ConsoleTaskResponse> consoleTaskBag = new ArrayList<>();

        for (ConsoleTaskMeta consoleTaskMeta : consoleTaskList.getTaskListBag()) {

            ConsoleTaskResponse consoleTaskResponse = new ConsoleTaskResponse();
            IntlIrTask intlIrTask = createIntlIrTask(consoleTaskMeta, timestamp);

            logger.debug("Creating new task - TaskId: "
                + (intlIrTask.getTaskId() != null ? intlIrTask.getTaskId() : "To be created") + ", TaskType : "
                + (intlIrTask.getIntlTaskType() != null ? intlIrTask.getIntlTaskType().getTaskCtgry() : "NULL")
                + ", Domestic Application File Number : "
                + (intlIrTask.getDmstcApltnFileNbr() != null ? intlIrTask.getDmstcApltnFileNbr() : "NULL")
                + ", Domestic Application File Number Ext : "
                + (intlIrTask.getDmstcApltnFileExtn() != null ? intlIrTask.getDmstcApltnFileExtn() : "NULL")
                + ", IR Office Category : " + (intlIrTask.getIntlIrOfficeType() != null
                    ? intlIrTask.getIntlIrOfficeType().getIrOfficeCtgry() : "NULL")
                + ", Intl Reg No : " + intlIrTask.getIntlRegNo());

            intlIrTaskDao.save(intlIrTask);

            logger.info("CNew IR task created. TaskId <" + intlIrTask.getTaskId() + ">. Task description <"
                + intlIrTask.getIntlTaskType().getDescEn()
                + ">. However this task is not finalized with workflow engine to assign activiti Id");

            consoleTaskResponse.setConsoleTaskId(intlIrTask.getTaskId());
            // may be null
            consoleTaskResponse.setConsoleTaskGroupId(consoleTaskMeta.getAuthorityId());
            consoleTaskResponse.setUserTaskType(consoleTaskMeta.getUserTaskType());
            consoleTaskBag.add(consoleTaskResponse);

            for (BigDecimal transactionId : consoleTaskMeta.getTransactionIds()) {
                IntlIrTaskXref intlIrTaskXref = createIntlIrTaskXref(intlIrTask, transactionId);

                intlIrTaskXrefDao.save(intlIrTaskXref);

            }

            if (CollectionUtils.isNotEmpty(consoleTaskMeta.getAdditionalInfos())) {
                Set<IntlTaskAddtnlInfo> intlTaskAddtnlInfos = createIntlIrTaskAddtnlInfo(intlIrTask,
                    consoleTaskMeta.getAdditionalInfos());

                for (IntlTaskAddtnlInfo intlTaskAddtnlInfo : intlTaskAddtnlInfos) {
                    if (StringUtils.isNotBlank(intlTaskAddtnlInfo.getAddtnlInfo())) {
                        intlTaskAddtnlInfoDao.save(intlTaskAddtnlInfo);
                    }

                }
            }

        }

        return consoleTaskBag;

    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void reactivateTasks(BigDecimal fileNumber) {
        intlIrTaskDao.reactivateTasks(fileNumber);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public List<IntlIrTaskDto> getTasksByTransactionId(BigDecimal irTranId) {

        List<IntlIrTask> transactionTaskList = intlIrTaskDao.getTasksByTransactionId(irTranId);
        return internationalDTOFactory.getIRTaskListDto(transactionTaskList);
    }

    private IntlIrTask createIntlIrTask(ConsoleTaskMeta consoleTaskMeta, Timestamp timestamp) {

        IntlIrTask intlIrTask = new IntlIrTask();
        intlIrTask.setActHiTaskInstId(consoleTaskMeta.getTaskReferenceId());
        intlIrTask.setDmstcApltnFileNbr((consoleTaskMeta.getFileNumber() == null ? null
            : Long.valueOf(consoleTaskMeta.getFileNumber().longValue())));

        intlIrTask.setIntlIrOfficeType(intlOfficeTypeDao.getOfficeTypeById(
            Long.valueOf((OfficeType.getOfficeTypeByName(consoleTaskMeta.getOfficeType())).getValue())));
        intlIrTask.setDmstcApltnFileExtn(String.valueOf(consoleTaskMeta.getExtensionCounter()));
        intlIrTask.setIntlRegNo(consoleTaskMeta.getIrNumber());
        intlIrTask.setWipoRefNbr(consoleTaskMeta.getWipoReferenceNumber());

        if (CollectionUtils.isNotEmpty(consoleTaskMeta.getAdditionalInfos())) {
            createIntlIrTaskAddtnlInfo(intlIrTask, consoleTaskMeta.getAdditionalInfos());

        }

        // Name of the User Task as seen on the console
        intlIrTask
            .setIntlTaskType(intlTaskTypeDao.getTaskTypeById(BigDecimal.valueOf(consoleTaskMeta.getUserTaskType())));

        // Status of the user task. Will be unprocessed or onHold.
        intlIrTask.setIntlTaskStatusType(
            intlTaskStatusTypeDao.getTaskStatusTypeById(BigDecimal.valueOf(consoleTaskMeta.getUserTaskStatus())));

        intlIrTask.setCreatedTmstmp(timestamp);

        if (consoleTaskMeta.getProcessActionDate() == null) {
            intlIrTask.setUpdatedTmstmp(timestamp);
        } else {
            intlIrTask.setUpdatedTmstmp(new Timestamp(consoleTaskMeta.getProcessActionDate().getTime()));
        }

        return intlIrTask;
    }

    private IntlIrTaskXref createIntlIrTaskXref(IntlIrTask intlIrTask, BigDecimal intlIrTranId) {

        IntlIrTaskXref intlIrTaskXref = new IntlIrTaskXref();
        intlIrTaskXref.setIrTranId(intlIrTranId);
        intlIrTaskXref.setTaskId(intlIrTask.getTaskId());

        return intlIrTaskXref;
    }

    private Set<IntlTaskAddtnlInfo> createIntlIrTaskAddtnlInfo(IntlIrTask intlIrTask,
                                                               List<IntlTaskAddtnlInfoDto> intlTaskAddtnlInfoDto) {
        Set<IntlTaskAddtnlInfo> intlTaskAddtnlInfoSet = new HashSet<>();
        for (IntlTaskAddtnlInfoDto addtnlInfoDto : intlTaskAddtnlInfoDto) {
            IntlTaskAddtnlInfo intlTaskAddtnlInfo = new IntlTaskAddtnlInfo();
            intlTaskAddtnlInfo.setTaskId(intlIrTask.getTaskId());
            intlTaskAddtnlInfo.setAddtnlInfo(addtnlInfoDto.getAddtnlInfo());
            intlTaskAddtnlInfo.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));

            IntlTaskAddtnlInfoType intlTaskAddtnlInfoType = intlTaskAddtnlInfoTypeDao
                .getTaskAddtnlInfoTypeById(addtnlInfoDto.getIntlTaskAddtnlInfoTypeDto().getTaskAddtnlInfoCtgryId());

            intlTaskAddtnlInfo.setTaskAddtnlInfoCtgry(intlTaskAddtnlInfoType);

            intlTaskAddtnlInfoSet.add(intlTaskAddtnlInfo);
        }

        intlIrTask.setIntlTaskAddtnlInfo(intlTaskAddtnlInfoSet);

        return intlTaskAddtnlInfoSet;

    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void updateConsoleTaskReference(String taskReferenceId, BigDecimal consoleTaskId) {

        logger.debug(
            "updateConsoleTaskReference - taskReferenceId:" + taskReferenceId + ", consoleTaskId:" + consoleTaskId);

        if (StringUtils.isEmpty(taskReferenceId)) {
            throw new IllegalArgumentException("Must provide a taskReferenceId");
        }

        IntlIrTask intlIrTask = intlIrTaskDao.getIrTaskById(consoleTaskId);

        intlIrTask.setActHiTaskInstId(taskReferenceId);

        intlIrTaskDao.save(intlIrTask);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType consoleTaskStatus) {

        if (null == consoleTaskStatus) {
            throw new IllegalArgumentException("Invalid ConsoleTaskStatusType" + consoleTaskStatus);
        }

        IntlIrTask intlIrTask = intlIrTaskDao.getIrTaskById(consoleTaskId);

        Integer taskStatus = null;
        if (consoleTaskStatus == ConsoleTaskStatusType.UNPROCESSED) {
            taskStatus = TaskStatusType.UNPROCESSED.getValue();
        } else if (consoleTaskStatus == ConsoleTaskStatusType.PROCESSED) {
            taskStatus = TaskStatusType.PROCESSED.getValue();
        } else {
            throw new IllegalArgumentException("Invalid ConsoleTaskStatusType" + consoleTaskStatus);
        }
        intlIrTask.setIntlTaskStatusType(intlTaskStatusTypeDao.getTaskStatusTypeById(BigDecimal.valueOf(taskStatus)));

        intlIrTaskDao.save(intlIrTask);
    }

    @Override
    @Transactional(value = "tmIntlTransactionManager")
    public IntlIrTaskDto getIrTaskById(BigDecimal taskId) {

        return internationalDTOFactory.getIRTaskDto(intlIrTaskDao.getIrTaskById(taskId));

    }

    @Override
    public WorkflowTaskListResponse getWorkflowTaskList(WorkflowTaskListSearchCriteria request)
        throws CIPOServiceFault {

        WorkflowTaskListResponse response = new WorkflowTaskListResponse();

        // 1. Get Tasks from the International DB
        WorkflowTaskMetaList workflowTaskMetaList = internationalService.getConsoleTasks(request);

        long totalRecords = internationalService.getTotalTasks(request);
        long totalDisplayed = totalRecords; // until filtering is implemented.

        try {
            response.setTotalTasks(BigInteger.valueOf(totalRecords));
            response.setTotalTasksForDisplay(BigInteger.valueOf(totalDisplayed));
            response.setWorkflowTaskMetaList(workflowTaskMetaList);

        } catch (Throwable e) {
            logger.error("Error getting data from madrid transaction service.", e);

            ServiceFaultDetails faultInfo = new ServiceFaultDetails();
            throw new CIPOServiceFault("Faied to call web service exportMessage", faultInfo, e);
        }

        return response;
    }

    @Override
    public TaskDescriptionListResponse getTaskDescriptionList(TaskDescriptionListSearchCriteria taskDescriptionListSearchCriteria)
        throws CIPOServiceFault {

        TaskDescriptionListResponse response = new TaskDescriptionListResponse();

        try {
            TaskDescriptionList list = internationalService.getTaskDescriptionList(taskDescriptionListSearchCriteria);
            response.setTaskDescriptionList(list);
            int size = list.getTaskListBag().size();
            response.setTotalItems(BigInteger.valueOf(size));

        } catch (Throwable e) {
            logger.error("Error getting data from madrid transaction service.", e);

            ServiceFaultDetails faultInfo = new ServiceFaultDetails();
            throw new CIPOServiceFault("Faied to call web service exportMessage", faultInfo, e);
        }

        return response;

    }

}
