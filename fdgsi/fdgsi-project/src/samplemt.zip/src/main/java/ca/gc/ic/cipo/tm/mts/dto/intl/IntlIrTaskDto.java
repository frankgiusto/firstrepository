package ca.gc.ic.cipo.tm.mts.dto.intl;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class IntlIrTaskDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -4629756410648914251L;

    private String taskReferenceId;

    private BigDecimal taskId;

    private Integer fileNumber;

    private String extensionCounter;

    private String irNumber;

    private String wipoReferenceNumber;

    private String officeType;

    private String authorityId;

    private IntlTaskStatusTypeDto taskStatusTypeDto;

    private IntlTaskTypeDto taskTypeDto;

    private List<IntlTaskAddtnlInfoDto> intlTaskAddtnlInfoDto;

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public Integer getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(Integer fileNumber) {
        this.fileNumber = fileNumber;
    }

    public String getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(String extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public String getIrNumber() {
        return irNumber;
    }

    public void setIrNumber(String irNumber) {
        this.irNumber = irNumber;
    }

    public IntlTaskTypeDto getTaskTypeDto() {
        return taskTypeDto;
    }

    public void setTaskTypeDto(IntlTaskTypeDto taskTypeDto) {
        this.taskTypeDto = taskTypeDto;
    }

    public String getWipoReferenceNumber() {
        return wipoReferenceNumber;
    }

    public void setWipoReferenceNumber(String wipoReferenceNumber) {
        this.wipoReferenceNumber = wipoReferenceNumber;
    }

    public String getOfficeType() {
        return officeType;
    }

    public void setOfficeType(String officeType) {
        this.officeType = officeType;
    }

    public String getAuthorityId() {
        return authorityId;
    }

    public void setAuthorityId(String authorityId) {
        this.authorityId = authorityId;
    }

    public String getTaskReferenceId() {
        return taskReferenceId;
    }

    public void setTaskReferenceId(String taskReferenceId) {
        this.taskReferenceId = taskReferenceId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(" taskReferenceId:").append(taskReferenceId);
        sb.append(", taskId:").append(taskId);
        sb.append(", fileNumber:").append(fileNumber);
        sb.append(", extensionCounter:").append(extensionCounter);
        sb.append(", irNumber:").append(irNumber);

        return sb.toString();
    }

    public IntlTaskStatusTypeDto getTaskStatusTypeDto() {
        return taskStatusTypeDto;
    }

    public void setTaskStatusTypeDto(IntlTaskStatusTypeDto taskStatusTypeDto) {
        this.taskStatusTypeDto = taskStatusTypeDto;
    }

    public List<IntlTaskAddtnlInfoDto> getIntlTaskAddtnlInfoDto() {
        if (null == intlTaskAddtnlInfoDto) {
            intlTaskAddtnlInfoDto = new ArrayList<>();
        }
        return intlTaskAddtnlInfoDto;
    }

    public void setIntlTaskAddtnlInfoDto(List<IntlTaskAddtnlInfoDto> intlTaskAddtnlInfoDto) {
        this.intlTaskAddtnlInfoDto = intlTaskAddtnlInfoDto;
    }
}
