package ca.gc.ic.cipo.tm.mts.enums;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ca.gc.ic.cipo.tm.enumerator.MailType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;

public class MailTypeTransactionCategory {

    public static final Map<TransactionCategory, MailType> transactionMailTypeMap;
    static {
        Map<TransactionCategory, MailType> aMap = new HashMap<>();
        aMap.put(TransactionCategory.MD_REGISTRATION, MailType.MADRID_DESIGNATION_REGISTRATION);
        aMap.put(TransactionCategory.MD_SUBSEQUENT_DESIGNATION, MailType.MADRID_DESIGNATION_SUBSEQUENT_DESIGNATION);
        aMap.put(TransactionCategory.MR_RENEWAL, MailType.MADRID_RENEWAL);
        aMap.put(TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK, MailType.MADRID_NON_RENEWAL);
        aMap.put(TransactionCategory.MDT_NON_RENEWAL_OF_CONTRACTING_PARTY, MailType.MADRID_NON_RENEWAL);
        aMap.put(TransactionCategory.MHR_CHANGE_OF_OWNER, MailType.MADRID_CHANGE_OF_OWNERSHIP_TOTAL);
        aMap.put(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION, MailType.MADRID_CHANGE_OF_OWNERSHIP_PARTIAL);
        aMap.put(TransactionCategory.DESIGNATION_TERMINATION, MailType.MADRID_CHANGE_OF_OWNERSHIP_PARTIAL);
        aMap.put(TransactionCategory.MD_MERGER, MailType.MADRID_CHANGE_OF_OWNERSHIP_MERGER);
        aMap.put(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT, MailType.MADRID_CEASING_OF_EFFECT_TOTAL_DO);
        aMap.put(TransactionCategory.MPR_PARTIAL_CEASING_OF_EFFECT, MailType.MADRID_CEASING_OF_EFFECT_PARTIAL_DO);
        aMap.put(TransactionCategory.MDT_TOTAL_CANCELLATION, MailType.MADRID_CANCELLATION_TOTAL);
        aMap.put(TransactionCategory.MPR_LIMITATION, MailType.MADRID_LIMITATION);
        aMap.put(TransactionCategory.MPR_PARTIAL_CANCELLATION, MailType.MADRID_CANCELLATION_PARTIAL);
        aMap.put(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS, MailType.MADRID_CHANGE_OF_HOLDER_NAME_ADDRESS);
        aMap.put(TransactionCategory.MDT_RENUNCIATION, MailType.MADRID_RENUNCIATION);
        aMap.put(TransactionCategory.MBR_APPLICATION_CHANGE, MailType.MADRID_BASIC_REGISTRATION_APPLICATION_CHANGE);
        aMap.put(TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE, MailType.MADRID_CHANGE_OF_REPRESENTATIVE);
        aMap.put(TransactionCategory.MI_IRREGULARITY_NOTIFICATION, MailType.MADRID_IRREGULARITY_NOTIFICATION);
        aMap.put(TransactionCategory.MC_CORRECTION, MailType.MADRID_CORRECTION);
        aMap.put(TransactionCategory.MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL,
            MailType.MADRID_RESTRICTION_OF_HOLDERS_RIGHT_DISPOSAL);
        aMap.put(TransactionCategory.MADRID_ABANDONMENT_NOTIFICATION, MailType.MADRID_ABANDONMENT_NOTIFICATION);

        transactionMailTypeMap = Collections.unmodifiableMap(aMap);
    }

}
