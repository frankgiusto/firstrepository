package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridPossibleOppositionNotificationType;
import ca.gc.ic.cipo.common.service.CalendarUtils;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.enums.ActionDateType;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;
import ca.gc.ic.cipo.tm.tirs.types.TrademarkActionType;

public class MadridPossibleOppositionNotification extends OfficeToIbBase
    implements IOutboundTransaction, IReportingService {

    private static Logger log = Logger.getLogger(MadridPossibleOppositionNotification.class.getName());

    private MadridOutboundTransactionType madridOutboundTransactionType;

    private final static String reportNameMf1 = "MADRID_MF1";

    private final static String reportNameMf2 = "MADRID_MF2";

    public MadridPossibleOppositionNotification(MadridOutboundTransactionType madridOutboundTransactionType) {
        this.madridOutboundTransactionType = madridOutboundTransactionType;
    }

    // TIRS
    @Override
    public ByteArrayOutputStream createOutboundTransaction(OutboundTransactionDto outboundTransactionDto,
                                                           OutboundTransactionRequest outboundTransactionRequest,
                                                           IntlIrTranDto intlIrTranDto,
                                                           IMarshallingService marshallingService)
        throws Exception {

        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        TMInfoRetrievalDto tirsDto = outboundTransactionDto.getProcessActionApplication();
        MadridPossibleOppositionNotificationType transaction = objectFactory
            .createMadridPossibleOppositionNotificationType();

        // Notification Language
        ISOLanguageCodeType notificationLanguage = getNotificationLanguage(tirsDto);
        transaction.setNotificationLanguage(notificationLanguage);

        // Office Reference Identifier - DO
        transaction.setOfficeReferenceIdentifier(mapIdentifier(intlIrTranDto.getIrTranId().toString()));

        // IR Number
        transaction.setInternationalRegistrationNumber(outboundTransactionDto.getIntlRegNo());

        // Opposition Start Date
        List<TrademarkActionType> trademarkActionTypes = tirsDto.getTrademarkActionTypes();
        SortedSet<Date> actionDates = new TreeSet<>(getTrademarkActionDateComparator());
        if (null != trademarkActionTypes) {
            for (TrademarkActionType trademarkActionType : trademarkActionTypes) {
                if (trademarkActionType.getActionCode() == ActionDateType.ADVERTISED_DATE.getActionCode()) {
                    actionDates.add(CalendarUtils.toDate(trademarkActionType.getActionDate()));
                }
            }
            // We want the latest date if we have any
            if (actionDates.size() > 0) {
                transaction.setOppositionPeriodStartDate(actionDates.last().toString());
            }
        }

        // Record Notification Date
        transaction.setRecordNotificationDate(convertDateToString(intlIrTranDto.getCreatedTmstmp()));

        // Holder Bag
        transaction.setHolderBag(super.mapHolder(tirsDto.getTmInterestedPartyTypeList(), notificationLanguage));

        // Document Included Bag
        List<String> documents = new ArrayList<>();
        StringBuilder documentName = null;

        String includedDocName = null;

        if (madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1) {
            includedDocName = getUniqueReportName(reportNameMf1, outboundTransactionDto.getIntlRegNo(),
                intlIrTranDto.getIrTranId().toString());
        } else {
            includedDocName = getUniqueReportName(reportNameMf2, outboundTransactionDto.getIntlRegNo(),
                intlIrTranDto.getIrTranId().toString());
        }

        documentName = createDocument(includedDocName);
        documents.add(documentName.toString());
        transaction.setDocumentIncludedBag(super.mapDocumentBag(documents));

        JAXBElement<MadridPossibleOppositionNotificationType> madridobject = objectFactory
            .createMadridPossibleOppositionNotification(transaction);
        return marshalTransactionWithValidation(madridobject, marshallingService);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost)
        throws Exception {
        return generateReport(transactionOutputStream, tranId, marshallingService, reportServiceHost, null);
    }

    @Override
    public MadridReportResponse generateReport(ByteArrayOutputStream transactionOutputStream, BigDecimal tranId,
                                               IMarshallingService marshallingService, String reportServiceHost,
                                               Object inObject)
        throws Exception {

        MadridPossibleOppositionNotificationType notificationType = marshallingService
            .unmarshallOutboundTransaction(tranId);

        StringBuilder xmlDataSource = new StringBuilder();
        xmlDataSource.append(OfficeToIbBase.xmlHeader);
        XMLTagUtil.appendTagStart(xmlDataSource, OfficeToIbBase.reportXpath);

        String tagName = OfficeToIbBase.xmltagName_ORID;
        String value = formatValue(notificationType.getOfficeReferenceIdentifier().getValue());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_NL;
        value = notificationType.getNotificationLanguage().value();
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_IR;
        value = formatValue(notificationType.getInternationalRegistrationNumber());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        tagName = OfficeToIbBase.xmltagName_HOLDER;
        value = buildHolderValue(notificationType.getHolderBag());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        String reportName = (this.madridOutboundTransactionType == MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1
            ? reportNameMf1 : reportNameMf2);

        if (reportName.equalsIgnoreCase(reportNameMf2)) {
            tagName = "OppositionPeriodStartDate";
            value = formatValue(notificationType.getOppositionPeriodStartDate());
            XMLTagUtil.appendTag(xmlDataSource, tagName, value);
        }

        tagName = OfficeToIbBase.xmltagName_SIGN;
        XMLTagUtil.appendTag(xmlDataSource, tagName);

        tagName = OfficeToIbBase.xmltagName_IBNDate;
        value = formatValue(notificationType.getRecordNotificationDate());
        XMLTagUtil.appendTag(xmlDataSource, tagName, value);

        XMLTagUtil.appendTagClose(xmlDataSource, OfficeToIbBase.reportXpath);
        log.debug(xmlDataSource.toString());

        Locale locale = ((notificationType.getNotificationLanguage().value().equalsIgnoreCase(LOCAL_EN)) ? Locale.CANADA
            : Locale.CANADA_FRENCH);

        String jobId = scheduleReport(reportServiceHost, xmlDataSource.toString(),
            (MtsStringUtil.SLASH + OfficeToIbBase.reportXpath), reportName, null, locale);

        MadridReportResponse madridReportResponse = new MadridReportResponse();
        madridReportResponse.setJobId(jobId);

        String includedDocName = getUniqueReportName(reportName, notificationType.getInternationalRegistrationNumber(),
            tranId.toString());

        madridReportResponse.setReportName(includedDocName);

        return madridReportResponse;
    }

    @Override
    public boolean isPdfRequired() {
        return true;
    }

    @Override
    public MadridOutboundTransactionType getMadridOutboundTransactionType() {
        return madridOutboundTransactionType;
    }
}
