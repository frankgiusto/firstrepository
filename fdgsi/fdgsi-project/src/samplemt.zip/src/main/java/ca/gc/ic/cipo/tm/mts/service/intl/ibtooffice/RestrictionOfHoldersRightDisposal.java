package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;

/**
 *
 * @author rahmana1
 *
 *         The class RestrictionOfHoldersRightDisposal is responsible for processing inbound transaction for Restriction
 *         of Holders Right Disposal.
 *
 */
@Service(value = "holdersRightDisposal")
public class RestrictionOfHoldersRightDisposal extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private FootNotesDao footnotesDao;

    @Autowired
    private ActionDao actionDao;

    private static Logger logger = Logger.getLogger(RestrictionOfHoldersRightDisposal.class.getName());

    @Override
    @Transactional(rollbackFor = Exception.class)
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug(
            "Processing Restriction of Holders Right Disposal : Intrl Record Id: " + intlIrTran.getIntlRecordId());

        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        MadridProtectionRestrictionType transaction = (MadridProtectionRestrictionType) transType;

        // Get all applications matching transactions international registration number.

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }
                // Recored application with same IR number
                statusTypeResults.put(intrepidDTOFactory.getApplicationDto(application, OfficeType.DO), null);

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    Action action = super.createAction(application, ActionCode.RESTRICTION_RECORDED,
                        SectionAuthority.AAR.name());
                    actionDao.saveAction(action);

                    Footnote footnote = new Footnote();
                    footnote.setApplication(application);
                    footnote.setFileNumber(application.getFileNumber());
                    footnote.setExtensionCounter(application.getExtensionCounter());
                    footnote.setSequenceNumber(getNextFootnoteSequence(application.getFootnotes()));
                    footnote.setType(FootnoteType.SECURITY_AGREEMENT_PLACE_ON_FILE.getValue());
                    footnote.setDateRegistered(new Date());
                    footnote.setText(null);
                    try {

                        footnote.setDateOfChange(DateFormats.getISOSDF().parse(transaction.getRecordEffectiveDate()));
                    } catch (ParseException e) {
                        logger.error("Error setting action date");
                    }

                    footnotesDao.saveFootNote(footnote);
                    application.getFootnotes().add(footnote);
                    applicationDao.saveApplication(application);

                } else {
                    logger.error(
                        "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
                    throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
                }
            }
        } else {
            // Madrid Mark does not exist
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");

            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);

        }

        return statusTypeResults;
    }

}
