package ca.gc.ic.cipo.tm.mts.enums;

public enum DelimeterType {

    PARTIAL_OWNERSHIP_NEW_MARK_ID("New File:");

    private String delimeter;

    private DelimeterType(String delimeter) {
        this.setDelimeter(delimeter);
    }

    public String getDelimeter() {
        return delimeter;
    }

    public void setDelimeter(String delimeter) {
        this.delimeter = delimeter;
    }
}
