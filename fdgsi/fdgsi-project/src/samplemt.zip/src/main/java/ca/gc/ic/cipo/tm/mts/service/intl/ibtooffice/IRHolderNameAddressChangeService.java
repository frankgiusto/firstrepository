package ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.enums.ActiveApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.PendingApplicationTypes;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.MadridTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * @author giustof
 *
 *         The Class IRHolderNameAddressChangeService is responsible for updating interested parties name and address in
 *         the Intrepid database with wipo international transaction information.
 */
@Service(value = "irHolderNameAddressChange")
public class IRHolderNameAddressChangeService extends MadridTransactionService implements IInboundTransaction {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private FootNotesDao footnotesDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Value("#{environment['mts.tm.information.retrieval.services.host.name']}")
    private String tmirServiceHost;

    private static Logger logger = Logger.getLogger(IRHolderNameAddressChangeService.class.getName());

    @Transactional
    @Override
    public <T> Map<ApplicationDto, UserTaskType> processInboundTransaction(IntlIrTranDto intlIrTran, T transType)
        throws MTSServiceFault {

        logger.debug("Processing IRHolderNameAddressChangeService: Intl Record Id:" + intlIrTran.getIntlRecordId());
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChange = (MadridHolderRepresentativeChangeType) transType;

        // Get all applications matching transactions international registration number.
        Map<ApplicationDto, UserTaskType> statusTypeResults = new HashMap<>();

        List<IntlIrTaskDto> taskList = intlIrTran.getIntlIrTaskList();
        if (CollectionUtils.isNotEmpty(taskList)) {
            for (IntlIrTaskDto intlIrTaskDto : taskList) {

                Application application = applicationDao
                    .getApplication(new ApplicationNumber(intlIrTaskDto.getFileNumber(), 0));
                if (null == application) {
                    logger
                        .error("Application not found for intl_ir_task file number: " + intlIrTaskDto.getFileNumber());
                    throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
                }

                if (ActiveApplicationTypes.MADRID_ACTIVE_APPLICATION_TYPES
                    .isActiveStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                    StringBuilder nameChange = new StringBuilder();
                    Set<InterestedParty> interestedParties = application.getInterestedParties();
                    LanguageType applicationLanguage = null;
                    if (CollectionUtils.isNotEmpty(interestedParties)) {
                        for (InterestedParty interestedParty : interestedParties) {
                            if (interestedParty.getRelationshipType().intValue() == RelationshipType.OWNER.getValue()
                                .intValue()) {

                                // update name/address
                                nameChange.append("From: ").append(interestedParty.getContact().getName())
                                    .append(" To: ");

                                applicationLanguage = LanguageType
                                    .getByValue(interestedParty.getLanguageOfPreference());
                            }
                        }

                        if (null != madridHolderRepresentativeChange.getHolderChangeBag()
                            && null != madridHolderRepresentativeChange.getHolderChangeBag().getHolderBag()) {

                            List<ApplicantType> applicantList = madridHolderRepresentativeChange.getHolderChangeBag()
                                .getHolderBag().getHolder();

                            // InterestedParty interestedParty = createMHRInterestedParty(application,
                            // getNextInterestedPartySequence(interestedParties));

                            InterestedParty interestedParty = interestedParties.iterator().next(); // get the first
                            // one

                            if (CollectionUtils.isEmpty(applicantList)) {
                                logger.error("madridHolderRepresentativeChangeType.getHolderChangeBag() is empty!");
                                continue;
                            }

                            // if (CollectionUtils.isNotEmpty(applicantList)) {
                            if (applicantList.size() > 1) {
                                // Notification to review ownership change
                                ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application,
                                    OfficeType.DO);
                                appDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
                                statusTypeResults.put(appDto, UserTaskType.REVIEW_OWNER_NAME);
                            }

                            // Create the Contact Information
                            setInterestedPartyContact(applicationLanguage, applicantList, application, interestedParty);

                            // Update the Interested Party Name
                            nameChange.append(interestedParty.getContact().getName());

                            setInterestedPartyAddress(applicantList, application, interestedParty,
                                madridHolderRepresentativeChange);

                            if (mailingAddressLengthNotification(applicantList, interestedParty)) {
                                // Notification that address > 8 lines by 40 chars
                                // set AuthorityId to MC_TMOB_OPERATOR
                                ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application,
                                    OfficeType.DO);
                                appDto.setAuthorityId(IntlAuthorityRole.MC_TM_OPERATOR.name());
                                statusTypeResults.put(appDto, UserTaskType.ADDRESS_EXCEEDED_LIMIT);
                            }

                            // update existing interestedParty and its addresses
                            updateInterestedPartyAndAddress(application, interestedParty);

                            // application.getInterestedParties().add(interestedParty);
                            applicationDao.saveApplication(application);

                        } else {
                            logger.error("No Interested Parties in transaction");
                            throwMTSServiceFault("mts.system.error", ExceptionReasonCode.SYSTEM_ERROR);
                        }
                    }

                    // Footnote
                    Footnote footnote = new Footnote();
                    footnote.setApplication(application);
                    footnote.setFileNumber(application.getFileNumber());
                    footnote.setExtensionCounter(application.getExtensionCounter());
                    footnote.setSequenceNumber(getNextFootnoteSequence(application.getFootnotes()));
                    footnote.setType(FootnoteType.NAME_AND_ADDRESS.getValue());
                    footnote.setDateRegistered(new Date());
                    try {
                        footnote.setDateOfChange(
                            DateFormats.getISOSDF().parse(madridHolderRepresentativeChange.getRecordEffectiveDate()));
                    } catch (ParseException e) {
                        logger.error("Could not parse record effective date: "
                            + madridHolderRepresentativeChange.getRecordEffectiveDate());
                    }
                    footnote.setText(nameChange.toString());

                    footnotesDao.saveFootNote(footnote);

                    application.getFootnotes().add(footnote);

                    // Process Action - Print Confirmation of Change – Partial Ownership
                    processActionsDao.saveProcessActions(createProcessAction(application,
                        ProcessActionsType.PRINT_IR_HOLDER_NAME_ADDRESS_CHANGE, SectionAuthority.MADRID.name()));

                    applicationDao.saveApplication(application);

                    if (application.getStatusCode() == TradeMarkStatusType.REGISTERED.getValue()) {

                        actionDao.saveAction(createAction(madridHolderRepresentativeChange, application,
                            ActionCode.AMENDMENT_TO_REGISTRATION, SectionAuthority.AAR.name(), nameChange.toString()));

                        // process open section 45 cases
                        if (openOppositionCases(application, registeredOppositionCaseTypes)) {
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            statusTypeResults.put(appDto, UserTaskType.IR_HOLDER_NAME_ADDRESS_CHANGE_OCCURRED);
                        }
                        applicationDao.saveApplication(application);

                    } else if (PendingApplicationTypes.MADRID_PENDING_APPLICATION_TYPES
                        .isPendingStatus(TradeMarkStatusType.getByValue(application.getStatusCode()))) {

                        actionDao.saveAction(createAction(madridHolderRepresentativeChange, application,
                            ActionCode.AMENDMENT_TO_APPLICATION, SectionAuthority.AAR.name(), nameChange.toString()));

                        if (openOppositionCases(application, unRegisteredOppositionCaseTypes)) {
                            ApplicationDto appDto = intrepidDTOFactory.getApplicationDto(application, OfficeType.DO);
                            appDto.setAuthorityId(IntlAuthorityRole.MC_TMOB_SUPERVISOR.name());
                            statusTypeResults.put(appDto, UserTaskType.IR_HOLDER_NAME_ADDRESS_CHANGE_OCCURRED);
                        }

                        applicationDao.saveApplication(application);

                    }
                } else {
                    logger.error(
                        "Madrid Mark is Inactive - This should not happen since CheckForExistingMark should have been called previously");
                    throwMTSServiceFault("mts.inactive.application", ExceptionReasonCode.INACTIVE_APPLICATION);
                }
            }
        } else {
            logger.error(
                "Madrid Mark does not exist - This should not happen since CheckForExistingMark should have been called previously");
            throwMTSServiceFault("mts.madrid.mark.not.found", ExceptionReasonCode.MARK_NOT_FOUND);
        }
        return statusTypeResults;
    }

    @Override
    protected boolean openOppositionCases(Application application, EnumSet<OppositionCaseType> oppositionCaseTypes) {

        Set<OppositionCase> oppositionCases = application.getOppositionCases();
        boolean open = false;
        if (CollectionUtils.isNotEmpty(oppositionCases)) {
            for (OppositionCase oppositionCase : oppositionCases) {

                if (oppositionCaseTypes.contains(OppositionCaseType.getByValue(oppositionCase.getOppCaseTypeCode()))
                    && openStatusTypes.contains(OppositionCaseStatus.getByValue(oppositionCase.getOppStatusCode()))) {

                    open = true;

                    processActionsDao.saveProcessActions(
                        createProcessAction(application, ProcessActionsType.PRINT_IR_HOLDER_NAME_ADDRESS_CHANGE,
                            oppositionCase.getOppCaseNumber(), SectionAuthority.MADRID.name()));

                }
            }
        }
        return open;
    }

    private void updateInterestedPartyAndAddress(Application application, InterestedParty interestedParty)
        throws MTSServiceFault {

        List<InterestedPartiesAddresses> existList = interestedPartiesAddressesDao.getInterestedPartiesAddresses(
            application.getFileNumber(), application.getExtensionCounter(), interestedParty.getIpNumber());
        logger.debug("Existing IP addresses: " + existList.size());

        // get existing types for comparison
        List<Integer> existTypes = getAddressTypes(existList);

        List<InterestedPartiesAddresses> newAddressList = new ArrayList<InterestedPartiesAddresses>(
            interestedParty.getContact().getInterestedPartiesAddresses());
        logger.debug("New IP addresses: " + newAddressList.size());

        for (int i = 0; i < newAddressList.size(); i++) {
            InterestedPartiesAddresses newAdr = newAddressList.get(i);
            int newType = newAdr.getAddressType();

            if (CollectionUtils.isNotEmpty(existTypes) && !existTypes.contains(newAdr.getAddressType())) {
                interestedPartiesAddressesDao.saveInterestedPartiesAddresses(newAdr);
                continue;
            }
            for (int j = 0; j < existList.size(); j++) {
                InterestedPartiesAddresses oldAdr = existList.get(j);
                int oldType = oldAdr.getAddressType();
                if (newType == oldType) {
                    oldAdr.setAddress(newAdr.getAddress());
                    interestedPartiesAddressesDao.saveInterestedPartiesAddresses(oldAdr);
                    break;
                }
            }
        }
        interestedPartyDao.saveInterestedParty(interestedParty);
    }

    private List<Integer> getAddressTypes(List<InterestedPartiesAddresses> existList) {
        if (CollectionUtils.isEmpty(existList)) {
            return new ArrayList<Integer>();
        }
        Set<Integer> types = new HashSet<Integer>();
        for (InterestedPartiesAddresses addr : existList) {
            types.add(addr.getAddressType());
        }
        return new ArrayList<Integer>(types);
    }

    @Override
    public <T> T unmarshallTransaction(IntlIrTranDto intlIrTran) throws JAXBException, SQLException {
        return marshallingService.unmarshallTransaction(intlIrTran.getIrTranId());
    }

    @Override
    public String getServiceName() {
        return "IRHolderNameAddressChangeService";
    }

}
