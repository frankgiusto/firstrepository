package ca.gc.ic.cipo.tm.mts.service.intl.officetoib;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.io.StringReader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import _int.wipo.standards.xmlschema.st96.common.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.AddressLineTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ApplicationNumberType;
import _int.wipo.standards.xmlschema.st96.common.madrid.DocumentFormatCategoryType;
import _int.wipo.standards.xmlschema.st96.common.madrid.DocumentIncludedBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.DocumentMediaCategoryType;
import _int.wipo.standards.xmlschema.st96.common.madrid.DocumentType;
import _int.wipo.standards.xmlschema.st96.common.madrid.EntityNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrganizationNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PersonNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PersonStructuredNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PhraseType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ApplicantType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.BasicApplicationBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.BasicApplicationType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.BasicRegistrationApplicationBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.BasicRegistrationApplicationType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.GoodsServicesType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.HolderBagType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MarkDisclaimerBagType;
import ca.gc.ic.cipo.report.CipoServiceFault;
import ca.gc.ic.cipo.report.ReportType;
import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.intl.enumerator.IntlFileFrmtTypeEnum;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.util.DateFormats;
import ca.gc.ic.cipo.tm.mts.util.ManualReportUtil;
import ca.gc.ic.cipo.tm.mts.util.MtsStringUtil;
import ca.gc.ic.cipo.tm.mts.util.XMLTagUtil;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;
import ca.gc.ic.cipo.xmlschema.common.ContactType;
import ca.gc.ic.cipo.xmlschema.common.NameType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.DisclaimerType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesStatementType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsType;

public abstract class OfficeToIbBase {

    private static int FIRST_INTERESTED_PARTY = 0;

    protected static String ATTACHMENT_FOLDER = "docs/";

    protected static String reportXpath = "mfReportRoot";

    protected static String xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";

    protected static String xmltagName_ORID = "OfficeReferenceIdentifier";

    protected static String xmltagName_NL = "NotificationLanguage";

    protected static String xmltagName_IR = "InternationalRegistrationNumber";

    protected static String xmltagName_HOLDER = "Holder";

    protected static String xmltagName_SIGN = "Signature";

    protected static String xmltagName_IBNDate = "RecordNotificationDate";

    private static final String PDF_EXTENTION = ".pdf";

    protected static final String LOCAL_EN = "en";

    _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

    _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

    protected IdentifierType mapIdentifier(String identifier) {
        IdentifierType identifierType = commonObjectFactory.createIdentifierType();
        identifierType.setValue(identifier);

        return identifierType;
    }

    protected HolderBagType mapHolder(List<TMInterestedPartyType> iterestedPartyList, ISOLanguageCodeType isoLanguage)
        throws CIPOServiceFault {
        HolderBagType holderBagType = objectFactory.createHolderBagType();
        ApplicantType applicantType = objectFactory.createApplicantType();

        TMInterestedPartyType tmInterestedPartyType = iterestedPartyList.get(FIRST_INTERESTED_PARTY);
        ContactType tirsContactType = tmInterestedPartyType.getContact();

        // TIRS Name Type
        NameType tirsNameType = tirsContactType.getName();

        _int.wipo.standards.xmlschema.st96.common.madrid.ContactType internationalContactType = commonObjectFactory
            .createContactType();

        // Entity Name
        if (tirsNameType.isSetEntityName()) {
            _int.wipo.standards.xmlschema.st96.common.madrid.NameType nameType = commonObjectFactory.createNameType();
            EntityNameType entityNameType = commonObjectFactory.createEntityNameType();
            entityNameType.setValue(tirsNameType.getEntityName());
            nameType.getPersonNameOrOrganizationNameOrEntityName().add(entityNameType);
            internationalContactType.setName(nameType);

            // Organization Name
        } else if (tirsNameType.isSetOrganizationName()) {
            _int.wipo.standards.xmlschema.st96.common.madrid.NameType nameType = commonObjectFactory.createNameType();
            OrganizationNameType organizationNameType = commonObjectFactory.createOrganizationNameType();
            PhraseType phraseType = commonObjectFactory.createPhraseType();
            phraseType.getContent().add(tirsNameType.getOrganizationName());

            organizationNameType.setOrganizationStandardName(phraseType);
            nameType.getPersonNameOrOrganizationNameOrEntityName().add(organizationNameType);
            internationalContactType.setName(nameType);

            // Person Name
        } else if (tirsNameType.isSetPersonName()) {
            _int.wipo.standards.xmlschema.st96.common.madrid.NameType nameType = commonObjectFactory.createNameType();
            PersonNameType personNameType = commonObjectFactory.createPersonNameType();
            PersonStructuredNameType personStructuredNameType = commonObjectFactory.createPersonStructuredNameType();
            personStructuredNameType.setFirstName(tirsNameType.getPersonName().getFirstName());
            personStructuredNameType.setLastName(tirsNameType.getPersonName().getLastName());
            personNameType.setPersonStructuredName(personStructuredNameType);
            nameType.getPersonNameOrOrganizationNameOrEntityName().add(personNameType);
            internationalContactType.setName(nameType);
        }
        if (null == internationalContactType.getName()) {
            ServiceFaultDetails serviceFaultDetails = new ServiceFaultDetails();
            throw new CIPOServiceFault("Contact Name is missing", serviceFaultDetails);
        }

        // Address - Unstructured
        PostalAddressBagType tirsPostalAddressBag = tirsContactType.getPostalAddressBag();

        _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressBagType internationalPostalAddressBagType = commonObjectFactory
            .createPostalAddressBagType();
        _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType internationalPostalAddressType = commonObjectFactory
            .createPostalAddressType();

        List<AddressLineTextType> addressLineText = new ArrayList<>();
        AddressLineTextType textType = new AddressLineTextType();
        String unstructuredAddress = ManualReportUtil.getPostalAddress(tirsPostalAddressBag);
        OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
        orderedTextType.setValue(unstructuredAddress);
        orderedTextType.setSequenceNumber("1");
        textType.setSequenceNumber("1");
        textType.setValue(unstructuredAddress);
        addressLineText.add(textType);
        internationalPostalAddressType.getPostalAddressText().add(orderedTextType);
        internationalPostalAddressBagType.getPostalAddress().add(internationalPostalAddressType);
        internationalContactType.setPostalAddressBag(internationalPostalAddressBagType);
        applicantType.getLegalEntityNameOrPartyIdentifierOrContact().add(internationalContactType);

        holderBagType.getHolder().add(applicantType);

        return holderBagType;
    }

    protected DocumentIncludedBagType mapDocumentBag(List<String> documents) {

        DocumentIncludedBagType documentIncludedBagType = commonObjectFactory.createDocumentIncludedBagType();

        for (String document : documents) {
            documentIncludedBagType.getDocumentIncluded().add(getDocumentType(document));
        }

        return documentIncludedBagType;
    }

    protected DocumentType getDocumentType(String document) {
        DocumentType documentType = commonObjectFactory.createDocumentType();
        documentType.setDocumentName(document);

        DocumentFormatCategoryType categoryType = DocumentFormatCategoryType.PDF;
        if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.DOC.name())
            || document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.DOCX.name())) {
            categoryType = DocumentFormatCategoryType.MS_WORD;
        } else if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.JPEG.name())) {
            categoryType = DocumentFormatCategoryType.JPEG;
        } else if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.TIFF.name())) {
            categoryType = DocumentFormatCategoryType.TIFF;
        } else if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.XML.name())) {
            categoryType = DocumentFormatCategoryType.XML;
        } else if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.PNG.name())) {
            categoryType = DocumentFormatCategoryType.PNG;
        } else if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.GIF.name())) {
            categoryType = DocumentFormatCategoryType.SVG;
        } else if (document.toUpperCase().endsWith(IntlFileFrmtTypeEnum.XLS.name())) {
            categoryType = DocumentFormatCategoryType.MS_EXCEL;
        }

        documentType.setDocumentFormatCategory(categoryType);
        documentType.setDocumentDate(convertDateToString(new Date()));
        documentType.setDocumentMediaCategory(DocumentMediaCategoryType.FILE);
        documentType.setDocumentKindCategory("Document");
        return documentType;
    }

    protected GoodsServicesBagType mapGoodsServices(List<ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType> goodsServicesList) {
        GoodsServicesBagType goodsServicesBagType = objectFactory.createGoodsServicesBagType();
        GoodsServicesType goodsServicesType = null;
        ClassDescriptionBagType classDescriptionBagType = null;
        ClassDescriptionType classDescriptionType = null;

        Iterator<ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType> tirsGSTypeIterator = goodsServicesList
            .iterator();

        boolean hasClassDescriptionBag = false;
        while (tirsGSTypeIterator.hasNext()) {
            goodsServicesType = objectFactory.createGoodsServicesType();
            classDescriptionBagType = objectFactory.createClassDescriptionBagType();
            classDescriptionType = objectFactory.createClassDescriptionType();
            hasClassDescriptionBag = false;
            ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType tirsGSType = tirsGSTypeIterator.next();
            String classNumber = tirsGSType.getClassification().getClassNumber();
            String classificationVersion = tirsGSType.getClassification().getClassificationVersion();
            Integer sequenceNumber = tirsGSType.getGoodsServiceNumber();
            GoodsServicesStatementType statement = tirsGSType.getStatement();
            LocalizedTextType localizedTextType = statement.getStatementDescription();

            if ((localizedTextType != null) && (localizedTextType.getValue() != null)
                && !localizedTextType.getValue().isEmpty()) {
                OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
                orderedTextType.setLanguageCode(localizedTextType.getLanguageCode());
                orderedTextType.setSequenceNumber(String.valueOf(sequenceNumber));
                orderedTextType.setValue(localizedTextType.getValue());
                classDescriptionType.getGoodsServicesDescriptionText().add(orderedTextType);
                classDescriptionType.setClassificationVersion(classificationVersion);
                hasClassDescriptionBag = true;
            }

            if (hasClassDescriptionBag) {
                classDescriptionType.setClassNumber(classNumber);
                classDescriptionBagType.getClassDescription().add(classDescriptionType);
                goodsServicesType.setClassDescriptionBag(classDescriptionBagType);
                goodsServicesBagType.getGoodsServices().add(goodsServicesType);
            }
        }

        if (goodsServicesBagType.getGoodsServices().isEmpty()) {
            goodsServicesBagType.getGoodsServices().add(goodsServicesType);
        }

        return goodsServicesBagType;
    }

    protected BasicRegistrationApplicationBagType basicRegistrationApplication(List<TMInfoRetrievalDto> tmInfoRetrievalDtoList) {

        // Basic Registration Application Bag
        BasicRegistrationApplicationBagType basicRegistrationApplicationBagType = objectFactory
            .createBasicRegistrationApplicationBagType();

        for (TMInfoRetrievalDto dto : tmInfoRetrievalDtoList) {
            // Basic Registration Application
            BasicRegistrationApplicationType basicRegistrationApplicationType = objectFactory
                .createBasicRegistrationApplicationType();

            // Basic Application Date
            // BR: Action_Date from the Actions table where the Action_Code = 30
            // (filed).
            BasicApplicationType basicApplicationType = objectFactory.createBasicApplicationType();
            if (null != dto.getTrademarkApplicationType().getFilingDate()) {
                basicApplicationType.setBasicApplicationDate(convertDateToString(
                    dto.getTrademarkApplicationType().getFilingDate().toGregorianCalendar().getTime()));
            }

            // Basic Application Number
            ApplicationNumberType applicationNumberType = commonObjectFactory.createApplicationNumberType();
            // applicationNumberType.setApplicationNumberText(String.valueOf(dto.getTrademarkApplicationType().getApplicationNumber().getFileNumber()));
            String fileNumber = String
                .valueOf(dto.getTrademarkApplicationType().getApplicationNumber().getFileNumber());
            String fileNumberExt = String
                .valueOf(dto.getTrademarkApplicationType().getApplicationNumber().getExtensionCounter());

            if (fileNumberExt == null) {
                fileNumberExt = "00";
            } else {
                fileNumberExt = StringUtils.leftPad(fileNumberExt, 2, "0");
            }

            String fileNumberST13 = "30" + "0000" + StringUtils.leftPad(fileNumber, 7, "0") + fileNumberExt;
            applicationNumberType.setST13ApplicationNumber(fileNumberST13);

            basicApplicationType.setBasicApplicationNumber(applicationNumberType);

            // Basic Application Bag
            BasicApplicationBagType basicApplicationBagType = objectFactory.createBasicApplicationBagType();
            basicApplicationBagType.getBasicApplication().add(basicApplicationType);

            JAXBElement<BasicApplicationBagType> basicApplicationBag = objectFactory
                .createBasicApplicationBag(basicApplicationBagType);

            basicRegistrationApplicationType.getContent().add(basicApplicationBag);

            basicRegistrationApplicationBagType.getBasicRegistrationApplication().add(basicRegistrationApplicationType);
        }

        return basicRegistrationApplicationBagType;
    }

    protected ISOLanguageCodeType getNotificationLanguage(TMInfoRetrievalDto processActionApplication) {
        // Notification Language
        ISOLanguageCodeType notificationLanguage = ISOLanguageCodeType.fromValue("en");

        if (processActionApplication != null) {
            TrademarkApplicationDetailsType trademarkApplicationDetailsType = processActionApplication
                .getTrademarkApplicationDetailsType();

            if ((trademarkApplicationDetailsType.getApplicants() != null)
                && (!trademarkApplicationDetailsType.getApplicants().isEmpty())
                && (trademarkApplicationDetailsType.getApplicants().get(0) != null)
                && (trademarkApplicationDetailsType.getApplicants().get(0).getContact() != null)
                && (trademarkApplicationDetailsType.getApplicants().get(0).getContact().getLanguage() != null)) {
                notificationLanguage = ISOLanguageCodeType.fromValue(
                    trademarkApplicationDetailsType.getApplicants().get(0).getContact().getLanguage().value());
            }
        }

        return notificationLanguage;
    }

    protected <T> ByteArrayOutputStream marshalTransactionWithValidation(JAXBElement<T> madridObject,
                                                                         IMarshallingService marshallingService)
        throws Exception {
        ByteArrayOutputStream os = null;

        try {
            Marshaller jaxbMarshaller = marshallingService.getMadridOutboundJAXBContext().createMarshaller();
            os = marshallingService.marshalExportMessageWithValidation(jaxbMarshaller, madridObject);
        } catch (Exception e) {
            throw new Exception("Error marshalling transaction.");
        }

        return os;
    }

    protected String scheduleReport(String reportServiceHost, String xmlDataSource, String reportXpath,
                                    String reportName, List<InputStream> images, Locale locale)
        throws ParserConfigurationException, IllegalArgumentException, SAXException, IOException, CipoServiceFault {

        String jobId = null;

        Document doc = null;
        DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(xmlDataSource));
        doc = docBuilder.parse(is);

        ReportGenerationWsClient rgsClient = new ReportGenerationWsClient(reportServiceHost);
        rgsClient.setOutReportType(ReportType.PDF);

        jobId = rgsClient.scheduleReportGenerationWithDocument(reportName, null, doc, reportXpath, null, images, locale,
            null);

        return jobId;
    }

    protected MarkDisclaimerBagType setDisclaimer(TrademarkDetailsType trademarkDetailsType) {

        MarkDisclaimerBagType markDisclaimerBagType = objectFactory.createMarkDisclaimerBagType();

        if (null != trademarkDetailsType) {

            DisclaimerType disclaimerType = trademarkDetailsType.getDisclaimer();
            if (null != disclaimerType && null != disclaimerType.getDisclaimerText()) {
                OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
                LocalizedTextType disclaimerText = disclaimerType.getDisclaimerText();

                orderedTextType.setValue(disclaimerText.getValue());
                orderedTextType.setLanguageCode(disclaimerText.getLanguageCode());

                markDisclaimerBagType.getMarkDisclaimerText().add(orderedTextType);

            } else {
                OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
                orderedTextType.setValue(MtsStringUtil.EMPTY);
                markDisclaimerBagType.getMarkDisclaimerText().add(orderedTextType);

            }
        }
        return markDisclaimerBagType;
    }

    protected Comparator<java.sql.Date> getTrademarkActionDateComparator() {
        Comparator<java.sql.Date> getOppositionCaseList = new Comparator<java.sql.Date>() {

            @Override
            public int compare(java.sql.Date left, java.sql.Date right) {
                return left.compareTo(right);
            }
        };
        return getOppositionCaseList;
    }

    protected StringBuilder createDocument(String fileName) {

        StringBuilder documentName = new StringBuilder();

        if (null != fileName) {
            documentName.append(ATTACHMENT_FOLDER);
            documentName.append(fileName.trim());
        }
        return documentName;
    }

    protected StringBuilder createDocument(String fileName, BigDecimal irTranId) {

        StringBuilder documentName = new StringBuilder();

        if (null != fileName) {
            fileName.replace(MtsStringUtil.DOT, irTranId.toString() + MtsStringUtil.DOT);
            documentName.append(createDocument(fileName));
        }
        return documentName;
    }

    protected String convertDateToString(java.util.Date dt) {
        String rtnDate = MtsStringUtil.EMPTY;

        if (dt != null) {
            rtnDate = DateFormats.getISOSDF().format(dt);
        }
        return rtnDate;
    }

    protected java.util.Date convertStringToDate(String dateString, Logger logger) {
        try {
            return DateFormats.getISOSDF().parse(dateString);
        } catch (ParseException e) {
            logger.warn("Cannot parse date string <" + dateString + "> to Date object. Null will be returned.");

            return null;
        }

    }

    protected DocumentFormatCategoryType buildDocumentFormatCategoryType(String value, Logger logger) {
        try {
            return DocumentFormatCategoryType.fromValue(value);
        } catch (IllegalArgumentException e) {
            if (value.toLowerCase().contains("doc")) {
                return DocumentFormatCategoryType.MS_WORD;
            } else if (value.toLowerCase().contains("XLS")) {
                return DocumentFormatCategoryType.MS_EXCEL;
            }

            logger.warn("File format of <" + value + "> is not recognized by DocumentFormatCategoryType.");
            return null;
        }
    }

    protected String buildHolderValue(HolderBagType holderBagType) {
        if (holderBagType == null) {
            return MtsStringUtil.EMPTY;
        }
        List<ApplicantType> applicantTypes = holderBagType.getHolder();
        if ((applicantTypes != null) && !applicantTypes.isEmpty()) {
            for (ApplicantType applicantType : applicantTypes) {
                if (applicantType.getLegalEntityNameOrPartyIdentifierOrContact() != null
                    && !applicantType.getLegalEntityNameOrPartyIdentifierOrContact().isEmpty()) {
                    List<Serializable> lists = applicantType.getLegalEntityNameOrPartyIdentifierOrContact();
                    if ((lists != null) && !lists.isEmpty()) {
                        for (Object obj : lists) {
                            if (obj instanceof String) {
                                return (obj.toString());
                            } else if (obj instanceof _int.wipo.standards.xmlschema.st96.common.madrid.ContactType) {
                                _int.wipo.standards.xmlschema.st96.common.madrid.NameType nameType = ((_int.wipo.standards.xmlschema.st96.common.madrid.ContactType) obj)
                                    .getName();
                                List<Serializable> names = nameType.getPersonNameOrOrganizationNameOrEntityName();
                                if (names != null && !names.isEmpty()) {
                                    for (Object subObj : names) {
                                        if (subObj instanceof EntityNameType) {
                                            return escapeXml((((EntityNameType) subObj).getValue()));
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
        }

        return MtsStringUtil.EMPTY;
    }

    protected String escapeXml(String data) {
        return StringEscapeUtils.escapeXml(data);
    }

    protected static List<InputStream> setReproductionMarksForReport(String tempFolder, String tempFileDir,
                                                                     Logger logger)
        throws Exception {

        List<InputStream> reproductionMarksZipList = new ArrayList<InputStream>();

        File imagesZip = null;

        // Retrieve any reproduction mark files and put them into a ZIP file for inclusion in the report
        // The file name for ZIP entries should be the element found under ../mfReportRoot/EarlierMark/ImageFileName
        // which contains no prefix or file extension. For example, "001_001".
        // This method may return null which is expected when there are no mark attachments
        try {
            imagesZip = zipReproductionMarks(tempFolder, tempFileDir, logger);
            if (imagesZip != null) {

                // Add the ZIP file to an array of streams for passing to RGS.
                reproductionMarksZipList.add(new FileInputStream(imagesZip));
            }

        } catch (Exception e) {
            logger.debug("Report service failed to create ZIP file: ", e);
        }

        return reproductionMarksZipList;
    }

    protected static File zipReproductionMarks(String tempFolder, String tempFileDir, Logger logger) throws Exception {

        File zippedFile = new File(tempFolder + File.separator + "reproductionMarks_.zip");

        FileOutputStream fileOutputStream = null;
        ZipOutputStream zipOutputStream = null;
        FileInputStream fileInputStream = null;
        try {
            fileOutputStream = new FileOutputStream(zippedFile);
            zipOutputStream = new ZipOutputStream(fileOutputStream);

            File markFileDir = new File(tempFileDir);
            File[] markFiles = markFileDir.listFiles();

            for (File markFile : markFiles) {
                zipOutputStream.putNextEntry(new ZipEntry(markFile.getName()));

                fileInputStream = new FileInputStream(markFile);
                byte[] buf = new byte[1024];
                int bytesRead = 0;

                while ((bytesRead = fileInputStream.read(buf)) > 0) {
                    zipOutputStream.write(buf, 0, bytesRead);
                }

                zipOutputStream.closeEntry();
                fileInputStream.close();
            }

        } finally {
            IOUtils.closeQuietly(zipOutputStream);
            IOUtils.closeQuietly(fileOutputStream);
            IOUtils.closeQuietly(fileInputStream);
        }

        return zippedFile;
    }

    protected static String builtReproductionMarkTempUploadFileDir(String commonTempFolder) throws Exception {
        String pathName = commonTempFolder + File.separator + "_RGSreport";
        Path path = Paths.get(pathName);
        Files.createDirectories(path);

        return pathName;
    }

    protected static void deleteReproductionMarkTempUploadDir(String tempFolder) {
        // clean up files
        if (tempFolder != null) {
            File tempDir = new File(tempFolder);
            File[] files = tempDir.listFiles();
            for (File f : files) {
                f.delete();
            }
            tempDir.delete();
        }
    }

    protected String formatValue(String inValue) {
        return ((inValue == null) ? MtsStringUtil.EMPTY : escapeXml(inValue));
    }

    protected String getUniqueReportName(String reportBaseName, String intlRegNo, String intlRecordId) {
        StringBuilder reportName = new StringBuilder();

        reportName.append(reportBaseName).append(MtsStringUtil.UNDER_SCORE).append(intlRegNo)
            .append(MtsStringUtil.UNDER_SCORE).append(intlRecordId);
        reportName.append(PDF_EXTENTION);

        return reportName.toString();
    }

    protected static String buildEmptyTag(String tagName) {
        StringBuilder rtnValue = new StringBuilder();
        XMLTagUtil.appendTagStart(rtnValue, tagName);
        XMLTagUtil.appendTagClose(rtnValue, tagName);
        return rtnValue.toString();
    }
}
