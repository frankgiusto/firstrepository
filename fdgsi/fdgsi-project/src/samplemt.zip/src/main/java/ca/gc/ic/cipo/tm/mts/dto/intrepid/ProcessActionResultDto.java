package ca.gc.ic.cipo.tm.mts.dto.intrepid;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProcessActionResultDto implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -2184906928725820290L;

    private String fileNumber;

    private Integer extensionCounter;

    private Integer processCode;

    private String wipoReferenceNumber;

    private String irNumber;

    private String officeType;

    private String additionalInfo;

    private Integer statusCode;

    private List<MadridApplicationXrefDto> madridApplicationXrefDto;

    public String getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(String fileNumber) {
        this.fileNumber = fileNumber;
    }

    public Integer getProcessCode() {
        return processCode;
    }

    public void setProcessCode(Integer processCode) {
        this.processCode = processCode;
    }

    public String getWipoReferenceNumber() {
        return wipoReferenceNumber;
    }

    public void setWipoReferenceNumber(String wipoReferenceNumber) {
        this.wipoReferenceNumber = wipoReferenceNumber;
    }

    public String getIrNumber() {
        return irNumber;
    }

    public void setIrNumber(String irNumber) {
        this.irNumber = irNumber;
    }

    public String getOfficeType() {
        return officeType;
    }

    public void setOfficeType(String officeType) {
        this.officeType = officeType;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public Integer getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(Integer extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public List<MadridApplicationXrefDto> getMadridApplicationXrefDto() {
        if (null == madridApplicationXrefDto) {
            madridApplicationXrefDto = new ArrayList<>();
        }
        return madridApplicationXrefDto;
    }

    public void setMadridApplicationXrefDto(List<MadridApplicationXrefDto> madridApplicationXrefDto) {
        this.madridApplicationXrefDto = madridApplicationXrefDto;
    }

}
