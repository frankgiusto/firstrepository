# TODO - Describe the steps to follow for proper configuration

copy this file to your ..WebSphere\AppServer\properties folder when running locally

for DEV,QA, etc, this file will be copied to location as defined by the database table Intl_Cnfgn_Parm parameter log4j.reloadable.properties.path
