package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationList;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.MadridConsoleService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IRProcessGoodServices;

/**
 * The Class tests the processing of Goods and Services of a Limitation, initiated by manual tasks on the Madrid
 * Console.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestProcessGSLimitation extends GoodsServicesTestBase {

    @Mock
    private IInternationalService internationalServiceMock;

    @Autowired
    private MadridTransactionServicePortType madridService;

    @Autowired
    private MadridConsoleService madridConsoleService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private Application application = null;

    @Mock
    private IIntrepidCommonService intrepidCommonServiceMock;

    @Mock
    private IOutboundTransactionService outboundTransactionServiceMock;

    @Autowired
    private IRProcessGoodServices processGoodServices;

    private int taskId = 1159325;

    @Before
    @Transactional
    @Rollback(true)
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(madridConsoleService, "intrepidCommonService", intrepidCommonServiceMock);
        ReflectionTestUtils.setField(madridConsoleService, "internationalService", internationalServiceMock);
        ReflectionTestUtils.setField(madridConsoleService, "outboundTransactionService",
            outboundTransactionServiceMock);

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-G&S-Base.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355288000", "1355288");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        printGS(application);

        GoodsAndServiceMeta goodsAndServiceMeta = new GoodsAndServiceMeta();
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        Mockito.when((internationalServiceMock).getTransactionByTaskId(Mockito.any(BigDecimal.class)))
            .thenReturn(super.getTaskTransaction(goodsAndServiceMeta.getTaskId()));

        // for processing total cancellation
        TMInfoRetrievalDto tmInfoRetrievalBean = initTIRSResult(application.getFileNumber());

        // OutboundTransactionDto
        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();
        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        outboundTransactionDto.setIntlRegNo("1355299");
        outboundTransactionDto.setOfficeType(OfficeType.DO);
        outboundTransactionDto.setRegisteredApplication(true);
        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);

        Mockito.when((intrepidCommonServiceMock).getMadridApplicationDetails(Mockito.any(BigDecimal.class),
            Mockito.any(String.class))).thenReturn(outboundTransactionDto);

    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationWithGSAdjustments() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_4(application);

        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);
                assertTrue(response != null);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }

        Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        assertTrue(updatedApplication.getGoodsServices().size() == 4);

        printGS(application);
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationNoGSAdjustments() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        // IntlTransactionTypeList intlTransactionTypeList = new IntlTransactionTypeList();
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();
        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                // process totalCancellation
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                // mock processing total cancellation
                OfficeToIbTransactionResponse res = new OfficeToIbTransactionResponse();
                Mockito
                    .when((outboundTransactionServiceMock).createAutoOutboundTransaction(
                        Mockito.any(OutboundTransactionRequest.class), Mockito.any(OutboundTransactionDto.class)))
                    .thenReturn(
                        res = super.createAutoOutboundTransaction(application, goodsAndServiceMeta.getTaskId()));

                assertTrue(res.getIrTranId() != null);
                assertTrue(response != null);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationActiveNoEffect() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            try {
                madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);
            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }

        Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);
        List<Action> actionList = updatedApplication.getActions();

        Set<Integer> actions = new HashSet<Integer>();
        for (Action action : actionList) {
            if (action.getActionCode().intValue() == ActionCode.LIMITATION_NOEFFECT.getValue().intValue()
                || action.getActionCode().intValue() == ActionCode.MF13_SENT.getValue().intValue()) {

                actions.add(action.getActionCode());
            }
        }
        assertTrue(actions.size() == 2);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationActiveAcceptAll() throws FileNotFoundException, JAXBException, SQLException {

        application.setStatusCode(12);
        applicationDao.saveApplication(application);

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_4(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_ALL);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);
                assertTrue(null != response);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }

        Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        assertTrue(updatedApplication.getGoodsServices().size() == 4);

        Set<GoodService> goodsServiceSet = updatedApplication.getGoodsServices();
        Iterator<GoodService> iterator = goodsServiceSet.iterator();
        while (iterator.hasNext()) {
            GoodService goodService = iterator.next();
            System.out.println("NiceClassCode: " + goodService.getNiceClassCode().toString());
            Set<GoodServiceText> gstextSet = goodService.getGoodServiceTexts();
            Iterator<GoodServiceText> iterator2 = gstextSet.iterator();
            while (iterator2.hasNext()) {
                GoodServiceText gsText = iterator2.next();
                System.out.println("GoodServiceText: " + gsText.getText());
            }
        }

        List<Action> actionList = updatedApplication.getActions();

        int match = 0;
        for (Action action : actionList) {
            if (action.getActionCode().intValue() == ActionCode.TOTAL_GOODSSERVICES_LIMITATION.getValue().intValue()) {
                match++;
            }
        }
        assertTrue(match == 1);
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationWithGSAdjustmentsRemovedStatement()
        throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_3(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }

        Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        assertTrue(updatedApplication.getGoodsServices().size() == 3);

        assertTrue(updatedApplication.getClaims().size() == 1);

        printGS(updatedApplication);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationWithGSAdjustmentsRemovedStatementClaim()
        throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_2(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);
                assertTrue(response != null);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }

        Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        assertTrue(updatedApplication.getGoodsServices().size() == 2);

        assertTrue(updatedApplication.getClaims().size() == 0);

        printGS(updatedApplication);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testLimitationWithGSAdjustmentsNewStatement()
        throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_6(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);
            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }

        Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        assertTrue(updatedApplication.getGoodsServices().size() == 6);

        assertTrue(updatedApplication.getClaims().size() == 1);

        printGS(updatedApplication);

    }

}
