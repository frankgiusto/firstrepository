package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;

public abstract class MadridTransactionTestBase {

    private static final Logger log = LoggerFactory.getLogger(MadridTransactionTestBase.class);

    private static final JAXBContext jaxbMadridDesignationContext = initMadridContext();

    protected static JAXBContext initMadridContext() {
        try {
            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid",
                ObjectFactory.class.getClassLoader());

        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridContext instance", e);
        }
        return null;
    }

    protected MadridDesignationType getMadridDesignationType(String xmlFileName)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/" + xmlFileName));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    protected void verifyInterestPartyAddress(Application application) {
        Set<InterestedParty> partites = application.getInterestedParties();
        System.out.println("InterestedParty size: " + partites.size());
        assertTrue(partites.size() > 0);

        for (InterestedParty party : partites) {

            Set<InterestedPartiesAddresses> pas = party.getContact().getInterestedPartiesAddresses();
            System.out.println("InterestedPartiesAddresses size: " + pas.size());

            Set<Integer> addressTypes = new HashSet<Integer>();
            for (InterestedPartiesAddresses pa : pas) {
                String address = pa.getAddress();
                int type = pa.getAddressType().intValue();
                addressTypes.add(type);
                System.out.println(address + ", type: " + type);
            }
            // must have two address types: 1 and 2
            assertTrue(addressTypes.size() > 0);
        }
    }

}
