package ca.gc.ic.cipo.tm.mts.services;

public class LatestVersion {

    public static String version() {

        return "Hello world";

    }

}
