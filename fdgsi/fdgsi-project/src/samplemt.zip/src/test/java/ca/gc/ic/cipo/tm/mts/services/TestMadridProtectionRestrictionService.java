package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author timyu
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridProtectionRestrictionService {
    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestMadridDesignationService.class);

    @Autowired
    @Qualifier("protectionRestriction")
    private IInboundTransaction protectionRestrictionService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private MadridDesignationType getCreateMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridProtectionRestrictionType getMadridProtectionRestrictionTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridProtectionRestriction-Limitation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridProtectionRestrictionType> madridProtectionRestrictioElement = (JAXBElement<MadridProtectionRestrictionType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestCreateMadridProtectionRestriction()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridProtectionRestrictionType madridProtectionRestriction = getMadridProtectionRestrictionTransaction();

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("1348320");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        madridDesignation.setInternationalRegistrationNumber("8888888");
        madridProtectionRestriction.setInternationalRegistrationNumber("8888888");

        // Create a Madrid Designation
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> statusTypes = protectionRestrictionService
            .processInboundTransaction(intlIrTranDto, madridProtectionRestriction);

        // verify statusTypes
        assertTrue(null != statusTypes && statusTypes.size() > 0);

        Collection<UserTaskType> notifications = statusTypes.values();
        for (UserTaskType taskType : notifications) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.GOODSERVICE_LIMITATION);
            }
        }
        // check the new field in application
        assertTrue(application.getLimitationListCode().intValue() == 2);
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional
    public void TestCreateMadridProtectionRestrictionInactive()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridProtectionRestrictionType madridProtectionRestriction = getMadridProtectionRestrictionTransaction();

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("1348320");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        // Create a Madrid Designation
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.CANCELLED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        setIntlIrTranDtoForMail(intlIrTranDto);

        Map<ApplicationDto, UserTaskType> statusTypes = null;
        try {
            statusTypes = protectionRestrictionService.processInboundTransaction(intlIrTranDto,
                madridProtectionRestriction);
            fail();
        } catch (Exception exception) {
            if (exception instanceof MTSServiceFault) {
                // processing designation error.
                System.out.println("error");
            }
        }

    }

    private IntlIrTranDto setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MPR_LIMITATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MPR_LIMITATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        return intlIrTranDto;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }
}
