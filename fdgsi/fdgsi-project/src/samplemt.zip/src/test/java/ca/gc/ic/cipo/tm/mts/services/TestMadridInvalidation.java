package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridInvalidationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionsResponse;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IProcessActionsService;

/**
 * The Class tests the creation of an outbound MadridInvalidation transaction. The transaction will contain a MF10
 * attachment for a Total Invalidation or a Partial Invalidation.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridInvalidation extends ProcessActionTestBase {

    private static final Logger log = LoggerFactory.getLogger(TestMadridInvalidation.class);

    @Autowired
    private IProcessActionsService processActionsService;

    @Autowired
    private MadridTransactionServicePortType madridService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IInternationalService internationalService;

    @Mock
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private Application application = null;

    @Before
    @Transactional
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);

        ReflectionTestUtils.setField(madridService, "intrepidCommonService", intrepidCommonService);

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-Process-Action-Base.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355299000", "1355299");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        TMInfoRetrievalDto tmInfoRetrievalBean = initTIRSResult(application.getFileNumber());

        // OutboundTransactionDto
        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();

        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        outboundTransactionDto.setIntlRegNo("1355299");
        outboundTransactionDto.setOfficeType(OfficeType.DO);
        outboundTransactionDto.setRegisteredApplication(true);
        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);

        Mockito.when((intrepidCommonService).getMadridApplicationDetails(Mockito.any(ProcessActionsMeta.class)))
            .thenReturn(outboundTransactionDto);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testMf10Total() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Process Action
        ProcessAction processAction = this.createProcessAction(application,
            ProcessActionsType.SEND_INVALIDATION_FULL.getValue(), null, application.getIrNumber(), "MF10 test");
        processActionsDao.saveProcessActions(processAction);

        // Create Madrid Application
        // madridApplicationDao
        // .saveMadridApplication(this.createMadridApplication(application, application.getIrNumber(), "FRANCO224"));

        ProcessAction processActionResult = processActionsService.getById(processAction.getProcessActionId());

        ProcessActionsResponse processActionResponse = intrepidDTOFactory.getProcessActionResultDto(processActionResult,
            ProcessActionCategoryType.AUTOMATIC);

        OfficeToIbTransactionResponse officeToIbResponse = madridService
            .createOfficeToIbTransaction(processActionResponse.getProcessActionsMeta());

        // Verify response
        assertTrue(officeToIbResponse != null);

        ProcessAction processedAction = processActionsDao.getById(processAction.getProcessActionId());

        // Verify process action deleted
        assertTrue(processedAction == null);

        // Verify action code created
        boolean valid = false;
        Application refreshedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        List<Action> actions = refreshedApplication.getActions();
        for (Action action : actions) {
            if (action.getActionCode() == ActionCode.INVALIDATION_TOTAL_SENT.getValue()) {
                valid = true;
                break;
            }
        }
        assertTrue(valid);

        TransactionDetail transactionDetail = internationalService.getTransaction(officeToIbResponse.getIrTranId(),
            true, true);

        // Verify details of transaction TODO
        assertTrue(transactionDetail != null);

        assertTrue(transactionDetail.getCurrentStatus().getCategory().equals("MPS_READY_FOR_EXPORT"));

        MadridInvalidationType mf10Transaction = marshallingService
            .unmarshallOutboundTransaction(officeToIbResponse.getIrTranId());

        // Verify details of transaction TODO

        assertTrue(mf10Transaction != null);

        assertTrue(mf10Transaction.getDocumentIncludedBag().getDocumentIncluded().size() == 1);
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testMf10Partial() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Process Action - ignore testing retrieval of file based on filename in additional info. Tested
        // separately.
        ProcessAction processAction = this.createProcessAction(application,
            ProcessActionsType.SEND_INVALIDATION_PARTIAL.getValue(), null, application.getIrNumber(), null);
        processActionsDao.saveProcessActions(processAction);

        // Create Madrid Application
        // madridApplicationDao
        // .saveMadridApplication(this.createMadridApplication(application, application.getIrNumber(), "FRANCO225"));

        ProcessAction processActionResult = processActionsService.getById(processAction.getProcessActionId());

        ProcessActionsResponse processActionResponse = intrepidDTOFactory.getProcessActionResultDto(processActionResult,
            ProcessActionCategoryType.AUTOMATIC);

        OfficeToIbTransactionResponse officeToIbResponse = madridService
            .createOfficeToIbTransaction(processActionResponse.getProcessActionsMeta());

        // Verify response
        assertTrue(officeToIbResponse != null);

        ProcessAction processedAction = processActionsDao.getById(processAction.getProcessActionId());

        // Verify process action deleted
        assertTrue(processedAction == null);

        // Verify action code created
        boolean valid = false;
        Application refreshedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        List<Action> actions = refreshedApplication.getActions();
        for (Action action : actions) {
            if (action.getActionCode() == ActionCode.INVALIDATION_PARTIAL_SENT.getValue()) {
                valid = true;
                break;
            }
        }
        assertTrue(valid);

        TransactionDetail transactionDetail = internationalService.getTransaction(officeToIbResponse.getIrTranId(),
            true, true);

        // Verify details of transaction TODO
        assertTrue(transactionDetail != null);

        MadridInvalidationType mf10Transaction = marshallingService
            .unmarshallOutboundTransaction(officeToIbResponse.getIrTranId());

        // Verify details of transaction TODO

        assertTrue(mf10Transaction != null);

        assertTrue(transactionDetail.getCurrentStatus().getCategory().equals("MPS_READY_FOR_EXPORT"));

        assertTrue(mf10Transaction.getDocumentIncludedBag().getDocumentIncluded().size() == 1);

    }

}
