package ca.gc.ic.cipo.tm.mts.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.common.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.ClassificationKindCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory;
import ca.gc.ic.cipo.common.service.CalendarUtils;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskDao;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationList;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.OrderedTextType;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.enums.GoodsServiceAction;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IRProcessGoodServices;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.common.ContactType;
import ca.gc.ic.cipo.xmlschema.common.NameType;
import ca.gc.ic.cipo.xmlschema.common.NationalCorrespondentType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressBagType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressType;
import ca.gc.ic.cipo.xmlschema.common.UnstructuredPostalAddressType;
import ca.gc.ic.cipo.xmlschema.trademark.ClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.ApplicationStatusType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClassificationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesStatementType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.StatementSourceCategoryType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.StatementType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsType;

public abstract class GoodsServicesTestBase {

    private static final Logger log = LoggerFactory.getLogger(GoodsServicesTestBase.class);

    private static final JAXBContext jaxbMadridDesignationContext = initMadridContext();

    private static Integer MADRID_APPLICATION_REGISTERED = 2;

    private final static int MADRID_LIMITATION_NO_EFFECT = 1;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IOutboundTransactionService outboundTransactionService;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IRProcessGoodServices intrepidProcessGoodServices;

    @Autowired
    private IntlIrTaskDao intlTaskDao;

    protected List<GoodsServicesClaimsType> initGoodsServicesClaimsTypeList() {

        // TIRS data
        List<GoodsServicesClaimsType> goodsServicesClaimsTypeListMock = new ArrayList<>();

        GoodsServicesClaimsType goodsServicesClaimsType = new GoodsServicesClaimsType();

        // 1
        goodsServicesClaimsType = new GoodsServicesClaimsType();

        GoodsServicesClassificationType goodsServicesClassificationType = new GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassNumber("36");
        goodsServicesClaimsType.setGoodsServiceType(2);
        goodsServicesClaimsType.setGoodsServiceNumber(1);
        goodsServicesClaimsType.setClassification(goodsServicesClassificationType);
        goodsServicesClaimsTypeListMock.add(goodsServicesClaimsType);

        // 2
        goodsServicesClaimsType = new GoodsServicesClaimsType();

        goodsServicesClassificationType = new GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassNumber("39");
        goodsServicesClaimsType.setGoodsServiceType(2);
        goodsServicesClaimsType.setGoodsServiceNumber(2);
        goodsServicesClaimsType.setClassification(goodsServicesClassificationType);
        goodsServicesClaimsTypeListMock.add(goodsServicesClaimsType);

        // 3
        goodsServicesClaimsType = new GoodsServicesClaimsType();

        goodsServicesClassificationType = new GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassNumber("36");
        goodsServicesClaimsType.setGoodsServiceType(2);
        goodsServicesClaimsType.setGoodsServiceNumber(3);
        ClaimType claimType = new ClaimType();
        claimType.setClaimNumber(1);
        claimType.setClaimCategoryType(12);
        goodsServicesClaimsType.getClaims().add(claimType);
        goodsServicesClaimsType.setClassification(goodsServicesClassificationType);
        goodsServicesClaimsTypeListMock.add(goodsServicesClaimsType);

        // 4
        goodsServicesClaimsType = new GoodsServicesClaimsType();

        goodsServicesClassificationType = new GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassNumber("39");
        goodsServicesClaimsType.setGoodsServiceType(2);
        goodsServicesClaimsType.setGoodsServiceNumber(4);
        claimType = new ClaimType();
        claimType.setClaimNumber(1);
        claimType.setClaimCategoryType(12);
        goodsServicesClaimsType.getClaims().add(claimType);
        goodsServicesClaimsType.setClassification(goodsServicesClassificationType);
        goodsServicesClaimsTypeListMock.add(goodsServicesClaimsType);

        return goodsServicesClaimsTypeListMock;
    }

    protected TMInfoRetrievalDto initTIRSResult(Integer fileNumber) {

        TMInfoRetrievalDto tmInfoRetrievalBean = new TMInfoRetrievalDto();

        // TrademarkApplicationType
        TrademarkApplicationType trademarkApplicationType = new TrademarkApplicationType();
        ApplicationNumber an = new ApplicationNumber();
        an.setFileNumber(fileNumber);
        an.setExtensionCounter(0);
        trademarkApplicationType.setApplicationNumber(an);

        ApplicationStatusType ast = new ApplicationStatusType();
        ast.setApplicationStatusCode(2);
        trademarkApplicationType.setApplicationStatus(ast);
        trademarkApplicationType.setFilingDate(CalendarUtils.toXMLCalendar(new java.sql.Date(new Date().getTime())));

        // tmInterestedPartyTypeList
        NameType nameType = new NameType();
        nameType.setEntityName("SPRATTS PATENT & LIMITED COMPANY");
        List<TMInterestedPartyType> tmInterestedPartyTypeList = new ArrayList<>();
        TMInterestedPartyType tmInterestedPartyType = new TMInterestedPartyType();
        ContactType contactType = new ContactType();
        contactType.setName(nameType);

        PostalAddressBagType postalAddressBagType = new PostalAddressBagType();
        PostalAddressType postalAddressType = new PostalAddressType();
        postalAddressType.setPostalCode("asdf");

        UnstructuredPostalAddressType unstructuredPostalAddressType = new UnstructuredPostalAddressType();
        unstructuredPostalAddressType.setExtendedISOCountryCode("GB");
        unstructuredPostalAddressType.setCipoPostalAddressCategory("Home");
        unstructuredPostalAddressType
            .setUnstructuredAddress("SPRATTS PATENT LIMITED COMPANY 58 MARKLANE LONDON, ENGLAND UNITED KINGDOM");

        postalAddressBagType.getUnstructuredPostalAddress().add(unstructuredPostalAddressType);
        contactType.setPostalAddressBag(postalAddressBagType);

        tmInterestedPartyType.setContact(contactType);

        tmInterestedPartyType.setName(nameType);
        tmInterestedPartyTypeList.add(tmInterestedPartyType);

        tmInfoRetrievalBean.setTrademarkApplicationType(trademarkApplicationType);
        tmInfoRetrievalBean.setTmInterestedPartyTypeList(tmInterestedPartyTypeList);

        // TrademarkApplicationDetailsType
        TrademarkApplicationDetailsType trademarkApplicationDetailsType = new TrademarkApplicationDetailsType();
        NationalCorrespondentType nationalCorrespondentType = new NationalCorrespondentType();
        nationalCorrespondentType.setApplicationLanguage(ISOLanguageCodeType.EN);
        trademarkApplicationDetailsType.setCorrespondenceDetails(nationalCorrespondentType);

        TrademarkDetailsType trademarkDetailsType = new TrademarkDetailsType();
        trademarkDetailsType.setMarkDescReference("SPRATTS FIBRINE DOG CAKES &amp; DESIGN");
        trademarkApplicationDetailsType.setTradmarkDetails(trademarkDetailsType);

        tmInfoRetrievalBean.setTrademarkApplicationDetailsType(trademarkApplicationDetailsType);

        // Goods and Services
        List<GoodsServicesType> goodsAndServices = new ArrayList<>();
        GoodsServicesType goodsServicesType = new GoodsServicesType();
        GoodsServicesClassificationType goodsServicesClassificationType = new GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassificationKind(ClassificationKindCategoryType.NICE);
        goodsServicesClassificationType.setClassNumber("11");
        LocalizedTextType localizedTextType = new LocalizedTextType();
        localizedTextType.setLanguageCode("en");
        localizedTextType.setValue(
            "Precious metals and their alloys;  jewellery, precious and semi-precious stones;  horological and chronometric instruments.");
        goodsServicesClassificationType.getClassHeadingDescriptions().add(localizedTextType);
        localizedTextType = new LocalizedTextType();
        localizedTextType.setLanguageCode("fr");
        localizedTextType.setValue(
            "Métaux précieux et leurs alliages;  joaillerie, bijouterie, pierres précieuses et semi précieuses;  horlogerie et instruments chronométriques.");
        goodsServicesClassificationType.getClassHeadingDescriptions().add(localizedTextType);
        goodsServicesClassificationType.setClassStatementType(StatementType.GOODS);
        goodsServicesType.setClassification(goodsServicesClassificationType);
        GoodsServicesStatementType goodsServicesStatementType = new GoodsServicesStatementType();
        localizedTextType = new LocalizedTextType();
        localizedTextType.setLanguageCode("en");
        localizedTextType.setValue(
            "Metallic salts and soaps in solid, paste and liquid form, useful alone and as an additive for a wide variety of purposes in the different arts where such products are useful, such as, fungicides, germicides, insecticides, driers, wetting agents, stabilizing agents, grinding aids, antichalking agents, bodying agents, antifouling agents, rust and corrosion inhibitants, lubricant additives, dispersing agents, non-penetrating agents, water repellants and catalysts, including oxidation catalysts, combustion catalysts for oils, candles, and smudge pots, and sprays to prevent smoking of coal during combustion; ink driers; driers for paste and ready-mixed paint, varnishes, and paint enamels, drier preservatives for driers for paste and ready-mixed paints, varnishes, and paint enamels, wetting and dispersing agents for pigmented coating materials, bodying agents for paste and ready-mixed paints, varnishes, paint enamels, and lacquers, and grinding agents for pigments and paste and ready-mixed paints, enamels and lacquers.");
        goodsServicesStatementType.setStatementDescription(localizedTextType);
        goodsServicesType.setStatement(goodsServicesStatementType);
        goodsServicesType.setStatementSourceCategory(StatementSourceCategoryType.CUSTOM);
        goodsAndServices.add(goodsServicesType);
        tmInfoRetrievalBean.setGoodsAndServices(goodsAndServices);

        return tmInfoRetrievalBean;
    }

    // protected ProcessAction createProcessAction(Application application, Integer processCode,
    // String wipoReferenceNumber, String irNumber, String additionalInfo) {
    //
    // ProcessAction processAction = new ProcessAction();
    // processAction.setAdditionalInfo(additionalInfo);
    // processAction.setApplication(application);
    // processAction.setAuthorityId("GIUSTOF1");
    // processAction.setExtensionCounter(0);
    // processAction.setFileNumber(application.getFileNumber());
    // processAction.setProcessCode(processCode);
    // processAction.setProcessType(2);
    // if (null != wipoReferenceNumber) {
    // processAction.setWipoReferenceNumber(wipoReferenceNumber);
    // }
    // if (null != irNumber) {
    // processAction.setIrNumber(irNumber);
    // }
    //
    // return processAction;
    // }

    protected MadridApplication createMadridApplication(Application application, String irNumber,
                                                        String wipoReferenceNumber) {

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber(irNumber);
        madridApplication.setWipoReferenceNumber(wipoReferenceNumber);
        madridApplication.setStatusCode(MADRID_APPLICATION_REGISTERED);

        // Create Madrid Application Xref
        MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
        madridApplicationXref.setMadridApplication(madridApplication);
        madridApplicationXref.setExtensionCounter(0);
        madridApplicationXref.setFileNumber(application.getFileNumber());
        madridApplicationXref.setWipoReferenceNumber(wipoReferenceNumber);

        madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);

        return madridApplication;
    }

    protected IntlIrTranDto createIntlIrTran(String intlRecordId, String intlRegNo) {
        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(intlRecordId);
        intlIrTranDto.setIntlRegNo(intlRegNo);

        return intlIrTranDto;
    }

    protected static JAXBContext initMadridContext() {
        try {

            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid",
                ObjectFactory.class.getClassLoader());

        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridContext instance", e);
        }
        return null;

    }

    protected MadridDesignationType getMadridTransaction(String xmlFileName)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource(xmlFileName));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    public <T> T unmarshallTransaction(byte[] xml) throws JAXBException, SQLException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();

        ByteArrayInputStream input = new ByteArrayInputStream(xml);

        @SuppressWarnings("unchecked")
        JAXBElement<T> transactionType = (JAXBElement<T>) unmarshallerRoot.unmarshal(input);

        return transactionType.getValue();
    }

    protected void printGS(Application application) {
        for (GoodService goodService : application.getGoodsServices()) { // 36
            System.out.println("Class:" + goodService.getNiceClassCode() + " SEQ:" + goodService.getNumber() + " Type:"
                + goodService.getType());
            Set<GoodServiceText> gsTextList = goodService.getGoodServiceTexts();
            for (GoodServiceText text : gsTextList) {
                System.out.println(" SEQ:" + text.getNumber() + " Type:" + text.getType() + " Orig:"
                    + text.getOriginalInd() + " LANG:" + text.getLanguage() + " TXT:" + text.getText());
            }
        }
    }

    protected ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType setMergedList(String classNumber, Integer wsNumber,
                                                                                 Integer wsType, String text,
                                                                                 String language) {
        ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType goodsServicesClassificationType = new ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassNumber(classNumber);
        goodsServicesClassificationType.setWsNumber(wsNumber);
        goodsServicesClassificationType.setWsType(wsType);
        OrderedTextType orderedTextType = new OrderedTextType();
        orderedTextType.setLanguageCode(language);
        orderedTextType.setValue(text);
        goodsServicesClassificationType.getClassTitleText().add(orderedTextType);
        return goodsServicesClassificationType;
    }

    protected boolean verifyTaskId(GoodsAndServiceMeta goodsAndServiceMeta) {
        try {
            List<IntlIrTranDto> transactionList = internationalService
                .getTransactionByTaskId(goodsAndServiceMeta.getTaskId());

            if (!CollectionUtils.isEmpty(transactionList)) {
                return true;

            } else {
                System.out.println("transactionList is empty - taskId maybe deleted in DB: " + transactionList
                    + "when processing test: " + goodsAndServiceMeta.getTaskType());
            }
        } catch (Exception e) {
            log.error("There are no intlIrTask with id [" + goodsAndServiceMeta.getTaskId() + "]\n");
        }

        return false;
    }

    protected GoodsAndServiceMeta getCommonGoodsAndServiceMeta(Application application) {
        GoodsAndServiceMeta goodsAndServiceMeta = new GoodsAndServiceMeta();
        goodsAndServiceMeta.setNotificationLanguage("en");
        goodsAndServiceMeta.setFileNumber(BigDecimal.valueOf(application.getFileNumber()));
        goodsAndServiceMeta.setExtensioncounter(application.getExtensionCounter().toString());
        goodsAndServiceMeta.setInternationalRegistrationNumber(application.getIrNumber());
        goodsAndServiceMeta.setAuthorityId(SectionAuthority.FORMALITIES.name());

        return goodsAndServiceMeta;
    }

    protected GoodsAndServiceMeta getGoodsAndServiceMeta_2(Application application) {
        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 1, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 fr", "fr"));

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        return goodsAndServiceMeta;
    }

    protected GoodsAndServiceMeta getGoodsAndServiceMeta_3(Application application) {
        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 1, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 fr", "fr"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 4, 2, "class number desc 39 en", "en"));

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        return goodsAndServiceMeta;
    }

    protected GoodsAndServiceMeta getGoodsAndServiceMeta_4(Application application) {
        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 1, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 fr", "fr"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 3, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 4, 2, "class number desc 39 en", "en"));

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        return goodsAndServiceMeta;
    }

    protected GoodsAndServiceMeta getGoodsAndServiceMeta_6(Application application) {

        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 1, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 fr", "fr"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 3, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 4, 2, "class number desc 39 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("16", 0, 0, "New statement 16 from wipo en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("15", 0, 0, "New statement 15 from wipo fr", "fr"));

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        return goodsAndServiceMeta;
    }

    protected List<IntlIrTranDto> getTaskTransaction(BigDecimal taskId) throws MTSServiceFault {
        List<IntlIrTranDto> transactionList = new ArrayList<IntlIrTranDto>();
        try {
            transactionList = internationalService.getTransactionByTaskId(taskId);

            if (CollectionUtils.isEmpty(transactionList)) {
                throw new IllegalArgumentException("Expecting one transaction for taskId: " + taskId);
            }
        } catch (Exception e) {
            log.error("There are no intlIrTask with id [" + taskId + "]\n");
        }
        return transactionList;
    }

    protected OfficeToIbTransactionResponse createAutoOutboundTransaction(Application application, BigDecimal taskId) {
        TMInfoRetrievalDto tmInfoRetrievalBean = initTIRSResult(application.getFileNumber());

        // OutboundTransactionDto
        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();

        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        outboundTransactionDto.setIntlRegNo("1355299");
        outboundTransactionDto.setOfficeType(OfficeType.DO);
        outboundTransactionDto.setRegisteredApplication(true);
        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);

        GoodsAndServiceMeta gsInfo = getCommonGoodsAndServiceMeta(application);
        OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
        outboundTransactionRequest.setFileNumber(gsInfo.getFileNumber());
        outboundTransactionRequest.setExtensionCounter(gsInfo.getExtensioncounter());
        outboundTransactionRequest.setRecordIdentifier(taskId.toString());
        outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_CANCELLATION);

        OfficeToIbTransactionResponse officeToIbTransactionResponse = null;
        try {
            officeToIbTransactionResponse = outboundTransactionService
                .createAutoOutboundTransaction(outboundTransactionRequest, outboundTransactionDto);
        } catch (CIPOServiceFault e) {
            log.error("Error createAutoOutboundTransaction for task id: " + taskId, e);
        }
        return officeToIbTransactionResponse;
    }

    /*
     * protected OutboundTransactionDto getMadridApplicationDetails(String irNumber, BigDecimal fileNumber, String
     * extensionCounter, List<ca.gc.ic.cipo.tm.mts.ApplicationNumber> basicMarkList) throws CIPOServiceFault {
     *
     * OutboundTransactionDto outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(irNumber,
     * fileNumber, extensionCounter, basicMarkList);
     *
     * return outboundTransactionDto; }
     */

    protected String getTaskTransaction(GoodsAndServiceMeta gsInfo) {
        MadridProtectionRestrictionType type = new MadridProtectionRestrictionType();
        type.setInternationalRegistrationNumber("9100001");
        // type.setMadridProtectionRestrictionCategory(TransactionCategory.MPR_PARTIAL_CEASING_OF_EFFECT.codeValue());
        type.setRecordEffectiveDate("2016-11-14");

        return type.getRecordEffectiveDate();

    }

    protected GoodsServiceAction processDOPartialCeasingEffect(GoodsAndServiceMeta gsInfo, String effectiveDate) {
        GoodsServiceAction goodsServiceAction = null;
        try {
            goodsServiceAction = intrepidProcessGoodServices.processDOPartialCeasingEffect(gsInfo, effectiveDate);
        } catch (CIPOServiceFault e) {
            log.error("Error processDOPartialCeasingEffect for file number: " + gsInfo.getFileNumber(), e);
        }
        return goodsServiceAction;
    }

    protected GoodsServiceAction processDOGoodServiceLimitation(GoodsAndServiceMeta gsInfo, String effectiveDate) {
        GoodsServiceAction goodsServiceAction = null;
        try {
            goodsServiceAction = intrepidProcessGoodServices.processDOGoodServiceLimitation(gsInfo, effectiveDate,
                null);
        } catch (CIPOServiceFault e) {
            log.error("Error processDOPartialCeasingEffect for file number: " + gsInfo.getFileNumber(), e);
        }
        return goodsServiceAction;
    }

    protected GoodsAndServicesChangesResponse processgoodsServiceAction(GoodsServiceAction goodsServiceAction,
                                                                        GoodsAndServiceMeta goodsAndServiceMeta,
                                                                        OutboundTransactionDto outboundTransactionDto) {
        GoodsAndServicesChangesResponse response = new GoodsAndServicesChangesResponse();
        OfficeToIbTransactionResponse outboundResponse = new OfficeToIbTransactionResponse();

        if (goodsServiceAction == GoodsServiceAction.TOTAL_CANCELLATION && outboundTransactionDto != null) {

            outboundResponse = totalCancellation(goodsAndServiceMeta, outboundTransactionDto);

        } else if (goodsServiceAction == GoodsServiceAction.MADRID_LIMITATION_NO_EFFECT) {

            response.setStatus(MADRID_LIMITATION_NO_EFFECT);
        }

        // change task status to processed
        TaskStatusType statusType = TaskStatusType.PROCESSED;
        if (outboundResponse != null && outboundResponse.getIrTranId() != null) {

            internationalService.updateTaskStatus(goodsAndServiceMeta.getTaskId(), statusType);
        }
        response.setStatus(HttpStatus.OK.value());

        return response;
    }

    private OfficeToIbTransactionResponse totalCancellation(GoodsAndServiceMeta gsInfo,
                                                            OutboundTransactionDto outboundTransactionDto) {
        // OutboundTransactionDto outboundTransactionDto;
        try {
            // outboundTransactionDto = intrepidCommonService.getMadridApplicationDetails(gsInfo.getFileNumber(),
            // gsInfo.getExtensioncounter());

            OutboundTransactionRequest outboundTransactionRequest = new OutboundTransactionRequest();
            outboundTransactionRequest.setFileNumber(gsInfo.getFileNumber());
            outboundTransactionRequest.setExtensionCounter(gsInfo.getExtensioncounter());
            outboundTransactionRequest.setRecordIdentifier(gsInfo.getTaskId().toString());
            outboundTransactionRequest.setProcessActionCodeType(ProcessActionCodeType.MADRID_CANCELLATION);

            OfficeToIbTransactionResponse response = outboundTransactionService
                .createAutoOutboundTransaction(outboundTransactionRequest, outboundTransactionDto);

            return response;

        } catch (CIPOServiceFault e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

}
