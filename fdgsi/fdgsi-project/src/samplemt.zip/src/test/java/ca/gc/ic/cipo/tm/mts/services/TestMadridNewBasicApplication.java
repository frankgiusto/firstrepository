package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridNewBasicApplicationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ProcessActionsResponse;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.IIntrepidDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IProcessActionsService;

/**
 * The Class tests the creation of an outbound MadridNewBasicApplication transaction. The transaction will create be a
 * Basic Applicaiton Division, Basic Application Merger, or a Basic Application Merger Ext.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridNewBasicApplication extends ProcessActionTestBase {

    private static final Logger log = LoggerFactory.getLogger(TestMadridNewBasicApplication.class);

    @Autowired
    private IProcessActionsService processActionsService;

    @Autowired
    private MadridTransactionServicePortType madridService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private IIntrepidDTOFactory intrepidDTOFactory;

    @Autowired
    private IInternationalService internationalService;

    @Mock
    private IIntrepidCommonService intrepidCommonService;

    @Autowired
    private IMarshallingService marshallingService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private Application application = null;

    @Before
    @Transactional
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);

        ReflectionTestUtils.setField(madridService, "intrepidCommonService", intrepidCommonService);

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-Process-Action-Base.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355299000", "1355299");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        TMInfoRetrievalDto tmInfoRetrievalBean = initTIRSResult(application.getFileNumber());

        // OutboundTransactionDto
        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();

        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        outboundTransactionDto.setIntlRegNo("1355299");
        outboundTransactionDto.setOfficeType(OfficeType.OO);
        outboundTransactionDto.setRegisteredApplication(true);
        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        List<TMInfoRetrievalDto> madridApplicationActionDetails = new ArrayList<>();
        madridApplicationActionDetails.add(tmInfoRetrievalBean);
        outboundTransactionDto.setMadridApplicationActionDetails(madridApplicationActionDetails);

        Mockito.when((intrepidCommonService).getMadridApplicationDetails(Mockito.any(ProcessActionsMeta.class)))
            .thenReturn(outboundTransactionDto);

    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testDivision() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Process Action
        ProcessAction processAction = this.createProcessAction(application,
            ProcessActionsType.DIVISION_BASIC_APPLICATION.getValue(), "FRANCO208", "3431111A", "Division test");
        processActionsDao.saveProcessActions(processAction);

        // Create Madrid Application
        madridApplicationDao.saveMadridApplication(
            this.createMadridApplication(application, application.getIrNumber() + "x", "FRANCO208"));

        ProcessAction processActionResult = processActionsService.getById(processAction.getProcessActionId());

        ProcessActionsResponse processActionResponse = intrepidDTOFactory.getProcessActionResultDto(processActionResult,
            ProcessActionCategoryType.MANUAL);

        ManualProcessResponse officeToIbResponse = madridService
            .createOfficeToIbManualTask(processActionResponse.getProcessActionsMeta()); // MADRID_NEW_BASIC_APPLICATION_DIVISION

        // Verify response
        assertTrue(officeToIbResponse != null);

        // Verify a console task was created.
        assertTrue(officeToIbResponse.getConsoleTaskBag().size() > 0);

        ProcessAction processedAction = processActionsDao.getById(processAction.getProcessActionId());

        // Verify process action deleted
        assertTrue(processedAction == null);

    }

    @Ignore
    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testMerger() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Process Action
        ProcessAction processAction = this.createProcessAction(application,
            ProcessActionsType.MERGER_BASIC_APPLICATION.getValue(), "FRANCO209", null, "Merger test");
        processActionsDao.saveProcessActions(processAction);

        // Create Madrid Application
        madridApplicationDao.saveMadridApplication(
            this.createMadridApplication(application, application.getIrNumber() + "x", "FRANCO209"));

        ProcessAction processActionResult = processActionsService.getById(processAction.getProcessActionId());

        ProcessActionsResponse processActionResponse = intrepidDTOFactory.getProcessActionResultDto(processActionResult,
            ProcessActionCategoryType.AUTOMATIC);

        OfficeToIbTransactionResponse officeToIbResponse = madridService
            .createOfficeToIbTransaction(processActionResponse.getProcessActionsMeta());

        // Verify response
        assertTrue(officeToIbResponse != null);

        ProcessAction processedAction = processActionsDao.getById(processAction.getProcessActionId());

        // Verify process action deleted
        assertTrue(processedAction == null);

        TransactionDetail transactionDetail = internationalService.getTransaction(officeToIbResponse.getIrTranId(),
            true, true);

        // Verify details of transaction TODO
        assertTrue(transactionDetail != null);

        assertTrue(transactionDetail.getCurrentStatus().getCategory().equals("MPS_READY_FOR_EXPORT"));

        MadridNewBasicApplicationType divisionTransaction = marshallingService
            .unmarshallOutboundTransaction(officeToIbResponse.getIrTranId());

        // Verify details of transaction TODO

        assertTrue(divisionTransaction != null);

    }

    @Ignore
    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testMergerExt() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Process Action
        ProcessAction processAction = this.createProcessAction(application,
            ProcessActionsType.MERGER_BASIC_APPLICATION_EXT_GS.getValue(), "FRANCO210", null, "Merger test");
        processActionsDao.saveProcessActions(processAction);

        // Create Madrid Application
        madridApplicationDao.saveMadridApplication(
            this.createMadridApplication(application, application.getIrNumber() + "x", "FRANCO210"));

        ProcessAction processActionResult = processActionsService.getById(processAction.getProcessActionId());

        ProcessActionsResponse processActionResponse = intrepidDTOFactory.getProcessActionResultDto(processActionResult,
            ProcessActionCategoryType.AUTOMATIC);

        OfficeToIbTransactionResponse officeToIbResponse = madridService
            .createOfficeToIbTransaction(processActionResponse.getProcessActionsMeta());

        // Verify response
        assertTrue(officeToIbResponse != null);

        ProcessAction processedAction = processActionsDao.getById(processAction.getProcessActionId());

        // Verify process action deleted
        assertTrue(processedAction == null);

        TransactionDetail transactionDetail = internationalService.getTransaction(officeToIbResponse.getIrTranId(),
            true, true);

        // Verify details of transaction TODO
        assertTrue(transactionDetail != null);

        assertTrue(transactionDetail.getCurrentStatus().getCategory().equals("MPS_READY_FOR_EXPORT"));

        MadridNewBasicApplicationType divisionTransaction = marshallingService
            .unmarshallOutboundTransaction(officeToIbResponse.getIrTranId());

        // Verify details of transaction TODO

        assertTrue(divisionTransaction != null);

    }
}
