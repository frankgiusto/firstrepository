package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridInternationalRegistrationCreationType;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridIRCreationService {

    private static final Logger log = LoggerFactory.getLogger(TestMadridIRCreationService.class);

    @Autowired
    private MadridApplicationDao madridApplicationsDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionsDao;

    @Autowired
    @Qualifier("madridIRCreation")
    private IInboundTransaction madridIRCreationService;

    private static final JAXBContext jaxbMadridInternationalRegistrationCreationContext = initMadridInternationalRegistrationCreationContext();

    @Test
    @Rollback(true)
    @Transactional
    public void TestRegisteredRenunciation()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // Create a test application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setWipoReferenceNumber("IA00003180625_01");
        madridApplication.setIaNumber(3180625l);
        madridApplication.setStatusCode(1);

        madridApplicationsDao.saveMadridApplication(madridApplication);

        // IR Designation Termination
        MadridInternationalRegistrationCreationType madridInternationalRegistrationCreationType = getInternationalRegistrationCreation();

        madridIRCreationService.processInboundTransaction(null, madridInternationalRegistrationCreationType); // TODO

        List<MadridApplication> result = madridApplicationsDao.getMadridApplicationByIrNumber(
            madridInternationalRegistrationCreationType.getInternationalRegistrationNumber());

        assertTrue(CollectionUtils.isNotEmpty(result));

        for (MadridApplication madridApplications : result) {
            List<MadridApplicationAction> actions = madridApplicationActionsDao
                .getMadridApplicationActionByReferenceNumber(madridApplications.getWipoReferenceNumber());
            assertTrue(actions.size() == 1);
            assertTrue(
                actions.iterator().next().getActionCode() == MadridApplicationActionStatus.IR_REGISTERED.getValue());
        }

    }

    public MadridInternationalRegistrationCreationType getInternationalRegistrationCreation()
        throws JAXBException, SQLException, FileNotFoundException {
        Unmarshaller unmarshallerRoot = jaxbMadridInternationalRegistrationCreationContext.createUnmarshaller();

        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridInternationalRegistration.xml"));
        @SuppressWarnings("unchecked")
        JAXBElement<MadridInternationalRegistrationCreationType> madridElement = (JAXBElement<MadridInternationalRegistrationCreationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridElement.getValue();
    }

    private static JAXBContext initMadridInternationalRegistrationCreationContext() {
        try {
            return JAXBContext.newInstance(MadridInternationalRegistrationCreationType.class,
                MadridInternationalRegistrationCreationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting initMadridInternationalRegistrationCreationContext instance", e);
        }
        return null;
    }

}
