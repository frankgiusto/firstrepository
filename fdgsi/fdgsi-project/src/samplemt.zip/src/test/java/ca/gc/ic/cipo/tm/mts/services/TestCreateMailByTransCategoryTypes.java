package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridBasicRegistrationApplicationChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridCorrectionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridRenewalType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmtType;
import ca.gc.ic.cipo.tm.intl.model.IntlFileFrmtType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlAtchmtDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * The Class TestCreateMailByTransCategoryTypes tests creating mail object for each transaction.
 *
 * @author
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestCreateMailByTransCategoryTypes {

    private static final Logger log = LoggerFactory.getLogger(TestCreateMailByTransCategoryTypes.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MailDao mailDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    @Qualifier("irCeasingOfEffectTotal")
    private IInboundTransaction irRCeasingOfEffectTotalService;

    @Autowired
    @Qualifier("protectionRestriction")
    private IInboundTransaction protectionRestrictionService;

    @Autowired
    @Qualifier("irRenewal")
    private IInboundTransaction irRenewalService;

    @Autowired
    @Qualifier("irOwnershipChangeTotal")
    private IInboundTransaction irOwnershipChangeTotalService;

    @Autowired
    @Qualifier("partialOwnershipChange")
    private IInboundTransaction irOwnershipChangePartialService;

    @Autowired
    @Qualifier("irHolderNameAddressChange")
    private IInboundTransaction irHolderNameAddressChangeService;

    @Autowired
    @Qualifier("irNonRenewal")
    private IInboundTransaction irNonRenewalService;

    @Autowired
    @Qualifier("irRenunciation")
    private IInboundTransaction irRenunciationService;

    @Autowired
    @Qualifier("irTotalCancellation")
    private IInboundTransaction irTotalCancellationService;

    @Autowired
    @Qualifier("holdersRightDisposal")
    private IInboundTransaction holderRightDisposalServiceService;

    @Autowired
    @Qualifier("irregularity")
    private IInboundTransaction irregularityService;

    @Autowired
    @Qualifier("irNotification")
    private IInboundTransaction irNotificationService;

    @Autowired
    @Qualifier("madridCorrection")
    private IInboundTransaction madridCorrectionService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridDesignationType getMadridTransaction(String xmlFileName) throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource(xmlFileName));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridPartialChangeOwnershipType getMadridPartialChangeOwnershipTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Combined-Partial-Ownership-Termination.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridPartialChangeOwnershipType> madridDesignationElement = (JAXBElement<MadridPartialChangeOwnershipType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepresentativeChangeTypeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/IRChangeOwnershipTotal-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridDesignationElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridRenewalType getMadridRenewalTypeTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/IRRenewalTransaction.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridRenewalType> madridDesignationElement = (JAXBElement<MadridRenewalType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationTerminationType getMadridDesignationTermination(String transaction)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = null;
        if (transaction.equalsIgnoreCase("irNonRenewalService")) {
            xml = ResourceUtils.getFile(this.getClass().getResource("/IRNonRenewalTransaction.xml"));
        } else if (transaction.equalsIgnoreCase("irRenunciationService")) {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridDesignationTermination-Partial-Ownership.xml"));
        } else if (transaction.equalsIgnoreCase("irTotalCancellationService")) {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridDesignationTermination-Total-Cancellation.xml"));
        } else if (transaction.equalsIgnoreCase("irRCeasingOfEffectTotalService")) {
            xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));
        }

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationTerminationType> madridDesignationElement = (JAXBElement<MadridDesignationTerminationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridIrregularityNotificationType getMadridIrregularityNotificationTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Irregularity.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridIrregularityNotificationType> madridProtectionRestrictioElement = (JAXBElement<MadridIrregularityNotificationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    private MadridProtectionRestrictionType getMadridProtectionRestrictionTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridProtectionRestriction.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridProtectionRestrictionType> madridProtectionRestrictioElement = (JAXBElement<MadridProtectionRestrictionType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    private MadridBasicRegistrationApplicationChangeType getMadridRegistrationApplicationChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Notification-ApplicationChange.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridBasicRegistrationApplicationChangeType> madridProtectionRestrictioElement = (JAXBElement<MadridBasicRegistrationApplicationChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    private MadridCorrectionType getMadridCorrectionTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Correction.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridCorrectionType> madridProtectionRestrictioElement = (JAXBElement<MadridCorrectionType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    /**
     * @throws JAXBException
     * @throws SQLException
     * @throws CIPOServiceFault
     * @throws FileNotFoundException
     */
    @Test
    @Rollback(true)
    @Transactional
    public void TestCreateMailTable() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        List<IntlAtchmtDto> intlAtchmtDtoList = createAttachment(intlIrTranDto);
        if (!intlAtchmtDtoList.isEmpty()) {
            intlIrTranDto.setIntlAtchmtDtoList(intlAtchmtDtoList);
        }

        // SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            // Date recordDate = dateFormat.parse("2027-02-28");
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);

        // verify mails for Madrid Designation
        verifyMails(application);

        // test MadridHolderRepresentativeChangeType
        // processingIRChangeOwnershipTotalService(intlIrTranDto, application); // PASS
        // notification
        processingIRNotificationService(intlIrTranDto, application); // PASS

        // test MadridIrregularityNotificationType
        // processingMadridIrregularity(intlIrTranDto, application);// PASS
        // test MadridDesignationTerminationType
        // processingIRCeasingOfEffectTotalService(intlIrTranDto, fileNumber); // PASS
        // test MadridHolderRepresentativeChangeType
        // processingIRHolderNameAddressChangeService(intlIrTranDto, fileNumber); // PASS
        // test MadridDesignationTerminationType
        // processingIRNonRenewal(intlIrTranDto, fileNumber); // PASS

        // test MadridPartialChangeOwnershipType
        // processingIROwnershipChangePartialService(intlIrTranDto, fileNumber); // PASS
        // test MadridRenewalType
        // processingIRRenewalService(intlIrTranDto, fileNumber);// PASS
        // test MadridDesignationTerminationType
        // processingIRRenunciationService(intlIrTranDto, fileNumber);// PASS
        // test MadridDesignationTerminationType
        // processingIRTotalCancellation(intlIrTranDto, fileNumber);// PASS
        // test MadridProtectionRestrictionType
        // processingMadridProtectionRestriction(intlIrTranDto, fileNumber);// PASS

        // test MadridProtectionRestrictionType
        // processingRestrictionOfHoldersRightDisposal(intlIrTranDto, fileNumber);// PASS
        // correction - pending
        // processingMadridCorrection(intlIrTranDto, fileNumber);// PASS

        // Abandonment- transaction is not done yet
        // processingMadridAbandonmentNotificationType(intlIrTranDto);

    }

    private void processingIRCeasingOfEffectTotalService(IntlIrTranDto intlIrTranDto, Integer fileNumber) {
        MadridDesignationTerminationType madridDesignationTerminationType = new MadridDesignationTerminationType();
        madridDesignationTerminationType.setExpiryDate("2027-02-28");
        madridDesignationTerminationType.setInternationalRegistrationNumber("8888888");
        IdentifierType it = new IdentifierType();
        it.setOfficeCode("302017000013034/GT");
        madridDesignationTerminationType.setOfficeReferenceIdentifier(it);
        // // madridDesignationTerminationType.setRecordFilingDate("2017-02-28");
        IdentifierType it2 = new IdentifierType();
        it2.setOfficeCode("9999999");
        madridDesignationTerminationType.setRecordIdentifier(it2);

        intlIrTranDto.setIntlRecordId(madridDesignationTerminationType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irRCeasingOfEffectTotalService
                .processInboundTransaction(intlIrTranDto, madridDesignationTerminationType);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRRenewalService(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridRenewalType madridRenewalType = getMadridRenewalTypeTransaction();
        intlIrTranDto.setIntlRecordId(madridRenewalType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // madridRenewalType.setRecordFilingDate("2017-05-24");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MR_RENEWAL.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MR_RENEWAL.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irRenewalService
                .processInboundTransaction(intlIrTranDto, madridRenewalType);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingMadridProtectionRestriction(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridProtectionRestrictionType protectionRestriction = getMadridProtectionRestrictionTransaction();
        protectionRestriction.setInternationalRegistrationNumber("0942093");
        intlIrTranDto.setIntlRecordId(protectionRestriction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // protectionRestriction.setRecordEffectiveDate("2017-05-01");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MPR_LIMITATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MPR_LIMITATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = protectionRestrictionService
                .processInboundTransaction(intlIrTranDto, protectionRestriction);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingRestrictionOfHoldersRightDisposal(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {

        MadridProtectionRestrictionType holderRightDisposalTransaction = getMadridProtectionRestrictionTransaction();
        intlIrTranDto.setIntlRecordId(holderRightDisposalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = holderRightDisposalServiceService
                .processInboundTransaction(intlIrTranDto, holderRightDisposalTransaction);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRChangeOwnershipTotalService(IntlIrTranDto intlIrTranDto, Application application)
        throws FileNotFoundException, JAXBException {
        MadridHolderRepresentativeChangeType holderRepresentativeChangeType = getMadridHolderRepresentativeChangeTypeTransaction();
        intlIrTranDto.setIntlRecordId(holderRepresentativeChangeType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // holderRepresentativeChangeType.setRecordEffectiveDate("2016-10-07");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MHR_CHANGE_OF_OWNER.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MHR_CHANGE_OF_OWNER.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        intlIrTranDto.setIntlIrTaskList(getActiveTaskList(application));

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irOwnershipChangeTotalService
                .processInboundTransaction(intlIrTranDto, holderRepresentativeChangeType);

            assertTrue(notificationTypes.size() > 0);
            // verify mails
            verifyMails(application);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRHolderNameAddressChangeService(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridHolderRepresentativeChangeType holderRepresentativeChangeType = getMadridHolderRepresentativeChangeTypeTransaction();
        intlIrTranDto.setIntlRecordId(holderRepresentativeChangeType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irHolderNameAddressChangeService
                .processInboundTransaction(intlIrTranDto, holderRepresentativeChangeType);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRNonRenewal(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridDesignationTerminationType nonRenewalTransaction = getMadridDesignationTermination("irNonRenewalService");
        intlIrTranDto.setIntlRecordId(nonRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // nonRenewalTransaction.setRecordFilingDate("2016-12-09");
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irNonRenewalService
                .processInboundTransaction(intlIrTranDto, nonRenewalTransaction);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRNotificationService(IntlIrTranDto intlIrTranDto, Application application)
        throws FileNotFoundException, JAXBException {

        // the service contains two type
        MadridBasicRegistrationApplicationChangeType applicationChange = getMadridRegistrationApplicationChangeTransaction();
        intlIrTranDto.setIntlRecordId(applicationChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();

        ptt.setTranCtgry(TransactionCategory.MBR_APPLICATION_CHANGE.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MBR_APPLICATION_CHANGE.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        intlIrTranDto.setIntlIrTaskList(getActiveTaskList(application));

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irNotificationService
                .processInboundTransaction(intlIrTranDto, applicationChange);

            assertTrue(notificationTypes.size() > 0);

            // verify mails
            verifyMails(application);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRRenunciationService(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridDesignationTerminationType renunciationTransaction = getMadridDesignationTermination(
            "irRenunciationService");
        intlIrTranDto.setIntlRecordId(renunciationTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // renunciationTransaction.setRecordFilingDate("2017-06-15");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_RENUNCIATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_RENUNCIATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irRenunciationService
                .processInboundTransaction(intlIrTranDto, renunciationTransaction);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIRTotalCancellation(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridDesignationTerminationType totalCancellationTransaction = getMadridDesignationTermination(
            "irTotalCancellationService");
        intlIrTranDto.setIntlRecordId(totalCancellationTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // totalCancellationTransaction.setRecordFilingDate("2017-06-29");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_TOTAL_CANCELLATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_TOTAL_CANCELLATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irTotalCancellationService
                .processInboundTransaction(intlIrTranDto, totalCancellationTransaction);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingMadridIrregularity(IntlIrTranDto intlIrTranDto, Application application)
        throws FileNotFoundException, JAXBException {
        MadridIrregularityNotificationType irregularityNotification = getMadridIrregularityNotificationTransaction();
        intlIrTranDto.setIntlRecordId(irregularityNotification.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // irregularityNotification.setMailDate("2012-12-21");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MI_IRREGULARITY_NOTIFICATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MI_IRREGULARITY_NOTIFICATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);
        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irregularityService
                .processInboundTransaction(intlIrTranDto, irregularityNotification);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(application.getFileNumber()));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingIROwnershipChangePartialService(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException, MTSServiceFault {

        MadridPartialChangeOwnershipType partialOwnershipTransaction = getMadridPartialChangeOwnershipTransaction();
        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("8888888");
        partialOwnershipTransaction.getMadridDesignationTermination().setInternationalRegistrationNumber("8888888");
        partialOwnershipTransaction.getMadridDesignation().setRecordEffectiveDate("2016-09-29");
        // intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> OPnotificationTypes = irOwnershipChangePartialService
                .processInboundTransaction(intlIrTranDto, partialOwnershipTransaction);

            assertTrue(OPnotificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }

        ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.DESIGNATION_TERMINATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.DESIGNATION_TERMINATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> OPnotificationTypes = irOwnershipChangePartialService
                .processInboundTransaction(intlIrTranDto, partialOwnershipTransaction);

            assertTrue(OPnotificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingMadridCorrection(IntlIrTranDto intlIrTranDto, Integer fileNumber)
        throws FileNotFoundException, JAXBException {
        MadridCorrectionType correctionType = getMadridCorrectionTransaction();
        intlIrTranDto.setIntlRecordId(correctionType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MC_CORRECTION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MC_CORRECTION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = madridCorrectionService
                .processInboundTransaction(intlIrTranDto, correctionType);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    private void processingMadridAbandonmentNotification(IntlIrTranDto intlIrTranDto, Integer fileNumber) {
        MadridDesignationTerminationType madridDesignationTerminationType = new MadridDesignationTerminationType();
        madridDesignationTerminationType.setExpiryDate("2027-02-28");
        madridDesignationTerminationType.setInternationalRegistrationNumber("8888888");
        // madridDesignationTerminationType.setMadridDesignationTerminationCategory();
        IdentifierType it = new IdentifierType();
        it.setOfficeCode("302017000013034/GT");
        madridDesignationTerminationType.setOfficeReferenceIdentifier(it);
        madridDesignationTerminationType.setRecordFilingDate("2017-02-28");
        IdentifierType it2 = new IdentifierType();
        it2.setOfficeCode("9999999");
        madridDesignationTerminationType.setRecordIdentifier(it2);
        // madridDesignationTerminationType.setSignatureBag(value);

        try {
            Map<ApplicationDto, UserTaskType> notificationTypes = irRCeasingOfEffectTotalService
                .processInboundTransaction(intlIrTranDto, madridDesignationTerminationType);

            assertTrue(notificationTypes.size() > 0);

            List<Mail> mail = new ArrayList<Mail>(mailDao.getMailByFileId(fileNumber));
            assertTrue(mail.size() > 0);

        } catch (MTSServiceFault e) {
            fail();
        }
    }

    /**
     * To create IntlAtchmtDto list
     *
     * @param intlIrTranDto
     * @return List<IntlAtchmtDto>
     * @throws SerialException
     * @throws SQLException
     */
    private List<IntlAtchmtDto> createAttachment(IntlIrTranDto intlIrTranDto) throws SerialException, SQLException {
        List<IntlAtchmtDto> intlAtchmtDtoList = new ArrayList<IntlAtchmtDto>();

        IntlAtchmtType atchType = new IntlAtchmtType();
        atchType.setAtchmtCtgryId(new Long(1));

        IntlFileFrmtType fileFrmtType = new IntlFileFrmtType();
        fileFrmtType.setFileFrmtId(new Long(2));

        Blob fileContent = new SerialBlob("blob".getBytes());

        IntlAtchmt intlAtchmt = new IntlAtchmt();

        intlAtchmt.setIntlAtchmtType(atchType);
        intlAtchmt.setIntlFileFrmtType(fileFrmtType);
        intlAtchmt.setFileName("IndustrialDesign-DataFlow-V15.pdf");
        intlAtchmt.setFileContent(fileContent);
        intlAtchmt.setIntlFileFrmtType(new IntlFileFrmtType(1, "pdf"));
        intlAtchmt.setIntlAtchmtType(new IntlAtchmtType(3, "doc"));
        // intlAtchmt.setIntlIrTran(intlIrTranDto.getIrTranId().);

        IntlAtchmtDto attachmentDao = createIntlAtchmtDto(intlAtchmt);
        // attachmentDao.save(intlAtchmt);
        intlAtchmtDtoList.add(attachmentDao);

        return intlAtchmtDtoList;
    }

    /**
     * To create IntlAtchmtDto
     *
     * @param intlAtchmt
     * @return IntlAtchmtDto
     */
    private IntlAtchmtDto createIntlAtchmtDto(IntlAtchmt intlAtchmt) {
        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto
            .setAtchmtCtgryId(BigDecimal.valueOf(intlAtchmt.getIntlAtchmtType().getAtchmtCtgryId().longValue()));
        intlAtchmtDto.setAtchmtId(intlAtchmt.getAtchmtId());
        intlAtchmtDto.setFileName(intlAtchmt.getFileName());
        // intlAtchmtDto.setIrTranId(intlAtchmt.getIntlIrTran().getIrTranId());
        intlAtchmtDto.setFileFrmtCtgry(intlAtchmt.getIntlFileFrmtType().getFileFrmtCtgry());
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(intlAtchmt.getIntlFileFrmtType().getFileFrmtId()));

        return intlAtchmtDto;
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private List<IntlIrTaskDto> getActiveTaskList(Application application) {
        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        return activeTaskList;
    }

    private void verifyMails(Application application) {
        List<Mail> mails = new ArrayList<Mail>(mailDao.getMailByFileId(application.getFileNumber()));
        assertTrue(mails.size() > 0);
        for (Mail m : mails) {
            System.out.println("mail time stamp: " + m.getMailTimestamp());
            System.out.println("file name: " + m.getAttachmentFileName());
        }
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

}
