package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoTypeDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;

/**
 * The Class tests methods in the TaskService.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@ContextConfiguration(locations = {"classpath:junit-ttmModelDaoContext.xml",
    "classpath:junit-idIntlModelDaoContext.xml"})
public class TestTaskService {

    private static final Logger logger = LoggerFactory.getLogger(TestTaskService.class);

    @Autowired
    private ITaskService taskService;

    @Autowired
    private IIntrepidCommonService intrepidService;

    @Test
    public void dummy() {
        assertTrue(1 == 1);
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestSycTask() {

        // TODO rewrite do to cipo schema changes.

        ConsoleTaskList consoleTaskList = new ConsoleTaskList();
        ConsoleTaskMeta consoleTaskMeta = new ConsoleTaskMeta();

        // good test for TRIGGER consoleTaskMeta.setTaskReferenceId("f6df5311-e0db-11e7-9997-2c4d544c0c89");
        consoleTaskMeta.setUserTaskStatus(TaskStatusType.UNPROCESSED.getValue());
        consoleTaskMeta.setUserTaskType(UserTaskType.SECTION_45_CASE_CLOSED.getValue());

        IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
        IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
        intlTaskAddtnlInfoTypeDto
            .setTaskAddtnlInfoCtgryId(BigDecimal.valueOf(TaskAddtnlInfoType.APPLICATION_ADDITIONAL_INFO.getValue()));
        intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
        intlTaskAddtnlInfoDto.setAddtnlInfo("additional info");
        consoleTaskMeta.getAdditionalInfos().add(intlTaskAddtnlInfoDto);

        consoleTaskMeta.setWipoReferenceNumber("WIPO-1");
        consoleTaskMeta.setExtensionCounter("0");
        consoleTaskMeta.setFileNumber(BigDecimal.valueOf(12345));
        consoleTaskMeta.setIrNumber("888999888");
        consoleTaskMeta.setOfficeType("DO");
        consoleTaskMeta.getTransactionIds().add(BigDecimal.valueOf(2904));

        consoleTaskList.getTaskListBag().add(consoleTaskMeta);

        List<ConsoleTaskResponse> response = taskService.createUserTask(consoleTaskList);

        assertTrue(response != null);

        List<IntlIrTaskDto> tasks = taskService.getTasksByTransactionId(BigDecimal.valueOf(2904));

        assertTrue(!CollectionUtils.isEmpty(tasks));

        assertTrue(1 == 1);
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestSycTask2() throws CIPOServiceFault {
        intrepidService.checkforExistingMarks(BigDecimal.valueOf(1330));
    }

}
