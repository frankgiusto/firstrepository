package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.mts.ApplicationNumber;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CeasingOfEffectMF9Type;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationList;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest.ManualReportForm;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.tm.mts.enums.ReportTypeEnum;
import ca.gc.ic.cipo.tm.mts.service.IMadridConsoleService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IRProcessGoodServices;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * The Class tests the processing of Goods and Services of a Partial Ceasing of Effect, initiated by manual tasks on the
 * Madrid Console.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestProcessNaNrCeasingEffect extends GoodsServicesTestBase {

    @Mock
    private IInternationalService internationalServiceMock;

    @Autowired
    private IMadridConsoleService madridConsoleService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Mock
    private IIntrepidCommonService intrepidCommonServiceMock;

    // @Mock
    // private IAirToExaminationSubmissionService airToExaminationSubmissionServiceMock;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private IRProcessGoodServices processGoodServices;

    private Application application = null;

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    private static final Logger log = LoggerFactory.getLogger(TestProcessNaNrCeasingEffect.class);

    @Before
    @Ignore
    @Transactional
    @Rollback(true)
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);

        ReflectionTestUtils.setField(madridConsoleService, "internationalService", internationalServiceMock);
        ReflectionTestUtils.setField(processGoodServices, "intrepidCommonService", intrepidCommonServiceMock);
        ReflectionTestUtils.setField(madridConsoleService, "intrepidCommonService", intrepidCommonServiceMock);
        // ReflectionTestUtils.setField(madridConsoleService, "airToExaminationSubmissionService",
        // airToExaminationSubmissionServiceMock);

        IntlIrTranDto intlIrTranDtoMock = new IntlIrTranDto();
        intlIrTranDtoMock.setIrTranId(BigDecimal.valueOf(0));

        IntlIrTaskDto intlIrTaskDtoMock = new IntlIrTaskDto();
        intlIrTaskDtoMock.setTaskId(BigDecimal.valueOf(0));
        intlIrTaskDtoMock.setFileNumber(0);
        intlIrTaskDtoMock.setExtensionCounter("0");

        Mockito.when((intrepidCommonServiceMock).getClaimsByGoodsServices(Mockito.any(BigDecimal.class),
            Mockito.any(String.class))).thenReturn(super.initGoodsServicesClaimsTypeList());

        Mockito.doNothing().when(internationalServiceMock).updateTaskStatus(BigDecimal.valueOf(0),
            TaskStatusType.PROCESSED);

        Mockito.when((internationalServiceMock).getConsoleTaskById(Mockito.any(BigDecimal.class)))
            .thenReturn(intlIrTaskDtoMock);

        Mockito
            .when((internationalServiceMock).storeTransaction(Mockito.any(ByteArrayOutputStream.class),
                Mockito.any(IntlPkg.class), Mockito.any(StatusType.class), Mockito.any(TransactionCategory.class),
                Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class)))
            .thenReturn(intlIrTranDtoMock);

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-G&S-Base.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355288000", "1355288");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        TMInfoRetrievalDto tmInfoRetrievalBean = initTIRSResult(application.getFileNumber());

        // OutboundTransactionDto
        OutboundTransactionDto outboundTransactionDto = new OutboundTransactionDto();

        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        outboundTransactionDto.setIntlRegNo(application.getIrNumber());
        outboundTransactionDto.setOfficeType(OfficeType.OO);
        outboundTransactionDto.setRegisteredApplication(true);
        outboundTransactionDto.setProcessActionApplication(tmInfoRetrievalBean);
        List<TMInfoRetrievalDto> madridApplicationActionDetails = new ArrayList<>();
        madridApplicationActionDetails.add(tmInfoRetrievalBean);
        outboundTransactionDto.setMadridApplicationActionDetails(madridApplicationActionDetails);

        Mockito.when((intrepidCommonServiceMock).getMadridApplicationDetails(Mockito.any(BigDecimal.class),
            Mockito.any(String.class))).thenReturn(outboundTransactionDto);
        Mockito
            .when((intrepidCommonServiceMock).getMadridApplicationDetails(Mockito.any(String.class),
                Mockito.any(BigDecimal.class), Mockito.any(String.class), Mockito.any(List.class)))
            .thenReturn(outboundTransactionDto);

        // Mockito
        // .when((intrepidCommonServiceMock).getMadridApplicationDetails(Mockito.any(String.class),
        // Mockito.any(BigDecimal.class), Mockito.any(String.class), Mockito.any(List.class)))
        // .thenReturn(outboundTransactionDto);
        //
        // Mockito.doNothing().when(airToExaminationSubmissionServiceMock).addMadridApplication(Mockito.any(String.class),
        // Mockito.any(MadridApplicationActionStatus.class));

        printGS(application);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectWithGSAdjustments()
        throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Madrid Application
        madridApplicationDao
            .saveMadridApplication(this.createMadridApplication(application, application.getIrNumber(), "FRANCO222"));

        ProcessManualReportRequest manualReportRequest = new ProcessManualReportRequest();
        manualReportRequest.setReportTypeCode(ReportTypeEnum.MF_9.value());
        manualReportRequest.setIrNumber(application.getIrNumber());
        manualReportRequest.setTaskId(BigDecimal.valueOf(0));
        manualReportRequest.setSystemDate(sdf.format(new Date()));
        manualReportRequest.setOwnerName("Joe Blow");
        manualReportRequest.setLanguageCode("en");
        manualReportRequest.setTransactionId(BigDecimal.valueOf(1));

        ManualReportForm manualReportForm = new ManualReportForm();
        CeasingOfEffectMF9Type ceasingOfEffectMF9Type = new CeasingOfEffectMF9Type();
        ceasingOfEffectMF9Type.setCeasingEffectiveInfo("Ceasing effect info");
        ceasingOfEffectMF9Type.setCeasingOfEffectDecision("a decision");
        ceasingOfEffectMF9Type.setRegistrarAuthority("MADRID");
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setExtensionCounter("0");
        applicationNumber.setFileNumber(BigDecimal.valueOf(1908272));
        ceasingOfEffectMF9Type.getBarNumberList().add(applicationNumber);

        manualReportForm.setCeasingOfEffectMF9Type(ceasingOfEffectMF9Type);

        GoodsAndServiceMeta goodsAndServiceMeta = new GoodsAndServiceMeta();
        goodsAndServiceMeta.setNotificationLanguage("en");
        goodsAndServiceMeta.setFileNumber(BigDecimal.valueOf(application.getFileNumber()));
        goodsAndServiceMeta.setExtensioncounter(application.getExtensionCounter().toString());
        goodsAndServiceMeta.setInternationalRegistrationNumber(application.getIrNumber());

        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(0));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.NANR_PARTIAL_CEASING_EFFECT);
        // IntlTransactionTypeList intlTransactionTypeList = new IntlTransactionTypeList();
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        goodsAndServiceMeta.getBasicMarkList().add(applicationNumber);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 1, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 fr", "fr"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 3, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 4, 2, "class number desc 39 en", "en"));

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        manualReportForm.getCeasingOfEffectMF9Type().setGoodsAndServices(goodsAndServiceMeta);
        manualReportRequest.setManualReportForm(manualReportForm);

        madridConsoleService.processManualReport(manualReportRequest);

        List<MadridApplication> verifyApplication = madridApplicationDao
            .getMadridApplicationByIrNumber(application.getIrNumber());

        assertTrue(CollectionUtils.isNotEmpty(verifyApplication));

        // check isHasMatchedActionCode
        verifyHasMatchedActionCode();
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectWithNOAdjustments()
        throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        // Create Madrid Application
        madridApplicationDao
            .saveMadridApplication(this.createMadridApplication(application, application.getIrNumber(), "FRANCO223"));

        ProcessManualReportRequest manualReportRequest = new ProcessManualReportRequest();
        manualReportRequest.setReportTypeCode(ReportTypeEnum.MF_9.value());
        manualReportRequest.setIrNumber(application.getIrNumber());
        manualReportRequest.setTaskId(BigDecimal.valueOf(0));
        manualReportRequest.setSystemDate(sdf.format(new Date()));
        manualReportRequest.setOwnerName("Joe Blow");
        manualReportRequest.setLanguageCode("en");
        manualReportRequest.setTransactionId(BigDecimal.valueOf(1));

        ManualReportForm manualReportForm = new ManualReportForm();
        CeasingOfEffectMF9Type ceasingOfEffectMF9Type = new CeasingOfEffectMF9Type();
        ceasingOfEffectMF9Type.setCeasingEffectiveInfo("Ceasing effect info");
        ceasingOfEffectMF9Type.setCeasingOfEffectDecision("a decision");
        ceasingOfEffectMF9Type.setRegistrarAuthority("MADRID");
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setExtensionCounter("0");
        applicationNumber.setFileNumber(BigDecimal.valueOf(1908272));
        ceasingOfEffectMF9Type.getBarNumberList().add(applicationNumber);

        manualReportForm.setCeasingOfEffectMF9Type(ceasingOfEffectMF9Type);

        GoodsAndServiceMeta goodsAndServiceMeta = new GoodsAndServiceMeta();
        goodsAndServiceMeta.setNotificationLanguage("en");
        goodsAndServiceMeta.setFileNumber(BigDecimal.valueOf(application.getFileNumber()));
        goodsAndServiceMeta.setExtensioncounter(application.getExtensionCounter().toString());
        goodsAndServiceMeta.setInternationalRegistrationNumber(application.getIrNumber());

        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(0));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.NANR_PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        goodsAndServiceMeta.getBasicMarkList().add(applicationNumber);

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 1, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 fr", "fr"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 3, 2, "class number desc 36 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 4, 2, "class number desc 39 en", "en"));

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        manualReportForm.getCeasingOfEffectMF9Type().setGoodsAndServices(goodsAndServiceMeta);
        manualReportRequest.setManualReportForm(manualReportForm);

        madridConsoleService.processManualReport(manualReportRequest);

        List<MadridApplication> verifyApplication = madridApplicationDao
            .getMadridApplicationByIrNumber(application.getIrNumber());

        assertTrue(CollectionUtils.isNotEmpty(verifyApplication));

        // check isHasMatchedActionCode
        verifyHasMatchedActionCode();
    }

    private void verifyHasMatchedActionCode() {
        try {
            // TODO:: Hua to update with correct Transaction type, if MADRID_CEASING_EFFECT_MF9 is not the correct one
            OutboundTransactionDto outboundTransactionDto = intrepidCommonServiceMock.getMadridApplicationDetails(
                application.getIrNumber(), BigDecimal.valueOf(application.getFileNumber()), "0", new ArrayList());

            // MadridOutboundTransactionType.MADRID_POTENTIAL_CEASING_EFFECT
            // doesn't exist in Madrid_Application_Actions table
            System.out.println("hasMatchedActionCode value: " + outboundTransactionDto.isHasMatchedActionCode());
            // assertTrue(!outboundTransactionDto.isHasMatchedActionCode());

        } catch (CIPOServiceFault e) {
            log.error("Error verifyHasMatchedActionCode for ir number: " + application.getIrNumber(), e);
        }
    }

}
