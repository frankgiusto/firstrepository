package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions. ,
 * "classpath:junit-idIntlModelDaoContext.xml"
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestLockTrademark {

    private static final Logger log = LoggerFactory.getLogger(TestLockTrademark.class);

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    @Test
    @Rollback(true)
    @Transactional
    public void TestLockTrademark() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        boolean exception = false;
        try {

            intrepidCommonService.acquireTrademarkLock(1, 0, "superman");
            intrepidCommonService.releaseTrademarkLock(1, 0);

            intrepidCommonService.acquireTrademarkLock(1, 0, "superman");

            // If another user attempts to acquire the lock, an exception is raised
            intrepidCommonService.acquireTrademarkLock(1, 0, "superwoman");
        } catch (DataAccessException e) {
            exception = true;
        }
        assertTrue(exception);
        intrepidCommonService.releaseTrademarkLock(1, 0);

    }
}
