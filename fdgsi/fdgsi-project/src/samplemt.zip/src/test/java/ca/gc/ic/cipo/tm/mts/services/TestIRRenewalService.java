package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridRenewalType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRRenewalService {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRRenewalService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irRenewal")
    private IInboundTransaction irRenewalService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbIRRenewalContext = initIRRenewalContext();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridRenewalType getIRRenewalTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbIRRenewalContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/IRRenewalTransaction.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridRenewalType> madridRenewalElement = (JAXBElement<MadridRenewalType>) unmarshallerRoot
            .unmarshal(xml);

        return madridRenewalElement.getValue();
    }

    private MadridRenewalType getIRRenewalTransaction(String transactionFileName)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbIRRenewalContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource(transactionFileName));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridRenewalType> madridRenewalElement = (JAXBElement<MadridRenewalType>) unmarshallerRoot
            .unmarshal(xml);

        return madridRenewalElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestGetActiveTasks() throws MTSServiceFault, FileNotFoundException, JAXBException {

        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestRegisteredIrRenewal()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException, InterruptedException {

        Thread.sleep(1000);
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("7766554");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);

        // IR Renewal
        MadridRenewalType irRenewalTransaction = getIRRenewalTransaction();
        intlIrTranDto.setIntlRecordId(irRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("7766554");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        irRenewalService.processInboundTransaction(intlIrTranDto, irRenewalTransaction);
        applicationDto = newApplication.keySet().iterator().next();

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean renewed = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.IR_RENEWED.getValue())) {
                assertTrue(action.getAdditionalInfo().contains("DP:" + getFormattedSystemDate()));

                // "2027-05-08"
                Date responseDate = action.getResponseDate();
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(responseDate);

                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH) + 1;
                int year = calendar.get(Calendar.YEAR);

                assertTrue(day == 8);
                assertTrue(month == 5);
                assertTrue(year == 2027);

                // "2017-05-08" Action Date
                Date actionDate = action.getActionDate();
                calendar = Calendar.getInstance();
                calendar.setTime(actionDate);

                day = calendar.get(Calendar.DAY_OF_MONTH);
                month = calendar.get(Calendar.MONTH) + 1;
                year = calendar.get(Calendar.YEAR);

                assertTrue(day == 8);
                assertTrue(month == 5);
                assertTrue(year == 2017);

                renewed = true;
                break;
            }
        }
        assertTrue(renewed);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        renewed = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode().equals(ProcessActionsType.PRINT_IR_RENEWAL_ACKNOWLEDGEMENT.getValue())) {
                renewed = true;
                break;
            }
        }
        assertTrue(renewed);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestNoMarkRenewal() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId("345353234");

        // IR Non Renewal
        MadridRenewalType irRenewalTransaction = getIRRenewalTransaction();
        intlIrTranDto.setIntlRecordId(irRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        activeTaskList.add(dto);
        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        try {
            irRenewalService.processInboundTransaction(intlIrTranDto, irRenewalTransaction);
        } catch (MTSServiceFault e) {
            assertTrue(e.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode());
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testQABug919() throws FileNotFoundException, JAXBException, MTSServiceFault {

        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8885588");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);

        System.out.println("File Number: " + application.getFileNumber().toString());

        // IR Non Renewal
        MadridRenewalType irRenewalTransaction = getIRRenewalTransaction("/IRRenewalTransaction-TMMADCON-919.xml");
        intlIrTranDto.setIntlRecordId(irRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8885588");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);
        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        irRenewalService.processInboundTransaction(intlIrTranDto, irRenewalTransaction);
        applicationDto = newApplication.keySet().iterator().next();

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean renewed = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.IR_RENEWED.getValue())) {
                assertTrue(action.getAdditionalInfo().contains("DP:" + getFormattedSystemDate()));

                // "2028-11-19" response date = expiry date
                Date responseDate = action.getResponseDate();
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(responseDate);

                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH) + 1;
                int year = calendar.get(Calendar.YEAR);

                assertTrue(day == 19);
                assertTrue(month == 11);
                assertTrue(year == 2028);

                // "2018-11-19" Action Date = renewal date
                Date actionDate = action.getActionDate();
                calendar = Calendar.getInstance();
                calendar.setTime(actionDate);

                day = calendar.get(Calendar.DAY_OF_MONTH);
                month = calendar.get(Calendar.MONTH) + 1;
                year = calendar.get(Calendar.YEAR);

                assertTrue(day == 19);
                assertTrue(month == 11);
                assertTrue(year == 2018);

                renewed = true;
                break;
            }
        }
        assertTrue(renewed);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        renewed = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode().equals(ProcessActionsType.PRINT_IR_RENEWAL_ACKNOWLEDGEMENT.getValue())) {
                renewed = true;
                break;
            }
        }
        assertTrue(renewed);

    }

    // @Test
    @Rollback(true)
    @Transactional
    public void TestInactiveMarkRenewal() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId("345353234");

        // Create a test application - Set status to an Inactive Status
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.UNKNOWN_STATUS.getValue());

        applicationDao.saveApplication(application);

        // IR Non Renewal
        MadridRenewalType irRenewalTransaction = getIRRenewalTransaction();
        intlIrTranDto.setIntlRecordId(irRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        try {
            irRenewalService.processInboundTransaction(intlIrTranDto, irRenewalTransaction);
        } catch (MTSServiceFault e) {
            if (e.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()) {
                assertTrue(e.getApplicationDto() != null);
            } else {
                fail("unexpeced fault");
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestNotRegisteredIrRenewal()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("7888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        // IR Non Renewal
        MadridRenewalType irRenewalTransaction = getIRRenewalTransaction();
        intlIrTranDto.setIntlRecordId(irRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("7888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(applicationDto.getFileNumber());
        activeTaskList.add(dto);
        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        irRenewalService.processInboundTransaction(intlIrTranDto, irRenewalTransaction);

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean renewed = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.IR_RENEWED.getValue())) {
                renewed = true;
                break;
            }
        }
        assertTrue(renewed);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        renewed = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode().equals(ProcessActionsType.PRINT_IR_RENEWAL_ACKNOWLEDGEMENT.getValue())) {
                renewed = true;
                break;
            }
        }
        assertTrue(renewed);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestCreateRenewal() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("7766554");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);

        System.out.println(application.getFileNumber());
    }

    private void setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MR_RENEWAL.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MR_RENEWAL.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }
    }

    private String getFormattedSystemDate() {
        Calendar calendar = Calendar.getInstance();
        StringBuilder systemDate = new StringBuilder();
        systemDate.append(calendar.get(Calendar.YEAR)).append("-")
            .append(String.format("%02d", calendar.get(Calendar.MONTH) + 1)).append("-");
        systemDate.append(String.format("%02d", calendar.get(Calendar.DAY_OF_MONTH)));

        return systemDate.toString();
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private static JAXBContext initIRRenewalContext() {
        try {
            return JAXBContext.newInstance(MadridRenewalType.class, MadridRenewalType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBIRrenewalContext instance", e);
        }
        return null;

    }
}
