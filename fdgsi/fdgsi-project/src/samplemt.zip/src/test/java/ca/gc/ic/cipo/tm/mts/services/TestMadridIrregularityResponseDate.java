package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.rowset.serial.SerialBlob;
import javax.xml.bind.JAXBException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgSchmaVrsn;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ResponseDueDateResponse;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.InboundTransactionService;

/**
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridIrregularityResponseDate {

    private final static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Autowired
    private InboundTransactionService inboundTransactionService;

    @Autowired
    private IntlPkgDao pkgDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao pkgSchmaVrsnDao;

    @Autowired
    private IntlPkgTranTypeDao intlPkgTranTypeDao;

    @Autowired
    private IntlPkgTypeDao intlPkgTypeDao;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testGetTransactionList() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        File xmlFile = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Irregularity.xml"));
        FileInputStream fin = null;
        fin = new FileInputStream(xmlFile);
        byte fileContent[] = new byte[(int) xmlFile.length()];
        fin.read(fileContent);
        if (fin != null) {
            fin.close();
        }

        IntlIrTran intlIrTran = createTransaction(fileContent);
        ResponseDueDateResponse responseDueDateResponse = inboundTransactionService
            .getResponseDueDate(intlIrTran.getIrTranId());
        Date response = responseDueDateResponse.getResponseDueDate();
        boolean areEqualDates = dateFormat.format(response).equals("2013-03-21");

        assertTrue(areEqualDates);
    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTran createTransaction(byte xml[]) throws SQLException, UnsupportedEncodingException {

        IntlPkgType intlPkgType = new IntlPkgType();
        intlPkgType.setPkgCtgryId(new BigDecimal(999));
        intlPkgType.setPackageCtgry("adtest");
        intlPkgType.setDestnName("adInbound");
        intlPkgTypeDao.save(intlPkgType);

        IntlPkgSchmaVrsn pkgSchmaVrsn = new IntlPkgSchmaVrsn();
        pkgSchmaVrsn.setIntlPkgType(intlPkgType);
        pkgSchmaVrsn.setSchmaFileName("adtest");
        pkgSchmaVrsn.setVldFromDt(new Timestamp(System.currentTimeMillis()));
        pkgSchmaVrsnDao.save(pkgSchmaVrsn);

        IntlStatusType intlStatusType = new IntlStatusType();
        intlStatusType.setStatusCtgryId(new BigDecimal(99999));
        intlStatusType.setStatusCtgry("adtest");
        intlStatusTypeDao.save(intlStatusType);

        IntlPkg intlPkg = new IntlPkg();

        // all 9 mandatory fields
        intlPkg.setIntlPkgType(intlPkgType);
        intlPkg.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlPkg.setIntlStatusType(intlStatusType);
        intlPkg.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlPkg.setIntlPblctnId("11/2017");
        intlPkg.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
        Blob xmlFileContent = new SerialBlob("adblob".getBytes());
        intlPkg.setXmlFileName("adtest.zip");
        intlPkg.setXmlFileContent(xmlFileContent);
        pkgDao.save(intlPkg);

        IntlPkgTranType intlPkgTranType = intlPkgTranTypeDao.getTranTypeById(
            BigDecimal.valueOf(TransactionCategory.MI_IRREGULARITY_NOTIFICATION.getTransactionCategoryId().intValue()));

        // all 7 mandatory fields plus pkg_id field
        IntlIrTran intlIrTran = new IntlIrTran();
        intlIrTran.setIntlPkg(intlPkg);
        intlIrTran.setIntlPkgTranType(intlPkgTranType);
        intlIrTran.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlIrTran.setIntlStatusType(intlStatusType);
        intlIrTran.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlIrTran.setXmlContent(intlIrTranDao.createAsBlob(xml));

        // nullable fields
        Date intlRecordEfctvDt = new Date();
        intlRecordEfctvDt.getTime();

        intlIrTran.setIntlRegNo("adReg");
        intlIrTran.setIntlRecordId("999999");
        intlIrTran.setIntlRecordEfctvDt(intlRecordEfctvDt);
        intlIrTran.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));

        intlIrTranDao.save(intlIrTran);
        return intlIrTran;

    }

}
