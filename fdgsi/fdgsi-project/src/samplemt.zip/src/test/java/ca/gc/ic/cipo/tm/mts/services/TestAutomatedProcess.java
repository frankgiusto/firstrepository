package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.xml.bind.JAXBException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.StatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgSchmaVrsn;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.InboundTransactionService;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@ContextConfiguration(locations = {"classpath:junit-ttmModelDaoContext.xml",
    "classpath:junit-idIntlModelDaoContext.xml"})
public class TestAutomatedProcess {

    private static final Logger log = LoggerFactory.getLogger(TestAutomatedProcess.class);

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IntlPkgDao pkgDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao pkgSchmaVrsnDao;

    @Autowired
    private IntlPkgTranTypeDao intlPkgTranTypeDao;

    @Autowired
    private IntlPkgTypeDao intlPkgTypeDao;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private InboundTransactionService inboundTransactionService;

    File xml = null;

    File xml2 = null;

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestProcessIRCreation() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/MadridInternationalRegistration.xml"));
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml), TransactionCategory.MIR_REGISTRATION);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_CREATION);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestProcessIRCeasingOfEffectProcess()
        throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/MadridInternationalRegistration.xml"));
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_CEASING_OF_EFFECT_TOTAL);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestHolderNameAddressChangeProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridHolderRepresentativeChange-NameAddress.xml"));
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_HOLDER_NAME_ADDRESS_CHANGE);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRNonRenewalProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/IRNonRenewalTransaction.xml"));
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.MDT_NON_RENEWAL_OF_TRADEMARK);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_NON_RENEWAL);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRNotificationProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/IRNonRenewalTransaction.xml")); // just need for
                                                                                                      // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml), TransactionCategory.MCP_NO_CATEGORY);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_NOTIFICATION);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIROwnershipChangeMergerProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto designationDto = null;
        IntlIrTranDto designationTerminationDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Merger.xml"));
            xml2 = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignationTermination-Merger.xml"));
            designationDto = createTransaction(FileUtils.readFileToByteArray(xml), TransactionCategory.MDT_MERGER);
            designationTerminationDto = createTransaction(FileUtils.readFileToByteArray(xml2), designationDto);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionPairRequest transactionRequest = new TransactionPairRequest();
        transactionRequest.setAssociatedIrTranId(designationDto.getIrTranId());
        // transactionRequest.setIrNumber(designationTerminationDto.getIntlRegNo());
        transactionRequest.setIrTranId(designationTerminationDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_OWNERSHIP_CHANGE_MERGER);

        try {
            inboundTransactionService.processOwnershipChangeMerger(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(transactionRequest.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    // @Test
    // @Rollback(true)
    // @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    // public void TestIROwnershipChangePartialTerminationProcess()
    // throws JAXBException, SQLException, CIPOServiceFault, IOException {
    //
    // IntlIrTranDto designationDto = null;
    // IntlIrTranDto designationTerminationDto = null;
    // try {
    // xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Partial-Ownership.xml"));
    // xml2 = ResourceUtils
    // .getFile(this.getClass().getResource("/MadridDesignationTermination-Partial-Ownership.xml"));
    // designationDto = createTransaction(FileUtils.readFileToByteArray(xml),
    // TransactionCategory.MDT_PARTIAL_CHANGE_OF_OWNERSHIP);
    // designationTerminationDto = createTransaction(FileUtils.readFileToByteArray(xml2), designationDto);
    // } catch (SQLException e) {
    // e.printStackTrace();
    // }
    //
    // TransactionPairRequest transactionRequest = new TransactionPairRequest();
    // transactionRequest.setAssociatedIrTranId(designationDto.getIrTranId());
    // // transactionRequest.setIrNumber(designationTerminationDto.getIntlRegNo());
    // transactionRequest.setIrTranId(designationTerminationDto.getIrTranId());
    // // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_OWNERSHIP_CHANGE_PARTIAL);
    //
    // try {
    // inboundTransactionService.processOwnershipChangePartialTransaction(transactionRequest);
    // } catch (Exception exception) {
    // if (exception instanceof CIPOServiceFault) {
    // // processing designation error.
    // CIPOServiceFault fault = (CIPOServiceFault) exception;
    // if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
    // .intValue()
    // || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
    // .intValue()) {
    //
    // IntlIrTranDto intlIrTran = internationalService
    // .getTransactionsByIrTranId(transactionRequest.getIrTranId());
    //
    // assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
    // .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());
    //
    // }
    // }
    // }
    // }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIROwnershipChangePartialRestrictionProcess()
        throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridDesignation-Combined-Partial-Ownership.xml")); // just need
                                                                                                            // for
            // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());

        try {
            inboundTransactionService.processTransaction(transactionRequest);

        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(transactionRequest.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTranDto createTransaction(byte[] xml, IntlIrTranDto previousTransaction)
        throws SerialException, SQLException {

        IntlIrTran previousIrTran = intlIrTranDao.getIrTranById(previousTransaction.getIrTranId());
        IntlIrTran intlIrTran = new IntlIrTran();
        BeanUtils.copyProperties(previousIrTran, intlIrTran);
        intlIrTran.setIrTranId(null);
        intlIrTran.setIntlAtchmts(null);
        intlIrTran.setIntlStatusHists(null);
        intlIrTranDao.save(intlIrTran);

        return internationalDTOFactory.getIntlIrTranDto(intlIrTran);
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRTotalOwnershipChangeProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/IRChangeOwnershipTotal.xml")); // just need for
                                                                                                     // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.MHR_CHANGE_OF_OWNER);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRRenewalProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/IRRenewalTransaction.xml")); // just need for
                                                                                                   // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml), TransactionCategory.MR_RENEWAL);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_RENEWAL);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRRenunciationProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridDesignationTermination-Partial-Ownership.xml")); // just
                                                                                                              // need
                                                                                                              // for
            // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml), TransactionCategory.MDT_RENUNCIATION);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_RENUNCIATION);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRTotalCancellationProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridDesignationTermination-Total-Cancellation.xml")); // just
                                                                                                               // need
                                                                                                               // for
            // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.MDT_TOTAL_CANCELLATION);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_CANCELLATION_TOTAL);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
        // IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(intlIrTranDto.getIrTranId());
        //
        // assertTrue(
        // intlIrTran.getStatusTypeDto().getStatusCtgryId().intValue() == StatusType.PROCESSED.getValue().intValue());
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestIRPartialCancellationProcess() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils
                .getFile(this.getClass().getResource("/MadridProtectionRestriction-Partial-Cancellation.xml")); // just
                                                                                                                // need
                                                                                                                // for
            // populate irtran
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml),
                TransactionCategory.MPR_PARTIAL_CANCELLATION);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrNumber(intlIrTranDto.getIntlRegNo());
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());
        // transactionRequest.setTransactionCategoryType(TransactionCategoryType.PROCESS_IR_CANCELLATION_PARTIAL);

        try {
            inboundTransactionService.processTransaction(transactionRequest);
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }

        // IntlIrTranDto intlIrTran = internationalService.getTransactionsByIrTranId(intlIrTranDto.getIrTranId());
        //
        // assertTrue(
        // intlIrTran.getStatusTypeDto().getStatusCtgryId().intValue() == StatusType.PROCESSED.getValue().intValue());
    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testCompleteProcessing() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTranDto intlIrTranDto = null;
        try {
            xml = ResourceUtils.getFile(this.getClass().getResource("/MadridCompletedProcessing.xml"));
            intlIrTranDto = createTransaction(FileUtils.readFileToByteArray(xml), TransactionCategory.MCP_NO_CATEGORY,
                StatusType.MPS_IMPORT_COMPLETE);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        Timestamp time = intlIrTranDto.getUpdatedTmstmp();

        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setIrTranId(intlIrTranDto.getIrTranId());

        IntlIrTran intlIrTranToUpdate = intlIrTranDao.getIrTranById(intlIrTranDto.getIrTranId());
        byte[] bytes = IOUtils.toByteArray(intlIrTranToUpdate.getXmlContent().getBinaryStream());
        String xmlString = new String(bytes, "UTF-8");
        xmlString = xmlString.replace("OfficeRefId_VAR", intlIrTranDto.getIrTranId().toString());

        intlIrTranToUpdate.setXmlContent(new SerialBlob(xmlString.getBytes()));
        intlIrTranDao.save(intlIrTranToUpdate);

        // The status should be in progress.
        assertTrue(!StringUtils.equalsIgnoreCase(intlIrTranToUpdate.getIntlStatusType().getCategory(),
            StatusType.PROCESSED.toString()));

        try {
            inboundTransactionService.processTransaction(transactionRequest);

            IntlIrTran postTransaction = intlIrTranDao.getIrTranById(intlIrTranDto.getIrTranId());

            // After the transaction is donw, package tran type is forced to update to MCP_NO_CATEGORY (Completed
            // processing)
            // and transaction status is forced to update to PROCESSED (Closed - Processed)
            assertEquals(postTransaction.getIntlPkgTranType().getCategory(),
                TransactionCategory.MCP_NO_CATEGORY.toString());
            assertEquals(postTransaction.getIntlStatusType().getCategory(), StatusType.PROCESSED.toString());

            // Timestamp: the transaction should get updated instead of the original timestamp.
            assertTrue(postTransaction.getUpdatedTmstmp().getTime() != time.getTime());
        } catch (Exception exception) {
            if (exception instanceof CIPOServiceFault) {
                // processing designation error.
                CIPOServiceFault fault = (CIPOServiceFault) exception;
                if (fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.MARK_NOT_FOUND.getReasonCode()
                    .intValue()
                    || fault.getFaultInfo().getReasonCode() == ExceptionReasonCode.INACTIVE_APPLICATION.getReasonCode()
                        .intValue()) {

                    IntlIrTranDto intlIrTran = internationalService
                        .getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

                    assertTrue(intlIrTran.getStatusTypeDto().getStatusCtgryId()
                        .intValue() == StatusType.PROCESSED_WITH_ERROR.getValue().intValue());

                }
            }
        }
    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTranDto createTransaction(byte[] xml, TransactionCategory transactionCategory)
        throws SerialException, SQLException {

        return createTransaction(xml, transactionCategory, null);

    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTranDto createTransaction(byte[] xml, TransactionCategory transactionCategory, StatusType statusCtgry)
        throws SerialException, SQLException {

        IntlPkgType intlPkgType = new IntlPkgType();
        intlPkgType.setPkgCtgryId(new BigDecimal(877));
        intlPkgType.setPackageCtgry("test");
        intlPkgType.setDestnName("Inbound");
        intlPkgTypeDao.save(intlPkgType);

        IntlPkgSchmaVrsn pkgSchmaVrsn = new IntlPkgSchmaVrsn();
        pkgSchmaVrsn.setIntlPkgType(intlPkgType);
        pkgSchmaVrsn.setSchmaFileName("test");
        pkgSchmaVrsn.setVldFromDt(new Timestamp(System.currentTimeMillis()));
        pkgSchmaVrsnDao.save(pkgSchmaVrsn);

        IntlStatusType intlStatusType = new IntlStatusType();
        intlStatusType.setStatusCtgryId(new BigDecimal(statusCtgry != null ? statusCtgry.getValue() : 453235));
        intlStatusType.setStatusCtgry(statusCtgry != null ? statusCtgry.toString() : "asdfasdf");
        intlStatusTypeDao.save(intlStatusType);

        IntlPkg intlPkg = new IntlPkg();

        // all 9 mandatory fields
        intlPkg.setIntlPkgType(intlPkgType);
        intlPkg.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlPkg.setIntlStatusType(intlStatusType);
        intlPkg.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlPkg.setIntlPblctnId("11/2017");
        intlPkg.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
        Blob xmlFileContent = new SerialBlob("blob".getBytes());
        intlPkg.setXmlFileName("H201711.zip");
        intlPkg.setXmlFileContent(xmlFileContent);
        pkgDao.save(intlPkg);

        IntlPkgTranType intlPkgTranType = intlPkgTranTypeDao
            .getTranTypeById(BigDecimal.valueOf(transactionCategory.getTransactionCategoryId().intValue()));

        // IntlPkgTranType intlPkgTranType = new IntlPkgTranType();
        // intlPkgTranType
        // .setPkgTranCtgryId(BigDecimal.valueOf(transactionCategory.getTransactionCategoryId().intValue()));
        // intlPkgTranType.setTranCtgry("TEST");
        // intlPkgTranType.setIntlPkgType(intlPkgType);
        // intlPkgTranTypeDao.persistIntlPkgTranType(intlPkgTranType);

        // all 7 mandatory fields plus pkg_id field
        IntlIrTran intlIrTran = new IntlIrTran();
        intlIrTran.setIntlPkg(intlPkg);
        intlIrTran.setIntlPkgTranType(intlPkgTranType);
        intlIrTran.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlIrTran.setIntlStatusType(intlStatusType);
        intlIrTran.setIntlRegNo("WIPO40480");
        intlIrTran.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlIrTran.setXmlContent(new SerialBlob(xml));

        // nullable fields
        Date intlRecordEfctvDt = new Date();
        intlRecordEfctvDt.getTime();

        intlIrTran.setIntlRecordId("852902001");
        intlIrTran.setIntlRecordEfctvDt(intlRecordEfctvDt);
        intlIrTran.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));

        intlIrTran.setIntlRecordId("343535");
        intlIrTran.setIntlRegNo("8888888");

        intlIrTranDao.save(intlIrTran);

        return internationalDTOFactory.getIntlIrTranDto(intlIrTran);

    }
}
