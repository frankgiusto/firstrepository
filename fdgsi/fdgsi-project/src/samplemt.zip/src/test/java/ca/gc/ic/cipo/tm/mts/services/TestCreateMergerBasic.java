package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.MadridNewBasicApplicationType;
import _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ProcessActionCodeType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.OutboundTransactionDto;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;

/**
 * The Class TestInternationalService tests methods in the International Service.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-ttmModelDaoContext.xml",
    "classpath:junit-idIntlModelDaoContext.xml"})
public class TestCreateMergerBasic {

    private static final Logger logger = LoggerFactory.getLogger(TestCreateMergerBasic.class);

    @Autowired
    private IOutboundTransactionService outboundTransactionService;

    @Autowired
    private IIntrepidCommonService intrepidCommonService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final Logger log = LoggerFactory.getLogger(TestCreateMergerBasic.class);

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid",
                ObjectFactory.class.getClassLoader());
            // return JAXBContext.newInstance(MadridNewBasicApplicationType.class, MadridNewBasicApplicationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private MadridNewBasicApplicationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridNewBasicApplication.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridNewBasicApplicationType> madridDesignationElement = (JAXBElement<MadridNewBasicApplicationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    @Test
    public void dummy() {
        assertTrue(1 == 1);
    }

    // @Test
    @Rollback(true)
    @Transactional
    public void TestRegisteredCeasingOfEffect() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        // CREATE an application with opposition cases
        MadridNewBasicApplicationType transaction = getMadridTransaction();

        assertTrue(transaction != null);

        ByteArrayOutputStream os = unmarshalThis(transaction);
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(new File("MergerBasicApplication.xml"));
            os.writeTo(fos);
        } finally {
            fos.close();
        }

    }

    // <a:processActionsMeta>
    // <a:fileNumber>1830049</a:fileNumber>
    // <a:extensionCounter>0</a:extensionCounter>
    // <a:processCode>209</a:processCode>
    // <a:wipoReferenceNumber>WIPO54321</a:wipoReferenceNumber>
    // <a:officeType>OO</a:officeType>
    // <a:statusCode>2</a:statusCode>
    // <a:additionalInfo>requested on 2017/11/17 08:42:01 by user MACPHEB1</a:additionalInfo>
    // <a:processActionCodeType>Merger of Basic Application</a:processActionCodeType>
    // </a:processActionsMeta>

    // @Test
    @Rollback(true)
    @Transactional(readOnly = false) // value = "tmIntlTransactionManager",
    public void createMF1() throws IOException, CIPOServiceFault, SQLException {

        ProcessActionsMeta processActionsMeta = new ProcessActionsMeta();
        processActionsMeta.setFileNumber(BigDecimal.valueOf(1857600)); // 148396 1830049
        processActionsMeta.setIrNumber("1355299");
        processActionsMeta.setExtensionCounter("0");
        processActionsMeta.setAuthorityId("GIUSTOF1");
        // processActionsMeta.setWipoReferenceNumber("WIPO54321");
        processActionsMeta.setAdditionalInfo("requested on 2017/11/17 08:42:01 by user MACPHEB1");
        processActionsMeta.setProcessActionCodeType(ProcessActionCodeType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF_1);

        OutboundTransactionDto tmInfoRetrievalDtoList = intrepidCommonService
            .getMadridApplicationDetails(processActionsMeta);

        if (null == tmInfoRetrievalDtoList) {
            logger.error("Error creating outbound transacion. No Madrid_Application found!");
        }

        try {
            outboundTransactionService.createAutoOutboundTransaction(processActionsMeta, tmInfoRetrievalDtoList);
            log.info("wundaba");
        } catch (CIPOServiceFault e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // String dd;
        // FileOutputStream fos = null;
        // try {
        // fos = new FileOutputStream(new File("MergerBasicApplication.xml"));
        // os.writeTo(fos);
        // } finally {
        // fos.close();
        // }
    }

    private ByteArrayOutputStream unmarshalThis(MadridNewBasicApplicationType transaction) {
        _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory();

        String resultStr = null;
        ByteArrayOutputStream os = null;
        JAXBElement<MadridNewBasicApplicationType> madridobject = objectFactory
            .createMadridNewBasicApplication(transaction);
        Marshaller jaxbMarshaller;
        try {
            // JAXBContext jaxbContext = JAXBContext.newInstance(MadridNewBasicApplicationType.class,
            // MadridNewBasicApplicationType.class);

            jaxbMarshaller = jaxbMadridDesignationContext.createMarshaller();
            os = marshalIt(jaxbMarshaller, madridobject);

            resultStr = os.toString("UTF-8");

        } catch (JAXBException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // if I/O error occurs
            e.printStackTrace();
        } finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException e) {

                }
            }
        }
        return os;
    }

    private static <T> ByteArrayOutputStream marshalIt(Marshaller marshaller, JAXBElement<T> madridObject)
        throws JAXBException {

        ByteArrayOutputStream os = new ByteArrayOutputStream();

        @SuppressWarnings("unchecked")
        JAXBElement jaxbElement = new JAXBElement(madridObject.getName(), madridObject.getClass(),
            madridObject.getValue());
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.marshal(jaxbElement, os);

        return os;
    }

}
