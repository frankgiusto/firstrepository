package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;

public class TestEnumUtils {

    private static final Logger log = LoggerFactory.getLogger(TestEnumUtils.class);

    @Test
    public void testSectionAuthority() {
        boolean result = SectionAuthority.contains(SectionAuthority.MC_TM_EXAMINER.name());

        assertTrue(result);

        result = SectionAuthority.contains("Invalid");

        assertTrue(!result);

    }

}
