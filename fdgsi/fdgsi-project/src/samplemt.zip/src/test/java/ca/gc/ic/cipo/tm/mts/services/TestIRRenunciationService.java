package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionActionType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRRenunciationService {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRRenunciationService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irRenunciation")
    private IInboundTransaction irRenunciationService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbMadridDesignationTermination = initMadridDesignationTerminationContext();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationTerminationType getMadridDesignationTermination()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationTermination.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignationTermination-Partial-Ownership.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationTerminationType> madridDesignationTerminationElement = (JAXBElement<MadridDesignationTerminationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationTerminationElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestRegisteredRenunciation()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException, InterruptedException {

        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Thread.sleep(1000);

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        OppositionCase oppositionCase = createOppositionCase(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction = createOppositionAction(application, oppositionCase,
            OppositionCaseActionCodeType.CLOSED_BY_TMO);
        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        // IR Designation Termination
        MadridDesignationTerminationType madridDesignationTerminationType = getMadridDesignationTermination();
        intlIrTranDto.setIntlRecordId(madridDesignationTerminationType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irRenunciationService
            .processInboundTransaction(intlIrTranDto, madridDesignationTerminationType);

        assertTrue(null != notificationTypes && notificationTypes.size() > 0);

        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType taskType : notifications) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.IR_RENUNCIATION);
            }
        }
        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify application status.
        assertTrue(
            application.getStatusCode().intValue() == TradeMarkStatusType.CANCELLED_BY_OWNER.getValue().intValue());

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean valid = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.CANCELLED_BY_OWNER.getValue())) {
                valid = true;
                break;
            }
        }
        assertTrue(valid);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);

        valid = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION.getValue())) {
                valid = true;
                break;
            }
        }
        assertTrue(valid);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestNotRegisteredIrRenewal()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException, InterruptedException {

        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a test application
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Thread.sleep(1000);

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());

        OppositionCase oppositionCase = createPendingOppositionCase(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction = createOppositionAction(application, oppositionCase,
            OppositionCaseActionCodeType.CASE_CLOSED_BY_TMO);
        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        // IR Designation Termination
        MadridDesignationTerminationType madridDesignationTerminationType = getMadridDesignationTermination();
        intlIrTranDto.setIntlRecordId(madridDesignationTerminationType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irRenunciationService
            .processInboundTransaction(intlIrTranDto, madridDesignationTerminationType);

        // verify Notification
        assertTrue(null != notificationTypes && notificationTypes.size() > 0);
        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType taskType : notifications) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.IR_RENUNCIATION);
            }
        }

        // Verify application status.
        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        assertTrue(application.getStatusCode().intValue() == TradeMarkStatusType.WITHDRAWN_OWNER.getValue().intValue());

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean valid = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.WITHDRAWN_BY_OWNER.getValue())) {
                valid = true;
                break;
            }
        }
        assertTrue(valid);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        valid = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION.getValue())) {
                valid = true;
                break;
            }
        }
        assertTrue(valid);
    }

    private OppositionCaseAction createOppositionAction(Application application, OppositionCase oppositionCase,
                                                        OppositionCaseActionCodeType actionCodeType) {
        OppositionCaseAction oppositionCaseAction1 = new OppositionCaseAction();
        oppositionCaseAction1.setFileNumber(application.getFileNumber());
        oppositionCaseAction1.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseAction1.setActionDate(new Date());
        oppositionCaseAction1.setOppCaseNumber(oppositionCase.getOppCaseNumber());
        oppositionCaseAction1.setOppositionCase(oppositionCase);
        if (actionCodeType == OppositionCaseActionCodeType.CLOSED_BY_TMO) {
            oppositionCaseAction1.setOppStageCode(301); // OppositionCaseStage.GENERAL_ACTIONS_OPPOSITIONS.getValue());
        } else {
            oppositionCaseAction1.setOppStageCode(1);
        }

        oppositionCaseAction1.setOppActionCode(actionCodeType.getValue());
        oppositionCaseAction1.setOppActionType(OppositionActionType.SYSTEM_GENERATED.getValue());
        oppositionCaseAction1.setAuthorityId(SectionAuthority.MADRID.name());

        return oppositionCaseAction1;
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {

        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.PENDING.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private void setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_TOTAL_CANCELLATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_TOTAL_CANCELLATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private static JAXBContext initMadridDesignationTerminationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationTerminationType.class,
                MadridDesignationTerminationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationTerminationContext instance", e);
        }
        return null;

    }
}
