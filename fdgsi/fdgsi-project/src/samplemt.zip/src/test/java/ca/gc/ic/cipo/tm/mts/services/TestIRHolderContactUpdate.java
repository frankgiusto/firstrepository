package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.rowset.serial.SerialBlob;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskXrefDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTask;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTaskXref;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTaskXrefId;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgSchmaVrsn;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.intl.model.IntlTaskStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskXrefDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IntrepidCommonService;
import wipo.AddressBookType;
import wipo.ApplicantType;
import wipo.ContactInformationDetailsType;
import wipo.HolderInfo;

/**
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRHolderContactUpdate {

    private static final Logger log = LoggerFactory.getLogger(TestIRHolderContactUpdate.class);

    @Spy
    private IntrepidCommonService intrepidService;

    @Autowired
    private IntlPkgDao pkgDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao pkgSchmaVrsnDao;

    @Autowired
    private IntlPkgTranTypeDao intlPkgTranTypeDao;

    @Autowired
    private IntlPkgTypeDao intlPkgTypeDao;

    @Autowired
    private IntlIrTaskDao intlIrTaskDao;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IntlIrTaskXrefDao intlIrTaskXrefDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ITaskService taskService;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        HolderInfo holderInfo = new HolderInfo();
        HolderInfo.ApplicantDetails applicantDetails = new HolderInfo.ApplicantDetails();
        ApplicantType applicantType = new ApplicantType();
        AddressBookType addressBook = new AddressBookType();
        ContactInformationDetailsType contactDetailsType = new ContactInformationDetailsType();
        contactDetailsType.setEmail("test@test.com");
        contactDetailsType.setPhone("613-999-9999");
        addressBook.setContactInformationDetails(contactDetailsType);
        applicantType.setApplicantAddressBook(addressBook);
        applicantDetails.getApplicant().add(applicantType);
        holderInfo.setApplicantDetails(applicantDetails);

        Mockito.doReturn(holderInfo).when(intrepidService).getHolderInfoFromWipo(Mockito.any(String.class));

        ReflectionTestUtils.setField(intrepidService, "internationalService", internationalService);
        ReflectionTestUtils.setField(intrepidService, "applicationDao", applicationDao);

    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testGetTransactionListForHolderDetails()
        throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTaskXrefId xrefId = createTaskAndTrans(true);

        List<IntlIrTaskXrefDto> results = internationalService.getTransactionListForHolderDetails();
        assertTrue(results != null);

        for (IntlIrTaskXrefDto xrefDto : results) {
            if (xrefDto.getIntlIrTaskDto().getTaskId().intValue() == xrefId.getTaskId().intValue()
                && xrefDto.getIrTranId().intValue() == xrefId.getIrTranId().intValue()) {
                return;
            }
        }
        fail();

    }

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testUpdateHolderContactDetails() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTaskXrefId xrefId = createTaskAndTrans(false);
        Application application = createApplication(xrefId.getIrTranId());
        intrepidService.updateHolderContactDetails(xrefId.getIrTranId(), xrefId.getTaskId());
        IntlIrTask task = intlIrTaskDao.getIrTaskById(xrefId.getTaskId());
        IntlTaskStatusType taskStatusType = task.getIntlTaskStatusType();
        assertTrue(taskStatusType.getTaskStatusCtgryId().intValue() == TaskStatusType.PROCESSED.toNumber().intValue());
        application = applicationDao.getApplication(application.getFileNumber(), application.getExtensionCounter());
        Set<InterestedParty> parties = application.getInterestedParties();
        assertFalse(parties.isEmpty());
        for (InterestedParty party : parties) {
            if (party.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {
                IPContact contact = party.getContact();
                assertTrue(contact.getEmailAddress().equals("test@test.com"));
                assertTrue(contact.getPhoneNumber().equals("613-999-9999"));
            }
        }

    }

    private IntlIrTaskXrefId createTaskAndTrans(boolean settingInternalXref)
        throws UnsupportedEncodingException, SQLException {
        IntlIrTaskXrefId xrefId = new IntlIrTaskXrefId();
        IntlIrTran intlIrTran = createTransaction("blob".getBytes());

        ConsoleTaskList consoleTaskList = new ConsoleTaskList();
        ConsoleTaskMeta consoleTaskMeta = new ConsoleTaskMeta();
        consoleTaskMeta.setUserTaskStatus(TaskStatusType.UNPROCESSED.getValue());
        consoleTaskMeta.setUserTaskType(UserTaskType.HOLDER_CONTACT_DETAILS_TASK.getValue());

        IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
        IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
        intlTaskAddtnlInfoTypeDto
            .setTaskAddtnlInfoCtgryId(BigDecimal.valueOf(TaskAddtnlInfoType.APPLICATION_ADDITIONAL_INFO.getValue()));
        intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
        intlTaskAddtnlInfoDto.setAddtnlInfo("additional info");
        consoleTaskMeta.getAdditionalInfos().add(intlTaskAddtnlInfoDto);

        consoleTaskMeta.setWipoReferenceNumber("WIPO-1");
        consoleTaskMeta.setExtensionCounter("0");
        consoleTaskMeta.setFileNumber(BigDecimal.valueOf(12345));
        consoleTaskMeta.setIrNumber("999999");
        consoleTaskMeta.setOfficeType("DO");
        consoleTaskMeta.getTransactionIds().add(intlIrTran.getIrTranId());

        consoleTaskList.getTaskListBag().add(consoleTaskMeta);

        List<ConsoleTaskResponse> response = taskService.createUserTask(consoleTaskList);

        assertTrue(response != null);
        assertTrue(response.size() == 1);

        xrefId.setIrTranId(intlIrTran.getIrTranId());
        xrefId.setTaskId(response.get(0).getConsoleTaskId());

        if (!settingInternalXref) {
            return xrefId;
        }
        // we have to do this work as Hibernate does not buil relationships since this is an uncommitted code
        List<IntlIrTaskXref> xRef_list = intlIrTaskXrefDao.getListByNativeQuery(
            "Select * from INTL_IR_TASK_XREF where IR_TRAN_ID=" + xrefId.getIrTranId().intValue());
        Set<IntlIrTaskXref> xRef_set = new HashSet<>();
        xRef_set.addAll(xRef_list);
        intlIrTran.setIntlIrTaskXrefs(xRef_set);
        if (!response.isEmpty()) {
            IntlIrTask intlIrTask = intlIrTaskDao.getIrTaskById(response.get(0).getConsoleTaskId());
            intlIrTask.setIntlIrTaskXrefs(xRef_set);
            intlIrTranDao.save(intlIrTran);
            intlIrTaskDao.save(intlIrTask);
        }
        return xrefId;
    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTran createTransaction(byte xml[]) throws SQLException, UnsupportedEncodingException {

        IntlPkgType intlPkgType = new IntlPkgType();
        intlPkgType.setPkgCtgryId(new BigDecimal(999));
        intlPkgType.setPackageCtgry("adtest");
        intlPkgType.setDestnName("adInbound");
        intlPkgTypeDao.save(intlPkgType);

        IntlPkgSchmaVrsn pkgSchmaVrsn = new IntlPkgSchmaVrsn();
        pkgSchmaVrsn.setIntlPkgType(intlPkgType);
        pkgSchmaVrsn.setSchmaFileName("adtest");
        pkgSchmaVrsn.setVldFromDt(new Timestamp(System.currentTimeMillis()));
        pkgSchmaVrsnDao.save(pkgSchmaVrsn);

        IntlStatusType intlStatusType = new IntlStatusType();
        intlStatusType.setStatusCtgryId(new BigDecimal(99999));
        intlStatusType.setStatusCtgry("adtest");
        intlStatusTypeDao.save(intlStatusType);

        IntlPkg intlPkg = new IntlPkg();

        // all 9 mandatory fields
        intlPkg.setIntlPkgType(intlPkgType);
        intlPkg.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlPkg.setIntlStatusType(intlStatusType);
        intlPkg.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlPkg.setIntlPblctnId("11/2017");
        intlPkg.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
        Blob xmlFileContent = new SerialBlob("adblob".getBytes());
        intlPkg.setXmlFileName("adtest.zip");
        intlPkg.setXmlFileContent(xmlFileContent);
        pkgDao.save(intlPkg);

        IntlPkgTranType intlPkgTranType = intlPkgTranTypeDao.getTranTypeById(BigDecimal
            .valueOf(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.getTransactionCategoryId().intValue()));

        // all 7 mandatory fields plus pkg_id field
        IntlIrTran intlIrTran = new IntlIrTran();
        intlIrTran.setIntlPkg(intlPkg);
        intlIrTran.setIntlPkgTranType(intlPkgTranType);
        intlIrTran.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlIrTran.setIntlStatusType(intlStatusType);
        intlIrTran.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlIrTran.setXmlContent(intlIrTranDao.createAsBlob(xml));

        // nullable fields
        Date intlRecordEfctvDt = new Date();
        intlRecordEfctvDt.getTime();

        intlIrTran.setIntlRegNo("999999");
        intlIrTran.setIntlRecordId("999999");
        intlIrTran.setIntlRecordEfctvDt(intlRecordEfctvDt);
        intlIrTran.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));

        intlIrTranDao.save(intlIrTran);
        return intlIrTran;

    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-base-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private Application createApplication(BigDecimal tranId)
        throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("999999");
        madridDesignation.getRecordIdentifier().setValue("999999");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(tranId);

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        return application;
    }

}
