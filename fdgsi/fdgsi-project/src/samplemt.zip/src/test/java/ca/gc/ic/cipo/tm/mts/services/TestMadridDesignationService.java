package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ApplicationTextDao;
import ca.gc.ic.cipo.tm.dao.CountryProvinceLookupDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.enumerator.ApplicationTextType;
import ca.gc.ic.cipo.tm.enumerator.ClaimType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmt;
import ca.gc.ic.cipo.tm.intl.model.IntlAtchmtType;
import ca.gc.ic.cipo.tm.intl.model.IntlFileFrmtType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ApplicationText;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.Mail;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlAtchmtDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.LanguageIndicator;
import ca.gc.ic.cipo.tm.mts.enums.OriginalIndicator;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author
 */
/**
 * @author TanH
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridDesignationService extends MadridTransactionTestBase {

    private static final Logger log = LoggerFactory.getLogger(TestMadridDesignationService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MailDao mailDao;

    @Autowired
    private CountryProvinceLookupDao countryProvinceLookupDao;

    @Autowired
    private ApplicationTextDao applicationTextDao;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    // private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    /*
     * private MadridDesignationType getMadridDesignationType(String xmlFileName) throws JAXBException,
     * FileNotFoundException {
     *
     * Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller(); File xml =
     * ResourceUtils.getFile(this.getClass().getResource(xmlFileName));
     *
     * @SuppressWarnings("unchecked") JAXBElement<MadridDesignationType> madridDesignationElement =
     * (JAXBElement<MadridDesignationType>) unmarshallerRoot .unmarshal(xml);
     *
     * return madridDesignationElement.getValue(); }
     */
    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestCountryLookup() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-D5.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);

        // verify interested parties - Only 1
        assertTrue(CollectionUtils.isNotEmpty(application.getInterestedParties())
            && application.getInterestedParties().size() == 1);

        // verify 2 address
        assertTrue(application.getInterestedParties().iterator().next().getContact().getInterestedPartiesAddresses()
            .size() == 2);

        checkCountryName(application);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestCreateSanityCheck() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-SanityCheck-D5.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Application application = applicationDao
            .getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        // verify action codes
        assertTrue(application.getActions().size() > 0);

        // Goods and Services
        assertTrue(application.getGoodsServices().size() > 0);

        // verify interested parties - Only 1
        assertTrue(application.getInterestedParties().size() > 0);

        // verify 2 address
        assertTrue(application.getInterestedParties().iterator().next().getContact().getInterestedPartiesAddresses()
            .size() == 2);

        // verify process action codes
        assertTrue(application.getProcessActions().size() > 0);

        // Fig Elements.
        assertTrue(application.getTrademarks().getFigurativeElements().size() > 0);

        // verify Application Text. should be 2
        assertTrue(application.getApplicationTexts().size() > 0);

        assertTrue(application.getFilingFeeAmount() != null);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestReviewLimitationCommentsNotification()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-GoodsServicesLimitationComments.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Application application = applicationDao
            .getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        assertTrue(application.getLimitationListCode().intValue() == 1);

        assertTrue(newApplication.containsValue(UserTaskType.DESIGNATION_LIMITATION));

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestLimitationWithGSClassDesc()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-GoodsServicesLimitationClassDesc.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Application application = applicationDao
            .getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        assertTrue(application.getClaims().size() > 0);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestCreateAttachmentCheck()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-SanityCheck-D5.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        List<IntlAtchmtDto> intlAtchmtDtoList = createAttachment(intlIrTranDto);
        if (!intlAtchmtDtoList.isEmpty()) {
            intlIrTranDto.setIntlAtchmtDtoList(intlAtchmtDtoList);
        }

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Application application = applicationDao
            .getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        // verify action codes
        assertTrue(application.getActions().size() > 0);

        // Goods and Services
        assertTrue(application.getGoodsServices().size() > 0);

        // verify interested parties - Only 1
        assertTrue(application.getInterestedParties().size() > 0);

        // verify 2 address
        assertTrue(application.getInterestedParties().iterator().next().getContact().getInterestedPartiesAddresses()
            .size() == 2);

        // verify process action codes
        assertTrue(application.getProcessActions().size() > 0);

        // verify additionalInfo for attachment
        Set<ProcessAction> processes = application.getProcessActions();
        for (ProcessAction pa : processes) {
            if (pa.getAdditionalInfo() != null) {
                assertTrue(pa.getAdditionalInfo() != null);
                break;
            }
        }

        // Fig Elements.
        assertTrue(application.getTrademarks().getFigurativeElements().size() > 0);

        // verify Application Text. should be 2
        assertTrue(application.getApplicationTexts().size() > 0);

    }

    /**
     * @throws JAXBException
     * @throws SQLException
     * @throws CIPOServiceFault
     * @throws FileNotFoundException
     */
    @Test
    @Rollback(true)
    @Transactional
    public void TestCreateMadridDesignation()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-DEMO.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        Timestamp stamp = new Timestamp(System.currentTimeMillis());
        intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        // intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);

        // verify new data
        verifyNewData(application);

        // verify action codes
        assertTrue(application.getActions().size() > 0);
        for (Action action : application.getActions()) {
            if (action.getActionCode() == ActionCode.CREATED.getValue()
                || action.getActionCode() == ActionCode.APPLICATION_FILED.getValue()
                || action.getActionCode() == ActionCode.INTERNATIONAL_REGISTRATION.getValue()
                || action.getActionCode() == ActionCode.FORMALIZED.getValue()
                || action.getActionCode() == ActionCode.MADRID_DESIGNATION_NOTIFICATION.getValue()
                || action.getActionCode() == ActionCode.IR_RENEWED.getValue()
                || action.getActionCode() == ActionCode.FILING_FEE_PAYMENT_DATE.getValue()) {
                continue;
            } else {
                fail("Unexpected Action code found");
            }
        }

        // Goods and Services

        assertTrue(application.getGoodsServices().size() == 4);
        for (GoodService goodService : application.getGoodsServices()) { // 36
            if (goodService.getNiceClassCode().intValue() == 36 || goodService.getNiceClassCode().intValue() == 39) {
                continue;
            } else {
                fail("Unexpected nice class code found");
            }
        }

        // Claims
        assertTrue(application.getClaims().size() == 1);
        Claim claim = application.getClaims().iterator().next();
        assertTrue(claim.getClaimCountry().equals("IL"));
        assertTrue(claim.getClaimDate().equals("20161116"));
        assertTrue(claim.getClaimNumber().intValue() == 1);
        assertTrue(claim.getForeignRegistrationNumber().equals("289546"));

        assertTrue(claim.getGoodServiceClaims().size() == 2);
        for (GoodServiceClaim goodServiceClaim : claim.getGoodServiceClaims()) {
            assertTrue(goodServiceClaim.getClaimNumber().intValue() == 1);
            assertTrue(goodServiceClaim.getClaimType() == ClaimType.PRIORITY_FILING.getValue().intValue());
            assertTrue(goodServiceClaim.getNumber().intValue() == 3 || goodServiceClaim.getNumber().intValue() == 4);
            assertTrue(goodServiceClaim.getType().intValue() == GoodServiceType.SERVICES.getValue().intValue());
        }

        // verify interested parties - Only 1
        assertTrue(CollectionUtils.isNotEmpty(application.getInterestedParties())
            && application.getInterestedParties().size() == 1);

        // verify 2 address
        assertTrue(application.getInterestedParties().iterator().next().getContact().getInterestedPartiesAddresses()
            .size() == 2);

        checkCountryName(application);

        /*
         * Iterator<InterestedParty> iterator = application.getInterestedParties().iterator(); while
         * (iterator.hasNext()) {
         *
         * InterestedParty interestedParty = iterator.next(); Set<InterestedPartiesAddresses> addressSet =
         * interestedParty.getContact().getInterestedPartiesAddresses(); for (InterestedPartiesAddresses
         * interestedPartiesAddress : addressSet) { if (interestedPartiesAddress.getAddressType() ==
         * AddressType.MAILING.getValue()) { assertTrue(interestedPartiesAddress.getAddress().equals(
         * "Cato Networks Ltd.; Norris, Michele L.\r\nAkihabara UDX,\r\n14-1, Sotokanda 4-chome,\r\nChiyoda-ku\r\nTokyo 101-0021\r\nJP"
         * )); } else if (interestedPartiesAddress.getAddressType() == AddressType.PRIMARY.getValue()) {
         * assertTrue(interestedPartiesAddress.getAddress() .equals(
         * "Akihabara UDX,\r\n14-1, Sotokanda 4-chome,\r\nChiyoda-ku\r\nTokyo 101-0021\r\nJP")); } } }
         */

        // verify 2 names concatenated in contact name.
        assertTrue(application.getInterestedParties().iterator().next().getContact().getName()
            .equals("Cato Networks Ltd.; Norris, Michele L."));

        // verify process action codes
        assertTrue(application.getProcessActions().size() > 0);

        for (ProcessAction processAction : application.getProcessActions()) {
            if (processAction.getProcessCode() == ProcessActionsType.FILE_COVER_LABEL.getValue()
                || processAction.getProcessCode() == ProcessActionsType.ACKNOWLEDGEMENT_NOTICE.getValue()
                || processAction.getProcessCode() == ProcessActionsType.CLIENT_PROOF_SHEET.getValue()
                || processAction.getProcessCode() == ProcessActionsType.RESEARCH_SHEET.getValue()
                || processAction.getProcessCode() == ProcessActionsType.EDIT_SHEETS.getValue()
                || processAction.getProcessCode() == ProcessActionsType.PRINT_NOTIFICATION_OF_DESIGNATION.getValue()
                || processAction.getProcessCode() == ProcessActionsType.EXTRACT_APP_FOR_INDEX_HEADING.getValue()) {
                continue;
            } else {
                fail("Unexpected Process Action code found");
            }
        }

        // verify Trademark Text
        assertTrue(application.getTrademarks().getText() != null);
        // .contains("Aucune description verbale fournie/ No verbal description provided"));

        // should be 6 Fig Elements.
        assertTrue(application.getTrademarks().getFigurativeElements().size() > 0);// == 6);

        // verify Application Text. should be 2
        // int size = application.getApplicationTexts().size();
        assertTrue(application.getApplicationTexts().size() == 7);

        for (ApplicationText text : application.getApplicationTexts()) {// 35, 31, 30, 42, 41
            log.debug(text.getText() + ", type: " + text.getTextType());

            assertTrue(text.getTextType() == ApplicationTextType.DESCRIPTION_OF_MARK.getValue()
                || text.getTextType() == ApplicationTextType.DISCLAIMER.getValue()
                || text.getTextType() == ApplicationTextType.FOREIGN_CHARACTER_TRANSLITERATION.getValue()
                || text.getTextType() == ApplicationTextType.FOREIGN_CHARACTER_TRANSLATION.getValue()
                || text.getTextType() == ApplicationTextType.COLOUR_CLAIM.getValue());
        }

        List<Mail> mail = mailDao.getMailByFileId(fileNumber);
        assertTrue(mail.size() > 0);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testQABugTMMADCON915() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-TMMADCON-915.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);
        Map<Integer, Integer> goodsMap = new HashMap<>();
        Map<Integer, Integer> servicesMap = new HashMap<>();

        assertTrue(application.getGoodsServices().size() == 6);
        for (GoodService goodService : application.getGoodsServices()) {
            if (goodService.getType().intValue() == 1) {
                goodsMap.put(goodService.getNumber(), goodService.getType());
            } else {
                servicesMap.put(goodService.getNumber(), goodService.getType());
            }
        }
        assertTrue(goodsMap.containsKey(new Integer(1)));
        assertTrue(goodsMap.containsKey(new Integer(2)));
        assertTrue(servicesMap.containsKey(new Integer(1)));
        assertTrue(servicesMap.containsKey(new Integer(2)));
        assertTrue(servicesMap.containsKey(new Integer(3)));
        assertTrue(servicesMap.containsKey(new Integer(4)));
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testQABugTMMADCON883() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-TMMADCON-883.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);

        // verify action codes
        assertTrue(application.getActions().size() > 0);
        for (Action action : application.getActions()) {
            if (action.getActionCode() == ActionCode.CREATED.getValue()
                || action.getActionCode() == ActionCode.APPLICATION_FILED.getValue()
                || action.getActionCode() == ActionCode.INTERNATIONAL_REGISTRATION.getValue()
                || action.getActionCode() == ActionCode.FORMALIZED.getValue()
                || action.getActionCode() == ActionCode.MADRID_DESIGNATION_NOTIFICATION.getValue()
                || action.getActionCode() == ActionCode.IR_RENEWED.getValue()
                || action.getActionCode() == ActionCode.FILING_FEE_PAYMENT_DATE.getValue()) {

                if (action.getActionCode() == ActionCode.APPLICATION_FILED.getValue()) {
                    assertTrue(action.getAdditionalInfo().trim().equals("Registration"));
                }

                continue;
            } else {
                fail("Unexpected Action code found");
            }
        }
    }

    @Test
    // @Ignore
    @Rollback(true)
    @Transactional
    public void testQABugTMMADCON1131() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-TMMADCON-1131.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(newApplication != null);

        ApplicationNumber appnum = new ApplicationNumber();
        appnum.setFileNumber(fileNumber);
        appnum.setExtensionCounter(application.getExtensionCounter());
        List<ApplicationText> textList = applicationTextDao.getApplicationText(appnum);
        assertTrue(textList.size() > 0);

        String testText = "tmk:MarkTransliteration For IR7719004";
        for (ApplicationText text : textList) {
            if (null != text && text.getText().equals(testText)) {
                assertTrue(text.getLanguage() == LanguageIndicator.APP_FRENCH_APP_TEXT_FRENCH.getLanguage());
                assertTrue(text.getOriginalInd() == OriginalIndicator.APP_FRENCH_APP_TEXT_FRENCH.getOrininalInd());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testGoodsServicesLimitationBagOnlyCD() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-GoodsServicesLimitation.xml"); // only G&S

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(newApplication != null);

        assertTrue(application.getGoodsServices().size() > 0);

        assertTrue(application.getLimitationListCode().intValue() == 1);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testGoodsServicesLimitationBagBoth() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-GoodsServicesLimitationClassDesc.xml"); // both CommentText and G&S

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(newApplication != null);

        assertTrue(application.getGoodsServices().size() > 0);

        Collection<UserTaskType> values = newApplication.values();
        Iterator<UserTaskType> iterator = values.iterator();
        int cnt = 0;
        while (iterator.hasNext()) {
            UserTaskType statusType = iterator.next();
            if (statusType == UserTaskType.DESIGNATION_LIMITATION) {
                cnt++;
            }
        }
        assertTrue(cnt == 1);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testGoodsServicesLimitationBagOnlyComment()
        throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-GoodsServicesLimitationComments.xml"); // only CommentText

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(newApplication != null);

        assertTrue(application.getGoodsServices().size() > 0);

        Collection<UserTaskType> values = newApplication.values();
        Iterator<UserTaskType> iterator = values.iterator();
        int cnt = 0;
        while (iterator.hasNext()) {
            UserTaskType statusType = iterator.next();
            if (statusType == UserTaskType.DESIGNATION_LIMITATION) {
                cnt++;
            }
        }
        assertTrue(cnt == 1);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void testApplicationCountryCode() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-D5.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);

        assertTrue(application.getCountryOfOrigin() != null);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testApplicationTradeMarkType() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType("MadridDesignation-base-D5.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(newApplication != null);

        assertTrue(application.getTradeMarkType().intValue() == 2 || application.getTradeMarkType().intValue() == 12);
        System.out.println("Application trade mark type: " + application.getTradeMarkType().intValue());

        System.out.println("Application trade mark FigurativeElements size: "
            + application.getTrademarks().getFigurativeElements().size());
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testCorrespondenceAddress() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-CorrespondenceAddress.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        assertTrue(newApplication != null);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        verifyInterestPartyAddress(application);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void testMDRepresentativeAddress() throws FileNotFoundException, JAXBException, MTSServiceFault {
        MadridDesignationType madridDesignation = getMadridDesignationType(
            "MadridDesignation-Representative-CourtesyLetter.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(newApplication != null);

        boolean isCourtesyLetter = false;
        for (Map.Entry<ApplicationDto, UserTaskType> entry : newApplication.entrySet()) {
            if (entry.getKey().getAddress() != null) {
                System.out.println("Address: " + entry.getKey().getAddress());
            }
            if (entry.getValue().equals(UserTaskType.UPDATE_ADDRESS_CREATE_COURTESYLATTER)
                || entry.getValue().equals(UserTaskType.REPRESENTATIVE_COURTESY_LETTER)) {
                isCourtesyLetter = true;
            }
        }

        Set<InterestedParty> parties = application.getInterestedParties();
        int arNum = 0;
        for (InterestedParty p : parties) {
            if (p.getAgentNumber() != null) {
                arNum = p.getAgentNumber();
                System.out.println("Agent number: " + arNum);
            }
        }

        if (arNum > 0) { // no courtesy letter
            assertTrue(arNum > 0);
        } else { // courtesy letter required
            assertTrue(isCourtesyLetter);
        }
    }

    private void verifyNewData(Application application) {
        assertTrue(application.getDisclaimerCode() == 6);
        assertTrue(application.getCountryOfOrigin() != null);
        Set<InterestedParty> parties = application.getInterestedParties();
        for (InterestedParty party : parties) {
            assertTrue(party.getReference() != null);
        }
    }

    private void checkCountryName(Application application) {
        Iterator<InterestedParty> iterator = application.getInterestedParties().iterator();
        while (iterator.hasNext()) {

            InterestedParty interestedParty = iterator.next();
            Set<InterestedPartiesAddresses> addressSet = interestedParty.getContact().getInterestedPartiesAddresses();
            for (InterestedPartiesAddresses interestedPartiesAddress : addressSet) {
                if (interestedPartiesAddress.getAddressType() == AddressType.MAILING.getValue()) {
                    assertTrue(interestedPartiesAddress.getAddress().equals(
                        "Cato Networks Ltd.; Norris, Michele L.\r\nAkihabara UDX,\r\n14-1, Sotokanda 4-chome,\r\nChiyoda-ku\r\nTokyo 101-0021\r\nJAPAN"));
                } else if (interestedPartiesAddress.getAddressType() == AddressType.PRIMARY.getValue()) {
                    assertTrue(interestedPartiesAddress.getAddress()
                        .equals("Akihabara UDX,\r\n14-1, Sotokanda 4-chome,\r\nChiyoda-ku\r\nTokyo 101-0021"));
                }
            }
        }
    }

    /**
     * To create IntlAtchmtDto list
     *
     * @param intlIrTranDto
     * @return List<IntlAtchmtDto>
     * @throws SerialException
     * @throws SQLException
     */
    private List<IntlAtchmtDto> createAttachment(IntlIrTranDto intlIrTranDto) throws SerialException, SQLException {
        List<IntlAtchmtDto> intlAtchmtDtoList = new ArrayList<IntlAtchmtDto>();

        IntlAtchmtType atchType = new IntlAtchmtType();
        atchType.setAtchmtCtgryId(new Long(1));

        IntlFileFrmtType fileFrmtType = new IntlFileFrmtType();
        fileFrmtType.setFileFrmtId(new Long(2));

        Blob fileContent = new SerialBlob("blob".getBytes());

        IntlAtchmt intlAtchmt = new IntlAtchmt();

        intlAtchmt.setIntlAtchmtType(atchType);
        intlAtchmt.setIntlFileFrmtType(fileFrmtType);
        intlAtchmt.setFileName("IndustrialDesign-DataFlow-V15.pdf");
        intlAtchmt.setFileContent(fileContent);
        intlAtchmt.setIntlFileFrmtType(new IntlFileFrmtType(1, "pdf"));
        intlAtchmt.setIntlAtchmtType(new IntlAtchmtType(3, "doc"));
        // intlAtchmt.setIntlIrTran(intlIrTranDto.getIrTranId().);

        IntlAtchmtDto attachmentDao = createIntlAtchmtDto(intlAtchmt);
        // attachmentDao.save(intlAtchmt);
        intlAtchmtDtoList.add(attachmentDao);

        return intlAtchmtDtoList;
    }

    /**
     * To create IntlAtchmtDto
     *
     * @param intlAtchmt
     * @return IntlAtchmtDto
     */
    private IntlAtchmtDto createIntlAtchmtDto(IntlAtchmt intlAtchmt) {
        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto
            .setAtchmtCtgryId(BigDecimal.valueOf(intlAtchmt.getIntlAtchmtType().getAtchmtCtgryId().longValue()));
        intlAtchmtDto.setAtchmtId(intlAtchmt.getAtchmtId());
        intlAtchmtDto.setFileName(intlAtchmt.getFileName());
        // intlAtchmtDto.setIrTranId(intlAtchmt.getIntlIrTran().getIrTranId());
        intlAtchmtDto.setFileFrmtCtgry(intlAtchmt.getIntlFileFrmtType().getFileFrmtCtgry());
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(intlAtchmt.getIntlFileFrmtType().getFileFrmtId()));

        return intlAtchmtDto;
    }

    // TODO this is now a separate MWE task to MTS...
    // @Test
    // @Rollback(true)
    // @Transactional(readOnly = false)
    // public void TestExceptionCreateMadridDesignation() throws JAXBException, SQLException, FileNotFoundException {
    //
    // MadridDesignationType madridDesignation = getMadridDesignationType();
    //
    // IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
    // IntlPkgDto intlPkgDto = new IntlPkgDto();
    // intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
    // intlIrTranDto.setIntlPkg(intlPkgDto);
    // intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
    //
    // try {
    //
    // // Create first application
    // Integer applicationNumber = intrepidService.processMadridDesignation(madridDesignation, intlIrTranDto,
    // LanguageType.ENGLISH);
    // assertTrue(applicationNumber != null);
    //
    // // Attempt to create second application with same international transaction. Should throw a
    // // CIPOServiceFault.
    // applicationNumber = intrepidService.processMadridDesignation(madridDesignation, intlIrTranDto,
    // LanguageType.ENGLISH);
    // fail("A duplicate designation error should have been thrown");
    // } catch (CIPOServiceFault e) {
    // assertTrue(e.getFaultInfo().getReasonCode() == ExceptionReasonCode.DUPLICATE_DESIGNATION.getReasonCode());
    // }
    //
    // }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

}
