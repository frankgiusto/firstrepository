package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.orm.hibernate4.HibernateOptimisticLockingFailureException;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.orm.hibernate4.SessionHolder;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesTextDao;
import ca.gc.ic.cipo.tm.enumerator.ClaimType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.GoodServiceComparator;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationList;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType;
import ca.gc.ic.cipo.tm.mts.LocalizedTextType;
import ca.gc.ic.cipo.tm.mts.OrderedTextType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReasonCode;
import ca.gc.ic.cipo.tm.mts.enums.ExceptionReturnCode;
import ca.gc.ic.cipo.tm.mts.enums.LanguageIndicator;
import ca.gc.ic.cipo.tm.mts.enums.OriginalIndicator;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;

/**
 * The Class tests the processing of Goods and Services of a Limitation, initiated by manual tasks on the Madrid
 * Console.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMergeGoodsServices extends GoodsServicesTestBase {

    @Mock
    private IInternationalService internationalServiceMock;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private Application application = null;

    @Mock
    private IIntrepidCommonService intrepidCommonServiceMock;

    @Mock
    private IOutboundTransactionService outboundTransactionServiceMock;

    @Autowired
    private GoodsServicesDao goodsServicesDao;

    @Autowired
    private GoodsServicesClaimDao goodsServicesClaimDao;

    @Autowired
    private ClaimDao claimDao;

    @Autowired
    private GoodsServicesTextDao goodsServicesTextDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Before
    @Ignore
    @Transactional
    @Rollback(true)
    public void setUp() throws Exception {

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-G&S-Sequence.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("135528800", "1355288");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        // application = applicationDao.getApplication(1958971, 0);
        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional
    public void testCreateApplication() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException,
        HibernateOptimisticLockingFailureException {

        Application testApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        printGS(testApplication);
        assertTrue(testApplication != null);
        applicationDao.saveApplication(testApplication);

        System.out.println("File number: " + testApplication.getFileNumber());
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional
    public void testGSUpdateRemoveAdd() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException,
        HibernateOptimisticLockingFailureException {

        Application testApplication = applicationDao.getApplication(application.getFileNumber(), 0);

        printGS(testApplication);
        assertTrue(testApplication != null);
        applicationDao.saveApplication(testApplication);
        // transactionManager.getSessionFactory().getCurrentSession().flush();

        // get testing data
        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta();
        List<GoodsServicesClassificationType> consoleGoodsServicesList = goodsAndServiceMeta.getMergedGoodServices()
            .getTaskListBag();

        // update
        Application update = applicationDao.getApplication(testApplication.getFileNumber(), 0);
        updateExistingStatements(update, LanguageType.ENGLISH, consoleGoodsServicesList, true);
        printGS(update);
        // transactionManager.getSessionFactory().getCurrentSession().flush();

        applicationDao.saveApplication(update);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        // delete
        Application dalete = applicationDao.getApplication(update.getFileNumber(), 0);
        removeExistingStatements(dalete, consoleGoodsServicesList);
        printGS(dalete);
        // transactionManager.getSessionFactory().getCurrentSession().flush();
        applicationDao.saveApplication(dalete);
        System.out.println("remaining GSs after deletion: " + dalete.getGoodsServices().size());
        transactionManager.getSessionFactory().getCurrentSession().flush();

        // update claim
        Application updateClaim = applicationDao.getApplication(dalete.getFileNumber(), 0);
        updateClaims(updateClaim);
        printGS(updateClaim);
        applicationDao.saveApplication(updateClaim);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        // add new
        Application add = applicationDao.getApplication(updateClaim.getFileNumber(), 0);
        addNewStatements(add, LanguageType.ENGLISH, consoleGoodsServicesList);
        printGS(add);
        applicationDao.saveApplication(add);
        // transactionManager.getSessionFactory().getCurrentSession().flush();

        System.out.println("the end");
        Application after_add = applicationDao.getApplication(add.getFileNumber(), 0);
        printGS(after_add);

        System.out.println("File number: " + testApplication.getFileNumber());
        // working around solution
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(after_add);
    }

    private void updateExistingStatements(Application application, LanguageType applicationLanguage,
                                          List<GoodsServicesClassificationType> consoleGoodsServicesList,
                                          boolean adjustment) {

        Set<GoodService> gsList = new TreeSet<>(new GoodServiceComparator());
        gsList.addAll(application.getGoodsServices());

        for (GoodService goodService : gsList) {

            for (GoodsServicesClassificationType goodsServicesClassificationType : consoleGoodsServicesList) {
                if (goodService.getNumber().intValue() == goodsServicesClassificationType.getWsNumber()
                    && goodService.getType().intValue() == goodsServicesClassificationType.getWsType()) {

                    // Update GS
                    updateGoodsServiceText(application, goodService, goodsServicesClassificationType, adjustment);
                }
            }
        }
    }

    private void removeExistingStatements(Application application,
                                          List<GoodsServicesClassificationType> consoleGoodsServicesList) {

        List<GoodService> removeStatementList = new ArrayList<GoodService>();

        Set<GoodService> gsList = new TreeSet<>(new GoodServiceComparator());
        gsList.addAll(application.getGoodsServices());

        // List<GoodsServicesClaimsType> removeStatementList = new ArrayList<>();
        // determine which statements need to be removed
        for (GoodService gs : gsList) {
            boolean wipoCipoMatch = false;
            for (GoodsServicesClassificationType goodsServicesClassificationType : consoleGoodsServicesList) {
                if (gs.getNumber().intValue() == goodsServicesClassificationType.getWsNumber()
                    && gs.getType().intValue() == goodsServicesClassificationType.getWsType()) {

                    wipoCipoMatch = true;
                }
            }
            if (!wipoCipoMatch) { // WIPO withheld a statement that exists in Intrepid so we remove statement from
                                  // Intrepid
                removeStatementList.add(gs);
            }
        }
        Collections.sort(removeStatementList, new GoodServiceNumberComparator());
        Collections.reverse(removeStatementList);

        for (GoodService deleteGS : removeStatementList) {
            // checked if statement to be removed is associated to a claim and remove reference if it does.
            removeStatement(application, deleteGS.getNumber(), deleteGS.getType());
        }
    }

    private void removeStatement(Application application, Integer wsNumber, Integer wsType) {

        Set<GoodService> goodsServicesSet = application.getGoodsServices();
        List<GoodService> deletedGoodsServices = new ArrayList<>();

        for (GoodService goodsService : goodsServicesSet) {

            if (goodsService.getNumber().intValue() == wsNumber.intValue()
                && goodsService.getType().intValue() == wsType.intValue()) {

                deletedGoodsServices.add(goodsService);
            }
        }
        for (GoodService deletedStatement : deletedGoodsServices) {
            // for testGSUpdateRemoveAdd
            removeRelationshipFromClaim(application, deletedStatement);
            application.getGoodsServices().remove(deletedStatement);
            deleteAndResequency(deletedStatement);

            // for testGSUpdateRemoveAddResequency
            // removeText(application, deletedStatement);
            // application.getGoodsServices().remove(deletedStatement);
            // goodsServicesDao.deleteGoodsServices(deletedStatement);

        }
    }

    private void removeRelationshipFromClaim(Application application, GoodService deletedStatement) {
        // Look for claims in remaining statements. if not found, remove it.
        Set<Claim> claimsList = application.getClaims();
        for (Claim existingClaim : claimsList) {
            System.out.println("size before remove: " + existingClaim.getGoodServiceClaims().size());
            List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application,
                deletedStatement);

            if (CollectionUtils.isNotEmpty(results)) {
                for (GoodServiceClaim cl : results) {
                    if (cl.getClaim().getClaimNumber().intValue() == existingClaim.getClaimNumber().intValue()
                        && cl.getClaim().getClaimType().intValue() == existingClaim.getClaimType().intValue()) {
                        existingClaim.getGoodServiceClaims().remove(cl);
                    }
                }
            }
            System.out.println("size after remove: " + existingClaim.getGoodServiceClaims().size());
        }
    }

    private void deleteAndResequency(GoodService deletedStatement) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(
            SessionFactoryUtils.getDataSource(transactionManager.getSessionFactory()));

        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("CFDELETE_WS")
                .withoutProcedureColumnMetaDataAccess().declareParameters(new SqlParameter("NFILE_NBR", Types.NUMERIC))
                .declareParameters(new SqlParameter("NEXTN_CNTR", Types.NUMERIC))
                .declareParameters(new SqlParameter("NWS_TYP", Types.NUMERIC))
                .declareParameters(new SqlParameter("NWS_NBR", Types.NUMERIC))
                .declareParameters(new SqlOutParameter("NERR_NBR", Types.NUMERIC));

            Map<String, Object> input = new HashMap<String, Object>();
            input.put("NFILE_NBR", deletedStatement.getFileNumber());
            input.put("NEXTN_CNTR", deletedStatement.getExtensionCounter());
            input.put("NWS_TYP", deletedStatement.getType());
            input.put("NWS_NBR", deletedStatement.getNumber());

            System.out.println(deletedStatement.getFileNumber() + ", " + deletedStatement.getType() + ", "
                + deletedStatement.getNumber());

            Map<String, Object> out = jdbcCall.execute(input);
            Object output = (out.get("NERR_NBR"));

            if (output != null) {
                System.out.println("Success!");
            } else {
                System.out.println("Fail!");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            // logger.error("Unable to get tm file number in the database", ex);
            // throw new DataAccessException("Unable to to get tm file number in the database", ex);
        }
        // commitTransactionAndContinue(deletedStatement);
    }

    private void addNewStatements(Application application, LanguageType applicationLanguage,
                                  List<GoodsServicesClassificationType> consoleGoodsServicesList)
        throws MTSServiceFault {

        // TIRS getClaimsByGoodsService sorts by WS Type and Ws Number, so looking at last entry for each will give
        // me the next ws number used.
        Set<GoodService> gsList = new TreeSet<>(new GoodServiceComparator());
        gsList.addAll(application.getGoodsServices());

        Integer goodsSequence = getNextWsNumber(gsList, GoodServiceType.GOODS);
        Integer serviceSequence = getNextWsNumber(gsList, GoodServiceType.SERVICES);

        for (GoodsServicesClassificationType goodsServicesClassificationType : consoleGoodsServicesList) {

            Set<GoodServiceText> goodsServicesText = new HashSet<>();

            if (goodsServicesClassificationType.getWsNumber() == 0
                && goodsServicesClassificationType.getWsType() == 0) {

                GoodServiceType statementType = goodsOrService(goodsServicesClassificationType.getClassNumber());
                GoodService goodsService = buildGoodService(application, goodsServicesClassificationType,
                    goodsOrService(goodsServicesClassificationType.getClassNumber()));

                if (statementType == GoodServiceType.GOODS) {
                    goodsService.setNumber(goodsSequence);
                    goodsSequence++;

                } else {
                    goodsService.setNumber(serviceSequence);
                    serviceSequence++;
                }

                // Goods Service Text
                buildGSText(setOrderedText(goodsServicesClassificationType.getClassTitleText()), goodsServicesText,
                    goodsService, application, applicationLanguage);
                goodsService.setGoodServiceTexts(goodsServicesText);

                goodsServicesDao.saveGoodsServices(goodsService);
                for (GoodServiceText goodServiceText : goodsServicesText) {
                    goodsServicesTextDao.saveGoodServiceText(goodServiceText);
                }

                application.getGoodsServices().add(goodsService);
            }
        }
    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional
    public void testGSUpdateRemoveAddResequency() throws FileNotFoundException, JAXBException, CIPOServiceFault,
        SQLException, HibernateOptimisticLockingFailureException {
        try {
            Application testApplication = applicationDao.getApplication(application.getFileNumber(), 0);

            printGS(testApplication);
            assertTrue(testApplication != null);
            applicationDao.saveApplication(testApplication);

            // get testing data
            GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta();
            List<GoodsServicesClassificationType> consoleGoodsServicesList = goodsAndServiceMeta.getMergedGoodServices()
                .getTaskListBag();

            // update
            Application update = applicationDao.getApplication(testApplication.getFileNumber(), 0);
            updateExistingStatements(update, LanguageType.ENGLISH, consoleGoodsServicesList, true);
            printGS(update);
            applicationDao.saveApplication(update);

            // delete
            Application delete = applicationDao.getApplication(update.getFileNumber(), 0);
            removeExistingStatements(delete, consoleGoodsServicesList);
            printGS(delete);
            applicationDao.saveApplication(delete);

            // update claim
            Application updateClaim = applicationDao.getApplication(delete.getFileNumber(), 0);
            updateClaims(updateClaim);
            printGS(updateClaim);
            applicationDao.saveApplication(updateClaim);

            // add new
            Application add = applicationDao.getApplication(updateClaim.getFileNumber(), 0);
            addNewStatements(add, LanguageType.ENGLISH, consoleGoodsServicesList);
            printGS(add);
            applicationDao.saveApplication(add);

            System.out.println("the end");
            Application after_add = applicationDao.getApplication(add.getFileNumber(), 0);
            printGS(after_add);

            // Application newApplication1 = applicationDao.getApplication(after_add.getFileNumber(), 0);
            refrequency(after_add, testApplication);
            applicationDao.saveApplication(testApplication);

            Application after_req = applicationDao.getApplication(testApplication.getFileNumber(), 0);
            System.out.println("File number: " + testApplication.getFileNumber());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void refrequency(Application app1, Application originalApp) {
        // get remaining
        Set<GoodService> updatedGSSet = app1.getGoodsServices();
        ArrayList<GoodService> gsList = new ArrayList<GoodService>();
        gsList.addAll(updatedGSSet);
        // 1. clone GSs
        ArrayList<GoodService> cloneList = (ArrayList<GoodService>) gsList.clone();
        Collections.sort(cloneList, new GoodServiceNumberComparator());

        Set<Claim> claimSet = app1.getClaims();
        ArrayList<Claim> claimList = new ArrayList<Claim>();
        claimList.addAll(claimSet);

        HashMap<Integer, List<GoodServiceClaim>> keepedGSClaims = new HashMap<Integer, List<GoodServiceClaim>>();
        for (int i = 0; i < gsList.size(); i++) {
            GoodService deletedStatement = gsList.get(i);

            // get GS claims first
            List<GoodServiceClaim> gsClaims = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(originalApp,
                deletedStatement);
            if (gsClaims.size() > 0) {
                keepedGSClaims.put(deletedStatement.getNumber(), gsClaims);
            }

            removeText(app1, deletedStatement);
            app1.getGoodsServices().remove(deletedStatement);
            goodsServicesDao.deleteGoodsServices(deletedStatement);
        }
        // remove claim
        if (app1.getClaims().size() > 0) {
            for (Claim claim : app1.getClaims()) {
                claimDao.deleteClaim(claim);
            }
        }
        transactionManager.getSessionFactory().getCurrentSession().flush();
        applicationDao.saveApplication(app1);

        // refrequency
        Claim claim = buildClaim(originalApp);
        claimDao.saveClaim(claim);

        Set<GoodServiceText> goodsServicesText = new HashSet<>();
        Integer seqNum = 1;
        for (GoodService gs : cloneList) {
            if (gs.getNumber() != seqNum) {
                GoodService goodService = this.reCreateGS(gs, seqNum);
                GoodServiceText goodServiceText = this.buildGoodServiceText(originalApp, gs, seqNum);
                goodsServicesText.add(goodServiceText);
                goodService.setGoodServiceTexts(goodsServicesText);
                goodsServicesDao.saveGoodsServices(goodService);
                originalApp.getGoodsServices().add(goodService);
                goodsServicesTextDao.saveGoodServiceText(goodServiceText);

                // claim
                // if (appClone.getClaims().size() > 0) {
                // for (Claim existingClaim : appClone.getClaims()) {
                // for (GoodServiceClaim gsClaim : existingClaim.getGoodServiceClaims()) {
                // if (gsClaim.getType() == gs.getNumber() && gsClaim.getType() == gs.getNumber()) {
                // gsClaim.setNumber(seqNum);
                // goodsServicesClaimDao.saveGoodServiceClaim(gsClaim);
                // claim.getGoodServiceClaims().add(gsClaim);
                // claimDao.saveClaim(claim);
                // }
                // }
                // }
                // }

            }
            seqNum++;
        }

    }

    private GoodService reCreateGS(GoodService gs, Integer seqNum) {
        GoodService goodService = new GoodService();
        goodService.setType(gs.getType());
        goodService.setNumber(seqNum);
        goodService.setApplication(gs.getApplication());
        goodService.setFileNumber(gs.getFileNumber());
        goodService.setExtensionCounter(gs.getExtensionCounter());
        goodService.setNiceClassCode(gs.getNiceClassCode());
        goodService.setNiceEdition(gs.getNiceEdition());
        goodService.setGiCategoryType(gs.getGiCategoryType());

        return goodService;
    }

    private GoodServiceText buildGoodServiceText(Application application, GoodService goodService, Integer seqNum) {
        GoodServiceText goodServiceText = new GoodServiceText();
        goodServiceText.setFileNumber(application.getFileNumber());
        goodServiceText.setExtensionCounter(application.getExtensionCounter());
        goodServiceText.setNumber(seqNum);
        goodServiceText.setType(goodService.getType());
        goodServiceText.setOriginalInd(1);
        goodServiceText.setModifiedTimestamp(new Date());
        goodServiceText.setLanguage(1);

        for (GoodServiceText text : goodService.getGoodServiceTexts()) {
            goodServiceText.setText(text.getText());
        }

        if (goodServiceText.getText() == null) {
            goodServiceText.setText("Why?");
        }
        return goodServiceText;
    }

    /*********************************** HELPER **********************************************/
    protected void buildGSText(List<_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType> list,
                               Set<GoodServiceText> goodsServicesText, GoodService goodsService,
                               Application application, LanguageType applicationLanguage) {

        StringBuilder gsDescriptionTextEnglish = new StringBuilder();
        StringBuilder gsDescriptionTextFrench = new StringBuilder();

        for (_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType localizedTextType : list) {

            if (null != localizedTextType.getLanguageCode()) {
                if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.EN.value())) {
                    gsDescriptionTextEnglish.append(localizedTextType.getValue());
                } else if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.FR.value())) {
                    gsDescriptionTextFrench.append(localizedTextType.getValue());
                }
            } else {
                gsDescriptionTextEnglish.append(localizedTextType.getValue());
            }

        }

        if (gsDescriptionTextEnglish.length() > 0) {
            goodsServicesText.add(createGoodServiceText(application, goodsService, gsDescriptionTextEnglish.toString(),
                ISOLanguageCodeType.EN, applicationLanguage));
        }

        if (gsDescriptionTextFrench.length() > 0) {
            goodsServicesText.add(createGoodServiceText(application, goodsService, gsDescriptionTextFrench.toString(),
                ISOLanguageCodeType.FR, applicationLanguage));
        }
    }

    protected GoodServiceText createGoodServiceText(Application application, GoodService goodsService, String gsText,
                                                    ISOLanguageCodeType textLanguage,
                                                    LanguageType applicationLanguage) {

        GoodServiceText goodServiceText = new GoodServiceText();

        goodServiceText.setFileNumber(application.getFileNumber());
        goodServiceText.setExtensionCounter(application.getExtensionCounter());
        goodServiceText.setNumber(goodsService.getNumber());
        goodServiceText.setType(goodsService.getType());
        goodServiceText.setOriginalInd(getGSOriginalIndicator(textLanguage, applicationLanguage));
        goodServiceText.setModifiedTimestamp(new Date());
        goodServiceText.setLanguage(getGSLanguageIndicator(textLanguage, applicationLanguage));

        goodServiceText.setText(gsText);

        return goodServiceText;
    }

    protected GoodServiceType goodsOrService(String classNumberString) throws MTSServiceFault {

        Integer classNumber = null;
        try {
            classNumber = Integer.valueOf(classNumberString);
            if (classNumber == 0) {
                throwMTSServiceFault("mts.invalid.gs.class.number", ExceptionReasonCode.INVALID_CLASS_NUMBER);
            }
        } catch (Exception e) {

            throwMTSServiceFault("mts.invalid.gs.class.number", ExceptionReasonCode.INVALID_CLASS_NUMBER);

        }
        if (classNumber > 0 && classNumber < 35) {
            return GoodServiceType.GOODS;
        }

        return GoodServiceType.SERVICES;
    }

    private Integer getNextWsNumber(Set<GoodService> goodsServices, GoodServiceType statementType) {

        Set<Integer> wsNumbers = new HashSet<Integer>();
        for (GoodService gs : goodsServices) {
            if (gs.getType().intValue() == statementType.getValue().intValue()) {
                wsNumbers.add(gs.getNumber());
            }
        }
        if (wsNumbers.size() > 0) {
            int maxNum = Collections.max(wsNumbers);
            return maxNum + 1;
        }

        return wsNumbers.size() + 1;

        // return wsNumbers.size() + 1;
    }

    private GoodService buildGoodService(Application application,
                                         GoodsServicesClassificationType goodsServicesClassificationType,
                                         GoodServiceType goodsOrServiceType)
        throws MTSServiceFault {
        GoodService goodService = new GoodService();
        goodService.setType(goodsOrServiceType.getValue());
        goodService.setApplication(application);
        goodService.setFileNumber(application.getFileNumber());
        goodService.setExtensionCounter(application.getExtensionCounter());
        goodService.setNiceClassCode(Integer.valueOf(goodsServicesClassificationType.getClassNumber()));

        return goodService;
    }

    private List<_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType> setOrderedText(List<OrderedTextType> classTitleText) {
        // Goods Service Text
        List<_int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType> mtsOrderedTextList = new ArrayList<>();

        for (OrderedTextType mtsOrderedTextType : classTitleText) {
            _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType commonOrderedTextType = new _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType();
            commonOrderedTextType.setLanguageCode(mtsOrderedTextType.getLanguageCode());
            commonOrderedTextType.setSequenceNumber(mtsOrderedTextType.getSequenceNumber());
            commonOrderedTextType.setValue(mtsOrderedTextType.getValue());

            mtsOrderedTextList.add(commonOrderedTextType);
        }
        return mtsOrderedTextList;
    }

    protected void throwMTSServiceFault(String errorKey, ExceptionReasonCode exceptionReasonCode)
        throws MTSServiceFault {

        ExceptionReturnCode exceptionReturnCode = null;
        if (ExceptionReasonCode.SYSTEM_ERROR == exceptionReasonCode) {
            exceptionReturnCode = ExceptionReturnCode.FATAL;
        } else {
            exceptionReturnCode = ExceptionReturnCode.RECOVERABLE;
        }
        // throw new MTSServiceFault("System Error",
        // setServiceDetails(errorKey, exceptionReasonCode, exceptionReturnCode));
    }

    private Claim buildClaim(Application application) {
        Claim claim = new Claim();
        claim.setApplication(application);
        claim.setClaimType(ClaimType.DECLARATION_OF_USE.getValue());
        claim.setClaimNumber(999);
        claim.setFileNumber(claim.getApplication().getFileNumber());
        claim.setExtensionCounter(claim.getApplication().getExtensionCounter());
        claim.setLanguage(1);
        return claim;
    }

    private Integer getGSOriginalIndicator(ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        if (applicationLanguage == LanguageType.ENGLISH) {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return OriginalIndicator.APP_ENGLISH_GOODS_SERVICES_ENGLISH.getOrininalInd();
            } else {
                return OriginalIndicator.APP_ENGLISH_GOODS_SERVICES_FRENCH.getOrininalInd();
            }
        } else {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return OriginalIndicator.APP_FRENCH_GOODS_SERVICES_ENGLISH.getOrininalInd();
            } else {
                return OriginalIndicator.APP_FRENCH_GOODS_SERVICES_FRENCH.getOrininalInd();
            }
        }
    }

    protected Integer getGSLanguageIndicator(ISOLanguageCodeType textLanguage, LanguageType applicationLanguage) {

        if (applicationLanguage == LanguageType.ENGLISH) {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return LanguageIndicator.APP_ENGLISH_GOODS_SERVICES_ENGLISH.getLanguage();
            } else {
                return LanguageIndicator.APP_ENGLISH_GOODS_SERVICES_FRENCH.getLanguage();
            }
        } else {
            if (textLanguage == ISOLanguageCodeType.EN) {
                return LanguageIndicator.APP_FRENCH_GOODS_SERVICES_ENGLISH.getLanguage();
            } else {
                return LanguageIndicator.APP_FRENCH_GOODS_SERVICES_FRENCH.getLanguage();
            }
        }
    }

    private void updateClaims(Application application) {

        // After updates above, check statements to see if there are any claims associated to it. If not, remove the
        // claim itself.
        Set<Claim> claimsList = application.getClaims();
        boolean used = false;
        for (Claim existingClaim : claimsList) {
            Set<GoodServiceClaim> results = existingClaim.getGoodServiceClaims();
            if (CollectionUtils.isNotEmpty(results)) {
                for (GoodServiceClaim cl : results) {
                    if (cl.getClaim().getClaimNumber().intValue() == existingClaim.getClaimNumber().intValue()
                        && cl.getClaim().getClaimType().intValue() == existingClaim.getClaimType().intValue()) {
                        used = true;
                        break;
                    }
                }
                if (!used) {
                    application.getClaims().remove(existingClaim);
                    claimDao.deleteClaim(existingClaim);
                }
            }
        }
        // Look for claims in remaining statements. if not found, remove it.
        // boolean used = false;
        // for (Claim existingClaim : claimsList) {
        // for (GoodService goodService : application.getGoodsServices()) {
        // List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application,
        // goodService);
        //
        // if (CollectionUtils.isNotEmpty(results)) {
        // for (GoodServiceClaim cl : results) {
        // if (cl.getClaim().getClaimNumber().intValue() == existingClaim.getClaimNumber().intValue()
        // && cl.getClaim().getClaimType().intValue() == existingClaim.getClaimType().intValue()) {
        // used = true;
        // break;
        // }
        // }
        // }
        // }
        // if (!used) {
        // application.getClaims().remove(existingClaim);
        // claimDao.deleteClaim(existingClaim);
        // }
        // }
    }

    protected LanguageType getApplicationLanguage(ISOLanguageCodeType transactionLanguage) {
        if (transactionLanguage == ISOLanguageCodeType.EN || transactionLanguage == ISOLanguageCodeType.ES) {
            return LanguageType.ENGLISH;
        } else {
            return LanguageType.FRENCH;
        }
    }

    @Override
    protected ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType setMergedList(String classNumber, Integer wsNumber,
                                                                                 Integer wsType, String text,
                                                                                 String language) {
        ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType goodsServicesClassificationType = new ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassNumber(classNumber);
        goodsServicesClassificationType.setWsNumber(wsNumber);
        goodsServicesClassificationType.setWsType(wsType);
        OrderedTextType orderedTextType = new OrderedTextType();
        orderedTextType.setLanguageCode(language);
        orderedTextType.setValue(text);
        goodsServicesClassificationType.getClassTitleText().add(orderedTextType);
        return goodsServicesClassificationType;
    }

    private void updateGoodsServiceText(Application application, GoodService goodsService,
                                        GoodsServicesClassificationType goodsServicesClassificationType,
                                        boolean adjustment) {

        List<OrderedTextType> clasTextList = goodsServicesClassificationType.getClassTitleText();

        StringBuilder gsDescriptionTextEnglish = new StringBuilder();
        StringBuilder gsDescriptionTextFrench = new StringBuilder();

        for (LocalizedTextType localizedTextType : clasTextList) {
            if (null != localizedTextType.getLanguageCode()) {
                if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.EN.value())) {
                    gsDescriptionTextEnglish.append(localizedTextType.getValue());

                } else if (localizedTextType.getLanguageCode().equals(ISOLanguageCodeType.FR.value())) {
                    gsDescriptionTextFrench.append(localizedTextType.getValue());

                }
            } else {
                gsDescriptionTextEnglish.append(localizedTextType.getValue());
            }
        }

        List<GoodServiceText> removeStatementTextList = new ArrayList<>();

        if (gsDescriptionTextEnglish.length() > 0) {
            for (GoodServiceText gsText : goodsService.getGoodServiceTexts()) {
                if (gsText.getNumber().intValue() == goodsService.getNumber().intValue()
                    && gsText.getType().intValue() == goodsService.getType().intValue() && gsText.getLanguage() == 1) { // English

                    gsText.setModifiedTimestamp(new Date());
                    gsText.setText(gsDescriptionTextEnglish.toString());
                    goodsServicesTextDao.saveGoodServiceText(gsText);
                }
            }
        } else {
            // This is for ADJUSTMENTS. Only update the language received and delete the other language text.
            if (adjustment) {
                for (GoodServiceText goodServiceText : goodsService.getGoodServiceTexts()) {
                    if (goodServiceText.getNumber().intValue() == goodsService.getNumber().intValue()
                        && goodServiceText.getType().intValue() == goodsService.getType().intValue()
                        && goodServiceText.getLanguage() == 1) { // English

                        goodsServicesTextDao.deleteGoodServiceText(goodServiceText);
                        removeStatementTextList.add(goodServiceText);
                    }
                }
                for (GoodServiceText goodServiceText : removeStatementTextList) {
                    goodsService.getGoodServiceTexts().remove(goodServiceText);
                }
            }
        }

        removeStatementTextList = new ArrayList<>();

        if (gsDescriptionTextFrench.length() > 0) {
            for (GoodServiceText gsText : goodsService.getGoodServiceTexts()) {
                if (gsText.getNumber().intValue() == goodsService.getNumber().intValue()
                    && gsText.getType().intValue() == goodsService.getType().intValue()
                    && gsText.getLanguage().intValue() == 2) {

                    gsText.setModifiedTimestamp(new Date());
                    gsText.setText(gsDescriptionTextFrench.toString());
                    goodsServicesTextDao.saveGoodServiceText(gsText);
                }
            }
        } else {
            // This is for ADJUSTMENTS. Only update the language received and delete the other language text.
            if (adjustment) {
                for (GoodServiceText goodServiceText : goodsService.getGoodServiceTexts()) {
                    if (goodServiceText.getNumber().intValue() == goodsService.getNumber().intValue()
                        && goodServiceText.getType().intValue() == goodsService.getType().intValue()
                        && goodServiceText.getLanguage().intValue() == 2) {

                        goodsServicesTextDao.deleteGoodServiceText(goodServiceText);
                        removeStatementTextList.add(goodServiceText);
                    }
                }
                for (GoodServiceText goodServiceText : removeStatementTextList) {
                    goodsService.getGoodServiceTexts().remove(goodServiceText);
                }
            }
        }
        goodsServicesDao.saveGoodsServices(goodsService);
    }

    private GoodsAndServiceMeta getGoodsAndServiceMeta() {
        GoodsAndServiceMeta goodsAndServiceMeta = new GoodsAndServiceMeta();
        goodsAndServiceMeta.setNotificationLanguage("en");
        goodsAndServiceMeta.setFileNumber(BigDecimal.valueOf(1883909));
        goodsAndServiceMeta.setExtensioncounter("0");
        goodsAndServiceMeta.setInternationalRegistrationNumber("1349230");// 1349230

        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(0));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);
        goodsAndServiceMeta.setAuthorityId(SectionAuthority.MADRID.name());

        GoodsServicesClassificationList goodsServicesClassificationList = new GoodsServicesClassificationList();

        // test 9
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("11", 0, 0, "class number desc 11 - new en", "en"));

        // goodsServicesClassificationList.getTaskListBag()
        // .add(setMergedList("20", 0, 0, "class number desc 20 - new en", "en"));
        /*
         * goodsServicesClassificationList.getTaskListBag() .add(setMergedList("36", 1, 2,
         * "Services d'administration fiduciaire de fonds, titres, crÃ©ances monÃ©taires, biens personnels, terrains, droits fonciers."
         * , "fr"));
         */
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 2, 2, "class number desc 39 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("40", 3, 2, "class number desc 40 en", "en"));
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("36", 4, 2, "computer network services", "en")); // GSClaim
        goodsServicesClassificationList.getTaskListBag()
            .add(setMergedList("39", 5, 2,
                "computer network security services, namely, securing, restricting and protecting traffic to and by computer networks to and of undesired media, ...",
                "en"));// GSClaim

        goodsAndServiceMeta.setMergedGoodServices(goodsServicesClassificationList);

        return goodsAndServiceMeta;
    }

    public class GoodServiceNumberComparator implements Comparator<GoodService> {

        @Override
        public int compare(GoodService x, GoodService y) {
            // TODO: Handle null x or y values
            int startComparison = compare(x.getNumber().intValue(), y.getNumber().intValue());
            return startComparison != 0 ? startComparison : compare(x.getNumber().intValue(), y.getNumber().intValue());
        }

        private int compare(int a, int b) {
            return a < b ? -1 : a > b ? 1 : 0;
        }
    }

    private void removeText(Application application, GoodService goodsService) {

        List<GoodServiceText> removeStatementTextList = new ArrayList<>();

        for (GoodServiceText goodServiceText : goodsService.getGoodServiceTexts()) {

            goodsServicesTextDao.deleteGoodServiceText(goodServiceText);
            removeStatementTextList.add(goodServiceText);

        }
        for (GoodServiceText goodServiceText : removeStatementTextList) {
            goodsService.getGoodServiceTexts().remove(goodServiceText);
        }

    }

    public void commitTransactionAndContinue(GoodService deletedStatement) {
        SessionFactory sessionFactory = transactionManager.getSessionFactory();

        sessionFactory.getCurrentSession().getTransaction().commit();

        // Cannot reuse existing Hibernate transaction, so start a new one.
        Transaction newTransaction = sessionFactory.getCurrentSession().beginTransaction();

        // Now need to update Spring transaction infrastructure with new
        // Hibernate transaction.
        // The logic for this is based on SessionFactoryUtils.doGetSession
        SessionHolder sessionHolder = (SessionHolder) TransactionSynchronizationManager.getResource(sessionFactory);
        sessionHolder.setTransaction(newTransaction);

    }

    private void deleteWSClaim(GoodServiceClaim gsc) {

        try {
            // StringBuilder queryString = new StringBuilder();
            // queryString.append("DELETE FROM WS_CLAIMS");
            // queryString.append(" WHERE FILE_NUMBER = " + gsc.getFileNumber() + " AND ");
            // queryString.append(" EXTENSION_COUNTER = " + gsc.getExtensionCounter() + " AND");
            // queryString.append(" WS_TYPE = " + gsc.getType() + " AND");
            // queryString.append(" WS_NUMBER = " + gsc.getNumber() );

            transactionManager.getSessionFactory().getCurrentSession().delete(gsc);

            // List<BigDecimal> transactionList = query.list();

        } catch (Exception ex) {
            throw new DataAccessException("Error when deleting GoodServiceClaim", ex);
        }

    }

}
