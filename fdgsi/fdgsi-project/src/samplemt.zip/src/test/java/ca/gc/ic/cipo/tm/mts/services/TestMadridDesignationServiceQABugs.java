package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridBasicRegistrationApplicationChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTaskXrefDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlOfficeTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlTaskTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskAddtnlInfoType;
import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTask;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTaskXref;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskList;
import ca.gc.ic.cipo.tm.mts.dto.intl.ConsoleTaskMeta;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlAtchmtDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlTaskAddtnlInfoTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridDesignationServiceQABugs extends MadridTransactionTestBase {

    private static final Logger log = LoggerFactory.getLogger(TestMadridDesignationServiceQABugs.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    @Qualifier("irHolderNameAddressChange")
    private IInboundTransaction irHolderNameAddressChangeService;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private IntlIrTaskDao intlIrTaskDao;

    @Autowired
    private IntlIrTaskXrefDao intlIrTaskXrefDao;

    @Autowired
    private IntlOfficeTypeDao intlOfficeTypeDao;

    @Autowired
    private IntlTaskTypeDao intlTaskTypeDao;

    @Autowired
    private IntlTaskStatusTypeDao intlTaskStatusTypeDao;

    @Autowired
    @Qualifier("irNotification")
    private IInboundTransaction irNotificationService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridDesignationType getMadridTransaction(String xmlFileName) throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource(xmlFileName));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-base-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1249_Figurative() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        // test for <tmk:MarkFeatureCategory>Figurative</tmk:MarkFeatureCategory>
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1249.xml"));

        // test for <tmk:MarkFeatureCategory>Word</tmk:MarkFeatureCategory>
        // File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1249_Word.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1368() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1368.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1374() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1374.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1528() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1528.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1714() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1714.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1578() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1578.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_By_Filename(String filename)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource(filename));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getMadridTransaction_1752() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1752.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getIRMadridHolderRepresentativeChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-975.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridDesignationElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridBasicRegistrationApplicationChangeType getMadridRegistrationApplicationChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-940_MBRAC.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridBasicRegistrationApplicationChangeType> madridProtectionRestrictioElement = (JAXBElement<MadridBasicRegistrationApplicationChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepresentativeChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-940_MRC.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridRepresentativeChange = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridRepresentativeChange.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepChangeTransTMMADCON1701()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridHolderRepChange-TMMADCON-1701.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridRepresentativeChange = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridRepresentativeChange.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepresentativeChangeXml_1176()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-TMMADCON-1176.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridRepresentativeChange = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridRepresentativeChange.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug897() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-TMMADCON-897.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Integer fileNumber = newApplication.keySet().iterator().next().getFileNumber();
        Application application = applicationDao.getApplication(fileNumber, 0);

        assertTrue(application != null);

        // verify process action codes
        assertTrue(application.getProcessActions().size() > 0);

        for (ProcessAction processAction : application.getProcessActions()) {
            if (processAction.getProcessCode() == ProcessActionsType.FILE_COVER_LABEL.getValue()
                || processAction.getProcessCode() == ProcessActionsType.ACKNOWLEDGEMENT_NOTICE.getValue()
                || processAction.getProcessCode() == ProcessActionsType.CLIENT_PROOF_SHEET.getValue()
                || processAction.getProcessCode() == ProcessActionsType.RESEARCH_SHEET.getValue()
                || processAction.getProcessCode() == ProcessActionsType.EDIT_SHEETS.getValue()
                || processAction.getProcessCode() == ProcessActionsType.PRINT_NOTIFICATION_OF_DESIGNATION.getValue()
                || processAction.getProcessCode() == ProcessActionsType.EXTRACT_APP_FOR_INDEX_HEADING.getValue()) {
                continue;
            } else {
                fail("Unexpected Process Action code found");
            }
        }

        // verify action codes
        assertTrue(application.getActions().size() > 0);
        for (Action action : application.getActions()) {
            if (action.getActionCode() == ActionCode.CREATED.getValue()
                || action.getActionCode() == ActionCode.APPLICATION_FILED.getValue()
                || action.getActionCode() == ActionCode.INTERNATIONAL_REGISTRATION.getValue()
                || action.getActionCode() == ActionCode.FORMALIZED.getValue()
                || action.getActionCode() == ActionCode.MADRID_DESIGNATION_NOTIFICATION.getValue()
                || action.getActionCode() == ActionCode.IR_RENEWED.getValue()
                || action.getActionCode() == ActionCode.FILING_FEE_PAYMENT_DATE.getValue()) {
                continue;
            } else {
                fail("Unexpected Action code found");
            }
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug929() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-TMMADCON-929.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> notifications = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Collection<UserTaskType> notificationList = notifications.values();
        boolean found = false;
        for (UserTaskType userTaskType : notificationList) {
            if (userTaskType == UserTaskType.REVIEW_TRADEMARK) {
                found = true;
            }
        }
        assertTrue(found);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestDeclan() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction("/declan3.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> notifications = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        assertTrue(null != notifications);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestThomas() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction("/thomas.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        try {
            Map<ApplicationDto, UserTaskType> notifications = madridDesignationService
                .processInboundTransaction(intlIrTranDto, madridDesignation);

            assertTrue(null != notifications);

        } catch (Exception e) {
            log.error("Expected error");
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug1021() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-TMMADCON-1021.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        IntlAtchmtDto intlAtchmtDto = new IntlAtchmtDto();
        intlAtchmtDto.setAtchmtCtgryId(BigDecimal.valueOf(3));
        intlAtchmtDto.setAtchmtId(BigDecimal.valueOf(691612));
        intlAtchmtDto.setFileName("7101563.pdf");
        intlAtchmtDto.setIrTranId(BigDecimal.valueOf(691609));
        intlAtchmtDto.setFileFrmtId(BigDecimal.valueOf(2));
        intlIrTranDto.getIntlAtchmtDtoList().add(intlAtchmtDto);

        Map<ApplicationDto, UserTaskType> notifications = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        Collection<UserTaskType> notificationList = notifications.values();
        // boolean found = false;
        // for (UserTaskType userTaskType : notificationList) {
        // if (userTaskType == UserTaskType.REVIEW_TRADEMARK) {
        // found = true;
        // }
        // }
        assertTrue(1 == 1);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug975() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // IR MadridHolderRepresentativeChangeType
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChange = getIRMadridHolderRepresentativeChangeTransaction();
        intlIrTranDto.setIntlRecordId(madridHolderRepresentativeChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888880");

        setIntlIrTranDtoForMail(intlIrTranDto, madridHolderRepresentativeChange);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, madridHolderRepresentativeChange);

        assertTrue(null != notificationTypes && notificationTypes.size() > 0);

        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType status : notifications) {
            if (null != status) {
                assertTrue(status == UserTaskType.IR_HOLDER_NAME_ADDRESS_CHANGE_OCCURRED);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // verify interested parties and addresses
        verifyInterestPartyAddress(application);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug1070() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-TMMADCON-1070_1.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        assertTrue(null != newApplication && newApplication.size() > 0);

        Collection<UserTaskType> notifications = newApplication.values();
        for (UserTaskType utt : notifications) {
            // List<ConsoleTaskResponse> responses = TestSycTask(utt);
            // assertTrue(responses.size() > 0);

            // for (ConsoleTaskResponse re : responses) {
            // IntlIrTaskDto task = taskService.getIrTaskById(re.getConsoleTaskId());
            // IntlTaskTypeDto tt = task.getTaskTypeDto();
            // String taskCtgry = tt.getTaskCtgry();
            // String ex = UserTaskType.ADDRESS_EXCEEDED_LIMIT.name();
            // assertTrue(taskCtgry.equals(ex));
            // }
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug1094() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // CREATE an application with PriorityBag
        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-TMMADCON-1094.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> notifications = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        assertTrue(null != notifications && notifications.size() > 0);

        Collection<UserTaskType> notificationList = notifications.values();
        boolean isReviewGS = false;
        for (UserTaskType userTaskType : notificationList) {
            if (userTaskType == UserTaskType.REVIEW_GOOD_SERVICE) {
                isReviewGS = true;
            }
        }
        assertTrue(isReviewGS);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug940_MRC() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        // CREATE an application with PriorityBag
        MadridHolderRepresentativeChangeType applicationChange = getMadridHolderRepresentativeChangeTransaction();

        intlIrTranDto.setIntlRecordId(applicationChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto, applicationChange);

        // Add automated task record used by processing.
        intlIrTranDto.setIntlIrTaskList(getTaskList(application));

        irNotificationService.processInboundTransaction(intlIrTranDto, applicationChange);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean isMessage = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getAdditionalInfo() != null
                && action.getAdditionalInfo().equals("Madrid Holder Representative Change - "
                    + applicationChange.getMadridHolderRepresentativeChangeCategory().value())) { // MHR_CHANGE_OF_REPRESENTATIVE"))
                // {
                isMessage = true;
                break;
            }
        }
        assertTrue(isMessage);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug1701() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        // CREATE an application with PriorityBag
        MadridHolderRepresentativeChangeType applicationChange = getMadridHolderRepChangeTransTMMADCON1701();

        intlIrTranDto.setIntlRecordId(applicationChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto, applicationChange);

        // Add automated task record used by processing.
        intlIrTranDto.setIntlIrTaskList(getTaskList(application));

        Map<ApplicationDto, UserTaskType> notifications = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, applicationChange);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        Collection<UserTaskType> values = notifications.values();

        Iterator<UserTaskType> itt = values.iterator();

        boolean task1 = false, task2 = false;
        while (itt.hasNext()) {
            UserTaskType userTaskType = itt.next();
            if (userTaskType == UserTaskType.REVIEW_OWNER_NAME) {
                task1 = true;
            } else if (userTaskType == UserTaskType.ADDRESS_EXCEEDED_LIMIT) {
                task2 = true;
            }

        }
        assertTrue(task1);
        // assertTrue(task2);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug940_MBRAC() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        // CREATE an application with PriorityBag
        MadridBasicRegistrationApplicationChangeType applicationChange = getMadridRegistrationApplicationChangeTransaction();

        intlIrTranDto.setIntlRecordId(applicationChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto, applicationChange);

        // Add automated task record used by processing.
        intlIrTranDto.setIntlIrTaskList(getTaskList(application));
        irNotificationService.processInboundTransaction(intlIrTranDto, applicationChange);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        String message = "Madrid Basic Registration Application Change";
        Iterator<Action> itt = application.getActions().iterator();
        boolean isMessage = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getAdditionalInfo() != null && action.getAdditionalInfo().equals(message)) {
                isMessage = true;
                break;
            }
        }
        assertTrue(isMessage);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug1176() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        // CREATE an application with PriorityBag
        MadridHolderRepresentativeChangeType applicationChange = getMadridHolderRepresentativeChangeXml_1176();

        intlIrTranDto.setIntlRecordId(applicationChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto, applicationChange);

        // Add automated task record used by processing.
        intlIrTranDto.setIntlIrTaskList(getTaskList(application));

        Map<ApplicationDto, UserTaskType> notifications = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, applicationChange);

        if (notifications.size() > 0) {
            System.out.print("Notification generated.");
        } else {
            System.out.print("No notification generated.");
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1249() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1249_Figurative();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        if (application.getTradeMarkType().intValue() == TradeMarkType.DESIGN.getValue()) {
            assertTrue(application.getDesignSampleFiledInd().intValue() == 1);
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1368_1568() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1368();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean isIR = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode() == ActionCode.INTERNATIONAL_REGISTRATION.getValue()) {
                isIR = true;
                break;
            }
        }
        assertTrue(isIR);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1374() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1374();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        boolean isReviewMarkType = false;
        for (Map.Entry<ApplicationDto, UserTaskType> entry : newApplication.entrySet()) {
            UserTaskType value = entry.getValue();
            if (value == UserTaskType.REVIEW_MARK_TYPE) {
                isReviewMarkType = true;
                break;
            }
            System.out.println(entry.getKey() + " " + entry.getValue());
        }

        if (application.getTradeMarkType().intValue() == TradeMarkType.TRACER.getValue()
            || application.getTradeMarkType().intValue() == TradeMarkType.OTHER.getValue()) {

            assertTrue(isReviewMarkType);
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1528() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1528();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        Iterator<ProcessAction> itt = application.getProcessActions().iterator();
        boolean isSpanish = false;
        while (itt.hasNext()) {
            ProcessAction pa = itt.next();
            if (pa.getAdditionalInfo() == "Spanish") {
                isSpanish = true;
                break;
            }
        }
        if (madridDesignation.getNotificationLanguage() == ISOLanguageCodeType.ES) { // Spanish
            assertTrue(isSpanish);
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1751() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1528();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        String code = application.getCountryOfOrigin();
        assertTrue(code.equals("US"));
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1714() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1714();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        Integer type = application.getTradeMarkType();
        assertTrue(type.intValue() == 12);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1578() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1578();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        try {
            Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
                .processInboundTransaction(intlIrTranDto, madridDesignation);
        } catch (Exception e) {
            assertTrue(e instanceof MTSServiceFault);
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1877() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = this
            .getMadridTransaction_By_Filename("/MadridDesignation-TMMADCON-1877.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        try {
            Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
                .processInboundTransaction(intlIrTranDto, madridDesignation);
            fail();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(1 == 1);
        }

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional
    public void TestQaBug_1916() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = this
            .getMadridTransaction_By_Filename("/MadridDesignation-TMMADCON-1916.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        try {
            Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
                .processInboundTransaction(intlIrTranDto, madridDesignation);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_1752() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction_1752();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        /**
         * three scenario: 1. MarkVerbalElementText 2. MarkSignificantVerbalElementText 3. default text
         *
         */
        TradeMark tm = application.getTrademarks();
        assertTrue(tm.getText() != null);
        System.out.println("Trade Mark Text: " + tm.getText());
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestQaBug_2075() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-TMMADCON-2075.xml");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        for (Map.Entry<ApplicationDto, UserTaskType> entry : newApplication.entrySet()) {
            System.out.println("UserTaskType: " + entry.getValue());
        }

    }

    private List<ConsoleTaskResponse> TestSycTask(UserTaskType type) {
        ConsoleTaskList consoleTaskList = new ConsoleTaskList();
        ConsoleTaskMeta consoleTaskMeta = new ConsoleTaskMeta();

        consoleTaskMeta.setUserTaskStatus(TaskStatusType.UNPROCESSED.getValue());
        consoleTaskMeta.setUserTaskType(type.getValue());

        IntlTaskAddtnlInfoDto intlTaskAddtnlInfoDto = new IntlTaskAddtnlInfoDto();
        IntlTaskAddtnlInfoTypeDto intlTaskAddtnlInfoTypeDto = new IntlTaskAddtnlInfoTypeDto();
        intlTaskAddtnlInfoTypeDto
            .setTaskAddtnlInfoCtgryId(BigDecimal.valueOf(TaskAddtnlInfoType.APPLICATION_ADDITIONAL_INFO.getValue()));
        intlTaskAddtnlInfoDto.setIntlTaskAddtnlInfoTypeDto(intlTaskAddtnlInfoTypeDto);
        intlTaskAddtnlInfoDto.setAddtnlInfo("additional info");
        consoleTaskMeta.getAdditionalInfos().add(intlTaskAddtnlInfoDto);

        consoleTaskMeta.setWipoReferenceNumber("WIPO-1");
        consoleTaskMeta.setExtensionCounter("0");
        consoleTaskMeta.setFileNumber(BigDecimal.valueOf(12345));
        consoleTaskMeta.setIrNumber("888999888");
        consoleTaskMeta.setOfficeType("DO");
        consoleTaskMeta.getTransactionIds().add(BigDecimal.valueOf(2904));
        consoleTaskMeta.setAuthorityId(SectionAuthority.MADRID.name());

        consoleTaskList.getTaskListBag().add(consoleTaskMeta);

        List<ConsoleTaskResponse> response = createUserTask(consoleTaskList);

        return response;
    }

    private List<ConsoleTaskResponse> createUserTask(ConsoleTaskList consoleTaskList) {

        Timestamp timestamp = new Timestamp(new Date().getTime());
        List<ConsoleTaskResponse> consoleTaskBag = new ArrayList<>();

        for (ConsoleTaskMeta consoleTaskMeta : consoleTaskList.getTaskListBag()) {

            ConsoleTaskResponse consoleTaskResponse = new ConsoleTaskResponse();
            IntlIrTask intlIrTask = createIntlIrTask(consoleTaskMeta, timestamp);

            intlIrTaskDao.save(intlIrTask);

            consoleTaskResponse.setConsoleTaskId(intlIrTask.getTaskId());
            consoleTaskResponse.setConsoleTaskGroupId(consoleTaskMeta.getAuthorityId());
            consoleTaskBag.add(consoleTaskResponse);

            for (BigDecimal transactionId : consoleTaskMeta.getTransactionIds()) {
                IntlIrTaskXref intlIrTaskXref = createIntlIrTaskXref(intlIrTask, transactionId);

                intlIrTaskXrefDao.save(intlIrTaskXref);
            }
        }
        return consoleTaskBag;
    }

    private IntlIrTask createIntlIrTask(ConsoleTaskMeta consoleTaskMeta, Timestamp timestamp) {

        IntlIrTask intlIrTask = new IntlIrTask();
        intlIrTask.setActHiTaskInstId(consoleTaskMeta.getTaskReferenceId());
        intlIrTask.setDmstcApltnFileNbr((consoleTaskMeta.getFileNumber() == null ? null
            : Long.valueOf(consoleTaskMeta.getFileNumber().longValue())));

        intlIrTask.setIntlIrOfficeType(intlOfficeTypeDao.getOfficeTypeById(
            Long.valueOf((OfficeType.getOfficeTypeByName(consoleTaskMeta.getOfficeType())).getValue())));
        intlIrTask.setDmstcApltnFileExtn(String.valueOf(consoleTaskMeta.getExtensionCounter()));
        intlIrTask.setIntlRegNo(consoleTaskMeta.getIrNumber());
        intlIrTask.setWipoRefNbr(consoleTaskMeta.getWipoReferenceNumber());
        // intlIrTask.setAddtnlInfo(consoleTaskMeta.getAdditionalInfo());

        // Name of the User Task as seen on the console
        intlIrTask
            .setIntlTaskType(intlTaskTypeDao.getTaskTypeById(BigDecimal.valueOf(consoleTaskMeta.getUserTaskType())));

        // Status of the user task. Will be unprocessed or onHold.
        intlIrTask.setIntlTaskStatusType(
            intlTaskStatusTypeDao.getTaskStatusTypeById(BigDecimal.valueOf(consoleTaskMeta.getUserTaskStatus())));

        intlIrTask.setCreatedTmstmp(timestamp);
        intlIrTask.setUpdatedTmstmp(timestamp);

        return intlIrTask;
    }

    private IntlIrTaskXref createIntlIrTaskXref(IntlIrTask intlIrTask, BigDecimal intlIrTranId) {

        IntlIrTaskXref intlIrTaskXref = new IntlIrTaskXref();
        intlIrTaskXref.setIrTranId(intlIrTranId);
        intlIrTaskXref.setTaskId(intlIrTask.getTaskId());

        return intlIrTaskXref;
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private IntlIrTranDto setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto, Object objType) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        if (objType instanceof MadridHolderRepresentativeChangeType) {
            ptt.setTranCtgry(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.name());
            ptt.setPkgTranCtgryId(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.toNumber());
        } else if (objType instanceof MadridBasicRegistrationApplicationChangeType) {
            ptt.setTranCtgry(TransactionCategory.MBR_APPLICATION_CHANGE.name());
            ptt.setPkgTranCtgryId(TransactionCategory.MBR_APPLICATION_CHANGE.toNumber());
        }

        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        return intlIrTranDto;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;

    }

    private List<IntlIrTaskDto> getTaskList(Application application) {
        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        return activeTaskList;
    }

    protected LanguageType getApplicationLanguage(ISOLanguageCodeType transactionLanguage) {
        if (transactionLanguage == ISOLanguageCodeType.EN || transactionLanguage == ISOLanguageCodeType.ES) {
            return LanguageType.ENGLISH;
        } else {
            return LanguageType.FRENCH;
        }
    }

}
