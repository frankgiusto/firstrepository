package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionActionType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRTotalCancellationService {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRTotalCancellationService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irTotalCancellation")
    private IInboundTransaction irTotalCancellationService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private MadridApplicationDao madridApplicationsDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionsDao;

    @Autowired
    private MailDao mailDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbIRinitIRDesignationTerminationContext = initIRDesignationTerminationContext();

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationTerminationType getIRDesignationTerminationTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbIRinitIRDesignationTerminationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignationTermination-Total-Cancellation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationTerminationType> madridDesignationElement = (JAXBElement<MadridDesignationTerminationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestTotalCancellation() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        OppositionCase oppositionCase = createOppositionCase(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction = createOppositionAction(application, oppositionCase,
            OppositionCaseActionCodeType.CLOSED_BY_TMO);
        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        // IR Total-Cancellation
        MadridDesignationTerminationType irNonRenewalTransaction = getIRDesignationTerminationTransaction();
        intlIrTranDto.setIntlRecordId(irNonRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irTotalCancellationService
            .processInboundTransaction(intlIrTranDto, irNonRenewalTransaction); // TODO

        // irTotalCancellationService.processInboundTransaction(intlIrTranDto, irNonRenewalTransaction); // test mails
        // irTotalCancellationService.processInboundTransaction(intlIrTranDto, irNonRenewalTransaction); // test mails

        assertTrue(null != notificationTypes);

        // List<Mail> mails = mailDao.getMailByFileId(application.getFileNumber());
        // assertTrue(mails.size() > 0);
        // for (Mail mail : mails) {
        // System.out.println("mail timestamp: " + mail.getMailTimestamp());
        // }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getStatusCode().equals(TradeMarkStatusType.CANCELLED_BY_OWNER.getValue()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean expunged = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.CANCELLED_BY_OWNER.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        expunged = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_CANCELLED_BY_OWNER_NOTIFICATION.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Opposition Cases
        assertTrue(application.getOppositionCases().size() == 1);
        Iterator<OppositionCase> ocIterator = application.getOppositionCases().iterator();
        while (ocIterator.hasNext()) {
            OppositionCase oc = ocIterator.next();
            assertTrue(oc.getOppositionCaseActions().size() == 2);

            OppositionCaseAction ca = oc.getOppositionCaseActions().iterator().next();
            assertTrue(ca.getOppCaseNumber().equals(oc.getOppCaseNumber()));
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestPendingTotalCancellation()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());

        OppositionCase oppositionCase = createPendingOppositionCase(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction = createOppositionAction(application, oppositionCase,
            OppositionCaseActionCodeType.CASE_CLOSED_BY_TMO);
        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        // IR Non Renewal
        MadridDesignationTerminationType irNonRenewalTransaction = getIRDesignationTerminationTransaction();
        intlIrTranDto.setIntlRecordId(irNonRenewalTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irTotalCancellationService
            .processInboundTransaction(intlIrTranDto, irNonRenewalTransaction); // TODO

        assertTrue(null != notificationTypes);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getStatusCode().equals(TradeMarkStatusType.WITHDRAWN_OWNER.getValue()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean expunged = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.WITHDRAWN_BY_OWNER.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        expunged = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_WITHDRAWN_BY_OWNER_NOTIFICATION.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Opposition Cases
        assertTrue(application.getOppositionCases().size() == 1);
        Iterator<OppositionCase> ocIterator = application.getOppositionCases().iterator();
        while (ocIterator.hasNext()) {
            OppositionCase oc = ocIterator.next();
            assertTrue(oc.getOppositionCaseActions().size() == 2);

            OppositionCaseAction ca = oc.getOppositionCaseActions().iterator().next();
            assertTrue(ca.getOppCaseNumber().equals(oc.getOppCaseNumber()));
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestTotalCancellationOO() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // Create a test application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setWipoReferenceNumber("IA00003180625_02");
        madridApplication.setIrNumber("1328767");
        madridApplication.setStatusCode(1);

        madridApplicationsDao.saveMadridApplication(madridApplication);

        MadridDesignationTerminationType irNonRenewalTransaction = getIRDesignationTerminationTransaction();

        irTotalCancellationService.processInboundTransaction(null, irNonRenewalTransaction);

        List<MadridApplication> result = madridApplicationsDao
            .getMadridApplicationByIrNumber(irNonRenewalTransaction.getInternationalRegistrationNumber());

        assertTrue(CollectionUtils.isNotEmpty(result));

        for (MadridApplication madridApplications : result) {
            List<MadridApplicationAction> actions = madridApplicationActionsDao
                .getMadridApplicationActionByReferenceNumber(madridApplications.getWipoReferenceNumber());
            assertTrue(actions.size() > 0);
            assertTrue(actions.iterator().next().getActionCode() == MadridApplicationActionStatus.CLOSED.getValue());
        }

    }

    private OppositionCaseAction createOppositionAction(Application application, OppositionCase oppositionCase,
                                                        OppositionCaseActionCodeType actionCodeType) {
        OppositionCaseAction oppositionCaseAction1 = new OppositionCaseAction();
        oppositionCaseAction1.setFileNumber(application.getFileNumber());
        oppositionCaseAction1.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseAction1.setActionDate(new Date());
        oppositionCaseAction1.setOppCaseNumber(oppositionCase.getOppCaseNumber());
        oppositionCaseAction1.setOppositionCase(oppositionCase);
        if (actionCodeType == OppositionCaseActionCodeType.CLOSED_BY_TMO) {
            oppositionCaseAction1.setOppStageCode(301); // OppositionCaseStage.GENERAL_ACTIONS_OPPOSITIONS.getValue());
        } else {
            oppositionCaseAction1.setOppStageCode(1);
        }

        oppositionCaseAction1.setOppActionCode(actionCodeType.getValue());
        oppositionCaseAction1.setOppActionType(OppositionActionType.SYSTEM_GENERATED.getValue());
        oppositionCaseAction1.setAuthorityId(SectionAuthority.MADRID.name());

        return oppositionCaseAction1;
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {

        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.PENDING.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private void setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_TOTAL_CANCELLATION.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_TOTAL_CANCELLATION.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }
    }

    // private IntlIrTask createTask(String irNumber, IntlIrTranDto intlIrTranDto, Integer applicationNumber) {
    // Timestamp timestamp = new Timestamp(new Date().getTime());
    //
    // IntlIrTask intlIrTask = new IntlIrTask();
    // intlIrTask.setIntlStatusType(intlStatusTypeDao
    // .getStatusTypeById(BigDecimal.valueOf(StatusType.MANUAL_DO_PARTIAL_CANCELLATION.getValue())));
    // intlIrTask.setAuthorityId("giustof");
    // intlIrTask.setFileNumber(applicationNumber);
    // intlIrTask.setIrNumber(irNumber);
    // intlIrTask.setExtensionCounter(0);
    // intlIrTask.setIntlFilingRecordId("1");
    // intlIrTask.setCreatedTmstmp(timestamp);
    // intlIrTask.setUpdatedTmstmp(timestamp);
    // intlIrTask.setOfficeType("DO");
    //
    // intlIrTask.setTaskStatusType(
    // intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(StatusType.TASK_STATUS_UNPROCESSED.getValue())));
    //
    // intlTaskDao.saveOrUpdate(intlIrTask);
    //
    // IntlIrTaskXref intlIrTaskXref = new IntlIrTaskXref();
    // IntlIrTaskXrefId id = new IntlIrTaskXrefId();
    // id.setIrTranId(intlIrTranDto.getIrTranId());
    // id.setTaskId(intlIrTask.getTaskId());
    // intlIrTaskXref.setId(id);
    // // intlIrTaskXref.setIntlIrTask(intlIrTask);
    // // intlIrTaskXref.setIntlIrTran(transactionOne);
    // intlTaskXrefDao.saveOrUpdate(intlIrTaskXref);
    // // intlIrTask.getIntlIrTaskXrefs().add(intlIrTaskXref);
    //
    // return intlIrTask;
    // }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private static JAXBContext initIRDesignationTerminationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationTerminationType.class,
                MadridDesignationTerminationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBIRNonRenewalContext instance", e);
        }
        return null;

    }
}
