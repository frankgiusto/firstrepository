package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.TransactionPairDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IIROwnershipChangeMerger;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRChangeOwnershipMergerService {

    private static final Logger log = LoggerFactory.getLogger(TestIRChangeOwnershipMergerService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private IIROwnershipChangeMerger irChangeOwnershipMerger;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbMadridDesignationTermination = initMadridDesignationTerminationContext();

    private MadridDesignationType getCreateMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationType getUpdateMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Merger.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationTerminationType getMadridDesignationTermination()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationTermination.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignationTermination-Merger.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationTerminationType> madridDesignationTerminationElement = (JAXBElement<MadridDesignationTerminationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationTerminationElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestMadridMergerRegistered()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888A");

        IntlIrTranDto designationTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        designationTransaction.setIntlPkg(intlPkgDto);
        designationTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Create a Madrid Designation
        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(designationTransaction, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Get MD Merger Transaction
        MadridDesignationType updateMadridDesignation = getUpdateMadridTransaction();
        updateMadridDesignation.setInternationalRegistrationNumber("8888888");

        // Get Designation Termination Merger Transaction
        MadridDesignationTerminationType madridDesignationTermination = getMadridDesignationTermination();
        madridDesignationTermination.setInternationalRegistrationNumber("8888888A");

        List<IntlIrTranDto> internationalTransactions = new ArrayList<>();
        internationalTransactions.add(this.createTransDto(updateMadridDesignation.getRecordIdentifier().getValue(),
            updateMadridDesignation.getInternationalRegistrationNumber(), TransactionCategory.MD_MERGER));
        internationalTransactions.add(this.createTransDto(madridDesignationTermination.getRecordIdentifier().getValue(),
            madridDesignationTermination.getInternationalRegistrationNumber(), TransactionCategory.MDT_MERGER));

        // Setup Input to the service
        IntlIrTranDto pairedTransaction = new IntlIrTranDto();
        pairedTransaction.setIntlRegNo(madridDesignationTermination.getInternationalRegistrationNumber());
        designationTransaction.setIntlRegNo(updateMadridDesignation.getInternationalRegistrationNumber());

        TransactionPairDto ownershipChangeMerger = new TransactionPairDto();
        ownershipChangeMerger.setMadridDesignationTransaction(designationTransaction);
        ownershipChangeMerger.setPairedTransaction(pairedTransaction);
        ownershipChangeMerger.setPairedTransactionType(TransactionCategory.MDT_MERGER);
        ownershipChangeMerger.setAuthorityId("GIUSTOF1");

        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        ownershipChangeMerger.setIntlIrTaskList(activeTaskList);

        // Execute the service.
        Map<ApplicationDto, UserTaskType> notificationTypes = irChangeOwnershipMerger
            .processIRChangeOwnershipMerger(ownershipChangeMerger);

        Collection<UserTaskType> notification = notificationTypes.values();

        for (UserTaskType taskType : notification) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.OWNERSHIP_CHANGE_MERGER_OCCURRED);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        assertTrue(application.getIrNumber().equals(updateMadridDesignation.getInternationalRegistrationNumber()));
        assertTrue(CollectionUtils.isNotEmpty(application.getFootnotes()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean verified = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.OWNERSHIP_CHANGE_MERGER.getValue())) {
                verified = true;
                break;
            }
        }
        assertTrue(verified);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestMadridMergerPending() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888A");

        IntlIrTranDto designationTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        designationTransaction.setIntlPkg(intlPkgDto);
        designationTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(designationTransaction, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Create Opposition Case
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // Get MD Merger Transaction
        MadridDesignationType updateMadridDesignation = getUpdateMadridTransaction();
        updateMadridDesignation.setInternationalRegistrationNumber("8888888");

        // Get Designation Termination Merger Transaction
        MadridDesignationTerminationType madridDesignationTermination = getMadridDesignationTermination();
        madridDesignationTermination.setInternationalRegistrationNumber("8888888A");

        List<IntlIrTranDto> internationalTransactions = new ArrayList<>();
        internationalTransactions.add(this.createTransDto(updateMadridDesignation.getRecordIdentifier().getValue(),
            updateMadridDesignation.getInternationalRegistrationNumber(), TransactionCategory.MD_MERGER));
        internationalTransactions.add(this.createTransDto(madridDesignationTermination.getRecordIdentifier().getValue(),
            madridDesignationTermination.getInternationalRegistrationNumber(), TransactionCategory.MDT_MERGER));

        // set transaction pairs
        IntlIrTranDto pairedTransaction = new IntlIrTranDto();
        pairedTransaction.setIntlRegNo(madridDesignationTermination.getInternationalRegistrationNumber());
        designationTransaction.setIntlRegNo(updateMadridDesignation.getInternationalRegistrationNumber());

        TransactionPairDto ownershipChangeMerger = new TransactionPairDto();
        ownershipChangeMerger.setMadridDesignationTransaction(designationTransaction);
        ownershipChangeMerger.setPairedTransaction(pairedTransaction);
        ownershipChangeMerger.setPairedTransactionType(TransactionCategory.MDT_MERGER);
        ownershipChangeMerger.setAuthorityId("GIUSTOF1");

        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        ownershipChangeMerger.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irChangeOwnershipMerger
            .processIRChangeOwnershipMerger(ownershipChangeMerger);

        Collection<UserTaskType> notification = notificationTypes.values();

        for (UserTaskType taskType : notification) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.OWNERSHIP_CHANGE_MERGER_OCCURRED);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        assertTrue(application.getIrNumber().equals(updateMadridDesignation.getInternationalRegistrationNumber()));

        // no footnotes
        assertTrue(CollectionUtils.isEmpty(application.getFootnotes()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean verified = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.OWNERSHIP_CHANGE_MERGER.getValue())) {
                verified = true;
                break;
            }
        }
        assertTrue(verified);

    }

    private IntlIrTranDto createTransDto(String recordIdentifier, String irNumber, TransactionCategory transCategory) {
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setPkgId(new BigDecimal(1));
        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(recordIdentifier);
        intlIrTranDto.setIntlRegNo(irNumber);
        IntlPkgTranTypeDto intlPkgTranType = new IntlPkgTranTypeDto();
        intlPkgTranType.setPkgTranCtgryId(BigDecimal.valueOf(transCategory.getTransactionCategoryId()));
        intlIrTranDto.setIntlPkgTranType(intlPkgTranType);

        return intlIrTranDto;
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private static JAXBContext initIRDesignationTerminationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationTerminationType.class,
                MadridDesignationTerminationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBIRNonRenewalContext instance", e);
        }
        return null;

    }

    private static JAXBContext initMadridDesignationTerminationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationTerminationType.class,
                MadridDesignationTerminationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationTerminationContext instance", e);
        }
        return null;

    }
}
