package ca.gc.ic.cipo.tm.mts.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridAbandonmentNotificationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationStatus;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 *
 * @author Anisur Rahman
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridAbandonmentNotification extends ProcessActionTestBase {

    private static final Logger log = LoggerFactory.getLogger(TestMadridAbandonmentNotification.class);

    private static final JAXBContext jaxbMadridAbandonmentNotificationContext = initMadridAbandonmentNotificationContext();

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    @Qualifier("abandonmentNotification")
    private IInboundTransaction madridAbandonmentNotificationService;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionDao;

    private Application application = null;

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("1234"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-Process-Action-Base.xml");
        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355299000", "1355299");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestProcessAbandonmentNotification() throws CIPOServiceFault, FileNotFoundException, JAXBException {
        MadridAbandonmentNotificationType abandonmentNotificationTransacton = getMadridAbandonmentNotificationTransaction();
        String wipoReferenceNumber = abandonmentNotificationTransacton.getOfficeReferenceIdentifier().getValue();

        Date actionDate = null;
        String actionDateStr = abandonmentNotificationTransacton.getMailDate();
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            actionDate = dateFormat.parse(actionDateStr);
        } catch (ParseException e) {
            log.error("Could not parse mail Date from AbandonmentNotificationTransaction : " + actionDateStr, e);
        }

        Integer testProcessCode = ProcessActionsType.MERGER_BASIC_APPLICATION.getValue();
        String info = "Testing AbandonmentNotification";

        // verify setup is correct to begin with
        Assert.assertTrue(application != null);

        ProcessAction processAction = createProcessAction(application, testProcessCode, wipoReferenceNumber, null,
            info);
        MadridApplication madridApplication = createMadridApplication(application, application.getIrNumber() + "x",
            wipoReferenceNumber);

        processActionsDao.saveProcessActions(processAction);
        madridApplicationDao.saveMadridApplication(madridApplication);

        // Verify precondition created for testing MadridAbandonmentNotification
        madridApplication = madridApplicationDao.getMadridApplicationByReferenceNumber(wipoReferenceNumber);
        List<ProcessAction> processActionlist = processActionsDao
            .getProcessActionsByReferenceNumber(wipoReferenceNumber);
        List<MadridApplicationAction> madridApplicationActionlist = madridApplicationActionDao
            .getMadridApplicationActionByReferenceNumber(wipoReferenceNumber);
        int numberOfMadridApplicationActionPriorToProcess = madridApplicationActionlist != null
            ? madridApplicationActionlist.size() : 0;

        Assert.assertTrue(madridApplication != null
            && madridApplication.getStatusCode().intValue() != MadridApplicationStatus.CLOSED.getValue());
        Assert.assertTrue(processActionlist != null && processActionlist.size() > 0);

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        intlIrTranDto.setIrTranId(new BigDecimal("99999999"));

        // Process MadridAbandonmentNotification
        madridAbandonmentNotificationService.processInboundTransaction(intlIrTranDto,
            abandonmentNotificationTransacton);

        // Verify post condition after processing MadridAbandonmentNotification
        madridApplication = madridApplicationDao.getMadridApplicationByReferenceNumber(wipoReferenceNumber);
        processActionlist = processActionsDao.getProcessActionsByReferenceNumber(wipoReferenceNumber);
        madridApplicationActionlist = madridApplicationActionDao
            .getMadridApplicationActionByReferenceNumber(wipoReferenceNumber);
        int numberOfMadridApplicationActionAfterProcessing = madridApplicationActionlist != null
            ? madridApplicationActionlist.size() : 0;

        Assert.assertTrue(madridApplication != null
            && madridApplication.getStatusCode().intValue() == MadridApplicationStatus.CLOSED.getValue());
        Assert.assertTrue(processActionlist == null || processActionlist.size() <= 0);
        Assert
            .assertTrue(numberOfMadridApplicationActionAfterProcessing > numberOfMadridApplicationActionPriorToProcess);

        // Verify MadridApplicationAction created
        boolean actionFound = false;
        for (MadridApplicationAction action : madridApplicationActionlist) {
            if (action != null && action.getWipoReferenceNumber() != null
                && action.getWipoReferenceNumber().equalsIgnoreCase(wipoReferenceNumber)
                && action.getActionCode() == MadridApplicationActionStatus.CLOSED.getValue()
                && action.getAuthorityId() != null && action.getAuthorityId().equalsIgnoreCase("MADRID")
                && action.getActionDate() != null && action.getActionDate().equals(actionDate)) {
                actionFound = true;
                break;
            }
        }

        Assert.assertTrue(actionFound);
    }

    private MadridAbandonmentNotificationType getMadridAbandonmentNotificationTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridAbandonmentNotificationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridAbandonmentNotification_TMMADCON_721.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridAbandonmentNotificationType> madridAbandonmentNotificationElement = (JAXBElement<MadridAbandonmentNotificationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridAbandonmentNotificationElement.getValue();
    }

    private static JAXBContext initMadridAbandonmentNotificationContext() {
        try {
            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid");
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBContext instance for MadridAbandonmentNotificationType", e);
        }
        return null;

    }
}
