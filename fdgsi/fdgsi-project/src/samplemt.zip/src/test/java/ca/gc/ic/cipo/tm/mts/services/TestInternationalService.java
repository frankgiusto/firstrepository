package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory;
import ca.gc.ic.cipo.report.ReportType;
import ca.gc.ic.cipo.report.RuntimeJobState;
import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.OfficeType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgSchmaVrsn;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.ManualAutoCategoryType;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.IMadridCacheService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ITaskService;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;

/**
 * The Class TestInternationalService tests methods in the International Service.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-ttmModelDaoContext.xml",
    "classpath:junit-idIntlModelDaoContext.xml"})
public class TestInternationalService {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger logger = LoggerFactory.getLogger(TestInternationalService.class);

    private static final JAXBContext jaxbMadridContext = initMadridContext();

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IntlPkgDao pkgDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao pkgSchmaVrsnDao;

    @Autowired
    private IntlPkgTranTypeDao intlPkgTranTypeDao;

    @Autowired
    private IntlPkgTypeDao intlPkgTypeDao;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private ITaskService taskService;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Autowired
    private IntlPkgTranTypeDao intlPackageTranTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao intlPackageSchemaVersionDao;

    @Autowired
    private IMadridCacheService madridCacheService;

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestGetUnprocessedTranactions() throws ca.gc.ic.cipo.tm.mts.CIPOServiceFault {

        TransactionCriteria transactionCriteria = new TransactionCriteria();
        transactionCriteria.setTransactionManualAutoCategory(ManualAutoCategoryType.AUTOMATED);
        transactionCriteria.getStatusCodeList().add(TransactionStatusType.MPS_IMPORT_COMPLETE);

        List<TransactionDetail> transactions = internationalService.getTransactionList(transactionCriteria);

        assertTrue(CollectionUtils.isNotEmpty(transactions));
    }

    @Test
    @Rollback(true)
    @Ignore
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestfinalizeCeasingOfEffectNoTaskOnHold() {

        Map<ApplicationDto, UserTaskType> notificationTypes = new HashMap<>();
        ApplicationDto applicationDto = new ApplicationDto();
        applicationDto.setExtensionCounter("0");
        applicationDto.setFileNumber(12345);
        applicationDto.setIntlFilingRecordId("23424");
        applicationDto.setIrNumber("33333");
        applicationDto.setOfficeType(OfficeType.DO.name());

        notificationTypes.put(applicationDto, UserTaskType.PARTIAL_CEASING_OF_EFFECT_DO);

        IntlIrTranDto intlIrTranDto = null;

        // intlIrTranDto = createTransaction();
        intlIrTranDto = internationalDTOFactory.getIntlIrTranDto(intlIrTranDao.getIrTranById(BigDecimal.valueOf(1726)));

        taskService.getUserTaskInformation(intlIrTranDto.getIrTranId(), notificationTypes);

        IntlIrTranDto trans = internationalService.getTransactionsByIrTranId(intlIrTranDto.getIrTranId());

        // List<IntlIrTaskDto> tasks = internationalService.getTasksByTransactionId(trans.getIrTranId());
        //
        // assertTrue(CollectionUtils.isNotEmpty(tasks));
        //
        // for (IntlIrTaskDto intlIrTaskDto : tasks) {
        // StatusType statusCreated = StatusType
        // .getStatusTypeByValue(intlIrTaskDto.getStatusTypeDto().getStatusCtgryId());
        // assertTrue(statusCreated == StatusType.MANUAL_DO_PARTIAL_CEASING_OF_EFFECT);
        // }

    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTranDto createTransaction() throws SerialException, SQLException {

        IntlPkgType intlPkgType = new IntlPkgType();
        intlPkgType.setPkgCtgryId(new BigDecimal(877));
        intlPkgType.setPackageCtgry("test");
        intlPkgType.setDestnName("Inbound");
        intlPkgTypeDao.save(intlPkgType);

        IntlPkgSchmaVrsn pkgSchmaVrsn = new IntlPkgSchmaVrsn();

        pkgSchmaVrsn.setIntlPkgType(intlPkgType);
        pkgSchmaVrsn.setSchmaFileName("test");
        pkgSchmaVrsn.setVldFromDt(new Timestamp(System.currentTimeMillis()));
        pkgSchmaVrsnDao.save(pkgSchmaVrsn);

        IntlStatusType intlStatusType = new IntlStatusType();
        intlStatusType.setStatusCtgryId(new BigDecimal(453235));
        intlStatusType.setStatusCtgry("asdfasdf");
        intlStatusTypeDao.save(intlStatusType);

        IntlPkg intlPkg = new IntlPkg();

        // all 9 mandatory fields
        intlPkg.setIntlPkgType(intlPkgType);
        intlPkg.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlPkg.setIntlStatusType(intlStatusType);
        intlPkg.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlPkg.setIntlPblctnId("11/2017");
        intlPkg.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
        Blob xmlFileContent = new SerialBlob("blob".getBytes());
        intlPkg.setXmlFileName("H201711.zip");
        intlPkg.setXmlFileContent(xmlFileContent);
        pkgDao.save(intlPkg);

        IntlPkgTranType intlPkgTranType = new IntlPkgTranType();
        intlPkgTranType.setPkgTranCtgryId(new BigDecimal(888));
        intlPkgTranType.setTranCtgry("TEST");

        intlPkgTranTypeDao.save(intlPkgTranType);

        Blob xmlContent = new SerialBlob("blob".getBytes());

        IntlIrTran intlIrTran = new IntlIrTran();

        // all 7 mandatory fields plus pkg_id field
        intlIrTran.setIntlPkg(intlPkg);
        intlIrTran.setIntlPkgTranType(intlPkgTranType);
        intlIrTran.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlIrTran.setIntlStatusType(intlStatusType);
        intlIrTran.setIntlRegNo("WIPO40480");
        intlIrTran.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlIrTran.setXmlContent(xmlContent);

        // nullable fields
        Date intlRecordEfctvDt = new Date();
        intlRecordEfctvDt.getTime();

        intlIrTran.setIntlRecordId("852902001");
        intlIrTran.setIntlRecordEfctvDt(intlRecordEfctvDt);
        intlIrTran.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));

        intlIrTran.setIntlRecordId("343535");
        intlIrTran.setIntlRegNo("8888888");

        intlIrTranDao.save(intlIrTran);

        return internationalDTOFactory.getIntlIrTranDto(intlIrTran);
    }

    // @Test
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void getPdf() throws ca.gc.ic.cipo.tm.mts.CIPOServiceFault, IOException {

        AttachmentDetail pdfResponse = internationalService.getTransactionAttachment(BigDecimal.valueOf(31786));

        FileOutputStream fos = null;

        byte[] bytes = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        pdfResponse.getFileContent().writeTo(bos);
        bos.flush();
        bos.close();
        bytes = bos.toByteArray();

        try {
            fos = new FileOutputStream(new File("From-Database.pdf"));

            fos.write(bytes);

        } finally {
            fos.close();
        }
    }

    // No longer applicable.
    // @Test
    // @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    // @Rollback(true)
    // public void mapTransactionPairsToXsd()
    // throws CIPOServiceFault, ca.gc.ic.cipo.tm.mts.CIPOServiceFault, SQLException {
    //
    // List<TransactionDetail> transactionDetailList = new ArrayList<>();
    // List<IntlIrTran> transList = new ArrayList<>();
    //
    // transList.add(createOutboundIntlIrTransaction("4444444c",
    // BigDecimal.valueOf(TransactionCategory.MDT_MERGER.getTransactionCategoryId())));
    //
    // transList.add(createOutboundIntlIrTransaction("3333333c",
    // BigDecimal.valueOf(TransactionCategory.MDT_MERGER.getTransactionCategoryId())));
    //
    // transList.add(createOutboundIntlIrTransaction("3333333",
    // BigDecimal.valueOf(TransactionCategory.MD_MERGER.getTransactionCategoryId())));
    //
    // internationalDTOFactory.mapTransactionPairsToXsd(transList, transactionDetailList);
    //
    // assertTrue(!transactionDetailList.isEmpty());
    //
    // }

    public static EnumSet<TransactionCategory> pairedMergerTransactionTypes = EnumSet.of(TransactionCategory.MD_MERGER,
        TransactionCategory.MDT_MERGER);

    private IntlIrTran createOutboundIntlIrTransaction(String registrationNumber, BigDecimal pkgTranType)
        throws MTSServiceFault {

        Timestamp timestamp = new Timestamp(new Date().getTime());

        Blob blob = null;

        try {
            blob = new SerialBlob("placeholder".getBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }

        IntlIrTran intlTransaction = new IntlIrTran();
        intlTransaction.setCreatedTmstmp(timestamp);
        intlTransaction.setIntlRegNo(registrationNumber);
        intlTransaction.setIntlPkgTranType(intlPackageTranTypeDao.getTranTypeById(pkgTranType));
        intlTransaction.setIntlPkgSchmaVrsn(intlPackageSchemaVersionDao.getPkgSchmaVrsnById(BigDecimal.valueOf(1)));
        intlTransaction.setIntlStatusType(intlStatusTypeDao.getStatusTypeById(BigDecimal.valueOf(508)));
        intlTransaction.setXmlContent(blob);

        intlIrTranDao.save(intlTransaction);

        return intlTransaction;
    }

    // @Test
    public void TestGetUserProfile() throws CIPOServiceFault {
        // TMsuperM
        String userId = "giustof";

        UserProfile userProfile = madridCacheService.getUserProfile(userId);
        System.out.println(userProfile.getName());

        userId = "giustof";

        userProfile = madridCacheService.getUserProfile(userId);
        System.out.println(userProfile.getName());

        userId = "TMsuperM";
        userProfile = madridCacheService.getUserProfile(userId);

        System.out.println(userProfile.getName());

        userId = "TMsuperM";
        userProfile = madridCacheService.getUserProfile(userId);
        System.out.println(userProfile.getName());
    }

    private String generateMf1() {
        StringBuilder sb = new StringBuilder();
        String jobId = null;

        sb.append("<?xml version=\"1.0\"?>");
        sb.append("<MadridPossibleOppositionNotification>");
        sb.append("<OfficeReferenceIdentifier>79178342</OfficeReferenceIdentifier>");
        sb.append("<NotificationLanguage>en</NotificationLanguage>");
        sb.append("<InternationalRegistrationNumber>1278267</InternationalRegistrationNumber>");
        sb.append("<Holder>ENTERTAINMENT ONE UK LIMITED, ENTERTAINMENT TWO UK LIMITED</Holder> ");
        sb.append("<Signature>This is my signature, His signature</Signature>");
        sb.append("<OppositionPeriodEndDate>2017-09-19</OppositionPeriodEndDate>");
        sb.append("<OppositionPeriodStartDate>2017-09-19</OppositionPeriodStartDate>");
        sb.append("<RecordNotificationDate>2017-09-20</RecordNotificationDate>");
        sb.append("</MadridPossibleOppositionNotification>");

        try {
            Document doc = null;
            DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = dbfac.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(sb.toString()));
            doc = docBuilder.parse(is);

            ReportGenerationWsClient rgsClient = new ReportGenerationWsClient("http://devz.ccs.ic.gc.ca:9080");
            rgsClient.setOutReportType(ReportType.PDF);

            jobId = rgsClient.scheduleReportGenerationWithDocument("MADRID-MF1", null, doc,
                "/MadridPossibleOppositionNotification", null, null, null, null);

            System.out.println(jobId);
            RuntimeJobState state = rgsClient.getJobStatus(jobId);
            while (state != RuntimeJobState.COMPLETE && state != RuntimeJobState.ERROR) {
                Thread.sleep(10000);
                state = rgsClient.getJobStatus(jobId);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return jobId;
    }

    private static JAXBContext initMadridContext() {
        try {

            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid",
                ObjectFactory.class.getClassLoader());

        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;

    }

    public <T> T unmarshallTransaction(byte[] xml) throws JAXBException, SQLException {

        Unmarshaller unmarshallerRoot = jaxbMadridContext.createUnmarshaller();

        ByteArrayInputStream input = new ByteArrayInputStream(xml);

        @SuppressWarnings("unchecked")
        JAXBElement<T> transactionType = (JAXBElement<T>) unmarshallerRoot.unmarshal(input);

        return transactionType.getValue();
    }
}
