package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 * The Class tests the OO version of MadridDesignationTermination - Total Cancellation
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRTotalCancelationNotificationOO extends ProcessActionTestBase {

    private static final Logger log = LoggerFactory.getLogger(TestIRTotalCancelationNotificationOO.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    @Qualifier("irTotalCancellation")
    private IInboundTransaction irTotalCancellationService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private MadridApplicationDao madridApplicationsDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionsDao;

    private MadridDesignationTerminationType madridDesignationTermination = null;

    private Application application = null;

    private static final JAXBContext jaxbIRinitIRDesignationTerminationContext = initIRDesignationTerminationContext();

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    @Before
    @Transactional
    public void setUp() throws Exception {

        // CREATE an application
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("1348320");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(691609));

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application != null);

        // Create Madrid Application
        madridDesignationTermination = getIRDesignationTerminationTransaction();

        madridApplicationDao.saveMadridApplication(this.createMadridApplication(application,
            madridDesignationTermination.getInternationalRegistrationNumber(), "FRANCO222"));

        List<MadridApplication> madridApplicationList = madridApplicationDao
            .getMadridApplicationByIrNumber(madridDesignationTermination.getInternationalRegistrationNumber());

        assertTrue(CollectionUtils.isNotEmpty(madridApplicationList));
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testTotalCancellationOO() throws FileNotFoundException, JAXBException, CIPOServiceFault, SQLException {

        IntlIrTranDto intlIrTranDto = createIntlIrTran(madridDesignationTermination.getRecordIdentifier().getValue(),
            madridDesignationTermination.getInternationalRegistrationNumber());
        intlIrTranDto.setIntlRecordId(madridDesignationTermination.getRecordIdentifier().getValue());

        irTotalCancellationService.processInboundTransaction(intlIrTranDto, madridDesignationTermination);

        List<MadridApplication> result = madridApplicationDao
            .getMadridApplicationByIrNumber(madridDesignationTermination.getInternationalRegistrationNumber());

        for (MadridApplication madridApplications : result) {
            List<MadridApplicationAction> actions = madridApplicationActionsDao
                .getMadridApplicationActionByReferenceNumber(madridApplications.getWipoReferenceNumber());
            assertTrue(actions.size() > 0);
            assertTrue(actions.iterator().next().getActionCode() == MadridApplicationActionStatus.CLOSED.getValue());
        }

    }

    private static JAXBContext initIRDesignationTerminationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationTerminationType.class,
                MadridDesignationTerminationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBIRNonRenewalContext instance", e);
        }
        return null;

    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-no-ir-number.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridDesignationTerminationType getIRDesignationTerminationTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbIRinitIRDesignationTerminationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignationTermination-Total-Cancellation_2.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationTerminationType> madridDesignationElement = (JAXBElement<MadridDesignationTerminationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }
}
