package ca.gc.ic.cipo.tm.mts.services;

import java.io.FileNotFoundException;
import java.math.BigInteger;
import java.sql.SQLException;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GetWorkflowTaskList;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.TaskRequestType;
import ca.gc.ic.cipo.tm.mts.TaskSubjectCategory;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.service.bindings.MadridTransactionServiceSOAPBindingImpl;

/**
 *
 * @author rahmana1
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestGetWorkflowTaskList {

    @Autowired
    private MadridTransactionServicePortType madridTransactionService;

    @Ignore
    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testGetWorkflowTaskList() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        MadridTransactionServiceSOAPBindingImpl madridService = new MadridTransactionServiceSOAPBindingImpl();
        madridService.setMadridTransactionService(madridTransactionService);

        WorkflowTaskListSearchCriteria criteria = new WorkflowTaskListSearchCriteria();
        GetWorkflowTaskList gwfTaskList = new GetWorkflowTaskList();
        gwfTaskList.setWorkflowTaskListSearchCriteria(criteria);

        criteria.setTaskRequestType(TaskRequestType.CLAIMED_AND_UNCLAIMED);
        criteria.setTaskSubjectCategory(TaskSubjectCategory.MANUAL);

        criteria.setRowsPerPage(new BigInteger("20"));
        criteria.setStartRow(new BigInteger("0"));

        criteria.getSortColumn().add("intl_reg_no");
        criteria.getSortColumn().add("created_tmstmp");

        criteria.getSortDirection().add("ASC");
        criteria.getSortDirection().add("ASC");

        WorkflowTaskListResponse response = madridService
            .getWorkflowTaskList(gwfTaskList.getWorkflowTaskListSearchCriteria());

        Assert.assertNotNull(response);

    }

}
