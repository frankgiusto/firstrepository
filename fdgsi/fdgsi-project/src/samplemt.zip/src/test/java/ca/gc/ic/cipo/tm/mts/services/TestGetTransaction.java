package ca.gc.ic.cipo.tm.mts.services;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgSchmaVrsn;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 *
 * @author rahmana1
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestGetTransaction {

    private static final Logger log = LoggerFactory.getLogger(TestGetTransaction.class);

    @Autowired
    private MadridTransactionServicePortType madridTransactionService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private IntlPkgDao intlPkgDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlPkgTypeDao intlPkgTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao pkgSchmaVrsnDao;

    @Autowired
    private IntlPkgTranTypeDao intlPkgTranTypeDao;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testGetTransaction() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        IntlIrTranDto intlIrTranDto = createTransaction();

        TransactionDetail tranDetail = madridTransactionService.getTransaction(intlIrTranDto.getIrTranId(), false,
            false);

        Assert.assertNotNull(tranDetail);

    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTranDto createTransaction() throws SerialException, SQLException {

        IntlPkgType intlPkgType = new IntlPkgType();
        intlPkgType.setPkgCtgryId(new BigDecimal(877));
        intlPkgType.setPackageCtgry("test");
        intlPkgType.setDestnName("Inbound");
        intlPkgTypeDao.save(intlPkgType);

        IntlPkgSchmaVrsn pkgSchmaVrsn = new IntlPkgSchmaVrsn();

        pkgSchmaVrsn.setIntlPkgType(intlPkgType);
        pkgSchmaVrsn.setSchmaFileName("test");
        pkgSchmaVrsn.setVldFromDt(new Timestamp(System.currentTimeMillis()));
        pkgSchmaVrsnDao.save(pkgSchmaVrsn);

        IntlStatusType intlStatusType = new IntlStatusType();
        intlStatusType.setStatusCtgryId(new BigDecimal(453235));
        intlStatusType.setStatusCtgry("asdfasdf");
        intlStatusTypeDao.save(intlStatusType);

        IntlPkg intlPkg = new IntlPkg();

        // all 9 mandatory fields
        intlPkg.setIntlPkgType(intlPkgType);
        intlPkg.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlPkg.setIntlStatusType(intlStatusType);
        intlPkg.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlPkg.setIntlPblctnId("11/2017");
        intlPkg.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
        Blob xmlFileContent = new SerialBlob("blob".getBytes());
        intlPkg.setXmlFileName("H201711.zip");
        intlPkg.setXmlFileContent(xmlFileContent);
        intlPkgDao.save(intlPkg);

        IntlPkgTranType intlPkgTranType = new IntlPkgTranType();
        intlPkgTranType.setPkgTranCtgryId(new BigDecimal(10));
        intlPkgTranType.setTranCtgry("TEST");

        intlPkgTranTypeDao.save(intlPkgTranType);

        Blob xmlContent = new SerialBlob("blob".getBytes());

        IntlIrTran intlIrTran = new IntlIrTran();

        // all 7 mandatory fields plus pkg_id field
        intlIrTran.setIntlPkg(intlPkg);
        intlIrTran.setIntlPkgTranType(intlPkgTranType);
        intlIrTran.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlIrTran.setIntlStatusType(intlStatusType);
        intlIrTran.setIntlRegNo("WIPO40480");
        intlIrTran.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlIrTran.setXmlContent(xmlContent);

        // nullable fields
        Date intlRecordEfctvDt = new Date();
        intlRecordEfctvDt.getTime();

        intlIrTran.setIntlRecordId("852902001");
        intlIrTran.setIntlRecordEfctvDt(intlRecordEfctvDt);
        intlIrTran.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));

        intlIrTran.setIntlRecordId("343535");
        intlIrTran.setIntlRegNo("8888888");

        intlIrTranDao.save(intlIrTran);

        return internationalDTOFactory.getIntlIrTranDto(intlIrTran);
    }
}
