package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.intl.exception.IDIntlNotFoundException;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;

/**
 * The Class tests the processing initiated by manual tasks on the Madrid Console.
 *
 * @author htan
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestMadridConsoleService extends GoodsServicesTestBase {

    @Mock
    private IInternationalService internationalServiceMock;

    @Autowired
    private MadridTransactionServicePortType madridService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Mock
    private IIntrepidCommonService intrepidCommonServiceMock;

    @Autowired
    private IInternationalService internationalService;

    private Application application = null;

    private static Logger logger = Logger.getLogger(TestMadridConsoleService.class.getName());

    @Before
    @Transactional
    @Rollback(true)
    public void setUp() throws Exception {

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-G&S-Base.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355288000", "1355288");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        printGS(application);

    }

    @Override
    @After
    public void finalize() {
        System.out.println("finalize");
        application = null;
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testIRCorrectionWithYes() throws FileNotFoundException, JAXBException, SQLException {

        ProcessIRCorrectionSubmissionRequest request = new ProcessIRCorrectionSubmissionRequest();
        request.setTaskId(BigDecimal.valueOf(1179116));
        request.setNotificationLanguage("en");
        request.setFileNumber(BigDecimal.valueOf(application.getFileNumber()));
        request.setExtensioncounter(application.getExtensionCounter().toString());
        request.setAuthorityId(SectionAuthority.FORMALITIES.name());
        request.setIsResetMonthPeriod(true);

        List<IntlIrTranDto> transactionList = new ArrayList<IntlIrTranDto>();
        try {
            transactionList = internationalService.getTransactionByTaskId(request.getTaskId());

            if (!CollectionUtils.isEmpty(transactionList)) {
                try {
                    madridService.processIRCorrectionSubmission(request);
                } catch (CIPOServiceFault e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);
                boolean found = false;
                if (updatedApplication.getActions().size() > 0) {
                    for (Action action : updatedApplication.getActions()) {
                        if (action.getActionCode() == ActionCode.IR_CORRECTION.getValue()
                            || action.getActionCode() == ActionCode.MADRID_DESIGNATION_NOTIFICATION.getValue()) {

                            found = true;
                        }
                    }
                    assertTrue(found);
                }
            } else {
                System.out.println("transactionList is empty - taskId maybe deleted in DB: " + transactionList
                    + "when processing test IR correction is YES.");
            }
        } catch (IDIntlNotFoundException ex) {
            logger.error("There are no intlIrTask with id [" + request.getTaskId() + "]\n");
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testIRCorrectionWithNo() throws FileNotFoundException, JAXBException, SQLException {

        ProcessIRCorrectionSubmissionRequest request = new ProcessIRCorrectionSubmissionRequest();
        request.setTaskId(BigDecimal.valueOf(1179116));
        request.setNotificationLanguage("en");
        request.setFileNumber(BigDecimal.valueOf(application.getFileNumber()));
        request.setExtensioncounter(application.getExtensionCounter().toString());
        request.setAuthorityId(SectionAuthority.FORMALITIES.name());
        request.setIsResetMonthPeriod(false);

        List<IntlIrTranDto> transactionList = new ArrayList<IntlIrTranDto>();
        try {
            transactionList = internationalService.getTransactionByTaskId(request.getTaskId());
            if (!CollectionUtils.isEmpty(transactionList)) {
                try {
                    madridService.processIRCorrectionSubmission(request);
                } catch (CIPOServiceFault e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);
                boolean found = false;
                if (updatedApplication.getActions().size() > 0) {
                    for (Action action : updatedApplication.getActions()) {
                        if (action.getActionCode() == ActionCode.IR_CORRECTION.getValue()) {
                            found = true;
                        }
                    }
                    // assertTrue(found);
                }
            } else {
                System.out.println("transactionList is empty - taskId maybe deleted in DB: " + transactionList
                    + "when processing test IR correction is NO.");
            }
        } catch (IDIntlNotFoundException ex) {
            logger.error("There are no intlIrTask with id [" + request.getTaskId() + "]\n");
        }
    }

}
