package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialBlob;
import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridOutboundTransactionType;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.IMarshallingService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.CourtesyLetter;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridCourtesyLetter;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.report.MadridReportResponse;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridGrantProtection;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.MadridPossibleOppositionNotification;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@ContextConfiguration(locations = {"classpath:junit-ttmModelDaoContext.xml",
    "classpath:junit-idIntlModelDaoContext.xml"})
public class TestCreateMForms {

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IMarshallingService marshallingService;

    private String reportServiceHost = "http://devz.ccs.ic.gc.ca:9080";

    private String filePath = "/madridTestData/MTS_FORMS/";

    @Test
    public void testDefault() {

    }

    // @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestCreateCourtesyLetter() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        MadridCourtesyLetter mclData = new MadridCourtesyLetter();
        mclData.setApplicant("KT &amp; G Corporation");
        mclData.setAddress("KBK &amp; Associates ");
        mclData.setYourFileNumber("123456");
        mclData.setMyFileNumber("111111");
        mclData.setIrNumber("9999912");
        mclData.setTradeMark("lil HYBRID");
        mclData.setReportFileName("abc.pdf");
        CourtesyLetter mcl = new CourtesyLetter();

        try {
            MadridReportResponse madridReportResponse = mcl.generateReport(null, null, null, reportServiceHost,
                mclData);
            assertTrue(madridReportResponse.getJobId() != null);
            getCompletedReport(madridReportResponse.getJobId(), "MADRID-COURTESY-LETTER.pdf");
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    // @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestCreateMF1Form() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTran tran = intlIrTranDao.getById(new BigDecimal(230857));

        MadridPossibleOppositionNotification testMF1 = new MadridPossibleOppositionNotification(
            MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1);
        try {
            MadridReportResponse madridReportResponse = testMF1.generateReport(null, tran.getIrTranId(),
                marshallingService, reportServiceHost, null);
            assertTrue(madridReportResponse.getJobId() != null);
            getCompletedReport(madridReportResponse.getJobId(), "MF1.pdf");
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    // @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestCreateMF2Form() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTran tran = intlIrTranDao.getById(new BigDecimal(230857));

        MadridPossibleOppositionNotification testMF1 = new MadridPossibleOppositionNotification(
            MadridOutboundTransactionType.MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF2);
        try {
            MadridReportResponse madridReportResponse = testMF1.generateReport(null, tran.getIrTranId(),
                marshallingService, reportServiceHost, null);
            assertTrue(madridReportResponse.getJobId() != null);
            getCompletedReport(madridReportResponse.getJobId(), "MF2.pdf");
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    // @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestCreateMF4Form() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        IntlIrTran tran = intlIrTranDao.getById(new BigDecimal(230409));

        MadridGrantProtection testMF1 = new MadridGrantProtection();
        try {
            MadridReportResponse madridReportResponse = testMF1.generateReport(null, tran.getIrTranId(),
                marshallingService, reportServiceHost, null);
            assertTrue(madridReportResponse.getJobId() != null);
            getCompletedReport(madridReportResponse.getJobId(), "MF4.pdf");
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

    private void getCompletedReport(String jobId, String fileName) {
        ReportGenerationWsClient rgsClient = new ReportGenerationWsClient(reportServiceHost);
        Blob blob = null;

        // Get the completed report.
        try {
            InputStream myReport = rgsClient.getGeneratedReport(jobId);
            byte[] buffer = new byte[myReport.available()];
            myReport.read(buffer);

            // Add the report to the blob type
            blob = new SerialBlob(buffer);

            InputStream is = blob.getBinaryStream();

            File directory = new File(filePath);

            if (!directory.exists()) {
                directory.mkdir();
            }

            @SuppressWarnings("resource")
            FileOutputStream fos = new FileOutputStream(filePath + fileName);

            int b = 0;
            while ((b = is.read()) != -1) {
                fos.write(b);
            }

            System.out.println("PDF file: " + (filePath + fileName) + " has been created");
        } catch (

        Exception e) {
            System.out.println(e.getMessage());
        }

    }

}
