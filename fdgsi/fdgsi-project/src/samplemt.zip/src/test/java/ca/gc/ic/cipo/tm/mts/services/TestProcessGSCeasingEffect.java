package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.GoodsServiceAction;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.MadridConsoleService;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.mts.service.intl.officetoib.IOutboundTransactionService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IIntrepidCommonService;
import ca.gc.ic.cipo.tm.mts.service.intrepid.IRProcessGoodServices;

/**
 * The Class tests the processing of Goods and Services of a Partial Ceasing of Effect, initiated by manual tasks on the
 * Madrid Console.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestProcessGSCeasingEffect extends GoodsServicesTestBase {

    @Mock
    private IInternationalService internationalServiceMock;

    @Autowired
    private MadridTransactionServicePortType madridService;

    @Autowired
    private MadridConsoleService madridConsoleService;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Mock
    private IIntrepidCommonService intrepidCommonServiceMock;

    @Autowired
    private IRProcessGoodServices processGoodServices;

    @Mock
    private IOutboundTransactionService outboundTransactionServiceMock;

    private Application application = null;

    private int taskId = 1156674;

    @Before
    @Transactional
    @Rollback(true)
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(madridConsoleService, "intrepidCommonService", intrepidCommonServiceMock);
        // ReflectionTestUtils.setField(processGoodServices, "intrepidCommonService", intrepidCommonServiceMock);
        ReflectionTestUtils.setField(madridConsoleService, "internationalService", internationalServiceMock);
        ReflectionTestUtils.setField(madridConsoleService, "outboundTransactionService",
            outboundTransactionServiceMock);

        MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-G&S-Base.xml");

        IntlIrTranDto intlIrTranDto = createIntlIrTran("1355288000", "1355288");

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        application = applicationDao.getApplication(newApplication.keySet().iterator().next().getFileNumber(), 0);

        assertTrue(application != null);

        GoodsAndServiceMeta goodsAndServiceMeta = new GoodsAndServiceMeta();
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        Mockito.when((internationalServiceMock).getTransactionByTaskId(Mockito.any(BigDecimal.class)))
            .thenReturn(super.getTaskTransaction(goodsAndServiceMeta.getTaskId()));

        printGS(application);

    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectActiveAcceptAll() throws FileNotFoundException, JAXBException, SQLException {

        application.setStatusCode(12);
        applicationDao.saveApplication(application);

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_4(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_ALL);

        GoodsAndServicesChangesResponse response;
        try {
            if (verifyTaskId(goodsAndServiceMeta)) {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);
                assertTrue(null != response);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

                assertTrue(updatedApplication.getGoodsServices().size() == 4);

                Set<GoodService> goodsServiceSet = updatedApplication.getGoodsServices();
                Iterator<GoodService> iterator = goodsServiceSet.iterator();
                while (iterator.hasNext()) {
                    GoodService goodService = iterator.next();
                    System.out.println(goodService.getNiceClassCode().toString());
                    Set<GoodServiceText> gstextSet = goodService.getGoodServiceTexts();
                    Iterator<GoodServiceText> iterator2 = gstextSet.iterator();
                    while (iterator2.hasNext()) {
                        GoodServiceText gsText = iterator2.next();
                        System.out.println(gsText.getText());
                    }
                }

                List<Action> actionList = updatedApplication.getActions();

                int match = 0;
                for (Action action : actionList) {
                    if (action.getActionCode().intValue() == ActionCode.PARTIAL_CANCELLATION.getValue().intValue()) {
                        match++;
                    }
                }
                assertTrue(match == 1);
            }
        } catch (CIPOServiceFault e) {
            throw new AssertionError("Expected exception: " + e.getMessage());
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectWithGSAdjustments() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_4(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

                assertTrue(updatedApplication.getGoodsServices().size() == 4);

                printGS(application);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectWithGSAdjustmentsRemovedStatement()
        throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_3(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

                assertTrue(updatedApplication.getGoodsServices().size() == 3);

                assertTrue(updatedApplication.getClaims().size() == 1);

                printGS(application);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectWithGSAdjustmentsRemovedStatementClaim()
        throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_2(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(1156674));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

                assertTrue(updatedApplication.getGoodsServices().size() == 2);

                assertTrue(updatedApplication.getClaims().size() == 0);

                printGS(application);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectWithGSAdjustmentsNewStatement()
        throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_6(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

                assertTrue(updatedApplication.getGoodsServices().size() == 6);

                assertTrue(updatedApplication.getClaims().size() == 1);

                printGS(application);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectNoGSAdjustments() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(response != null);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectActiveNoEffect() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getCommonGoodsAndServiceMeta(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT);

        if (verifyTaskId(goodsAndServiceMeta)) {
            try {
                madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);
                List<Action> actionList = updatedApplication.getActions();

                int match = 0;
                for (Action action : actionList) {
                    if (action.getActionCode().intValue() == ActionCode.PARTIAL_CEASING_OF_EFFECT_RECEIVED_NOEFFECT
                        .getValue().intValue()) {
                        match++;
                    }
                }
                assertTrue(match == 1);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testCeasingOfEffectPendingAcceptAll() throws FileNotFoundException, JAXBException, SQLException {

        // update the application to a pending status.
        application.setStatusCode(1);
        applicationDao.saveApplication(application);

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_4(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_ALL);

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsAndServicesChangesResponse response;
            try {
                response = madridService.processGoodsAndServicesChanges(goodsAndServiceMeta);

                assertTrue(null != response);

                Application updatedApplication = applicationDao.getApplication(application.getFileNumber(), 0);

                assertTrue(updatedApplication.getGoodsServices().size() == 4);

                Set<GoodService> goodsServiceSet = updatedApplication.getGoodsServices();
                Iterator<GoodService> iterator = goodsServiceSet.iterator();
                while (iterator.hasNext()) {
                    GoodService goodService = iterator.next();
                    System.out.println(goodService.getNiceClassCode().toString());
                    Set<GoodServiceText> gstextSet = goodService.getGoodServiceTexts();
                    Iterator<GoodServiceText> iterator2 = gstextSet.iterator();
                    while (iterator2.hasNext()) {
                        GoodServiceText gsText = iterator2.next();
                        System.out.println(gsText.getText());
                    }
                }

                List<Action> actionList = updatedApplication.getActions();

                int match = 0;
                for (Action action : actionList) {
                    if (action.getActionCode().intValue() == ActionCode.PARTIAL_WITHDRAWAL.getValue().intValue()) {
                        match++;
                    }
                }
                assertTrue(match == 1);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void testPartialCeasingOfEffectWOGSAdjustment() throws FileNotFoundException, JAXBException, SQLException {

        GoodsAndServiceMeta goodsAndServiceMeta = getGoodsAndServiceMeta_6(application);
        goodsAndServiceMeta.setTaskId(BigDecimal.valueOf(taskId));
        goodsAndServiceMeta.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        goodsAndServiceMeta.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT);
        goodsAndServiceMeta.setAuthorityId(SectionAuthority.MADRID.name());

        if (verifyTaskId(goodsAndServiceMeta)) {
            GoodsServiceAction gsAction;
            try {
                gsAction = processGoodServices.processDOPartialCeasingEffect(goodsAndServiceMeta, null);

                assertTrue(gsAction != null);

                Iterator<Action> itt = application.getActions().iterator();
                boolean isMadrid = false;
                while (itt.hasNext()) {
                    Action action = itt.next();
                    if (action.getAuthorityId().equals(SectionAuthority.MADRID.name())) {
                        isMadrid = true;
                        break;
                    }
                }
                assertTrue(isMadrid);

            } catch (CIPOServiceFault e) {
                throw new AssertionError("Expected exception: " + e.getMessage());
            }
        }
    }
}
