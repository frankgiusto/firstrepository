package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationTerminationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionActionType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.enums.SectionAuthority;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRCeasingOfEffectService {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRCeasingOfEffectService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irCeasingOfEffectTotal")
    private IInboundTransaction irRCeasingOfEffectTotalService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestRegisteredCeasingOfEffect()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        OppositionCase oppositionCase = createOppositionCase(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction = createOppositionAction(application, oppositionCase,
            OppositionCaseActionCodeType.CLOSED_BY_TMO);
        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        // OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        // IR Non Renewal
        MadridDesignationTerminationType madridDesignationTerminationType = new MadridDesignationTerminationType();
        madridDesignationTerminationType.setExpiryDate("2027-02-28");
        madridDesignationTerminationType.setInternationalRegistrationNumber("8888888");
        IdentifierType it = new IdentifierType();
        it.setOfficeCode("302017000013034/GT");
        madridDesignationTerminationType.setOfficeReferenceIdentifier(it);
        // // madridDesignationTerminationType.setRecordFilingDate("2017-02-28");
        IdentifierType it2 = new IdentifierType();
        it2.setOfficeCode("9999999");
        madridDesignationTerminationType.setRecordIdentifier(it2);

        intlIrTranDto.setIntlRecordId(madridDesignationTerminationType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");
        // intlIrTranDto.setIntlRecordId("343535");
        // intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irRCeasingOfEffectTotalService
            .processInboundTransaction(intlIrTranDto, madridDesignationTerminationType);

        assertTrue(null != notificationTypes);
        Collection<UserTaskType> values = notificationTypes.values();
        Iterator<UserTaskType> iterator = values.iterator();
        int cnt = 0;
        while (iterator.hasNext()) {
            UserTaskType statusType = iterator.next();
            if (statusType == UserTaskType.TOTAL_CEASING_OF_EFFECT_DO) {
                cnt++;
            }
        }
        assertTrue(cnt == 1);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getStatusCode().equals(TradeMarkStatusType.CANCELLED.getValue()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean expunged = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.CANCELLED.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        expunged = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode().equals(ProcessActionsType.PRINT_CANCELLED_NOTIFICATION.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Opposition Cases
        assertTrue(application.getOppositionCases().size() == 1);
        Iterator<OppositionCase> ocIterator = application.getOppositionCases().iterator();
        while (ocIterator.hasNext()) {
            OppositionCase oc = ocIterator.next();
            assertTrue(oc.getOppositionCaseActions().size() == 2);

            OppositionCaseAction ca = oc.getOppositionCaseActions().iterator().next();
            assertTrue(ca.getOppCaseNumber().equals(oc.getOppCaseNumber()));
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestPendingCeasingOfEffect()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());

        OppositionCase oppositionCase = createPendingOppositionCase(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction = createOppositionAction(application, oppositionCase,
            OppositionCaseActionCodeType.CASE_CLOSED_BY_TMO);
        oppositionCase.getOppositionCaseActions().add(oppositionCaseAction);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        application.getOppositionCases().add(oppositionCase);

        applicationDao.saveApplication(application);

        MadridDesignationTerminationType madridDesignationTerminationType = new MadridDesignationTerminationType();
        madridDesignationTerminationType.setExpiryDate("2027-02-28");
        madridDesignationTerminationType.setInternationalRegistrationNumber("8888888");
        IdentifierType it = new IdentifierType();
        it.setOfficeCode("302017000013034/GT");
        madridDesignationTerminationType.setOfficeReferenceIdentifier(it);
        // // madridDesignationTerminationType.setRecordFilingDate("2017-02-28");
        IdentifierType it2 = new IdentifierType();
        it2.setOfficeCode("9999999");
        madridDesignationTerminationType.setRecordIdentifier(it2);

        intlIrTranDto.setIntlRecordId(madridDesignationTerminationType.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irRCeasingOfEffectTotalService
            .processInboundTransaction(intlIrTranDto, madridDesignationTerminationType);

        assertTrue(null != notificationTypes);
        Collection<UserTaskType> values = notificationTypes.values();
        Iterator<UserTaskType> iterator = values.iterator();
        int cnt = 0;
        while (iterator.hasNext()) {
            UserTaskType statusType = iterator.next();
            if (statusType == UserTaskType.TOTAL_CEASING_OF_EFFECT_DO) {
                cnt++;
            }
        }
        assertTrue(cnt == 1);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getStatusCode().equals(TradeMarkStatusType.WITHDRAWN.getValue()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean expunged = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.WITHDRAWN.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        expunged = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode().equals(ProcessActionsType.PRINT_WITHDRAWN_NOTIFICATION.getValue())) {
                expunged = true;
                break;
            }
        }
        assertTrue(expunged);

        // Verify Opposition Cases
        assertTrue(application.getOppositionCases().size() == 1);
        Iterator<OppositionCase> ocIterator = application.getOppositionCases().iterator();
        while (ocIterator.hasNext()) {
            OppositionCase oc = ocIterator.next();
            assertTrue(oc.getOppositionCaseActions().size() == 2);

            OppositionCaseAction ca = oc.getOppositionCaseActions().iterator().next();
            assertTrue(ca.getOppCaseNumber().equals(oc.getOppCaseNumber()));
        }
    }

    private OppositionCaseAction createOppositionAction(Application application, OppositionCase oppositionCase,
                                                        OppositionCaseActionCodeType actionCodeType) {
        OppositionCaseAction oppositionCaseAction1 = new OppositionCaseAction();
        oppositionCaseAction1.setFileNumber(application.getFileNumber());
        oppositionCaseAction1.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseAction1.setActionDate(new Date());
        oppositionCaseAction1.setOppCaseNumber(oppositionCase.getOppCaseNumber());
        oppositionCaseAction1.setOppositionCase(oppositionCase);
        if (actionCodeType == OppositionCaseActionCodeType.CLOSED_BY_TMO) {
            oppositionCaseAction1.setOppStageCode(301); // OppositionCaseStage.GENERAL_ACTIONS_OPPOSITIONS.getValue());
        } else {
            oppositionCaseAction1.setOppStageCode(1);
        }

        oppositionCaseAction1.setOppActionCode(actionCodeType.getValue());
        oppositionCaseAction1.setOppActionType(OppositionActionType.SYSTEM_GENERATED.getValue());
        oppositionCaseAction1.setAuthorityId(SectionAuthority.MADRID.name());

        return oppositionCaseAction1;
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {

        // OPP_STAGE_CODE 1
        // OPP_ACTION_CODE 2
        // OPP_ACTION_TYPE 3

        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.PENDING.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private IntlIrTranDto setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MDT_TOTAL_CEASING_OF_EFFECT.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        return intlIrTranDto;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }
}
