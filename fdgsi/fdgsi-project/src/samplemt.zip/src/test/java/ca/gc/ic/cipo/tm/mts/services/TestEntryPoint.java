package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.bind.JAXBException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.service.bindings.MadridTransactionServiceSOAPBindingImpl;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestEntryPoint {

    private static final Logger log = LoggerFactory.getLogger(TestEntryPoint.class);

    @Autowired
    private MadridTransactionServicePortType madridTransactionService;

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestProcessIRCreation() throws JAXBException, SQLException, CIPOServiceFault, IOException {

        MadridTransactionServiceSOAPBindingImpl madridService = new MadridTransactionServiceSOAPBindingImpl();
        madridService.setMadridTransactionService(madridTransactionService);

        // MD
        // AutomaticProcessingCriteria automaticProcessingCriteria = new AutomaticProcessingCriteria();
        // TransactionRequest transactionRequest = new TransactionRequest();
        // transactionRequest.setIrTranId(BigDecimal.valueOf(1416627));
        // automaticProcessingCriteria.setTransactionRequest(transactionRequest);
        //
        // AutomatedProcessResponse results = madridService.processAutomatedTransaction(automaticProcessingCriteria);
        //
        // assertTrue(results != null);

        // MDT
        AutomaticProcessingCriteria automaticProcessingCriteria = new AutomaticProcessingCriteria();
        TransactionRequest transactionRequest = new TransactionRequest();
        transactionRequest.setIrTranId(BigDecimal.valueOf(1416627));
        automaticProcessingCriteria.setTransactionRequest(transactionRequest);

        AutomatedProcessResponse results = madridService.processAutomatedTransaction(automaticProcessingCriteria);

        assertTrue(results != null);
    }

}
