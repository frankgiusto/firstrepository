package ca.gc.ic.cipo.tm.mts.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.common.madrid.AddressLineTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.EntityNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrganizationNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PartyIdentifierType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PersonNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PhraseType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType;
import _int.wipo.standards.xmlschema.st96.common.madrid.RepresentativeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.RepresentativeAddressDto;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */

public class TestRepresentativeAddress {

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static MadridDesignationType getMadridTransaction(String xmlFileName)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(xmlFileName);

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    public static void main(String[] args) throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {
        MadridDesignationType madridDesignation = getMadridTransaction(
            "C:/Users/giustof/Workspaces/ICEclipse4WASDevelopers-2/CIPO-tm-madrid-transaction-service/CIPO-tm-madrid-transaction-service-ws/src/test/resources/MadridDesignation-D5.xml");

        RepresentativeAddressDto addr = getRepAddress(madridDesignation);
        addr.setFileNumber(BigDecimal.valueOf(1423552));
        addr.setExtensionCounter("0");
        addr.setIrNumber("234253");

        System.out.println("within limits: " + addr.isAddressSizeOk());
    }

    private static RepresentativeAddressDto getRepAddress(MadridDesignationType madridDesignation) {

        StringBuilder nameBuffer = new StringBuilder();
        RepresentativeAddressDto representativeAddress = new RepresentativeAddressDto();

        RepresentativeType representative = madridDesignation.getRepresentative();

        ContactType contact = null;
        for (Object aType : representative.getLegalEntityNameOrPartyIdentifierOrContact()) {
            if (aType instanceof ContactType) {
                contact = (ContactType) aType;
                InterestedParty interestedParty = createInterestedPartyContact(contact);

                addNameToken(nameBuffer, interestedParty.getContact().getName());

            } else if (aType instanceof String) { // This is LegalEntityName
                addNameToken(nameBuffer, (String) aType);

            } else if (aType instanceof PartyIdentifierType) {
                PartyIdentifierType partyIdentifierType = (PartyIdentifierType) aType;
                addNameToken(nameBuffer, partyIdentifierType.getValue());
            }
        }
        representativeAddress.setRepresentativeName(nameBuffer.toString());

        // Now Address. check all contacts for a postalAddress.
        for (Object aType : representative.getLegalEntityNameOrPartyIdentifierOrContact()) {
            if (aType instanceof ContactType) {
                contact = (ContactType) aType;

                createRepresentativeAddress(representativeAddress, contact);

                if (!CollectionUtils.isEmpty(representativeAddress.getRepresentativeAddress())) {
                    break;
                }

            }
        }
        return representativeAddress;
    }

    private static void addNameToken(StringBuilder representativeAddress, String token) {
        if (representativeAddress.length() > 0) {
            representativeAddress.append(";");
        }
        representativeAddress.append(token);
    }

    private static void createRepresentativeAddress(RepresentativeAddressDto representativeAddress,
                                                    ContactType wipoContact) {

        // Address, Postal Code, Country Code
        if (null != wipoContact.getPostalAddressBag()) {
            List<PostalAddressType> postalAddress = wipoContact.getPostalAddressBag().getPostalAddress();
            for (PostalAddressType address : postalAddress) {

                representativeAddress.setCountryProvince(address.getPostalStructuredAddress().getCountryCode());
                representativeAddress.setZipPostalCode(address.getPostalStructuredAddress().getPostalCode());

                for (AddressLineTextType addressLineText : address.getPostalStructuredAddress().getAddressLineText()) {

                    representativeAddress.getRepresentativeAddress().add(addressLineText.getValue());
                }
                break;
            }
        }

    }

    private static InterestedParty createInterestedPartyContact(ContactType contact) {

        IPContact nameContact = null;
        IPContact businessContact = null;
        IPContact entityContact = null;
        InterestedParty interestedPartyHolder = new InterestedParty();

        for (Object personNameOrOrganizationNameOrEntityName : contact.getName()
            .getPersonNameOrOrganizationNameOrEntityName()) {

            if (personNameOrOrganizationNameOrEntityName instanceof PersonNameType) {
                nameContact = new IPContact();

                nameContact.setName(((PersonNameType) personNameOrOrganizationNameOrEntityName).getPersonFullName());
                interestedPartyHolder.setContact(nameContact);

            } else if (personNameOrOrganizationNameOrEntityName instanceof OrganizationNameType) {
                businessContact = new IPContact();

                OrganizationNameType organizationNameType = (OrganizationNameType) personNameOrOrganizationNameOrEntityName;
                PhraseType orgStandardName = organizationNameType.getOrganizationStandardName();
                StringBuilder standardNameBuffer = new StringBuilder();
                for (Serializable standardName : orgStandardName.getContent()) {
                    if (standardNameBuffer.length() > 0) {
                        standardNameBuffer.append(";");
                    }
                    standardNameBuffer.append(standardName);
                }

                businessContact.setName(standardNameBuffer.toString());

            } else if (personNameOrOrganizationNameOrEntityName instanceof EntityNameType) {
                entityContact = new IPContact();

                entityContact.setName(((EntityNameType) personNameOrOrganizationNameOrEntityName).getValue());

            }
            break; // Primary Address only required
        }
        // Name is mandatory.
        if (null == interestedPartyHolder.getContact()) {
            if (null != entityContact) {
                interestedPartyHolder.setContact(entityContact);
            } else {
                interestedPartyHolder.setContact(businessContact);
            }
        }
        return interestedPartyHolder;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class);
        } catch (JAXBException e) {
            e.printStackTrace();
        }
        return null;

    }

}
