package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRChangeOwnershipTotalService extends MadridTransactionTestBase {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRChangeOwnershipTotalService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irOwnershipChangeTotal")
    private IInboundTransaction irOwnershipChangeTotalService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private MailDao mailDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbHolderRepresentativeChangeContext = initHolderRepresentativeChange();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-base-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepresentativeChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbHolderRepresentativeChangeContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/IRChangeOwnershipTotal-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> holderRepresentativeChangeElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return holderRepresentativeChangeElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepresentativeChangeCAdress()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbHolderRepresentativeChangeContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/IRChangeOwnershipTotal-CorrespondenceAddress.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> holderRepresentativeChangeElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return holderRepresentativeChangeElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestRegisteredIrChangeOwnershipTotal()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Create Opposition Case
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // IR Change Ownership total
        MadridHolderRepresentativeChangeType irMHRChangeTransaction = getMadridHolderRepresentativeChangeTransaction();
        intlIrTranDto.setIntlRecordId(irMHRChangeTransaction.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irOwnershipChangeTotalService
            .processInboundTransaction(intlIrTranDto, irMHRChangeTransaction);

        assertTrue(null != notificationTypes);

        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType taskType : notifications) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.TOTAL_OWNERSHIP_CHANGED_OCCURRED
                    || taskType == UserTaskType.ADDRESS_EXCEEDED_LIMIT
                    || taskType == UserTaskType.REPRESENTATIVE_COURTESY_LETTER
                    || taskType == UserTaskType.UPDATE_ADDRESS_CREATE_COURTESYLATTER);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(CollectionUtils.isNotEmpty(application.getFootnotes()));

        Set<InterestedParty> interestedParties = application.getInterestedParties();
        // Should be 2 interested parties
        assertTrue(interestedParties.size() == 2);

        for (InterestedParty party : interestedParties) {
            // Intitial party relationship should now be Old Owner.
            if (party.getRelationshipType().intValue() == RelationshipType.OLD_OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Cato Networks Ltd.; Norris, Michele L."));
            }
            // New relationship type should be OWNER.
            if (party.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Finsec S.r.l. in liquidazione"));
            }
        }
        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean verified = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.CHANGE_OF_TITLE_REGISTERED.getValue())) {
                verified = true;
                break;
            }
        }
        assertTrue(verified);

        // Process actions

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        boolean actionexists = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_CONFIRMATION_OWNERSHIP_CHANGE_TOTAL.getValue())) {
                actionexists = true;
                break;
            }
        }
        // assertTrue(actionexists);

        // Footnote
        Set<Footnote> footnotes = application.getFootnotes();
        for (Footnote footnote : footnotes) { // 2017-02-21
            Date ftDate = footnote.getDateOfChange();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(ftDate);

            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH) + 1;
            int year = calendar.get(Calendar.YEAR);

            assertTrue(day == 21);
            assertTrue(month == 2);
            assertTrue(year == 2017);

            assertTrue(footnote.getType().intValue() == FootnoteType.CHANGE_OF_OWNERSHIP_INTERNATIONAL_REGISTRATION
                .getValue());
            assertTrue(footnote.getText()
                .equals("From: Cato Networks Ltd.; Norris, Michele L. To: Finsec S.r.l. in liquidazione"));
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestIrChangeOwnershipTotal()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // IR Change Ownership total
        MadridHolderRepresentativeChangeType irMHRChangeTransaction = getMadridHolderRepresentativeChangeTransaction();
        intlIrTranDto.setIntlRecordId(irMHRChangeTransaction.getRecordIdentifier().getValue());

        // intlIrTranDto.setIntlRegNo(irMHRChangeTransaction.getInternationalRegistrationNumber());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irOwnershipChangeTotalService
            .processInboundTransaction(intlIrTranDto, irMHRChangeTransaction);

        assertTrue(null != notificationTypes);

        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType taskType : notifications) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.TOTAL_OWNERSHIP_CHANGED_OCCURRED
                    || taskType == UserTaskType.ADDRESS_EXCEEDED_LIMIT
                    || taskType == UserTaskType.REPRESENTATIVE_COURTESY_LETTER
                    || taskType == UserTaskType.UPDATE_ADDRESS_CREATE_COURTESYLATTER);
            }
        }

        Set<InterestedParty> party = application.getInterestedParties();
        for (InterestedParty p : party) {
            Set<InterestedPartiesAddresses> pas = p.getContact().getInterestedPartiesAddresses();
            for (InterestedPartiesAddresses pa : pas) {
                String address = pa.getAddress();
                int type = pa.getAddressType().intValue();

                System.out.println(address + ", type: " + pa.getAddressType().intValue());
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestIrCOTWithCorrespondenceAddress()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // IR Change Ownership total
        MadridHolderRepresentativeChangeType irMHRChangeTransaction = getMadridHolderRepresentativeChangeCAdress();
        intlIrTranDto.setIntlRecordId(irMHRChangeTransaction.getRecordIdentifier().getValue());

        // intlIrTranDto.setIntlRegNo(irMHRChangeTransaction.getInternationalRegistrationNumber());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irOwnershipChangeTotalService
            .processInboundTransaction(intlIrTranDto, irMHRChangeTransaction);

        assertTrue(null != notificationTypes);

        verifyInterestPartyAddress(application);
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private IntlIrTranDto setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MHR_CHANGE_OF_OWNER.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MHR_CHANGE_OF_OWNER.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        return intlIrTranDto;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private static JAXBContext initHolderRepresentativeChange() {
        try {
            return JAXBContext.newInstance(MadridHolderRepresentativeChangeType.class,
                MadridHolderRepresentativeChangeType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBHolderRepresentativeChangeContext instance", e);
        }
        return null;

    }
}
