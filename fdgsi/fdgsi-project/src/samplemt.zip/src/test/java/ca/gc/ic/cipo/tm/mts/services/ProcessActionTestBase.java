package ca.gc.ic.cipo.tm.mts.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.common.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.ClassificationKindCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory;
import ca.gc.ic.cipo.common.service.CalendarUtils;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.TMInfoRetrievalDto;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.common.ContactType;
import ca.gc.ic.cipo.xmlschema.common.NameType;
import ca.gc.ic.cipo.xmlschema.common.NationalCorrespondentType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressBagType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressType;
import ca.gc.ic.cipo.xmlschema.common.UnstructuredPostalAddressType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.ApplicationStatusType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClassificationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesStatementType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.StatementSourceCategoryType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.StatementType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TMInterestedPartyType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationDetailsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsType;

public abstract class ProcessActionTestBase {

    private static final Logger log = LoggerFactory.getLogger(ProcessActionTestBase.class);

    private static final JAXBContext jaxbMadridDesignationContext = initMadridContext();

    private static Integer MADRID_APPLICATION_REGISTERED = 2;

    protected TMInfoRetrievalDto initTIRSResult(Integer fileNumber) {

        TMInfoRetrievalDto tmInfoRetrievalBean = new TMInfoRetrievalDto();

        // TrademarkApplicationType
        TrademarkApplicationType trademarkApplicationType = new TrademarkApplicationType();
        ApplicationNumber an = new ApplicationNumber();
        an.setFileNumber(fileNumber);
        an.setExtensionCounter(0);
        trademarkApplicationType.setApplicationNumber(an);

        ApplicationStatusType ast = new ApplicationStatusType();
        ast.setApplicationStatusCode(2);
        trademarkApplicationType.setApplicationStatus(ast);
        trademarkApplicationType.setFilingDate(CalendarUtils.toXMLCalendar(new java.sql.Date(new Date().getTime())));

        // tmInterestedPartyTypeList
        NameType nameType = new NameType();
        nameType.setEntityName("SPRATTS PATENT & LIMITED COMPANY");
        List<TMInterestedPartyType> tmInterestedPartyTypeList = new ArrayList<>();
        TMInterestedPartyType tmInterestedPartyType = new TMInterestedPartyType();
        ContactType contactType = new ContactType();
        contactType.setName(nameType);

        PostalAddressBagType postalAddressBagType = new PostalAddressBagType();
        PostalAddressType postalAddressType = new PostalAddressType();
        postalAddressType.setPostalCode("asdf");

        UnstructuredPostalAddressType unstructuredPostalAddressType = new UnstructuredPostalAddressType();
        unstructuredPostalAddressType.setExtendedISOCountryCode("GB");
        unstructuredPostalAddressType.setCipoPostalAddressCategory("Home");
        unstructuredPostalAddressType
            .setUnstructuredAddress("SPRATTS PATENT LIMITED COMPANY 58 MARKLANE LONDON, ENGLAND UNITED KINGDOM");

        postalAddressBagType.getUnstructuredPostalAddress().add(unstructuredPostalAddressType);
        contactType.setPostalAddressBag(postalAddressBagType);

        tmInterestedPartyType.setContact(contactType);

        tmInterestedPartyType.setName(nameType);
        tmInterestedPartyTypeList.add(tmInterestedPartyType);

        tmInfoRetrievalBean.setTrademarkApplicationType(trademarkApplicationType);
        tmInfoRetrievalBean.setTmInterestedPartyTypeList(tmInterestedPartyTypeList);

        // TrademarkApplicationDetailsType
        TrademarkApplicationDetailsType trademarkApplicationDetailsType = new TrademarkApplicationDetailsType();
        NationalCorrespondentType nationalCorrespondentType = new NationalCorrespondentType();
        nationalCorrespondentType.setApplicationLanguage(ISOLanguageCodeType.EN);
        trademarkApplicationDetailsType.setCorrespondenceDetails(nationalCorrespondentType);

        TrademarkDetailsType trademarkDetailsType = new TrademarkDetailsType();
        trademarkDetailsType.setMarkDescReference("SPRATTS FIBRINE DOG CAKES &amp; DESIGN");
        trademarkApplicationDetailsType.setTradmarkDetails(trademarkDetailsType);

        tmInfoRetrievalBean.setTrademarkApplicationDetailsType(trademarkApplicationDetailsType);

        // Goods and Services
        List<GoodsServicesType> goodsAndServices = new ArrayList<>();
        GoodsServicesType goodsServicesType = new GoodsServicesType();
        GoodsServicesClassificationType goodsServicesClassificationType = new GoodsServicesClassificationType();
        goodsServicesClassificationType.setClassificationKind(ClassificationKindCategoryType.NICE);
        goodsServicesClassificationType.setClassNumber("11");
        LocalizedTextType localizedTextType = new LocalizedTextType();
        localizedTextType.setLanguageCode("en");
        localizedTextType.setValue(
            "Precious metals and their alloys;  jewellery, precious and semi-precious stones;  horological and chronometric instruments.");
        goodsServicesClassificationType.getClassHeadingDescriptions().add(localizedTextType);
        localizedTextType = new LocalizedTextType();
        localizedTextType.setLanguageCode("fr");
        localizedTextType.setValue(
            "Métaux précieux et leurs alliages;  joaillerie, bijouterie, pierres précieuses et semi précieuses;  horlogerie et instruments chronométriques.");
        goodsServicesClassificationType.getClassHeadingDescriptions().add(localizedTextType);
        goodsServicesClassificationType.setClassStatementType(StatementType.GOODS);
        goodsServicesType.setClassification(goodsServicesClassificationType);
        GoodsServicesStatementType goodsServicesStatementType = new GoodsServicesStatementType();
        localizedTextType = new LocalizedTextType();
        localizedTextType.setLanguageCode("en");
        localizedTextType.setValue(
            "Metallic salts and soaps in solid, paste and liquid form, useful alone and as an additive for a wide variety of purposes in the different arts where such products are useful, such as, fungicides, germicides, insecticides, driers, wetting agents, stabilizing agents, grinding aids, antichalking agents, bodying agents, antifouling agents, rust and corrosion inhibitants, lubricant additives, dispersing agents, non-penetrating agents, water repellants and catalysts, including oxidation catalysts, combustion catalysts for oils, candles, and smudge pots, and sprays to prevent smoking of coal during combustion; ink driers; driers for paste and ready-mixed paint, varnishes, and paint enamels, drier preservatives for driers for paste and ready-mixed paints, varnishes, and paint enamels, wetting and dispersing agents for pigmented coating materials, bodying agents for paste and ready-mixed paints, varnishes, paint enamels, and lacquers, and grinding agents for pigments and paste and ready-mixed paints, enamels and lacquers.");
        goodsServicesStatementType.setStatementDescription(localizedTextType);
        goodsServicesType.setStatement(goodsServicesStatementType);
        goodsServicesType.setStatementSourceCategory(StatementSourceCategoryType.CUSTOM);
        goodsAndServices.add(goodsServicesType);
        tmInfoRetrievalBean.setGoodsAndServices(goodsAndServices);

        return tmInfoRetrievalBean;
    }

    protected ProcessAction createProcessAction(Application application, Integer processCode,
                                                String wipoReferenceNumber, String irNumber, String additionalInfo) {

        ProcessAction processAction = new ProcessAction();
        processAction.setAdditionalInfo(additionalInfo);
        processAction.setApplication(application);
        processAction.setAuthorityId("MADRID");
        processAction.setExtensionCounter(0);
        processAction.setFileNumber(application.getFileNumber());
        processAction.setProcessCode(processCode);
        processAction.setProcessType(2);
        if (null != wipoReferenceNumber) {
            processAction.setWipoReferenceNumber(wipoReferenceNumber);
        }
        if (null != irNumber) {
            processAction.setIrNumber(irNumber);
        }

        return processAction;
    }

    protected MadridApplication createMadridApplication(Application application, String irNumber,
                                                        String wipoReferenceNumber) {

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber(irNumber);
        madridApplication.setWipoReferenceNumber(wipoReferenceNumber);
        madridApplication.setStatusCode(MADRID_APPLICATION_REGISTERED);

        // Create Madrid Application Xref
        MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
        madridApplicationXref.setMadridApplication(madridApplication);
        madridApplicationXref.setExtensionCounter(0);
        madridApplicationXref.setFileNumber(application.getFileNumber());
        madridApplicationXref.setWipoReferenceNumber(wipoReferenceNumber);

        madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);

        return madridApplication;
    }

    protected IntlIrTranDto createIntlIrTran(String intlRecordId, String intlRegNo) {
        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(intlRecordId);
        intlIrTranDto.setIntlRegNo(intlRegNo);

        return intlIrTranDto;
    }

    protected static JAXBContext initMadridContext() {
        try {

            return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid",
                ObjectFactory.class.getClassLoader());

        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridContext instance", e);
        }
        return null;

    }

    protected MadridDesignationType getMadridTransaction(String xmlFileName)
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource(xmlFileName));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    public <T> T unmarshallTransaction(byte[] xml) throws JAXBException, SQLException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();

        ByteArrayInputStream input = new ByteArrayInputStream(xml);

        @SuppressWarnings("unchecked")
        JAXBElement<T> transactionType = (JAXBElement<T>) unmarshallerRoot.unmarshal(input);

        return transactionType.getValue();
    }
}
