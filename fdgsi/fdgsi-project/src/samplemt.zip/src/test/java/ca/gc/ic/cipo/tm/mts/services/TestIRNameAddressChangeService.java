package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRNameAddressChangeService extends MadridTransactionTestBase {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRNameAddressChangeService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irHolderNameAddressChange")
    private IInboundTransaction irHolderNameAddressChangeService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbHolderRepresentativeChangeContext = initHolderRepresentativeChange();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-base-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getIRMadridHolderRepresentativeChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbHolderRepresentativeChangeContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridHolderRepresentativeChange-NameAddress.xml"));
        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridDesignationElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getCorrespondenceAddressChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbHolderRepresentativeChangeContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridHolderRepresentativeChange-NAddressAndCAddress.xml"));
        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridDesignationElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getMadridHolderRepresentativeChangeTransaction_1095()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbHolderRepresentativeChangeContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridChange-NameAddress_TMMADCON-1095.xml"));
        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridDesignationElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestNameAddressChange() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        // test Madrid Desination interest party and address
        verifyInterestPartyAddress(application);

        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // IR MadridHolderRepresentativeChangeType
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChange = getIRMadridHolderRepresentativeChangeTransaction();
        intlIrTranDto.setIntlRecordId(madridHolderRepresentativeChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, madridHolderRepresentativeChange);

        assertTrue(null != notificationTypes && notificationTypes.size() > 0);

        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType status : notifications) {
            if (null != status) {
                assertTrue(status == UserTaskType.REVIEW_OWNER_NAME
                    || status == UserTaskType.IR_HOLDER_NAME_ADDRESS_CHANGE_OCCURRED
                    || status == UserTaskType.ADDRESS_EXCEEDED_LIMIT);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Footnotes exist
        assertTrue(CollectionUtils.isNotEmpty(application.getFootnotes()));

        // test interest party and address
        verifyInterestPartyAddress(application);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean actionexists = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.AMENDMENT_TO_REGISTRATION.getValue())) {
                actionexists = true;
                break;
            }
        }
        assertTrue(actionexists);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        actionexists = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_IR_HOLDER_NAME_ADDRESS_CHANGE.getValue())) {
                // check case number.
                // assertTrue(processAction.getOppositionCaseNumber().intValue() == 10);
                actionexists = true;
                break;
            }
        }
        assertTrue(actionexists);

        // Verify Opposition Cases
        assertTrue(application.getOppositionCases().size() == 1);

        // Footnote
        Set<Footnote> footnotes = application.getFootnotes();
        for (Footnote footnote : footnotes) { // Wed Mar 15 00:00:00 EDT 2017
            Date ftDate = footnote.getDateOfChange();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(ftDate);

            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH) + 1;
            int year = calendar.get(Calendar.YEAR);

            assertTrue(day == 15);
            assertTrue(month == 3);
            assertTrue(year == 2017);

            assertTrue(footnote.getType().intValue() == FootnoteType.NAME_AND_ADDRESS.getValue());
            assertTrue(footnote.getText() != null);
            System.out.println(footnote.getText());// ("From: Cato Networks Ltd.; Norris, Michele L. To: The Bridge
                                                   // S.p.A."));
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestPendingTotalCancellation()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // IR MadridHolderRepresentativeChangeType
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChange = getIRMadridHolderRepresentativeChangeTransaction();
        intlIrTranDto.setIntlRecordId(madridHolderRepresentativeChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, madridHolderRepresentativeChange);

        assertTrue(null != notificationTypes && notificationTypes.size() > 0);

        Collection<UserTaskType> notifications = notificationTypes.values();
        for (UserTaskType status : notifications) {
            if (null != status) {
                assertTrue(status == UserTaskType.REVIEW_OWNER_NAME
                    || status == UserTaskType.IR_HOLDER_NAME_ADDRESS_CHANGE_OCCURRED
                    || status == UserTaskType.ADDRESS_EXCEEDED_LIMIT);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean actionExist = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.AMENDMENT_TO_APPLICATION.getValue())) {
                actionExist = true;
                break;
            }
        }
        assertTrue(actionExist);

        // Verify Process Actions
        assertTrue(application.getProcessActions().size() > 0);
        actionExist = false;
        Iterator<ProcessAction> pactionsIterator = application.getProcessActions().iterator();
        while (pactionsIterator.hasNext()) {
            ProcessAction processAction = pactionsIterator.next();
            if (processAction.getProcessCode()
                .equals(ProcessActionsType.PRINT_IR_HOLDER_NAME_ADDRESS_CHANGE.getValue())) {
                // check case number.
                // assertTrue(processAction.getOppositionCaseNumber().intValue() == 10);
                actionExist = true;
                break;
            }
        }
        assertTrue(actionExist);

        // Verify Opposition Cases
        assertTrue(application.getOppositionCases().size() == 1);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void testQABugTMMADCON1095() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // IR MadridHolderRepresentativeChangeType
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChange = getMadridHolderRepresentativeChangeTransaction_1095();
        intlIrTranDto.setIntlRecordId(madridHolderRepresentativeChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, madridHolderRepresentativeChange);

        assertTrue(null != notificationTypes && notificationTypes.size() > 0);

        // test interest party and address
        verifyInterestPartyAddress(application);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestNameAddrChangeWithCorrespondenceAddr()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE an application with opposition cases
        MadridDesignationType madridDesignation = getMadridTransaction();

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        // test Madrid Desination interest party and address
        verifyInterestPartyAddress(application);

        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        // IR MadridHolderRepresentativeChangeType
        MadridHolderRepresentativeChangeType madridHolderRepresentativeChange = getCorrespondenceAddressChangeTransaction();
        intlIrTranDto.setIntlRecordId(madridHolderRepresentativeChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        Map<ApplicationDto, UserTaskType> notificationTypes = irHolderNameAddressChangeService
            .processInboundTransaction(intlIrTranDto, madridHolderRepresentativeChange);

        assertTrue(null != notificationTypes && notificationTypes.size() > 0);

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // test interest party and address
        verifyInterestPartyAddress(application);
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private IntlIrTranDto setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();
        ptt.setTranCtgry(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.name());
        ptt.setPkgTranCtgryId(TransactionCategory.MHR_CHANGE_OF_HOLDER_NAME_ADDRESS.toNumber());
        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        return intlIrTranDto;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

    private static JAXBContext initHolderRepresentativeChange() {
        try {
            return JAXBContext.newInstance(MadridHolderRepresentativeChangeType.class,
                MadridHolderRepresentativeChangeType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBHolderRepresentativeChangeContext instance", e);
        }
        return null;
    }
}
