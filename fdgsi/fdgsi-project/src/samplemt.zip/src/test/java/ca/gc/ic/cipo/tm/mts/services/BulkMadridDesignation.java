package ca.gc.ic.cipo.tm.mts.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.InboundTransactionService;

//
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:database.properties", ignoreResourceNotFound = false)})
@ContextConfiguration(locations = {"classpath:junit-ttmModelDaoContext.xml",
    "classpath:junit-idIntlModelDaoContext.xml"})
public class BulkMadridDesignation { // extends AbstractTransactionalJUnit4SpringContextTests {

    @Autowired
    private InboundTransactionService madridDesignationService;

    Map<Integer, String> designations = new HashMap<>();

    private static final Logger log = LoggerFactory.getLogger(BulkMadridDesignation.class);

    @Before
    public void setUp() {
        // designations.put(52365, "1349219"); done
        // designations.put(52338, "1349175"); done
        // designations.put(52339, "1349176"); done
        // designations.put(52340, "1349177"); done
        // designations.put(52341, "1349178"); done
        // designations.put(52342, "1349179"); done
        // designations.put(52345, "1349187"); done
        // designations.put(52346, "1349188");done
        // designations.put(52356, "1349202");done

        // designations.put(52357, "1349203"); // done. After processing, I changed the reg no in Intrepid to match a
        // Process IR Ceasing of Effect Partial - from 1349203 to 1172619

        designations.put(155746, "1273648");
        // designations.put (52359,"1349209");
        // designations.put (52360,"1349210");
        // designations.put (52362,"1349214");
        // designations.put (52363,"1349216");
        // designations.put (52364,"1349218");
        // designations.put (52366,"1349221");
        // designations.put (52367,"1349224");
        // designations.put (52368,"1349226");
        // designations.put (52370,"1349230");
        // designations.put (52371,"1349231");
        // designations.put (52373,"1349233");
        // designations.put (52374,"1349235");
        // designations.put (52375,"1349237");
        // designations.put (52376,"1349238");
        // designations.put (52377,"1349239");
        // designations.put (52381,"1349243");
        // designations.put (52388,"1349252");
        // designations.put (52389,"1349256");
        // designations.put (52390,"1349257");
        // designations.put (52394,"1349269");
        // designations.put (52397,"1349283");
        // designations.put (52398,"1349284");
        // designations.put (52399,"1349288");
        // designations.put (52400,"1349289");
        // designations.put (52401,"1349290");
        // designations.put (52403,"1349294");
        // designations.put (52405,"1349296");
        // designations.put (52406,"1349300");
        // designations.put (52408,"1349306");
        // designations.put (52409,"1349307");
        // designations.put (52410,"1349309");
        // designations.put (52411,"1349311");
        // designations.put (52412,"1349312");
        // designations.put (52413,"1349314");
        // designations.put (52414,"1349316");
        // designations.put (52415,"1349317");
        // designations.put (52416,"1349319");
        // designations.put (52417,"1349322");
        // designations.put (52418,"1349323");
        // designations.put (52420,"1349329");
        // designations.put (52421,"1349330");
        // designations.put (52422,"1349331");
        // designations.put (52423,"1349332");
        // designations.put (52428,"1349337");
        // designations.put (52429,"1349339");
        // designations.put (52430,"1349340");
        // designations.put (52431,"1349341");
        // designations.put (52432,"1349345");
        // designations.put (52433,"1349349");
        // designations.put (52434,"1349350");
        // designations.put (52435,"1349351");
        // designations.put (52439,"1349356");
        // designations.put (52440,"1349357");
        // designations.put (52441,"1349359");
        // designations.put (52446,"1349372");
        // designations.put (52447,"1349373");
        // designations.put (52450,"1349376");
        // designations.put (52451,"1349377");
        // designations.put (52448,"1349374");
        // designations.put (52449,"1349375");
        // designations.put (52452,"1349380");
        // designations.put (52453,"1349381");
        // designations.put (52454,"1349382");
        // designations.put (52455,"1349384");
        // designations.put (52456,"1349385");
        // designations.put (52457,"1349386");
        // designations.put (52458,"1349387");
        // designations.put (52459,"1349388");
        // designations.put (52460,"1349391");
        // designations.put (52462,"1349396");
        // designations.put (52463,"1349397");
        // designations.put (52464,"1349398");
        // designations.put (52465,"1349401");
        // designations.put (52466,"1349402");
        // designations.put (52467,"1349404");
        // designations.put (52469,"1349407");
        // designations.put (52470,"1349408");
        // designations.put (52476,"1349415");
        // designations.put (52480,"1349419");
        // designations.put (52486,"1349429");
        // designations.put (52487,"1349430");
        // designations.put (52488,"1349433");
        // designations.put (52489,"1349434");
        // designations.put (52490,"1349438");
        // designations.put (52491,"1349442");
        // designations.put (52492,"1349447");
        // designations.put (52493,"1349449");
        // designations.put (52494,"1349450");
        // designations.put (51827,"1348330");
        // designations.put (51828,"1348334");
        // designations.put (51829,"1348335");
        // designations.put (51830,"1348339");
        // designations.put (51831,"1348341");
        // designations.put (51832,"1348343");
        // designations.put (51833,"1348344");
        // designations.put (51834,"1348345");
        // designations.put (51835,"1348348");
        // designations.put (51836,"1348349");
        // designations.put (51839,"1348355");
        // designations.put (51840,"1348357");
        // designations.put (51866,"1348409");
        // designations.put (51841,"1348358");
        // designations.put (51843,"1348360");
        // designations.put (51844,"1348362");
        // designations.put (51845,"1348364");
        // designations.put (51846,"1348366");
        // designations.put (51847,"1348367");
        // designations.put (51848,"1348368");
        // designations.put (51849,"1348369");
        // designations.put (51850,"1348370");
        // designations.put (51851,"1348371");
        // designations.put (51852,"1348372");
        // designations.put (51853,"1348374");
        // designations.put (51854,"1348380");
        // designations.put (51855,"1348381");
        // designations.put (51856,"1348382");
        // designations.put (51858,"1348384");
        // designations.put (51860,"1348389");
        // designations.put (51863,"1348403");
        // designations.put (51864,"1348406");
        // designations.put (51865,"1348408");
        // designations.put (51867,"1348415");
        // designations.put (51868,"1348418");
        // designations.put (51869,"1348419");
        // designations.put (51870,"1348420");
        // designations.put (51871,"1348421");
        // designations.put (51872,"1348422");
        // designations.put (51873,"1348426");
        // designations.put (51874,"1348427");
        // designations.put (51875,"1348429");
        // designations.put (51876,"1348430");
        // designations.put (51878,"1348439");
        // designations.put (51883,"1348445");
        // designations.put (51884,"1348447");
        // designations.put (51885,"1348448");
        // designations.put (51886,"1348450");
        // designations.put (51888,"1348452");
        // designations.put (51889,"1348453");
        // designations.put (51890,"1348454");
        // designations.put (51891,"1348456");
        // designations.put (51892,"1348457");
        // designations.put (51894,"1348461");
        // designations.put (51898,"1348465");
        // designations.put (51900,"1348467");
        // designations.put (51901,"1348469");
        // designations.put (51902,"1348471");
        // designations.put (51905,"1348475");
        // designations.put (51906,"1348476");
        // designations.put (51907,"1348480");
        // designations.put (51909,"1348484");
        // designations.put (51910,"1348486");
        // designations.put (51912,"1348496");
        // designations.put (51913,"1348497");
        // designations.put (51914,"1348498");
        // designations.put (51915,"1348499");
        // designations.put (51917,"1348501");
        // designations.put (51919,"1348504");
        // designations.put (51922,"1348507");
        // designations.put (51923,"1348508");
        // designations.put (51924,"1348509");
        // designations.put (51925,"1348510");
        // designations.put (51930,"1348515");
        // designations.put (51931,"1348516");
        // designations.put (51932,"1348517");
        // designations.put (51933,"1348520");
        // designations.put (51935,"1348522");
        // designations.put (51940,"1348528");
        // designations.put (51941,"1348529");
        // designations.put (51944,"1348532");
        // designations.put (51945,"1348534");
        // designations.put (51947,"1348541");
        // designations.put (51953,"1348554");
        // designations.put (51954,"1348556");
        // designations.put (51951,"1348546");
        // designations.put (51952,"1348549");
        // designations.put (51955,"1348561");
        // designations.put (51956,"1348564");
        // designations.put (51959,"1348571");
        // designations.put (51960,"1348573");
        // designations.put (51961,"1348574");
        // designations.put (51962,"1348575");
        // designations.put (51963,"1348576");
        // designations.put (51964,"1348580");
        // designations.put (51965,"1348581");
        // designations.put (51966,"1348582");
        // designations.put (51970,"1348592");
        // designations.put (51971,"1348593");
        // designations.put (51972,"1348595");
        // designations.put (51973,"1348596");
        // designations.put (51974,"1348598");
        // designations.put (51975,"1348599");
        // designations.put (51976,"1348600");
        // designations.put (51977,"1348601");
        // designations.put (51981,"1348613");
        // designations.put (51982,"1348614");
        // designations.put (51983,"1348615");
        // designations.put (51984,"1348622");
        // designations.put (51985,"1348625");
        // designations.put (51986,"1348632");
        // designations.put (51990,"1348636");
        // designations.put (51992,"1348638");
        // designations.put (51994,"1348642");
        // designations.put (51995,"1348644");
        // designations.put (51997,"1348647");
        // designations.put (51998,"1348648");
        // designations.put (51999,"1348650");
        // designations.put (52000,"1348651");
        // designations.put (52001,"1348653");
        // designations.put (52002,"1348655");
        // designations.put (52004,"1348661");
        // designations.put (52006,"1348664");
        // designations.put (52539,"0387945");
        // designations.put (52540,"0427081");
        // designations.put (52541,"0427674");
        // designations.put (52542,"0466809");
        // designations.put (52543,"0511891");
        // designations.put (52544,"0633539");
        // designations.put (52545,"0653441");
        // designations.put (52546,"0659519");
        // designations.put (52547,"0666233");
        // designations.put (52548,"0849540");
        // designations.put (52549,"0864678");
        // designations.put (52551,"0907614");
        // designations.put (52552,"0926246A");
        // designations.put (52009,"1348667");
        // designations.put (52010,"1348669");
        // designations.put (52007,"1348665");
        // designations.put (52008,"1348666");
        // designations.put (52011,"1348670");
        // designations.put (52012,"1348671");
        // designations.put (52013,"1348672");
        // designations.put (52014,"1348673");
        // designations.put (52015,"1348674");
        // designations.put (52016,"1348676");
        // designations.put (52019,"1348679");
        // designations.put (52021,"1348681");
        // designations.put (52025,"1348690");
        // designations.put (52026,"1348691");
        // designations.put (52027,"1348692");
        // designations.put (52028,"1348694");
        // designations.put (52029,"1348701");
        // designations.put (52030,"1348702");
        // designations.put (52034,"1348711");
        // designations.put (52046,"1348723");
        // designations.put (52047,"1348725");
        // designations.put (52048,"1348728");
        // designations.put (52049,"1348732");
        // designations.put (52050,"1348734");
        // designations.put (52051,"1348736");
        // designations.put (52052,"1348741");
        // designations.put (52053,"1348742");
        // designations.put (52054,"1348743");
        // designations.put (52055,"1348744");
        // designations.put (52056,"1348746");
        // designations.put (52059,"1348752");
        // designations.put (52060,"1348753");
        // designations.put (52061,"1348754");
        // designations.put (52062,"1348755");
        // designations.put (52556,"1248441");
        // designations.put (52557,"1264679");
        // designations.put (52558,"1291353");
        // designations.put (52559,"1313303");
        // designations.put (52560,"1335489");
        // designations.put (52561,"1335490");
        // designations.put (52562,"1340268");
        // designations.put (52563,"1342509");
        // designations.put (52564,"1344264");
        // designations.put (52565,"1344432");
        // designations.put (52566,"1344921");
        // designations.put (52064,"1348757");
        // designations.put (52065,"1348758");
        // designations.put (52063,"1348756");
        // designations.put (52067,"1348760");
        // designations.put (52068,"1348762");
        // designations.put (52069,"1348763");
        // designations.put (52070,"1348764");
        // designations.put (52071,"1348765");
        // designations.put (52072,"1348766");
        // designations.put (52073,"1348767");
        // designations.put (52074,"1348768");
        // designations.put (52075,"1348770");
        // designations.put (52077,"1348772");
        // designations.put (52078,"1348774");
        // designations.put (52079,"1348775");
        // designations.put (52080,"1348776");
        // designations.put (52081,"1348779");
        // designations.put (52083,"1348792");
        // designations.put (52084,"1348793");
        // designations.put (52085,"1348794");
        // designations.put (52086,"1348795");
        // designations.put (52087,"1348796");
        // designations.put (52088,"1348800");
        // designations.put (52089,"1348801");
        // designations.put (52092,"1348806");
        // designations.put (52093,"1348807");
        // designations.put (52094,"1348810");
        // designations.put (52095,"1348812");
        // designations.put (52097,"1348815");
        // designations.put (52098,"1348816");
        // designations.put (52099,"1348817");
        // designations.put (52100,"1348818");
        // designations.put (52101,"1348819");
        // designations.put (52102,"1348820");
        // designations.put (52103,"1348821");
        // designations.put (52104,"1348822");
        // designations.put (52106,"1348825");
        // designations.put (52107,"1348826");
        // designations.put (52108,"1348827");
        // designations.put (52109,"1348828");
        // designations.put (52110,"1348829");
        // designations.put (52111,"1348830");
        // designations.put (52112,"1348832");
        // designations.put (52114,"1348835");
        // designations.put (52115,"1348836");
        // designations.put (52116,"1348839");
        // designations.put (52117,"1348840");
        // designations.put (52118,"1348842");
        // designations.put (52120,"1348844");
        // designations.put (52121,"1348846");
        // designations.put (52125,"1348850");
        // designations.put (52126,"1348851");
        // designations.put (52127,"1348852");
        // designations.put (52128,"1348854");
        // designations.put (52129,"1348855");
        // designations.put (52131,"1348859");
        // designations.put (52132,"1348861");
        // designations.put (52133,"1348862");
        // designations.put (52134,"1348863");
        // designations.put (52135,"1348865");
        // designations.put (52136,"1348866");
        // designations.put (52137,"1348867");
        // designations.put (52138,"1348868");
        // designations.put (52139,"1348869");
        // designations.put (52140,"1348870");
        // designations.put (52142,"1348877");
        // designations.put (52143,"1348878");
        // designations.put (52144,"1348879");
        // designations.put (52147,"1348883");
        // designations.put (52148,"1348884");
        // designations.put (52149,"1348887");
        // designations.put (52150,"1348888");
        // designations.put (52153,"1348893");
        // designations.put (52154,"1348894");
        // designations.put (52156,"1348896");
        // designations.put (52157,"1348897");
        // designations.put (52160,"1348903");
        // designations.put (52163,"1348906");
        // designations.put (52164,"1348908");
        // designations.put (52165,"1348909");
        // designations.put (52166,"1348913");
        // designations.put (52167,"1348914");
        // designations.put (52168,"1348915");
        // designations.put (52172,"1348920");
        // designations.put (52173,"1348921");
        // designations.put (52174,"1348922");
        // designations.put (52175,"1348923");
        // designations.put (52177,"1348925");
        // designations.put (52178,"1348926");
        // designations.put (52180,"1348928");
        // designations.put (52181,"1348929");
        // designations.put (52183,"1348933");
        // designations.put (52185,"1348936");
        // designations.put (52186,"1348938");
        // designations.put (52187,"1348939");
        // designations.put (52194,"1348946");
        // designations.put (52196,"1348948");
        // designations.put (52197,"1348949");
        // designations.put (52198,"1348951");
        // designations.put (52200,"1348955");
        // designations.put (52202,"1348960");
        // designations.put (52205,"1348965");
        // designations.put (52206,"1348966");
        // designations.put (52207,"1348967");
        // designations.put (52208,"1348970");
        // designations.put (52209,"1348971");
        // designations.put (52210,"1348972");
        // designations.put (52211,"1348973");
        // designations.put (52212,"1348975");
        // designations.put (52213,"1348976");
        // designations.put (52214,"1348978");
        // designations.put (52215,"1348979");
        // designations.put (52216,"1348981");
        // designations.put (52217,"1348982");
        // designations.put (52218,"1348983");
        // designations.put (52219,"1348986");
        // designations.put (52222,"1348991");
        // designations.put (52223,"1348992");
        // designations.put (52224,"1348994");
        // designations.put (52225,"1348996");
        // designations.put (52227,"1349002");
        // designations.put (52228,"1349003");
        // designations.put (52229,"1349004");
        // designations.put (52230,"1349005");
        // designations.put (52231,"1349007");
        // designations.put (52232,"1349008");
        // designations.put (52233,"1349009");
        // designations.put (52237,"1349013");
        // designations.put (52239,"1349016");
        // designations.put (52243,"1349021");
        // designations.put (52246,"1349027");
        // designations.put (52248,"1349031");
        // designations.put (52249,"1349034");
        // designations.put (52263,"1349054");
        // designations.put (52264,"1349055");
        // designations.put (52265,"1349058");
        // designations.put (52266,"1349061");
        // designations.put (52267,"1349062");
        // designations.put (52269,"1349064");
        // designations.put (52270,"1349066");
        // designations.put (52271,"1349069");
        // designations.put (52272,"1349070");
        // designations.put (52273,"1349071");
        // designations.put (52274,"1349073");
        // designations.put (52275,"1349074");
        // designations.put (52276,"1349076");
        // designations.put (52277,"1349080");
        // designations.put (52278,"1349082");
        // designations.put (52279,"1349083");
        // designations.put (52280,"1349084");
        // designations.put (52281,"1349085");
        // designations.put (52282,"1349087");
        // designations.put (52292,"1349099");
        // designations.put (52293,"1349102");
        // designations.put (52283,"1349089");
        // designations.put (52284,"1349090");
        // designations.put (52285,"1349092");
        // designations.put (52286,"1349093");
        // designations.put (52287,"1349094");
        // designations.put (52288,"1349095");
        // designations.put (52289,"1349096");
        // designations.put (52290,"1349097");
        // designations.put (52291,"1349098");
        // designations.put (52298,"1349108");
        // designations.put (52299,"1349111");
        // designations.put (52301,"1349114");
        // designations.put (52302,"1349119");
        // designations.put (52303,"1349120");
        // designations.put (52304,"1349122");
        // designations.put (52305,"1349123");
        // designations.put (52306,"1349124");
        // designations.put (52307,"1349125");
        // designations.put (52308,"1349126");
        // designations.put (52309,"1349127");
        // designations.put (52310,"1349129");
        // designations.put (52311,"1349130");
        // designations.put (52313,"1349132");
        // designations.put (52314,"1349135");
        // designations.put (52315,"1349137");
        // designations.put (52316,"1349139");
        // designations.put (52317,"1349141");
        // designations.put (52318,"1349146");
        // designations.put (52319,"1349148");
        // designations.put (52320,"1349149");
        // designations.put (52321,"1349150");
        // designations.put (52322,"1349151");
        // designations.put (52324,"1349155");
        // designations.put (52325,"1349156");
        // designations.put (52327,"1349158");
        // designations.put (52328,"1349159");
        // designations.put (52329,"1349160");
        // designations.put (52330,"1349161");
        // designations.put (52331,"1349168");
        // designations.put (52332,"1349169");
        // designations.put (52333,"1349170");
        // designations.put (52334,"1349171");
        // designations.put (52335,"1349172");
        // designations.put (52336,"1349173");
        // designations.put (52337,"1349174");
    }

    @Test
    @Ignore
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    @Rollback(true)
    public void testProcessDesginations() {
        Set<Integer> keys = designations.keySet();

        // MadridTransactionService service = MadridTransactionServiceFactory
        // .createMadridTransactionClient("http://localhost:9080");

        Iterator<Integer> iterator = keys.iterator();

        while (iterator.hasNext()) {
            Integer intlTranId = iterator.next();
            log.debug("Processing transaction id:" + intlTranId);

            AutomaticProcessingCriteria automaticProcessingCriteria = new AutomaticProcessingCriteria();
            TransactionRequest transactionRequest = new TransactionRequest();
            transactionRequest.setIrTranId(BigDecimal.valueOf(intlTranId));
            automaticProcessingCriteria.setTransactionRequest(transactionRequest);

            AutomatedProcessResponse response = null;
            try {
                log.debug("Calling service processMadridDesignation");
                response = madridDesignationService
                    .processTransaction(automaticProcessingCriteria.getTransactionRequest());

                // response = service.processMadridDesignation(automaticProcessingCriteria);
            } catch (CIPOServiceFault e) {
                log.error("Error processing transactionId:" + intlTranId, e);
                continue;
            }
            if (null != response.getConsoleTaskBag()) {
                log.debug("Notifications found!");
            }
        }

    }
}
