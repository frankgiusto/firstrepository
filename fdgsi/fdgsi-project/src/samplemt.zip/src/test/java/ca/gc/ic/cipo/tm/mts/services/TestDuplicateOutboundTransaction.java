package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.IdentifierType;
import _int.wipo.standards.xmlschema.st96.common.madrid.NameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressBagType;
import _int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.IrregularityBagType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.IrregularityType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ResponsiblePartyCategoryType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.DuplicateIrregularResponse;
import ca.gc.ic.cipo.tm.mts.service.intl.IDuplicateTransaction;
import ca.gc.ic.cipo.xmlschema.common.UnstructuredPostalAddressType;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestDuplicateOutboundTransaction {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestDuplicateOutboundTransaction.class);

    @Autowired
    private IDuplicateTransaction duplicateTransaction;

    @Before
    @Transactional
    public void setUp() throws Exception {

        // MockitoAnnotations.initMocks(this);
        //
        // ReflectionTestUtils.setField(madridService, "intrepidCommonService", intrepidCommonService);
        //
        // MadridDesignationType madridDesignation = getMadridTransaction("/MadridDesignation-Process-Action-Base.xml");

        _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory objectFactory = new _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory();
        _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory commonObjectFactory = new _int.wipo.standards.xmlschema.st96.common.madrid.ObjectFactory();

        NameType nameType = commonObjectFactory.createNameType();
        nameType.getPersonNameOrOrganizationNameOrEntityName().add("SPRATTS PATENT & LIMITED COMPANY");
        // nameType.setEntityName("SPRATTS PATENT & LIMITED COMPANY");

        ContactType contactType = commonObjectFactory.createContactType();
        contactType.setName(nameType);

        OrderedTextType orderedTextType = commonObjectFactory.createOrderedTextType();
        orderedTextType.setValue("address");
        orderedTextType.setSequenceNumber("1");

        PostalAddressBagType postalAddressBagType = commonObjectFactory.createPostalAddressBagType();
        PostalAddressType postalAddressType = new PostalAddressType();
        postalAddressType.getPostalAddressText().add(orderedTextType);

        UnstructuredPostalAddressType unstructuredPostalAddressType = new UnstructuredPostalAddressType();
        unstructuredPostalAddressType.setExtendedISOCountryCode("GB");
        unstructuredPostalAddressType.setCipoPostalAddressCategory("Home");
        unstructuredPostalAddressType
            .setUnstructuredAddress("SPRATTS PATENT LIMITED COMPANY 58 MARKLANE LONDON, ENGLAND UNITED KINGDOM");
        contactType.setPostalAddressBag(postalAddressBagType);

        MadridIrregularityNotificationType irregularityNotitication = objectFactory
            .createMadridIrregularityNotificationType();
        irregularityNotitication.setApplicantFileReference("file reference");
        irregularityNotitication.setContact(contactType);
        irregularityNotitication.setInternationalRegistrationNumber("12345");

        IrregularityBagType irregularityBagType = objectFactory.createIrregularityBagType();
        objectFactory.createIrregularityBagType();
        IrregularityType irregularityType = objectFactory.createIrregularityType();
        // IRREGULARITYTYPE
        // .SETIRREGULARITYCONSEQUENCECATEGORY(IRREGULARITYCONSEQUENCECATEGORYTYPE.OBSERVATION_WITHOUT_CONSEQUENCE);
        irregularityType.setResponsiblePartyCategory(ResponsiblePartyCategoryType.APPLICANT);
        IdentifierType identifierType = new IdentifierType();
        identifierType.setValue("885540");
        irregularityType.setIrregularityIdenfier(identifierType);
        irregularityBagType.getIrregularity().add(irregularityType);

        irregularityNotitication.setIrregularityBag(irregularityBagType);
        irregularityNotitication
            .setMadridIrregularityNotificationCategory(MadridIrregularityNotificationCategoryType.APPLICATION);
        irregularityNotitication.setMailDate("2018/09/09");
        irregularityNotitication.setNotificationLanguage(ISOLanguageCodeType.CA);
        identifierType = new IdentifierType();
        identifierType.setValue("123");
        irregularityNotitication.setOfficeReferenceIdentifier(identifierType);
        identifierType = new IdentifierType();
        identifierType.setValue("885540");
        irregularityNotitication.setRecordIdentifier(identifierType);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void TestDuplicateTransaction() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // mf1: 691604
        // mf3a: 791981 , irreg: 885540

        DuplicateIrregularResponse response = duplicateTransaction
            .duplicateIrregularTransaction(BigDecimal.valueOf(885540), "MADRID");

        assertTrue(response != null);

    }

}
