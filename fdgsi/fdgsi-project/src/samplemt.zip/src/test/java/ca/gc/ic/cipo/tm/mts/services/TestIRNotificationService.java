package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridBasicRegistrationApplicationChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;
import ca.gc.ic.cipo.tm.schema.mfs.GoodsAndServicesClasses;
import ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.MadridFinancialTransactionCategoryType;

/**
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRNotificationService {

    private static final Logger log = LoggerFactory.getLogger(TestIRNotificationService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("irNotification")
    private IInboundTransaction irNotificationService;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridDesignationContext();

    private static final JAXBContext jaxbMadridBasicRegistrationApplicationChange = initBasicRegistrationApplicationChangeContext();

    @Before
    @Transactional
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        TMMadridFinancialFeeServicePortType madridFinancialFeeServiceClient = Mockito
            .mock(TMMadridFinancialFeeServicePortType.class);

        Mockito.when(
            (madridFinancialFeeServiceClient).calculateFee(Mockito.any(MadridFinancialTransactionCategoryType.class),
                Mockito.any(GoodsAndServicesClasses.class), Mockito.any(Date.class)))
            .thenReturn(new BigDecimal("123"));

        ReflectionTestUtils.setField(madridDesignationService, "madridFinancialFeeServiceClient",
            madridFinancialFeeServiceClient);
    }

    private MadridBasicRegistrationApplicationChangeType getMadridRegistrationApplicationChangeTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Notification-ApplicationChange.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridBasicRegistrationApplicationChangeType> madridProtectionRestrictioElement = (JAXBElement<MadridBasicRegistrationApplicationChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    private MadridHolderRepresentativeChangeType getHolderRepresentativeChangeCategoryTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-Notification-HPChange.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridHolderRepresentativeChangeType> madridProtectionRestrictioElement = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridProtectionRestrictioElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestIRNotification() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();

        IntlPkgTranTypeDto intlPkgTranTypeDto = new IntlPkgTranTypeDto();
        intlPkgTranTypeDto.setPkgTranCtgryId(
            BigDecimal.valueOf(TransactionCategory.MBR_APPLICATION_CHANGE.getTransactionCategoryId().intValue()));
        intlIrTranDto.setIntlPkgTranType(intlPkgTranTypeDto);

        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());
        intlIrTranDto.setIrTranId(BigDecimal.valueOf(8888888));

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        MadridBasicRegistrationApplicationChangeType applicationChange = getMadridRegistrationApplicationChangeTransaction();
        intlIrTranDto.setIntlRecordId(applicationChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto, 1);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        irNotificationService.processInboundTransaction(intlIrTranDto, applicationChange); // TODO

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean actionExist = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.IR_NOTIFICATION_FILED.getValue())) {
                actionExist = true;
                break;
            }
        }
        assertTrue(actionExist);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestIRNotificationWithHolderChange()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // Create a test application
        MadridDesignationType madridDesignation = getMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();

        IntlPkgTranTypeDto intlPkgTranTypeDto = new IntlPkgTranTypeDto();
        intlPkgTranTypeDto.setPkgTranCtgryId(
            BigDecimal.valueOf(TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE.getTransactionCategoryId().intValue()));
        intlIrTranDto.setIntlPkgTranType(intlPkgTranTypeDto);

        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        Map<ApplicationDto, UserTaskType> newApplication = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);
        ApplicationDto applicationDto = newApplication.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        MadridHolderRepresentativeChangeType holderChange = getHolderRepresentativeChangeCategoryTransaction();
        intlIrTranDto.setIntlRecordId(holderChange.getRecordIdentifier().getValue());
        intlIrTranDto.setIntlRegNo("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto, 2);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        irNotificationService.processInboundTransaction(intlIrTranDto, holderChange); // TODO

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean actionExist = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.IR_NOTIFICATION_FILED.getValue())) {
                actionExist = true;
                break;
            }
        }
        assertTrue(actionExist);

    }

    public MadridBasicRegistrationApplicationChangeType getBasicRegistrationApplicationChange()
        throws JAXBException, SQLException, FileNotFoundException {
        Unmarshaller unmarshallerRoot = jaxbMadridBasicRegistrationApplicationChange.createUnmarshaller();

        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridInternationalRegistration.xml"));
        @SuppressWarnings("unchecked")
        JAXBElement<MadridBasicRegistrationApplicationChangeType> madridElement = (JAXBElement<MadridBasicRegistrationApplicationChangeType>) unmarshallerRoot
            .unmarshal(xml);

        return madridElement.getValue();
    }

    private MadridDesignationType getMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private void setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto, int testNum) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();

        if (testNum == 2) {
            ptt.setTranCtgry(TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE.name());
            ptt.setPkgTranCtgryId(TransactionCategory.MHR_CHANGE_OF_REPRESENTATIVE.toNumber());
        } else {
            ptt.setTranCtgry(TransactionCategory.MBR_APPLICATION_CHANGE.name());
            ptt.setPkgTranCtgryId(TransactionCategory.MBR_APPLICATION_CHANGE.toNumber());
        }

        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }
    }

    private static JAXBContext initBasicRegistrationApplicationChangeContext() {
        try {
            return JAXBContext.newInstance(MadridBasicRegistrationApplicationChangeType.class,
                MadridBasicRegistrationApplicationChangeType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting initRegistrationApplicationChangeContext instance", e);
        }
        return null;
    }

    private static JAXBContext initMadridDesignationContext() {
        try {
            return JAXBContext.newInstance(MadridDesignationType.class, MadridDesignationType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }
}
