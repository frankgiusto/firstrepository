package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.MadridTransactionType.TransactionCategory;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTaskDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgDto;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlPkgTranTypeDto;
import ca.gc.ic.cipo.tm.mts.dto.intrepid.ApplicationDto;
import ca.gc.ic.cipo.tm.mts.exception.MTSServiceFault;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 * The Class TestIntrepidService tests the automatic processing of madrid transactions.
 *
 * @author giustof
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestIRChangeOwnershipPartialService extends MadridTransactionTestBase {

    // public class TestPackage extends AbstractTransactionalJUnit4SpringContextTests {

    private static final Logger log = LoggerFactory.getLogger(TestIRChangeOwnershipPartialService.class);

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    @Qualifier("partialOwnershipChange")
    private IInboundTransaction irOwnershipChangePartialService;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    private static final JAXBContext jaxbMadridDesignationContext = initMadridPartialChangeOwnershipContext();

    private MadridDesignationType getCreateMadridTransaction() throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils.getFile(this.getClass().getResource("/MadridDesignation-base-D5.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridDesignationType> madridDesignationElement = (JAXBElement<MadridDesignationType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridPartialChangeOwnershipType getMadridPartialChangeOwnershipTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Combined-Partial-Ownership.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridPartialChangeOwnershipType> madridDesignationElement = (JAXBElement<MadridPartialChangeOwnershipType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridPartialChangeOwnershipType getMadridPartialChangeOwnershipTerminationTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Combined-Partial-Ownership-Termination.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridPartialChangeOwnershipType> madridDesignationElement = (JAXBElement<MadridPartialChangeOwnershipType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridPartialChangeOwnershipType getMadridPartialChangeOwnershipTerminationAddressTransaction()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Combined-Partial-Ownership-LargeAddress.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridPartialChangeOwnershipType> madridDesignationElement = (JAXBElement<MadridPartialChangeOwnershipType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    private MadridPartialChangeOwnershipType getPartialChangeOwnershipCorrespondenceAddress()
        throws JAXBException, FileNotFoundException {

        Unmarshaller unmarshallerRoot = jaxbMadridDesignationContext.createUnmarshaller();
        File xml = ResourceUtils
            .getFile(this.getClass().getResource("/MadridDesignation-Partial-Ownership-CorrespondenceAddress.xml"));

        @SuppressWarnings("unchecked")
        JAXBElement<MadridPartialChangeOwnershipType> madridDesignationElement = (JAXBElement<MadridPartialChangeOwnershipType>) unmarshallerRoot
            .unmarshal(xml);

        return madridDesignationElement.getValue();
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestValidateAddress() throws FileNotFoundException, JAXBException, MTSServiceFault {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlTransaction.setIntlPkg(intlPkgDto);
        intlTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Get MD Partial change of ownership Transaction
        MadridPartialChangeOwnershipType partialOwnershipTransaction = getMadridPartialChangeOwnershipTerminationAddressTransaction();

        Map<ApplicationDto, UserTaskType> notificationTypes = madridDesignationService
            .processInboundTransaction(intlTransaction, madridDesignation);

        ApplicationDto applicationDto = notificationTypes.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Create Opposition Case
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("8888888");
        partialOwnershipTransaction.getMadridDesignationTermination().setInternationalRegistrationNumber("8888888");

        setIntlIrTranDtoForMail(intlTransaction);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlTransaction.setIntlIrTaskList(activeTaskList);

        notificationTypes = irOwnershipChangePartialService.processInboundTransaction(intlTransaction,
            partialOwnershipTransaction);

        Collection<UserTaskType> notification = notificationTypes.values();

        assertTrue(notification.contains(UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED)
            || notification.contains(UserTaskType.ADDRESS_EXCEEDED_LIMIT)
            || notification.contains(UserTaskType.REPRESENTATIVE_COURTESY_LETTER)
            || notification.contains(UserTaskType.UPDATE_ADDRESS_CREATE_COURTESYLATTER));

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getIrNumber()
            .equals(partialOwnershipTransaction.getMadridDesignation().getInternationalRegistrationNumber()));
        assertTrue(CollectionUtils.isNotEmpty(application.getFootnotes()));

        Set<InterestedParty> interestedParties = application.getInterestedParties();
        // Should be 2 interested parties
        assertTrue(interestedParties.size() == 2);

        for (InterestedParty party : interestedParties) {
            // Intitial party relationship should now be Old Owner.
            if (party.getRelationshipType().intValue() == RelationshipType.OLD_OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Cato Networks Ltd.; Norris, Michele L."));
            }
            // New relationship type should be OWNER.
            if (party.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Aesthetic Center \"G-DERM\" LLC"));
            }
        }
        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean verified = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.PARTIAL_OWNERSHIP.getValue())) {
                verified = true;
                break;
            }
        }
        assertTrue(verified);

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestMadridProtectionRestrictionType()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlTransaction.setIntlPkg(intlPkgDto);
        intlTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Get MD Partial change of ownership Transaction
        MadridPartialChangeOwnershipType partialOwnershipTransaction = getMadridPartialChangeOwnershipTransaction();

        Map<ApplicationDto, UserTaskType> notificationTypes = madridDesignationService
            .processInboundTransaction(intlTransaction, madridDesignation);

        ApplicationDto applicationDto = notificationTypes.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("8888888");
        partialOwnershipTransaction.getMadridProtectionRestriction().setInternationalRegistrationNumber("8888888");

        setIntlIrTranDtoForMail(intlTransaction);

        // Add task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlTransaction.setIntlIrTaskList(activeTaskList);

        notificationTypes = irOwnershipChangePartialService.processInboundTransaction(intlTransaction,
            partialOwnershipTransaction);

        Collection<UserTaskType> notification = notificationTypes.values();
        for (UserTaskType taskType : notification) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.PARTIAL_OWNERSHIP_CHANGE_DESIGNATION_RESTRICTION);
            }
        }

    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestMadridDesignationTerminationTypeRegistered()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlTransaction.setIntlPkg(intlPkgDto);
        intlTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Get MD Partial change of ownership Transaction
        MadridPartialChangeOwnershipType partialOwnershipTransaction = getMadridPartialChangeOwnershipTerminationTransaction();

        Map<ApplicationDto, UserTaskType> notificationTypes = madridDesignationService
            .processInboundTransaction(intlTransaction, madridDesignation);

        ApplicationDto applicationDto = notificationTypes.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Create Opposition Case
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("8888888");
        partialOwnershipTransaction.getMadridDesignationTermination().setInternationalRegistrationNumber("8888888");

        setIntlIrTranDtoForMail(intlTransaction);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlTransaction.setIntlIrTaskList(activeTaskList);

        notificationTypes = irOwnershipChangePartialService.processInboundTransaction(intlTransaction,
            partialOwnershipTransaction);

        Collection<UserTaskType> notification = notificationTypes.values();
        for (UserTaskType taskType : notification) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getIrNumber()
            .equals(partialOwnershipTransaction.getMadridDesignation().getInternationalRegistrationNumber()));
        assertTrue(CollectionUtils.isNotEmpty(application.getFootnotes()));

        Set<InterestedParty> interestedParties = application.getInterestedParties();
        // Should be 2 interested parties
        assertTrue(interestedParties.size() == 2);

        for (InterestedParty party : interestedParties) {
            // Intitial party relationship should now be Old Owner.
            if (party.getRelationshipType().intValue() == RelationshipType.OLD_OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Cato Networks Ltd.; Norris, Michele L."));
            }
            // New relationship type should be OWNER.
            if (party.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Aesthetic Center \"G-DERM\" LLC"));
            }
        }
        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean verified = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.PARTIAL_OWNERSHIP.getValue())) {
                verified = true;
                break;
            }
        }
        assertTrue(verified);
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestMadridDesignationTerminationTypePending()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlTransaction.setIntlPkg(intlPkgDto);
        intlTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Get MD Partial change of ownership Transaction
        MadridPartialChangeOwnershipType partialOwnershipTransaction = getMadridPartialChangeOwnershipTerminationTransaction();

        Map<ApplicationDto, UserTaskType> notificationTypes = madridDesignationService
            .processInboundTransaction(intlTransaction, madridDesignation);

        ApplicationDto applicationDto = notificationTypes.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTRATION_PENDING.getValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Create Opposition Case

        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("8888888A");
        partialOwnershipTransaction.getMadridDesignationTermination().setInternationalRegistrationNumber("8888888");

        setIntlIrTranDtoForMail(intlTransaction);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlTransaction.setIntlIrTaskList(activeTaskList);

        notificationTypes = irOwnershipChangePartialService.processInboundTransaction(intlTransaction,
            partialOwnershipTransaction);

        Collection<UserTaskType> notification = notificationTypes.values();
        for (UserTaskType taskType : notification) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED);
            }
        }

        application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);

        assertTrue(application.getIrNumber().equals("8888888A"));
        assertTrue(!CollectionUtils.isEmpty(application.getFootnotes()));

        // Verify Action
        assertTrue(application.getActions().size() > 0);

        Iterator<Action> itt = application.getActions().iterator();
        boolean verified = false;
        while (itt.hasNext()) {
            Action action = itt.next();
            if (action.getActionCode().equals(ActionCode.PARTIAL_OWNERSHIP.getValue())) {
                verified = true;
                break;
            }
        }
        assertTrue(verified);

    }

    @Test
    @Ignore
    @Rollback(true)
    @Transactional
    public void TestPartialChangeOwnershipOO()
        throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlIrTranDto = new IntlIrTranDto();

        IntlPkgTranTypeDto intlPkgTranTypeDto = new IntlPkgTranTypeDto();
        intlPkgTranTypeDto.setPkgTranCtgryId(
            BigDecimal.valueOf(TransactionCategory.MBR_APPLICATION_CHANGE.getTransactionCategoryId().intValue()));
        intlIrTranDto.setIntlPkgTranType(intlPkgTranTypeDto);

        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlIrTranDto.setIntlPkg(intlPkgDto);
        intlIrTranDto.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Get MD Partial change of ownership Transaction
        MadridPartialChangeOwnershipType partialOwnershipTransaction = getMadridPartialChangeOwnershipTerminationTransaction();

        Map<ApplicationDto, UserTaskType> notificationTypes = madridDesignationService
            .processInboundTransaction(intlIrTranDto, madridDesignation);

        ApplicationDto applicationDto = notificationTypes.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());

        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("5555555");// 8888888A
        partialOwnershipTransaction.getMadridDesignationTermination().setInternationalRegistrationNumber("8888888");

        setIntlIrTranDtoForMail(intlIrTranDto);

        applicationDao.saveApplication(application);
        intlIrTranDto.setIntlRegNo(application.getIrNumber());

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlIrTranDto.setIntlIrTaskList(activeTaskList);

        notificationTypes = irOwnershipChangePartialService.processInboundTransaction(intlIrTranDto,
            partialOwnershipTransaction);

        Collection<UserTaskType> notification = notificationTypes.values();
        for (UserTaskType taskType : notification) {
            if (null != taskType) {
                assertTrue(taskType == UserTaskType.PARTIAL_OWNERSHIP_CHANGED_OCCURRED_OO);
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional
    public void TestCorrespondenceAddress() throws FileNotFoundException, JAXBException, MTSServiceFault {

        // CREATE a base application
        MadridDesignationType madridDesignation = getCreateMadridTransaction();
        madridDesignation.setInternationalRegistrationNumber("8888888");

        IntlIrTranDto intlTransaction = new IntlIrTranDto();
        IntlPkgDto intlPkgDto = new IntlPkgDto();
        intlPkgDto.setCreatedTmstmp(new Timestamp(new Date().getTime()));
        intlTransaction.setIntlPkg(intlPkgDto);
        intlTransaction.setIntlRecordId(madridDesignation.getRecordIdentifier().getValue());

        // Get MD Partial change of ownership Transaction
        MadridPartialChangeOwnershipType partialOwnershipTransaction = getPartialChangeOwnershipCorrespondenceAddress();

        Map<ApplicationDto, UserTaskType> notificationTypes = madridDesignationService
            .processInboundTransaction(intlTransaction, madridDesignation);

        ApplicationDto applicationDto = notificationTypes.keySet().iterator().next();

        Application application = applicationDao.getApplication(applicationDto.getFileNumber(), 0);
        application.setStatusCode(TradeMarkStatusType.REGISTERED.getValue());
        OppositionCase oppositionCase = createOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // Create Opposition Case
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        partialOwnershipTransaction.getMadridDesignation().setInternationalRegistrationNumber("8888888");
        partialOwnershipTransaction.getMadridDesignationTermination().setInternationalRegistrationNumber("8888888");

        setIntlIrTranDtoForMail(intlTransaction);

        // Add automated task record used by processing.
        List<IntlIrTaskDto> activeTaskList = new ArrayList<>();
        IntlIrTaskDto dto = new IntlIrTaskDto();
        dto.setFileNumber(application.getFileNumber());
        activeTaskList.add(dto);

        intlTransaction.setIntlIrTaskList(activeTaskList);

        notificationTypes = irOwnershipChangePartialService.processInboundTransaction(intlTransaction,
            partialOwnershipTransaction);

        Collection<UserTaskType> notification = notificationTypes.values();

        Set<InterestedParty> interestedParties = application.getInterestedParties();
        // Should be 2 interested parties
        assertTrue(interestedParties.size() == 2);

        for (InterestedParty party : interestedParties) {
            // Intitial party relationship should now be Old Owner.
            if (party.getRelationshipType().intValue() == RelationshipType.OLD_OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Cato Networks Ltd.; Norris, Michele L."));
            }
            // New relationship type should be OWNER.
            if (party.getRelationshipType().intValue() == RelationshipType.OWNER.getValue().intValue()) {
                assertTrue(party.getContact().getName().equals("Aesthetic Center \"G-DERM\" LLC"));
            }
        }

        verifyInterestPartyAddress(application);
    }

    private OppositionCase createOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.SECTION_44.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private OppositionCase createPendingOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private IntlIrTranDto setIntlIrTranDtoForMail(IntlIrTranDto intlIrTranDto) {
        IntlPkgTranTypeDto ptt = new IntlPkgTranTypeDto();

        int protectionCatgryId = TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION.toNumber().intValue();
        int originalTransCatgryId = TransactionCategory.DESIGNATION_TERMINATION.toNumber().intValue();
        if (intlIrTranDto.getIntlPkgTranType() != null) {
            originalTransCatgryId = intlIrTranDto.getIntlPkgTranType().getPkgTranCtgryId().intValue();
        }

        if (protectionCatgryId == originalTransCatgryId) {
            ptt.setTranCtgry(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION.name());
            ptt.setPkgTranCtgryId(TransactionCategory.DESIGNATION_PROTECTION_RESTRICTION.toNumber());
        } else {
            ptt.setTranCtgry(TransactionCategory.DESIGNATION_TERMINATION.name());
            ptt.setPkgTranCtgryId(TransactionCategory.DESIGNATION_TERMINATION.toNumber());
        }

        intlIrTranDto.setIntlPkgTranType(ptt);

        try {
            Timestamp stamp = new Timestamp(System.currentTimeMillis());
            intlIrTranDto.getIntlPkg().setCreatedTmstmp(stamp);
        } catch (Exception e) {
            fail();
        }

        return intlIrTranDto;
    }

    private static JAXBContext initMadridPartialChangeOwnershipContext() {
        try {
            return JAXBContext.newInstance(MadridPartialChangeOwnershipType.class,
                MadridPartialChangeOwnershipType.class);
        } catch (JAXBException e) {
            log.error("An error occurred while getting JAXBMadridDesignationContext instance", e);
        }
        return null;

    }

}
