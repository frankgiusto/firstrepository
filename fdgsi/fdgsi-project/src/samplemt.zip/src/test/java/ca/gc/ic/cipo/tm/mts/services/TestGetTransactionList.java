package ca.gc.ic.cipo.tm.mts.services;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;
import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.intl.dao.IntlIrTranDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgSchmaVrsnDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTranTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlPkgTypeDao;
import ca.gc.ic.cipo.tm.intl.dao.IntlStatusTypeDao;
import ca.gc.ic.cipo.tm.intl.model.IntlIrTran;
import ca.gc.ic.cipo.tm.intl.model.IntlPkg;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgSchmaVrsn;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgTranType;
import ca.gc.ic.cipo.tm.intl.model.IntlPkgType;
import ca.gc.ic.cipo.tm.intl.model.IntlStatusType;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.dto.intl.IInternationalDTOFactory;
import ca.gc.ic.cipo.tm.mts.dto.intl.IntlIrTranDto;
import ca.gc.ic.cipo.tm.mts.service.intl.IInternationalService;
import ca.gc.ic.cipo.tm.mts.service.intl.ibtooffice.IInboundTransaction;

/**
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@PropertySources({@PropertySource(value = "classpath:tm-database.properties", ignoreResourceNotFound = false)})
@TestPropertySource("classpath:madrid-test.properties")
@ContextConfiguration(locations = {"classpath:junit-idIntlModelDaoContext.xml",
    "classpath:junit-ttmModelDaoContext.xml"})
public class TestGetTransactionList {

    @Autowired
    @Qualifier("madridDesignation")
    private IInboundTransaction madridDesignationService;

    @Autowired
    private IntlPkgDao intlPkgDao;

    @Autowired
    private IntlStatusTypeDao intlStatusTypeDao;

    @Autowired
    private IntlPkgSchmaVrsnDao pkgSchmaVrsnDao;

    @Autowired
    private IntlPkgTranTypeDao intlPkgTranTypeDao;

    @Autowired
    private IntlPkgTypeDao intlPkgTypeDao;

    @Autowired
    private IInternationalService internationalService;

    @Autowired
    private IntlIrTranDao intlIrTranDao;

    @Autowired
    private IInternationalDTOFactory internationalDTOFactory;

    @Test
    @Rollback(true)
    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    public void testGetTransactionList() throws JAXBException, SQLException, CIPOServiceFault, FileNotFoundException {

        IntlIrTranDto intlIrTranDto = createTransaction();

        TransactionCriteria transactionCriteria = new TransactionCriteria();
        transactionCriteria.getPackageIdList().add(intlIrTranDto.getIntlPkg().getPkgId());

        List<TransactionDetail> transactions = internationalService.getTransactionList(transactionCriteria);

        assertTrue(!CollectionUtils.isEmpty(transactions));
    }

    @Transactional(value = "tmIntlTransactionManager", readOnly = false)
    private IntlIrTranDto createTransaction() throws SerialException, SQLException {

        IntlPkgType intlPkgType = new IntlPkgType();
        intlPkgType.setPkgCtgryId(new BigDecimal(877));
        intlPkgType.setPackageCtgry("test");
        intlPkgType.setDestnName("Inbound");
        intlPkgTypeDao.save(intlPkgType);

        IntlPkgSchmaVrsn pkgSchmaVrsn = new IntlPkgSchmaVrsn();

        pkgSchmaVrsn.setIntlPkgType(intlPkgType);
        pkgSchmaVrsn.setSchmaFileName("test");
        pkgSchmaVrsn.setVldFromDt(new Timestamp(System.currentTimeMillis()));
        pkgSchmaVrsnDao.save(pkgSchmaVrsn);

        IntlStatusType intlStatusType = new IntlStatusType();
        intlStatusType.setStatusCtgryId(new BigDecimal(453235));
        intlStatusType.setStatusCtgry("asdfasdf");
        intlStatusTypeDao.save(intlStatusType);

        IntlPkg intlPkg = new IntlPkg();

        // all 9 mandatory fields
        intlPkg.setIntlPkgType(intlPkgType);
        intlPkg.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlPkg.setIntlStatusType(intlStatusType);
        intlPkg.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlPkg.setIntlPblctnId("11/2017");
        intlPkg.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));
        Blob xmlFileContent = new SerialBlob("blob".getBytes());
        intlPkg.setXmlFileName("H201711.zip");
        intlPkg.setXmlFileContent(xmlFileContent);
        intlPkgDao.save(intlPkg);

        IntlPkgTranType intlPkgTranType = new IntlPkgTranType();
        intlPkgTranType.setPkgTranCtgryId(new BigDecimal(1000));
        intlPkgTranType.setTranCtgry("TEST");

        intlPkgTranTypeDao.save(intlPkgTranType);

        Blob xmlContent = new SerialBlob("blob".getBytes());

        IntlIrTran intlIrTran = new IntlIrTran();

        // all 7 mandatory fields plus pkg_id field
        intlIrTran.setIntlPkg(intlPkg);
        intlIrTran.setIntlPkgTranType(intlPkgTranType);
        intlIrTran.setIntlPkgSchmaVrsn(pkgSchmaVrsn);
        intlIrTran.setIntlStatusType(intlStatusType);
        intlIrTran.setIntlRegNo("WIPO40480");
        intlIrTran.setCreatedTmstmp(new Timestamp(System.currentTimeMillis()));
        intlIrTran.setXmlContent(xmlContent);

        // nullable fields
        Date intlRecordEfctvDt = new Date();
        intlRecordEfctvDt.getTime();

        intlIrTran.setIntlRecordId("852902001");
        intlIrTran.setIntlRecordEfctvDt(intlRecordEfctvDt);
        intlIrTran.setUpdatedTmstmp(new Timestamp(System.currentTimeMillis()));

        intlIrTran.setIntlRecordId("343535");
        intlIrTran.setIntlRegNo("8888888");

        intlIrTranDao.save(intlIrTran);

        return internationalDTOFactory.getIntlIrTranDto(intlIrTran);
    }

}
