# Madrid Workflow Engine (MWE)

## Project Information

The Madrid Workflow Engine is responsible for choreographing the business processing steps of an International Tradmark application according to the Madrid Treaty. The engine is built around the open-source Activtiti BPM project and supports BPMN 2.0 models. 

## Project Setup
This Maven project includes the typical EAR module and WAR module.

MWE is configured externally with a file called `TBD` which, by convention, should be on the WebSphere server's extended classpath -- typically `/cipo/config/TBD`. A sample copy of this configuration file is stored in the Git repository under `madrid-workflow-enging-webapp/config`. This file can be used as a starting point but it should be customized to fit the environment (ie. for local development) as needed.

MWE uses a common JDBC datasource that is used for various applications and services at CIPO. The datasource has the JNDI name: `jdbc/cipo/trademarks/tmds`. See one of the KEDC development servers for details on this datasource.

## Websphere Setup
This project requires the following resources to be configured on the Websphere server:

**JDBC Datasource**<br>
Name: MweActivitiDS<br>
URL(dev): jdbc:oracle:thin:@p8221.ic.gc.ca:1521:TMDEV0<br>
User/PW: INTL_TM_WORKFLOW_PRJT_DEV_USER / user
JNDI: jdbc/cipo/tm/intl/madrid/workflowDS<br>

**Timer Manager**<br>
Name: Madrid Timer Manager<br>
Number of threads: 10<br>
JNDI: tm/mwe<br>
 
**Work Manager**<br>
Name: Madrid Work Manager<br>
Alarm Threads: 2<br>
Min Threads: 0<br>
Max Threads: 100<br>
Thread Priority: 5<br>
Growable: TRUE<br>
JNDI: wm/mwe<br>
 

## Internal CIPO Dependencies (Release for Sprint 5)

* [MTS Client](https://asbscr.ic.gc.ca/scm/projects/CWP/repos/cipo-tm-madrid-transaction-service) (0.0.7)
* [MPS Client](https://asbscr.ic.gc.ca/scm/projects/CWP/repos/cipo-tm-madrid-package-service) (0.0.7)
* [TUPS Client](https://asbscr.ic.gc.ca/scm/projects/CWP/repos/cipo-tm-user-profile-service) (0.0.10)

[See list of released projects](https://wiki.ic.gc.ca/pages/viewpage.action?spaceKey=BSBPDT&title=Bill+C-31+and+Madrid+Web+Service+Release+Management)

## CIPO Projects Dependent on MWE Client

* [Madrid Console](https://asbscr.ic.gc.ca/scm/projects/CWP/repos/cipo-tm-madrid-console) 

## External Dependencies (non-CIPO libraries)
External dependencies are listed in the POM of the Web App (WAR).


## Build Information

* [Bamboo Builds](http://asbscr.ic.gc.ca/ci/browse/CIPODEPS)
* [Nexus Artifacts](https://asbscr.ic.gc.ca/maven-proxy/index.html#nexus-search;gav~ca.gc.ic.cipo.cipo-dependency~cipo-dependencies~~~)
* [Release Steps](http://jira.ic.gc.ca/browse/TMMADCON-659)

