package ca.gc.ised.cipo.tm.madrid.exception;

import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * @author J. Greene
 *
 */
public class BpmnWebServiceCallException extends Exception {

    BusinessErrorLogItem businessErrorLogItem;

    private static final long serialVersionUID = -8246572663336623798L;

    /**
     * @return the businessErrorLogItem
     */
    public BusinessErrorLogItem getBusinessErrorLogItem() {
        if (this.businessErrorLogItem == null) {
            this.businessErrorLogItem = new BusinessErrorLogItem();
        }
        return businessErrorLogItem;
    }

    /**
     * @param businessErrorLogItem the businessErrorLogItem to set
     */
    public void setBusinessErrorLogItem(BusinessErrorLogItem businessErrorLogItem) {
        this.businessErrorLogItem = businessErrorLogItem;
    }

    /**
     * @param message
     * @param cause
     */
    public BpmnWebServiceCallException(String message, Throwable cause) {
        super(message, cause);
        getBusinessErrorLogItem().setMessage(message);
    }

    /**
     * @param message
     */
    public BpmnWebServiceCallException(String message) {
        super(message);
        getBusinessErrorLogItem().setMessage(message);
    }

}
