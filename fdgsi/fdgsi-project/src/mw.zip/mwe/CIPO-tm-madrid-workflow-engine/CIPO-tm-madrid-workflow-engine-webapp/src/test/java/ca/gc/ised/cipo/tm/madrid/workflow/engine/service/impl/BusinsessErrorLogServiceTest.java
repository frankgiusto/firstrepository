package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.BusinessErrorLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Tests (lightly) the various DB functions in the business error log service.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:package_log_before.sql"),
    @Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:package_log_after.sql")})
public class BusinsessErrorLogServiceTest {

    @Autowired
    BusinessErrorLogDao dao;

    @Autowired
    BusinessErrorLogService businessErrorLogService;

    // @Before
    public void init() {
        // Uncomment @Before to test against the following oracle instance. Otherwise it will use an in-memory db.
        SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
        // dataSource.setDriverClass(oracle.jdbc.driver.OracleDriver.class);
        dataSource.setUrl("jdbc:oracle:thin:@p7217:1521:INDDEV0");
        dataSource.setUsername("INTL_ID_WORKFLOW_USER");
        dataSource.setPassword("INTL_ID_WORKFLOW_USER");

        dao.setDataSource(dataSource);
    }

    @Test
    public void testInsert() {
        System.out.println("#############################################");
        System.out.println("###                testInsert             ###");
        System.out.println("#############################################");
        BusinessErrorLogItem newItem = createGenericLogItem();

        businessErrorLogService.insertBusinessErrorLogEntry(newItem);

        assertNotNull(newItem.getBusinessErrorLogId());
    }

    @Test
    public void testPurgeOldRecords() {
        System.out.println("#############################################");
        System.out.println("###           testPurgeOldRecords         ###");
        System.out.println("#############################################");
        int i = 5;
        List<BusinessErrorLogItem> itemList = new ArrayList<>();
        for (int j = 0; j < i; j++) {
            BusinessErrorLogItem iteratedItem = createGenericLogItem();
            businessErrorLogService.insertBusinessErrorLogEntry(iteratedItem);
            itemList.add(iteratedItem);
        }

        businessErrorLogService.purgeOldBusinessErrorLogEntries(-2);

        int numNotFound = 0;
        for (BusinessErrorLogItem item : itemList) {
            BusinessErrorLogItem searchItem = new BusinessErrorLogItem();
            searchItem.setBusinessErrorLogId(item.getBusinessErrorLogId());
            List<BusinessErrorLogItem> itemFoundList = businessErrorLogService
                .getBusinessErrorLogItemsByFields(searchItem);
            if (itemFoundList.isEmpty()) {
                numNotFound++;
            }
        }
        assertEquals(numNotFound, i);
    }

    @SuppressWarnings("unused")
    @Test
    public void testQuery() {
        System.out.println("#############################################");
        System.out.println("###               testQuery               ###");
        System.out.println("#############################################");

        BusinessErrorLogItem searchableItem = createGenericLogItem();
        businessErrorLogService.insertBusinessErrorLogEntry(searchableItem);

        BusinessErrorLogItem queryItem1 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem2 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem3 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem4 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem5 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem6 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem7 = new BusinessErrorLogItem();
        BusinessErrorLogItem queryItem8 = new BusinessErrorLogItem();

        queryItem1.setBusinessErrorLogId(searchableItem.getBusinessErrorLogId());
        List<BusinessErrorLogItem> foundItem1 = businessErrorLogService.getBusinessErrorLogItemsByFields(queryItem1);
        assertFalse(foundItem1.isEmpty());

        queryItem2.setReasonCode(searchableItem.getReasonCode());
        List<BusinessErrorLogItem> foundItem2 = businessErrorLogService.getBusinessErrorLogItemsByFields(queryItem2);
        assertFalse(foundItem2.isEmpty());

        queryItem3.setReturnCode(searchableItem.getReturnCode());
        List<BusinessErrorLogItem> foundItem3 = businessErrorLogService.getBusinessErrorLogItemsByFields(queryItem3);
        assertFalse(foundItem3.isEmpty());

        queryItem4.setComponentAcronym(searchableItem.getComponentAcronym());
        List<BusinessErrorLogItem> foundItem4 = businessErrorLogService.getBusinessErrorLogItemsByFields(queryItem4);
        assertFalse(foundItem4.isEmpty());

        queryItem5.setProcessInstanceId(searchableItem.getProcessInstanceId());
        List<BusinessErrorLogItem> foundItem5 = businessErrorLogService.getBusinessErrorLogItemsByFields(queryItem5);
        assertFalse(foundItem5.isEmpty());

        // B.S. Item
        queryItem6.setBusinessErrorLogId(666L);
        List<BusinessErrorLogItem> foundItem6 = businessErrorLogService.getBusinessErrorLogItemsByFields(queryItem6);
        assertTrue(foundItem6.isEmpty());
    }

    protected BusinessErrorLogItem createGenericLogItem() {
        BusinessErrorLogItem genericBusinessErrorLogItem = new BusinessErrorLogItem();
        genericBusinessErrorLogItem.setMessage("Hey, this is a message!");
        genericBusinessErrorLogItem.setReasonCode(99L);
        genericBusinessErrorLogItem.setReturnCode(-1L);
        genericBusinessErrorLogItem.setComponentAcronym("DTF");
        genericBusinessErrorLogItem.setErrorMessageEn("English error message");
        genericBusinessErrorLogItem.setErrorMessageFr("French error message");
        genericBusinessErrorLogItem.setProcessInstanceId("HFFFFF");
        genericBusinessErrorLogItem.setProcessDefinitionName("Process Definition Name");
        return genericBusinessErrorLogItem;
    }
}
