package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;

import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * A transfer request creator strategy for creating a DTF transfer request for a Madrid irregularities package
 *
 * @author J. Greene
 *
 */
public class IrregularitiesTransferRequestCreator extends AbstractWipoInboundTransferRequestCreator {

    /** {@inheritDoc} */
    @Override
    protected String getDtfSite() {
        return getEnvironment().getProperty("mwe.dtf.madrid.site.name");
    }

    /** {@inheritDoc} */
    @Override
    protected void setParamCollection(List<TransferRequestParamXsd> paramList, DelegateExecution execution,
                                      DownloadLogItem lastDownloadLogItem) {
        TransferRequestParamXsd remoteDirParam = new TransferRequestParamXsd();
        remoteDirParam.setParameterCode(ParamNameCode.REMOTE_DIR.codeValue());
        remoteDirParam.setParameterValue(getEnvironment().getProperty("mwe.dtf.madrid.ftp.irregularities.dir.xml"));
        paramList.add(remoteDirParam);

        String fileNameParameter = execution.getVariable(ProcessFlowConstants.REMOTE_FILE_NAME, String.class);
        TransferRequestParamXsd fileRegexParam = new TransferRequestParamXsd();
        fileRegexParam.setParameterCode(ParamNameCode.FILE_REGEX.codeValue());
        if (StringUtils.isNotBlank(fileNameParameter)) {
            fileRegexParam.setParameterValue("(?i)" + fileNameParameter);
        } else {
            fileRegexParam.setParameterValue(getRemoteFileRegex(lastDownloadLogItem.getFileName(),
                getEnvironment().getProperty("mwe.irregularities.xml.regex")));
        }
        paramList.add(fileRegexParam);
    }

    protected String getRemoteFileRegex(String previousFileName, String regexForTransactionType) {
        StringBuilder remoteFileRegexBuilder = new StringBuilder("(?i)")
            .append(getEnvironment().getProperty("mwe.irregularities.xml.file.discriminator"));
        String remoteFileRegex = null;

        if (!previousFileName.matches(regexForTransactionType)) {
            throw new IllegalArgumentException("Invalid file name parameter.");
        }

        // Parse out the date info of the last file
        String yearString = previousFileName.substring(1, 3);
        String monthString = previousFileName.substring(3, 5);
        String dayString = previousFileName.substring(5, 7);
        int yearInt = Integer.parseInt(yearString);
        int monthInt = Integer.parseInt(monthString);
        int dayInt = Integer.parseInt(dayString);
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");

        calendar.set(yearInt, monthInt - 1, dayInt);
        calendar.add(Calendar.DATE, 1);

        remoteFileRegexBuilder.append(sdf.format(calendar.getTime()));
        remoteFileRegexBuilder.append(".ZIP");
        remoteFileRegex = remoteFileRegexBuilder.toString();

        return remoteFileRegex;
    }

}
