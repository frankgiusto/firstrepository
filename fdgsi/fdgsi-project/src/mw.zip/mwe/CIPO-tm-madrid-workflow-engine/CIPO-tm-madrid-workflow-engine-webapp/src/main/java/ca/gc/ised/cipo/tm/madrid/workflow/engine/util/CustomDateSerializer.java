package ca.gc.ised.cipo.tm.madrid.workflow.engine.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

/**
 * Date formatter for JSON.
 *
 * @author J. Greene
 *
 */
public class CustomDateSerializer extends StdSerializer<Date> {

    private static final long serialVersionUID = 3643131996848933944L;

    public CustomDateSerializer() {
        this(null);
    }

    protected CustomDateSerializer(Class<Date> t) {
        super(t);
    }

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss z");

    /** {@inheritDoc} */
    @Override
    public void serialize(Date value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeString(sdf.format(value));
    }

}
