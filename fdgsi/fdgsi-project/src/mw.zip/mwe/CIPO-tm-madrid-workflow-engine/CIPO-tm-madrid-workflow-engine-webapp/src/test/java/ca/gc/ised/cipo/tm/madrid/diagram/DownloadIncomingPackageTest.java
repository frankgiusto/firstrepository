package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DOWNLOAD_INCOMING_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DOWNLOAD_VERIFICATION_RETRY_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MOVE_VERIFICATION_POLL_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUTPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_TRANSFER_STATE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.STAGING_TRANSFER_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TR_CREATE_STATUS;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricDetail;
import org.activiti.engine.history.HistoricVariableUpdate;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestDownloadPackageServiceImpl;
import util.TestUtils;

/**
 * Test class for the download_madrid_package_from_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class DownloadIncomingPackageTest {

    protected Long verifRetrySeconds;

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    TestDownloadPackageServiceImpl testDownloadPackageServiceImpl;

    @After
    public void closeProcessEngine() {
        // Required, since all the other tests seem to do a specific drop on the
        // end
        processEngine.close();
    }

    @Before
    public void init() {
        verifRetrySeconds = 0L;
        testDownloadPackageServiceImpl.setCreateTransferRequestReturnObject(null);
        testDownloadPackageServiceImpl.setVerifyPackageTransferReturnObject(null);
        testDownloadPackageServiceImpl.setLoopIterationIncomplete(null);
        testDownloadPackageServiceImpl.setLoopIterationThrowError(null);
        testDownloadPackageServiceImpl.setStagingTransferReturnObject(null);
        testDownloadPackageServiceImpl.setTrCreateStatus(null);
    }

    /**
     * Nothing to transfer - Start, create transfer request, decision gate -> NOTHING_TO_DO, finish.
     *
     * No longer a valid test - download package regardless of prior status.
     */
    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/download_madrid_package_from_wipo.bpmn"})
    public void testPackageNothingToTransfer() {
        System.out.println("#############################################");
        System.out.println("###      testPackageNothingToTransfer     ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        // Fake the return values from the service bean
        testDownloadPackageServiceImpl.setTrCreateStatus(NOTHING_TO_DO);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_INCOMING_PACKAGE, runtimeService,
            processVariables);

        // Look for the process variables created in the history to get an idea
        // of the mockExecution path.
        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricDetail> activityDetails = historyService.createHistoricDetailQuery().variableUpdates()
            .processInstanceId(testInstance.getProcessInstanceId()).list();
        assertNotNull("No activity details for process instance " + testInstance.getProcessInstanceId(),
            activityDetails);

        // Two variables ("result variables" in the bpmn diagram) should have
        // been set by this path. Make sure they
        // were.
        for (HistoricDetail detail : activityDetails) {
            HistoricVariableUpdate varUpdate = (HistoricVariableUpdate) detail;
            if (varUpdate.getVariableName().equals(TR_CREATE_STATUS)) {
                System.out.println(varUpdate);
                assertEquals(NOTHING_TO_DO, varUpdate.getValue());
            }
            if (varUpdate.getVariableName().equals("transferRequestId")) {
                System.out.println(varUpdate);
                assertNotNull("Variable " + varUpdate.getVariableName() + " was not set", varUpdate.getValue());
            }
        }

    }

    /**
     * Error on package validation - Start, retrieve transfer request ID, wait, verify, decision gate -> ERROR, finish.
     */
    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/download_madrid_package_from_wipo.bpmn"})
    public void testPackageVerificationErrorHandling() {
        System.out.println("#############################################");
        System.out.println("### testPackageVerificationErrorHandling  ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        testDownloadPackageServiceImpl.setTrCreateStatus(COMPLETE);
        testDownloadPackageServiceImpl.setVerifyPackageTransferReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_INCOMING_PACKAGE, runtimeService,
            processVariables);

        // Multi-threading fun! Wait for the process to end so we can query the
        // history and see what happened.
        // The hang-up is with the existence of the timer intermediate event. It
        // relegates processing to a new thread
        // making it difficult to detect the end state without the JobTestHelper
        // class.
        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 5000L);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricDetail> activityDetails = historyService.createHistoricDetailQuery().variableUpdates()
            .processInstanceId(testInstance.getProcessInstanceId()).list();
        assertNotNull("No activity details for process instance " + testInstance.getProcessInstanceId(),
            activityDetails);

        // package transfer status should be ERROR
        for (HistoricDetail detail : activityDetails) {
            HistoricVariableUpdate varUpdate = (HistoricVariableUpdate) detail;
            if (varUpdate.getVariableName().equals(PACKAGE_TRANSFER_STATE)) {
                System.out.println(varUpdate);
                assertEquals(ERROR, varUpdate.getValue());
            }
        }

        TestUtils.assertActivitiEventFired(historyService, "businessErrorHandlingEndEvent", 1);
    }

    /**
     * Not finished downloading - Start, tx request ID, wait, verify, decision -> INCOMPLETE, wait again,
     * NOTHING_TO_TRANSFER (to end test)
     */
    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/download_madrid_package_from_wipo.bpmn"})
    public void testPackageNotFinishedDownload() {
        System.out.println("#############################################");
        System.out.println("###    testPackageNotFinishedDownload     ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        testDownloadPackageServiceImpl.setTrCreateStatus(COMPLETE);
        testDownloadPackageServiceImpl.setVerifyPackageTransferReturnObject(INCOMPLETE);
        testDownloadPackageServiceImpl.setLoopIterationIncomplete(3);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 5000L);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricDetail> activityDetails = historyService.createHistoricDetailQuery().variableUpdates()
            .processInstanceId(testInstance.getProcessInstanceId()).list();
        assertNotNull("No activity details for process instance " + testInstance.getProcessInstanceId(),
            activityDetails);

        // The package transfer status should have been updated twice. First to
        // INCOMPLETE then to COMPLETE
        HistoricVariableUpdate incompleteUpdate = null;
        HistoricVariableUpdate completeUpdate = null;
        for (HistoricDetail detail : activityDetails) {
            HistoricVariableUpdate varUpdate = (HistoricVariableUpdate) detail;
            if (varUpdate.getVariableName().equals(PACKAGE_TRANSFER_STATE)) {
                if (varUpdate.getValue().equals(INCOMPLETE)) {
                    incompleteUpdate = varUpdate;
                }
                if (varUpdate.getValue().equals(COMPLETE)) {
                    completeUpdate = varUpdate;
                }
            }
        }
        assertNotNull("Missing incomplete variable update for package transfer", incompleteUpdate);
        assertNotNull("Missing complete variable update for package transfer", completeUpdate);
        // Make sure the incomplete comes before the complete state.
        assertTrue(incompleteUpdate.getTime().getTime() < completeUpdate.getTime().getTime());
    }

    /**
     * Error on package staging - Start, retrieve transfer request ID, wait, verify, tx to staging -> decision gate -
     * error, finish.
     */
    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/download_madrid_package_from_wipo.bpmn"})
    public void testPackageToOutputFolderErrorHandling() {
        System.out.println("################################################");
        System.out.println("###  testPackageToOutputFolderErrorHandling  ###");
        System.out.println("################################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        testDownloadPackageServiceImpl.setTrCreateStatus(COMPLETE);
        testDownloadPackageServiceImpl.setVerifyPackageTransferReturnObject(COMPLETE);
        testDownloadPackageServiceImpl.setStagingTransferReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 5000L);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricDetail> activityDetails = historyService.createHistoricDetailQuery().variableUpdates()
            .processInstanceId(testInstance.getProcessInstanceId()).list();
        assertNotNull("No activity details for process instance " + testInstance.getProcessInstanceId(),
            activityDetails);

        // staging transfer status should be ERROR
        for (HistoricDetail detail : activityDetails) {
            HistoricVariableUpdate varUpdate = (HistoricVariableUpdate) detail;
            if (varUpdate.getVariableName().equals(STAGING_TRANSFER_STATUS)) {
                System.out.println(varUpdate);
                assertEquals(ERROR, varUpdate.getValue());
            }
        }

        // The embedded business error handling should have been called
        TestUtils.assertActivitiEventFired(historyService, "businessErrorHandlingEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/download_madrid_package_from_wipo.bpmn"})
    public void testPackageMoveVerifyIncomplete() {
        System.out.println("#############################################");
        System.out.println("###     testPackageMoveVerifyIncomplete   ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        testDownloadPackageServiceImpl.setTrCreateStatus(COMPLETE);
        testDownloadPackageServiceImpl.setVerifyPackageTransferReturnObject(COMPLETE);
        testDownloadPackageServiceImpl.setStagingTransferReturnObject(INCOMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 5000L);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricDetail> activityDetails = historyService.createHistoricDetailQuery().variableUpdates()
            .processInstanceId(testInstance.getProcessInstanceId()).list();
        assertNotNull("No activity details for process instance " + testInstance.getProcessInstanceId(),
            activityDetails);

        HistoricVariableUpdate incompleteUpdate = null;
        HistoricVariableUpdate completeUpdate = null;
        // staging transfer status should be COMPLETE
        for (HistoricDetail detail : activityDetails) {
            HistoricVariableUpdate varUpdate = (HistoricVariableUpdate) detail;
            if (varUpdate.getVariableName().equals(STAGING_TRANSFER_STATUS)) {
                if (varUpdate.getValue().equals(INCOMPLETE)) {
                    incompleteUpdate = varUpdate;
                }
                if (varUpdate.getValue().equals(COMPLETE)) {
                    completeUpdate = varUpdate;
                }
            }
        }

        assertNotNull("Missing incomplete variable update for package transfer", incompleteUpdate);
        assertNotNull("Missing complete variable update for package transfer", completeUpdate);

        // Make sure the incomplete comes before the complete.
        assertTrue(incompleteUpdate.getTime().getTime() < completeUpdate.getTime().getTime());

        // The embedded business error handling should have been called
        TestUtils.assertActivitiEventFired(historyService, "trMoveVerificationTask", 2);
    }

    /**
     * Happy path.
     */
    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/download_madrid_package_from_wipo.bpmn"})
    public void testSuccessfulTransfer() {
        System.out.println("#############################################");
        System.out.println("###         testSuccessfulTransfer        ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        testDownloadPackageServiceImpl.setTrCreateStatus(COMPLETE);
        testDownloadPackageServiceImpl.setVerifyPackageTransferReturnObject(COMPLETE);
        testDownloadPackageServiceImpl.setStagingTransferReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 5000L);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricDetail> activityDetails = historyService.createHistoricDetailQuery().variableUpdates()
            .processInstanceId(testInstance.getProcessInstanceId()).list();
        assertNotNull("No activity details for process instance " + testInstance.getProcessInstanceId(),
            activityDetails);

        TestUtils.assertActivitiEventFired(historyService, "downloadWipoHaguePackageEndEvent", 1);
    }

    private Map<String, Object> getTypicalProcessVars() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(TRANSFER_ITEM, IN_NOTIF_PKG);
        processVariables.put(OUTPUT_FOLDER, "/c/path/to/output");
        processVariables.put(DOWNLOAD_VERIFICATION_RETRY_PERIOD, "PT" + verifRetrySeconds + "S");
        processVariables.put(MOVE_VERIFICATION_POLL_PERIOD, "PT5S");
        return processVariables;
    }
}
