package ca.gc.ised.cipo.tm.madrid.exception;

/**
 * @author J. Greene
 *
 */
public class NoDownloadHistoryException extends Exception {

    private static final long serialVersionUID = -7279177621947611087L;

    public NoDownloadHistoryException(String message) {
        super(message);
    }
}
