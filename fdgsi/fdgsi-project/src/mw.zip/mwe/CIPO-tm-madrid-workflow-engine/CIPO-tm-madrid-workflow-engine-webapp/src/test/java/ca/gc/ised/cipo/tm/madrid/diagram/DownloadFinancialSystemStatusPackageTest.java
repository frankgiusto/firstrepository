package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_NUMBER_OF_RETRIES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_VERIFICATION_POLL_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_FILE_NOT_FOUND_RETRY_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_INPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionInternalDownloadServiceImpl;
import util.TestUtils;

/**
 * Test class for the {@code download_financial_system_status_package.bpmn} workflow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class DownloadFinancialSystemStatusPackageTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    public TestFinancialTransactionInternalDownloadServiceImpl testFinancialTransactionInternalDownloadServiceImpl;

    @Before
    public void init() {
        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(null);
        testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(null);
        testFinancialTransactionInternalDownloadServiceImpl.setVerifyFinPackageDownloadTransferStatusReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn"})
    public void happyPathTest() {
        System.out.println("#############################################");
        System.out.println("###             happyPathTest             ###");
        System.out.println("#############################################");

        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl
            .setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "downloadFeeStatusPackageEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn"})
    public void errorMakingTransferRequestTest() {
        System.out.println("#############################################");
        System.out.println("###     errorMakingTransferRequestTest    ###");
        System.out.println("#############################################");

        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE,
            runtimeService, getParameterMap());

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "movePackageToStagingTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "updateTransferStateTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "downloadFeeStatusPackageEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn"})
    public void verifyIncompleteTest() {
        System.out.println("#############################################");
        System.out.println("###         verifyIncompleteTest          ###");
        System.out.println("#############################################");

        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl
            .setVerifyFinPackageDownloadTransferStatusReturnObject(INCOMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "movePackageToStagingTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "downloadFeeStatusPackageEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn"})
    public void verifyNoFileFoundTest() {
        System.out.println("#############################################");
        System.out.println("###         verifyNoFileFoundTest         ###");
        System.out.println("#############################################");

        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl
            .setVerifyFinPackageDownloadTransferStatusReturnObject(NOTHING_TO_DO);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "createDownlaodFinStatusPackageTransferRequestTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "movePackageToStagingTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "downloadFeeStatusPackageEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn"})
    public void verifyErrorTest() {
        System.out.println("#############################################");
        System.out.println("###            verifyErrorTest            ###");
        System.out.println("#############################################");

        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl
            .setVerifyFinPackageDownloadTransferStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "createDownlaodFinStatusPackageTransferRequestTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "movePackageToStagingTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "downloadFeeStatusPackageEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "updateTransferStateTask", 0);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn"})
    public void movePackageToStagingFailTest() {
        System.out.println("#############################################");
        System.out.println("###      movePackageToStagingFailTest     ###");
        System.out.println("#############################################");

        testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
        testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(ERROR);
        testFinancialTransactionInternalDownloadServiceImpl
            .setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "movePackageToStagingTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "updateTransferStateTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    protected Map<String, Object> getParameterMap() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(FIN_PKG_DOWNLOAD_VERIFICATION_POLL_PERIOD, "PT1S");
        processVariables.put(FIN_PKG_FILE_NOT_FOUND_RETRY_PERIOD, "PT1S");
        processVariables.put(FIN_PKG_PERSIST_INPUT_FOLDER, "/c/your/mom");
        processVariables.put(FIN_PKG_PERSIST_FAIL_FOLDER, "/c/your/sister");
        processVariables.put(FIN_PKG_DOWNLOAD_NUMBER_OF_RETRIES, "1");
        processVariables.put(FIN_PKG_DOWNLOAD_TRANSFER_ITEM, "INFINPKG");
        processVariables.put(FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX, "FIN_PKG_2000-01.zip");
        return processVariables;
    }
}
