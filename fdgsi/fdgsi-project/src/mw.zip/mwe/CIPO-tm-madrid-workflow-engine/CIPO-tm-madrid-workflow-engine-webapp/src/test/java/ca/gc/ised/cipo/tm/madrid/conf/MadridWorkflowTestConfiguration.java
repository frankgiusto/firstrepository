package ca.gc.ised.cipo.tm.madrid.conf;

import javax.sql.DataSource;

import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.spring.ProcessEngineFactoryBean;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender;
import ca.gc.ised.cipo.tm.madrid.mock.MailSenderMock;
import ca.gc.ised.cipo.tm.madrid.mock.MpsServiceManagerMock;
import ca.gc.ised.cipo.tm.madrid.mock.MtsServiceManagerMock;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.BusinessErrorLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorHandler;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridDelegateService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridGroupAssignmentService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridListenerService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.ManualTransactionService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TUPSUserProfileService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestMadridDelegateServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestMadridListenerServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestTUPSUserProfileServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.AutomatedTransactionServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.BusinessErrorHandlerImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.BusinessErrorLogServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.MadridGroupAssignmentServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.MadridUserAuthorityServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.ManualTransactionServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.ProcessFlowConstantService;
import ca.gc.ised.cipo.tm.madrid.workflow.ws.MadridWorkflowServiceImpl;
import util.TestMadridMethodVarsService;

// TODO: This needs to be configured properly
@Configuration
@EnableTransactionManagement
@EnableAsync
@PropertySources({ @PropertySource(value = { "classpath:mwe.properties" }, ignoreResourceNotFound = false) })
// @ComponentScan({"ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl"})
public class MadridWorkflowTestConfiguration implements TransactionManagementConfigurer {

	@Bean(name = "madridListenerServiceImpl")
	public MadridListenerService madridListenerServiceImpl() {

		TestMadridListenerServiceImpl listener = new TestMadridListenerServiceImpl();

		return listener;
	}

	@Bean(name = "madridDelegateServiceImpl")
	public MadridDelegateService madridDelegetServiceImpl() {

		TestMadridDelegateServiceImpl delegate = new TestMadridDelegateServiceImpl();

		return delegate;
	}

	@Bean(name = "madridGroupAssignmentServiceImpl")
	public MadridGroupAssignmentService madridGroupAssignmentService() {

		// TestMadridGroupAssignmentServiceImpl delegate = new
		// TestMadridGroupAssignmentServiceImpl();
		MadridGroupAssignmentServiceImpl delegate = new MadridGroupAssignmentServiceImpl();

		return delegate;
	}

	@Bean(name = "madridMethodVarsService")
	public TestMadridMethodVarsService madridMethodVarsService() {

		TestMadridMethodVarsService delegate = new TestMadridMethodVarsService();

		return delegate;
	}

	@Bean(name = "userAuthorityService")
	public MadridUserAuthorityServiceImpl madridUserAuthorityService() {

		MadridUserAuthorityServiceImpl delegate = new MadridUserAuthorityServiceImpl();
		return delegate;
	}

	@Bean(name = "TUPSUserProfileService")
	public TUPSUserProfileService TUPSUserProfileService() {

		TUPSUserProfileService delegate = new TestTUPSUserProfileServiceImpl();
		return delegate;
	}

	@Bean(name = "MadridWorkflowService")
	public MadridWorkflowServiceImpl MadridWorkflowServiceImpl() {

		MadridWorkflowServiceImpl service = new MadridWorkflowServiceImpl();
		return service;
	}

	@Bean
	public DataSource dataSource() {

		SimpleDriverDataSource dataSource = new SimpleDriverDataSource();

		dataSource.setDriverClass(org.h2.Driver.class);
		dataSource.setUrl("jdbc:h2:mem:activiti;DB_CLOSE_DELAY=1000;DB_CLOSE_ON_EXIT=FALSE");
		dataSource.setUsername("sa");
		dataSource.setPassword("");

		// dataSource.setDriverClass(oracle.jdbc.driver.OracleDriver.class);
		// dataSource.setUrl("jdbc:oracle:thin:@p8221.ic.gc.ca:1521:TMDEV0");
		// dataSource.setUsername("INTL_TM_WORKFLOW_PRJT_DEV_USER");
		// dataSource.setPassword("user");

		return dataSource;
	}

	@Override
	@Bean
	public PlatformTransactionManager annotationDrivenTransactionManager() {

		DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager();
		dataSourceTransactionManager.setDataSource(dataSource());
		return dataSourceTransactionManager;
	}

	@Bean
	public SpringProcessEngineConfiguration processEngineConfiguration() {

		SpringProcessEngineConfiguration processEngineConfiguration = new SpringProcessEngineConfiguration();
		processEngineConfiguration.setDataSource(dataSource());
		processEngineConfiguration.setTransactionManager(annotationDrivenTransactionManager());
		processEngineConfiguration.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);
		processEngineConfiguration.setJobExecutorActivate(Boolean.FALSE);
		processEngineConfiguration.setAsyncExecutorActivate(Boolean.TRUE);
		processEngineConfiguration.setAsyncExecutorEnabled(Boolean.TRUE);
		processEngineConfiguration.setEnableDatabaseEventLogging(Boolean.TRUE);
		processEngineConfiguration.setHistory("full");
		return processEngineConfiguration;
	}

	@Bean
	public ProcessEngineFactoryBean processEngineFactory() {

		ProcessEngineFactoryBean processEngine = new ProcessEngineFactoryBean();
		processEngine.setProcessEngineConfiguration(processEngineConfiguration());
		return processEngine;
	}

	@Bean
	public ProcessEngine processEngine() {

		try {
			return processEngineFactory().getObject();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Bean
	public RepositoryService repositoryService() {

		return processEngine().getRepositoryService();
	}

	@Bean
	public RuntimeService runtimeService() {

		return processEngine().getRuntimeService();
	}

	@Bean
	public TaskService taskService() {

		return processEngine().getTaskService();
	}

	@Bean
	public HistoryService historyService() {

		return processEngine().getHistoryService();
	}

	@Bean
	public FormService formService() {

		return processEngine().getFormService();
	}

	@Bean
	public IdentityService identityService() {

		return processEngine().getIdentityService();
	}

	@Bean
	public ManagementService managementService() {

		return processEngine().getManagementService();
	}

	@Bean
	public ActivitiRule activitiRule() {
		return new ActivitiRule(processEngine());
	}

	@Bean
	public MtsServiceManager mtsServiceManager() {

		return new MtsServiceManagerMock();
	}

	@Bean
	public MpsServiceManager mpsServiceManager() {

		return new MpsServiceManagerMock();
	}

	@Bean
	public ProcessFlowConstantService processFlowConstantService() {

		return new ProcessFlowConstantService();
	}

	@Bean
	public AutomatedTransactionService automatedTransactionServiceImpl() {
		return new AutomatedTransactionServiceImpl();
	}

	@Bean
	public ManualTransactionService manualTransactionServiceImpl() {
		return new ManualTransactionServiceImpl();
	}

	@Bean
	public JndiSimpleMailSender mailSender() {
		return new MailSenderMock();
	}

	@Bean
	public BusinessErrorHandler businessErrorHandler() {
		return new BusinessErrorHandlerImpl();
	}

	@Bean
	public BusinessErrorLogDao businessErrorLogDao() {
		return new BusinessErrorLogDao();
	}

	@Bean
	public BusinessErrorLogService businessErrorLogService() {
		return new BusinessErrorLogServiceImpl();
	}
}
