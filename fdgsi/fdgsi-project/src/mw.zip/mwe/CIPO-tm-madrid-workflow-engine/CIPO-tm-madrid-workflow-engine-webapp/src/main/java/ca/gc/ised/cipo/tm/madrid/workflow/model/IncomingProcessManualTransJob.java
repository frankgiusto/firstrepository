package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.util.Date;

public final class IncomingProcessManualTransJob extends MweJob implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -958743892980515449L;

	private String transId;

	private String transTypeCode;

	private Date startDate;

	private Date endDate;

	/**
	 *
	 * @return
	 */
	public String getTransId() {
		return transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getTransTypeCode() {
		return transTypeCode;
	}

	public void setTransTypeCode(String transTypeCode) {
		this.transTypeCode = transTypeCode;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "IncomingProcessManualTransJob [transId=" + transId + ", transTypeCode=" + transTypeCode + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}

}
