package ca.gc.ised.cipo.tm.madrid.exception;

@SuppressWarnings("serial")
public class UserAuthorityException extends Exception {

    public final static int AUTH_SERVER_UNAVAILABLE = 999;

    public final static int ASSIGNEE_AUTH_ERROR = 100;

    public final static int AUTHORITY_AUTH_ERROR = 200;

    public final static int TASK_CONFIG_ERROR = 300;

    private int errorType;

    private String assignedGroup;

    private String errorMsg;

    public int getErrorType() {
	return errorType;
    }

    public void setErrorType(int errorType) {
	this.errorType = errorType;
    }

    public String getAssignedGroup() {
	return assignedGroup;
    }

    public void setAssignedGroup(String assignedGroup) {
	this.assignedGroup = assignedGroup;
    }

    public String getErrorMsg() {
	return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
	this.errorMsg = errorMsg;
    }

}
