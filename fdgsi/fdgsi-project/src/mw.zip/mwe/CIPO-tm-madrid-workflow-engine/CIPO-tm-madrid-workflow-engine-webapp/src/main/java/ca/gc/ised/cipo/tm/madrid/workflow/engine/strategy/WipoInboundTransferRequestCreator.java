package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.core.env.Environment;

import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;

/**
 * An interface to describe the behavior of a strategy to build a transfer request for DTF.
 *
 * @author J. Greene
 *
 */
public interface WipoInboundTransferRequestCreator {

    /**
     * Creates a serializable {@code CreateTransferRequest} IB-to-Office specific object to send to DTF.
     *
     * @param execution The execution metadata related to the BPMN process execution
     * @param packageDownloadLogService The service that controls the download log CRUD operations
     * @return A complete request object to send to DTF
     *
     * @throws NoDownloadHistoryException if no file name is passed via service and system can't determine baseline for
     *             calculating next file to download
     */
    CreateTransferRequest createTransferReqeust(DelegateExecution execution,
                                                PackageDownloadLogService packageDownloadLogService)
        throws NoDownloadHistoryException;

    /**
     * Sets the Spring env for accessing application configuration properties.
     *
     * @param env
     */
    void setEnvironmnent(Environment env);
}
