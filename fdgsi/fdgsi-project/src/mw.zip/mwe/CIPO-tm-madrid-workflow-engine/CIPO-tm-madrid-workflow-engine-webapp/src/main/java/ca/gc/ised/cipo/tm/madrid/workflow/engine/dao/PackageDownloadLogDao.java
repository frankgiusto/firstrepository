package ca.gc.ised.cipo.tm.madrid.workflow.engine.dao;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * A simple DAO object to control logging of downloaded packages for internal purposes.
 *
 * @author J. Greene
 *
 */
@Repository
public class PackageDownloadLogDao {

    protected static final Logger LOG = LoggerFactory.getLogger(PackageDownloadLogDao.class);

    protected NamedParameterJdbcTemplate jdbcTemplate;

    public void insertLogEntry(DownloadLogItem downloadLogItem) {
        try {
            // @formatter:off
            String sql =
                "insert into mwe_download_log "
                    + "(xfer_req_id, package_type, "
                    + " file_name, target_location, "
                    + " file_regex, "
                    + " dl_status, "
                    + " dl_date, "
                    + " msg, "
                    + " xfer_req_date)"
                    + " values(" + downloadLogItem.getXferReqId() + ", " // :xferReqId, "
                    + "'" + downloadLogItem.getPackageType() + "', "     // "        :packageType, "
                    + "        :fileName, "
                    + "        :targetLocation, "
                    + "        :fileRegex, "
                    + "        :dlStatus, "
                    + "        :dlDate, "
                    + "        :msg, "
                    + "        :xferReqDate)";
            // @formatter:on
            GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
            SqlParameterSource downloadItemNamedParameters = new BeanPropertySqlParameterSource(downloadLogItem);

            jdbcTemplate.update(sql, downloadItemNamedParameters, keyHolder, new String[]{"dl_log_id"});
            downloadLogItem.setDlLogId(keyHolder.getKey().longValue());

            String logFileInfo = downloadLogItem.getFileName() == null ? downloadLogItem.getFileRegex()
                : downloadLogItem.getFileName();
            LOG.debug(
                "Created log entry for request for file " + logFileInfo + ".  PK: " + keyHolder.getKey().longValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateLogEntry(DownloadLogItem downloadLogItem) {
        SqlParameterSource downloadItemNamedParameters = new BeanPropertySqlParameterSource(downloadLogItem);
        String sql = "update mwe_download_log "
            + "set xfer_req_id = :xferReqId, file_name = :fileName, file_regex = :fileRegex, "
            + "dl_status = :dlStatus, dl_date = :dlDate, msg = :msg " + "where dl_log_id = :dlLogId";
        int i = jdbcTemplate.update(sql, downloadItemNamedParameters);

        String logFileInfo = downloadLogItem.getFileName() == null ? downloadLogItem.getFileRegex()
            : downloadLogItem.getFileName();
        LOG.debug("Updated log entry for request for file " + logFileInfo + ".  Rows affected:  " + i);
    }

    public void purgeOldLogEntries(int olderThanNumberOfDays) {
        Date cutoffDate = DateUtils.addDays(new Date(), -(olderThanNumberOfDays + 1));
        String sql = "delete from mwe_download_log where dl_date < :cutoffDate";
        int i = jdbcTemplate.update(sql, Collections.singletonMap("cutoffDate", cutoffDate));
        LOG.debug("Removed " + i + " old log instance(s) from more than " + olderThanNumberOfDays + " days ago.");
    }

    public List<DownloadLogItem> getDownloadLogItemsByFields(DownloadLogItem item) {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from mwe_download_log");

        Map<String, Object> paramMap = new HashMap<>();
        int whereCount = 0;

        if (item.getDlLogId() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("dl_log_id = :dlLogId");
            whereCount++;
            paramMap.put("dlLogId", item.getDlLogId());
        }
        if (item.getXferReqId() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("xfer_req_id = :xferReqId");
            whereCount++;
            paramMap.put("xferReqId", item.getXferReqId());
        }
        if (item.getPackageType() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("package_type = :packageType");
            whereCount++;
            paramMap.put("packageType", item.getPackageType());
        }
        if (item.getFileName() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("lower(file_name) = :fileName");
            whereCount++;
            paramMap.put("fileName", item.getFileName().toLowerCase());
        }
        if (item.getTargetLocation() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("lower(target_location) = :targetLocation");
            whereCount++;
            paramMap.put("targetLocation", item.getTargetLocation().toLowerCase());
        }
        if (item.getFileRegex() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("file_regex = :fileRegex");
            whereCount++;
            paramMap.put("fileRegex", item.getFileRegex());
        }
        if (item.getDlStatus() != null) {
            sql.append(whereCount == 0 ? " where " : " and ");
            sql.append("dl_status = :dlStatus");
            whereCount++;
            paramMap.put("dlStatus", item.getDlStatus());
        }
        // Keeping it simple for now
        if (item.getDlDate() != null || item.getXferReqDate() != null) {
            throw new IllegalArgumentException("Query does not support date arguments");
        }

        return jdbcTemplate.query(sql.toString(), paramMap, BeanPropertyRowMapper.newInstance(DownloadLogItem.class));
    }

    public List<DownloadLogItem> getAllDownloadLogItems() {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from mwe_download_log");

        return jdbcTemplate.query(sql.toString(), BeanPropertyRowMapper.newInstance(DownloadLogItem.class));
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

}
