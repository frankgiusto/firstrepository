package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.model.OperationCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestXsd;
import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * An abstract strategy to handle creation of a DTF transfer request.
 *
 * @author J. Greene
 *
 */
public abstract class AbstractWipoInboundTransferRequestCreator implements WipoInboundTransferRequestCreator {

    protected PackageDownloadLogService packageDownloadLogService;

    protected Environment env;

    protected static final Logger LOG = LoggerFactory.getLogger(AbstractWipoInboundTransferRequestCreator.class);

    /** {@inheritDoc} */
    @Override
    public CreateTransferRequest createTransferReqeust(DelegateExecution execution,
                                                       PackageDownloadLogService packageDownloadLogService)
        throws NoDownloadHistoryException {

        DownloadLogItem lastSuccessfulDownloadLogItem = null;
        setPackageDownloadLogService(packageDownloadLogService);
        CreateTransferRequest request = new CreateTransferRequest();
        TransferRequestXsd transferRequest = new TransferRequestXsd();
        request.setTransferRequest(transferRequest);

        String transferItem = execution.getVariable(ProcessFlowConstants.TRANSFER_ITEM, String.class);
        String overrideFileName = execution.getVariable(ProcessFlowConstants.REMOTE_FILE_NAME, String.class);

        if (StringUtils.isBlank(overrideFileName)) {
            // if there is no successful download history and an attempt to call service without a file name passed as
            // argument, thrown an error because the system can't determine the next file in order without a history of
            // successful downloads.

            lastSuccessfulDownloadLogItem = getPackageDownloadLogService().getPreviouslyDownloadedByType(transferItem);
            if (lastSuccessfulDownloadLogItem == null) {
                String msg = "The system cannot determine the next file in order to download from WIPO without a download history.  Please provide a file name in the service call.";
                throw new NoDownloadHistoryException(msg);
            }
        }

        // Transfer request creation
        request.getTransferRequest().setExternalSiteAcronym(getDtfSite());
        request.getTransferRequest().setTransferItemAcronym(transferItem);
        request.getTransferRequest().setOperationCode(OperationCode.INBOUND.codeValue());
        request.getTransferRequest().setRequestor(ProcessFlowConstants.MWE);
        request.getTransferRequest().setNote("Activiti process instance: " + execution.getProcessInstanceId());

        // Transfer request parameters
        setParamCollection(request.getTransferRequest().getParameters(), execution, lastSuccessfulDownloadLogItem);

        return request;
    }

    /** {@inheritDoc} */
    @Override
    public void setEnvironmnent(Environment env) {
        this.env = env;
    }

    protected Environment getEnvironment() {
        return env;
    }

    /**
     * @return the packageDownloadLogDao
     */
    protected PackageDownloadLogService getPackageDownloadLogService() {
        return packageDownloadLogService;
    }

    /**
     * @param [] the packageDownloadLogDao to set
     */
    protected void setPackageDownloadLogService(PackageDownloadLogService packageDownloadLogService) {
        this.packageDownloadLogService = packageDownloadLogService;
    }

    /**
     * DTF Site acronym - should be set in COM-FTI database and set through the File Transfer Console (FTC)
     *
     * @return the DTF Site acronym
     */
    abstract protected String getDtfSite();

    /**
     * Parameters for the file transfer (file name, remote dir, etc.)
     */
    abstract protected void setParamCollection(List<TransferRequestParamXsd> paramList, DelegateExecution execution,
                                               DownloadLogItem lastDownloadLogItem);

}
