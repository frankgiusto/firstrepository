package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MPS;

import java.math.BigDecimal;

import javax.xml.ws.BindingProvider;

import org.activiti.engine.RuntimeService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mps.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mps.ImportPackage;
import ca.gc.ic.cipo.tm.mps.MadridPackageServicePortType;
import ca.gc.ic.cipo.tm.mps.factory.MadridPackageServiceFactory;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.UpdatePackageStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * Manager class to handle the Madrid package service calls and response as well as any SOAP faults.
 *
 * @author J. Greene
 *
 */
@Service
public class MpsServiceManagerImpl extends AbstractServiceManager implements MpsServiceManager {

    protected static final Logger LOG = LoggerFactory.getLogger(MpsServiceManagerImpl.class);

    protected MadridPackageServicePortType mpsClient;

    @Value("${mwe.mps.service.endpoint.hostname}")
    private String mpsHost;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskExecutor taskExecutor;

    @Autowired
    Environment env;

    /**
     * Wraps the call to initiate the package processing.
     *
     * @param importPackage The formatted SOAP request object
     * @param packageUnit the {@code packageUnit} associated with this flow
     * @return The package ID of the newly created package
     * @throws BpmnWebServiceCallException if there is an issue with the web service call
     */
    @Override
    public BigDecimal processPackage(ImportPackage importPackage, PackageUnit packageUnit)
        throws BpmnWebServiceCallException {
        if (importPackage == null) {
            throw new IllegalArgumentException("Parameter [importPackage] must not be null");
        }
        if (packageUnit == null) {
            throw new IllegalArgumentException("Parameter [packageUnit] must not be null");
        }
        BigDecimal packageId = null;
        try {
            LOG.debug("--> Calling WSO : importPackage");
            packageId = getMpsClient().importPackage(importPackage.getImportPackageRequest());
            LOG.debug("-->         WSO : importPackage - returned with ID " + packageId);

        } catch (CIPOServiceFault csf) {
            handleMpsSoapFault(csf, packageUnit);
        } catch (Throwable t) {
            handleWebServiceException(t, MPS, "importPackage");
        }

        return packageId;
    }

    /**
     * Wraps the call to get the package processing status from the previous call.
     *
     * @param packageId The package ID of the request object
     * @param packageUnit the {@code packageUnit} associated with this flow
     * @return The formatted SOAP response object
     * @throws BpmnWebServiceCallException if there is an issue with the web service call
     */
    @Override
    public PackageStatusEnum getPackageProcessingStatus(BigDecimal packageId, PackageUnit packageUnit)
        throws BpmnWebServiceCallException {
        if (packageId == null) {
            throw new IllegalArgumentException("Parameter [packageId] must not be null");
        }
        if (packageUnit == null) {
            throw new IllegalArgumentException("Parameter [packageUnit] must not be null");
        }
        PackageStatusEnum response = null;

        try {
            LOG.debug("--> Calling WSO : getPackageStatus - with package ID " + packageId);
            response = getMpsClient().getPackageStatus(packageId.intValue());
            LOG.debug("-->         WSO : getPackageStatus - returned with status " + response);
        } catch (CIPOServiceFault csf) {
            handleMpsSoapFault(csf, packageUnit);
        } catch (Throwable t) {
            handleWebServiceException(t, MPS, "getPackageStatus");
        }

        return response;
    }

    /**
     * Wraps the package export MPS operation call.
     *
     * @param packageLocation The string representation of the package location
     * @param execution the delegate execution from which we will get the process to signal upon completion.
     * @throws BpmnWebServiceCallException
     */
    @Override
    public BigDecimal exportPackage(String packageLocation) throws BpmnWebServiceCallException {
        if (packageLocation == null) {
            throw new IllegalArgumentException("Parameter [packageLocation] must not be null");
        }
        BigDecimal packageId = null;

        try {
            LOG.debug("--> Calling WSO : exportPackage");
            packageId = getMpsClient().exportPackage(packageLocation);
            LOG.debug("-->         WSO : exportPackage - returned with ID " + packageId);
        } catch (CIPOServiceFault csf) {
            handleMpsSoapFault(csf);
        } catch (Throwable t) {
            handleWebServiceException(t, MPS, "exportPackage");
        }

        return packageId;
    }

    /**
     * Wraps the call to update package status.
     *
     * @param updatePackageStatusType the complex object containing package identifier and status to be updated
     */
    @Override
    public void updatePackageStatus(UpdatePackageStatusType updatePackageStatusType)
        throws BpmnWebServiceCallException {
        if (updatePackageStatusType == null) {
            throw new IllegalArgumentException("Parameter [updatePackageStatusType] must not be null");
        }
        try {
            LOG.debug("--> Calling WSO : updatePackageStatus - with status " + updatePackageStatusType);
            getMpsClient().updatePackageStatus(updatePackageStatusType);
        } catch (CIPOServiceFault csf) {
            handleMpsSoapFault(csf);
        } catch (Throwable t) {
            handleWebServiceException(t, MPS, "updatePackageStatus");
        }
    }

    protected void handleMpsSoapFault(CIPOServiceFault fault) throws BpmnWebServiceCallException {
        BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(fault.getFaultInfo());

        BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::CIPOServiceFault::");
        serviceException.setBusinessErrorLogItem(businessErrorLogItem);
        throw serviceException;
    }

    protected void handleMpsSoapFault(CIPOServiceFault fault, PackageUnit badPackageUnit)
        throws BpmnWebServiceCallException {
        BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(fault.getFaultInfo());
        businessErrorLogItem.setMessage(getFileInfoString(badPackageUnit));

        BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::CIPOServiceFault::");
        serviceException.setBusinessErrorLogItem(businessErrorLogItem);
        throw serviceException;
    }

    protected String getMpsHost() {
        if (StringUtils.isBlank(mpsHost)) {
            throw new IllegalArgumentException(
                "Please provide a valid value for property [mwe.mps.service.endpoint.hostname] in the application configuration");
        }
        return mpsHost;
    }

    protected MadridPackageServicePortType getMpsClient() {
        if (mpsClient == null) {
            mpsClient = MadridPackageServiceFactory.createClient(getMpsHost());
        }

        return mpsClient;
    }

    protected String getFileInfoString(PackageUnit badPackageUnit) {
        StringBuilder messageStringBuilder = new StringBuilder();
        // @formatter:off
        messageStringBuilder
            .append(SystemUtils.LINE_SEPARATOR)
            .append(SystemUtils.LINE_SEPARATOR)
            .append("Files:")
            .append(SystemUtils.LINE_SEPARATOR)
            .append("\t")
            .append(badPackageUnit.getXmlFileName())
            .append(SystemUtils.LINE_SEPARATOR)
            .append("\t")
            .append(badPackageUnit.getImgFileName());
        // @formatter:on

        return messageStringBuilder.toString();
    }

    /** {@inheritDoc} */
    @Override
    protected BindingProvider getBindingProvider() {
        return (BindingProvider) getMpsClient();
    }

}
