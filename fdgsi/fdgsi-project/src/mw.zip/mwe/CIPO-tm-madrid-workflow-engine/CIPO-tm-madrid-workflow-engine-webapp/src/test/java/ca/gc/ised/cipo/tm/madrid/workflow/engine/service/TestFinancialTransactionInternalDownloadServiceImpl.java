package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_REQUEST_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_MOVE_TO_STAGING_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.VERIFY_FIN_PACKAGE_DOWNLOAD_TRANSFER_STATUS;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Test service implementation for the {@code download_financial_system_status_package.bpmn} workflow delegate execution
 * service.
 *
 * @author J. Greene
 *
 */
public class TestFinancialTransactionInternalDownloadServiceImpl extends TestBusinessErrorHandlerImpl
    implements FinancialTransactionInternalDownloadService {

    protected Integer finPkgDownloadRequestStatusReturnObject;

    protected Integer verifyFinPackageDownloadTransferStatusReturnObject;

    protected Integer packageMoveToStagingStatusReturnObject;

    /** {@inheritDoc} */
    @Override
    public void createFinSysFeedbackTransferRequest(DelegateExecution execution) {
        if (getFinPkgDownloadRequestStatusReturnObject() != null) {
            execution.setVariable(FIN_PKG_DOWNLOAD_REQUEST_STATUS, getFinPkgDownloadRequestStatusReturnObject());
        }
        System.out.println("[[createFinSysReconciledFeeReportTransferRequest]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void verifyFinSysFeedbackDownload(DelegateExecution execution) {
        if (getVerifyFinPackageDownloadTransferStatusReturnObject() != null) {
            execution.setVariable(VERIFY_FIN_PACKAGE_DOWNLOAD_TRANSFER_STATUS,
                getVerifyFinPackageDownloadTransferStatusReturnObject());
            if (getVerifyFinPackageDownloadTransferStatusReturnObject().equals(INCOMPLETE)
                || getVerifyFinPackageDownloadTransferStatusReturnObject().equals(NOTHING_TO_DO)) {
                setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);
            }

        }
        System.out.println("[[verifyFinSysReconciledFeeReportDownload]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void movePackageToStaging(DelegateExecution execution) {
        if (getPackageMoveToStagingStatusReturnObject() != null) {
            execution.setVariable(PACKAGE_MOVE_TO_STAGING_STATUS, getPackageMoveToStagingStatusReturnObject());
        }
        System.out.println("[[movePackageToStaging]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void sendTransferConfirmation(DelegateExecution execution) {
        System.out.println("[[updateTransferState]]: " + execution.getVariables());
    }

    /**
     * @return the finPkgDownloadRequestStatusReturnObject
     */
    public Integer getFinPkgDownloadRequestStatusReturnObject() {
        return finPkgDownloadRequestStatusReturnObject;
    }

    /**
     * @param finPkgDownloadRequestStatusReturnObject the finPkgDownloadRequestStatusReturnObject to set
     */
    public void setFinPkgDownloadRequestStatusReturnObject(Integer finPkgDownloadRequestStatusReturnObject) {
        this.finPkgDownloadRequestStatusReturnObject = finPkgDownloadRequestStatusReturnObject;
    }

    /**
     * @return the verifyFinPackageDownloadTransferStatusReturnObject
     */
    public Integer getVerifyFinPackageDownloadTransferStatusReturnObject() {
        return verifyFinPackageDownloadTransferStatusReturnObject;
    }

    /**
     * @param verifyFinPackageDownloadTransferStatusReturnObject the verifyFinPackageDownloadTransferStatusReturnObject
     *            to set
     */
    public void setVerifyFinPackageDownloadTransferStatusReturnObject(Integer verifyFinPackageDownloadTransferStatusReturnObject) {
        this.verifyFinPackageDownloadTransferStatusReturnObject = verifyFinPackageDownloadTransferStatusReturnObject;
    }

    /**
     * @return the packageMoveToStagingStatusReturnObject
     */
    public Integer getPackageMoveToStagingStatusReturnObject() {
        return packageMoveToStagingStatusReturnObject;
    }

    /**
     * @param packageMoveToStagingStatusReturnObject the packageMoveToStagingStatusReturnObject to set
     */
    public void setPackageMoveToStagingStatusReturnObject(Integer packageMoveToStagingStatusReturnObject) {
        this.packageMoveToStagingStatusReturnObject = packageMoveToStagingStatusReturnObject;
    }

}
