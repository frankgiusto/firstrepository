package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;

/**
 * A special class that will resolve the type of report type enum being passed
 * through the workflow engine. This is an 11th hour patch to an issue that came
 * up due to collision with all the service clients. A code smell for sure, but
 * unavoidable at this point in time.
 *
 * @author J. Greene
 *
 */
public class ReportTypeEnumResolver implements Serializable {

	private static final long serialVersionUID = 552780569189113832L;

	private ca.gc.ic.cipo.tm.mts.ReportTypeEnum mtsReportType;

	// MFS-CLEAN-SPR5 private ca.gc.ic.cipo.tm.schema.mfs.ReportTypeEnum
	// mfsReportType;

	// private ca.gc.ic.cipo.tm.schema.mps.ReportTypeEnum mpsReportType;

	public enum TypeOfObject {
		MTS, MFS, MPS
	}

	private TypeOfObject typeOfObject;

	public ReportTypeEnumResolver(ca.gc.ic.cipo.tm.mts.ReportTypeEnum mtsReportType) {
		this.mtsReportType = mtsReportType;
		this.typeOfObject = TypeOfObject.MTS;
	}

	// MFS-CLEAN-SPR5 public
	// ReportTypeEnumResolver(ca.gc.ic.cipo.tm.schema.mfs.ReportTypeEnum
	// mfsReportType) {
	// this.mfsReportType = mfsReportType;
	// this.typeOfObject = TypeOfObject.MFS;
	// }

	// public ReportTypeEnumResolver(ca.gc.ic.cipo.schema.tm.ihps.ReportTypeEnum
	// mpsReportType) {
	// this.mpsReportType = mpsReportType;
	// this.typeOfObject = TypeOfObject.MPS;
	// }

	/**
	 * @return the mtsReportType
	 */
	public ca.gc.ic.cipo.tm.mts.ReportTypeEnum getMtsReportType() {
		return mtsReportType;
	}

	/**
	 * @return the mfsReportType
	 */
	// MFS-CLEAN-SPR5 public ca.gc.ic.cipo.tm.schema.mfs.ReportTypeEnum
	// getMfsReportType() {
	// return mfsReportType;
	// }

	/**
	 * @return the mpsReportType
	 */
	// public ca.gc.ic.cipo.schema.tm.ihps.ReportTypeEnum getMpsReportType() {
	// return mpsReportType;
	// }

	/**
	 * @return the typeOfObject
	 */
	public TypeOfObject getTypeOfObject() {
		return typeOfObject;
	};

}
