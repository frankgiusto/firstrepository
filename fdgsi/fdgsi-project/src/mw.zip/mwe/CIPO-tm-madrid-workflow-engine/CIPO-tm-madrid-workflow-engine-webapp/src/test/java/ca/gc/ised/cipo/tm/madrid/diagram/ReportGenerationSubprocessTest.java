package ca.gc.ised.cipo.tm.madrid.diagram;

/**
 * A test class for the report generation subprocess diagram
 * (report_generation_test_container.bpmn).
 *
 * @author J. Greene
 *
 */
// @RunWith(SpringJUnit4ClassRunner.class)
// @ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class ReportGenerationSubprocessTest {

	// MFS-CLEAN-SPR5 private static final String TEST_CONTAINER =
	// "reportGenerationTestContainer";
	//
	// @Autowired
	// protected ManagementService managementService;
	//
	// @Autowired
	// protected ProcessEngine processEngine;
	//
	// @Autowired
	// protected RuntimeService runtimeService;
	//
	// @Autowired
	// protected TaskService taskService;
	//
	// @Autowired
	// protected HistoryService historyService;
	//
	// @Autowired
	// @Rule
	// public ActivitiRule activitiRule;
	//
	// @Autowired
	// protected TestReportGenerationServiceImpl
	// testReportGenerationServiceImpl;
	//
	// @Before
	// public void init() {
	// testReportGenerationServiceImpl.setPersistReportStatus(null);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(null);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(null);
	// testReportGenerationServiceImpl.setRecoverableErrorStatus(null);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void happyPathTest() {
	// System.out.println("#############################################");
	// System.out.println("### happyPathTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	// parameterMap.put(REPORT_TYPE_VAR, new
	// ReportTypeEnumResolver(ReportTypeEnum.TRANSACTION_REP_PDF));
	// parameterMap.put(TRANSACTION_ID, "100");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L,
	// 1000L);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it ended properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenerationSubprocessEndEvent", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "evaluateErrorSeverity2Task", 0);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void initiateErrorTest() {
	// System.out.println("#############################################");
	// System.out.println("### initiateErrorTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(ERROR);
	// testReportGenerationServiceImpl.setRecoverableErrorStatus(ERROR);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it handled the error properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "initiateReportGenErrorEndEvent", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "evaluateErrorSeverity1Task", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void initiateErrorRecoverableTest() {
	// System.out.println("#############################################");
	// System.out.println("### initiateErrorRecoverableTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(ERROR);
	// testReportGenerationServiceImpl.setRecoverableErrorStatus(COMPLETE);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it handled the error properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "initiateReportGenErrorEndEvent", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "evaluateErrorSeverity1Task", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenerationSubprocessEndEvent", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "pollReportServiceTask", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenErrorEndEvent", 0);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void pingErrorTest() {
	// System.out.println("#############################################");
	// System.out.println("### pingErrorTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(ERROR);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L,
	// 1000L);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it handled the error properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportServicePollErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void rgsErrorStatusTest() {
	// System.out.println("#############################################");
	// System.out.println("### rgsErrorStatusTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(RGS_ERROR_STATUS);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L,
	// 1000L);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it handled the error properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "handleRgsErrorStatusTask", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "updateCallingService", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenerationSubprocessEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void updateStatusErrorRecoverableTest() {
	// System.out.println("#############################################");
	// System.out.println("### updateStatusErrorRecoverableTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(ERROR);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	// testReportGenerationServiceImpl.setRecoverableErrorStatus(COMPLETE);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L,
	// 1000L);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it handled the error properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "updateCallingServiceErrorEndEvent", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "evaluateErrorSeverity2Task", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenerationSubprocessEndEvent", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenErrorEndEvent", 0);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void updateStatusErrorNotRecoverableTest() {
	// System.out.println("#############################################");
	// System.out.println("### updateStatusErrorNotRecoverableTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(ERROR);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	// testReportGenerationServiceImpl.setRecoverableErrorStatus(ERROR);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L,
	// 1000L);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it handled the error properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "updateCallingServiceErrorEndEvent", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "evaluateErrorSeverity2Task", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenerationSubprocessEndEvent", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/report_generation_test_container.bpmn"})
	// public void notReadyYetTest() {
	// System.out.println("#############################################");
	// System.out.println("### notReadyYetTest ###");
	// System.out.println("#############################################");
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(INCOMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// Map<String, Object> parameterMap = new HashMap<>();
	// parameterMap.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(TEST_CONTAINER, runtimeService,
	// parameterMap);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L,
	// 1000L);
	//
	// // Make sure it ended
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// // Make sure it called the poll activity twice
	// TestUtils.assertActivitiEventFired(historyService,
	// "pollReportServiceTask", 2);
	// // Make sure it ended properly.
	// TestUtils.assertActivitiEventFired(historyService,
	// "reportGenerationSubprocessEndEvent", 1);
	// }

}
