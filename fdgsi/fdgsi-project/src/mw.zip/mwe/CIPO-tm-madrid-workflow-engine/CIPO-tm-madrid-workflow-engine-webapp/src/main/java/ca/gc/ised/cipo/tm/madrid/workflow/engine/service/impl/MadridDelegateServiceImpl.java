package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskIdsResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.ManualAutoCategoryType;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridDelegateService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

@Service
public class MadridDelegateServiceImpl extends BusinessErrorHandlerImpl implements MadridDelegateService {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Value("${mwe.mts.service.endpoint.hostname}")
	private String mtsHostUrl;

	@Value("${application.acronym}")
	private String serviceName;

	@Autowired
	MtsServiceManager mtsServiceManager;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void checkForExistingMarks(DelegateExecution execution) throws BpmnError {

		Map<String, Object> varMap = execution.getVariables();

		String irTranId = (String) varMap.get(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID);
		String transTypeStr = (String) execution.getVariable(ProcessFlowConstants.CONSOLE_TASK_TYPE);

		//
		// Delegate Logic Here.
		//
		try {

			this.checkMarkExists(irTranId, transTypeStr, execution);

		} catch (Exception e) {

			LOG.error(e.getMessage());

			BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem(e.getMessage());
			businessErrorLogItem.setCipoServiceFaultOrigin(true);
			businessErrorLogItem.setServiceName(serviceName);
			businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
			businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

			execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

			BpmnError error = new BpmnError("madridError", e.getMessage());
			error.addSuppressed(e);

			throw error;

		}

	}

	@Override
	public void checkForNotifications(DelegateExecution execution) throws Exception {
		Map<String, Object> varMap = execution.getVariables();

		String irTranId = (String) varMap.get(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID);

		//
		// Delegate Logic Here.
		//
		try {

			this.checkForNotifications(irTranId, execution);

		} catch (Exception e) {

			LOG.error(e.getMessage());

			BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem(e.getMessage());
			businessErrorLogItem.setCipoServiceFaultOrigin(true);
			businessErrorLogItem.setServiceName(serviceName);
			businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
			businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

			execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

			BpmnError error = new BpmnError("madridError", e.getMessage());
			error.addSuppressed(e);

			throw error;

		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createConsoleTask(DelegateExecution execution) {

		// Pull vars off the process flow
		String irTranId = (String) execution.getVariable(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID);

		try {

			BigDecimal irTranIdDecimal = new BigDecimal(irTranId);

			ManualProcessingCriteria criteria = new ManualProcessingCriteria();
			TransactionRequest req = new TransactionRequest();
			req.setIrTranId(irTranIdDecimal);

			criteria.setTransactionRequest(req);

			ManualProcessResponse res = mtsServiceManager.processManualTransaction(criteria);

			List<ConsoleTaskResponse> consoleTasks = res.getConsoleTaskBag();
			if (consoleTasks != null && !consoleTasks.isEmpty()) {

				// TODO - Should we be iterating over the list?
				ConsoleTaskResponse consoleTask = consoleTasks.get(0);

				execution.setVariable(ProcessFlowConstants.CONSOLE_TASK_ID, consoleTask.getConsoleTaskId());
				if (consoleTask.getAuthorityId() != null) {

					LOG.debug("Setting candidate group to AuthId: " + consoleTask.getAuthorityId());
					execution.setVariable(ProcessFlowConstants.CANDIDATE_GROUP_ID, consoleTask.getAuthorityId());

				} else {
					execution.removeVariable(ProcessFlowConstants.CANDIDATE_GROUP_ID);
				}

			}

			execution.setVariable(ProcessFlowConstants.MTS_ERROR, false);

		} catch (BpmnWebServiceCallException ex) {

			String errMsg = "";

			if (ex.getBusinessErrorLogItem() != null) {

				errMsg += "Service: " + ex.getBusinessErrorLogItem().getServiceName();
				errMsg += " threw exception with message -> " + ex.getBusinessErrorLogItem().getErrorMessageEn();

			}

			LOG.error(errMsg);

			execution.setVariable(ProcessFlowConstants.ERR_MSG_DESC_VAR, errMsg);
			execution.setVariable(ProcessFlowConstants.MTS_ERROR, true);

		} catch (Exception e) {

			LOG.error(e.getMessage());

			// TODO Add more descriptive error
			execution.setVariable(ProcessFlowConstants.ERR_MSG_DESC_VAR, e.getMessage());
			execution.setVariable(ProcessFlowConstants.MTS_ERROR, true);

		}

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updateConsoleTaskStatus(DelegateExecution execution) {

		// Pull vars off the process flow
		BigDecimal consoleTaskId = (BigDecimal) execution.getVariable(ProcessFlowConstants.CONSOLE_TASK_ID);
		String consoleTaskStatus = (String) execution.getVariable(ProcessFlowConstants.CONSOLE_TASK_STATUS);

		try {

			ConsoleTaskStatusType statusType = ConsoleTaskStatusType.PROCESSED;

			if (consoleTaskStatus != null) {
				statusType = ConsoleTaskStatusType.valueOf(consoleTaskStatus);
			}

			mtsServiceManager.updateConsoleTaskStatus(consoleTaskId, statusType);

			execution.setVariable(ProcessFlowConstants.MTS_ERROR, false);

		} catch (Exception e) {

			// TODO Add more descriptive error
			execution.setVariable(ProcessFlowConstants.ERR_MSG_DESC_VAR, e.getMessage());
			execution.setVariable(ProcessFlowConstants.MTS_ERROR, true);

		}

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void notifyAdmin(DelegateExecution execution) {

		LOG.debug("Sending email to administrator");

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void fetchTransactions(DelegateExecution execution) {

		BigDecimal specifiedTransId = (BigDecimal) execution
				.getVariable(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID);

		List<String[]> transInfo = new ArrayList<String[]>();

		try {

			TransactionCriteria criterea = new TransactionCriteria();

			criterea.setTransactionManualAutoCategory(ManualAutoCategoryType.MANUAL);
			criterea.getStatusCodeList().add(TransactionStatusType.MPS_IMPORT_COMPLETE);

			List<TransactionDetail> details = mtsServiceManager.getTransactionList(criterea);

			LOG.info("MTS returned " + details.size() + " manual transactions ready for processing.");

			for (TransactionDetail transactionDetail : details) {

				String[] detail = new String[2];

				// If we were given a transId, only the transaction with that Id
				// will be added to the list
				if (specifiedTransId != null) {

					if (transactionDetail.getTransactionId().equals(specifiedTransId)) {

						detail = new String[] { specifiedTransId.toString(),
								transactionDetail.getTransactionType().getCategory() };

						transInfo.add(detail);
					}

				} else {

					detail = new String[] { transactionDetail.getTransactionId().toString(),
							transactionDetail.getTransactionType().getCategory() };

					transInfo.add(detail);
				}

			}

			LOG.info(transInfo.size() + " transactions to be processed");

		} catch (Exception e) {

			// Create a business error and put it on the flow.
			BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem(e.getMessage());
			businessErrorLogItem.setCipoServiceFaultOrigin(true);
			businessErrorLogItem.setServiceName(serviceName);
			businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
			businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

			execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

			// TODO Add more descriptive error
			execution.setVariable(ProcessFlowConstants.ERR_MSG_DESC_VAR, e.getMessage());
			execution.setVariable(ProcessFlowConstants.MTS_ERROR, true);

		}

		// Use this to limit the size of the array
		// int maxSize = 5;
		// if (transInfo.size() >= maxSize) {
		//
		// List<String[]> tempTransInfo = transInfo.subList(0, maxSize);
		//
		// transInfo = new ArrayList<String[]>();
		// for (String[] strings : tempTransInfo) {
		// transInfo.add(strings);
		// }
		//
		// }

		// Put the list of transaction details on the process flow
		execution.setVariable(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_DESC_LIST, transInfo);
		execution.setVariable(ProcessFlowConstants.MTS_ERROR, false);

	}

	/**
	 *
	 * @param irNumber
	 * @param irTranId
	 * @param execution
	 * @return
	 */
	private void checkMarkExists(String irTranId, String transTypeStr, DelegateExecution execution) throws Exception {

		ExistingMarkRequest req = new ExistingMarkRequest();
		ExistingMarkResponse res = null;

		// Set up the Request variables
		try {

			req.setIrTranId(new BigDecimal(irTranId));

		} catch (NumberFormatException e) {

			LOG.error("Cannot convert transId(" + irTranId + ") to decimal");
			throw new Exception("Cannot convert transId(" + irTranId + ") to decimal");

		}

		// Call the MTS
		try {

			res = mtsServiceManager.checkExistingMark(req);

		} catch (BpmnWebServiceCallException ex) {

			LOG.error("MTS error calling checkExistingMark(): " + ex.getMessage());
			throw ex;

		} catch (Exception e) {

			LOG.error("non-MTS error calling checkExistingMark(): " + e.getMessage());
			throw e;

		}

		// NOTE: This is a bit confusing.
		// If the method returns 'false', the mark cannot be used.
		// If the method returns 'true' and also a task id list, the mark cannot
		// be used.
		// If the method returns 'true' and there is no list, the mark CAN be
		// used.
		List<BigDecimal> taskIds = res.getConsoleTaskIds();

		if (!res.isMarkExists() || (taskIds != null && !taskIds.isEmpty())) {

			LOG.debug("Mark is not valid for use. " + irTranId);
			execution.setVariable(ProcessFlowConstants.MARK_EXISTS_VAR, false);
			execution.setVariable(ProcessFlowConstants.CONSOLE_TASK_ID_LIST, taskIds);
			execution.removeVariable(ProcessFlowConstants.CONSOLE_TASK_TYPE);

		} else {

			execution.setVariable(ProcessFlowConstants.MARK_EXISTS_VAR, true);

		}

		return;
	}

	/**
	 *
	 * @param irNumber
	 * @param irTranId
	 * @param execution
	 * @return
	 */
	private void checkForNotifications(String irTranId, DelegateExecution execution) throws Exception {

		CheckForNotificationsRequest req = new CheckForNotificationsRequest();
		ConsoleTaskIdsResponse res = null;

		// Set up the Request variables
		try {

			req.setIrTranId(new BigDecimal(irTranId));

		} catch (NumberFormatException e) {

			LOG.error("Cannot convert transId(" + irTranId + ") to decimal");
			throw new Exception("Cannot convert transId(" + irTranId + ") to decimal");

		}

		// Call the MTS
		try {

			res = mtsServiceManager.checkForNotifications(req);

		} catch (BpmnWebServiceCallException ex) {

			LOG.error("MTS error calling checkExistingMark(): " + ex.getMessage());
			throw ex;

		} catch (Exception e) {

			LOG.error("non-MTS error calling checkExistingMark(): " + e.getMessage());
			throw e;

		}

		List<BigDecimal> taskIds = res.getConsoleTaskIds();

		if (taskIds != null && !taskIds.isEmpty()) {

			execution.setVariable(ProcessFlowConstants.CONSOLE_TASK_ID_LIST, taskIds);

		} else {

			execution.setVariable(ProcessFlowConstants.CONSOLE_TASK_ID_LIST, new ArrayList<BigDecimal>());

		}

		return;
	}

	/**
	 *
	 * @param execution
	 * @return
	 */
	private String createVariableString(DelegateExecution execution) {

		String varString = "";

		Map<String, Object> varMap = execution.getVariables();
		Set<String> keys = varMap.keySet();

		for (String key : keys) {

			String varAsString = "null";

			if (varMap.get(key) != null) {
				varAsString = varMap.get(key).toString();
			}
			varString += "[" + key + "->" + varAsString + "], ";
		}

		return varString;
	}

}
