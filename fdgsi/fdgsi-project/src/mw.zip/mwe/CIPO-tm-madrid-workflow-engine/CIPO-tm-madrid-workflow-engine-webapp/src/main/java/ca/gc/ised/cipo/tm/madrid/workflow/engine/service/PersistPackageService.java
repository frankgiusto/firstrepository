package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Describes a service that will handle delegated task actions from the {@code persist_package_data.bpmn}
 * process flow
 *
 * @author J. Greene
 *
 */
public interface PersistPackageService extends BusinessErrorHandler {

    /**
     * Service task method responsible for downloading packages from WIPO that are in the staging area.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getPackagesFromStaging(DelegateExecution execution);

    /**
     * Service task method responsible for persisting the downloaded package to the appropriate datastore.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void persistPackageData(DelegateExecution execution);

    /**
     * Service task method responsible for checking on the state of the service operation to persist the package to the
     * datastore.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void verifyPackagePersisted(DelegateExecution execution);

    /**
     * Service task method responsible for splitting the financial package into financial transactions (if applicable).
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void splitFinancialTransactions(DelegateExecution execution);

    /**
     * Service task method responsible for moving the package to the fail folder if an error occurs during processing.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void movePackageToFail(DelegateExecution execution);

}
