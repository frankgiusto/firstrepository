package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_LOCATION;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.io.IOUtils;
import org.springframework.core.env.Environment;

import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.model.OperationCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestXsd;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * A transfer request strategy for the Office-to-IB (outgoing ID nightly package) data.
 *
 * @author J. Greene
 *
 */
public class OfficeToIbTransferRequestCreator {

    // @Value("${mwe.dtf.madrid.site.name}")
    // private String dtfSite;

    // @Value("${mwe.dtf.madrid.ftp.dir.upload}")
    // private String uploadDirectory;

    /**
     * Creates a {@code CreateTransferRequest} object for the service operation call to DTF for an outgoing package to
     * WIPO.
     *
     * @param execution The execution metadata related to the BPMN process execution
     * @param dtfSite
     * @return a {@code CreateTransferRequest} object representing the IB-to-Office transfer request.
     * @throws IOException if there is an issue with the file attachment creation
     */
    public CreateTransferRequest createOutgoingTransferRequest(DelegateExecution execution, Environment env)
        throws IOException {

        String packageLocation = execution.getVariableLocal(PACKAGE_LOCATION, String.class);
        File packageFile = new File(packageLocation);

        CreateTransferRequest request = new CreateTransferRequest();
        TransferRequestXsd transferRequest = new TransferRequestXsd();
        request.setTransferRequest(transferRequest);

        request.getTransferRequest().setExternalSiteAcronym(env.getRequiredProperty("mwe.dtf.madrid.site.name"));
        request.getTransferRequest().setTransferItemAcronym(ProcessFlowConstants.OUT_DAILY_PKG);
        request.getTransferRequest().setOperationCode(OperationCode.OUTBOUND.codeValue());
        request.getTransferRequest().setRequestor(ProcessFlowConstants.MWE);
        // request.getTransferRequest().setExternalRefId("HWE Outbound");
        request.getTransferRequest().setNote("Activiti process instance: " + execution.getProcessInstanceId());
        request.setRacfUser(MweWorkflowUtil.getRacfUser());

        // File representation for upload
        DataHandler dtfUploadDataHandler = createUploadFileDataHandler(packageFile);
        request.setZipStream(dtfUploadDataHandler);

        // Transfer request parameters
        setParamCollection(request.getTransferRequest().getParameters(), execution, null,
            env.getRequiredProperty("mwe.dtf.madrid.ftp.dir.upload"));

        return request;
    }

    protected DataHandler createUploadFileDataHandler(File packageFile) throws IOException {
        // ALL DTF uploads must be zipped in order to preserve file names and
        // directory structures. Even though the
        // CASE export package is already zipped it must be wrapped in another
        // zip to preserve the file name (which
        // is important to WIPO)
        // ** credit to the import-export-component project.

        DataHandler dtfUploadDataHandler = null;

        if (packageFile.exists()) {
            File outputDir = packageFile.getParentFile();

            File dtfWrapper = File.createTempFile("HaguePackageUpload", ".zip", outputDir);

            ZipOutputStream dtfZos = new ZipOutputStream(new FileOutputStream(dtfWrapper));
            BufferedInputStream dtfBis = new BufferedInputStream(new FileInputStream(packageFile));
            ZipEntry dtfEntry = new ZipEntry(packageFile.getName());
            dtfZos.putNextEntry(dtfEntry);
            try {
                MweWorkflowUtil.writeBytesToOutput(dtfZos, dtfBis);
            } finally {
                IOUtils.closeQuietly(dtfBis);
                IOUtils.closeQuietly(dtfZos);
            }

            dtfUploadDataHandler = new DataHandler(new FileDataSource(dtfWrapper));
        }

        return dtfUploadDataHandler;
    }

    protected void setParamCollection(List<TransferRequestParamXsd> paramList, DelegateExecution execution,
                                      DownloadLogItem lastDownloadLogItem, String uploadDirectory) {
        TransferRequestParamXsd remoteDirParam = new TransferRequestParamXsd();
        remoteDirParam.setParameterCode(ParamNameCode.REMOTE_DIR.codeValue());
        remoteDirParam.setParameterValue(uploadDirectory);
        paramList.add(remoteDirParam);

        String packageLocation = execution.getVariableLocal(PACKAGE_LOCATION, String.class);
        Path packageLocationPath = Paths.get(packageLocation).getFileName();

        TransferRequestParamXsd fileParam = new TransferRequestParamXsd();
        fileParam.setParameterCode(ParamNameCode.FILE_NAME.codeValue());
        fileParam.setParameterValue(packageLocationPath.toString());
        paramList.add(fileParam);
    }

}
