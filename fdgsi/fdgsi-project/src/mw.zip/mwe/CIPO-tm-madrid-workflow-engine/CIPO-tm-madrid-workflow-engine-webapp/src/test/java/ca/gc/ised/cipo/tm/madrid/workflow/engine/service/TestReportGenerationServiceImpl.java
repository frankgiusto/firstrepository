package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.POLL_REPORT_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_GENERATION_CALLING_UPDATE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_GENERATION_INITIATION_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RUNNING_ERROR_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSACTION_ID;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * A test service class implementation for the generation of reports via the RGS (mocked)
 *
 * @author J. Greene
 *
 */
public class TestReportGenerationServiceImpl extends TestBusinessErrorHandlerImpl implements ReportGenerationService {

    private Integer reportGenerationInitiationStatus;

    private Integer persistReportStatus;

    private Integer reportGenerationCallingUpdateStatus;

    private Integer recoverableErrorStatus;

    @Autowired
    protected RuntimeService runtimeService;

    /** {@inheritDoc} */
    @Override
    public void initiateReportGeneration(DelegateExecution execution) {
        if (getReportGenerationInitiationStatus() != null) {
            execution.setVariable(REPORT_GENERATION_INITIATION_STATUS, getReportGenerationInitiationStatus());
        }
        System.out.println("[[initiateReportGeneration]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void pollReportService(DelegateExecution execution) {
        if (getPersistReportStatus() != null) {
            execution.setVariable(POLL_REPORT_STATUS, getPersistReportStatus());

            if (getPersistReportStatus().equals(INCOMPLETE)) {
                setPersistReportStatus(COMPLETE);
            }
        }
        System.out.println("[[pollReportService]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void updateCallingService(DelegateExecution execution) {
        if (getReportGenerationCallingUpdateStatus() != null) {
            execution.setVariable(REPORT_GENERATION_CALLING_UPDATE_STATUS, getReportGenerationCallingUpdateStatus());
        }
        System.out.println("[[updateCallingService]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void handleRgsErrorStatus(DelegateExecution execution) {
        BigDecimal transactionId = execution.getVariable(TRANSACTION_ID, BigDecimal.class);
        BigDecimal packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);
        BigDecimal testIdForDisplay = transactionId == null ? packageId : transactionId;

        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
        if (runningErrorMessageList == null) {
            runningErrorMessageList = new ArrayList<>();
        }
        runningErrorMessageList.add("Blah blah blah " + testIdForDisplay);
        execution.setVariable(RUNNING_ERROR_MESSAGE, runningErrorMessageList);

        System.out.println("[[handleRgsErrorStatus]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void evaluateCallbackErrorSeverity(DelegateExecution execution) {
        if (getRecoverableErrorStatus() != null) {
            execution.setVariable(RECOVERABLE_ERROR_CONDITION, getRecoverableErrorStatus());
        }
        System.out.println("[[evaluateCallbackErrorSeverity]]: " + execution.getVariables());
    }

    /**
     * @return the reportGenerationInitiationStatus
     */
    public Integer getReportGenerationInitiationStatus() {
        return reportGenerationInitiationStatus;
    }

    /**
     * @param reportGenerationCallingUpdateStatus the reportGenerationCallingUpdateStatus to set
     */
    public void setReportGenerationCallingUpdateStatus(Integer reportGenerationCallingUpdateStatus) {
        this.reportGenerationCallingUpdateStatus = reportGenerationCallingUpdateStatus;
    }

    /**
     * @param reportGenerationInitiationStatus the reportGenerationInitiationStatus to set
     */
    public void setReportGenerationInitiationStatus(Integer reportGenerationInitiationStatus) {
        this.reportGenerationInitiationStatus = reportGenerationInitiationStatus;
    }

    /**
     * @return the persistReportStatus
     */
    public Integer getPersistReportStatus() {
        return persistReportStatus;
    }

    /**
     * @param persistReportStatus the persistReportStatus to set
     */
    public void setPersistReportStatus(Integer persistReportStatus) {
        this.persistReportStatus = persistReportStatus;
    }

    /**
     * @return the reportGenerationCallingUpdateStatus
     */
    public Integer getReportGenerationCallingUpdateStatus() {
        return reportGenerationCallingUpdateStatus;
    }

    /**
     * @return the recoverableErrorStatus
     */
    public Integer getRecoverableErrorStatus() {
        return recoverableErrorStatus;
    }

    /**
     * @param recoverableErrorStatus the recoverableErrorStatus to set
     */
    public void setRecoverableErrorStatus(Integer recoverableErrorStatus) {
        this.recoverableErrorStatus = recoverableErrorStatus;
    }

}
