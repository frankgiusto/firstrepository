package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.BusinessErrorLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * @author J. Greene
 *
 */
@Service
public class BusinessErrorLogServiceImpl implements BusinessErrorLogService {

    protected static final Logger LOG = LoggerFactory.getLogger(BusinessErrorLogServiceImpl.class);

    @Autowired
    BusinessErrorLogDao dao;

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void insertBusinessErrorLogEntry(BusinessErrorLogItem item) {
        // Watch for column length restrictions.
        String message = item.getMessage();
        if (StringUtils.isNotBlank(message) && message.length() > 2000) {
            item.setMessage(message.substring(0, 1975) + "\n(more...)");
        }
        String errEng = item.getErrorMessageEn();
        if (StringUtils.isNotBlank(errEng) && errEng.length() > 512) {
            item.setErrorMessageEn(errEng.substring(0, 500) + "\n(more...)");
        }
        String errFr = item.getErrorMessageFr();
        if (StringUtils.isNotBlank(errFr) && errFr.length() > 512) {
            item.setErrorMessageFr(errFr.substring(0, 500) + "\n(more...)");
        }

        dao.insertBusinessErrorLogEntry(item);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void purgeOldBusinessErrorLogEntries(int olderThanNumberOfDays) {
        dao.purgeOldBusinessErrorLogEntries(olderThanNumberOfDays);
    }

    /** {@inheritDoc} */
    @Override
    public List<BusinessErrorLogItem> getBusinessErrorLogItemsByFields(BusinessErrorLogItem item) {
        return dao.getBusinessErrorLogItemsByFields(item);
    }

    /** {@inheritDoc} */
    @Override
    public List<BusinessErrorLogItem> getAllBusinessErrorLogItems() {
        return dao.getAllBusinessErrorLogItems();
    }

}
