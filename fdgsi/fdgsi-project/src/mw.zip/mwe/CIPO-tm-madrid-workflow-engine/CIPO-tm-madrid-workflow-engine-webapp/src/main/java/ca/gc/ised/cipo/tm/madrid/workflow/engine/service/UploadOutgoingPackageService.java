package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Describes a service that will handle delegated task actions from the
 * {@code upload_madrid_packages_to_wipo.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
public interface UploadOutgoingPackageService extends BusinessErrorHandler {

	/**
	 * Service task method responsible for combining and packaging all
	 * export-ready packages bound for WIPO.
	 *
	 * @param execution
	 *            The Activiti context object that holds information and
	 *            variables related to the current process execution.
	 */
	void prepareUploadPackage(DelegateExecution execution);

	/**
	 * Service task method responsible for transferring data to WIPO from CIPO.
	 * See {@link #prepareUploadPackage(DelegateExecution)}.
	 *
	 * @param execution
	 *            The Activiti context object that holds information and
	 *            variables related to the current process execution.
	 */
	void createTransferRequest(DelegateExecution execution);

	/**
	 * Service task method responsible for verifying the package transfer. See
	 * {@link #createTransferRequest(DelegateExecution)}.
	 *
	 * @param execution
	 *            The Activiti context object that holds information and
	 *            variables related to the current process execution.
	 */
	void verifyPackageTransfer(DelegateExecution execution);

	/**
	 * Service task method responsible for cleaning up (delete) outgoing
	 * packages upon successful upload to WIPO.
	 *
	 * @param execution
	 *            The Activiti context object that holds information and
	 *            variables related to the current process execution.
	 */
	void cleanUp(DelegateExecution execution);

	/**
	 * Service task method responsible for moving the prepared upload package to
	 * an archive folder upon failure.
	 *
	 * @param execution
	 *            The Activiti context object that holds information and
	 *            variables related to the current process execution.
	 */
	void movePackageToFail(DelegateExecution execution);
}
