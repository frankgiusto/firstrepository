package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * This service class just feeds constant values to the bpmn engine from diagrams. There is currently no way to wire in
 * constants directly so this awful workaround is an option.
 *
 * @author J. Greene
 *
 */
@Component
public final class ProcessFlowConstantService implements Serializable {

    private static final long serialVersionUID = -3333769075879623848L;

    public Integer getErrorWithRetry() {
        return ERROR_WITH_RETRY;
    }

    public Integer getError() {
        return ERROR;
    }

    public Integer getIncomplete() {
        return INCOMPLETE;
    }

    public Integer getComplete() {
        return COMPLETE;
    }

    public Integer getNothingToDo() {
        return NOTHING_TO_DO;
    }

    public String getInMadridFees() {
        return IN_MADRID_FEES;
    }

    public String getInNotifPkg() {
        return IN_NOTIF_PKG;
    }

    public String getInNotifImgPkg() {
        return IN_NOTIF_IMG_PKG;
    }

    public String getInIrregPkg() {
        return IN_IRREG_PKG;
    }

    public String getOfficeToIbPkg() {
        return OUT_DAILY_PKG;
    }

    public String getInFinanceFees() {
        return IN_FINANCE_FEES;
    }

    public Integer getRgsErrorStatus() {
        return RGS_ERROR_STATUS;
    }

}
