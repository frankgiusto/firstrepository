package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATED_PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_PACKAGE_CALL_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_UPLOAD_PACKAGE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR_WITH_RETRY;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NUMBER_OF_REATTEMPTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUTPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_CREATION_VERIFY_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_UNIT_ITEM;

import java.io.Serializable;
import java.math.BigDecimal;

import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageOutgoingTransactionsService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * A service that will handle delegated task actions from the {@code package_hague_packages_to_wipo.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
@Service
public class PackageOutgoingTransactionsServiceImpl extends BusinessErrorHandlerImpl
    implements PackageOutgoingTransactionsService, Serializable {

    protected static final Logger LOG = LoggerFactory.getLogger(PackageOutgoingTransactionsServiceImpl.class);

    private static final long serialVersionUID = -8548582305522508345L;

    @Autowired
    MpsServiceManager mpsServiceManager;

    /**
     * {@inheritDoc}
     * <p>
     * Uses a web service call to create and persist a package of message transactions to be uploaded to WIPO. A
     * success/fail process variable called {@code createUploadPackageStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  1]} - OK,<br/>
     * {@code [ -1]} - Error,<br/>
     * {@code [-10]} - Error with retry<br/>
     * </p>
     *
     */
    @Override
    public void createUploadTransactionPackage(DelegateExecution execution) {
        Integer createUploadPackageStatus = COMPLETE;
        String outputFolder = execution.getVariable(OUTPUT_FOLDER, String.class);

        try {
            BigDecimal packageId = mpsServiceManager.exportPackage(outputFolder);

            execution.setVariable(CREATED_PACKAGE_ID, packageId);
            LOG.debug("Export package created with package ID " + packageId);
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            Integer numberOfReattempts = execution.getVariable(NUMBER_OF_REATTEMPTS, Integer.class);
            if (numberOfReattempts != null && numberOfReattempts > 0) {
                createUploadPackageStatus = ERROR_WITH_RETRY;
                execution.setVariable(NUMBER_OF_REATTEMPTS, --numberOfReattempts);
            } else {
                createUploadPackageStatus = ERROR;
            }
        }

        execution.setVariable(CREATE_UPLOAD_PACKAGE_STATUS, createUploadPackageStatus);
    }

    @Override
    public void verifyPackageCreated(DelegateExecution execution) {
        BigDecimal createdPackageId = execution.getVariableLocal(CREATED_PACKAGE_ID, BigDecimal.class);
        PackageUnit packageUnit = execution.getVariableLocal(PACKAGE_UNIT_ITEM, PackageUnit.class);
        Integer packageCreationVerifyStatus = COMPLETE;
        String infoString = "Variable packageStatus returned with value [%s]";

        if (packageUnit != null) {
            try {
                PackageStatusEnum packageStatus = mpsServiceManager.getPackageProcessingStatus(createdPackageId,
                    packageUnit);

                if (packageStatus == null) {
                    execution.setVariableLocal(CREATE_PACKAGE_CALL_STATUS, ERROR);
                } else {

                    switch (packageStatus) {
                        case IB_TO_OFFICE_UNPROCESSED:
                        case MPS_IMPORT_SPLIT_TRANSACTIONS:
                            packageCreationVerifyStatus = INCOMPLETE;
                            break;
                        case MPS_IMPORT_COMPLETE:
                            break;
                        case MPS_IMPORT_VALIDATION_ERROR:
                        case MPS_IMPORT_ERROR:
                            Integer loopCounter = execution.getVariableLocal("loopCounter", Integer.class);
                            String loopReattemptCounter = "numberOfReattemptsLocal" + loopCounter;
                            Integer numReattemptsLocal = execution.getVariableLocal(loopReattemptCounter,
                                Integer.class);
                            if (numReattemptsLocal == null) {
                                Integer numReattempts = execution.getVariable(NUMBER_OF_REATTEMPTS, Integer.class);
                                execution.setVariableLocal(loopReattemptCounter, numReattempts);
                                numReattemptsLocal = numReattempts;
                            }

                            if (numReattemptsLocal > 0) {
                                packageCreationVerifyStatus = ERROR_WITH_RETRY;
                                execution.setVariableLocal(loopReattemptCounter, --numReattemptsLocal);
                            } else {
                                registerGenericMweBusinessError(execution,
                                    String.format(infoString, packageStatus.value()));
                                packageCreationVerifyStatus = ERROR;
                            }
                            break;
                        default:
                            registerGenericMweBusinessError(execution,
                                "Variable packageStatus returned with unrecognized value [" + packageStatus.value()
                                    + "]");
                            packageCreationVerifyStatus = ERROR;
                    }
                    LOG.debug(String.format(infoString, packageStatus.value()));
                }
            } catch (BpmnWebServiceCallException bpe) {
                execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
                packageCreationVerifyStatus = ERROR;
            }
        }
        execution.setVariableLocal(PACKAGE_CREATION_VERIFY_STATUS, packageCreationVerifyStatus);
    }
}
