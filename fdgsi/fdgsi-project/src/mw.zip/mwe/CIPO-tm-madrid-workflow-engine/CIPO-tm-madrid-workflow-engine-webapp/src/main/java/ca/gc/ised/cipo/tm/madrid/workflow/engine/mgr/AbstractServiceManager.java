package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.ws.BindingProvider;

import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.SystemInfo;

/**
 * An abstract class for MWE's service manager classes.
 *
 * @author J. Greene
 *
 */
public abstract class AbstractServiceManager {

    protected static final Logger LOG = LoggerFactory.getLogger(AbstractServiceManager.class);

    protected static final String WSDL_SUFFIX = "?WSDL";

    /**
     * Gets the {@code BindingProvider} associated with the service client.
     *
     * @return the {@code BindingProvider}
     */
    protected abstract BindingProvider getBindingProvider();

    protected StringBuilder getWebServiceErrorMessageStringBuilder(Throwable t) {
        StringBuilder messageStringBuilder = new StringBuilder();
        // @formatter:off
        messageStringBuilder
            .append("Exception processing %1$s service request for operation [%2$s]:")
            .append(SystemUtils.LINE_SEPARATOR)
            .append("\t\t")
            .append(t.getMessage());
        // @formatter:on

        return messageStringBuilder;
    }

    protected void handleWebServiceException(Throwable t, String appName, String methodName)
        throws BpmnWebServiceCallException {
        LOG.error("A web service execption was thrown.", t);
        String message = String.format(getWebServiceErrorMessageStringBuilder(t).toString(), appName, methodName);
        BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException(message);
        serviceException.getBusinessErrorLogItem().setComponentAcronym(appName);
        serviceException.getBusinessErrorLogItem().setServiceName(ProcessFlowConstants.MWE_SERVICE_NAME);
        throw serviceException;
    }

    protected BusinessErrorLogItem buildBusinessErrorLogItem(ServiceFaultDetails fault) {
        BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem();
        businessErrorLogItem.setCipoServiceFaultOrigin(true);

        businessErrorLogItem.setComponentAcronym(fault.getComponentAcronym());
        businessErrorLogItem.setServiceName(fault.getServiceName());
        businessErrorLogItem.setReturnCode(new Long(fault.getReturnCode()));
        businessErrorLogItem.setReasonCode(new Long(fault.getReasonCode()));
        businessErrorLogItem.setErrorMessageEn(fault.getEnErrorMsg());
        businessErrorLogItem.setErrorMessageFr(fault.getFrErrorMsg());

        return businessErrorLogItem;
    }

    /**
     * Checks the status of the SOAP service by using a simple HTTP connection to fetch the WSDL.
     *
     * @param systemInfo The SystemInfo object to be updated
     * @see SystemInfo
     */
    public void updateServiceStatus(SystemInfo systemInfo) {
        String status = SystemInfo.STATUS_INDETERMINATE;

        String url = (String) getBindingProvider().getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        String wsdlUrl = url + WSDL_SUFFIX;
        LOG.info("Checking status of service at " + url);

        try {
            HttpURLConnection conn = (HttpURLConnection) new URL(wsdlUrl).openConnection();
            int responseCode = conn.getResponseCode();

            if (HttpStatus.OK.value() <= responseCode && responseCode < HttpStatus.BAD_REQUEST.value()) {
                status = SystemInfo.STATUS_OK;
            } else {
                status = SystemInfo.STATUS_DOWN;
            }
        } catch (Exception ex) {
            LOG.warn("Cannot determine status of the service located at {" + url + "}", ex);
        }

        systemInfo.createClientInfoInstance(status, url);
    }

}
