package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import java.math.BigDecimal;
import java.util.List;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingPairCriteria;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskIdsResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.OfficeToIbProcessActions;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ReportTypeEnum;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;

public interface MtsServiceManager {

	/**
	 * Wraps the MTS call to get the list of transaction details for various
	 * input types. For our use, we only need the transaction status. Also
	 * handles response.
	 *
	 * @param transactionCriteria
	 *            The transaction criteria object
	 * @return The WSDL specified operation output parameter
	 * @throws BpmnWebServiceCallException
	 */
	List<TransactionDetail> getTransactionList(TransactionCriteria transactionCriteria)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to process an automated Madrid TM transaction.
	 *
	 * @param apc
	 *            The WS criteria object
	 * @return The WSDL specified operation output parameter
	 * @throws BpmnWebServiceCallException
	 */
	AutomatedProcessResponse processAutomatedTransaction(AutomaticProcessingCriteria apc)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to process an automated Madrid TM transaction pair.
	 *
	 * @param appc
	 *            The WS criteria object
	 * @return The WSDL specified operation output parameter
	 * @throws BpmnWebServiceCallException
	 */
	AutomatedProcessResponse processAutomatedTransactionPair(AutomaticProcessingPairCriteria appc)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to process a manual Madrid TM transaction.
	 *
	 * @param criteria
	 *            The WS criteria object
	 * @return The WSDL specified operation output parameter
	 * @throws BpmnWebServiceCallException
	 */
	ManualProcessResponse processManualTransaction(ManualProcessingCriteria criteria)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to update the console task status.
	 *
	 * @param consoleTaskId
	 *            The WS criteria object
	 * @param statusType
	 *            The WS criteria object
	 * @throws BpmnWebServiceCallException
	 */
	void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType statusType)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to update the console task reference.
	 *
	 * @param userTaskId
	 *            The WS criteria object
	 * @param consoleTaskId
	 *            The WS criteria object
	 * @throws BpmnWebServiceCallException
	 */
	void updateConsoleTaskReference(String userTaskId, BigDecimal consoleTaskId) throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to check existing mark.
	 *
	 * @param req
	 *            The WS criteria object
	 * @return The WSDL specified operation output parameter
	 * @throws BpmnWebServiceCallException
	 */
	ExistingMarkResponse checkExistingMark(ExistingMarkRequest req) throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to check for notificications
	 *
	 * @param req
	 * @return
	 * @throws BpmnWebServiceCallException
	 */
	ConsoleTaskIdsResponse checkForNotifications(CheckForNotificationsRequest req) throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to get process actions to send to WIPO.
	 *
	 * @return List of actions from Intrepid
	 * @throws BpmnWebServiceCallException
	 */
	OfficeToIbProcessActions getOfficeToIbProcessActions(ProcessActionCategoryType type)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps the MTS call to create a transaction to be sent to WIPO.
	 *
	 * @param processActionsMeta
	 *            The data to be sent
	 * @return An object containing a Transaction ID, among other things.
	 * @throws BpmnWebServiceCallException
	 */
	OfficeToIbTransactionResponse createOfficeToIbTransaction(ProcessActionsMeta processActionsMeta)
			throws BpmnWebServiceCallException;

	ManualProcessResponse createOfficeToIbManualTask(ProcessActionsMeta processActionsMeta)
			throws BpmnWebServiceCallException;

	public String generateReport(BigDecimal transactionId, ReportTypeEnum reportTypeCode)
			throws BpmnWebServiceCallException;

	public BigDecimal generateReportNotification(String reportJobId, BigDecimal transactionId,
			ReportTypeEnum reportTypeCode) throws BpmnWebServiceCallException;

}