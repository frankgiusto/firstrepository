package ca.gc.ised.cipo.tm.madrid.workflow.ws;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ActivitiObjectNotFoundException;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ised.cipo.tm.madrid.exception.UserAuthorityException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.MadridUserAuthorityServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.mwe.AckNotificationRequest;
import ca.gc.ised.cipo.tm.mwe.AssignUserTasksRequest;
import ca.gc.ised.cipo.tm.mwe.CompleteUserTaskRequest;
import ca.gc.ised.cipo.tm.mwe.CreateNotificationRequest;
import ca.gc.ised.cipo.tm.mwe.MWEServiceFault;
import ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType;
import ca.gc.ised.cipo.tm.mwe.ReassignTaskGroupRequest;
import ca.gc.ised.cipo.tm.mwe.UnassignUserTasksRequest;

@Component
public class MadridWorkflowServiceImpl extends MadridWorkflowService implements MadridWorkflowEngineServicePortType {

	private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private TaskService taskService;

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private MadridUserAuthorityServiceImpl madridUserAuthorityService;

	@Override
	public HeartbeatResponseType getHeartbeat() throws MWEServiceFault {

		HeartbeatResponseType res = new HeartbeatResponseType();

		String status = "";
		String ipAddress = "";
		String nodeName = "";

		try {

			ipAddress = InetAddress.getLocalHost().getHostAddress();
			nodeName = InetAddress.getLocalHost().getHostName();
			status = "online";

		} catch (UnknownHostException e) {

			LOG.error("Error getting the Heartbeat status", e);
			ServiceFaultDetails details = new ServiceFaultDetails();

			details.setComponentAcronym("MWE");
			details.setEnErrorMsg("Error getting the Heartbeat status.");
			details.setFrErrorMsg("Erreur, l'obtention du statut pour le service n'est pas disponible.");
			details.setReasonCode(1);
			details.setReturnCode(-99);
			details.setServiceName("Madrid Workflow Engine Service ");
			details.setStackTrace(Arrays.toString(e.getStackTrace()));

			throw new MWEServiceFault("Error getting the Heartbeat status", details);
		}

		res.setIpAddress(ipAddress);
		res.setNodeName(nodeName);
		res.setStatus(status);

		LOG.trace("Successfully processed JAX-WS getHeartbeat call with IP: " + ipAddress + ", Node name: " + nodeName
				+ " and Status: " + status);

		return res;
	}

	@Override
	public void assignUserTasks(AssignUserTasksRequest assignUserTasksRequest) throws MWEServiceFault {

		String authId = assignUserTasksRequest.getAuthId();
		String assignee = assignUserTasksRequest.getAssigneeId();
		List<String> taskList = assignUserTasksRequest.getTaskIdList();

		try {

			// Perform Input validation
			this.validateAssignUserTasksRequest(assignUserTasksRequest);

			// Perform verification on all tasks first.
			for (String taskId : taskList) {

				this.madridUserAuthorityService.verifyAssignAuthority(authId, taskId, assignee);

			}

			// Then assign them so long as none fail.
			for (String taskId : taskList) {

				// Do an unassign in case this task is already assigned.
				this.processEngine.getTaskService().unclaim(taskId);

				this.processEngine.getTaskService().claim(taskId, assignee);

			}

		} catch (UserAuthorityException e) {

			// TODO: Set reason and return codes
			ServiceFaultDetails faultInfo = new ServiceFaultDetails();
			faultInfo.setServiceName("MWE");
			faultInfo.setReasonCode(e.getErrorType());
			MWEServiceFault ex = new MWEServiceFault(e.getErrorMsg(), faultInfo);

			throw ex;

		} catch (Exception e) {

			ServiceFaultDetails details = new ServiceFaultDetails();
			details.setServiceName("MWE");
			details.setEnErrorMsg(e.getMessage());

			MWEServiceFault fault = new MWEServiceFault(e.getMessage(), details);

			throw fault;
		}

	}

	@Override
	public void unassignUserTasks(UnassignUserTasksRequest unassignUserTasksRequest) throws MWEServiceFault {

		String authId = unassignUserTasksRequest.getAuthId();
		List<String> taskList = unassignUserTasksRequest.getTaskIdList();

		try {

			// Perform Input validation
			this.validateUnassignUserTasksRequest(unassignUserTasksRequest);

			// Perform verification on all tasks first.
			for (String taskId : taskList) {

				this.madridUserAuthorityService.verifyUnassignAuthority(authId, taskId);

			}

			// Un-assign any users assigned to the task.
			for (String taskId : taskList) {

				this.processEngine.getTaskService().unclaim(taskId);

			}

		} catch (UserAuthorityException e) {

			// TODO: Set reason and return codes
			ServiceFaultDetails faultInfo = new ServiceFaultDetails();
			faultInfo.setServiceName("MWE");
			faultInfo.setReasonCode(e.getErrorType());
			MWEServiceFault ex = new MWEServiceFault(e.getErrorMsg(), faultInfo);

			throw ex;

		} catch (Exception e) {

			ServiceFaultDetails details = new ServiceFaultDetails();
			details.setServiceName("MWE");
			details.setEnErrorMsg(e.getMessage());

			MWEServiceFault fault = new MWEServiceFault(e.getMessage(), details);

			throw fault;
		}

		// return res;
	}

	@Override
	public void reassignTaskGroup(ReassignTaskGroupRequest reassignTaskGroupRequest) throws MWEServiceFault {

		String authId = reassignTaskGroupRequest.getAuthId();
		String groupId = reassignTaskGroupRequest.getGroupId();
		List<String> taskList = reassignTaskGroupRequest.getTaskIdList();

		try {

			// Perform Input validation
			this.validateReassignTaskGroupRequest(reassignTaskGroupRequest);

			// Perform verification on all tasks first.
			for (String taskId : taskList) {

				this.madridUserAuthorityService.verifyReassignTaskGroup(authId, taskId, groupId);

			}

			// Re-assign the candidate group for each Task
			for (String taskId : taskList) {

				// Unassigns any assigned users
				this.processEngine.getTaskService().unclaim(taskId);

				// Delete any candidate groups
				List<IdentityLink> indentityLinks = this.processEngine.getTaskService().getIdentityLinksForTask(taskId);
				for (IdentityLink identityLink : indentityLinks) {

					if (identityLink.getType() != null && identityLink.getType().equals(IdentityLinkType.CANDIDATE)
							&& identityLink.getGroupId() != null) {

						this.processEngine.getTaskService().deleteGroupIdentityLink(taskId, identityLink.getGroupId(),
								identityLink.getType());

					}

				}

				// Assign the new candidate group
				taskService.addCandidateGroup(taskId, groupId);
			}

		} catch (UserAuthorityException e) {

			// TODO: Set reason and return codes
			ServiceFaultDetails faultInfo = new ServiceFaultDetails();
			faultInfo.setServiceName("MWE");
			faultInfo.setReasonCode(e.getErrorType());
			MWEServiceFault ex = new MWEServiceFault(e.getErrorMsg(), faultInfo);

			throw ex;

		} catch (ActivitiObjectNotFoundException e) {

			// TODO: Set reason and return codes
			ServiceFaultDetails faultInfo = new ServiceFaultDetails();
			faultInfo.setServiceName("MWE");
			// faultInfo.setReasonCode();
			MWEServiceFault ex = new MWEServiceFault(e.getMessage(), faultInfo);

			throw ex;

		} catch (Exception e) {

			ServiceFaultDetails details = new ServiceFaultDetails();
			details.setServiceName("MWE");
			details.setEnErrorMsg(e.getMessage());

			MWEServiceFault fault = new MWEServiceFault(e.getMessage(), details);

			throw fault;
		}

	}

	@Override
	public void completeUserTask(CompleteUserTaskRequest completeUserTaskRequest) throws MWEServiceFault {

		String assignee = completeUserTaskRequest.getAssigneeId();
		String taskId = completeUserTaskRequest.getTaskId();
		// String compState = completeUserTaskRequest.getCompletionState();
		// String forwardStatus =
		// completeUserTaskRequest.getForwardTaskStatus();

		try {

			// Perform Input validation
			this.validateCompleteUserTaskRequest(completeUserTaskRequest);

			// TODO(ghamer) - Put variables on the process associated with the
			// task

			this.madridUserAuthorityService.verifyTaskCompletionAuthority(taskId, assignee);

			this.processEngine.getTaskService().complete(taskId);

		} catch (UserAuthorityException e) {

			// TODO: Set reason and return codes
			ServiceFaultDetails faultInfo = new ServiceFaultDetails();
			faultInfo.setServiceName("MWE");
			faultInfo.setReasonCode(e.getErrorType());
			MWEServiceFault ex = new MWEServiceFault(e.getErrorMsg(), faultInfo);

			throw ex;

		} catch (Exception e) {

			ServiceFaultDetails details = new ServiceFaultDetails();
			details.setServiceName("MWE");
			details.setEnErrorMsg(e.getMessage());

			MWEServiceFault fault = new MWEServiceFault(e.getMessage(), details);

			throw fault;
		}

	}

	@Override
	public void createNotification(CreateNotificationRequest createNotificationRequest) throws MWEServiceFault {

		String taskId = createNotificationRequest.getTaskId();
		String groupId = createNotificationRequest.getGroupId();

		try {

			this.validateCreateNotificationRequest(createNotificationRequest);

			Map<String, Object> processVars = new HashMap<String, Object>();
			processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, new BigDecimal(taskId));
			processVars.put(ProcessFlowConstants.CANDIDATE_GROUP_ID, groupId);

			this.runtimeService.startProcessInstanceByKey("createNotification", processVars);

		} catch (Exception e) {

			ServiceFaultDetails details = new ServiceFaultDetails();
			details.setServiceName("MWE");
			details.setEnErrorMsg(e.getMessage());

			MWEServiceFault fault = new MWEServiceFault(e.getMessage(), details);

			throw fault;
		}

	}

	@Override
	public void ackNotification(AckNotificationRequest ackNotificationRequest) throws MWEServiceFault {

		String assignee = ackNotificationRequest.getAssigneeId();
		List<String> taskList = ackNotificationRequest.getTaskIdList();

		try {

			// Perform Input validation
			this.validateAckNotificationRequest(ackNotificationRequest);

			for (String taskId : taskList) {

				this.madridUserAuthorityService.verifyAckNotificationAuthority(taskId, assignee);

			}

			// For notifications, we both assign and complete the Task in this
			// call
			for (String taskId : taskList) {

				this.processEngine.getTaskService().setAssignee(taskId, assignee);

				this.processEngine.getTaskService().complete(taskId);

			}

		} catch (UserAuthorityException e) {

			// TODO: Set reason and return codes
			ServiceFaultDetails faultInfo = new ServiceFaultDetails();
			faultInfo.setServiceName("MWE");
			faultInfo.setReasonCode(e.getErrorType());
			MWEServiceFault ex = new MWEServiceFault(e.getErrorMsg(), faultInfo);

			throw ex;

		} catch (Exception e) {

			ServiceFaultDetails details = new ServiceFaultDetails();
			details.setServiceName("MWE");
			details.setEnErrorMsg(e.getMessage());

			MWEServiceFault fault = new MWEServiceFault(e.getMessage(), details);

			throw fault;
		}

	}

	/**
	 *
	 * @param req
	 * @throws Exception
	 */
	private void validateAssignUserTasksRequest(AssignUserTasksRequest req) throws Exception {

		if (req.getAuthId() == null || req.getAuthId().isEmpty()) {

			String errStr = "The Authority Id must not be null.";
			throw new Exception(errStr);

		}

		if (req.getTaskIdList() == null || req.getTaskIdList().isEmpty()) {

			String errStr = "The Task Id List must contain at least one Task Id.";
			throw new Exception(errStr);

		}

		if (req.getAssigneeId() == null || req.getAssigneeId().isEmpty()) {

			String errStr = "The Assignee User Id must not be null.";
			throw new Exception(errStr);

		}

	}

	/**
	 *
	 * @param req
	 * @throws Exception
	 */
	private void validateUnassignUserTasksRequest(UnassignUserTasksRequest req) throws Exception {

		if (req.getAuthId() == null || req.getAuthId().isEmpty()) {

			String errStr = "The Authority Id must not be null.";
			throw new Exception(errStr);

		}

		if (req.getTaskIdList() == null || req.getTaskIdList().isEmpty()) {

			String errStr = "The Task Id List must contain at least one Task Id.";
			throw new Exception(errStr);

		}

	}

	/**
	 *
	 * @param req
	 * @throws Exception
	 */
	private void validateReassignTaskGroupRequest(ReassignTaskGroupRequest req) throws Exception {

		if (req.getAuthId() == null || req.getAuthId().isEmpty()) {

			String errStr = "The Authority Id must not be null.";
			throw new Exception(errStr);

		}
		;

		if (req.getTaskIdList() == null || req.getTaskIdList().isEmpty()) {

			String errStr = "The Task Id List must contain at least one Task Id.";
			throw new Exception(errStr);

		}

		if (req.getGroupId() == null || req.getGroupId().isEmpty()) {

			String errStr = "The Group Id must not be null.";
			throw new Exception(errStr);

		}

	}

	/**
	 *
	 * @param req
	 * @throws Exception
	 */
	private void validateCompleteUserTaskRequest(CompleteUserTaskRequest req) throws Exception {

		if (req.getTaskId() == null || req.getTaskId().isEmpty()) {

			String errStr = "The Task Id must not be null.";
			throw new Exception(errStr);

		}

		if (req.getAssigneeId() == null || req.getAssigneeId().isEmpty()) {

			String errStr = "The Assignee User Id must not be null.";
			throw new Exception(errStr);

		}

	}

	/**
	 *
	 * @param req
	 * @throws Exception
	 */
	private void validateCreateNotificationRequest(CreateNotificationRequest req) throws Exception {

		if (req.getTaskId() == null) {

			String errStr = "The Task Id must not be null.";
			throw new Exception(errStr);

		}

		try {

			new BigDecimal(req.getTaskId());

		} catch (Exception e) {

			String errStr = "The Task Id cannot be parsed to a number (" + req.getTaskId() + ").";
			throw new Exception(errStr);

		}

		if (req.getGroupId() == null) {

			String errStr = "The Group Id must not be null.";
			throw new Exception(errStr);

		}

	}

	/**
	 *
	 * @param req
	 * @throws Exception
	 */
	private void validateAckNotificationRequest(AckNotificationRequest req) throws Exception {

		if (req.getTaskIdList() == null || req.getTaskIdList().isEmpty()) {

			String errStr = "The Task Id List must contain at least one Task Id.";
			throw new Exception(errStr);

		}

		if (req.getAssigneeId() == null || req.getAssigneeId().isEmpty()) {

			String errStr = "The Assignee User Id must not be null.";
			throw new Exception(errStr);

		}

	}

}
