package util;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 *
 * @author hamerg
 *
 */
public class TestMadridMethodVarsService {

    protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    /**
     *
     */
    private Map<String, Map<String, Object>> methodVariables = new HashMap<String, Map<String, Object>>();

    /**
     *
     * @return
     */
    public Map<String, Object> getMethodVars() {

        String callingMethod = this.findCallingMethod();

        Map<String, Object> methodVars = this.methodVariables.get(callingMethod);

        return methodVars;
    }

    /**
     *
     * @param methodName
     * @param varName
     * @param value
     */
    public void setMethodVar(String methodName, String varName, Object value) {

        Map<String, Object> methodVars = this.methodVariables.get(methodName);
        if (methodVars == null) {

            methodVars = new HashMap<String, Object>();

            this.methodVariables.put(methodName, methodVars);

        }

        methodVars.put(varName, value);

    }

    /**
     *
     */
    public void reset() {

        this.methodVariables = new HashMap<String, Map<String, Object>>();
    }

    private String findCallingMethod() {

        String callingMethod = null;

        Boolean methodFound = false;
        Integer foundIndex = null;

        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        for (int i = 0; (!methodFound && i < stackTraceElements.length); i++) {

            StackTraceElement elem = stackTraceElements[i];
            if (elem.getMethodName().equals("getMethodVars")) {
                foundIndex = i;
                methodFound = true;
            }

        }

        if (foundIndex != null) {

            StackTraceElement callingClass = stackTraceElements[foundIndex + 1];
            String fullClassname = callingClass.getClassName();
            String className = fullClassname.substring(fullClassname.lastIndexOf(".") + 1, fullClassname.length());

            callingMethod = className + "." + callingClass.getMethodName();

            // LOG.debug( "The calling method was -> " + callingMethod );
        }

        return callingMethod;
    }

}
