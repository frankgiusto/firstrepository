package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.util.Map;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import util.TestMadridMethodVarsService;

public class TestMadridGroupAssignmentServiceImpl implements MadridGroupAssignmentService {

    @Autowired
    private TestMadridMethodVarsService methodVarsService;

    @Override
    public String getCandidateGroupForTask(DelegateExecution execution) {

        Map<String, Object> methodVars = methodVarsService.getMethodVars();

        if (methodVars != null) {

            // Throw an error if the var is set
            Boolean throwError = (Boolean) methodVars.get(ProcessFlowConstants.ERR_MSG_IND_VAR);
            if (throwError != null && throwError == true) {

                BpmnError ex = new BpmnError("madridError", "This is an error");

                throw ex;
            }

            // Set any other variables indicated.
            for (String key : methodVars.keySet()) {

                execution.setVariable(key, methodVars.get(key));
            }
        }

        // TODO Auto-generated method stub
        return "SOME_GROUP";
    }

    @Override
    public void setCallingProcessVariable(DelegateExecution execution) {

        // TODO Auto-generated method stub

    }

}
