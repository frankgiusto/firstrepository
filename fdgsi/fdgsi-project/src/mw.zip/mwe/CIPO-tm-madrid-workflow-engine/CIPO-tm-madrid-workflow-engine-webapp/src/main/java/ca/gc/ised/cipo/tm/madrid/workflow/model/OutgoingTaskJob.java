package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Domain object to contain fields for starting an outgoing message job (messages from Office to IB).
 *
 * @author J. Greene
 *
 */
public final class OutgoingTaskJob extends MweJob implements Serializable {

    private static final long serialVersionUID = 1628585904777632324L;

    private BigDecimal consoleTaskId;

    private String candidateGroupId;

    public BigDecimal getConsoleTaskId() {
        return consoleTaskId;
    }

    public void setConsoleTaskId(BigDecimal consoleTaskId) {
        this.consoleTaskId = consoleTaskId;
    }

    public String getCandidateGroupId() {
        return candidateGroupId;
    }

    public void setCandidateGroupId(String candidateGroupId) {
        this.candidateGroupId = candidateGroupId;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        // @formatter:off
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("consoleTaskId", consoleTaskId)
            .append("candidateGroupId", candidateGroupId)
            .append("processInstanceId", processInstanceId)
            .toString();
        // @formatter:on
    }
}
