package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Describes a service that will handle delegated task actions from the {@code package_madrid_packages_to_wipo.bpmn}
 * process flow
 *
 * @author J. Greene
 *
 */
public interface PackageOutgoingTransactionsService extends BusinessErrorHandler {

    /**
     * Service task method responsible for creating a package of message transactions to upload to WIPO.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void createUploadTransactionPackage(DelegateExecution execution);

    void verifyPackageCreated(DelegateExecution execution);

}
