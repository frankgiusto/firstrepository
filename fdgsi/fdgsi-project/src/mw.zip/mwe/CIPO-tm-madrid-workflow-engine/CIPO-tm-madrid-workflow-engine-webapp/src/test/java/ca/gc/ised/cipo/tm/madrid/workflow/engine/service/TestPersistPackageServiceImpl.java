package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;

import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * A test service class to be used for unit testing the persist_hague_package_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
public class TestPersistPackageServiceImpl extends TestBusinessErrorHandlerImpl
    implements PersistPackageService, Serializable {

    private static final long serialVersionUID = 2586601570528399522L;

    protected Integer packageFetchStatusReturnObject;

    protected Integer packagePersistVerifyStatusReturnObject;

    protected Integer persistPackageCallStatusReturnObject;

    protected Integer hfsSplitStatusReturnObject;

    protected List<PackageUnit> packageUnitListReturnObject;

    /** {@inheritDoc} */
    @Override
    public void getPackagesFromStaging(DelegateExecution execution) {
        Integer out = null;
        if (getPackageFetchStatusReturnObject() != null) {
            out = getPackageFetchStatusReturnObject();
        }
        execution.setVariable(PACKAGE_FETCH_STATUS, out);
        if (getPackageUnitListReturnObject() != null) {
            execution.setVariable(PACKAGE_UNIT_LIST, getPackageUnitListReturnObject());
        }
        System.out.println("[[getPackageFromStaging]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void persistPackageData(DelegateExecution execution) {
        Integer persistPackageCallStatus = null;
        if (getPersistPackageCallStatusReturnObject() != null) {
            persistPackageCallStatus = getPersistPackageCallStatusReturnObject();
        }
        execution.setVariableLocal(PERSIST_PACKAGE_CALL_STATUS, persistPackageCallStatus);
        execution.setVariableLocal(PERSISTED_PACKAGE_ID, new BigDecimal(1000));
        System.out.println("[[persistPackageData]]: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void movePackageToFail(DelegateExecution execution) {
        System.out.println("[[movePackageToFail]]: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void verifyPackagePersisted(DelegateExecution execution) {
        Integer out = null;
        if (getPackagePersistVerifyStatusReturnObject() != null) {
            out = getPackagePersistVerifyStatusReturnObject();
            execution.setVariableLocal(PACKAGE_PERSISTENCE_VERIFY_STATUS, out);
        }

        if (out.equals(INCOMPLETE)) {
            setPackagePersistVerifyStatusReturnObject(ERROR);
        }
        if (out.equals(ERROR)) {
            execution.setVariableLocal(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with package persist.");
        }
        if (out.equals(ERROR_WITH_RETRY)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error (with retry) with package persist.");
            Integer loopCounter = execution.getVariableLocal("loopCounter", Integer.class);
            String loopReattemptCounter = "numberOfReattemptsLocal" + loopCounter;
            Integer numReattemptsLocal = execution.getVariableLocal(loopReattemptCounter, Integer.class);
            if (numReattemptsLocal == null) {
                Integer numReattempts = execution.getVariable(NUMBER_OF_REATTEMPTS, Integer.class);
                execution.setVariableLocal(loopReattemptCounter, numReattempts);
                numReattemptsLocal = new Integer(numReattempts);
            }

            if (numReattemptsLocal > 0) {
                execution.setVariableLocal(PACKAGE_PERSISTENCE_VERIFY_STATUS, ERROR_WITH_RETRY);
                execution.setVariableLocal(loopReattemptCounter, --numReattemptsLocal);
            } else {
                execution.setVariableLocal(PACKAGE_PERSISTENCE_VERIFY_STATUS, COMPLETE);
            }
        }
        System.out.println("[[verifyPackagePersisted]]: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void splitFinancialTransactions(DelegateExecution execution) {
        if (getHfsSplitStatusReturnObject() != null) {
            execution.setVariableLocal("hfsSplitStatus", getHfsSplitStatusReturnObject());
        }

        System.out.println("[[splitFinancialTransactions]]: " + execution.getVariablesLocal());
    }

    /**
     * @return the packageFetchStatusReturnObject
     */
    public Integer getPackageFetchStatusReturnObject() {
        return packageFetchStatusReturnObject;
    }

    /**
     * @param packageFetchStatusReturnObject the packageFetchStatusReturnObject to set
     */
    public void setPackageFetchStatusReturnObject(Integer packageFetchStatusReturnObject) {
        this.packageFetchStatusReturnObject = packageFetchStatusReturnObject;
    }

    /**
     * @return the packagePersistVerifyStatusReturnObject
     */
    public Integer getPackagePersistVerifyStatusReturnObject() {
        return packagePersistVerifyStatusReturnObject;
    }

    /**
     * @param packagePersistVerifyStatusReturnObject the packagePersistVerifyStatusReturnObject to set
     */
    public void setPackagePersistVerifyStatusReturnObject(Integer packagePersistStatusReturnObject) {
        this.packagePersistVerifyStatusReturnObject = packagePersistStatusReturnObject;
    }

    /**
     * @return the packageUnitListReturnObject
     */
    public List<PackageUnit> getPackageUnitListReturnObject() {
        return packageUnitListReturnObject;
    }

    /**
     * @param packageUnitListReturnObject the packageUnitListReturnObject to set
     */
    public void setPackageUnitListReturnObject(List<PackageUnit> packageUnitListReturnObject) {
        this.packageUnitListReturnObject = packageUnitListReturnObject;
    }

    /**
     * @return the persistPackageCallStatusReturnObject
     */
    public Integer getPersistPackageCallStatusReturnObject() {
        return persistPackageCallStatusReturnObject;
    }

    /**
     * @param persistPackageCallStatusReturnObject the persistPackageCallStatusReturnObject to set
     */
    public void setPersistPackageCallStatusReturnObject(Integer persistPackageCallStatusReturnObject) {
        this.persistPackageCallStatusReturnObject = persistPackageCallStatusReturnObject;
    }

    /**
     * @return the hfsSplitStatusReturnObject
     */
    public Integer getHfsSplitStatusReturnObject() {
        return hfsSplitStatusReturnObject;
    }

    /**
     * @param hfsSplitStatusReturnObject the hfsSplitStatusReturnObject to set
     */
    public void setHfsSplitStatusReturnObject(Integer hfsSplitStatusReturnObject) {
        this.hfsSplitStatusReturnObject = hfsSplitStatusReturnObject;
    }
}
