package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.env.Environment;

import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * Tests the methods of PersistPacakgeServiceImpl
 *
 * @author J. Greene
 *
 */
@RunWith(PowerMockRunner.class)
public class PersistPackageServiceTest {

    protected static final String X = "x";

    protected static final String I = "i";

    protected static final String N = "n";

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Mock
    private PackageDownloadLogService packageDownloadLogService;

    @Mock
    private DelegateExecution mockExecution;

    @Mock
    private Environment mockEnv;

    @InjectMocks
    private PersistPackageServiceImpl svc = new PersistPackageServiceImpl();

    @Before
    public void init() throws Exception {
        System.out.println("#############################################");
        System.out.println("###                init()                 ###");
        System.out.println("#############################################");

        MockitoAnnotations.initMocks(this);

        Mockito.when(mockEnv.getProperty("mwe.notification.xml.regex")).thenReturn("(?i)x20[1-9][0-9][0-9][0-9].zip");
        Mockito.when(mockEnv.getProperty("mwe.notification.img.regex")).thenReturn("(?i)n20[1-9][0-9][0-9][0-9].zip");
        Mockito.when(mockEnv.getProperty("mwe.notification.pdf.regex")).thenReturn("(?i)i20[1-9][0-9][0-9][0-9].zip");
        Mockito.when(mockEnv.getProperty("mwe.irregularities.xml.regex"))
            .thenReturn("(?i)i[1-9][0-9][0-9][0-9][0-9][0-9].zip");
        Mockito.when(mockEnv.getProperty("mwe.wipo.fees.regex")).thenReturn("(?i)CA-ID-20[0-9][0-9][0-9][0-9].xml");
        Mockito.when(mockEnv.getProperty("mwe.notification.img.file.discriminator")).thenReturn("n");
        Mockito.when(mockEnv.getProperty("mwe.notification.pdf.file.discriminator")).thenReturn("i");
        Mockito.when(mockEnv.getProperty("mwe.notification.xml.file.discriminator")).thenReturn("x");
    }

    @Test(expected = Exception.class)
    public void testGetPackageGroupListDoesNotExist() throws Exception {
        System.out.println("#############################################");
        System.out.println("### testGetPackageGroupListDoesNotExist() ###");
        System.out.println("#############################################");

        Path fakePath = Paths.get(tempFolder.getRoot().toString(), "fakePath");

        svc.getPackageGroupList(fakePath.toString(), IN_NOTIF_PKG);
        Assert.fail("Should not reach this point.");

    }

    @SuppressWarnings("unused")
    @Test
    public void testGetPackageGroupListNoGroup() throws Exception {
        System.out.println("#############################################");
        System.out.println("###     testGetPackageGroupListNoGroup()  ###");
        System.out.println("#############################################");

        File pathToFilePath1 = tempFolder.newFile(X + "201700.zip");
        File pathToFilePath2 = tempFolder.newFile(X + "201701.zip");
        File pathToFilePath3 = tempFolder.newFile(X + "201702.zip");

        Mockito.when(packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(Mockito.anyString(),
            Mockito.any(String[].class))).thenThrow(new NoDownloadHistoryException("Blah"));

        List<PackageUnit> packageUnitList = svc.getPackageGroupList(tempFolder.getRoot().toString(), IN_NOTIF_PKG);

        Assert.assertTrue(packageUnitList.isEmpty());
    }

    @Test
    public void testGetPackageGroupListNoFiles() throws Exception {
        System.out.println("#############################################");
        System.out.println("###     testGetPackageGroupListNoFiles()  ###");
        System.out.println("#############################################");

        List<PackageUnit> packageUnitList = svc.getPackageGroupList(tempFolder.getRoot().toString(), IN_NOTIF_PKG);

        Assert.assertTrue(packageUnitList.isEmpty());
    }

    @SuppressWarnings("unused")
    @Test
    public void testGetPackageGroupListFinancial() throws Exception {
        System.out.println("#############################################");
        System.out.println("###   testGetPackageGroupListFinancial()  ###");
        System.out.println("#############################################");

        File pathToFilePath1 = tempFolder.newFile("CA-ID-201700.xml");
        File pathToFilePath2 = tempFolder.newFile("CA-ID-201701.xml");
        File pathToFilePath3 = tempFolder.newFile("CA-ID-201702.xml");
        // No match
        File pathToFilePath4 = tempFolder.newFile("EM-ID-201702.xml");

        List<PackageUnit> packageUnitList = svc.getPackageGroupList(tempFolder.getRoot().toString(), IN_MADRID_FEES);

        Assert.assertTrue(packageUnitList.size() == 3);
    }

    @SuppressWarnings("unused")
    @Test(expected = IllegalArgumentException.class)
    public void testGetPackageGroupListInvalidType() throws Exception {
        System.out.println("#############################################");
        System.out.println("### testGetPackageGroupListInvalidType()  ###");
        System.out.println("#############################################");

        Path pathToFilePath1 = Files.createFile(Paths.get(tempFolder.getRoot().toString(), "CA-ID-201700.xml"));
        DownloadLogItem item01 = new DownloadLogItem("01", IN_MADRID_FEES, "CA-ID-201700.xml",
            tempFolder.getRoot().toString(), null);

        List<PackageUnit> packageUnitList = svc.getPackageGroupList(tempFolder.getRoot().toString(), OUT_DAILY_PKG);
    }

    @SuppressWarnings("unused")
    @Test
    public void testGetPackageGroupListFoundGroups() throws Exception {
        System.out.println("#############################################");
        System.out.println("###  testGetPackageGroupListFoundGroups() ###");
        System.out.println("#############################################");

        File pathToFilePath01 = tempFolder.newFile(X + "201700.ZIP");
        File pathToFilePath02 = tempFolder.newFile(X + "201701.ZIP");
        File pathToFilePath03 = tempFolder.newFile(X + "201702.ZIP");

        // Only one will be complete.
        PackageUnit pu1 = new PackageUnit();
        pu1.setXmlFileName(X + "201700.ZIP");
        pu1.setImgFileName(N + "201700.ZIP");
        pu1.setPdfFileName(I + "201700.ZIP");

        PackageUnit pu2 = new PackageUnit();
        pu2.setXmlFileName(X + "201700.ZIP");
        pu2.setPdfFileName(I + "201700.ZIP");

        PackageUnit pu3 = new PackageUnit();
        pu3.setXmlFileName(X + "201700.ZIP");
        pu3.setImgFileName(N + "201700.ZIP");

        Mockito.when(packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(Mockito.eq(X + "201700.ZIP"),
            Mockito.any(String[].class))).thenReturn(pu1);
        Mockito.when(packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(Mockito.eq(X + "201701.ZIP"),
            Mockito.any(String[].class))).thenReturn(pu2);
        Mockito.when(packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(Mockito.eq(X + "201702.ZIP"),
            Mockito.any(String[].class))).thenReturn(pu3);

        List<PackageUnit> packageUnitList = svc.getPackageGroupList(tempFolder.getRoot().toString(), IN_NOTIF_PKG);

        System.out.println("packageUnitList.size() == " + packageUnitList.size());

        Assert.assertTrue(packageUnitList.size() == 1);
    }

    @Test
    public void testMovePackageToFailHappy() throws IOException {
        System.out.println("#############################################");
        System.out.println("###      testMovePackageToFailHappy()     ###");
        System.out.println("#############################################");

        Path failDirPath = Paths.get(tempFolder.getRoot().toString(), "fail");

        Path xmlFile = Files.createFile(Paths.get(tempFolder.getRoot().toString(), X + "201700.zip"));
        Path subdirPath = Paths.get(tempFolder.getRoot().toString(), "subdirectory");
        Files.createDirectory(subdirPath);
        Path imgFile = Files.createFile(Paths.get(subdirPath.toString(), I + "201700.ZIP"));
        Path pdfFile = Files.createFile(Paths.get(subdirPath.toString(), N + "201700.ZIP"));

        PackageUnit badPackageUnit = new PackageUnit();
        badPackageUnit.setImgFileName(imgFile.toString());
        badPackageUnit.setXmlFileName(xmlFile.toString());
        badPackageUnit.setPdfFileName(pdfFile.toString());

        Mockito.when(mockExecution.getVariableLocal(PACKAGE_UNIT_ITEM, PackageUnit.class)).thenReturn(badPackageUnit);
        Mockito.when(mockExecution.getVariable("failFolder", String.class)).thenReturn(failDirPath.toString());

        svc.movePackageToFail(mockExecution);

        Assert.assertTrue(Files.notExists(imgFile));
        Assert.assertTrue(Files.notExists(xmlFile));
        Assert.assertTrue(Files.notExists(pdfFile));

        File[] fileList = failDirPath.toFile().listFiles();
        Assert.assertEquals(fileList.length, 3);
    }

    @Test
    public void testMovePackageToFailUnhappy() throws IOException {
        System.out.println("#############################################");
        System.out.println("###     testMovePackageToFailUnhappy()    ###");
        System.out.println("#############################################");

        Path failDirPath = Paths.get(tempFolder.getRoot().toString(), "fail");

        Path xmlFile = Files.createFile(Paths.get(tempFolder.getRoot().toString(), X + "201700.ZIP"));

        PackageUnit badPackageUnit = new PackageUnit();
        badPackageUnit.setXmlFileName("C:\\blah\\blah\\blah\\non\\el\\existo\\H201700.ZIP");

        Mockito.when(mockExecution.getVariableLocal(PACKAGE_UNIT_ITEM, PackageUnit.class)).thenReturn(badPackageUnit);
        Mockito.when(mockExecution.getVariable("failFolder", String.class)).thenReturn(failDirPath.toString());

        svc.movePackageToFail(mockExecution);

        Assert.assertTrue(Files.exists(xmlFile));

        File[] fileList = failDirPath.toFile().listFiles();
        Assert.assertEquals(fileList.length, 0);
    }
}
