package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;

/**
 * A bean object to hold fields specific to creating an email message.
 *
 * @author J. Greene
 *
 */
public class EmailMessageDetails implements Serializable {

    private static final long serialVersionUID = -6204698821861983948L;

    private String subject;

    private String body;

    private String[] toArray;

    private String[] ccArray;

    private String[] bccArray;

    /**
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * @return the body
     */
    public String getBody() {
        return body;
    }

    /**
     * @param body the body to set
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * @return the toArray
     */
    public String[] getToArray() {
        return toArray;
    }

    /**
     * @param toArray the toArray to set
     */
    public void setToArray(String[] toList) {
        this.toArray = toList;
    }

    /**
     * @return the ccArray
     */
    public String[] getCcArray() {
        return ccArray;
    }

    /**
     * @param ccArray the ccArray to set
     */
    public void setCcArray(String[] ccList) {
        this.ccArray = ccList;
    }

    /**
     * @return the bccArray
     */
    public String[] getBccArray() {
        return bccArray;
    }

    /**
     * @param bccArray the bccArray to set
     */
    public void setBccArray(String[] bccList) {
        this.bccArray = bccList;
    }

}
