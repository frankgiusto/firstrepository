package ca.gc.ised.cipo.workflow.conf;

import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.nio.charset.StandardCharsets;

import javax.mail.Session;
import javax.sql.DataSource;

import org.activiti.engine.impl.cfg.IdGenerator;
import org.activiti.engine.impl.persistence.StrongUuidGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.commonj.TimerManagerTaskScheduler;
import org.springframework.scheduling.commonj.WorkManagerTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.WebSphereUowTransactionManager;

import ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.web.servlet.MweWebConfigurer;
import ca.gc.ised.cipo.workflow.model.ActivitiSettings;

/**
 * This is the main configuration class for Activiti in MWE.
 *
 * The @ComponentScan will locate the following:
 *
 * - ca.gc.ised.cipo.workflow.conf.ActivitiEngineConfiguration:
 *
 * This is the common config class for all CIPO Activiti projects. It
 * initializes Activti, starts the ProcessEngine and declares all of the
 * Activiti service classes as beans.
 *
 *
 *
 *
 * @author hamerg
 *
 */
@Configuration
@EnableTransactionManagement
@EnableScheduling
@EnableAsync
@ImportResource("classpath:commonConfigurationContext.xml")
@ComponentScan({ "ca.gc.ised.cipo.workflow.conf", "ca.gc.ised.cipo.tm.madrid.workflow.ws",
		"ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl", "ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr",
		"ca.gc.ised.cipo.tm.madrid.workflow.engine.dao", "ca.gc.ic.cipo.common.config" })
@PropertySources({ @PropertySource(value = { "classpath:mwe.properties" }, ignoreResourceNotFound = false) })
public class MadridEngineConfigurationImpl implements ApplicationSpecificEngineConfiguration {

	private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().getClass());

	// @Value("${log4j.reloadable.properties.path}")
	// private String filePath;

	@Value("${mwe.mts.service.endpoint.hostname}")
	private String mtsHostUrl;

	@Value("${mwe.activiti.event.logging:false}")
	private boolean activitiEventLogging;

	@Value("${mwe.activiti.history.level:audit}")
	private String activitiHistoryLevel;

	@Value("${mwe.activiti.identity.management.used:false}")
	private boolean activitiIdentityMgmtUsed;

	@Value("${application.acronym}")
	private String applicationAcronym;

	@Value("${mwe.jndi.mail.session}")
	private String mweMailSessionName;

	/** {@inheritDoc} */
	@Override
	@Bean
	public PlatformTransactionManager annotationDrivenTransactionManager() {

		/** Allow websphere to manage transactions */
		WebSphereUowTransactionManager transactionManager = new WebSphereUowTransactionManager();
		return transactionManager;
	}

	// @Bean(name = "reloadableProperties")
	// public ReloadableProperties reloadableProperties() {
	//
	// final ReloadingStrategy reloadingStrategy = fileReloadStrategy();
	// ReloadableProperties reloadableProperties = new
	// ReloadableProperties(filePath, reloadingStrategy);
	// return reloadableProperties;
	// }

	// @Bean(name = "fileReloadStrategy")
	// public FileReloadStrategy fileReloadStrategy() {
	//
	// final FileReloadStrategy fileReloadStrategy = new FileReloadStrategy();
	// fileReloadStrategy.setRefreshDelay(1000L);
	// return fileReloadStrategy;
	// }

	/** {@inheritDoc} */
	@Override
	@Bean
	public ActivitiSettings getActivitiSettings() {
		ActivitiSettings hweSettings = new ActivitiSettings();

		hweSettings.setEventLoggingUsed(activitiEventLogging);
		hweSettings.setHistoryLevel(activitiHistoryLevel);
		hweSettings.setIdentityManagementUsed(activitiIdentityMgmtUsed);

		return hweSettings;
	}

	/** {@inheritDoc} */
	@Override
	@Bean
	public Resource[] bpmnDeploymentResources() throws IOException {

		LOG.debug("Configuring bpmnDeploymentResources");
		final PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		return resolver.getResources("classpath*:ca/gc/ised/cipo/tm/madrid/diagram/**/*.bpmn");
	}

	/** {@inheritDoc} */
	@Override
	@Bean
	public DataSource dataSource() {
		LOG.debug("About to configure dataSource");
		final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		DataSource dataSource = dsLookup.getDataSource(MweWebConfigurer.DATA_SOURCE_JNDI_NAME);
		return dataSource;
	}

	/** {@inheritDoc} */
	@Override
	@Bean
	public IdGenerator idGenerator() {

		IdGenerator idGenerator = new StrongUuidGenerator();
		return idGenerator;
	}

	@Override
	public String getAppPrefix() {
		return applicationAcronym;
	}

	@Bean
	@Override
	public TaskScheduler taskScheduler() {

		TimerManagerTaskScheduler scheduler = new TimerManagerTaskScheduler();
		scheduler.setResourceRef(true);
		scheduler.setTimerManagerName(MweWebConfigurer.TIME_MANAGER_JNDI_NAME);

		return scheduler;
	}

	@Bean
	@Override
	public AsyncTaskExecutor taskExecutor() {

		WorkManagerTaskExecutor executor = new WorkManagerTaskExecutor();
		executor.setResourceRef(true);
		executor.setWorkManagerName(MweWebConfigurer.WORK_MANAGER_JNDI_NAME);

		return executor;
	}

	@Bean
	public JndiObjectFactoryBean mailSessionFactoryBean() {
		JndiObjectFactoryBean mailSessionFactoryBean = new JndiObjectFactoryBean();
		mailSessionFactoryBean.setJndiName(mweMailSessionName);
		mailSessionFactoryBean.setResourceRef(true);
		return mailSessionFactoryBean;
	}

	@Bean
	@DependsOn("mailSessionFactoryBean")
	public JndiSimpleMailSender mailSender() {

		Session mailSession = (Session) mailSessionFactoryBean().getObject();

		JndiSimpleMailSender mailSender = new JndiSimpleMailSender();
		mailSender.setDefaultEncoding(StandardCharsets.UTF_8.name());
		mailSender.setSession(mailSession);

		return mailSender;
	}
}
