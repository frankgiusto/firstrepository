package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import javax.xml.ws.BindingProvider;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.report.CipoServiceFault;
import ca.gc.ic.cipo.report.RuntimeJobState;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationServiceFactory;
import ca.gc.ic.cipo.ws.client.rgs.ReportGenerationWsClient;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Manager class to handle the report generation service calls and response as well as any SOAP faults.
 *
 * @author J. Greene
 *
 */
@Service
public class RgsServiceManager extends AbstractServiceManager {

    protected ReportGenerationWsClient rgsClient;

    @Value("${mwe.rgs.service.endpoint.hostname}")
    String rgsHost;

    /**
     * Wraps the web service operation in RGS that polls for the completion of a given report job.
     *
     * @param reportJobId the ID of the report job to check
     * @return The complex object containing the job status
     * @throws BpmnWebServiceCallException
     */
    public RuntimeJobState pollReportService(String reportJobId) throws BpmnWebServiceCallException {
        RuntimeJobState rgsJobState = null;
        try {
            LOG.debug("--> Calling WSO : getJobStatus for reportJobId " + reportJobId);
            rgsJobState = getRgsClient().getJobStatus(reportJobId);
            LOG.debug("-->         WSO : getJobStatus - returned with status " + rgsJobState);
        } catch (CipoServiceFault csf) {
            handleRgsSoapFault(csf);
        } catch (Throwable t) {
            handleWebServiceException(t, ProcessFlowConstants.RGS, "getJobStatus");
        }
        return rgsJobState;
    }

    protected String getRgsHost() {
        if (StringUtils.isBlank(rgsHost)) {
            throw new IllegalArgumentException(
                "Please provide a valid value for property [mwe.rgs.service.endpoint.hostname] in the application configuration");
        }
        return rgsHost;
    }

    protected ReportGenerationWsClient getRgsClient() {
        if (rgsClient == null) {
            rgsClient = new ReportGenerationWsClient(getRgsHost());
        }

        return rgsClient;
    }

    /** {@inheritDoc} */
    @Override
    protected BindingProvider getBindingProvider() {
        BindingProvider bindingProvider = (BindingProvider) ReportGenerationServiceFactory.createClient(getRgsHost());

        return bindingProvider;
    }

    protected void handleRgsSoapFault(CipoServiceFault fault) throws BpmnWebServiceCallException {
        BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(fault.getFaultInfo());

        BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::CipoServiceFault::");
        serviceException.setBusinessErrorLogItem(businessErrorLogItem);
        throw serviceException;
    }
}
