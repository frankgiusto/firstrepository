package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.util.List;

import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * An interface of a service class to front the DAO class for MWE's package download log.
 *
 * @author J. Greene
 *
 */
public interface PackageDownloadLogService {

    /**
     * Creates and persists the {@code DownloadLogItem}.
     *
     * @param downloadLogItem The item to be persisted
     */
    void insertLogEntry(DownloadLogItem downloadLogItem);

    /**
     * Updates the {@code DownloadLogItem}.
     *
     * @param downloadLogItem The item to be updated
     */
    void updateLogEntry(DownloadLogItem downloadLogItem);

    /**
     * Determines whether or not a DTF staged package file was downloaded successfully according to the log based on
     * either the package file's name.
     *
     * @param fileName The name given to the DTF package locally
     * @return true or false
     */
    boolean wasFileDownloadedSuccessfully(String fileName);

    /**
     * Cleanup method to prevent data pile-up.
     *
     * @param olderThanNumberOfDays The number of days beyond which records will be deleted
     */
    void purgeOldLogEntries(int olderThanNumberOfDays);

    /**
     * Fetches a {@code DownloadLogItem} by unique identifier.
     *
     * @param id The ID of the {@code DownloadLogItem} item.
     * @return The item found, or null if not found.
     */
    DownloadLogItem getDownloadLogItemById(Long id);

    /**
     * Gets the previously successful download of the given type.
     *
     * @param type the package type
     * @return the item found, or null if not found.
     */
    DownloadLogItem getPreviouslyDownloadedByType(String type);

    /**
     * Gets a collection of previously downloaded packages that match the given file name using the discriminator
     * prefixes. i.e. if there are 3 files in a grouping named iFILE.txt, jFILE.txt, kFILE.txt and we are looking for
     * groupings matching jFILE.txt then pass discriminators {i,k}.
     *
     * @param fileName the file name of the downloaded package content
     * @param discriminators the array of discriminator prefixes for the remaining items
     * @return a complete package unit
     * @throws NoDownloadHistoryException if the package unit can't be completed because associated downloads do not
     *             exist
     */
    PackageUnit createPackageUnitWithRelatedDownloadItems(String fileName, String[] discriminators)
        throws NoDownloadHistoryException;

    /**
     * Gets a collection of {@code DownloadLogItem}s based on the criteria provided in the object.
     *
     * @param searchReferenceItem the reference object containing search fields
     * @return the items found, or an empty collection if nothing found
     */
    List<DownloadLogItem> getDownloadLogItems(DownloadLogItem searchReferenceItem);

    /**
     * Returns all download log items in the database (use wisely).
     *
     * @return all items currently in the database
     */
    List<DownloadLogItem> getAllDownloadLogItems();
}
