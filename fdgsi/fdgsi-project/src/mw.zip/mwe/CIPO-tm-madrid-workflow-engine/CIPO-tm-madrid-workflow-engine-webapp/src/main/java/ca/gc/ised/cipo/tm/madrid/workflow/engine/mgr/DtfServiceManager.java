package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_IRREG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_MADRID_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.ws.BindingProvider;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.patents.dtf.trs.CreateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.DownloadResponse;
import ca.gc.ic.cipo.patents.dtf.trs.GetTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.SecureTransferRequestServicePortType;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestServicePortType;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestStateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.UnsecureTransferRequestServicePortType;
import ca.gc.ic.cipo.patents.dtf.trs.UpdateTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.factory.TransferRequestServiceFactory;
import ca.gc.ic.cipo.schema.dtf.RacfUser;
import ca.gc.ic.cipo.schema.dtf.ServiceResponse;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.IrregularitiesTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.MonthlyFinanceTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.NotificationImgTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.NotificationPdfTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.NotificationXmlTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.WipoInboundTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Manager class to help with handling DTF web service calls/response.
 *
 * @author J. Greene
 *
 */
@Service
public class DtfServiceManager extends AbstractServiceManager {

    protected static final Logger LOG = LoggerFactory.getLogger(DtfServiceManager.class);

    protected TransferRequestServicePortType trServiceClient;

    private RacfUser mweRacfUser;

    @Autowired
    private Environment env;

    @Value("${mwe.dtf.service.username}")
    private String dtfUser;

    // Except in the DEV region password should be NULL
    @Value("${mwe.dtf.service.password:#{null}}")
    private String dtfPwd;

    @Value("${mwe.dtf.service.endpoint.hostname}")
    private String dtfHost;

    /**
     * Wraps the call and response handling of the 'create transfer request' DTF service operation.
     *
     * @param transferRequestInput The WSDL specified operation input parameter
     * @return The WSDL specified operation output parameter
     * @see TransferRequestServicePortType#createTransferRequest(ca.gc.ic.cipo.schema.RacfUser,
     *      ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestXsd, javax.activation.DataHandler)
     * @throws BpmnWebServiceCallException if there is an issue with the web service call
     */
    public CreateResponse createTransferRequest(CreateTransferRequest transferRequestInput)
        throws BpmnWebServiceCallException {
        DataHandler zipStream = null;

        if (transferRequestInput == null) {
            throw new IllegalArgumentException("Parameter [transferRequestInput] must not be null");
        }
        CreateResponse response = null;
        try {
            transferRequestInput.setRacfUser(getRacfUser());
            if (transferRequestInput.getZipStream() != null) {
                zipStream = transferRequestInput.getZipStream();
            }
            LOG.debug("--> Calling WSO : createTransferRequest");
            response = getTrServiceClient().createTransferRequest(transferRequestInput.getRacfUser(),
                transferRequestInput.getTransferRequest(), zipStream);
            LOG.debug("-->         WSO : createTransferRequest - returned with ID "
                + (response.getTransferRequest() == null ? "null" : response.getTransferRequest().getRequestId()));
        } catch (Throwable t) {
            handleWebServiceException(t, ProcessFlowConstants.DTF, "createTransferRequest");
        } finally {
            // remove temp upload archive file if exists
            if (zipStream != null) {
                FileDataSource fds = (FileDataSource) zipStream.getDataSource();
                fds.getFile().delete();
            }
        }
        if (response != null) {
            handleDtfServiceResposneErrorCondition(response);
        }

        return response;
    }

    /**
     * Wraps the call and response handling of the 'get transfer request state' DTF service operation.
     *
     * @param trStateInput The WSDL specified operation input parameter
     * @return The WSDL specified operation output parameter
     * @see TransferRequestServicePortType#getTransferRequestState(ca.gc.ic.cipo.schema.RacfUser,
     *      ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd)
     * @throws BpmnWebServiceCallException if there is an issue with the web service call
     */
    public TransferRequestStateResponse getTransferRequestState(GetTransferRequestState trStateInput)
        throws BpmnWebServiceCallException {
        if (trStateInput == null) {
            throw new IllegalArgumentException("Parameter [trStateInput] must not be null");
        }
        TransferRequestStateResponse response = null;
        try {
            trStateInput.setRacfUser(getRacfUser());

            LOG.debug("--> Calling WSO : getTransferRequestState - with transfer request ID "
                + trStateInput.getTransferRequestState().getRequestId());
            response = getTrServiceClient().getTransferRequestState(trStateInput.getRacfUser(),
                trStateInput.getTransferRequestState());
            LOG.debug("-->         WSO : getTransferRequestState - returned with state "
                + response.getTxRequestState().getStateCode());
        } catch (Throwable t) {
            handleWebServiceException(t, ProcessFlowConstants.DTF, "getTransferRequestState");
        }
        if (response != null) {
            handleDtfServiceResposneErrorCondition(response);
        }

        return response;
    }

    /**
     * Wraps the call and response handling of the 'update transfer request state' DTF service operation.
     *
     * @param trStateInput The WSDL specified operation input parameter
     * @return The WSDL specified operation output parameter
     * @see TransferRequestServicePortType#updateTransferRequestState(ca.gc.ic.cipo.schema.RacfUser,
     *      ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd)
     * @throws BpmnWebServiceCallException if there is an issue with the web service call
     */
    public TransferRequestStateResponse setTransferRequestState(UpdateTransferRequestState trStateUpdateInput)
        throws BpmnWebServiceCallException {
        if (trStateUpdateInput == null) {
            throw new IllegalArgumentException("Parameter [trStateUpdateInput] must not be null");
        }
        TransferRequestStateResponse response = null;
        try {
            trStateUpdateInput.setRacfUser(getRacfUser());

            LOG.debug("--> Calling WSO : updateTransferRequestState");
            response = getTrServiceClient().updateTransferRequestState(trStateUpdateInput.getRacfUser(),
                trStateUpdateInput.getTransferRequestState());
        } catch (Throwable t) {
            handleWebServiceException(t, ProcessFlowConstants.DTF, "updateTransferRequestState");
        }
        if (response != null) {
            handleDtfServiceResposneErrorCondition(response);
        }

        return response;
    }

    /**
     * Wraps the call and response handling of the 'download staged files' DTF service operation.
     *
     * @param requestId The transfer request ID
     * @return The WSDL specified operation output parameter
     * @throws BpmnWebServiceCallException
     * @see TransferRequestServicePortType#downloadStagedFiles(RacfUser, int)
     */
    public DownloadResponse downloadStagedFiles(Integer requestId) throws BpmnWebServiceCallException {
        DownloadResponse response = null;
        if (requestId == null) {
            throw new IllegalArgumentException("Parameter [requestId] must not be null");
        }
        LOG.debug("--> Calling WSO : downloadStagedFiles - with transfer request ID " + requestId);
        response = getTrServiceClient().downloadStagedFiles(getRacfUser(), requestId);
        if (response != null) {
            handleDtfServiceResposneErrorCondition(response);
        }
        return response;
    }

    /**
     * Identifies and creates the appropriate strategy to build a transfer request based on the transfer item
     *
     * @param transferItem The transfer item being downloaded.
     */
    public WipoInboundTransferRequestCreator getInboundTransferRequestCreateStrategy(String transferItem) {
        WipoInboundTransferRequestCreator strategy = null;

        if (transferItem.equals(IN_NOTIF_PKG)) {
            strategy = new NotificationXmlTransferRequestCreator();
        } else if (transferItem.equals(IN_NOTIF_IMG_PKG)) {
            strategy = new NotificationImgTransferRequestCreator();
        } else if (transferItem.equals(IN_NOTIF_PDF_PKG)) {
            strategy = new NotificationPdfTransferRequestCreator();
        } else if (transferItem.equals(IN_IRREG_PKG)) {
            strategy = new IrregularitiesTransferRequestCreator();
        } else if (transferItem.equals(IN_MADRID_FEES)) {
            strategy = new MonthlyFinanceTransferRequestCreator();
        } else {
            throw new IllegalArgumentException(
                "Unknown transfer item cannot be mapped to an execution strategy:  " + transferItem);
        }
        strategy.setEnvironmnent(env);

        return strategy;
    }

    /**
     * Creates a {@code BusinessErrorLogItem} from the DTF specific service response object.
     *
     * @param response The DTF response object
     * @return a new {@code BusinessErrorLogItem}
     */
    public BusinessErrorLogItem createBusinessErrorLogItem(ServiceResponse response) {
        BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem();
        businessErrorLogItem.setErrorMessageEn(response.getEnErrorMsg());
        businessErrorLogItem.setErrorMessageFr(response.getFrErrorMsg());
        businessErrorLogItem.setComponentAcronym(response.getComponentAcronym());
        businessErrorLogItem.setReasonCode(new Long(response.getReasonCode()));
        businessErrorLogItem.setReturnCode(new Long(response.getReturnCode()));

        return businessErrorLogItem;
    }

    protected void handleDtfServiceResposneErrorCondition(ServiceResponse response) throws BpmnWebServiceCallException {

        if (response.getReturnCode() < 0) {
            BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem();
            businessErrorLogItem.setCipoServiceFaultOrigin(true);

            businessErrorLogItem.setComponentAcronym(response.getComponentAcronym());
            businessErrorLogItem.setServiceName(response.getServiceName());
            businessErrorLogItem.setReturnCode(new Long(response.getReturnCode()));
            businessErrorLogItem.setReasonCode(new Long(response.getReasonCode()));
            businessErrorLogItem.setErrorMessageEn(response.getEnErrorMsg());
            businessErrorLogItem.setErrorMessageFr(response.getFrErrorMsg());

            BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::CipoServiceFault::");
            serviceException.setBusinessErrorLogItem(businessErrorLogItem);
            throw serviceException;
        }
    }

    protected RacfUser getRacfUser() {
        if (mweRacfUser == null) {
            mweRacfUser = new RacfUser();
            mweRacfUser.setUserId(dtfUser);
            mweRacfUser.setPassword(dtfPwd);
        }
        return mweRacfUser;
    }

    protected String getDtfHost() {
        if (StringUtils.isBlank(dtfHost)) {
            throw new IllegalArgumentException(
                "Please provide a valid value for property [mwe.dtf.service.endpoint.hostname] in the application configuration");
        }
        return dtfHost;
    }

    protected TransferRequestServicePortType getTrServiceClient() {
        if (trServiceClient == null) {
            trServiceClient = TransferRequestServiceFactory.createClient(getDtfHost());
        }
        return trServiceClient;
    }

    /** {@inheritDoc} */
    @Override
    protected BindingProvider getBindingProvider() {
        SecureTransferRequestServicePortType securePortType = getTrServiceClient().getSecuredPort();
        UnsecureTransferRequestServicePortType unsecurePortType = getTrServiceClient().getUnsecuredPort();

        BindingProvider b;
        if (securePortType == null) {
            b = (BindingProvider) unsecurePortType;
        } else {
            b = (BindingProvider) securePortType;
        }
        return b;
    }

    public Environment getEnvironment() {
        return env;
    }

}
