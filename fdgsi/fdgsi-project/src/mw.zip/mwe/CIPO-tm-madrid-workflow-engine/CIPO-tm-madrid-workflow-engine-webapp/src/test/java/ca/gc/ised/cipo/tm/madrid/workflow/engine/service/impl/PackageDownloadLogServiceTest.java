package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_IRREG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_MADRID_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.PackageDownloadLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * Tests (lightly) the various CRUD functions in the package download logg service.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:package_log_before.sql"),
    @Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:package_log_after.sql")})
public class PackageDownloadLogServiceTest {

    @Autowired
    PackageDownloadLogDao dao;

    PackageDownloadLogService packageDownloadLogService;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    Environment env = Mockito.mock(Environment.class);

    @Before
    public void init() {
        // Uncomment below to test against the following oracle instance.
        // Otherwise it will use an in-memory db.
        // SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
        // // dataSource.setDriverClass(oracle.jdbc.driver.OracleDriver.class);
        // dataSource.setUrl("jdbc:oracle:thin:@p7217:1521:INDDEV0");
        // dataSource.setUsername("INTL_ID_WORKFLOW_USER");
        // dataSource.setPassword("INTL_ID_WORKFLOW_USER");
        //
        // dao.setDataSource(dataSource);
        Mockito.when(env.getProperty("mwe.notification.xml.file.discriminator")).thenReturn("x");
        Mockito.when(env.getProperty("mwe.notification.img.file.discriminator")).thenReturn("n");
        Mockito.when(env.getProperty("mwe.notification.pdf.file.discriminator")).thenReturn("z");

        packageDownloadLogService = new PackageDownloadLogServiceImpl(dao, env);
    }

    // @Test
    public void testInsert() {
        System.out.println("#############################################");
        System.out.println("###                testInsert             ###");
        System.out.println("#############################################");
        DownloadLogItem newItem = new DownloadLogItem();

        newItem.setDlDate(new Date());
        newItem.setDlStatus(DownloadLogItem.Status.INPROGRESS.getValue());
        newItem.setPackageType(IN_NOTIF_PKG);
        newItem.setFileName("Hague9999.xml");
        newItem.setTargetLocation("/c/blah/blah/blah");
        newItem.setXferReqId("INSERTTEST_123");

        packageDownloadLogService.insertLogEntry(newItem);

        assertNotNull(newItem.getDlLogId());

        // Bare minimum constructor
        DownloadLogItem stubItem = new DownloadLogItem("9999888777", IN_NOTIF_PKG, "Hague0000.xml", "/c/blah/blah/blah",
            null);
        packageDownloadLogService.insertLogEntry(stubItem);

        assertEquals(stubItem.getDlStatus(), DownloadLogItem.Status.INPROGRESS.getValue());
    }

    // @Test
    public void testUpdate() {
        System.out.println("#############################################");
        System.out.println("###              testUpdate               ###");
        System.out.println("#############################################");
        String stagedPkgName = "Staged_File_UPDATETEST_123.zip";
        String updtMsg = "BLAH";
        DownloadLogItem updatingItem = new DownloadLogItem("UPDATETEST_123", IN_NOTIF_PKG, "Hague1234.xml",
            "/c/blah/blah/blah", null);
        packageDownloadLogService.insertLogEntry(updatingItem);

        assertNull(updatingItem.getFileRegex());
        assertNull(updatingItem.getDlDate());
        assertEquals(DownloadLogItem.Status.INPROGRESS.getValue(), updatingItem.getDlStatus());

        updatingItem.setFileRegex(stagedPkgName);
        updatingItem.setDlDate(new Date());
        updatingItem.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        updatingItem.setMsg(updtMsg);
        packageDownloadLogService.updateLogEntry(updatingItem);

        DownloadLogItem persistedItem = packageDownloadLogService.getDownloadLogItemById(updatingItem.getDlLogId());
        assertNotNull(persistedItem);
        assertNotNull(persistedItem.getDlDate());
        assertEquals(stagedPkgName, persistedItem.getFileRegex());
        assertEquals(updtMsg, persistedItem.getMsg());
        assertEquals(DownloadLogItem.Status.SUCCESS.getValue(), persistedItem.getDlStatus());
    }

    // @Test
    public void testCheckForExistingSuccess() throws Exception {
        System.out.println("#############################################");
        System.out.println("###      testCheckForExistingSuccess      ###");
        System.out.println("#############################################");
        DownloadLogItem successItem = new DownloadLogItem();
        successItem.setDlDate(new Date());
        successItem.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        successItem.setPackageType(IN_NOTIF_PKG);
        successItem.setFileName("Hague91011.xml");
        successItem.setTargetLocation("/c/blah/blah/blah");
        successItem.setXferReqId("CHECKFORSUCCESSTEST_123");
        successItem.setFileRegex("(?i)Hague91011.xml");
        packageDownloadLogService.insertLogEntry(successItem);

        assertTrue(packageDownloadLogService.wasFileDownloadedSuccessfully(successItem.getFileName()));

        DownloadLogItem failedItem = new DownloadLogItem();
        failedItem.setDlDate(new Date());
        failedItem.setDlStatus(DownloadLogItem.Status.FAIL.getValue());
        failedItem.setPackageType(IN_NOTIF_PKG);
        failedItem.setFileName("Hague121314.xml");
        failedItem.setTargetLocation("/c/blah/blah/blah");
        failedItem.setXferReqId("CHECKFORFAILTEST_123");
        failedItem.setFileRegex("(?i)Hague121314.xml");
        packageDownloadLogService.insertLogEntry(failedItem);

        assertFalse(packageDownloadLogService.wasFileDownloadedSuccessfully(failedItem.getFileName()));
    }

    // @Test
    public void testPurgeOldRecords() {
        System.out.println("#############################################");
        System.out.println("###           testPurgeOldRecords         ###");
        System.out.println("#############################################");

        /*
         * TODO: Test randomly fails. Not sure why. I blame sunspots.
         */

        int i = 10;
        Date date = new Date();
        List<DownloadLogItem> itemList = new ArrayList<>();
        for (int j = 0; j < i; j++) {
            Date newDate = DateUtils.addDays(date, -(1 + j));
            DownloadLogItem iteratedItem = new DownloadLogItem();
            iteratedItem.setDlDate(newDate);
            iteratedItem.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
            iteratedItem.setPackageType(IN_NOTIF_PKG);
            iteratedItem.setFileName("Hague0000" + j + ".xml");
            iteratedItem.setTargetLocation("/c/blah/blah/blah");
            iteratedItem.setXferReqId("CHECKFORSUCCESSTEST_" + j + ".xml");
            iteratedItem.setFileRegex("Staged_file_CHECKFORSUCCESSTEST_" + j + ".zip");
            packageDownloadLogService.insertLogEntry(iteratedItem);
            itemList.add(iteratedItem);
            System.out
                .println("Created Log ID [" + iteratedItem.getDlLogId() + "] and DL Date " + iteratedItem.getDlDate());
        }

        packageDownloadLogService.purgeOldLogEntries(5);

        int numFailures = 0;
        for (DownloadLogItem item : itemList) {
            DownloadLogItem foundItem = packageDownloadLogService.getDownloadLogItemById(item.getDlLogId());
            if (foundItem == null) {
                numFailures++;
            } else {
                System.out.println("Download Log ID [" + item.getDlLogId() + "] and DL Date " + item.getDlDate()
                    + " survived the cull");
            }
        }
        assertEquals(5, numFailures);
    }

    @SuppressWarnings("unused")
    // @Test
    public void testQuery() {
        System.out.println("#############################################");
        System.out.println("###               testQuery               ###");
        System.out.println("#############################################");

        DownloadLogItem searchableItem = new DownloadLogItem();
        searchableItem.setDlLogId(100L);
        searchableItem.setXferReqId("0000");
        searchableItem.setPackageType(IN_IRREG_PKG);
        searchableItem.setFileName("H190001.ZIP");
        searchableItem.setTargetLocation("/c/blah/blah/blah");
        searchableItem.setFileRegex("(?i)H190001.zip");
        searchableItem.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        searchableItem.setDlDate(new Date());
        packageDownloadLogService.insertLogEntry(searchableItem);

        DownloadLogItem queryItem1 = new DownloadLogItem();
        DownloadLogItem queryItem2 = new DownloadLogItem();
        DownloadLogItem queryItem3 = new DownloadLogItem();
        DownloadLogItem queryItem4 = new DownloadLogItem();
        DownloadLogItem queryItem5 = new DownloadLogItem();
        DownloadLogItem queryItem6 = new DownloadLogItem();
        DownloadLogItem queryItem7 = new DownloadLogItem();
        DownloadLogItem queryItem8 = new DownloadLogItem();

        queryItem1.setDlLogId(searchableItem.getDlLogId());
        List<DownloadLogItem> foundItem1 = dao.getDownloadLogItemsByFields(queryItem1);
        assertFalse(foundItem1.isEmpty());

        queryItem2.setXferReqId(searchableItem.getXferReqId());
        List<DownloadLogItem> foundItem2 = dao.getDownloadLogItemsByFields(queryItem2);
        assertFalse(foundItem2.isEmpty());

        queryItem3.setFileName(searchableItem.getFileName());
        List<DownloadLogItem> foundItem3 = dao.getDownloadLogItemsByFields(queryItem3);
        assertFalse(foundItem3.isEmpty());

        queryItem4.setTargetLocation(searchableItem.getTargetLocation());
        List<DownloadLogItem> foundItem4 = dao.getDownloadLogItemsByFields(queryItem4);
        assertFalse(foundItem4.isEmpty());

        queryItem5.setFileRegex(searchableItem.getFileRegex());
        List<DownloadLogItem> foundItem5 = dao.getDownloadLogItemsByFields(queryItem5);
        assertFalse(foundItem5.isEmpty());

        queryItem6.setDlStatus(searchableItem.getDlStatus());
        List<DownloadLogItem> foundItem6 = dao.getDownloadLogItemsByFields(queryItem6);
        assertFalse(foundItem6.isEmpty());

        queryItem7.setDlDate(searchableItem.getDlDate());
        try {
            List<DownloadLogItem> foundItem7 = dao.getDownloadLogItemsByFields(queryItem7);
            fail("Should not reach this point");
        } catch (IllegalArgumentException iex) {
            //
        }

        queryItem8.setPackageType(searchableItem.getPackageType());
        List<DownloadLogItem> foundItem8 = dao.getDownloadLogItemsByFields(queryItem8);
        assertFalse(foundItem8.isEmpty());

    }

    @Test
    public void testGetPreviouslyDownloadedByType() {
        System.out.println("#############################################");
        System.out.println("###   testGetPreviouslyDownloadedByType   ###");
        System.out.println("#############################################");

        Date today = new Date();

        DownloadLogItem item1 = new DownloadLogItem("1", IN_MADRID_FEES, "x200001.xxx", "/", null);
        item1.setDlDate(DateUtils.addDays(today, -4));
        item1.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item1);

        DownloadLogItem item2 = new DownloadLogItem("2", IN_MADRID_FEES, "x200000.xxx", "/", null);
        item2.setDlDate(DateUtils.addDays(today, -5));
        item2.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item2);

        DownloadLogItem item3 = new DownloadLogItem("3", IN_MADRID_FEES, "x200003.xxx", "/", null);
        item3.setDlDate(DateUtils.addDays(today, -1));
        item3.setDlStatus(DownloadLogItem.Status.FAIL.getValue());
        packageDownloadLogService.insertLogEntry(item3);

        DownloadLogItem item4 = new DownloadLogItem("4", IN_NOTIF_PKG, "x200001.xxx", "/", null);
        item4.setDlDate(today);
        item4.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item4);

        DownloadLogItem item5 = new DownloadLogItem("5", IN_MADRID_FEES, "x200003.xxx", "/", null);
        item5.setDlDate(DateUtils.addDays(today, -2));
        item5.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item5);

        DownloadLogItem mostRecentFile = packageDownloadLogService.getPreviouslyDownloadedByType(IN_MADRID_FEES);

        assertTrue(mostRecentFile.getDlLogId().equals(5L));

    }

    @Test
    public void testCreatePackageUnitHappyPath() throws Exception {
        System.out.println("##################################################");
        System.out.println("###       testCreatePackageUnitHappyPath        ##");
        System.out.println("##################################################");

        File xmlFile = tempFolder.newFile("x000000.zip");
        File imgFile = tempFolder.newFile("n000000.zip");
        File pdfFile = tempFolder.newFile("z000000.zip");
        String[] groupTransferTypes = new String[]{IN_NOTIF_PKG, IN_NOTIF_IMG_PKG, IN_NOTIF_PDF_PKG};

        Date today = new Date();

        DownloadLogItem item1 = new DownloadLogItem("1", IN_NOTIF_PKG, xmlFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item1.setDlDate(DateUtils.addDays(today, -4));
        item1.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item1);

        DownloadLogItem item2 = new DownloadLogItem("2", IN_NOTIF_IMG_PKG, imgFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item2.setDlDate(DateUtils.addDays(today, -5));
        item2.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item2);

        DownloadLogItem item3 = new DownloadLogItem("3", IN_NOTIF_PDF_PKG, pdfFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item3.setDlDate(DateUtils.addDays(today, -5));
        item3.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item3);

        PackageUnit unit = packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(xmlFile.getName(),
            groupTransferTypes);

        assertNotNull(unit.getXmlFileName());
    }

    @SuppressWarnings("unused")
    @Test(expected = NoDownloadHistoryException.class)
    public void testCreatePackageUnitNoDownloadHistory() throws Exception {
        System.out.println("##################################################");
        System.out.println("###    testCreatePackageUnitNoDownloadHistory   ##");
        System.out.println("##################################################");

        File xmlFile = tempFolder.newFile("x000000.zip");
        File imgFile = tempFolder.newFile("n000000.zip");
        File pdfFile = tempFolder.newFile("z000000.zip");
        String[] groupTransferTypes = new String[]{IN_NOTIF_PKG, IN_NOTIF_IMG_PKG, IN_NOTIF_PDF_PKG};

        Date today = new Date();

        DownloadLogItem item1 = new DownloadLogItem("1", IN_NOTIF_PKG, xmlFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item1.setDlDate(DateUtils.addDays(today, -4));
        item1.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item1);

        DownloadLogItem item2 = new DownloadLogItem("2", IN_NOTIF_IMG_PKG, imgFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item2.setDlDate(DateUtils.addDays(today, -5));
        item2.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item2);

        // No PDF file download log item

        PackageUnit unit = packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(xmlFile.getName(),
            groupTransferTypes);

        assertNotNull(unit.getXmlFileName());
    }

    @Test(expected = NoDownloadHistoryException.class)
    public void testCreatePackageUnitNoFileExists() throws Exception {
        System.out.println("##################################################");
        System.out.println("###      testCreatePackageUnitNoFileExists      ##");
        System.out.println("##################################################");

        File xmlFile = tempFolder.newFile("x000000.zip");
        File pdfFile = tempFolder.newFile("z000000.zip");
        String[] groupTransferTypes = new String[]{IN_NOTIF_PKG, IN_NOTIF_IMG_PKG, IN_NOTIF_PDF_PKG};

        Date today = new Date();

        DownloadLogItem item1 = new DownloadLogItem("1", IN_NOTIF_PKG, xmlFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item1.setDlDate(DateUtils.addDays(today, -4));
        item1.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item1);

        // Download log item, but no file (scenario: File may have been deleted)
        DownloadLogItem item2 = new DownloadLogItem("2", IN_NOTIF_IMG_PKG, "n000000.zip",
            tempFolder.getRoot().getPath(), null);
        item2.setDlDate(DateUtils.addDays(today, -5));
        item2.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item2);

        DownloadLogItem item3 = new DownloadLogItem("3", IN_NOTIF_PDF_PKG, pdfFile.getName(),
            tempFolder.getRoot().getPath(), null);
        item3.setDlDate(DateUtils.addDays(today, -5));
        item3.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        packageDownloadLogService.insertLogEntry(item3);

        PackageUnit unit = packageDownloadLogService.createPackageUnitWithRelatedDownloadItems(xmlFile.getName(),
            groupTransferTypes);

        assertNotNull(unit.getXmlFileName());
    }

    @Test
    public void testGetPreviouslyDownloadedNone() {
        System.out.println("#############################################");
        System.out.println("###    testGetPreviouslyDownloadedNone    ###");
        System.out.println("#############################################");

        DownloadLogItem mostRecentFees = packageDownloadLogService.getPreviouslyDownloadedByType(IN_MADRID_FEES);

        assertNull(mostRecentFees);
    }

}
