package ca.gc.ised.cipo.tm.madrid.diagram;

/**
 * A test class for the
 * {@code process_madrid_financial_transactions_from_wipo.bpmn} workflow.
 *
 * @author J. Greene
 *
 */
// @RunWith(SpringJUnit4ClassRunner.class)
// @ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class ProcessMadridFinancialTransactionsFromWipoTest {

	// MFS-CLEAN-SPR5 @Autowired
	// protected ManagementService managementService;
	//
	// @Autowired
	// protected ProcessEngine processEngine;
	//
	// @Autowired
	// protected RuntimeService runtimeService;
	//
	// @Autowired
	// protected TaskService taskService;
	//
	// @Autowired
	// protected HistoryService historyService;
	//
	// @Autowired
	// @Rule
	// public ActivitiRule activitiRule;
	//
	// @Autowired
	// protected TestFinancialTransactionReconcileServiceImpl
	// testFinancialTransactionReconcileServiceImpl;
	//
	// @Autowired
	// protected TestFinancialTransactionGapReportGenerationServiceImpl
	// testFinancialTransactionGapReportGenerationServiceImpl;
	//
	// @Autowired
	// protected TestReportGenerationServiceImpl
	// testReportGenerationServiceImpl;
	//
	// @Autowired
	// protected TestFinancialTransactionSubmitServiceImpl
	// testFinancialTransactionSubmitServiceImpl;
	//
	// @Autowired
	// protected TestFinancialTransactionInternalDownloadServiceImpl
	// testFinancialTransactionInternalDownloadServiceImpl;
	//
	// @Autowired
	// protected TestFinancialTransactionUpdateFeeStatusServiceImpl
	// testFinancialTransactionUpdateFeeStatusServiceImpl;
	//
	// @Autowired
	// protected TestPersistPackageServiceImpl testPersistPackageServiceImpl;
	//
	// @Before
	// public void init() {
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(null);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(null);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(null);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(null);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(null);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(null);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(null);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(null);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(null);
	// testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(null);
	// testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(null);
	//
	// testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(null);
	// testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(null);
	// testFinancialTransactionInternalDownloadServiceImpl.setVerifyFinPackageDownloadTransferStatusReturnObject(null);
	//
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setFetchFinSystemPackageTransactionsStatusReturnObject(null);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(null);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(null);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(null);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(null);
	//
	// testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(null);
	// testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(null);
	// testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(null);
	// testPersistPackageServiceImpl.setPackageUnitListReturnObject(null);
	// testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(null);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
	// public void happyPathTest() {
	// System.out.println("#############################################");
	// System.out.println("### happyPathTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl
	// .setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionUpdateFeeStatusServiceImpl
	// .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(COMPLETE);
	//
	// testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
	// testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
	// testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(COMPLETE);
	//
	// List<PackageUnit> testPackages = createDummyPackageUnitList(1);
	// testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);
	//
	// testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "packageStatusSetReconciledTask", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "packageStatusSetFeeUpdatedTask", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "processMadridFinancialTransactionsFromWipoEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn"})
	// public void fetchFinancialTransactionsErrorTest() {
	// System.out.println("#############################################");
	// System.out.println("### fetchFinancialTransactionsErrorTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(ERROR);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "businessErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn"})
	// public void recoverableReconcileErrorTest() {
	// System.out.println("#############################################");
	// System.out.println("### recoverableReconcileErrorTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(ERROR);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// List<TransactionDetail> transactionIdList = new ArrayList<>();
	// TransactionDetail td1 = new TransactionDetail();
	// td1.setTransactionId(new BigDecimal(10001));
	// transactionIdList.add(td1);
	// TransactionDetail td2 = new TransactionDetail();
	// td2.setTransactionId(new BigDecimal(10002));
	// transactionIdList.add(td2);
	// Map<String, Object> processVariables = getParameterMap();
	// processVariables.put(TRANSACTION_DETAIL_LIST, transactionIdList);
	//
	// // short-circuit here to prevent wiring in all the other subflows
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(ERROR);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, processVariables);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "packageStatusSetReconciledTask", 0);
	// TestUtils.assertActivitiEventFired(historyService, "reconcileTxEndEvent",
	// transactionIdList.size());
	// TestUtils.assertActivitiEventFired(historyService,
	// "reconcileTxUnrecoverableErrorEndEvent", 0);
	// // Make sure listener is firing.
	// List<HistoricVariableInstance> histList =
	// historyService.createHistoricVariableInstanceQuery()
	// .variableName(RUNNING_ERROR_MESSAGE).list();
	// Assert.assertTrue(histList != null && !histList.isEmpty());
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn"})
	// public void notRecoverableReconcileErrorTest() {
	// System.out.println("#############################################");
	// System.out.println("### notRecoverableReconcileErrorTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(ERROR);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(ERROR);
	//
	// List<TransactionDetail> transactionIdList = new ArrayList<>();
	// TransactionDetail td1 = new TransactionDetail();
	// td1.setTransactionId(new BigDecimal(10001));
	// transactionIdList.add(td1);
	// TransactionDetail td2 = new TransactionDetail();
	// td2.setTransactionId(new BigDecimal(10002));
	// transactionIdList.add(td2);
	// Map<String, Object> processVariables = getParameterMap();
	// processVariables.put(TRANSACTION_DETAIL_LIST, transactionIdList);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, processVariables);
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "reconcileTxUnrecoverableErrorEndEvent", 1);
	// TestUtils.assertActivitiEventFired(historyService,
	// "businessErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn"})
	// public void generateReconciledXmlErrorTest() {
	// System.out.println("#############################################");
	// System.out.println("### generateReconciledXmlErrorTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(ERROR);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(COMPLETE);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "businessErrorEndEvent", 1);
	// }
	//
	// /******************************************************************************************************************
	// * TERMINATION TESTS
	// ******************************************************************************************************************/
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn"})
	// public void generateGapReportTerminationTest() {
	// System.out.println("#############################################");
	// System.out.println("### generateGapReportTerminationTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl.setGapReportEmailNotificationStatusReturnObject(ERROR);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "genGapReportsErrorEndEvent", 1);
	// }
	//
	// // TODO Retry when reportTypeList is fixed @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn"})
	// public void generateGapReportIterativeError() {
	// System.out.println("#############################################");
	// System.out.println("### generateGapReportIterativeError ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(ERROR);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	// testReportGenerationServiceImpl.setRecoverableErrorStatus(ERROR);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "genGapReportsErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
	// public void sendFeesTerminationTest() {
	// System.out.println("#############################################");
	// System.out.println("### sendFeesTerminationTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(ERROR);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "sendReconciledFeesToFinSystemErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
	// public void downloadFinPackageTerminationTest() {
	// System.out.println("#############################################");
	// System.out.println("### downloadFinPackageTerminationTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(ERROR);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "downloadIfmsFeedbackErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
	// public void persistFinPkgTerminationTest() {
	// System.out.println("#############################################");
	// System.out.println("### persistFinPkgTerminationTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl
	// .setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionUpdateFeeStatusServiceImpl
	// .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(COMPLETE);
	//
	// testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(ERROR);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "persistFinancialSystemPackageErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
	// public void applyFeeStatusTerminateTest() {
	// System.out.println("#############################################");
	// System.out.println("### applyFeeStatusTerminateTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl
	// .setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionUpdateFeeStatusServiceImpl
	// .setFetchFinSystemPackageTransactionsStatusReturnObject(ERROR);
	//
	// testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
	// testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
	// testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(COMPLETE);
	//
	// List<PackageUnit> testPackages = createDummyPackageUnitList(1);
	// testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);
	//
	// testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "applyFeeStatusUpdateErrorEndEvent", 1);
	// }
	//
	// @Test
	// @Deployment(resources = {
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/download_financial_system_status_package.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn",
	// "ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
	// public void applyFeeStatusRecoverableErrTest() {
	// System.out.println("#############################################");
	// System.out.println("### applyFeeStatusRecoverableErrTest ###");
	// System.out.println("#############################################");
	//
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setFinancialTransactionReconcileStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setGenerateReconciledXmlStatusReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setRecoverableErrorConditionReturnObject(COMPLETE);
	// testFinancialTransactionReconcileServiceImpl.setReconciledSetStatusReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionGapReportGenerationServiceImpl
	// .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
	//
	// testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
	// testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
	//
	// testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
	// testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionInternalDownloadServiceImpl.setFinPkgDownloadRequestStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl.setPackageMoveToStagingStatusReturnObject(COMPLETE);
	// testFinancialTransactionInternalDownloadServiceImpl
	// .setVerifyFinPackageDownloadTransferStatusReturnObject(COMPLETE);
	//
	// testFinancialTransactionUpdateFeeStatusServiceImpl
	// .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(ERROR);
	// testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
	//
	// testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
	// testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
	// testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(COMPLETE);
	//
	// List<PackageUnit> testPackages = createDummyPackageUnitList(1);
	// testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);
	//
	// testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
	//
	// ProcessInstance testInstance =
	// TestUtils.startProcessInstance(PROCESS_INCOMING_FINANCIAL_TRANSACTIONS,
	// runtimeService, getParameterMap());
	//
	// JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L,
	// 1000L);
	//
	// TestUtils.assertCompletion(historyService, testInstance);
	//
	// TestUtils.assertActivitiEventFired(historyService,
	// "applyFeeStatusUpdateErrorEndEvent", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "packageStatusSetFeeUpdatedTask", 0);
	// TestUtils.assertActivitiEventFired(historyService,
	// "processMadridFinancialTransactionsFromWipoEndEvent", 1);
	// }
	//
	// protected Map<String, Object> getParameterMap() {
	// Map<String, Object> processVariables = new HashMap<>();
	//
	// List<TransactionDetail> transactionDetailList = new ArrayList<>();
	// TransactionDetail testTxDetail = new TransactionDetail();
	// testTxDetail.setTransactionId(new BigDecimal(10001));
	// transactionDetailList.add(testTxDetail);
	// processVariables.put(TRANSACTION_DETAIL_LIST, transactionDetailList);
	//
	// processVariables.put(PACKAGE_ID, "FakePackage01");
	// processVariables.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
	// List<ReportTypeEnumResolver> reportTypeList = new ArrayList<>();
	// // TODO Put it back when we figure out the values
	// // reportTypeList.add(new
	// ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_GAP_PDF));
	// // reportTypeList.add(new
	// ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_GAP_XLS));
	// processVariables.put(REPORT_TYPE_LIST, reportTypeList);
	//
	// processVariables.put(UPLOAD_VERIFICATION_POLL_INTERVAL, "PT1S");
	//
	// processVariables.put(FIN_PKG_DOWNLOAD_VERIFICATION_POLL_PERIOD, "PT1S");
	// processVariables.put(FIN_PKG_FILE_NOT_FOUND_RETRY_PERIOD, "PT1S");
	// processVariables.put(FIN_PKG_PERSIST_INPUT_FOLDER, "/c/your/mom");
	// processVariables.put(FIN_PKG_PERSIST_FAIL_FOLDER, "/c/your/sister");
	// processVariables.put(FIN_PKG_DOWNLOAD_NUMBER_OF_RETRIES, "1");
	// processVariables.put(FIN_PKG_DOWNLOAD_TRANSFER_ITEM, "INFINPKG");
	// processVariables.put(FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX,
	// "FIN_PKG_2000-01.zip");
	//
	// processVariables.put(FIN_PKG_PERSIST_NUMBER_OF_REATTEMPTS, 0);
	// processVariables.put(FIN_PKG_PERSIST_TRANSFER_ITEM, IN_FINANCE_FEES);
	// processVariables.put(FIN_PKG_PERSIST_FAIL_FOLDER, "/c/path/to/fail");
	// processVariables.put(FIN_PKG_PERSIST_INPUT_FOLDER, "/c/path/to/input");
	// processVariables.put(FIN_PKG_PERSIST_VERIFICATION_POLL_PERIOD, "PT1S");
	//
	// processVariables.put(RECONCILED_INDICATOR, Boolean.TRUE);
	//
	// processVariables.put(FIN_PACKAGE_ID, "FakePackage01");
	//
	// processVariables.put(REPORT_TYPE_VAR, new
	// ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_FULL_XLS));
	//
	// return processVariables;
	// }
	//
	// private List<PackageUnit> createDummyPackageUnitList(int numEntries) {
	// List<PackageUnit> packageUnitList = new ArrayList<>();
	//
	// for (int i = 0; i < numEntries; i++) {
	// PackageUnit p = new PackageUnit();
	// p.setImgFileName("file" + i + ".zip");
	// p.setXmlFileName("xmlFile" + i + ".zip");
	// packageUnitList.add(p);
	// }
	//
	// return packageUnitList;
	// }
}
