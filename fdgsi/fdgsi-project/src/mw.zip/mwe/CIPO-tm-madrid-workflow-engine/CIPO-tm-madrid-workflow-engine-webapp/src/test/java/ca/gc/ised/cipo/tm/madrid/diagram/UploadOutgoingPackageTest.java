package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUTPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUT_DAILY_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_LOCATION_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_OUTGOING_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_VERIFICATION_POLL_INTERVAL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestUploadOutgoingTransactionPackageServiceImpl;
import util.TestUtils;

/**
 * Test class for the upload_madrid_packages_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class UploadOutgoingPackageTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    protected TestUploadOutgoingTransactionPackageServiceImpl testUploadOutgoingTransactionPackageServiceImpl;

    @Before
    public void init() {
        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(null);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(null);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(null);
        testUploadOutgoingTransactionPackageServiceImpl.setPackatgeListReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testHappyPath() {
        System.out.println("#############################################");
        System.out.println("###             testHappyPath             ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        List<String> packageList = createDummyPackageList(1);
        processVariables.put(PACKAGE_LOCATION_LIST, packageList);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPLOAD_OUTGOING_PACKAGE, runtimeService,
            processVariables);

        // Multi-threading fun! Wait for the process to end so we can query the
        // history and see what happened.
        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "uploadPackageEndEvent", (1 * packageList.size()));
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testPackageCreateError() {
        System.out.println("#############################################");
        System.out.println("###        testPackageCreateError         ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPLOAD_OUTGOING_PACKAGE, runtimeService,
            processVariables);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "packagePrepareErrorEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "errorHandlingEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testPackageCreateNothingToDo() {
        System.out.println("#############################################");
        System.out.println("###      testPackageCreateNothingToDo     ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(NOTHING_TO_DO);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPLOAD_OUTGOING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "nothingToDoEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testCreateTxReqError() {
        System.out.println("#############################################");
        System.out.println("###         testCreateTxReqError          ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        List<String> packageList = createDummyPackageList(1);
        processVariables.put(PACKAGE_LOCATION_LIST, packageList);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPLOAD_OUTGOING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Shouldn't reach this:
        TestUtils.assertActivitiEventFired(historyService, "verifyTransferTask", 0);
        // Should reach this:
        TestUtils.assertActivitiEventFired(historyService, "handleSubprocessBusinessError", (1 * packageList.size()));
        // Should still end
        TestUtils.assertActivitiEventFired(historyService, "uploadPackageEndEvent", (1 * packageList.size()));
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testPackageVerifyError() {
        System.out.println("#############################################");
        System.out.println("###        testPackageVerifyError         ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        List<String> packageList = createDummyPackageList(1);
        processVariables.put(PACKAGE_LOCATION_LIST, packageList);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPLOAD_OUTGOING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Should reach this:
        TestUtils.assertActivitiEventFired(historyService, "handleSubprocessBusinessError", (1 * packageList.size()));
        // Should still end
        TestUtils.assertActivitiEventFired(historyService, "uploadPackageEndEvent", (1 * packageList.size()));
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testPackageVerifyIncomplete() {
        System.out.println("#############################################");
        System.out.println("###      testPackageVerifyIncomplete      ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        List<String> packageList = createDummyPackageList(1);
        processVariables.put(PACKAGE_LOCATION_LIST, packageList);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(INCOMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPLOAD_OUTGOING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Create transfer request task should have fired once while the verify
        // task twice.
        TestUtils.assertActivitiEventFired(historyService, "createTransferRequestTask", (1 * packageList.size()));
        TestUtils.assertActivitiEventFired(historyService, "verifyTransferTask", (2 * packageList.size()));
        TestUtils.assertActivitiEventFired(historyService, "uploadPackageEndEvent", (1 * packageList.size()));
    }

    private Map<String, Object> getTypicalProcessVars() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(TRANSFER_ITEM, OUT_DAILY_PKG);
        processVariables.put(OUTPUT_FOLDER, "/c/path/to/output");
        processVariables.put(FAIL_FOLDER, "/c/path/to/output");
        processVariables.put(UPLOAD_VERIFICATION_POLL_INTERVAL, "PT1S");
        return processVariables;
    }

    private List<String> createDummyPackageList(int numElements) {
        List<String> packageList = new ArrayList<>(numElements);

        for (int i = 1; i <= numElements; i++) {
            packageList.add("c:/Temp/File" + i + ".zip");
        }
        return packageList;
    }
}
