package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.ws.BindingProvider;

import org.activiti.engine.RuntimeService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingPairCriteria;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskIdsResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.OfficeToIbProcessActions;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ReportTypeEnum;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.client.common.MadridTransactionServiceFactory;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Manager class to handle the Madrid transaction service calls and response as
 * well as any SOAP faults.
 *
 * @author J. Greene
 *
 */
@Service
public class MtsServiceManagerImpl extends AbstractServiceManager implements MtsServiceManager {

	@Autowired
	protected RuntimeService runtimeService;

	@Autowired
	protected TaskExecutor taskExecutor;

	@Value("${mwe.mts.service.endpoint.hostname}")
	protected String mtsHost;

	protected MadridTransactionServicePortType mtsClient;

	protected static final Logger LOG = LoggerFactory.getLogger(MtsServiceManagerImpl.class);

	/*
	 * (non-Javadoc)
	 *
	 * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager#
	 * getTransactionList(ca.gc.ic.cipo.tm.mts.TransactionCriteria)
	 */
	@Override
	public List<TransactionDetail> getTransactionList(TransactionCriteria transactionCriteria)
			throws BpmnWebServiceCallException {
		if (transactionCriteria == null) {
			throw new IllegalArgumentException("Parameter [transactionCriteria] must not be null");
		}
		List<TransactionDetail> transactionDetailList = null;

		try {
			LOG.debug("--> Calling WSO : getTransactionList");
			transactionDetailList = getMtsClient().getTransactionList(transactionCriteria);
			LOG.debug("-->         WSO : getTransactionList - returned with " + transactionDetailList.size()
					+ " transacitons");
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "getTransactionList");
		}
		return transactionDetailList;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager#
	 * processAutomatedTransaction(ca.gc.ic.cipo.tm.mts.
	 * AutomaticProcessingCriteria)
	 */
	@Override
	public AutomatedProcessResponse processAutomatedTransaction(AutomaticProcessingCriteria apc)
			throws BpmnWebServiceCallException {
		if (apc == null) {
			throw new IllegalArgumentException("Parameter [apc] must not be null");
		}
		AutomatedProcessResponse apr = null;

		try {
			LOG.debug("--> Calling WSO : processAutomatedTransaction");
			apr = getMtsClient().processAutomatedTransaction(apc);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "processAutomatedTransaction");
		}

		return apr;
	}

	@Override
	public AutomatedProcessResponse processAutomatedTransactionPair(AutomaticProcessingPairCriteria appc)
			throws BpmnWebServiceCallException {
		if (appc == null) {
			throw new IllegalArgumentException("Parameter [appc] must not be null");
		}
		AutomatedProcessResponse apr = null;

		try {
			LOG.debug("--> Calling WSO : processAutomatedTransactionPair");
			apr = getMtsClient().processAutomatedTransactionPair(appc);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "processAutomatedTransactionPair");
		}

		return apr;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager#
	 * processManualTransaction(ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria)
	 */
	@Override
	public ManualProcessResponse processManualTransaction(ManualProcessingCriteria criteria)
			throws BpmnWebServiceCallException {
		if (criteria == null) {
			throw new IllegalArgumentException("Parameter [criteria] must not be null");
		}

		ManualProcessResponse response = null;

		try {
			response = getMtsClient().processManualTransaction(criteria);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "processManualTransaction");
		}

		return response;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager#
	 * updateConsoleTaskStatus(java.math.BigDecimal,
	 * ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType)
	 */
	@Override
	public void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType statusType)
			throws BpmnWebServiceCallException {
		if (consoleTaskId == null) {
			throw new IllegalArgumentException("Parameter [consoleTaskId] must not be null");
		}
		if (statusType == null) {
			throw new IllegalArgumentException("Parameter [statusType] must not be null");
		}

		try {
			getMtsClient().updateConsoleTaskStatus(consoleTaskId, statusType);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "updateConsoleTaskStatus");
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager#
	 * updateConsoleTaskReference(java.lang.String, java.math.BigDecimal)
	 */
	@Override
	public void updateConsoleTaskReference(String userTaskId, BigDecimal consoleTaskId)
			throws BpmnWebServiceCallException {
		if (StringUtils.isBlank(userTaskId)) {
			throw new IllegalArgumentException("Parameter [userTaskId] must not be null");
		}
		if (consoleTaskId == null) {
			throw new IllegalArgumentException("Parameter [consoleTaskId] must not be null");
		}

		try {
			getMtsClient().updateConsoleTaskReference(userTaskId, consoleTaskId);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "updateConsoleTaskReference");
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager#
	 * checkExistingMark(ca.gc.ic.cipo.tm.mts.ExistingMarkRequest)
	 */
	@Override
	public ExistingMarkResponse checkExistingMark(ExistingMarkRequest req) throws BpmnWebServiceCallException {
		if (req == null) {
			throw new IllegalArgumentException("Parameter [req] must not be null");
		}
		ExistingMarkResponse response = null;

		try {
			response = getMtsClient().checkExistingMark(req);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "checkExistingMark");
		}

		return response;
	}

	@Override
	public ConsoleTaskIdsResponse checkForNotifications(CheckForNotificationsRequest req)
			throws BpmnWebServiceCallException {

		if (req == null) {
			throw new IllegalArgumentException("Parameter [req] must not be null");
		}

		ConsoleTaskIdsResponse response = null;

		try {
			// response = getMtsClient().checkForNotifications(req);
			response = getMtsClient().checkForNotifications(req);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "checkExistingMark");
		}

		return response;
	}

	@Override
	public OfficeToIbProcessActions getOfficeToIbProcessActions(ProcessActionCategoryType type)
			throws BpmnWebServiceCallException {
		OfficeToIbProcessActions response = null;

		try {
			response = getMtsClient().getOfficeToIbProcessActions(type);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "getOfficeToIbProcessActions");
		}

		return response;
	}

	@Override
	public OfficeToIbTransactionResponse createOfficeToIbTransaction(ProcessActionsMeta processActionsMeta)
			throws BpmnWebServiceCallException {
		OfficeToIbTransactionResponse response = null;

		try {
			response = getMtsClient().createOfficeToIbTransaction(processActionsMeta);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "createOfficeToIbTransaction");
		}

		return response;
	}

	@Override
	public ManualProcessResponse createOfficeToIbManualTask(ProcessActionsMeta processActionsMeta)
			throws BpmnWebServiceCallException {
		ManualProcessResponse response = null;

		try {
			response = getMtsClient().createOfficeToIbManualTask(processActionsMeta);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "createOfficeToIbTransaction");
		}

		return response;
	}

	/**
	 * Wraps the call in HTS to generate a report of a specific type given
	 * either the package ID or transaction ID associated with the report input
	 * data.
	 *
	 * @param packageId
	 *            the package ID pertaining to the report generation
	 * @param transactionId
	 *            the transaction ID pertaining to the report generation
	 * @param reportTypeCode
	 *            the type of report to be generated
	 * @return the report job ID for use when polling for report progress from
	 *         report service
	 * @throws BpmnWebServiceCallException
	 */
	@Override
	public String generateReport(BigDecimal transactionId, ReportTypeEnum reportTypeCode)
			throws BpmnWebServiceCallException {
		String reportJobId = null;
		if (transactionId == null) {
			throw new IllegalArgumentException("Parameter [transactionId] must not be provided");
		}
		if (reportTypeCode == null) {
			throw new IllegalArgumentException("Parameter [reportTypeCode] must not be null");
		}

		// TODO Put it back when MTS is ready
		// try {
		// LOG.debug("--> Calling WSO : generateReport - with transaction ID " +
		// transactionId);
		// reportJobId = getMtsClient().generateReport(transactionId,
		// reportTypeCode);
		// LOG.debug("--> WSO : generateReport - returned with ID " +
		// reportJobId);
		// } catch (CIPOServiceFault csf) {
		// handleMtsSoapFault(csf);
		// } catch (Throwable t) {
		// handleWebServiceException(t, ProcessFlowConstants.MTS,
		// "generateReport");
		// }

		return reportJobId;
	}

	/**
	 * Wraps a call to HTS to notify HTS that a report is ready for consumption.
	 *
	 * @param reportJobId
	 *            the report job ID of the completed report in RGS
	 * @param packageId
	 *            the package ID pertaining to the report generation
	 * @param transactionId
	 *            the transaction ID pertaining to the report generation
	 * @param reportTypeCode
	 *            the type of report to be generated
	 * @return the attachment ID of the attachment that was created in the INTL
	 *         DB as a result of this call
	 * @throws BpmnWebServiceCallException
	 */
	@Override
	public BigDecimal generateReportNotification(String reportJobId, BigDecimal transactionId,
			ReportTypeEnum reportTypeCode) throws BpmnWebServiceCallException {
		BigDecimal attachmentId = null;
		if (transactionId == null) {
			throw new IllegalArgumentException("Parameter [transactionId] must not be provided");
		}
		if (reportJobId == null) {
			throw new IllegalArgumentException("Parameter [reportJobId] must not be null");
		}
		if (reportTypeCode == null) {
			throw new IllegalArgumentException("Parameter [reportTypeCode] must not be null");
		}

		try {
			LOG.debug("--> Calling WSO : generateReportNotification - with report job ID " + reportJobId);
			getMtsClient().generateReportNotification(reportJobId, transactionId, reportTypeCode);
			// attachmentId =
			// getMtsClient().generateReportNotification(reportJobId,
			// transactionId, reportTypeCode);
			// LOG.debug("--> WSO : generateReportNotification - returned with
			// ID " + attachmentId);
		} catch (CIPOServiceFault csf) {
			handleMtsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MTS, "generateReportNotification");
		}
		return attachmentId;
	}

	protected void handleMtsSoapFault(CIPOServiceFault fault) throws BpmnWebServiceCallException {
		BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(fault.getFaultInfo());

		BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::CIPOServiceFault::");
		serviceException.setBusinessErrorLogItem(businessErrorLogItem);
		throw serviceException;
	}

	protected String getMtsHost() {
		if (StringUtils.isBlank(mtsHost)) {
			throw new IllegalArgumentException(
					"Please provide a valid value for property [mts.service.endpoint.hostname] in the application configuration");
		}
		return mtsHost;
	}

	protected MadridTransactionServicePortType getMtsClient() {
		if (mtsClient == null) {
			mtsClient = MadridTransactionServiceFactory.createMadridTransactionClient(getMtsHost());
		}

		return mtsClient;
	}

	/** {@inheritDoc} */
	@Override
	protected BindingProvider getBindingProvider() {
		return (BindingProvider) getMtsClient();
	}

}
