package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATION_VERIFICATION_POLL_INTERVAL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR_WITH_RETRY;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_OUTGOING_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_VERIFICATION_POLL_INTERVAL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestPackageOutgoingTransactionsServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestUploadOutgoingTransactionPackageServiceImpl;
import util.TestUtils;

/**
 * Test class for the package_madrid_transactions_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class PackageOutgoingMessagesTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    protected TestPackageOutgoingTransactionsServiceImpl testPackageOutgoingTransactionsServiceImpl;

    @Autowired
    protected TestUploadOutgoingTransactionPackageServiceImpl testUploadOutgoingTransactionPackageServiceImpl;

    @Before
    public void init() {
        testPackageOutgoingTransactionsServiceImpl.setCreateUploadPackageStatusReturnObject(null);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(null);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(null);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(null);
        testUploadOutgoingTransactionPackageServiceImpl.setPackatgeListReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})

    public void testHappyPath() {
        System.out.println("#############################################");
        System.out.println("###             testHappyPath             ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();
        testPackageOutgoingTransactionsServiceImpl.setCreateUploadPackageStatusReturnObject(COMPLETE);
        testPackageOutgoingTransactionsServiceImpl.setPackageCreationVerifyStatusReturnObject(COMPLETE);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(COMPLETE);

        List<String> packageList = createDummyPackageList(1);
        testUploadOutgoingTransactionPackageServiceImpl.setPackatgeListReturnObject(packageList);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PACKAGE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        // Make sure it ended
        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure the end event fired.
        TestUtils.assertActivitiEventFired(historyService, "packageMessagesEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn"})
    public void testErrorHandling() {
        System.out.println("#############################################");
        System.out.println("###           testErrorHandling           ###");
        System.out.println("#############################################");

        // ERROR at create upload package
        Map<String, Object> processVariables = getTypicalProcessVars();
        testPackageOutgoingTransactionsServiceImpl.setCreateUploadPackageStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PACKAGE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testErrorWithRetry() {
        System.out.println("#############################################");
        System.out.println("###           testErrorWithRetry          ###");
        System.out.println("#############################################");

        // ERROR at create upload package
        Map<String, Object> processVariables = getTypicalProcessVars();
        testPackageOutgoingTransactionsServiceImpl.setCreateUploadPackageStatusReturnObject(ERROR_WITH_RETRY);
        testPackageOutgoingTransactionsServiceImpl.setPackageCreationVerifyStatusReturnObject(COMPLETE);

        testUploadOutgoingTransactionPackageServiceImpl.setPackageGatherStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setPackageVerifyStatusReturnObject(COMPLETE);
        testUploadOutgoingTransactionPackageServiceImpl.setUploadTrStatusReturnObject(COMPLETE);

        List<String> packageList = createDummyPackageList(1);
        testUploadOutgoingTransactionPackageServiceImpl.setPackatgeListReturnObject(packageList);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PACKAGE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "createMessagePackageTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "packageMessagesEndEvent", 1);
    }

    private Map<String, Object> getTypicalProcessVars() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(CREATION_VERIFICATION_POLL_INTERVAL, "PT1S");
        processVariables.put(UPLOAD_VERIFICATION_POLL_INTERVAL, "PT1S");
        return processVariables;
    }

    private List<String> createDummyPackageList(int numElements) {
        List<String> packageList = new ArrayList<>(numElements);

        for (int i = 1; i <= numElements; i++) {
            packageList.add("c:/Temp/File" + i + ".zip");
        }
        return packageList;
    }

}
