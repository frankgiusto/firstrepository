package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.util.List;

import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * An interface of a service class to front the DAO class for HWE's package download log.
 *
 * @author J. Greene
 *
 */
public interface BusinessErrorLogService {

    /**
     * Inserts a business error log item.
     *
     * @param item The business error log item object
     */
    void insertBusinessErrorLogEntry(BusinessErrorLogItem item);

    /**
     * Purges business error log items older than the number of days provided.
     *
     * @param olderThanNumberOfDays The number of days beyond which records will be deleted
     */
    void purgeOldBusinessErrorLogEntries(int olderThanNumberOfDays);

    /**
     * Searches business error log items based on parameters passed in the form of a {@code BusinessErrorLogItem}
     * object.
     *
     * @param item The object containing valid search fields
     * @return a collection of {@code BusinessErrorLogItem}s representing the search parameter
     */
    List<BusinessErrorLogItem> getBusinessErrorLogItemsByFields(BusinessErrorLogItem item);

    /**
     * Returns all business error log items currently in the database. Use with caution.
     *
     * @return a collection of {@code BusinessErrorLogItem}s
     */
    List<BusinessErrorLogItem> getAllBusinessErrorLogItems();

}
