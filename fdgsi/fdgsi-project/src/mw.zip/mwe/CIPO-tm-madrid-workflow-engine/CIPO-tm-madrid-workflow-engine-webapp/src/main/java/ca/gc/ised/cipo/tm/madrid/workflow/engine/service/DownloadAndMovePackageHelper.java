package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * An interface to describe the behavior of a helper class that will download and move DTF packages to local staging.
 *
 * @author J. Greene
 *
 */
public interface DownloadAndMovePackageHelper {

    void downloadAndMovePackage(DownloadLogItem downloadLogItem, Integer requestId, String outputDirectoryString);
}
