package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_AND_PERSIST_AUTOMATED_MESSAGE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_AND_PERSIST_MANUAL_MESSAGE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_OUTGOING_MANUAL_TASK;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FETCH_PENDING_AUTOMATED_MSG_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FETCH_PENDING_MANUAL_MSG_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_AUTOMATED_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_AUTOMATED_MESSAGES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_MANUAL_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_MANUAL_MESSAGES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.SERVICE_FAULT_SEVERITY_THRESHOLD;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.OfficeToIbProcessActions;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsResponse;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.CreateOutgoingTransactionsService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * A service that will handle delegated task actions from the {@code create_madrid_transactions_to_wipo.bpmn} process
 * flow.
 *
 */
@Service
public class CreateOutgoingTransactionServiceImpl extends BusinessErrorHandlerImpl
    implements CreateOutgoingTransactionsService, Serializable {

    @Autowired
    MtsServiceManager mtsServiceManager;

    protected static final Logger LOG = LoggerFactory.getLogger(CreateOutgoingTransactionServiceImpl.class);

    private static final long serialVersionUID = 6691693826927038879L;

    /**
     * {@inheritDoc}
     * <p>
     * Uses a web service call to fetch a collection of pending Madrid automated messages that are to be processed. The
     * collection is placed in the process variable called {@code pendingAutomatedMessages}. A success/fail process
     * variable called {@code fetchPendingAutomatedMsgsStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  1]} - OK,<br/>
     * {@code [ -1]} - Error,<br/>
     * {@code [ 10]} - Nothing to do
     * </p>
     */
    @Override
    public void getOfficeToIbAutomaticProcessActions(DelegateExecution execution) {
        getOfficeToIbProcessActions(execution, ProcessActionCategoryType.AUTOMATIC, PENDING_AUTOMATED_MESSAGES,
            FETCH_PENDING_AUTOMATED_MSG_STATUS);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses a web service call to fetch a collection of pending Madrid manual messages that are to be processed. The
     * collection is placed in the process variable called {@code pendingManualMessages}. A success/fail process
     * variable called {@code fetchPendingManualMsgsStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  1]} - OK,<br/>
     * {@code [ -1]} - Error,<br/>
     * {@code [ 10]} - Nothing to do
     * </p>
     */
    @Override
    public void getOfficeToIbManualProcessActions(DelegateExecution execution) {
        getOfficeToIbProcessActions(execution, ProcessActionCategoryType.MANUAL, PENDING_MANUAL_MESSAGES,
            FETCH_PENDING_MANUAL_MSG_STATUS);
    }

    private void getOfficeToIbProcessActions(DelegateExecution execution, ProcessActionCategoryType type,
                                             String pendingMessageKey, String fetchStatusKey) {
        List<ProcessActionsResponse> processActionList = new ArrayList<ProcessActionsResponse>();
        Integer fetchPendingMsgsStatus = COMPLETE;

        try {
            OfficeToIbProcessActions processActions = mtsServiceManager.getOfficeToIbProcessActions(type);

            if (processActions != null && processActions.getProcessActionList() != null) {
                for (ProcessActionsResponse processAction : processActions.getProcessActionList().getTaskListBag()) {

                    // if (processAction.getProcessActionsMeta().getIrNumber() != null
                    // && processAction.getProcessActionsMeta().getIrNumber().equals("1355404")) {

                    processActionList.add(processAction);

                    // }

                }
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            fetchPendingMsgsStatus = ERROR;
        }

        execution.setVariable(pendingMessageKey, processActionList);
        execution.setVariable(fetchStatusKey, fetchPendingMsgsStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses a web service call to create and persist a pending automated message from the back end system to the INTL DB
     * datastore. A success/fail process variable called {@code createAndPersistMessageStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  1]} - OK<br/>
     * {@code [ -1]} - Error
     * </p>
     */
    @Override
    public void createOfficeToIbTransaction(DelegateExecution execution) {
        Integer createAndPersistMessageStatus = COMPLETE;
        ProcessActionsResponse processAction = execution.getVariableLocal(PENDING_AUTOMATED_MESSAGE,
            ProcessActionsResponse.class);

        try {
            OfficeToIbTransactionResponse response = mtsServiceManager
                .createOfficeToIbTransaction(processAction.getProcessActionsMeta());

            LOG.debug("Export automated transaction generated with ID [" + response.getIrTranId() + "]");
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            createAndPersistMessageStatus = ERROR;
        }

        execution.setVariableLocal(CREATE_AND_PERSIST_AUTOMATED_MESSAGE_STATUS, createAndPersistMessageStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Uses a web service call to create and persist a pending manual message from the back end system to the INTL DB
     * datastore. A success/fail process variable called {@code createAndPersistMessageStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  1]} - OK<br/>
     * {@code [ -1]} - Error
     * </p>
     */
    @Override
    public void createOfficeToIbManualTask(DelegateExecution execution) {
        Integer createAndPersistMessageStatus = COMPLETE;
        ProcessActionsResponse processAction = execution.getVariableLocal(PENDING_MANUAL_MESSAGE,
            ProcessActionsResponse.class);

        try {
            ManualProcessResponse processResponse = mtsServiceManager
                .createOfficeToIbManualTask(processAction.getProcessActionsMeta());

            // Create task in Madrid Console
            Map<String, Object> processVars = new HashMap<String, Object>();
            ConsoleTaskResponse taskResponse = processResponse.getConsoleTaskBag().get(0);

            processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, taskResponse.getConsoleTaskId());
            processVars.put(ProcessFlowConstants.CANDIDATE_GROUP_ID, taskResponse.getAuthorityId());

            runtimeService.startProcessInstanceByKey(CREATE_OUTGOING_MANUAL_TASK, processVars);
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            createAndPersistMessageStatus = ERROR;
        }

        execution.setVariableLocal(CREATE_AND_PERSIST_MANUAL_MESSAGE_STATUS, createAndPersistMessageStatus);
    }

    /** {@inheritDoc} */
    @Override
    public void handleAutomatedIterativeError(DelegateExecution execution) {
        Integer recoverableErrorCondition = COMPLETE;

        BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
            BusinessErrorLogItem.class);
        ProcessActionsResponse processAction = execution.getVariableLocal(PENDING_AUTOMATED_MESSAGE,
            ProcessActionsResponse.class);

        if (!businessErrorLogItem.isCipoServiceFaultOrigin()) {
            recoverableErrorCondition = ERROR;
            LOG.error("A non-CipoServiceFault error occurred while processing action ID "
                + processAction.getProcessActionsMeta().getProcessActionId());
        } else {
            // Check the fault return code. If it falls below the threshold,
            // assume not recoverable.
            if (businessErrorLogItem.getReturnCode() <= SERVICE_FAULT_SEVERITY_THRESHOLD) {
                recoverableErrorCondition = ERROR;
                LOG.error("A non-recoverable error occurred while processing action ID "
                    + processAction.getProcessActionsMeta().getProcessActionId());
            } else {
                handleCumulativeError(execution, "EXPORT MESSAGE - Process Action ID: "
                    + processAction.getProcessActionsMeta().getProcessActionId());
            }
        }

        execution.setVariable(RECOVERABLE_ERROR_CONDITION, recoverableErrorCondition);
    }

    /** {@inheritDoc} */
    @Override
    public void handleManualIterativeError(DelegateExecution execution) {
        Integer recoverableErrorCondition = COMPLETE;

        BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
            BusinessErrorLogItem.class);
        ProcessActionsResponse processAction = execution.getVariableLocal(PENDING_MANUAL_MESSAGE,
            ProcessActionsResponse.class);

        if (!businessErrorLogItem.isCipoServiceFaultOrigin()) {
            recoverableErrorCondition = ERROR;
            LOG.error("A non-CipoServiceFault error occurred while processing action ID "
                + processAction.getProcessActionsMeta().getProcessActionId());
        } else {
            // Check the fault return code. If it falls below the threshold,
            // assume not recoverable.
            if (businessErrorLogItem.getReturnCode() <= SERVICE_FAULT_SEVERITY_THRESHOLD) {
                recoverableErrorCondition = ERROR;
                LOG.error("A non-recoverable error occurred while processing action ID "
                    + processAction.getProcessActionsMeta().getProcessActionId());
            } else {
                handleCumulativeError(execution, "EXPORT MESSAGE - Process Action ID: "
                    + processAction.getProcessActionsMeta().getProcessActionId());
            }
        }

        execution.setVariable(RECOVERABLE_ERROR_CONDITION, recoverableErrorCondition);
    }

}
