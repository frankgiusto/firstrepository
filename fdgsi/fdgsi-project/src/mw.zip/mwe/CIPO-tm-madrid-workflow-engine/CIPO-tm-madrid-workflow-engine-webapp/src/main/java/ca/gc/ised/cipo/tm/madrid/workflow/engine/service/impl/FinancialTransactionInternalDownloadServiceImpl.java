package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DTF_PACKAGE_TEMP_NAME_PREFIX;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FILE_NOT_FOUND_ON_SERVER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_FILE_FULL_PATH;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_REQUEST_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_INPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_MOVE_TO_STAGING_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQUEST_LOG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQ_ID_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.VERIFY_FIN_PACKAGE_DOWNLOAD_TRANSFER_STATUS;

import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.patents.dtf.trs.CreateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.DownloadResponse;
import ca.gc.ic.cipo.patents.dtf.trs.GetTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestStateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.UpdateTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.model.RequestStateCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.DownloadAndMovePackageHelper;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionInternalDownloadService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.InFinFeesTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem.Status;

/**
 * Service class for the financial feedback download subprocess call activity of the financial flow.
 *
 * @author J. Greene
 * @see FinancialTransactionReconcileServiceImpl
 */
@Service
public class FinancialTransactionInternalDownloadServiceImpl extends BusinessErrorHandlerImpl
    implements FinancialTransactionInternalDownloadService, Serializable {

    @Autowired
    protected DtfServiceManager dtfServiceManager;

    @Autowired
    protected PackageDownloadLogService packageDownloadLogService;

    @Autowired
    protected DownloadAndMovePackageHelper downloadHelper;

    private static final long serialVersionUID = 1794038660261292867L;

    /**
     * {@inheritDoc}
     * <p>
     * Creates a transfer request via DTF to download the financial system feedback file. The process variable
     * {@code transferRequestId} is set accordingly. The process variable {@code finPkgDownloadRequestStatus} is set
     * accordingly:
     * </p>
     * <p>
     * {@code [  -1]} if the transfer request failed, <br/>
     * {@code [   1]} if the transfer request succeeded<br/>
     * </p>
     *
     */
    @Override
    public void createFinSysFeedbackTransferRequest(DelegateExecution execution) {
        Integer finPkgDownloadRequestStatus = COMPLETE;
        String outputDirectoryString = execution.getVariable(FIN_PKG_PERSIST_INPUT_FOLDER, String.class);

        InFinFeesTransferRequestCreator txCreator = new InFinFeesTransferRequestCreator();

        try {
            CreateTransferRequest requestObject = txCreator.createOutgoingTransferRequest(execution);
            CreateResponse response = dtfServiceManager.createTransferRequest(requestObject);

            String transferRequestId = response.getTransferRequest().getRequestId();
            if (StringUtils.isBlank(transferRequestId)) {
                registerGenericMweBusinessError(execution, "No transfer request ID was returned from service!");
                finPkgDownloadRequestStatus = ERROR;
            } else {
                execution.setVariable(TRANSFER_REQ_ID_VAR, transferRequestId);
                LOG.info("Created transfer request #" + transferRequestId);

                // log transfer
                String fileNameRegex = execution
                    .getVariable(ProcessFlowConstants.FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX, String.class);
                DownloadLogItem downloadLogItem = new DownloadLogItem(transferRequestId, IN_FINANCE_FEES, null,
                    outputDirectoryString, fileNameRegex);
                packageDownloadLogService.insertLogEntry(downloadLogItem);
                execution.setVariable(TRANSFER_REQUEST_LOG, downloadLogItem);
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            finPkgDownloadRequestStatus = ERROR;
        }

        execution.setVariable(FIN_PKG_DOWNLOAD_REQUEST_STATUS, finPkgDownloadRequestStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Verifies the DTF download process and reports on the progress and the sets the process variable
     * {@code verifyFinPackageDownloadTransferStatus} according to the outcome of the verification:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [   0]} if incomplete,<br/>
     * {@code [  -1]} if an error occurred trying to fetch the status, <br/>
     * {@code [ -10]} if transfer failed (assume file not found remotely)
     * </p>
     */
    @Override
    public void verifyFinSysFeedbackDownload(DelegateExecution execution) {
        Integer verifyFinPackageDownloadTransferStatus = COMPLETE;
        String transferRequestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);
        TransferRequestStateXsd inputState = new TransferRequestStateXsd();
        inputState.setRequestId(transferRequestId);
        Status downloadStatus = Status.INPROGRESS;
        String downloadMessage = null;
        DownloadLogItem downloadLogItem = execution.getVariable(TRANSFER_REQUEST_LOG, DownloadLogItem.class);

        GetTransferRequestState request = new GetTransferRequestState();
        request.setRacfUser(MweWorkflowUtil.getRacfUser());
        request.setTransferRequestState(inputState);

        try {
            TransferRequestStateResponse response = dtfServiceManager.getTransferRequestState(request);

            RequestStateCode returnedStateCode = RequestStateCode
                .getEnumByCodeValue(response.getTxRequestState().getStateCode());
            if (returnedStateCode == null) {
                downloadMessage = "Request State Code [" + response.getTxRequestState().getStateCode()
                    + "] is unknown to this application.";
                registerGenericMweBusinessError(execution, downloadMessage);
                verifyFinPackageDownloadTransferStatus = ERROR;
                downloadStatus = Status.FAIL;
            } else {
                switch (returnedStateCode) {
                    case FAILED:
                        /*********************************************************************************
                         * Huge caveat here: There's no way to tell why the transfer request failed via the web service,
                         * only that it failed. For now assume file was not found so it can queue up again for another
                         * round.
                         *********************************************************************************/
                        verifyFinPackageDownloadTransferStatus = FILE_NOT_FOUND_ON_SERVER;
                        downloadMessage = "Transfer request #" + transferRequestId + " failed (file not found?).";
                        LOG.info(downloadMessage);
                        downloadStatus = Status.FAILNOTFOUND;
                        break;
                    case CANCELLED:
                        BusinessErrorLogItem businessErrorLogItem = dtfServiceManager
                            .createBusinessErrorLogItem(response);
                        businessErrorLogItem.setMessage("DTF Transfer for request #" + transferRequestId + " failed.");
                        execution.setVariable(ERR_MSG_OBJECT_VAR, businessErrorLogItem);
                        verifyFinPackageDownloadTransferStatus = ERROR;
                        downloadMessage = "Transfer request #" + transferRequestId + " failed.";
                        LOG.info(downloadMessage);
                        downloadStatus = Status.FAIL;
                        break;
                    case IN_PROGRESS:
                    case INITIATED:
                    case READY_FOR_PROCESSING:
                        verifyFinPackageDownloadTransferStatus = INCOMPLETE;
                        downloadMessage = "Transfer request #" + transferRequestId + " is in progress.";
                        LOG.info(downloadMessage);
                        break;
                    case COMPLETED:
                        verifyFinPackageDownloadTransferStatus = COMPLETE;
                        downloadMessage = "Transfer request #" + transferRequestId + " succeeded!";
                        LOG.info(downloadMessage);
                        downloadStatus = Status.DTF_STAGED;
                        break;
                    default:
                        // No handling available for other edge cases
                        downloadMessage = "Unable to process the DTF transfer state [" + returnedStateCode.codeValue()
                            + "]";
                        registerGenericMweBusinessError(execution, downloadMessage);
                        verifyFinPackageDownloadTransferStatus = ERROR;
                        downloadStatus = Status.FAIL;
                }
            }
            downloadLogItem.setDlStatus(downloadStatus.getValue());
            downloadLogItem.setMsg(downloadMessage);
            packageDownloadLogService.updateLogEntry(downloadLogItem);

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            verifyFinPackageDownloadTransferStatus = ERROR;
            failDownloadItem(downloadLogItem, bpe.getMessage());
        }

        execution.setVariable(VERIFY_FIN_PACKAGE_DOWNLOAD_TRANSFER_STATUS, verifyFinPackageDownloadTransferStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Fetches the downloaded package from DTF staging and moves it to the provided output folder. The flow variable
     * {@code packageMoveToStagingStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an error occurred with the download request or move <br/>
     * </p>
     */
    @Override
    public void movePackageToStaging(DelegateExecution execution) {
        Integer transferRequestId = Integer.parseInt(execution.getVariable(TRANSFER_REQ_ID_VAR, String.class));
        Integer packageMoveToStagingStatus = COMPLETE;
        DownloadLogItem downloadLogItem = execution.getVariable(TRANSFER_REQUEST_LOG, DownloadLogItem.class);
        String outputDirectoryString = execution.getVariable(FIN_PKG_PERSIST_INPUT_FOLDER, String.class);

        try {
            DownloadResponse dlResponse = dtfServiceManager.downloadStagedFiles(transferRequestId);
            DataHandler dataHandler = dlResponse.getZipStream();
            if (dataHandler == null) {
                String msg = "Data object from DTF is null!";
                failDownloadItem(downloadLogItem, msg);
                registerGenericMweBusinessError(execution, msg);
                packageMoveToStagingStatus = ERROR;
            } else {

                String packageFileName = DTF_PACKAGE_TEMP_NAME_PREFIX.concat(transferRequestId.toString())
                    .concat(".zip");

                MweWorkflowUtil.moveFileStream(dataHandler, outputDirectoryString, packageFileName);
                // See if the file is there
                Path packageFilePath = Paths.get(outputDirectoryString, packageFileName);
                if (Files.exists(packageFilePath)) {
                    // unzip the package in place.
                    List<String> entryNames = MweWorkflowUtil.unzipInPlace(packageFilePath);

                    // remove the old DTF archive
                    Files.deleteIfExists(packageFilePath);

                    Date downloadDate = new Date();
                    int iterCount = 0;
                    for (String entryName : entryNames) {
                        if (iterCount++ == 0) {
                            downloadLogItem.setDlDate(downloadDate);
                            downloadLogItem.setFileName(entryName);
                            downloadLogItem.setDlStatus(Status.SUCCESS.getValue());
                            packageDownloadLogService.updateLogEntry(downloadLogItem);
                            Path xmlFilePath = Paths.get(outputDirectoryString, entryName);
                            execution.setVariable(FIN_PKG_DOWNLOAD_FILE_FULL_PATH, xmlFilePath.toString());
                        } else {
                            // if there's more than one file in the DTF archive, create new download log items for each
                            // for tracking purposes.
                            DownloadLogItem relatedDownloadLogItem = new DownloadLogItem();
                            BeanUtils.copyProperties(relatedDownloadLogItem, downloadLogItem);
                            relatedDownloadLogItem.setFileName(entryName);
                            relatedDownloadLogItem.setDlDate(downloadDate);
                            packageDownloadLogService.insertLogEntry(relatedDownloadLogItem);
                            LOG.warn(
                                "More than one file in the archive from the financial system was found.  Expecting only one.");
                        }
                    }
                    LOG.info("Successfully moved package '" + packageFileName + "'");
                }
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            failDownloadItem(downloadLogItem, bpe.getMessage());
            packageMoveToStagingStatus = ERROR;
        } catch (Exception ex) {
            registerGenericMweBusinessError(execution, ex.getMessage());
            failDownloadItem(downloadLogItem, ex.getMessage());
            packageMoveToStagingStatus = ERROR;
        }

        execution.setVariable(PACKAGE_MOVE_TO_STAGING_STATUS, packageMoveToStagingStatus);
    }

    /** {@inheritDoc} */
    @Override
    public void sendTransferConfirmation(DelegateExecution execution) {
        String transferRequestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);
        TransferRequestStateXsd inputState = new TransferRequestStateXsd();
        inputState.setRequestId(transferRequestId);
        inputState.setStateCode(RequestStateCode.PROCESSED.codeValue());

        UpdateTransferRequestState request = new UpdateTransferRequestState();
        request.setRacfUser(MweWorkflowUtil.getRacfUser());
        request.setTransferRequestState(inputState);

        try {
            TransferRequestStateResponse response = dtfServiceManager.setTransferRequestState(request);
            if (!response.getTxRequestState().getStateCode().equals(request.getTransferRequestState().getStateCode())) {
                // Not a show stopper if it wasn't updated. But will warn anyway.
                LOG.warn("Transfer request ID " + transferRequestId
                    + " was processed successfully but was unable to be set accordingly in DTF.");
            } else {
                LOG.debug("Transfer request ID " + transferRequestId + " state update was successful in DTF.");
            }
        } catch (BpmnWebServiceCallException bpe) {
            LOG.warn(bpe.getMessage());
        }
    }

    protected void failDownloadItem(DownloadLogItem downloadLogItem, String msg) {
        downloadLogItem.setDlStatus(Status.FAIL.getValue());
        downloadLogItem.setMsg(msg);
        packageDownloadLogService.updateLogEntry(downloadLogItem);
    }
}
