package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.GAP_REPORT_EMAIL_NOTIFICATION_STATUS;

import java.io.Serializable;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionGapReportGenerationService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.EmailMessageDetails;

/**
 * Service class for the generate gap reports subprocess call activity of the financial flow.
 *
 * @author J. Greene
 * @see FinancialTransactionReconcileServiceImpl
 */
@Service
public class FinancialTransactionGapReportGenerationServiceImpl extends BusinessErrorHandlerImpl
    implements FinancialTransactionGapReportGenerationService, Serializable {

    private static final long serialVersionUID = 3557072846896994579L;

    @Autowired
    MfsServiceManager mfsServiceManager;

    @Autowired
    private static Environment env;

    /**
     * {@inheritDoc}
     * <p>
     * Calls an operation to get the notification email specifics (subject, body, recipient, etc.) and then sends an
     * email via the application server mail sender. The status variable {@code gapReportEmailNotificationStatus} is set
     * accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an error occurred<br/>
     * </p>
     */
    @Override
    public void sendGapReportNotification(DelegateExecution execution) {
        Integer gapReportEmailNotificationStatus = COMPLETE;
        try {
            EmailMessageDetails emailDeets = mfsServiceManager.getNotificationEmailContent();
            mailSender.send(env.getProperty("mwe.business.error.email.sender"), emailDeets.getToArray(),
                emailDeets.getSubject(), emailDeets.getBody());
        } catch (BpmnWebServiceCallException bpe) {
            gapReportEmailNotificationStatus = ERROR;
        }

        execution.setVariable(GAP_REPORT_EMAIL_NOTIFICATION_STATUS, gapReportEmailNotificationStatus);
    }

}
