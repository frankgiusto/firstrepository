package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.util.List;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.userprofile.schema.AuthorityType;
import ca.gc.ic.cipo.tm.userprofile.schema.BaseUserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;

/**
 * TUPS CLient to retrieve Office Users Profile
 *
 * @author Marvin Amin
 *
 */
public interface TUPSUserProfileService {

    public UserProfile getUserProfile( UserProfileType userProfileType ) throws CIPOServiceFault;


    public List<String> listAuthorityTypes( AuthorityType authorityType ) throws CIPOServiceFault;


    public List<BaseUserProfile> searchUserProfiles( UserAuthority userAuthority ) throws CIPOServiceFault;


    public HeartbeatResponseType getHeartbeat() throws CIPOServiceFault;
}
