package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FEE_STATUS_UPDATE_INDICATOR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FINANCIAL_TRANSACTION_LIST_GET_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FINANCIAL_TRANSACTION_RECONCILE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_VERIFICATION_POLL_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_FILE_NOT_FOUND_RETRY_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_INPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_NUMBER_OF_REATTEMPTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_PERSIST_VERIFICATION_POLL_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_UPLOAD_STAGING_FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_UPLOAD_STAGING_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MWE_INCOMING_STAGING_DIR_FINANCIAL_CIPO_FAIL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MWE_INCOMING_STAGING_DIR_FINANCIAL_CIPO_XML;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MWE_OUTGOING_STAGING_DIR_FINANCIAL_FAIL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MWE_OUTGOING_STAGING_DIR_FINANCIAL_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECONCILED_INDICATOR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECONCILED_SET_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_SERVICE_POLL_INTERVAL_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_TYPE_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.SERVICE_FAULT_SEVERITY_THRESHOLD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSACTION_DETAIL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSACTION_DETAIL_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_VERIFICATION_POLL_INTERVAL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.YYYY_MM_REGEX_SEGMENT;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.UpdatePackageStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionReconcileService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.ReportTypeEnumResolver;

/**
 * This is the main service class for delegate execution of the finance fee
 * workflow.
 *
 * @author J. Greene
 *
 */
@Service
public class FinancialTransactionReconcileServiceImpl extends BusinessErrorHandlerImpl
		implements FinancialTransactionReconcileService, Serializable {

	private static final long serialVersionUID = -9130385506622294445L;

	@Autowired
	protected MfsServiceManager mfsServiceManager;

	@Autowired
	protected MtsServiceManager mtsServiceManager;

	@Autowired
	protected MpsServiceManager mpsServiceManager;

	@Autowired
	private static Environment env;

	/**
	 * {@inheritDoc}
	 * <p>
	 * Calls a service operation to get a collection of transaction details
	 * related to unprocessed WIPO financial fee transactions. The call activity
	 * variable {@code transactionDetailList} will contain the results. The
	 * status variable {@code financialTransactionListGetStatus} will be
	 * populated accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 */
	@Override
	public void getFinancialTransactionCollection(DelegateExecution execution) {
		Integer financialTransactionListGetStatus = COMPLETE;
		BigDecimal packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);
		try {
			TransactionCriteria transactionCriteria = new TransactionCriteria();
			// TODO Put it back when we figure out the right value
			// transactionCriteria.getStatusCodeList().add(StatusType.MADRID_FEE_TRANS_IMPORTED);
			transactionCriteria.getPackageIdList().add(packageId);

			List<TransactionDetail> transactionDetails = mtsServiceManager.getTransactionList(transactionCriteria);
			execution.setVariable(TRANSACTION_DETAIL_LIST, transactionDetails);
			if (transactionDetails == null || transactionDetails.isEmpty()) {
				execution.setVariable(RECONCILED_INDICATOR, Boolean.FALSE);
			}
		} catch (BpmnWebServiceCallException bpe) {
			execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
			financialTransactionListGetStatus = ERROR;
		}

		execution.setVariable(FINANCIAL_TRANSACTION_LIST_GET_STATUS, financialTransactionListGetStatus);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Calls a service operation to reconcile the provided financial
	 * transaction. The process flow variable
	 * {@code financialTransactionReconcileStatus} will be set accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 */
	@Override
	public void reconcileFinancialTransaction(DelegateExecution execution) {
		Integer financialTransactionReconcileStatus = COMPLETE;
		TransactionDetail transactionDetail = execution.getVariableLocal(TRANSACTION_DETAIL, TransactionDetail.class);

		try {
			mfsServiceManager.reconcileFinancialTransaction(transactionDetail.getTransactionId());
		} catch (BpmnWebServiceCallException bpe) {
			execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
			financialTransactionReconcileStatus = ERROR;
		}
		execution.setVariableLocal(FINANCIAL_TRANSACTION_RECONCILE_STATUS, financialTransactionReconcileStatus);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Calls a service operation to generate an xml file for consumption later
	 * on in the process. The file must match the regex string located in the
	 * application properties. The variable
	 * {@code finPkgDownloadRemoteFileNameRegex} will be derived from the
	 * incoming file name and set in the process flow. The variable
	 * {@code finPkgUploadFileName} will be passed forward in the flow chain.
	 * The process flow variable {@code generateReconciledXmlStatus} will be set
	 * accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 */
	@Override
	public void generateReconciledFeeXml(DelegateExecution execution) {

		// MFS-CLEAN-SPR5 Integer generateReconciledXmlStatus = COMPLETE;
		// BigDecimal packageId = execution.getVariable(PACKAGE_ID,
		// BigDecimal.class);
		// String pkgOutputFolder =
		// execution.getVariable(FIN_PKG_UPLOAD_STAGING_FOLDER, String.class);
		//
		// ReconciledOutput feeXmlOutput;
		//
		// try {
		// feeXmlOutput =
		// mfsServiceManager.generateReconciledFeeDistribution(packageId);
		// if (feeXmlOutput != null && feeXmlOutput.getFileSteam().length > 0) {
		// String uploadFileName = feeXmlOutput.getFileName();
		// if (StringUtils.isNotBlank(uploadFileName)) {
		// String fileNameMatcher =
		// MweWorkflowUtil.getFileRegexForPackageType(OUT_FINANCE_FEES);
		// if (uploadFileName.matches(fileNameMatcher)) {
		//
		// ByteArrayDataSource ds = new
		// ByteArrayDataSource(feeXmlOutput.getFileSteam(),
		// MimeTypeUtils.APPLICATION_XML_VALUE);
		// DataHandler dh = new DataHandler(ds);
		//
		// MweWorkflowUtil.moveFileStream(dh, pkgOutputFolder, uploadFileName);
		//
		// execution.setVariable(FIN_PKG_UPLOAD_FILE_NAME, uploadFileName);
		//
		// String feedbackFileNameRegex =
		// deriveFeedbackFileNameRegex(uploadFileName);
		// if (StringUtils.isNotBlank(feedbackFileNameRegex)) {
		// execution.setVariable(FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX,
		// feedbackFileNameRegex);
		// } else {
		// registerGenericMweBusinessError(execution,
		// "Cannot derive the feedback file name from the upload file name!");
		// generateReconciledXmlStatus = ERROR;
		// }
		//
		// } else {
		// registerGenericMweBusinessError(execution, "Reconciled fee
		// distribution file name ["
		// + uploadFileName + "] does not match with the regex string [" +
		// fileNameMatcher + "]!");
		// generateReconciledXmlStatus = ERROR;
		// }
		// } else {
		// registerGenericMweBusinessError(execution, "Reconciled fee
		// distribution file name is blank!");
		// generateReconciledXmlStatus = ERROR;
		// }
		// } else {
		// registerGenericMweBusinessError(execution, "Reconciled fee
		// distribution file contains no data!");
		// generateReconciledXmlStatus = ERROR;
		// }
		// } catch (BpmnWebServiceCallException bpe) {
		// execution.setVariable(ERR_MSG_OBJECT_VAR,
		// bpe.getBusinessErrorLogItem());
		// generateReconciledXmlStatus = ERROR;
		// } catch (Exception ex) {
		// registerGenericMweBusinessError(execution,
		// "An exception occurred while trying to move file to staging area.",
		// ex);
		// generateReconciledXmlStatus = ERROR;
		// }
		//
		// execution.setVariable(GENERATE_RECONCILED_XML_STATUS,
		// generateReconciledXmlStatus);
	}

	/*
	 * Constructs the name regex of the feedback file from the financial system
	 * by using the name of the outgoing file and the regular expression of the
	 * feedback file.
	 */
	protected String deriveFeedbackFileNameRegex(String reconciledFeeXmlFileName) {
		String feedbackFileRegexString = MweWorkflowUtil.getFileRegexForPackageType(IN_FINANCE_FEES);
		int indexOfYmSegment = feedbackFileRegexString.indexOf(YYYY_MM_REGEX_SEGMENT);
		String ymString = null;
		StringBuilder targetedFeedbackFileRegex = new StringBuilder();

		Pattern ymPattern = Pattern.compile(YYYY_MM_REGEX_SEGMENT);
		Matcher ymMatcher = ymPattern.matcher(reconciledFeeXmlFileName);

		if (ymMatcher.find() && indexOfYmSegment > 0) {
			ymString = ymMatcher.group();
			targetedFeedbackFileRegex.append(feedbackFileRegexString.substring(0, indexOfYmSegment));
			targetedFeedbackFileRegex.append(ymString);
			targetedFeedbackFileRegex
					.append(feedbackFileRegexString.substring(indexOfYmSegment + YYYY_MM_REGEX_SEGMENT.length()));
		}

		return targetedFeedbackFileRegex.toString();
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Handles the iterative error that may occur while processing individual
	 * transactions. Evaluate the severity to alter course of action
	 * appropriately.
	 * </p>
	 */
	@Override
	public void handleIterativeError(DelegateExecution execution) {
		Integer recoverableErrorCondition = COMPLETE;
		execution.setVariable(RECONCILED_INDICATOR, Boolean.FALSE);

		BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
				BusinessErrorLogItem.class);
		TransactionDetail transactionDetail = execution.getVariableLocal(TRANSACTION_DETAIL, TransactionDetail.class);

		if (!businessErrorLogItem.isCipoServiceFaultOrigin()) {
			recoverableErrorCondition = ERROR;
		} else {
			// Check the fault return code. If it falls below the threshold,
			// assume not recoverable.
			if (businessErrorLogItem.getReturnCode() <= SERVICE_FAULT_SEVERITY_THRESHOLD) {
				recoverableErrorCondition = ERROR;
				LOG.error("A non-recoverable error occurred while processing transaction # ["
						+ transactionDetail.getTransactionId() + "]");
			} else {
				handleCumulativeError(execution, "TRANSACTION ID: " + transactionDetail.getTransactionId());
			}
		}

		execution.setVariable(RECOVERABLE_ERROR_CONDITION, recoverableErrorCondition);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Updates the package status after successful reconcile process. Sets the
	 * process flow variable {@code reconciledSetStatus} accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 */
	@Override
	public void updatePkgStatusPostReconcile(DelegateExecution execution) {
		Integer reconciledSetStatus = COMPLETE;
		BigDecimal packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);

		UpdatePackageStatusType pkgUpdateType = new UpdatePackageStatusType();

		pkgUpdateType.setPackageId(packageId);
		pkgUpdateType.setPackageStatusType(PackageStatusEnum.MADRID_FEE_PKG_RECONCILED);

		try {
			mpsServiceManager.updatePackageStatus(pkgUpdateType);
		} catch (BpmnWebServiceCallException bpe) {
			execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
			reconciledSetStatus = ERROR;
		}
		execution.setVariable(RECONCILED_SET_STATUS, reconciledSetStatus);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @throws Exception
	 */
	@Override
	public void setProcessFlowVariables(DelegateExecution execution) {

		// Keeps track of the number of errors encountered during reconciliation
		execution.setVariable(RECONCILED_INDICATOR, Boolean.TRUE);

		// Keeps track of the number of errors encountered during fee update
		execution.setVariable(FEE_STATUS_UPDATE_INDICATOR, Boolean.TRUE);

		// Report service poll interval. Same for gap reports and the financial
		// fee update report
		execution.setVariable(REPORT_SERVICE_POLL_INTERVAL_VAR, env.getProperty("hwe.report.service.poll.interval"));

		// The polling period default for upload via DTF to the financial
		// system.
		execution.setVariable(UPLOAD_VERIFICATION_POLL_INTERVAL,
				env.getProperty("hwe.hague.package.upload.default.poll.period"));

		// Financial feedback package download verification period
		execution.setVariable(FIN_PKG_DOWNLOAD_VERIFICATION_POLL_PERIOD,
				env.getProperty("hwe.hague.package.download.default.poll.period"));

		// Financial feedback package download transfer request retry period (if
		// file not found, etc.)
		execution.setVariable(FIN_PKG_FILE_NOT_FOUND_RETRY_PERIOD,
				env.getProperty("hwe.hague.package.download.notfound.retry.period"));

		// Transfer item for the finance feedback package
		execution.setVariable(FIN_PKG_PERSIST_TRANSFER_ITEM, IN_FINANCE_FEES);

		// Transfer item of the feedback package
		execution.setVariable(FIN_PKG_DOWNLOAD_TRANSFER_ITEM, IN_FINANCE_FEES);

		// Number of retries for package persist of financial feedback pkg
		execution.setVariable(FIN_PKG_PERSIST_NUMBER_OF_REATTEMPTS,
				env.getProperty("hwe.hague.package.persist.default.reattempt.count"));

		// Package persist verify poll period for financial feedback pkg
		execution.setVariable(FIN_PKG_PERSIST_VERIFICATION_POLL_PERIOD,
				env.getProperty("hwe.hague.package.persist.verification.poll.period"));

		// financial feedback report type
		// MFS-CLEAN-SPR5 execution.setVariable(REPORT_TYPE_VAR, new
		// ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_FULL_XLS));

		// Report types for the gap report. Right now only Excel and PDF
		List<ReportTypeEnumResolver> reportTypeList = new ArrayList<>();
		// TODO Put it back when we figure out the values
		// reportTypeList.add(new
		// ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_GAP_PDF));
		// reportTypeList.add(new
		// ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_GAP_XLS));
		execution.setVariable(REPORT_TYPE_LIST, reportTypeList);

		// Download folder for the feedback package
		String finPkgPersistInputFolder = env.getProperty(MWE_INCOMING_STAGING_DIR_FINANCIAL_CIPO_XML);
		execution.setVariable(FIN_PKG_PERSIST_INPUT_FOLDER, finPkgPersistInputFolder);

		// Processing fail folder for the feedback package
		String finPkgPersistFailFolder = env.getProperty(MWE_INCOMING_STAGING_DIR_FINANCIAL_CIPO_FAIL);
		execution.setVariable(FIN_PKG_PERSIST_FAIL_FOLDER, finPkgPersistFailFolder);

		// Staging folder for the feedback package upload
		String finPkgUploadStagingFolder = env.getProperty(MWE_OUTGOING_STAGING_DIR_FINANCIAL_PKG);
		execution.setVariable(FIN_PKG_UPLOAD_STAGING_FOLDER, finPkgUploadStagingFolder);

		// Staging fail folder for the feedback package upload
		String finPkgUploadStagingFailFolder = env.getProperty(MWE_OUTGOING_STAGING_DIR_FINANCIAL_FAIL);
		execution.setVariable(FIN_PKG_UPLOAD_STAGING_FAIL_FOLDER, finPkgUploadStagingFailFolder);
	}

}
