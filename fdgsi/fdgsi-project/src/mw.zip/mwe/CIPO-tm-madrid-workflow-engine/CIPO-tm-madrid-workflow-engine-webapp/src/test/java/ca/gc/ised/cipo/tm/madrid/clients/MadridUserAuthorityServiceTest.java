package ca.gc.ised.cipo.tm.madrid.clients;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;
import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.exception.UserAuthorityException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TUPSUserProfileService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.MadridUserAuthorityServiceImpl;

// @RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MadridWorkflowTestConfiguration.class})
public class MadridUserAuthorityServiceTest {

    protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Autowired
    private TUPSUserProfileService port;

    @Autowired
    private TaskService taskService;

    @Autowired
    private MadridUserAuthorityServiceImpl userAuthorityService;

    @Autowired
    @Rule
    public ActivitiRule activitiSpringRule;

    private ProcessInstance startProcessInstance(String key, Map<String, Object> processVars) {

        return activitiSpringRule.getRuntimeService().startProcessInstanceByKey(key, processVars);
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMSupervisorAssign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMSupervisorAssign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_EXAMINER.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAssignAuthority("MADRID3", task.getId(), "MADRID2");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMOBSupervisorAssign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMOBSupervisorAssign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID5", task.getId(), "MADRID4");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMSupervisorAssignToSelf() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMSupervisorAssignToSelf) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID3", task.getId(), "MADRID3");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMOBSupervisorAssignToSelf() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMOBSupervisorAssignToSelf) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID5", task.getId(), "MADRID5");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMOBSupervisorAssignToTMSupervisor() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMOBSupervisorAssignToTMSupervisor) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID5", task.getId(), "MADRID3");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMSupervisorAssign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMSupervisorAssign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID3", task.getId(), "MADRID4");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

            assertEquals(e.getClass(), UserAuthorityException.class);

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMOBSupervisorAssign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMOBSupervisorAssign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID1", "MADRID5", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

            assertEquals(e.getClass(), UserAuthorityException.class);

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidUserSelfAssign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidUserSelfAssign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_EXAMINER.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID2", task.getId(), "MADRID2");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidUserSelfAssign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidUserSelfAssign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_EXAMINER.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            success = this.userAuthorityService.verifyAssignAuthority("MADRID1", task.getId(), "MADRID1");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMSupervisorUnassign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMSupervisorUnassign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = "MADRID2";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyUnassignAuthority("MADRID3", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMOBSupervisorUnassign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMOBSupervisorUnassign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_OPERATOR.value();
        String userToAssign = "MADRID4";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyUnassignAuthority("MADRID5", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMUserSelfUnassign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMUserSelfUnassign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = "MADRID2";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyUnassignAuthority("MADRID2", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMSupervisorUnassign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMSupervisorUnassign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_OPERATOR.value();
        String userToAssign = "MADRID4";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyUnassignAuthority("MADRID3", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMOBSupervisorUnassign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMOBSupervisorUnassign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = "MADRID1";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyUnassignAuthority("MADRID5", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMUserSelfUnassign() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMUserSelfUnassign) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = "MADRID2";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyUnassignAuthority("MADRID1", task.getId());

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTaskCompletion() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTaskCompletion) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = "MADRID2";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyTaskCompletionAuthority(task.getId(), "MADRID2");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTaskCompletionUnassigned() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTaskCompletionUnassigned) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyTaskCompletionAuthority(task.getId(), "MADRID2");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTaskCompletionWrongGroup() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTaskCompletionWrongGroup) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_EXAMINER.value();
        String userToAssign = "MADRID1";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyTaskCompletionAuthority(task.getId(), "MADRID1");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidUserAckNotification() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidUserAckNotification) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAckNotificationAuthority(task.getId(), "MADRID2");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidSupervisorAckNotification() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidSupervisorAckNotification) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_OPERATOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAckNotificationAuthority(task.getId(), "MADRID3");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testValidTMOBSupervisorAckNotification() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testValidTMOBSupervisorAckNotification) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_SUPERVISOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAckNotificationAuthority(task.getId(), "MADRID5");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertTrue(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidUserAckNotification() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidUserAckNotification) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_EXAMINER.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAckNotificationAuthority(task.getId(), "MADRID1");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidSupervisorAckNotification() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidSupervisorAckNotification) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TM_EXAMINER.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAckNotificationAuthority(task.getId(), "MADRID5");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testInvalidTMSupervisorAckNotification() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testInvalidTMSupervisorAckNotification) started.");
        LOG.debug("------------");

        String groupToAssign = IntlAuthorityRole.MC_TMOB_SUPERVISOR.value();
        String userToAssign = null;

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", userToAssign);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        Boolean success = null;

        try {

            this.userAuthorityService.verifyAckNotificationAuthority(task.getId(), "MADRID3");

            success = true;

        } catch (UserAuthorityException e) {

            success = false;

            LOG.error("Error type: " + e.getErrorType());
            LOG.error("Error: " + e.getErrorMsg());

        }

        assertFalse(success);

        LOG.debug("Test complete.");
    }

    // ----------------------
    // End of Regular Tests.
    // ----------------------

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testDiagram() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testDiagram) started.");
        LOG.debug("------------");

        String groupToAssign = "SUPER_AWESOME_GROUP";

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("groupId", groupToAssign);
        processVars.put("userId", null);

        ProcessInstance instance = startProcessInstance("simpleUserTask", processVars);

        Task task = this.taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();

        List<IdentityLink> identityLinks = this.taskService.getIdentityLinksForTask(task.getId());

        assertEquals(groupToAssign, identityLinks.get(0).getGroupId());

        LOG.debug("Test complete.");
    }

    // @Test
    public void testTestUsers() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testTestUsers) started.");
        LOG.debug("------------");

        String[] testArray = {"MADRID2", "MADRID4", "MADRID5", "MADRID1", "MADRID3"};
        for (String userId : testArray) {

            LOG.debug("User -> " + userId);

            UserProfileType req = new UserProfileType();
            req.setUserName(userId);

            UserProfile res = null;

            try {

                res = port.getUserProfile(req);

            } catch (CIPOServiceFault e) {

                LOG.error("Error: " + e.getMessage());
                throw new InterruptedException();
            }

            List<UserAuthority> returnedAuths = res.getUserAuthorities();
            for (UserAuthority userAuthority : returnedAuths) {
                if (userAuthority.getIntlAuthorityRole() != null
                    && userAuthority.getIntlAuthorityRole().startsWith("MC_")) {

                    LOG.debug(userAuthority.getIntlAuthorityRole());
                }
            }

        }

        LOG.debug("Test complete.");
    }

    // @Test
    public void testUserAuthEnum() throws InterruptedException {

        IntlAuthorityRole authRole = IntlAuthorityRole.valueOf("MC_TM_OPERATOR");

        assertNotNull(authRole);

        authRole = IntlAuthorityRole.valueOf("MC_TM_EXAMINER");

        assertNotNull(authRole);

        authRole = IntlAuthorityRole.valueOf("MC_TMOB_OPERATOR");

        assertNotNull(authRole);

        authRole = IntlAuthorityRole.valueOf("MC_TMOB_SUPERVISOR");

        assertNotNull(authRole);

        authRole = IntlAuthorityRole.valueOf("MC_TM_SUPERVISOR");

        assertNotNull(authRole);

        try {

            authRole = IntlAuthorityRole.valueOf("MC_TM_BADROLE");

        } catch (Exception e) {

            assertEquals(e.getClass(), IllegalArgumentException.class);
        }

    }

}
