package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.activiti.engine.TaskService;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityCategory;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;
import ca.gc.ised.cipo.tm.madrid.exception.UserAuthorityException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridUserAuthorityService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TUPSUserProfileService;

/**
 * This service uses the TUPS Authorization Service to verify that Users of the
 * Madrid Console have the proper authority to perform MWE Task assignments.
 *
 * The following parameters are common to each method:
 *
 * userId - The user the Task is being assigned to
 *
 * authId - The user performing the assign
 *
 * taskId - The id of the Task involved
 *
 * If a user is assigning a Task to themselves, userId and authId will be the
 * same.
 *
 * @author hamerg
 *
 */
@Service
public class MadridUserAuthorityServiceImpl implements MadridUserAuthorityService {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private TUPSUserProfileService tupsClient;

	@Autowired
	private TaskService taskService;

	// TM Roles
	public final static List<IntlAuthorityRole> TM_MC_INTERNATIONAL_ROLES = new ArrayList<IntlAuthorityRole>(
			Arrays.asList(IntlAuthorityRole.MC_TM_EXAMINER, IntlAuthorityRole.MC_TM_OPERATOR,
					IntlAuthorityRole.MC_TM_SUPERVISOR));

	// TMOB ROles
	public final static List<IntlAuthorityRole> TMOB_MC_INTERNATIONAL_ROLES = new ArrayList<IntlAuthorityRole>(
			Arrays.asList(IntlAuthorityRole.MC_TMOB_OPERATOR, IntlAuthorityRole.MC_TMOB_SUPERVISOR));

	/** {@inheritDoc} */
	@Override
	public Boolean verifyAssignAuthority(String authId, String taskId, String userId) throws UserAuthorityException {

		Boolean verified = false;

		// String assignedUserId = this.getAssignedUserForTask(taskId);
		IntlAuthorityRole assignedTaskRole = this.getAssignedGroupForTask(taskId);
		List<IntlAuthorityRole> userRoles = this.getMCUserRoles(userId);
		List<IntlAuthorityRole> authRoles = this.getMCUserRoles(authId);

		// This is a Task being assigned to a Supervisor.
		if (userRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)
				|| userRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

			// Only TM supervisors can assign to TM supervisors
			if (userRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)
					&& !authRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg(
						"User(" + authId + ") is not a TM Supervisor and cannot assign Tasks to User(" + userId + ").");

				throw ex;

				// Only TMOB supervisors can assign to TM supervisors
			} else if (userRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)
					&& !authRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") is not a TMOB Supervisor and cannot assign Tasks to User(" + userId
						+ ").");

				throw ex;

				// TM Tasks can only be assigned by a TM_SUPERVISOR
			} else if (TM_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !authRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") does not have required Role(" + IntlAuthorityRole.MC_TM_SUPERVISOR
						+ ") to assign Task(" + taskId + ")");

				throw ex;

				// TMOB Tasks can only be assigned by a TMOB_SUPERVISOR
			} else if (TMOB_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !authRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") does not have required Role("
						+ IntlAuthorityRole.MC_TMOB_SUPERVISOR + ") to assign Task(" + taskId + ")");

				throw ex;

			}

			// Does the user have the Role assigned to the Task?
		} else if (!userRoles.contains(assignedTaskRole)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + userId + ") does not have required Role(" + assignedTaskRole + ") for Task("
					+ taskId + ")");

			throw ex;

			// This is a supervisor assigning a Task to a user. Verify TM/TMOB
			// is consistent.
		} else if (!userId.equals(authId)) {

			if (TM_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !authRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") does not have required Role(" + IntlAuthorityRole.MC_TM_SUPERVISOR
						+ ") to assign Task(" + taskId + ")");

				throw ex;

			} else if (TMOB_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !authRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") does not have required Role("
						+ IntlAuthorityRole.MC_TMOB_SUPERVISOR + ") to assign Task(" + taskId + ")");

				throw ex;

			}

		} else {
			verified = true;
		}

		return verified;
	}

	/** {@inheritDoc} */
	@Override
	public Boolean verifyUnassignAuthority(String authId, String taskId) throws UserAuthorityException {

		Boolean verified = false;

		String assignedUserId = this.getAssignedUserForTask(taskId);
		IntlAuthorityRole assignedTaskRole = this.getAssignedGroupForTask(taskId);
		List<IntlAuthorityRole> authRoles = this.getMCUserRoles(authId);

		// If nobody is currently assigned the task, or the task is assigned to
		// the user, it's OK
		if (assignedUserId == null || assignedUserId.equals(authId)) {

			verified = true;

			// This is a user un-assigning a task NOT assigned to them... it
			// better be a supervisor.
		} else if (!assignedUserId.equals(authId)) {

			// Verify this is a Supervisor
			if (!authRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)
					&& !authRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") is not assigned Task(" + taskId
						+ ") and therefore must be a Supervisor to unassign it.");

				throw ex;

				// TM Supervisor can only assign TM Tasks
			} else if (TM_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !authRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") does not have required Role(" + IntlAuthorityRole.MC_TM_SUPERVISOR
						+ ") to unassign Task(" + taskId + ")");

				throw ex;

				// TMOB Supervisor can only assign TMOB Tasks
			} else if (TMOB_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !authRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.AUTHORITY_AUTH_ERROR);
				ex.setErrorMsg("User(" + authId + ") does not have required Role("
						+ IntlAuthorityRole.MC_TMOB_SUPERVISOR + ") to unassign Task(" + taskId + ")");

				throw ex;
			}

		}

		return verified;
	}

	/** {@inheritDoc} */
	@Override
	public Boolean verifyReassignTaskGroup(String authId, String taskId, String groupId) throws UserAuthorityException {

		Boolean verified = false;

		IntlAuthorityRole assignedTaskRole = this.getAssignedGroupForTask(taskId);
		List<IntlAuthorityRole> userRoles = this.getMCUserRoles(authId);

		// Only supervisors can perform this.
		if (!userRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)
				&& !userRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

			String requiredSupRole = "MC_TM_SUPERVISOR";
			if (TMOB_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)) {
				requiredSupRole = "MC_TMOB_SUPERVISOR";
			}

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + authId + ") does not have required Role(" + requiredSupRole
					+ ") to reassign the Group for Task(" + taskId + ")");

			throw ex;

			// The group assignment must be for an existing TM/TMOB Role.
		} else if (!TM_MC_INTERNATIONAL_ROLES.contains(groupId) && !TMOB_MC_INTERNATIONAL_ROLES.contains(groupId)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + authId + ") does not have required Role(" + assignedTaskRole
					+ ") to reassign the Group for Task(" + taskId + ")");

			throw ex;

			// TM Supervisor can only reassign TM Tasks
		} else if (TM_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
				&& !userRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + authId + ") does not have required Role(" + assignedTaskRole
					+ ") to reassign the Group for Task(" + taskId + ")");

			throw ex;

			// TMOB Supervisor can only reassign TMOB Tasks
		} else if (TMOB_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
				&& !userRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + authId + ") does not have required Role(" + assignedTaskRole
					+ ") to reassign the Group for Task(" + taskId + ")");

			throw ex;

		} else {
			verified = true;
		}

		return verified;
	}

	/** {@inheritDoc} */
	@Override
	public Boolean verifyTaskCompletionAuthority(String taskId, String userId) throws UserAuthorityException {

		Boolean verified = false;

		String assignedUserId = this.getAssignedUserForTask(taskId);
		IntlAuthorityRole assignedTaskRole = this.getAssignedGroupForTask(taskId);
		List<IntlAuthorityRole> userRoles = this.getMCUserRoles(userId);

		// Is the task already assigned?
		if (assignedUserId == null) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.TASK_CONFIG_ERROR);
			ex.setErrorMsg("Task(" + taskId + ") is not assigned to a User");

			throw ex;

			// Is the user assigned this task?
		} else if (!assignedUserId.equals(userId)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + userId + ") is not assigned this Task(" + taskId + ")");

			throw ex;

			// Is the User a member of the assigned group? They SHOULD be. This
			// probably means the user's group assignment was changed after they
			// were assigned the task.
		} else if (!userRoles.contains(assignedTaskRole)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + assignedUserId + ") does not have required Role(" + assignedTaskRole
					+ ") to complete Task(" + taskId + ")");

			throw ex;

		} else {
			verified = true;
		}

		return verified;
	}

	/** {@inheritDoc} */
	@Override
	public Boolean verifyAckNotificationAuthority(String taskId, String userId) throws UserAuthorityException {

		Boolean verified = false;

		IntlAuthorityRole assignedTaskRole = this.getAssignedGroupForTask(taskId);
		List<IntlAuthorityRole> userRoles = this.getMCUserRoles(userId);

		// Is this a Supervisor?
		if (userRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)
				|| userRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

			// TM Supervisor can only assign TM Tasks
			if (TM_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !userRoles.contains(IntlAuthorityRole.MC_TM_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
				ex.setErrorMsg("User(" + userId + ") does not have required Role(" + assignedTaskRole
						+ ") to acknowledge Notification Task(" + taskId + ")");

				throw ex;

				// TMOB Supervisor can only assign TMOB Tasks
			} else if (TMOB_MC_INTERNATIONAL_ROLES.contains(assignedTaskRole)
					&& !userRoles.contains(IntlAuthorityRole.MC_TMOB_SUPERVISOR)) {

				UserAuthorityException ex = new UserAuthorityException();
				ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
				ex.setErrorMsg("User(" + userId + ") does not have required Role(" + assignedTaskRole
						+ ") to acknowledge Notification Task(" + taskId + ")");

				throw ex;
			}

			// Make sure non-Supervisors have the correct Role
		} else if (!userRoles.contains(assignedTaskRole)) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
			ex.setErrorMsg("User(" + userId + ") does not have required Role(" + assignedTaskRole
					+ ") to acknowledge Notification Task(" + taskId + ")");

			throw ex;

		} else {
			verified = true;
		}

		return verified;
	}

	/**
	 *
	 * @param taskId
	 * @return
	 */
	private IntlAuthorityRole getAssignedGroupForTask(String taskId) throws UserAuthorityException {

		IntlAuthorityRole authRole = null;

		// We check that the
		Task task = this.taskService.createTaskQuery().taskId(taskId).singleResult();

		if (task == null) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.TASK_CONFIG_ERROR);
			ex.setErrorMsg("Task(" + taskId + ") does not exist");

			throw ex;
		}

		List<IdentityLink> identityLinks = new ArrayList<IdentityLink>();

		try {

			List<IdentityLink> foundIdLinks = this.taskService.getIdentityLinksForTask(taskId);

			// We only want the candidate group id.
			for (IdentityLink identityLink : foundIdLinks) {

				if (identityLink.getType().equals(IdentityLinkType.CANDIDATE)) {
					identityLinks.add(identityLink);
				}

			}

		} catch (NullPointerException e) {
			// There is a bug in the taskService where it throws a NPE if the
			// Task doesn't exist.
		}

		// Set the role based on the groupId
		try {

			if (identityLinks.size() > 0) {
				authRole = IntlAuthorityRole.valueOf(identityLinks.get(0).getGroupId());
			}

		} catch (Exception e) {

			LOG.error("Error: " + e.getMessage());

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.TASK_CONFIG_ERROR);
			ex.setErrorMsg("Task(" + taskId + ") has groupId(" + identityLinks.get(0).getGroupId()
					+ ") that is not an IntlAuthorityRole enum");

			throw ex;
		}

		return authRole;
	}

	/**
	 *
	 * @param taskId
	 * @return
	 * @throws UserAuthorityException
	 */
	private String getAssignedUserForTask(String taskId) throws UserAuthorityException {

		String userId = null;

		// We check that the
		Task task = this.taskService.createTaskQuery().taskId(taskId).singleResult();

		if (task == null) {

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.TASK_CONFIG_ERROR);
			ex.setErrorMsg("Task(" + taskId + ") does not exist");

			throw ex;

		}

		userId = task.getAssignee();

		return userId;
	}

	/**
	 *
	 * @param userId
	 * @return
	 */
	private List<IntlAuthorityRole> getMCUserRoles(String userId) throws UserAuthorityException {

		List<IntlAuthorityRole> authorities = new ArrayList<IntlAuthorityRole>();

		UserProfileType req = new UserProfileType();
		req.setAuthorityId(userId);
		req.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.toString());

		UserProfile res = null;

		try {

			HeartbeatResponseType r = tupsClient.getHeartbeat();

			res = tupsClient.getUserProfile(req);

		} catch (CIPOServiceFault e) {

			LOG.error(e.getMessage());

			UserAuthorityException ex = new UserAuthorityException();
			ex.setErrorType(UserAuthorityException.AUTH_SERVER_UNAVAILABLE);
			ex.setErrorMsg(e.getMessage());

			throw ex;
		}

		List<UserAuthority> returnedAuths = res.getUserAuthorities();

		for (UserAuthority userAuthority : returnedAuths) {

			if (userAuthority.getIntlAuthorityRole() != null) {

				IntlAuthorityRole authRole = null;

				try {

					authRole = IntlAuthorityRole.valueOf(userAuthority.getIntlAuthorityRole());

				} catch (IllegalArgumentException e) {

					LOG.error("Error: " + e.getMessage());

					UserAuthorityException ex = new UserAuthorityException();
					ex.setErrorType(UserAuthorityException.ASSIGNEE_AUTH_ERROR);
					ex.setErrorMsg("User(" + userId + ") has Role(" + userAuthority.getIntlAuthorityRole()
							+ ") that is not an IntlAuthorityRole enum");

					throw ex;
				}

				authorities.add(authRole);
			}

		}

		return authorities;
	}
}
