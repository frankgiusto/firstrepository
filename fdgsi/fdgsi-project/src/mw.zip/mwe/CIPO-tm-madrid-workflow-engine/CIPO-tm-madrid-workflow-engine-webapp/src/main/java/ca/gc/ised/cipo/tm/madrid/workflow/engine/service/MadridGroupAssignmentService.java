package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

public interface MadridGroupAssignmentService {

    String getCandidateGroupForTask( DelegateExecution execution );


    void setCallingProcessVariable( DelegateExecution execution );

}
