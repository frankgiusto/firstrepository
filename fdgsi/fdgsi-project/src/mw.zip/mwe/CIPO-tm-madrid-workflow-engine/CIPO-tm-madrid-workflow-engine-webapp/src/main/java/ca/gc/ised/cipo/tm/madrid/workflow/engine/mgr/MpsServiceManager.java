package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mps.ImportPackage;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.UpdatePackageStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;
import ca.gc.ised.cipo.tm.madrid.workflow.model.SystemInfo;

@Service
public interface MpsServiceManager {

    public BigDecimal processPackage(ImportPackage importPackage, PackageUnit packageUnit)
        throws BpmnWebServiceCallException;

    public PackageStatusEnum getPackageProcessingStatus(BigDecimal packageId, PackageUnit packageUnit)
        throws BpmnWebServiceCallException;

    public BigDecimal exportPackage(String packageLocation) throws BpmnWebServiceCallException;

    public void updatePackageStatus(UpdatePackageStatusType updatePackageStatusType) throws BpmnWebServiceCallException;

    public void updateServiceStatus(SystemInfo systemInfo);

}
