/*
 * Copyright (c) 2018 CIPO Created on May 16, 2018
 */
package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This workflow service is responsible for handling SOAP calls and other process flow requirements when handling Manual
 * Madrid ST.96 transactions.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public interface ManualTransactionService {

    void getPendingManualTransactionCollection(DelegateExecution execution);

    void determineTransactionType(DelegateExecution execution);

}
