package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.SEND_RECONCILED_FEES_TO_FIN_SYSTEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_VERIFICATION_POLL_INTERVAL;

import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionSubmitServiceImpl;
import util.TestUtils;

/**
 * A test class for the {@code send_reconciled_fees_to_financial_system.bpmn} workflow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class SendReconciledFeesToFinancialSystemTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    protected TestFinancialTransactionSubmitServiceImpl testFinancialTransactionSubmitServiceImpl;

    @Before
    public void init() {
        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(null);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(null);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
    public void happyPathTest() {
        System.out.println("#############################################");
        System.out.println("###             happyPathTest             ###");
        System.out.println("#############################################");

        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(SEND_RECONCILED_FEES_TO_FIN_SYSTEM,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "sendReconciledFeesToFinEndEvent", 1);
    }

    /**
     * Be careful with this one. It can cause the tests to run on for a long time depending on the parameters.
     */
    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
    public void longWaitTest() {
        System.out.println("#############################################");
        System.out.println("###             longWaitTest              ###");
        System.out.println("#############################################");

        Integer numberOfLoops = 7;
        Integer pollIntervalInSeconds = 30;

        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(INCOMPLETE);
        testFinancialTransactionSubmitServiceImpl.setNumberOfLoops(numberOfLoops);

        Map<String, Object> paramMap = getParameterMap();
        paramMap.put(UPLOAD_VERIFICATION_POLL_INTERVAL, "PT" + pollIntervalInSeconds + "S");
        ProcessInstance testInstance = TestUtils.startProcessInstance(SEND_RECONCILED_FEES_TO_FIN_SYSTEM,
            runtimeService, paramMap);

        Long maxWait = (numberOfLoops * 1000L * 60L) * 10;
        Long pollIntervalInMilliseconds = pollIntervalInSeconds * 1000L;

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, maxWait, pollIntervalInMilliseconds);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "sendReconciledFeesToFinEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
    public void txReqErrorTest() {
        System.out.println("#############################################");
        System.out.println("###             txReqErrorTest            ###");
        System.out.println("#############################################");

        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(ERROR);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(SEND_RECONCILED_FEES_TO_FIN_SYSTEM,
            runtimeService, getParameterMap());

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "sendReconciledFeesToFinEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTimerCatchEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "updateDropStatusTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
    public void verifyIncompleteTest() {
        System.out.println("#############################################");
        System.out.println("###         verifyIncompleteTest          ###");
        System.out.println("#############################################");

        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(INCOMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(SEND_RECONCILED_FEES_TO_FIN_SYSTEM,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "sendReconciledFeesToFinEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "updateDropStatusTask", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
    public void verifyErrorTest() {
        System.out.println("#############################################");
        System.out.println("###            verifyErrorTest            ###");
        System.out.println("#############################################");

        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(SEND_RECONCILED_FEES_TO_FIN_SYSTEM,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "sendReconciledFeesToFinEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "updateDropStatusTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "movePackageToFailFolder", 1);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/send_reconciled_fees_to_financial_system.bpmn"})
    public void updateDropStatusErrorTest() {
        System.out.println("#############################################");
        System.out.println("###       updateDropStatusErrorTest       ###");
        System.out.println("#############################################");

        testFinancialTransactionSubmitServiceImpl.setFinFileUploadRequestStatus(COMPLETE);
        testFinancialTransactionSubmitServiceImpl.setUpdateFeeDropStatusReturnObject(ERROR);
        testFinancialTransactionSubmitServiceImpl.setVerifyFinFileUploadStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(SEND_RECONCILED_FEES_TO_FIN_SYSTEM,
            runtimeService, getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "sendReconciledFeesToFinEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "verifyPackageTransferTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "updateDropStatusTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    protected Map<String, Object> getParameterMap() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(PACKAGE_ID, "FakePackage01");
        processVariables.put(UPLOAD_VERIFICATION_POLL_INTERVAL, "PT1S");
        return processVariables;
    }
}
