package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * An interface to define the behavior of a service class that will handle business-level process flow errors.
 *
 * @author J. Greene
 *
 */
public interface BusinessErrorHandler {

    /**
     * Handles the process flow errors that may occur.
     *
     * @param execution The Activiti context object that holds information about the current process execution.
     */
    void handleBusinessError(DelegateExecution execution);

    /**
     * A method that should be called whenever an iterative error handling sub-process ends in order to aggregate and
     * send the notification message. This can (and should) be used as an Activiti event listener.
     *
     * @param execution The Activiti context object that holds information about the current process execution.
     */
    void cumulativeErrorMessageListener(DelegateExecution execution);

}
