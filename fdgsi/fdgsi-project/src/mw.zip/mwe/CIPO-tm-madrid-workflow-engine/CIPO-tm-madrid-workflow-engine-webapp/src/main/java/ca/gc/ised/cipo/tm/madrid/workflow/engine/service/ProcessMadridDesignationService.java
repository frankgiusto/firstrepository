package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.impl.pvm.delegate.ActivityExecution;

/**
 * Interface for ProcessMadridDesignationService
 *
 * @author sagary
 *
 */
public interface ProcessMadridDesignationService {

    /**
     * Process Madrid Designation. Makes a web service call to MTS.
     *
     * @param delegateExecution ActivityExecution
     */
    public void processMaridDesignation(ActivityExecution delegateExecution) throws Exception;

}
