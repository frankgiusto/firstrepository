package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import ca.gc.ic.cipo.mail.SimpleMailSender;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorHandler;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Handles business errors.
 *
 * @author J. Greene
 *
 */
public class BusinessErrorHandlerImpl implements BusinessErrorHandler {

    protected static final Logger LOG = LoggerFactory.getLogger(BusinessErrorHandler.class);

    @Autowired
    SimpleMailSender mailSender;

    @Autowired
    RepositoryService repositoryService;

    @Autowired
    BusinessErrorLogService businessErrorLogService;

    @Autowired
    protected RuntimeService runtimeService;

    @Value("${mwe.business.error.email.sender}")
    private String emailSenderString;

    @Value("${mwe.business.error.email.recipients}")
    private String[] emailRecipients;

    /**
     * {@inheritDoc}
     * <p>
     * This method will handle errors in the process flow that are severe enough to terminate the flow entirely.
     * Examples of severe errors include;
     * <ul>
     * <li>Call to service operation fails</li>
     * <li>IO exceptions when manipulating files</li>
     * <li>Web service operation returns a severe error code</li>
     * </ul>
     * </p>
     * <p>
     * Errors are logged in the application log as well as the MWE database. An email message is sent to members of the
     * development/maintenance team (configurable) with the details of the error as well.
     * </p>
     */
    @Override
    public void handleBusinessError(DelegateExecution execution) {

        // Used mostly for subprocess and call execution
        execution.setVariable(SUBPROCESS_STATUS_VAR, ERROR);

        ProcessDefinition processDefinition = repositoryService
            .getProcessDefinition(execution.getProcessDefinitionId());

        // Fetch the business error item
        BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
            BusinessErrorLogItem.class);

        // Create the readable message string for CIPO service faults
        if (businessErrorLogItem.isCipoServiceFaultOrigin()) {
            String messageString = getDescriptiveMessageStringFromErroLogItem(businessErrorLogItem);
            if (businessErrorLogItem.getMessage() == null) {
                businessErrorLogItem.setMessage(messageString);
            } else {
                businessErrorLogItem.setMessage(messageString + SystemUtils.LINE_SEPARATOR + SystemUtils.LINE_SEPARATOR
                    + businessErrorLogItem.getMessage());
            }
        }

        // Log the business error
        businessErrorLogItem.setProcessDefinitionName(processDefinition.getName());
        businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
        logBusinessError(businessErrorLogItem);

        StringBuilder logMessage = getErrorMessageHeader(businessErrorLogItem,
            "A business process error was caught by the workflow engine:");
        logMessage.append("\tMessage:\t\t");
        logMessage.append(businessErrorLogItem.getMessage() == null ? "none" : businessErrorLogItem.getMessage());
        logMessage.append(SystemUtils.LINE_SEPARATOR);

        LOG.error(logMessage.toString());

        // Email the error message too.
        sendErrorMessageEmail(processDefinition.getName(), logMessage.toString());

    }

    /**
     * {@inheritDoc}
     * <p>
     * Checks the cardinality of the multi-instance task to determine completeness by using Activiti's own variables.
     * </p>
     */
    @Override
    public void cumulativeErrorMessageListener(DelegateExecution execution) {
        Integer nrOfInstances = execution.getVariableLocal(NR_OF_INSTANCES, Integer.class);
        Integer loopCounter = execution.getVariableLocal(LOOP_COUNTER, Integer.class);

        if (nrOfInstances.equals(loopCounter)) {
            LOG.trace("Multi-instance task has completed all " + nrOfInstances + " iterations.");
            createAndSendCumulativeErrorMessage(execution);
        } else {
            LOG.trace("Multi-instance task has NOT completed.  Count " + (loopCounter + 1) + " of " + nrOfInstances);
        }
    }

    /*
     * Creates the cumulative error message (if exists) and sends it to the specified email account(s) after completion
     * of a multi-instance task. The onus of determining multi-instance task completion is outside of the scope of this
     * method.
     *
     * For an example of a listener that determines the end of a multi-instance task, see {@link
     * BusinessErrorHandler#cumulativeErrorMessageListener(DelegateExecution)}.
     */
    protected void createAndSendCumulativeErrorMessage(DelegateExecution execution) {
        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);

        if (runningErrorMessageList != null && !runningErrorMessageList.isEmpty()) {
            // For the financial gap report sub-flow
            execution.setVariable(BYPASS_GAP_REPORT_NOTIFICATION, true);

            StringBuilder runningErrorMessage = new StringBuilder();
            for (String msg : runningErrorMessageList) {
                runningErrorMessage.append(msg);
            }
            BusinessErrorLogItem cumulativeBusinessErrorLogItem = createGenericMweBusinessErrorLogItem(
                runningErrorMessage.toString());
            ProcessDefinition processDefinition = repositoryService
                .getProcessDefinition(execution.getProcessDefinitionId());

            // Log the business error
            cumulativeBusinessErrorLogItem.setProcessDefinitionName(processDefinition.getName());
            cumulativeBusinessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
            String unalteredMessage = cumulativeBusinessErrorLogItem.getMessage();
            logBusinessError(cumulativeBusinessErrorLogItem);

            StringBuilder logMessage = getErrorMessageHeader(cumulativeBusinessErrorLogItem,
                "One or more business errors were caught by the workflow engine during an iterative process:");
            logMessage.append("Message(s):\n\n");
            logMessage.append(SystemUtils.LINE_SEPARATOR);
            logMessage.append(unalteredMessage);
            logMessage.append(SystemUtils.LINE_SEPARATOR);

            LOG.debug(logMessage.toString());

            // Email the error message too.
            sendErrorMessageEmail(processDefinition.getName(), logMessage.toString());

            // Clear the running error message
            execution.setVariable(RUNNING_ERROR_MESSAGE, null);
        }
    }

    /*
     * Handles the building of a cumulative business error message. This type of message can occur when iterative
     * processing throws business errors that do not warrant the termination of the workflow process instance. Instead,
     * messages are accumulated and handled at the end of the iteration cycle.
     *
     * Assumes the error log item originates from a CIPO service fault.
     */
    protected void handleCumulativeError(DelegateExecution execution, String identifierLine) {
        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
        if (runningErrorMessageList == null) {
            runningErrorMessageList = new ArrayList<>();
        }
        StringBuilder runningMessageBuilder = new StringBuilder();

        BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
            BusinessErrorLogItem.class);

        if (StringUtils.isNotBlank(identifierLine)) {
            LOG.debug("Adding to a running error message : " + identifierLine);
            runningMessageBuilder.append("*************************************************");
            runningMessageBuilder.append(SystemUtils.LINE_SEPARATOR);
            runningMessageBuilder.append(identifierLine);
            runningMessageBuilder.append(SystemUtils.LINE_SEPARATOR);
            runningMessageBuilder.append("*************************************************");
            runningMessageBuilder.append(SystemUtils.LINE_SEPARATOR);
            runningMessageBuilder.append(SystemUtils.LINE_SEPARATOR);
        }
        runningMessageBuilder.append(getDescriptiveMessageStringFromErroLogItem(businessErrorLogItem));
        runningMessageBuilder.append(SystemUtils.LINE_SEPARATOR);
        runningMessageBuilder.append(SystemUtils.LINE_SEPARATOR);

        runningErrorMessageList.add(runningMessageBuilder.toString());

        execution.setVariable(RUNNING_ERROR_MESSAGE, runningErrorMessageList);
    }

    protected void logBusinessError(BusinessErrorLogItem businessErrorLogItem) {
        businessErrorLogService.insertBusinessErrorLogEntry(businessErrorLogItem);
    }

    /*
     * The header of the email message that describes the process that threw the error
     */
    protected StringBuilder getErrorMessageHeader(BusinessErrorLogItem businessErrorLogItem, String seedMessage) {
        StringBuilder logMessage = new StringBuilder(seedMessage);
        logMessage.append(SystemUtils.LINE_SEPARATOR);
        logMessage.append(SystemUtils.LINE_SEPARATOR);
        logMessage.append("\tProcess Instance ID:\t[");
        logMessage.append(businessErrorLogItem.getProcessInstanceId());
        logMessage.append("]");
        logMessage.append(SystemUtils.LINE_SEPARATOR);
        logMessage.append("\tProcess Definition:\t[");
        logMessage.append(businessErrorLogItem.getProcessDefinitionName());
        logMessage.append("]");
        logMessage.append(SystemUtils.LINE_SEPARATOR);
        logMessage.append(SystemUtils.LINE_SEPARATOR);

        return logMessage;
    }

    /*
     * Send the message with a standard subject and recipients
     */
    protected void sendErrorMessageEmail(String processDefinitionName, String messageString) {
        String subject = "Madrid Workflow Engine - Error in " + processDefinitionName;

        mailSender.send(emailSenderString, emailRecipients, subject, messageString);
    }

    /*
     * Registers a {@code BusinessErrorLogItem} in the current execution to contain issues that arise from the HWE code.
     */
    protected void registerGenericMweBusinessError(DelegateExecution execution, String message) {
        registerGenericMweBusinessError(execution, message, null);
    }

    /*
     * Registers a {@code BusinessErrorLogItem} in the current execution to contain issues that arise from the HWE code.
     */
    protected void registerGenericMweBusinessError(DelegateExecution execution, String message, Throwable t) {
        BusinessErrorLogItem businessErrorLogItem = createGenericMweBusinessErrorLogItem(message);
        if (t != null) {
            businessErrorLogItem.setErrorMessageEn(t.getMessage());
        }
        execution.setVariable(ERR_MSG_OBJECT_VAR, businessErrorLogItem);
    }

    protected BusinessErrorLogItem createGenericMweBusinessErrorLogItem(String message) {
        BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem(message);
        businessErrorLogItem.setComponentAcronym(MWE);
        businessErrorLogItem.setServiceName(MWE_SERVICE_NAME);
        return businessErrorLogItem;
    }

    protected String getDescriptiveMessageStringFromErroLogItem(BusinessErrorLogItem businessErrorLogItem) {
        String messageString = null;
        // Create the readable message string for CIPO service faults
        if (businessErrorLogItem.isCipoServiceFaultOrigin()) {
         // @formatter:off
             messageString = String.format(MweWorkflowUtil.getBaseMailStringBuilder().toString(),
                businessErrorLogItem.getComponentAcronym(),
                businessErrorLogItem.getServiceName(),
                businessErrorLogItem.getReturnCode(),
                businessErrorLogItem.getReasonCode(),
                businessErrorLogItem.getErrorMessageEn(),
                businessErrorLogItem.getErrorMessageFr());
         // @formatter:on
        } else {
            messageString = businessErrorLogItem.getMessage();
        }
        return messageString;
    }

}
