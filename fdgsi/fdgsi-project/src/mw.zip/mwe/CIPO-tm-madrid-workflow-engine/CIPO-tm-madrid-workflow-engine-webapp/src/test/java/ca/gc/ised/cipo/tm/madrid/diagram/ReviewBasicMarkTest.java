package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import util.TestMadridMethodVarsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class ReviewBasicMarkTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private TaskService taskService;

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Autowired
	@Rule
	public ActivitiRule activitiSpringRule;

	private ProcessInstance startProcessInstance(Map<String, Object> processVars) {

		return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("reviewBasicMarks", processVars);
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateNotificationTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/CR41_ReviewBasicMark.bpmn" })
	public void testDiagram() throws InterruptedException {

		LOG.debug("BPMN Test (reviewBasicMark) happy path started.");

		this.methodVarsService.reset();

		Map<String, Object> processVars = new HashMap<String, Object>();
		processVars.put("irTranId", "12345");

		// Start the process.
		ProcessInstance processInstance = startProcessInstance(processVars);
		String processId = processInstance.getId();

		LOG.debug("Waiting for UserTask completion... ");
		Thread.sleep(1000);

		// The task is created within the CreateConsoleTask sub-process... get
		// it's ID
		ProcessInstance subProcessInstance = runtimeService.createProcessInstanceQuery()
				.superProcessInstanceId(processId).singleResult();

		assertNotNull(subProcessInstance);

		// Fetch the created Task
		Task task = processEngine.getTaskService().createTaskQuery().processInstanceId(subProcessInstance.getId())
				.singleResult();

		assertNotNull(task);

		// Fetch the assigned group
		String groupId = null;

		List<IdentityLink> taskIdenLinks = taskService.getIdentityLinksForTask(task.getId());
		if (taskIdenLinks != null && !taskIdenLinks.isEmpty()) {
			groupId = taskIdenLinks.get(0).getGroupId();
		}

		assertEquals(groupId, "MC_TM_SUPERVISOR");

		this.taskService.complete(task.getId());

		// WIth the Task completed, it should no longer come back in searches
		task = this.taskService.createTaskQuery().taskId(task.getId()).singleResult();

		assertNull(task);

		// With the Task completed, the process should be complete
		processInstance = this.runtimeService.createProcessInstanceQuery().processInstanceId(processId).singleResult();

		assertNull(processInstance);

		LOG.debug("Test complete.");
	}

}
