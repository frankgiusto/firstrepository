package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FEE_STATUS_UPDATE_INDICATOR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FEE_STATUS_UPDATE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FETCH_FIN_SYSTEM_PACKAGE_TRANSACTION_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_STATUS_UPDATE_TRANSACTION_DETAIL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_STATUS_UPDATE_TRANSACTION_DETAIL_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.SERVICE_FAULT_SEVERITY_THRESHOLD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPDATE_FEE_STATUS_STATUS;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.UpdatePackageStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionUpdateFeeStatusService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Service class for the processing of financial feedback transaction items subprocess call activity of the financial
 * flow.
 *
 * @author J. Greene
 * @see FinancialTransactionReconcileServiceImpl
 */
@Service
public class FinancialTransactionUpdateFeeStatusServiceImpl extends BusinessErrorHandlerImpl
    implements FinancialTransactionUpdateFeeStatusService, Serializable {

    private static final long serialVersionUID = -4007764888137478180L;

    @Autowired
    MtsServiceManager mtsServiceManager;

    @Autowired
    MpsServiceManager mpsServiceManager;

    @Autowired
    MfsServiceManager mfsServiceManager;

    /**
     * {@inheritDoc}
     * <p>
     * Calls a service operation to get a collection of transaction details related to unprocessed CIPO financial
     * feedback transactions. The call activity variable {@code finStatusUpdateTransactionDetailList} will contain the
     * results. The status variable {@code fetchFinSystemPackageTransactionsStatus} will be populated accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an error occurred<br/>
     * </p>
     */
    @Override
    public void getUpdatedFinancialTransactions(DelegateExecution execution) {
        Integer fetchFinSystemPackageTransactionsStatus = COMPLETE;
        BigDecimal packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);
        try {
            TransactionCriteria transactionCriteria = new TransactionCriteria();
            // TODO Put it back when we figure out the right value
            // transactionCriteria.getStatusCodeList().add(TransactionStatusType.MADRID_FEE_TRANS_IMPORTED);
            transactionCriteria.getPackageIdList().add(packageId);

            List<TransactionDetail> transactionDetails = mtsServiceManager.getTransactionList(transactionCriteria);
            execution.setVariable(FIN_STATUS_UPDATE_TRANSACTION_DETAIL_LIST, transactionDetails);
            if (transactionDetails == null || transactionDetails.isEmpty()) {
                execution.setVariable(FEE_STATUS_UPDATE_INDICATOR, Boolean.FALSE);
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            fetchFinSystemPackageTransactionsStatus = ERROR;
        }

        execution.setVariable(FETCH_FIN_SYSTEM_PACKAGE_TRANSACTION_STATUS, fetchFinSystemPackageTransactionsStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Calls an operation to update the financial data with the feedback transaction specifics. The flow variable
     * {@code updateFeeStatusStatus} will be set accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an error occurred<br/>
     * </p>
     */
    @Override
    public void updateReconciledFeeTransaction(DelegateExecution execution) {
        Integer updateFeeStatusStatus = COMPLETE;
        TransactionDetail txDetail = execution.getVariableLocal(FIN_STATUS_UPDATE_TRANSACTION_DETAIL,
            TransactionDetail.class);

        try {
            mfsServiceManager.updateApplicationsFinancialStatus(txDetail.getTransactionId());
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            updateFeeStatusStatus = ERROR;
        }

        execution.setVariableLocal(UPDATE_FEE_STATUS_STATUS, updateFeeStatusStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Handles the iterative error that may occur while processing individual transactions. Evaluate the severity to
     * alter course of action appropriately.
     * </p>
     */
    @Override
    public void handleIterativeError(DelegateExecution execution) {
        Integer recoverableErrorCondition = COMPLETE;
        execution.setVariable(FEE_STATUS_UPDATE_INDICATOR, Boolean.FALSE);

        BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
            BusinessErrorLogItem.class);
        TransactionDetail txDetail = execution.getVariableLocal(FIN_STATUS_UPDATE_TRANSACTION_DETAIL,
            TransactionDetail.class);

        if (!businessErrorLogItem.isCipoServiceFaultOrigin()) {
            recoverableErrorCondition = ERROR;
        } else {
            // Check the fault return code. If it falls below the threshold, assume not recoverable.
            if (businessErrorLogItem.getReturnCode() <= SERVICE_FAULT_SEVERITY_THRESHOLD) {
                recoverableErrorCondition = ERROR;
                LOG.error("A non-recoverable error occurred while processing transaction # ["
                    + txDetail.getTransactionId() + "]");
            } else {
                handleCumulativeError(execution, "TRANSACTION ID: " + txDetail.getTransactionId());
            }
        }

        execution.setVariable(RECOVERABLE_ERROR_CONDITION, recoverableErrorCondition);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Updates the package status after successful fee status update process. Sets the process flow variable
     * {@code feeStatusUpdateStatus} accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an error occurred<br/>
     * </p>
     */
    @Override
    public void updatePkgStatusPostFeeUpdate(DelegateExecution execution) {
        Integer feeStatusUpdateStatus = COMPLETE;
        BigDecimal packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);

        UpdatePackageStatusType pkgUpdateType = new UpdatePackageStatusType();

        pkgUpdateType.setPackageId(packageId);
        pkgUpdateType.setPackageStatusType(PackageStatusEnum.MADRID_FEE_PKG_FIN_STATUS_UPDATED);

        try {
            mpsServiceManager.updatePackageStatus(pkgUpdateType);
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            feeStatusUpdateStatus = ERROR;
        }
        execution.setVariable(FEE_STATUS_UPDATE_STATUS, feeStatusUpdateStatus);
    }

}
