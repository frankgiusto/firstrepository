package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;

import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.model.OperationCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestXsd;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * A transfer request strategy for downloading the updated fee data from the internal financial system.
 *
 * @author J. Greene
 *
 */
public class InFinFeesTransferRequestCreator {

    /**
     * Creates a {@code CreateTransferRequest} object for the service operation call to DTF for an incoming package from
     * the financial system.
     *
     * @param execution The execution metadata related to the BPMN process execution
     * @return a {@code CreateTransferRequest} object representing the transfer request.
     */
    public CreateTransferRequest createOutgoingTransferRequest(DelegateExecution execution) {

        CreateTransferRequest request = new CreateTransferRequest();
        TransferRequestXsd transferRequest = new TransferRequestXsd();
        request.setTransferRequest(transferRequest);

        String dtfSite = MweWorkflowUtil.getRequiredConfigurationProperty("hwe.dtf.hague.site.name.cipo.finance");

        request.getTransferRequest().setExternalSiteAcronym(dtfSite);
        request.getTransferRequest().setTransferItemAcronym(ProcessFlowConstants.IN_FINANCE_FEES);
        request.getTransferRequest().setOperationCode(OperationCode.INBOUND.codeValue());
        request.getTransferRequest().setRequestor(ProcessFlowConstants.MWE);
        request.getTransferRequest().setNote("Activiti process instance: " + execution.getProcessInstanceId());
        request.setRacfUser(MweWorkflowUtil.getRacfUser());

        // Transfer request parameters
        setParamCollection(request.getTransferRequest().getParameters(), execution, null);

        return request;
    }

    protected void setParamCollection(List<TransferRequestParamXsd> paramList, DelegateExecution execution,
                                      DownloadLogItem lastDownloadLogItem) {

        String remoteDir = MweWorkflowUtil.getRequiredConfigurationProperty("hwe.dtf.internal.finance.ftp.dir");

        TransferRequestParamXsd remoteDirParam = new TransferRequestParamXsd();
        remoteDirParam.setParameterCode(ParamNameCode.REMOTE_DIR.codeValue());
        remoteDirParam.setParameterValue(remoteDir);
        paramList.add(remoteDirParam);

        String fileNameRegex = execution.getVariable(ProcessFlowConstants.FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX,
            String.class);

        TransferRequestParamXsd fileRegexParam = new TransferRequestParamXsd();
        fileRegexParam.setParameterCode(ParamNameCode.FILE_REGEX.codeValue());
        fileRegexParam.setParameterValue(fileNameRegex);
        paramList.add(fileRegexParam);
    }

}
