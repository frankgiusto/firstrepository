package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.BusinessErrorHandlerImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import util.TestMadridMethodVarsService;

public class TestMadridDelegateServiceImpl extends BusinessErrorHandlerImpl implements MadridDelegateService {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Value("${application.acronym}")
	private String serviceName;

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Override
	public void checkForExistingMarks(DelegateExecution execution) throws BpmnError {

		// Initially set the 'markExists' var to 'true'.
		execution.setVariable(ProcessFlowConstants.MARK_EXISTS_VAR, true);

		// This will set variables assigned in the test method.
		Map<String, Object> methodVars = methodVarsService.getMethodVars();
		this.assignTestVars(execution, methodVars);

		if (methodVars != null) {

			Boolean throwError = (Boolean) methodVars.get(ProcessFlowConstants.ERR_MSG_IND_VAR);
			if (throwError != null && throwError == true) {

				BpmnError ex = new BpmnError("madridError", "This is an BpmnError");

				BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem("This is test a BusinessError");
				businessErrorLogItem.setCipoServiceFaultOrigin(true);
				businessErrorLogItem.setServiceName(serviceName);
				businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
				businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

				execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

				throw ex;
			}

		}

	}

	@Override
	public void checkForNotifications(DelegateExecution execution) throws Exception {

		// This will set variables assigned in the test method.
		Map<String, Object> methodVars = methodVarsService.getMethodVars();
		this.assignTestVars(execution, methodVars);

		if (methodVars != null) {

			Boolean throwError = (Boolean) methodVars.get(ProcessFlowConstants.ERR_MSG_IND_VAR);
			if (throwError != null && throwError == true) {

				BpmnError ex = new BpmnError("madridError", "This is an BpmnError");

				BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem("This is test a BusinessError");
				businessErrorLogItem.setCipoServiceFaultOrigin(true);
				businessErrorLogItem.setServiceName(serviceName);
				businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
				businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

				execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

				throw ex;
			}

		}

		// A variable of type collection must be on the flow for the manual
		// tasks

		if (execution.getVariable(ProcessFlowConstants.CONSOLE_TASK_ID_LIST) == null) {

			execution.setVariable(ProcessFlowConstants.CONSOLE_TASK_ID_LIST, new ArrayList<String>(0));

		}
	}

	@Override
	public void handleBusinessError(DelegateExecution execution) {

		Map<String, Object> methodVars = methodVarsService.getMethodVars();
		this.assignTestVars(execution, methodVars);

	}

	@Override
	public void createConsoleTask(DelegateExecution execution) {

		Map<String, Object> methodVars = methodVarsService.getMethodVars();
		this.assignTestVars(execution, methodVars);

		execution.setVariable(ProcessFlowConstants.MTS_ERROR, false);

	}

	@Override
	public void updateConsoleTaskStatus(DelegateExecution execution) {

		Map<String, Object> methodVars = methodVarsService.getMethodVars();
		this.assignTestVars(execution, methodVars);

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void fetchTransactions(DelegateExecution execution) {

		Map<String, Object> methodVars = methodVarsService.getMethodVars();
		this.assignTestVars(execution, methodVars);

	}

	@Override
	public void notifyAdmin(DelegateExecution execution) {

		LOG.debug("Sending email to administrator");

	}

	/**
	 *
	 * @param execution
	 * @param methodVars
	 */
	private void assignTestVars(DelegateExecution execution, Map<String, Object> methodVars) {

		if (methodVars != null) {

			Set<String> keys = methodVars.keySet();
			for (String key : keys) {
				execution.setVariable(key, methodVars.get(key));
			}

		}

	}

}
