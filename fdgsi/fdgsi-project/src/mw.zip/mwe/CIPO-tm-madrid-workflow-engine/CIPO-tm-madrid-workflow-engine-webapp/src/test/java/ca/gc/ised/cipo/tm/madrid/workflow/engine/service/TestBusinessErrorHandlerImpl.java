package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Superclass for delegate execution service classes. This contains some variable assignments necessary for the workflow
 * tests.
 *
 * @author J. Greene
 *
 */
public class TestBusinessErrorHandlerImpl implements BusinessErrorHandler {

    /** {@inheritDoc} */
    @Override
    public void handleBusinessError(DelegateExecution execution) {
        execution.setVariable(SUBPROCESS_STATUS_VAR, ERROR);
        System.out.println("[[handleBursinesError]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void cumulativeErrorMessageListener(DelegateExecution execution) {
        Integer nrOfInstances = execution.getVariableLocal(NR_OF_INSTANCES, Integer.class);
        Integer loopCounter = execution.getVariableLocal(LOOP_COUNTER, Integer.class);

        if (nrOfInstances != null && loopCounter != null && nrOfInstances.equals(loopCounter)) {
            System.out.println("\t[[cumulativeErrorMessageListener]]: Multi-instance task has completed all "
                + nrOfInstances + " iterations.");
            @SuppressWarnings("unchecked")
            List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
            if (runningErrorMessageList == null || runningErrorMessageList.isEmpty()) {
                System.out.println("runningErrorMessageList has no data.");
            } else {
                execution.setVariable(BYPASS_GAP_REPORT_NOTIFICATION, true);
                for (String s : runningErrorMessageList) {
                    System.out.println("\t\t" + s);
                }
                execution.setVariable(RUNNING_ERROR_MESSAGE, null);
            }
        } else {
            System.out.println("\t[[cumulativeErrorMessageListener]]: Multi-instance task has NOT completed.  Count "
                + loopCounter + " of " + nrOfInstances + ".");
        }
    }

}
