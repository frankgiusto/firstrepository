package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.math.BigDecimal;
import java.util.List;

import org.activiti.engine.runtime.ProcessInstance;

import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingMonthlyFinPkgJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingPackageDownloadJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingPackagePersistJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingProcessManualTransJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingMessageJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingMonthlyFinPkgJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingTaskJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.SystemInfo;

/**
 * An interface to describe a service class that will be responsible for stop/start process engine job actions related
 * to the Madrid TM workflow process definitions.
 *
 * @author J. Greene
 *
 */
public interface MweJobService {

    // TODO: Update see references

    /**
     * This service will query the MTS for Manual Transactions in the 'unprocessed' states and create User Tasks
     * required.
     *
     * @param incomingProcessManualTransJob
     * @return
     */
    String processManualTransactions(IncomingProcessManualTransJob incomingProcessManualTransJob);

    /**
     * This service method starts a process flow that will initiate a Data Transfer Service (DTF) operation to download
     * the specified WIPO package, unpack it, persist, then delete package. These operations will all be performed
     * either in situ or by an external service call.
     *
     * @param incomingPackageDownloadJob the import job instructions from the REST call
     * @return IncomingPackageDownloadJob the effective import job instructions after accounting for defaults
     * @see DownloadPackageService
     */
    IncomingPackageDownloadJob downloadIncomingPackage(IncomingPackageDownloadJob incomingPackageDownloadJob);

    /**
     * This service will start the workflow to process any Automated Transactions in the 'ready_for_processing' state.
     *
     * @return the processId assigned by Activiti
     */
    String processAutomatedTransactions();

    /**
     * < * This service method starts a process flow that will call service operations to persist package data that was
     * previously downloaded (see {@link #downloadIncomingPackage(IncomingPackageDownloadJob)}).
     *
     * @param incomingPackagePersistJob the job specific instructions from the REST service call
     * @return IncomingPackagePersistJob the effective job instructions including unspecified default values
     * @see ca.gc.ised.cipo.id.hague.workflow.engine.service.PersistPackageService
     */
    IncomingPackagePersistJob persistIncomingPackage(IncomingPackagePersistJob incomingPackagePersistJob);

    /**
     * This service will start the workflow to process any Automated Transaction Pairs in the 'ready_for_processing'
     * state.
     *
     * @return the processId assigned by Activiti
     */
    String processAutomatedTransactionPairs();

    /**
     * This service method starts a process flow that will call service operations to perform message processing on
     * individual ID related transactions from any package with outstanding transactions to be processed (see
     * {@link #persistIncomingPackage(IncomingPackagePersistJob)} ).
     *
     * @see ca.gc.ised.cipo.TmTransactionService.hague.workflow.engine.service.IdTransactionService
     * @return information about the process instance
     */
    String processIncomingIdTransactions();

    /**
     * This service method starts a process flow that will call service operations to perform message processing on
     * individual financial transactions from an incoming message package that was previously persisted (see
     * {@link #persistIncomingPackage(IncomingPackagePersistJob)} ).
     *
     * @param packageId the package ID containing transactions to process
     * @see ca.gc.ised.cipo.id.hague.workflow.engine.service.FinancialTransactionReconcileService
     * @return information about the process instance
     */
    String processIncomingFinancialTransactions(BigDecimal packageId);

    /**
     * This service method starts a process flow that will call service operations to update fee status transactions
     * from the financial system. It is a call activity of the overall financial transaction workflow. (see
     * {@link #processIncomingFinancialTransactions(BigDecimal)}).
     *
     * @param packageId the package ID containing transactions to process
     * @see ca.gc.ised.cipo.id.hague.workflow.engine.service.FinancialTransactionUpdateFeeStatusService
     * @return information about the process instance
     */
    String processFinancialFeeUpdate(BigDecimal packageId);

    /**
     * This service method creates outgoing message transactions from the back-end system and populates the datastore
     * with the transactions in a format that is ready to package.
     *
     * @return the process instance identifier of the created process instance
     * @see ca.gc.ised.cipo.id.hague.workflow.engine.service.CreateOutgoingTransactionsService
     */
    String createOutgoingMessages();

    /**
     * This service method starts a process flow that will call service operations to package outgoing messages from the
     * back end system en route to WIPO.
     *
     * @param outgoingMessageJob the job specific instructions from the REST service call
     * @return OutgoingPackageAssemblyJob the effective job instructions including unspecified default values
     * @see ca.gc.ised.cipo.id.hague.workflow.engine.service.PackageOutgoingTransactionsService
     */
    OutgoingMessageJob packageOutgoingMessages(OutgoingMessageJob outgoingMessageJob);

    /**
     * This service method starts a process flow that will call service operations to combine and upload outgoing
     * message packages to WIPO.
     *
     * @param outgoingMessageJob the job specific instructions from the REST service call
     * @return OutgoingPackageUploadJob the effective job instructions including unspecified default values
     */
    OutgoingMessageJob uploadOutgoingMessagePackage(OutgoingMessageJob outgoingMessageJob);

    /**
     * This service method will start the call activity for uploading a monthly finance package to the financial system.
     * <em>This is not meant to be run on its own but only under extraordinary circumstances</em> such as re-running a
     * failed process.
     *
     * @param outgoingMonthlyFinPkgJob the job specific instructions for the REST service call
     * @return OutgoingMonthlyFinPkgJob the effective job instructions including unspecified default data
     */
    OutgoingMonthlyFinPkgJob uploadOutgoingMonthlyFinancePackageJob(OutgoingMonthlyFinPkgJob outgoingMonthlyFinPkgJob);

    OutgoingMessageJob createOutgoingManualTask(OutgoingTaskJob outgoingTaskJob);

    /**
     * This service method will start the call activity to download a monthly finance fee update package from the
     * financial system. <em>This is not meant to be run on its own but only under extraordinary circumstances</em>
     *
     * @param incomingMonthlyFinPkgJob the job specific instructions for the REST service call
     * @return IncomingMonthlyFinPkgJob the effective job instructions including unspecified default data
     */
    IncomingMonthlyFinPkgJob downloadIncomingMonthlyFinancePackageJob(IncomingMonthlyFinPkgJob incomingMonthlyFinPkgJob);

    /**
     * A utility service that will gather various system statuses to determine the health of this application.
     *
     * @return an inflated {@code SystemInfo} model object.
     */
    SystemInfo getSystemInfo();

    /**
     * A service method to search for and retrieve download log items meeting the provided criteria.
     *
     * @param xferReqId the transfer request ID to search for
     * @param topX the top XX latest records only
     * @param packageType the transfer type to search for
     * @return the collection of {@code DownloadLogItem}s that match the criteria
     */
    List<DownloadLogItem> getDownloadLogItems(String xferReqId, Integer topX, String packageType);

    /**
     * A service method to search for and retrieve business error log items meeting the provided criteria.
     *
     * @param componentAcronym the service acronym to narrow down the results
     * @param topX topX the top XX latest records only
     * @return the collection of {@code BusinessErrorLogItem}s that match the criteria
     */
    List<BusinessErrorLogItem> getBusinessErrorLogItems(String componentAcronym, Integer topX);

    /**
     * A service method to search for and retrieve process instances that are still running.
     *
     * @param processDefinitionKey the process that we are looking for
     * @return the collection of {@code ProcessInstance}s that match the criteria
     */
    List<ProcessInstance> getOngoingProcessList(String processDefinitionKey);

    /**
     * A service method to delete an ongoing process.
     *
     * @param processInstance the process to remove
     */
    void deleteProcessInstance(ProcessInstance processInstance);
}
