/*
 * Copyright (c) 2018 CIPO Created on May 16, 2018
 */
package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IMPORT_PENDING_TRANSACTION_DETAILS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSACTION_TYPE;

import java.util.List;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.ManualAutoCategoryType;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.ManualTransactionService;

@Service
public class ManualTransactionServiceImpl extends BusinessErrorHandlerImpl implements ManualTransactionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ManualTransactionServiceImpl.class);

    @Autowired
    protected MtsServiceManager mtsServiceManager;

    @Autowired
    private ProcessEngine processEngine;

    /**
     * Constructor.
     */
    public ManualTransactionServiceImpl() {
        // no op
    }

    @Override
    public void getPendingManualTransactionCollection(DelegateExecution execution) {
        LOGGER.debug("Calling MTS to get a collection of pending Manual Transactions");
        List<TransactionDetail> transactions = null;

        // Reset the error message object for each iteration of this flow
        execution.setVariable(ERR_MSG_OBJECT_VAR, null);

        try {
            TransactionCriteria tc = new TransactionCriteria();
            tc.setTransactionManualAutoCategory(ManualAutoCategoryType.MANUAL);
            tc.getStatusCodeList().add(TransactionStatusType.MPS_IMPORT_COMPLETE);

            transactions = mtsServiceManager.getTransactionList(tc);

            LOGGER.debug(String.format("MTS successfully returned a collection of %s pending Manual Transactions",
                transactions.size()));

            execution.setVariable("manualTransactionCollection", transactions);

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        }
    }

    @Override
    public void determineTransactionType(DelegateExecution execution) {
        TransactionDetail transactionDetail = execution.getVariableLocal(IMPORT_PENDING_TRANSACTION_DETAILS,
            TransactionDetail.class);

        if (transactionDetail != null) {
            execution.setVariable(TRANSACTION_TYPE, transactionDetail.getTransactionType().getCategory());
        }
    }

}
