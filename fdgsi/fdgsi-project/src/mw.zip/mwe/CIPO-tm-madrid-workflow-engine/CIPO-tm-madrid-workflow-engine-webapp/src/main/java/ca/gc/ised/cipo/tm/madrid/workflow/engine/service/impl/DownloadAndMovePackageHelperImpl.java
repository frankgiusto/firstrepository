package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DTF_PACKAGE_TEMP_NAME_PREFIX;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import ca.gc.ic.cipo.patents.dtf.trs.DownloadResponse;
import ca.gc.ic.cipo.schema.dtf.RacfUser;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem.Status;

/**
 * This helper class will employ an asynchronous method to download packages from DTF and move them to local staging.
 *
 * @author J. Greene
 *
 */
@Component
public class DownloadAndMovePackageHelperImpl
    implements ca.gc.ised.cipo.tm.madrid.workflow.engine.service.DownloadAndMovePackageHelper {

    protected static final Logger LOG = LoggerFactory.getLogger(DownloadAndMovePackageHelperImpl.class);

    @Autowired
    protected DtfServiceManager dtfServiceManager;

    @Autowired
    protected PackageDownloadLogService packageDownloadLogService;

    /**
     * <p>
     * Will download packages from DTF and move them to local staging asynchronously in order to prevent timeout issues
     * with Activiti transactions. Some package files are large and take a while to transfer/move.
     * </p>
     * <p>
     * <b>WebSphere Oddities</b><br/>
     * Container-managed tasks (WebSphere 8.5.5.0) seem to have some difficulty with executing this particular web
     * service. Result is an unmarshal exception whereas the same call on the main thread seems to run just fine. Even
     * with a non-container managed async task execution, the call returns normally. Some preliminary Google-fu lead to
     * <a href="http://www-01.ibm.com/support/docview.wss?uid=swg21998761">this article</a> that suggests the
     * WorkManager thread class loader locates the ws client and that loader is different than the main thread loader.
     * The workaround is to temporarily set the thread's classloader to that of the original class.
     * </p>
     * <p>
     * TODO: Maybe this goes away with versions of WAS with the Liberty build or higher? Revisit.
     * </p>
     *
     * @param downloadLogItem The log item related to this download for log update
     * @param requestId The DTF request ID of the original transfer request
     * @param outputDirectoryString The output directory
     */
    @Override
    @Async("taskExecutor")
    public void downloadAndMovePackage(DownloadLogItem downloadLogItem, Integer requestId,
                                       String outputDirectoryString) {
        RacfUser racfUser = MweWorkflowUtil.getRacfUser();

        DownloadResponse response;

        // *hack hack cough cough*
        Thread thread = Thread.currentThread();
        ClassLoader loader = thread.getContextClassLoader();
        thread.setContextClassLoader(this.getClass().getClassLoader());

        try {
            response = dtfServiceManager.downloadStagedFiles(requestId);
            DataHandler dataHandler = response.getZipStream();

            if (dataHandler == null) {
                String msg = "Data object from DTF is null!";
                failDownloadItem(downloadLogItem, msg);
            }

            String packageFileName = DTF_PACKAGE_TEMP_NAME_PREFIX.concat(requestId.toString()).concat(".zip");

            MweWorkflowUtil.moveFileStream(dataHandler, outputDirectoryString, packageFileName);
            // See if the file is there
            Path packageFilePath = Paths.get(outputDirectoryString, packageFileName);
            if (Files.exists(packageFilePath)) {
                // unzip the package in place.
                List<String> entryNames = MweWorkflowUtil.unzipInPlace(packageFilePath);

                // remove the old DTF archive
                Files.deleteIfExists(packageFilePath);

                Date downloadDate = new Date();
                int iterCount = 0;
                for (String entryName : entryNames) {
                    if (iterCount++ == 0) {
                        downloadLogItem.setDlDate(downloadDate);
                        downloadLogItem.setFileName(entryName);
                        downloadLogItem.setDlStatus(Status.SUCCESS.getValue());
                        packageDownloadLogService.updateLogEntry(downloadLogItem);
                    } else {
                        // if there's more than one file in the DTF archive, create new download log items for each for
                        // tracking purposes.
                        DownloadLogItem relatedDownloadLogItem = new DownloadLogItem();
                        BeanUtils.copyProperties(relatedDownloadLogItem, downloadLogItem);
                        relatedDownloadLogItem.setFileName(entryName);
                        relatedDownloadLogItem.setDlDate(downloadDate);
                        packageDownloadLogService.insertLogEntry(relatedDownloadLogItem);
                    }
                }
                LOG.info("Successfully moved package '" + packageFileName + "'");
            }
        } catch (BpmnWebServiceCallException e) {
            failDownloadItem(downloadLogItem, e.getMessage());
        } catch (Exception ex) {
            failDownloadItem(downloadLogItem, ex.getMessage());
        } finally {
            thread.setContextClassLoader(loader);
        }
    }

    protected void failDownloadItem(DownloadLogItem downloadLogItem, String msg) {
        downloadLogItem.setDlStatus(Status.FAIL.getValue());
        downloadLogItem.setMsg(msg);
        packageDownloadLogService.updateLogEntry(downloadLogItem);
    }
}
