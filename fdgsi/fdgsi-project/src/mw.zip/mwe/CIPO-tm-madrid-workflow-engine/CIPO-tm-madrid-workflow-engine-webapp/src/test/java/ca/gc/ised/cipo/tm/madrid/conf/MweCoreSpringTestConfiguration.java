package ca.gc.ised.cipo.tm.madrid.conf;

import javax.sql.DataSource;

import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.spring.ProcessEngineFactoryBean;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.h2.Driver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender;
import ca.gc.ised.cipo.tm.madrid.mock.MailSenderMock;
import ca.gc.ised.cipo.tm.madrid.mock.MfsServiceManagerMock;
import ca.gc.ised.cipo.tm.madrid.mock.MpsServiceManagerMock;
import ca.gc.ised.cipo.tm.madrid.mock.MtsServiceManagerMock;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.ActivitiHistoryPurgeDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.BusinessErrorLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.PackageDownloadLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AccountsReceivableService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.CreateOutgoingTransactionsService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.DownloadPackageService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionGapReportGenerationService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionInternalDownloadService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionReconcileService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionSubmitService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionUpdateFeeStatusService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridDelegateService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridListenerService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.ManualTransactionService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageOutgoingTransactionsService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PersistPackageService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.ReportGenerationService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestCreateOutgoingTransactionsServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestDownloadPackageServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionGapReportGenerationServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionInternalDownloadServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionReconcileServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionSubmitServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionUpdateFeeStatusServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestMadridDelegateServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestMadridListenerServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestPackageOutgoingTransactionsServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestPersistPackageServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestReportGenerationServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestTmTransactionsServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestUploadOutgoingTransactionPackageServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TmTransactionService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.UploadOutgoingPackageService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.AccountsReceivableServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.AutomatedTransactionServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.BusinessErrorLogServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.ManualTransactionServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.ProcessFlowConstantService;
import util.TestMadridMethodVarsService;

/**
 * Spring configuration class for MWE workflow engine flow tests.
 * <p>
 * <em>
 *  Note:  The inclusion of test service classes for the process flow service tasks is due to Activiti's not very refined mocking support.
 *  Mocking in the process engine generally works unless the processes are asynchronous (which most here are).
 *  </em>
 * </p>
 *
 * @author J. Greene
 *
 */
@Configuration
@EnableTransactionManagement
@EnableAsync
public class MweCoreSpringTestConfiguration implements TransactionManagementConfigurer {

	@Bean
	public DataSource dataSource() {
		SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
		dataSource.setDriverClass(Driver.class);
		dataSource.setUrl("jdbc:h2:mem:activiti_core;DB_CLOSE_DELAY=1000");
		dataSource.setUsername("sa");
		dataSource.setPassword("");
		return dataSource;
	}

	/** {@inheritDoc} */
	@Override
	@Bean
	public PlatformTransactionManager annotationDrivenTransactionManager() {
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
		transactionManager.setDataSource(dataSource());
		return transactionManager;
	}

	@Bean
	public SpringProcessEngineConfiguration processEngineConfiguration() {
		SpringProcessEngineConfiguration processEngineConfiguration = new SpringProcessEngineConfiguration();
		processEngineConfiguration.setDataSource(dataSource());
		processEngineConfiguration.setTransactionManager(annotationDrivenTransactionManager());
		processEngineConfiguration.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);
		processEngineConfiguration.setJobExecutorActivate(Boolean.FALSE);
		processEngineConfiguration.setAsyncExecutorActivate(Boolean.TRUE);
		processEngineConfiguration.setAsyncExecutorEnabled(Boolean.TRUE);
		processEngineConfiguration.setEnableDatabaseEventLogging(Boolean.TRUE);
		processEngineConfiguration.setHistory("full");
		return processEngineConfiguration;
	}

	@Bean
	public ProcessEngineFactoryBean processEngineFactory() {
		ProcessEngineFactoryBean processEngine = new ProcessEngineFactoryBean();
		processEngine.setProcessEngineConfiguration(processEngineConfiguration());
		return processEngine;
	}

	@Bean
	public ProcessEngine processEngine() {
		try {
			return processEngineFactory().getObject();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Bean
	public RepositoryService repositoryService() {
		return processEngine().getRepositoryService();
	}

	@Bean
	public RuntimeService runtimeService() {
		return processEngine().getRuntimeService();
	}

	@Bean
	public TaskService taskService() {
		return processEngine().getTaskService();
	}

	@Bean
	public HistoryService historyService() {
		return processEngine().getHistoryService();
	}

	@Bean
	public FormService formService() {
		return processEngine().getFormService();
	}

	@Bean
	public IdentityService identityService() {
		return processEngine().getIdentityService();
	}

	@Bean
	public ManagementService managementService() {
		return processEngine().getManagementService();
	}

	@Bean
	public ActivitiRule activitiRule() {
		return new ActivitiRule(processEngine());
	}

	/*
	 * Test implementations of the engine service classes.
	 */

	@Bean
	public DownloadPackageService downloadPackageServiceImpl() {
		return new TestDownloadPackageServiceImpl();
	}

	@Bean
	public PersistPackageService persistPackageServiceImpl() {
		return new TestPersistPackageServiceImpl();
	}

	@Bean
	public TmTransactionService tmTransactionServiceImpl() {
		return new TestTmTransactionsServiceImpl();
	}

	/*
	 * Constants 'service' to overcome limitations with Activiti's workflow
	 * engine.
	 */
	@Bean
	public ProcessFlowConstantService processFlowConstantService() {
		return new ProcessFlowConstantService();
	}

	/*
	 * DAO & service classes for logging
	 */
	@Bean
	public PackageDownloadLogDao packageDownloadLogDao() {
		return new PackageDownloadLogDao();
	}

	@Bean
	public BusinessErrorLogDao businessErrorLogDao() {
		return new BusinessErrorLogDao();
	}

	// @Bean
	// public PackageDownloadLogService packageDownloadLogService() {
	// return new PackageDownloadLogServiceImpl();
	// }
	//
	@Bean
	public ActivitiHistoryPurgeDao activitiHistoryPurgeDao() {
		return new ActivitiHistoryPurgeDao();
	}

	@Bean
	public BusinessErrorLogService businessErrorLogService() {
		return new BusinessErrorLogServiceImpl();
	}

	@Bean
	public TaskExecutor taskExecutor() {
		return new SimpleAsyncTaskExecutor();
	}

	@Bean
	public CreateOutgoingTransactionsService createOutgoingTransactionServiceImpl() {
		return new TestCreateOutgoingTransactionsServiceImpl();
	}

	@Bean
	public PackageOutgoingTransactionsService packageOutgoingTransactionsServiceImpl() {
		return new TestPackageOutgoingTransactionsServiceImpl();
	}

	@Bean
	public UploadOutgoingPackageService uploadOutgoingPackageServiceImpl() {
		return new TestUploadOutgoingTransactionPackageServiceImpl();
	}

	@Bean
	public ReportGenerationService reportGenerationServiceImpl() {
		return new TestReportGenerationServiceImpl();
	}

	@Bean
	public FinancialTransactionReconcileService financialTransactionReconcileServiceImpl() {
		return new TestFinancialTransactionReconcileServiceImpl();
	}

	@Bean
	public FinancialTransactionSubmitService financialTransactionSubmitServiceImpl() {
		return new TestFinancialTransactionSubmitServiceImpl();
	}

	@Bean
	public FinancialTransactionInternalDownloadService financialTransactionInternalDownloadServiceImpl() {
		return new TestFinancialTransactionInternalDownloadServiceImpl();
	}

	@Bean
	public FinancialTransactionUpdateFeeStatusService financialTransactionUpdateFeeStatusServiceImpl() {
		return new TestFinancialTransactionUpdateFeeStatusServiceImpl();
	}

	@Bean
	public FinancialTransactionGapReportGenerationService financialTransactionGapReportGenerationServiceImpl() {
		return new TestFinancialTransactionGapReportGenerationServiceImpl();
	}

	@Bean
	public MtsServiceManager mtsServiceManager() {

		return new MtsServiceManagerMock();
	}

	@Bean
	public MpsServiceManager mpsServiceManager() {

		return new MpsServiceManagerMock();
	}

	@Bean
	public MfsServiceManager mfsServiceManager() {
		// MFS-CLEAN-SPR5 return new MfsServiceManagerMock();
		return null;
	}

	@Bean
	public AccountsReceivableService accountsReceivableServiceImpl() {
		return new AccountsReceivableServiceImpl();
	}

	@Bean(name = "madridListenerServiceImpl")
	public MadridListenerService madridListenerServiceImpl() {
		return new TestMadridListenerServiceImpl();
	}

	@Bean(name = "madridDelegateServiceImpl")
	public MadridDelegateService madridDelegetServiceImpl() {

		TestMadridDelegateServiceImpl delegate = new TestMadridDelegateServiceImpl();

		return delegate;
	}

	@Bean(name = "madridMethodVarsService")
	public TestMadridMethodVarsService madridMethodVarsService() {

		TestMadridMethodVarsService delegate = new TestMadridMethodVarsService();

		return delegate;
	}

	@Bean
	public AutomatedTransactionService automatedTransactionServiceImpl() {
		return new AutomatedTransactionServiceImpl();
	}

	@Bean
	public ManualTransactionService manualTransactionServiceImpl() {
		return new ManualTransactionServiceImpl();
	}

	@Bean
	public JndiSimpleMailSender mailSender() {
		return new MailSenderMock();
	}

}
