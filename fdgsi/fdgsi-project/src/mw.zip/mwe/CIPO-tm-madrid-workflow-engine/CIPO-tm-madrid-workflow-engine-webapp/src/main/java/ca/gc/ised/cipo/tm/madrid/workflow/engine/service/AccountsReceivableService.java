/*
 * Copyright (c) 2018 CIPO Created on Aug 15, 2018
 */
package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes the operations required to handle the steps of Account Receivable for the BPMN flow
 * process-accounts-receivable.bpmn and its sub-flow send-accounts-receivable-to-financial-system.bpmn
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public interface AccountsReceivableService extends BusinessErrorHandler {

    /**
     * Calls the designated service (HFS) to process the accounts receivable distribution.
     *
     * @param execution the Activiti context object that holds information and variables related to the current process
     *            execution
     */
    public void processAccountReceivableDistribution(DelegateExecution execution);

    /**
     * Calls the designated service (HPS) to get a collection of packages READY to be sent to the financial system.
     * Typically this call will only return 1 package at a time but allowance is made that under error correction
     * conditions more than one package may be returned.
     *
     * @param execution the Activiti context object that holds information and variables related to the current process
     *            execution
     */
    public void fetchAccountsReceivablePackages(DelegateExecution execution);

    /**
     * Call the designated service (HPS) to export a specific Account Receivable package to a provided file system
     * location. This file will be sent the financial system via a DTF transfer.
     *
     * @param execution the Activiti context object that holds information and variables related to the current process
     *            execution
     */
    public void exportAccountsReceivablePackage(DelegateExecution execution);

    /**
     * Creates a DTF Transfer Request to send the Accounts Receivable package to the Financial system (IFMS).
     *
     * @param execution execution the Activiti context object that holds information and variables related to the
     *            current process execution
     */
    public void createArTransferRequestToIfms(DelegateExecution execution);

    /**
     * Verifies if the previously created DTF Transfer Request has completed (successfully or otherwise).
     *
     * @param execution execution the Activiti context object that holds information and variables related to the
     *            current process execution
     */
    public void verifyArTransferRequest(DelegateExecution execution);

    /**
     * Cleans up the files in the shared directory used in the transfer and processing.
     *
     * @param execution execution the Activiti context object that holds information and variables related to the
     *            current process execution
     */
    public void cleanUpSharedFiles(DelegateExecution execution);

    /**
     * Moves shared files to a designated FAIL folder.
     *
     * @param execution execution the Activiti context object that holds information and variables related to the
     *            current process execution
     */
    public void moveSharedFilesToFailFolder(DelegateExecution execution);

    /**
     * Sets the status of the package being processed to SENT.
     *
     * @param execution execution the Activiti context object that holds information and variables related to the
     *            current process execution
     */
    public void setPackageStatusSent(DelegateExecution execution);

    /**
     * Sets the status of the package being processed to FAILED.
     *
     * @param execution execution the Activiti context object that holds information and variables related to the
     *            current process execution
     */
    public void setPackageStatusFailed(DelegateExecution execution);

}
