package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility level model object to hold system information
 *
 * @author J. Greene
 *
 */
public class SystemInfo implements Serializable {

    public static final String STATUS_OK = "OK";

    public static final String STATUS_INDETERMINATE = "INDETERMINATE";

    public static final String STATUS_DOWN = "DOWN";

    private static final long serialVersionUID = -1228622876115465598L;

    private String version;

    private String buildDateAndTime;

    private List<ServiceClientInfo> clientInfoList;

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * @return the buildDateAndTime
     */
    public String getBuildDateAndTime() {
        return buildDateAndTime;
    }

    /**
     * @param buildDateAndTime the buildDateAndTime to set
     */
    public void setBuildDateAndTime(String buildDateAndTime) {
        this.buildDateAndTime = buildDateAndTime;
    }

    /**
     * @return the clientInfoList
     */
    public List<ServiceClientInfo> getClientInfoList() {
        if (clientInfoList == null) {
            clientInfoList = new ArrayList<>();
        }
        return clientInfoList;
    }

    public void createClientInfoInstance(String status, String url) {
        ServiceClientInfo scInfo = new ServiceClientInfo(status, url);
        getClientInfoList().add(scInfo);
    }

    class ServiceClientInfo implements Serializable {

        private static final long serialVersionUID = 3865209148257176320L;

        String status = STATUS_INDETERMINATE;

        String url;

        String name;

        protected ServiceClientInfo(String status, String url) {
            super();
            this.status = status;
            this.url = url;
        }

        /**
         * @return the status
         */
        public String getStatus() {
            return status;
        }

        /**
         * @param status the status to set
         */
        void setStatus(String status) {
            this.status = status;
        }

        /**
         * @return the url
         */
        public String getUrl() {
            return url;
        }

        /**
         * @param url the url to set
         */
        void setUrl(String url) {
            this.url = url;
        }

    }
}
