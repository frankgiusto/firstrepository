package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code process_hague_id_transactions_from_wipo.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
public interface TmTransactionService extends BusinessErrorHandler {

    /**
     * Service task method responsible for retrieving a collection of ID transactions for PDF generation.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getPdfGenerationPendingTransactionCollection(DelegateExecution execution);

    /**
     * Service task method responsible for retrieving a collection of ID transactions to be imported to the back-end
     * system.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getImportPendingTransactionCollection(DelegateExecution execution);

    /**
     * Service task method responsible for importing a WIPO ID transaction to the back-end system.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void processTransaction(DelegateExecution execution);

    /**
     * Service task method responsible for evaluating and collecting iterative errors that may occur in the looping
     * subprocess.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void handleIterativeError(DelegateExecution execution);

    /**
     * EVENT LISTENER: To be used to set default variables from HWE configuration parameters.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void setProcessFlowVariables(DelegateExecution execution);
}
