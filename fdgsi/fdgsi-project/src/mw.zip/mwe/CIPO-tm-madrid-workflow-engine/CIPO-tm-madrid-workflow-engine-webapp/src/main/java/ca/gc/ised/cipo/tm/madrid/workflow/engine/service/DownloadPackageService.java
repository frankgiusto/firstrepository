package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code download_hague_package_from_wipo.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
public interface DownloadPackageService extends BusinessErrorHandler {

    /**
     * Service task method responsible for transferring data from WIPO to CIPO.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void createTransferRequest(DelegateExecution execution);

    /**
     * Service task method responsible for verifying whether or not the data transfer was successful. See
     * {@link #createTransferRequest(DelegateExecution)}.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void verifyPackageTransfer(DelegateExecution execution);

    /**
     * Service task method responsible for queuing the move of the WIPO package from DTF staging area to the output
     * folder.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void queueTransferPackageToOutputFolder(DelegateExecution execution);

    /**
     * Service task method responsible for notifying DTF that the package was downloaded and 'processed' from DTF's
     * perspective. This will initiate the purge process on the datastore.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void sendTransferConfirmation(DelegateExecution execution);

    /**
     * Service task method responsible for verifying the completion of the move operation on the WIPO package from
     * staging to the output folder. Files may be large and it's possible that the move operation may take more time
     * than the transaction timeout will allow.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void verifyPackageMove(DelegateExecution execution);

    /**
     * This method will hopefully not stay and is meant to test if life would be better without Activiti's timer, who
     * sometimes forget to wake up.
     */
    void waitOneMinute(DelegateExecution execution);
}
