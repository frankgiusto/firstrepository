package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.lang.invoke.MethodHandles;

import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridGroupAssignmentService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;

@Service
public class MadridGroupAssignmentServiceImpl implements MadridGroupAssignmentService {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Override
	public String getCandidateGroupForTask(DelegateExecution execution) {

		String candidateGroup = (String) execution.getVariable(ProcessFlowConstants.CANDIDATE_GROUP_ID);

		if (candidateGroup == null) {

			String callingProcessId = (String) execution.getVariable(ProcessFlowConstants.CALLING_PROCESS_NAME);

			// This is just temporary until we set this up properly.
			switch (callingProcessId) {

			case "processIRCeasingOfEffectPartial":

				candidateGroup = "MC_TM_EXAMINER";
				break;

			case "processIRLimitation":

				candidateGroup = "MC_TM_EXAMINER";
				break;

			case "processIRCancellationPartial":

				candidateGroup = "MC_TM_EXAMINER";
				break;

			case "processDesignationOwnershipChangePartial":

				candidateGroup = "MC_TM_OPERATOR";
				break;

			case "processIRTransformation":

				candidateGroup = "MC_TM_EXAMINER";
				break;

			case "processNANRCeasingOfEffectPartial":

				candidateGroup = "MC_TM_EXAMINER";
				break;

			case "processIrregularity":

				candidateGroup = "MC_TM_SUPERVISOR";
				break;

			case "createNotification":

				candidateGroup = "MC_TM_SUPERVISOR";
				break;

			case "createOutgoingManualTask":

				candidateGroup = "MC_TM_EXAMINER";
				break;

			case "reviewBasicMarks":

				candidateGroup = "MC_TM_SUPERVISOR";
				break;

			default:
				candidateGroup = "UNKNOWN";
				break;
			}

		}

		return candidateGroup;
	}

	@Override
	public void setCallingProcessVariable(DelegateExecution execution) {

		String processId = null;

		String processInstanceId = execution.getProcessDefinitionId();

		// The returned value is <processId>:<threadId>:<processInstanceId>.
		// We only want the processId defined in the BPMN.
		if (processInstanceId != null && processInstanceId.indexOf(":") != -1) {

			processId = processInstanceId.substring(0, processInstanceId.indexOf(":"));

		}

		LOG.debug("Setting " + ProcessFlowConstants.CALLING_PROCESS_NAME + " -> " + processId);

		execution.setVariable(ProcessFlowConstants.CALLING_PROCESS_NAME, processId);
	}

}
