package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.math.BigDecimal;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A bean to represent the process flow variables needed to run the outgoing monthly financial reconciled fee workflow
 * as a stand-alone process.
 *
 * @author J. Greene
 *
 */
public class OutgoingMonthlyFinPkgJob extends MweJob implements Serializable {

    private static final long serialVersionUID = -1831712321994363793L;

    private BigDecimal packageId;

    private String uploadVerificationPollInterval;

    private String finPkgUploadStagingFolder;

    private String finPkgUploadStagingFailureFolder;

    private String finPkgUploadFileName;

    /**
     * @return the packageId
     */
    public BigDecimal getPackageId() {
        return packageId;
    }

    /**
     * @param packageId the packageId to set
     */
    public void setPackageId(BigDecimal packageId) {
        this.packageId = packageId;
    }

    /**
     * @return the uploadVerificationPollInterval
     */
    public String getUploadVerificationPollInterval() {
        return uploadVerificationPollInterval;
    }

    /**
     * @param uploadVerificationPollInterval the uploadVerificationPollInterval to set
     */
    public void setUploadVerificationPollInterval(String uploadVerificationPollInterval) {
        this.uploadVerificationPollInterval = uploadVerificationPollInterval;
    }

    /**
     * @return the finPkgUploadStagingFolder
     */
    public String getFinPkgUploadStagingFolder() {
        return finPkgUploadStagingFolder;
    }

    /**
     * @param finPkgUploadStagingFolder the finPkgUploadStagingFolder to set
     */
    public void setFinPkgUploadStagingFolder(String finPkgUploadStagingFolder) {
        this.finPkgUploadStagingFolder = finPkgUploadStagingFolder;
    }

    /**
     * @return the finPkgUploadStagingFailureFolder
     */
    public String getFinPkgUploadStagingFailureFolder() {
        return finPkgUploadStagingFailureFolder;
    }

    /**
     * @param finPkgUploadStagingFailureFolder the finPkgUploadStagingFailureFolder to set
     */
    public void setFinPkgUploadStagingFailureFolder(String finPkgUploadStagingFailureFolder) {
        this.finPkgUploadStagingFailureFolder = finPkgUploadStagingFailureFolder;
    }

    /**
     * @return the finPkgUploadFileName
     */
    public String getFinPkgUploadFileName() {
        return finPkgUploadFileName;
    }

    /**
     * @param finPkgUploadFileName the finPkgUploadFileName to set
     */
    public void setFinPkgUploadFileName(String finPkgUploadFileName) {
        this.finPkgUploadFileName = finPkgUploadFileName;
    }

    @Override
    public String toString() {
     // @formatter:off
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("packageId", packageId)
            .append("uploadVerificationPollInterval", uploadVerificationPollInterval)
            .append("finPkgUploadStagingFolder", finPkgUploadStagingFolder)
            .append("finPkgUploadStagingFailureFolder", finPkgUploadStagingFailureFolder)
            .append("finPkgUploadFileName", finPkgUploadFileName)
            .append("processInstanceId", processInstanceId)
            .toString();
     // @formatter:on
    }
}
