package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import java.math.BigDecimal;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Service;

import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.model.EmailMessageDetails;

/**
 * Manager class to handle the Madrid finance service calls and response as well
 * as any SOAP faults.
 *
 * @author J. Greene
 *
 */
@Service
public interface MfsServiceManager {

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManagerI#
	 * processAccountReceivableDistributionAsync
	 * (org.activiti.engine.delegate.DelegateExecution)
	 */
	public void processAccountReceivableDistributionAsync(DelegateExecution execution)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps a service operation that will parse financial transactions from a
	 * financial package.
	 *
	 * @param packageId
	 *            the package ID of the package to be parsed
	 * @param transferItem
	 *            the transfer type of the package
	 * @throws BpmnWebServiceCallException
	 */

	public void parsePackageToTransactions(BigDecimal packageId, String transferItem)
			throws BpmnWebServiceCallException;

	/**
	 * Wraps a service operation to get email details (subject, body,
	 * receiver(s)) for notification purposes upon generation of a gap report
	 *
	 * @return A local bean to hold the transcribed information from the
	 *         operation
	 * @throws BpmnWebServiceCallException
	 */

	public EmailMessageDetails getNotificationEmailContent() throws BpmnWebServiceCallException;

	/**
	 * Wraps an operation to perform reconciliation tasks on a financial
	 * transaction.
	 *
	 * @param transactionId
	 *            the transaction ID
	 * @throws BpmnWebServiceCallException
	 */

	public void reconcileFinancialTransaction(BigDecimal transactionId) throws BpmnWebServiceCallException;

	/**
	 * Wraps an operation to retrieve the reconciled fee distribution XML data
	 * for
	 *
	 * @param packageId
	 * @return
	 * @throws BpmnWebServiceCallException
	 */
	// MFS-CLEAN-SPR5 public ReconciledOutput
	// generateReconciledFeeDistribution(BigDecimal packageId) throws
	// BpmnWebServiceCallException;

	/**
	 * Wraps an operation that will update a specific transaction's financial
	 * status.
	 *
	 * @param transactionId
	 *            the transaction ID
	 * @throws BpmnWebServiceCallException
	 */
	public void updateApplicationsFinancialStatus(BigDecimal transactionId) throws BpmnWebServiceCallException;

	/**
	 * Wraps the call in MFS to generate a report of a specific type given the
	 * package ID associated with the report input data.
	 *
	 * @param packageId
	 *            the package ID pertaining to the report generation
	 * @param reportTypeCode
	 *            the type of report to be generated
	 * @return the report job ID for use when polling for report progress from
	 *         report service
	 * @throws BpmnWebServiceCallException
	 */
	// MFS-CLEAN-SPR5 public String generateReport(BigDecimal packageId,
	// ReportTypeEnum reportTypeCode)
	// throws BpmnWebServiceCallException;

	/**
	 * Wraps a call to MFS to notify HTS that a report is ready for consumption.
	 *
	 * @param reportJobId
	 *            the report job ID of the completed report in RGS
	 * @param packageId
	 *            the package ID pertaining to the report generation
	 * @param reportTypeCode
	 *            the type of report to be generated
	 * @return the attachment ID of the attachment that was created in the INTL
	 *         DB as a result of this call
	 * @throws BpmnWebServiceCallException
	 */
	// MFS-CLEAN-SPR5 public BigDecimal generateReportNotification(String
	// reportJobId, BigDecimal packageId,
	// ReportTypeEnum reportTypeCode)
	// throws BpmnWebServiceCallException;

}
