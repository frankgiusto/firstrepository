/*
 * Copyright (c) 2018 CIPO Created on May 16, 2018
 */
package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IMPORT_PENDING_TRANSACTION_DETAILS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.SERVICE_FAULT_SEVERITY_THRESHOLD;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingPairCriteria;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ManualAutoCategoryType;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.TransactionPairRequest;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Implementation of service interface used to support the ProcessAutomatedTransactionFromWIPO bpmn flow.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
@Service
public class AutomatedTransactionServiceImpl extends BusinessErrorHandlerImpl implements AutomatedTransactionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AutomatedTransactionServiceImpl.class);

    @Autowired
    protected MtsServiceManager mtsServiceManager;

    @Autowired
    private ProcessEngine processEngine;

    /**
     * Constructor.
     */
    public AutomatedTransactionServiceImpl() {
        // no op
    }

    /*
     * (non-Javadoc)
     *
     * @see ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService#
     * getPendingAutomatedTransactionCollection(org.activiti.engine.delegate.DelegateExecution)
     */
    @Override
    public void getPendingAutomatedTransactionCollection(DelegateExecution execution) {
        LOGGER.debug("Calling MTS to get a collection of pending automated Transactions");
        List<TransactionDetail> transactions = null;

        // Reset the error message object for each iteration of this flow
        execution.setVariable(ERR_MSG_OBJECT_VAR, null);

        try {
            TransactionCriteria tc = new TransactionCriteria();
            tc.setTransactionManualAutoCategory(ManualAutoCategoryType.AUTOMATED);
            tc.getStatusCodeList().add(TransactionStatusType.MPS_IMPORT_COMPLETE);

            transactions = mtsServiceManager.getTransactionList(tc);

            LOGGER.debug(String.format("MTS successfully returned a collection of %s pending automated Transactions",
                transactions.size()));

            execution.setVariable("automatedTransactionCollection", transactions);

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService#getPendingAutomatedPairsCollection(
     * org.activiti.engine.delegate.DelegateExecution)
     */
    @Override
    public void getPendingAutomatedPairsCollection(DelegateExecution execution) {
        LOGGER.debug("Calling MTS to get a collection of pending automated pair Transactions");
        List<TransactionDetail> transactions = null;

        // Reset the error message object for each iteration of this flow
        execution.setVariable(ERR_MSG_OBJECT_VAR, null);

        try {
            TransactionCriteria tc = new TransactionCriteria();
            tc.setTransactionManualAutoCategory(ManualAutoCategoryType.AUTOMATED_PAIR);
            tc.getStatusCodeList().add(TransactionStatusType.MPS_IMPORT_COMPLETE);

            transactions = mtsServiceManager.getTransactionList(tc);

            LOGGER
                .debug(String.format("MTS successfully returned a collection of %s pending automated pair Transactions",
                    transactions.size()));

            execution.setVariable("automatedPairTransactionCollection", transactions);

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService#processAutomatedTransaction(org.
     * activiti.engine.delegate.DelegateExecution)
     */
    @Override
    public void processAutomatedTransaction(DelegateExecution execution) {
        // Reset the error message object for each iteration of this flow
        execution.setVariable(ERR_MSG_OBJECT_VAR, null);

        try {
            // A valid transaction object MUST exist at this point
            TransactionDetail mTrans = execution.getVariableLocal(IMPORT_PENDING_TRANSACTION_DETAILS,
                TransactionDetail.class);
            LOGGER.debug("Calling MTS to process an automated Transaction ID: " + mTrans.getTransactionId());

            // Set up the criteria to request MTS processing of a given transaction ID
            AutomaticProcessingCriteria apc = new AutomaticProcessingCriteria();
            TransactionRequest tr = new TransactionRequest();
            tr.setIrTranId(mTrans.getTransactionId());
            // Authority ID will be set by MTS (parameter omitted here)
            apc.setTransactionRequest(tr);
            AutomatedProcessResponse apr = mtsServiceManager.processAutomatedTransaction(apc);

            // After MTS successfully completes processing AND if it returns one or more Console Task ID, start a manual
            // notification BPM flow which will be linked with each console task
            for (ConsoleTaskResponse ctr : apr.getConsoleTaskBag()) {
                BigDecimal consoleTaskId = ctr.getConsoleTaskId();

                if (consoleTaskId != null) {

                    // Add the Console Task ID to a parameter map
                    Map<String, Object> processVars = new TreeMap<String, Object>();
                    processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, consoleTaskId);

                    // Start the Notification process flow with the Console TAsk ID as a parameter
                    ProcessInstance notificationInstance = processEngine.getRuntimeService()
                        .startProcessInstanceByKey("createNotification", processVars);

                    String processInstanceTaskId = "?";
                    if (notificationInstance != null) {
                        processInstanceTaskId = notificationInstance.getProcessInstanceId();
                    }
                    LOGGER.debug(String.format(
                        "Started 'createNotification' flow with Process Instance ID: %s associated with Console Task ID: %s",
                        processInstanceTaskId, consoleTaskId));

                    // This association of the ConsoleTask Id and Activiti User Task Id will be done in the newly
                    // spawned process flow
                }
            }

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AutomatedTransactionService#processAutomatedPair(org.activiti.
     * engine.delegate.DelegateExecution)
     */
    @Override
    public void processAutomatedPair(DelegateExecution execution) {
        // Reset the error message object for each iteration of this flow
        execution.setVariable(ERR_MSG_OBJECT_VAR, null);

        try {
            // A valid transaction object MUST exist at this point
            TransactionDetail mTrans = execution.getVariableLocal(IMPORT_PENDING_TRANSACTION_DETAILS,
                TransactionDetail.class);
            LOGGER.debug("Calling MTS to process an automated pair Transaction ID: " + mTrans.getTransactionId());

            // Set up the criteria to request MTS processing of a given transaction ID
            AutomaticProcessingPairCriteria appc = new AutomaticProcessingPairCriteria();
            TransactionPairRequest tpr = new TransactionPairRequest();
            tpr.setIrTranId(mTrans.getTransactionId());
            tpr.setAssociatedIrTranId(mTrans.getAssociatedTransactionId());
            // Authority ID will be set by MTS (parameter omitted here)
            appc.setTransactionMeta(tpr);

            AutomatedProcessResponse apr = mtsServiceManager.processAutomatedTransactionPair(appc);

            // After MTS successfully completes processing AND if it returns one or more Console Task ID, start a manual
            // notification BPM flow which will be linked with each console task
            for (ConsoleTaskResponse ctr : apr.getConsoleTaskBag()) {
                BigDecimal consoleTaskId = ctr.getConsoleTaskId();

                if (consoleTaskId != null) {

                    // Add the Console Task ID to a parameter map
                    Map<String, Object> processVars = new TreeMap<String, Object>();
                    processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, consoleTaskId);

                    // Start the Notification process flow with the Console TAsk ID as a parameter
                    ProcessInstance notificationInstance = processEngine.getRuntimeService()
                        .startProcessInstanceByKey("createNotification", processVars);

                    String processInstanceTaskId = "?";
                    if (notificationInstance != null) {
                        processInstanceTaskId = notificationInstance.getProcessInstanceId();
                    }
                    LOGGER.debug(String.format(
                        "Started 'createNotification' flow with Process Instance ID: %s associated with Console Task ID: %s",
                        processInstanceTaskId, consoleTaskId));

                    // This association of the ConsoleTask Id and Activiti User Task Id will be done in the newly
                    // spawned process flow
                }
            }

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        }
    }

    /**
     * {@inheritDoc}
     * <p>
     * Handles the iterative error that may occur while processing individual transactions. Evaluate the severity to
     * alter course of action appropriately.
     * </p>
     */
    @Override
    public void handleIterativeError(DelegateExecution execution) {
        LOGGER.debug("Handling Iterative error");
        Integer recoverableErrorCondition = COMPLETE;
        BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
            BusinessErrorLogItem.class);
        TransactionDetail transactionDetail = execution.getVariableLocal(IMPORT_PENDING_TRANSACTION_DETAILS,
            TransactionDetail.class);

        if (!businessErrorLogItem.isCipoServiceFaultOrigin()) {
            recoverableErrorCondition = ERROR;
        } else {
            // Check the fault return code. If it falls below the threshold, assume not recoverable.
            if (businessErrorLogItem.getReturnCode() <= SERVICE_FAULT_SEVERITY_THRESHOLD) {
                recoverableErrorCondition = ERROR;
                LOG.error("A non-recoverable error occurred while processing transaction # ["
                    + transactionDetail.getTransactionId() + "]");
            } else {
                handleCumulativeError(execution, "TRANSACTION ID: " + transactionDetail.getTransactionId());
            }
        }
        execution.setVariable(RECOVERABLE_ERROR_CONDITION, recoverableErrorCondition);
    }

}
