package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.io.Serializable;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * A test service class to be used for unit testing the process_hague_messages_from_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
public class TestTmTransactionsServiceImpl extends TestBusinessErrorHandlerImpl
    implements TmTransactionService, Serializable {

    private static final long serialVersionUID = 3512192055565820824L;

    private Integer importTransactionStatusReturnObject;

    private Integer getPdfTransactionsStatusReturnObject;

    private Integer getImportTransactionsStatusReturnObject;

    private Integer recoverableConditionReturnObject;

    private Integer asyncOperationStatusReturnObject;

    /** {@inheritDoc} */
    @Override
    public void setProcessFlowVariables(DelegateExecution execution) {
        System.out.println("[[setProcessFlowVariables]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void getPdfGenerationPendingTransactionCollection(DelegateExecution execution) {
        if (getGetPdfTransactionsStatusReturnObject() != null) {
            execution.setVariable(GET_PDF_TRANSACTION_STATUS, getGetPdfTransactionsStatusReturnObject());
        }

        System.out.println("[[getPdfGenerationPendingTransactionCollection]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void processTransaction(DelegateExecution execution) {
        if (getImportTransactionStatusReturnObject() != null) {
            execution.setVariableLocal("importTransactionStatus", getImportTransactionStatusReturnObject());
        }
        if (getAsyncOperationStatusReturnObject() != null) {
            execution.setVariableLocal(ASYNC_OPERATION_STATUS, getAsyncOperationStatusReturnObject());
        }
        System.out.println("[[processTransaction]] GLOBAL: " + execution.getVariables()
            + "\n                        LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void handleIterativeError(DelegateExecution execution) {
        if (getRecoverableConditionReturnObject() != null) {
            execution.setVariableLocal(RECOVERABLE_ERROR_CONDITION, getRecoverableConditionReturnObject());
        }
        System.out.println("[[handleIterativeError]] GLOBAL: " + execution.getVariables()
            + "\n                          LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void getImportPendingTransactionCollection(DelegateExecution execution) {
        if (getGetImportTransactionsStatusReturnObject() != null) {
            execution.setVariable(GET_IMPORT_TRANSACTION_STATUS, getGetImportTransactionsStatusReturnObject());
        }
        System.out.println("[[getImportPendingTransactionCollection]]: " + execution.getVariables());
    }

    /**
     * @return the importTransactionStatusReturnObject
     */
    public Integer getImportTransactionStatusReturnObject() {
        return importTransactionStatusReturnObject;
    }

    /**
     * @param importTransactionStatusReturnObject the importTransactionStatusReturnObject to set
     */
    public void setImportTransactionStatusReturnObject(Integer importMessageStatusReturnObject) {
        this.importTransactionStatusReturnObject = importMessageStatusReturnObject;
    }

    /**
     * @return the recoverableConditionReturnObject
     */
    public Integer getRecoverableConditionReturnObject() {
        return recoverableConditionReturnObject;
    }

    /**
     * @param recoverableConditionReturnObject the recoverableConditionReturnObject to set
     */
    public void setRecoverableConditionReturnObject(Integer recoverableCondition) {
        this.recoverableConditionReturnObject = recoverableCondition;
    }

    /**
     * @return the getPdfTransactionsStatusReturnObject
     */
    public Integer getGetPdfTransactionsStatusReturnObject() {
        return getPdfTransactionsStatusReturnObject;
    }

    /**
     * @param getPdfTransactionsStatusReturnObject the getPdfTransactionsStatusReturnObject to set
     */
    public void setGetPdfTransactionsStatusReturnObject(Integer getPdfTransactionsStatusReturnObject) {
        this.getPdfTransactionsStatusReturnObject = getPdfTransactionsStatusReturnObject;
    }

    /**
     * @return the getImportTransactionsStatusReturnObject
     */
    public Integer getGetImportTransactionsStatusReturnObject() {
        return getImportTransactionsStatusReturnObject;
    }

    /**
     * @param getImportTransactionsStatusReturnObject the getImportTransactionsStatusReturnObject to set
     */
    public void setGetImportTransactionsStatusReturnObject(Integer getImportTransactionsStatusReturnObject) {
        this.getImportTransactionsStatusReturnObject = getImportTransactionsStatusReturnObject;
    }

    /**
     * @return the asyncOperationStatusReturnObject
     */
    public Integer getAsyncOperationStatusReturnObject() {
        return asyncOperationStatusReturnObject;
    }

    /**
     * @param asyncOperationStatusReturnObject the asyncOperationStatusReturnObject to set
     */
    public void setAsyncOperationStatusReturnObject(Integer asyncOperationStatusReturnObject) {
        this.asyncOperationStatusReturnObject = asyncOperationStatusReturnObject;
    }

}
