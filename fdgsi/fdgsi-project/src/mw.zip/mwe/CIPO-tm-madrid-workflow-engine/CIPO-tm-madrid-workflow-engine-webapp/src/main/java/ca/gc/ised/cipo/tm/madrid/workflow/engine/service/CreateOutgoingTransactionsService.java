package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code create_madrid_transactions_to_wipo.bpmn} process flow.
 *
 */
public interface CreateOutgoingTransactionsService extends BusinessErrorHandler {

    /**
     * Service task method responsible for retrieving a collection of pending automated message transactions from the
     * back-end system to be sent to WIPO.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getOfficeToIbAutomaticProcessActions(DelegateExecution execution);

    /**
     * Service task method responsible for retrieving a collection of pending manual message transactions from the
     * back-end system to be sent to WIPO.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getOfficeToIbManualProcessActions(DelegateExecution execution);

    /**
     * Service task method responsible for creating an outgoing automated WIPO message transaction from the back-end
     * system message transaction. See {@link #getPendingTransactionCollection(DelegateExecution)}.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void createOfficeToIbTransaction(DelegateExecution execution);

    /**
     * Service task method responsible for creating an outgoing manual WIPO message transaction from the back-end system
     * message transaction. See {@link #getPendingTransactionCollection(DelegateExecution)}.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void createOfficeToIbManualTask(DelegateExecution execution);

    /**
     * Service task method to handle errors that occur in the iterative process. Errors may be deemed recoverable or not
     * recoverable with different outcomes.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void handleAutomatedIterativeError(DelegateExecution execution);

    void handleManualIterativeError(DelegateExecution execution);

}
