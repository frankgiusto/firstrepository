package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.CustomDateSerializer;

/**
 * A domain object to represent a business error entry in the datastore.
 *
 * @author J. Greene
 *
 */
public class BusinessErrorLogItem implements Serializable, Comparable<BusinessErrorLogItem> {

    private static final long serialVersionUID = 2484094204042880331L;

    private Long businessErrorLogId;

    private String message;

    private Long returnCode;

    private Long reasonCode;

    private String componentAcronym;

    private String serviceName;

    private String errorMessageEn;

    private String errorMessageFr;

    private String processInstanceId;

    private String processDefinitionName;

    private Date createdDate;

    private boolean cipoServiceFaultOrigin = false;

    public BusinessErrorLogItem() {
    }

    public BusinessErrorLogItem(String message) {
        this.setMessage(message);
    }

    /**
     * @return the businessErrorLogId
     */
    public Long getBusinessErrorLogId() {
        return businessErrorLogId;
    }

    /**
     * @param businessErrorLogId the businessErrorLogId to set
     */
    public void setBusinessErrorLogId(Long businessErrorLogId) {
        this.businessErrorLogId = businessErrorLogId;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the returnCode
     */
    public Long getReturnCode() {
        return returnCode;
    }

    /**
     * @param returnCode the returnCode to set
     */
    public void setReturnCode(Long returnCode) {
        this.returnCode = returnCode;
    }

    /**
     * @return the reasonCode
     */
    public Long getReasonCode() {
        return reasonCode;
    }

    /**
     * @param reasonCode the reasonCode to set
     */
    public void setReasonCode(Long reasonCode) {
        this.reasonCode = reasonCode;
    }

    /**
     * @return the componentAcronym
     */
    public String getComponentAcronym() {
        return componentAcronym;
    }

    /**
     * @param componentAcronym the componentAcronym to set
     */
    public void setComponentAcronym(String componentAcronym) {
        this.componentAcronym = componentAcronym;
    }

    /**
     * @return the serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * @return the errorMessageEn
     */
    public String getErrorMessageEn() {
        return errorMessageEn;
    }

    /**
     * @param errorMessageEn the errorMessageEn to set
     */
    public void setErrorMessageEn(String errorMessageEn) {
        this.errorMessageEn = errorMessageEn;
    }

    /**
     * @return the errorMessageFr
     */
    public String getErrorMessageFr() {
        return errorMessageFr;
    }

    /**
     * @param errorMessageFr the errorMessageFr to set
     */
    public void setErrorMessageFr(String errorMessageFr) {
        this.errorMessageFr = errorMessageFr;
    }

    /**
     * @return the processInstanceId
     */
    public String getProcessInstanceId() {
        return processInstanceId;
    }

    /**
     * @param processInstanceId the processInstanceId to set
     */
    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    /**
     * @return the processDefinitionName
     */
    public String getProcessDefinitionName() {
        return processDefinitionName;
    }

    /**
     * @param processDefinitionName the processDefinitionName to set
     */
    public void setProcessDefinitionName(String processDefinitionName) {
        this.processDefinitionName = processDefinitionName;
    }

    /**
     * @return the createdDate
     */
    @JsonSerialize(using = CustomDateSerializer.class)
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the cipoServiceFaultOrigin
     */
    public boolean isCipoServiceFaultOrigin() {
        return cipoServiceFaultOrigin;
    }

    /**
     * @param cipoServiceFaultOrigin the cipoServiceFaultOrigin to set
     */
    public void setCipoServiceFaultOrigin(boolean cipoServiceFaultOrigin) {
        this.cipoServiceFaultOrigin = cipoServiceFaultOrigin;
    }

    /** {@inheritDoc} */
    @Override
    public int compareTo(BusinessErrorLogItem o) {
        return this.getCreatedDate().compareTo(o.getCreatedDate()) * -1;
    }

}
