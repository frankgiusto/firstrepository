package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.assertEquals;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.IdentityService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import util.TestMadridMethodVarsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class MultiInstanceTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private IdentityService identityService;

	@Autowired
	private TaskService taskService;

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Autowired
	@Rule
	public ActivitiRule activitiSpringRule;

	private ProcessInstance startProcessInstance(Map<String, Object> processVars) {

		return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("multiInstanceTest", processVars);
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/MultiInstanceTest.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn" })
	public void testDiagram() throws InterruptedException {

		LOG.debug("Test (testDiagram) started.");
		this.methodVarsService.reset();

		Map<String, Object> processVars = new HashMap<String, Object>();
		List<Integer> numCollection = new ArrayList<Integer>();
		numCollection.add(new Integer(1));
		numCollection.add(new Integer(2));
		numCollection.add(new Integer(3));

		processVars.put("numCollection", numCollection);

		ProcessInstance processInstance = startProcessInstance(processVars);

		String id = processInstance.getId();
		LOG.debug("Waiting for UserTask completion... ");
		Thread.sleep(5000);

		List<Task> tasks = processEngine.getTaskService().createTaskQuery().list();

		LOG.debug(tasks.size() + " tasks found");

		// assertEquals(tasks.size(), 3);

		while (!tasks.isEmpty()) {

			Task task = tasks.get(0);

			LOG.debug("Completing Task -> Id:[" + task.getId() + "]");
			taskService.complete(task.getId());

			tasks = processEngine.getTaskService().createTaskQuery().list();

		}

		tasks = processEngine.getTaskService().createTaskQuery().list();
		assertEquals(tasks.size(), 0);

		LOG.debug("Test complete.");
	}

	// @Test
	public void testSendSignal() throws InterruptedException {

		LOG.debug("Test (testSendSignal) started.");
		this.methodVarsService.reset();

		String execId = "237503";

		this.processEngine.getRuntimeService().signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_RECOVERY, execId);

		Thread.sleep(1000);

		ProcessInstance subProcessInstance = runtimeService.createProcessInstanceQuery().superProcessInstanceId(execId)
				.singleResult();

		Task task = this.processEngine.getTaskService().createTaskQuery().processInstanceId(execId).singleResult();

		if (task != null) {
			this.processEngine.getTaskService().complete(task.getId());
		}

		// Look for Tasks and complete them

		LOG.debug("Test complete.");
	}

	// @Test
	public void testCompleteTask() throws InterruptedException {

		LOG.debug("Test (testSendSignal) started.");
		this.methodVarsService.reset();

		String taskId = "282507";

		this.processEngine.getTaskService().complete(taskId);

		// Look for Tasks and complete them

		LOG.debug("Test complete.");
	}

	// @Test
	public void testFetchTask() throws InterruptedException {

		LOG.debug("Test (testSendSignal) started.");
		this.methodVarsService.reset();

		String taskId = "e5d29e3b-7975-11e8-82d0-2c4d544c0c89";

		Task task = this.processEngine.getTaskService().createTaskQuery().taskId(taskId).singleResult();
		Execution exec = this.processEngine.getRuntimeService().createExecutionQuery()
				.executionId(task.getExecutionId()).singleResult();

		ProcessInstance proc = this.processEngine.getRuntimeService().createProcessInstanceQuery()
				.processInstanceId(exec.getProcessInstanceId()).includeProcessVariables().singleResult();

		Object obj = proc.getProcessVariables();

		// Look for Tasks and complete them

		LOG.debug("Test complete.");
	}

}
