package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FEE_STATUS_UPDATE_INDICATOR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RUNNING_ERROR_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPDATE_FINANCIAL_FEE_STATUS;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionUpdateFeeStatusServiceImpl;
import util.TestUtils;

/**
 * A test class for the {@code update_financial_fee_status.bpmn} workflow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class UpdateFinancialFeeStatusTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    protected TestFinancialTransactionUpdateFeeStatusServiceImpl testFinancialTransactionUpdateFeeStatusServiceImpl;

    @Before
    public void init() {
        testFinancialTransactionUpdateFeeStatusServiceImpl.setFetchFinSystemPackageTransactionsStatusReturnObject(null);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(null);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(null);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn"})
    public void happyPathTest() {
        System.out.println("#############################################");
        System.out.println("###             happyPathTest             ###");
        System.out.println("#############################################");

        testFinancialTransactionUpdateFeeStatusServiceImpl
            .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(COMPLETE);

        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(FIN_PACKAGE_ID, "FakePackage01");
        processVariables.put(FEE_STATUS_UPDATE_INDICATOR, Boolean.TRUE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPDATE_FINANCIAL_FEE_STATUS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "updateFinFeeStatusEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "packageStatusSetFeeUpdatedTask", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn"})
    public void packageTransactionFetchFailTest() {
        System.out.println("#############################################");
        System.out.println("###    packageTransactionFetchFailTest    ###");
        System.out.println("#############################################");

        testFinancialTransactionUpdateFeeStatusServiceImpl
            .setFetchFinSystemPackageTransactionsStatusReturnObject(ERROR);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(COMPLETE);

        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(FIN_PACKAGE_ID, "FakePackage01");
        processVariables.put(FEE_STATUS_UPDATE_INDICATOR, Boolean.TRUE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPDATE_FINANCIAL_FEE_STATUS, runtimeService,
            processVariables);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "updateFeeStatusTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "updateFinFeeStatusEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn"})
    public void recoverableErrorTest() {
        System.out.println("#############################################");
        System.out.println("###          recoverableErrorTest         ###");
        System.out.println("#############################################");

        testFinancialTransactionUpdateFeeStatusServiceImpl
            .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(ERROR);

        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(FIN_PACKAGE_ID, "FakePackage01");
        processVariables.put(FEE_STATUS_UPDATE_INDICATOR, Boolean.TRUE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPDATE_FINANCIAL_FEE_STATUS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "updateFeeStatusTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "updateFinFeeStatusEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "packageStatusSetFeeUpdatedTask", 0);
        List<HistoricVariableInstance> histList = historyService.createHistoricVariableInstanceQuery()
            .variableName(RUNNING_ERROR_MESSAGE).list();
        Assert.assertTrue(histList != null && !histList.isEmpty());
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn"})
    public void nonrecoverableErrorTest() {
        System.out.println("#############################################");
        System.out.println("###        nonrecoverableErrorTest        ###");
        System.out.println("#############################################");

        testFinancialTransactionUpdateFeeStatusServiceImpl
            .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(ERROR);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(ERROR);

        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(FIN_PACKAGE_ID, "FakePackage01");
        processVariables.put(FEE_STATUS_UPDATE_INDICATOR, Boolean.TRUE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPDATE_FINANCIAL_FEE_STATUS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "updateFeeStatusTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "updateFinFeeStatusEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/update_financial_fee_status.bpmn"})
    public void updateStateFailTest() {
        System.out.println("#############################################");
        System.out.println("###          updateStateFailTest          ###");
        System.out.println("#############################################");

        testFinancialTransactionUpdateFeeStatusServiceImpl
            .setFetchFinSystemPackageTransactionsStatusReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setRecoverableConditionReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setUpdateFeeStatusStatusReturnObject(COMPLETE);
        testFinancialTransactionUpdateFeeStatusServiceImpl.setFeeStatusUpdateStatusReturnObject(ERROR);

        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(FIN_PACKAGE_ID, "FakePackage01");
        processVariables.put(FEE_STATUS_UPDATE_INDICATOR, Boolean.TRUE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(UPDATE_FINANCIAL_FEE_STATUS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "updateFinFeeStatusEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "packageStatusSetFeeUpdatedTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorEndEvent", 1);
    }
}
