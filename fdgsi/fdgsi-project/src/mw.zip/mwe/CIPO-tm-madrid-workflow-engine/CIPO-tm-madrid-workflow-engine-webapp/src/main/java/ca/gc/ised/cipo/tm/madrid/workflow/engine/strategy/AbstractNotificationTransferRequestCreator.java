package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;

import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * A common parent to the notification package strategies.
 *
 * @see AbstractWipoInboundTransferRequestCreator
 *
 * @author J. Greene
 *
 */
public abstract class AbstractNotificationTransferRequestCreator extends AbstractWipoInboundTransferRequestCreator {

    /**
     * {@inheritDoc}
     *
     * <p>
     * Evaluates the execution parameters to see if an exact file name was provided. If so, it will create a regular
     * expression that simply checks for the exact name regardless of case. Otherwise, it will base the regex on the
     * name of the last file downloaded.
     */
    @Override
    protected void setParamCollection(List<TransferRequestParamXsd> paramList, DelegateExecution execution,
                                      DownloadLogItem lastdownloadLogItem) {
        TransferRequestParamXsd remoteDirParam = new TransferRequestParamXsd();
        remoteDirParam.setParameterCode(ParamNameCode.REMOTE_DIR.codeValue());
        remoteDirParam.setParameterValue(getRemoteDir());
        paramList.add(remoteDirParam);

        String fileNameParameter = execution.getVariable(ProcessFlowConstants.REMOTE_FILE_NAME, String.class);

        TransferRequestParamXsd fileRegexParam = new TransferRequestParamXsd();
        fileRegexParam.setParameterCode(ParamNameCode.FILE_REGEX.codeValue());
        if (StringUtils.isNotBlank(fileNameParameter)) {
            fileRegexParam.setParameterValue("(?i)" + fileNameParameter);
        } else {
            fileRegexParam
                .setParameterValue(getRemoteFileRegex(lastdownloadLogItem.getFileName(), getRegexForTransactionType()));
        }
        paramList.add(fileRegexParam);
    }

    /**
     * Builds a regular expression that will be used by DTF to get the next file in sequence from WIPO. The expression
     * is complicated by WIPO's odd and inconsistent use of the leap week calendar system that results in our inability
     * to predict the next file name in sequence past the 52nd week of the year.
     *
     * @param previousFileName the file name of the previously downloaded weekly bulletin used as the base for the
     *            computation. This method expect the parameter to have the format 'x' + 4-digit year + 2-digit week
     *            number plus '.zip'. ex. {@code x201701.zip}.
     * @param regexForTransactionType The regular expression for this particular transaction type.
     * @return the regex to send to DTF
     */
    protected String getRemoteFileRegex(String previousFileName, String regexForTransactionType) {
        StringBuilder remoteFileRegexBuilder = new StringBuilder("(?i)").append(getFileNameDiscriminator())
            .append("20");
        String remoteFileRegex = null;

        if (!previousFileName.matches(regexForTransactionType)) {
            throw new IllegalArgumentException("Invalid file name parameter.");
        }

        // Parse out the year, week info of the last file
        String yearString = previousFileName.substring(1, 5);
        String weekString = previousFileName.substring(5, 7);
        int weekInt = Integer.parseInt(weekString);
        int yearInt = Integer.parseInt(yearString);

        // First case: The week number is less than 52, look for next interval
        if (weekString.compareTo("52") < 0) {
            remoteFileRegexBuilder.append(yearString.substring(2))
                .append(StringUtils.leftPad(new Integer(++weekInt).toString(), 2, "0"));
        } else {
            // If the week is 52 or 53 (or greater, but that shouldn't happen) then check for next year + 01 OR current
            // year + (week+1)
            remoteFileRegexBuilder.append(yearString.substring(2)).append(++weekInt)
                .append(".ZIP|" + getFileNameDiscriminator()).append(++yearInt).append("01");
        }

        remoteFileRegexBuilder.append(".ZIP");
        remoteFileRegex = remoteFileRegexBuilder.toString();

        return remoteFileRegex;
    }

    /**
     * Returns a file name discriminator for the download package (i for images, X for XML).
     *
     * @return the discriminator
     */
    public abstract String getFileNameDiscriminator();

    /**
     * Returns the remote directory for the type of package
     *
     * @return the remote directory in String form
     */
    public abstract String getRemoteDir();

    /**
     * Returns the regular expression string related to this transaction type.
     *
     * @return the regex String
     */
    public abstract String getRegexForTransactionType();
}
