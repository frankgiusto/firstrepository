package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_FILE_UPLOAD_REQUEST_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPDATE_FEE_DROP_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.VERIFY_FIN_FILIE_UPLOAD_STATUS;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Test service implementation for the {@code send_reconciled_fees_to_financial_system.bpmn} workflow delegate execution
 * service.
 *
 * @author J. Greene
 *
 */
public class TestFinancialTransactionSubmitServiceImpl extends TestBusinessErrorHandlerImpl
    implements FinancialTransactionSubmitService {

    protected Integer updateFeeDropStatusReturnObject;

    protected Integer verifyFinFileUploadStatusReturnObject;

    protected Integer finFileUploadRequestStatus;

    protected Integer numberOfLoops;

    /** {@inheritDoc} */
    @Override
    public void createTransferRequestFeeXmlToIfms(DelegateExecution execution) {
        if (getFinFileUploadRequestStatus() != null) {
            execution.setVariable(FIN_FILE_UPLOAD_REQUEST_STATUS, getFinFileUploadRequestStatus());
        }
        System.out.println("[[createTransferRequestFeeXmlToIfms]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void verifyFeeXmlTransferRequest(DelegateExecution execution) {
        if (getVerifyFinFileUploadStatusReturnObject() != null) {
            execution.setVariable(VERIFY_FIN_FILIE_UPLOAD_STATUS, getVerifyFinFileUploadStatusReturnObject());
            if (getVerifyFinFileUploadStatusReturnObject().equals(INCOMPLETE)) {
                if (getNumberOfLoops() == null) {
                    setVerifyFinFileUploadStatusReturnObject(COMPLETE);
                } else {
                    if (getNumberOfLoops() > 0) {
                        setNumberOfLoops(getNumberOfLoops() - 1);
                        System.out.println("Number of wait loops remaining: " + getNumberOfLoops());
                    } else {
                        setVerifyFinFileUploadStatusReturnObject(COMPLETE);
                    }
                }
            }
        }
        System.out.println("[[verifyFeeXmlTransferRequest]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void updateFeeXmlDropStatus(DelegateExecution execution) {
        if (getUpdateFeeDropStatusReturnObject() != null) {
            execution.setVariable(UPDATE_FEE_DROP_STATUS, getUpdateFeeDropStatusReturnObject());
        }
        System.out.println("[[updateFeeXmlDropStatus]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void movePackageToFailFolder(DelegateExecution execution) {
        System.out.println("[[movePackageToFailFolder]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void cleanUp(DelegateExecution execution) {
        System.out.println("[[cleanUp]]: " + execution.getVariables());
    }

    /**
     * @return the updateFeeDropStatusReturnObject
     */
    public Integer getUpdateFeeDropStatusReturnObject() {
        return updateFeeDropStatusReturnObject;
    }

    /**
     * @param updateFeeDropStatusReturnObject the updateFeeDropStatusReturnObject to set
     */
    public void setUpdateFeeDropStatusReturnObject(Integer updateFeeDropStatusReturnObject) {
        this.updateFeeDropStatusReturnObject = updateFeeDropStatusReturnObject;
    }

    /**
     * @return the verifyFinFileUploadStatusReturnObject
     */
    public Integer getVerifyFinFileUploadStatusReturnObject() {
        return verifyFinFileUploadStatusReturnObject;
    }

    /**
     * @param verifyFinFileUploadStatusReturnObject the verifyFinFileUploadStatusReturnObject to set
     */
    public void setVerifyFinFileUploadStatusReturnObject(Integer verifyFinFileUploadStatusReturnObject) {
        this.verifyFinFileUploadStatusReturnObject = verifyFinFileUploadStatusReturnObject;
    }

    /**
     * @return the finFileUploadRequestStatus
     */
    public Integer getFinFileUploadRequestStatus() {
        return finFileUploadRequestStatus;
    }

    /**
     * @param finFileUploadRequestStatus the finFileUploadRequestStatus to set
     */
    public void setFinFileUploadRequestStatus(Integer finFileUploadRequestStatus) {
        this.finFileUploadRequestStatus = finFileUploadRequestStatus;
    }

    /**
     * @return the numberOfLoops
     */
    public Integer getNumberOfLoops() {
        return numberOfLoops;
    }

    /**
     * @param numberOfLoops the numberOfLoops to set
     */
    public void setNumberOfLoops(Integer numberOfLoops) {
        this.numberOfLoops = numberOfLoops;
    }

}
