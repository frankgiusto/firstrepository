package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.ActivitiHistoryPurgeDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;

/**
 * A log manager run at regular intervals to clean up old data in MWE specific log tables
 *
 * @author J. Greene
 *
 */
@Component
public class MweDataCleanupManager {

    @Autowired
    protected PackageDownloadLogService packageDownloadLogService;

    @Autowired
    protected BusinessErrorLogService businessErrorLogService;

    @Autowired
    protected ActivitiHistoryPurgeDao activitiHistoryPurgeDao;

    @Autowired
    protected TaskScheduler taskScheduler;

    @Value("${mwe.madrid.log.schedule.cron.string:0 0 6 ? * FRI}")
    private String cronString;

    @Value("${mwe.madrid.package.download.log.retention.days:90}")
    private String downloadLogPurgePeriod;

    @Value("${mwe.madrid.business.error.log.retention.days.days:90}")
    private String businessErrorLogPurgePeriod;

    @Value("${mwe.activiti.history.retention.days:90}")
    private String activitiHistoryPurgePeriod;

    private static final Logger LOG = LoggerFactory.getLogger(MweDataCleanupManager.class);

    @PostConstruct
    public void cleanUpLogData() {
        Trigger cronTrigger = new CronTrigger(cronString);

        LOG.debug("Initializing scheduled task for cleaning up of MWE business related log items.  Cron interval : ["
            + cronString + "]");

        taskScheduler.schedule(new Runnable() {

            @Override
            public void run() {
                packageDownloadLogService.purgeOldLogEntries(Integer.parseInt(downloadLogPurgePeriod));
                businessErrorLogService.purgeOldBusinessErrorLogEntries(Integer.parseInt(businessErrorLogPurgePeriod));
                activitiHistoryPurgeDao.purgeOldHistoryEntries(Integer.parseInt(activitiHistoryPurgePeriod));
            }
        }, cronTrigger);

    }

}
