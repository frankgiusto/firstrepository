package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_FILE_UPLOAD_REQUEST_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_UPLOAD_FILE_NAME;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_UPLOAD_STAGING_FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_UPLOAD_STAGING_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQ_ID_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPDATE_FEE_DROP_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.VERIFY_FIN_FILIE_UPLOAD_STATUS;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.patents.dtf.trs.CreateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.GetTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestStateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.model.RequestStateCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.UpdatePackageStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.FinancialTransactionSubmitService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.OutFinFeesTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * Service class for the upload of reconciled financial transactions subprocess call activity for the financial flow.
 *
 * @author J. Greene
 * @see FinancialTransactionReconcileServiceImpl
 */
@Service
public class FinancialTransactionSubmitServiceImpl extends BusinessErrorHandlerImpl
    implements FinancialTransactionSubmitService, Serializable {

    private static final long serialVersionUID = 5121504188336800675L;

    @Autowired
    DtfServiceManager dtfServiceManager;

    @Autowired
    MpsServiceManager mpsServiceManager;

    /**
     * {@inheritDoc}
     * <p>
     * Calls the operation to initiate a transfer request to upload the financial package to the financial system. The
     * variable {@code finFileUploadRequestStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an exception occurred<br/>
     * </p>
     */
    @Override
    public void createTransferRequestFeeXmlToIfms(DelegateExecution execution) {
        Integer finFileUploadRequestStatus = COMPLETE;

        OutFinFeesTransferRequestCreator txCreator = new OutFinFeesTransferRequestCreator();

        try {
            CreateTransferRequest outgoingTransferRequest = txCreator.createOutgoingTransferRequest(execution);

            CreateResponse response = dtfServiceManager.createTransferRequest(outgoingTransferRequest);

            String transferRequestId = response.getTransferRequest().getRequestId();
            if (StringUtils.isBlank(transferRequestId)) {
                registerGenericMweBusinessError(execution, "No transfer request ID was returned from service!");
                finFileUploadRequestStatus = ERROR;
            } else {
                execution.setVariableLocal(TRANSFER_REQ_ID_VAR, transferRequestId);
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            finFileUploadRequestStatus = ERROR;
        } catch (IOException ioe) {
            registerGenericMweBusinessError(execution, "Cannot create the upload data for the transfer request!", ioe);
            finFileUploadRequestStatus = ERROR;
        }

        execution.setVariableLocal(FIN_FILE_UPLOAD_REQUEST_STATUS, finFileUploadRequestStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Verifies the DTF upload process and reports on the progress and the sets the process variable
     * {@code verifyFinFileUploadStatus} according to the outcome of the verification:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [   0]} if incomplete,<br/>
     * {@code [  -1]} if an exception occurred (no retry), <br/>
     */
    @Override
    public void verifyFeeXmlTransferRequest(DelegateExecution execution) {
        TransferRequestStateXsd inputState = new TransferRequestStateXsd();
        String requestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);
        inputState.setRequestId(requestId);
        Integer verifyFinFileUploadStatus = COMPLETE;

        GetTransferRequestState request = new GetTransferRequestState();
        request.setRacfUser(MweWorkflowUtil.getRacfUser());
        request.setTransferRequestState(inputState);

        try {
            TransferRequestStateResponse response = dtfServiceManager.getTransferRequestState(request);

            RequestStateCode returnedStateCode = RequestStateCode
                .getEnumByCodeValue(response.getTxRequestState().getStateCode());
            if (returnedStateCode == null) {
                registerGenericMweBusinessError(execution, "Request State Code ["
                    + response.getTxRequestState().getStateCode() + "] is unknown to this application.");
                verifyFinFileUploadStatus = ERROR;
            } else {
                switch (returnedStateCode) {
                    case FAILED:
                    case CANCELLED:
                        BusinessErrorLogItem businessErrorLogItem = dtfServiceManager
                            .createBusinessErrorLogItem(response);
                        businessErrorLogItem.setMessage("DTF Transfer for request #" + requestId + " failed.");
                        execution.setVariable(ERR_MSG_OBJECT_VAR, businessErrorLogItem);
                        verifyFinFileUploadStatus = ERROR;
                        LOG.info("Transfer request #" + requestId + " failed.");
                        break;
                    case IN_PROGRESS:
                    case INITIATED:
                    case READY_FOR_PROCESSING:
                        verifyFinFileUploadStatus = INCOMPLETE;
                        LOG.info("Transfer request #" + requestId + " is incomplete.");
                        break;
                    case COMPLETED:
                        verifyFinFileUploadStatus = COMPLETE;
                        LOG.info("Transfer request #" + requestId + " succeeded!");
                        break;
                    default:
                        // No handling available for other edge cases
                        registerGenericMweBusinessError(execution,
                            "Unable to process the DTF transfer state [" + returnedStateCode.codeValue() + "]");
                        verifyFinFileUploadStatus = ERROR;
                }
            }

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            verifyFinFileUploadStatus = ERROR;
        }

        execution.setVariable(VERIFY_FIN_FILIE_UPLOAD_STATUS, verifyFinFileUploadStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * The process flow variable {@code updateFeeDropStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an exception occurred<br/>
     * </p>
     */
    @Override
    public void updateFeeXmlDropStatus(DelegateExecution execution) {
        Integer updateFeeDropStatus = COMPLETE;

        BigDecimal packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);
        try {
            UpdatePackageStatusType droppedUpdateType = new UpdatePackageStatusType();
            droppedUpdateType.setPackageId(packageId);
            droppedUpdateType.setPackageStatusType(PackageStatusEnum.MADRID_FEE_PKG_RECONCILED_SENT);
            mpsServiceManager.updatePackageStatus(droppedUpdateType);
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            updateFeeDropStatus = ERROR;
        }

        execution.setVariable(UPDATE_FEE_DROP_STATUS, updateFeeDropStatus);
    }

    /** {@inheritDoc} */
    @Override
    public void movePackageToFailFolder(DelegateExecution execution) {
        String failFolder = execution.getVariable(FIN_PKG_UPLOAD_STAGING_FAIL_FOLDER, String.class);
        String packageLocation = execution.getVariable(FIN_PKG_UPLOAD_STAGING_FOLDER, String.class);
        String packageName = execution.getVariable(FIN_PKG_UPLOAD_FILE_NAME, String.class);
        Path packageFileLocationPath = Paths.get(packageLocation, packageName);
        File packageLocationFile = packageFileLocationPath.toFile();

        if (packageLocationFile != null) {
            try {
                MweWorkflowUtil.moveFile(packageLocationFile, failFolder);
            } catch (IOException ioe) {
                LOG.warn("Could not move file [" + packageLocation + "] to failure folder [" + failFolder + "].");
            }
        }
    }

    /** {@inheritDoc} */
    @Override
    public void cleanUp(DelegateExecution execution) {
        String packageLocation = execution.getVariable(FIN_PKG_UPLOAD_STAGING_FOLDER, String.class);
        String packageName = execution.getVariable(FIN_PKG_UPLOAD_FILE_NAME, String.class);
        Path packageFileLocationPath = Paths.get(packageLocation, packageName);
        try {
            Files.deleteIfExists(packageFileLocationPath);
        } catch (IOException ioe) {
            LOG.warn("Could not clean up (remove) file [" + packageLocation + "] upon successful upload.");
        }
    }

}
