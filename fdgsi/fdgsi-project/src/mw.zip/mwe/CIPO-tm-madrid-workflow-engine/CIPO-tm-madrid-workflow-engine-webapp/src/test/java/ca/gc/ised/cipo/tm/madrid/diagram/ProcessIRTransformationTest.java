package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.*;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.IdentityService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;

import util.TestMadridMethodVarsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MadridWorkflowTestConfiguration.class})
public class ProcessIRTransformationTest {

    protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private ProcessEngine processEngine;

    @Autowired
    private IdentityService identityService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private TestMadridMethodVarsService methodVarsService;

    @Autowired
    @Rule
    public ActivitiRule activitiSpringRule;

    private ProcessInstance startProcessInstance(Map<String, Object> processVars) {

        return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("processIRTransformation", processVars);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.13_ProcessIRTransformation.bpmn"})
    public void testDiagram() throws InterruptedException {

        LOG.debug("Test (processIRTransformation) started.");
        this.methodVarsService.reset();

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("irTranId", "12805");

        ProcessInstance processInstance = startProcessInstance(processVars);

        String id = processInstance.getId();
        LOG.debug("Waiting for first UserTask completion... ");
        Thread.sleep(1000);

        String taskId = null;
        List<Task> tasks = null;
        Map<String, Object> taskVars = null;
        List<IdentityLink> taskIdenLinks = null;
        IdentityLink link = null;

        // Verify the first task was created
        tasks = processEngine.getTaskService().createTaskQuery().list();
        if (tasks != null && !tasks.isEmpty()) {
            taskId = tasks.get(0).getId();
        }

        assertNotNull(taskId);

        // Verify the task has local variables assigned.
        taskVars = processEngine.getTaskService().getVariablesLocal(taskId);

        assertFalse(taskVars.isEmpty());
        assertEquals(taskVars.get(ProcessFlowConstants.CONSOLE_TASK_TYPE), "PROCESS_IR_TRANSFORMATION");

        // Verify we can retrieve the task based on local variables
        tasks = processEngine.getTaskService().createTaskQuery()
            .taskVariableValueEquals(ProcessFlowConstants.CONSOLE_TASK_TYPE, "PROCESS_IR_TRANSFORMATION").list();

        assertFalse(tasks.isEmpty());

        // Verify the Tasks are properly assigned.
        taskIdenLinks = taskService.getIdentityLinksForTask(taskId);

        assertFalse(taskIdenLinks.isEmpty());

        assertEquals(taskIdenLinks.get(0).getGroupId(), "MC_TM_EXAMINER");

        // Complete the second Task
        taskService.claim(taskId, "userid");
        taskService.complete(taskId);
        Thread.sleep(1000);

        LOG.debug("Waiting for second UserTask completion... ");

        // Verify the second task was created
        tasks = processEngine.getTaskService().createTaskQuery().list();
        if (tasks != null && !tasks.isEmpty()) {
            taskId = tasks.get(0).getId();
        }

        assertNotNull(taskId);

        // Verify the task has local variables assigned.
        taskVars = processEngine.getTaskService().getVariablesLocal(taskId);

        assertFalse(taskVars.isEmpty());

        // Verify we can retrieve the task based on local variables
        tasks = processEngine.getTaskService().createTaskQuery()
            .taskVariableValueEquals(ProcessFlowConstants.CONSOLE_TASK_TYPE, "CONFIRM_IR_TRANSFORMATION").list();

        assertFalse(tasks.isEmpty());

        // Verify the Tasks are properly assigned.
        taskIdenLinks = taskService.getIdentityLinksForTask(taskId);

        assertFalse(taskIdenLinks.isEmpty());

        assertEquals(taskIdenLinks.get(0).getGroupId(), "MC_TM_EXAMINER");

        // Complete the second Task
        taskService.claim(taskId, "userid");
        taskService.complete(taskId);

        LOG.debug("Test complete.");
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.13_ProcessIRTransformation.bpmn"})
    public void testError() throws InterruptedException {

        LOG.debug("Test (testError) started.");
        this.methodVarsService.reset();

        // This will cause the test methods indicated to set the listed
        // variables
        this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.checkForExistingMarks",
            ProcessFlowConstants.ERR_MSG_IND_VAR, new Boolean(true));
        this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.checkForExistingMarks",
            ProcessFlowConstants.ERR_MSG_DESC_VAR, "An error occurred checking Marks.");

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put("irTranId", "12805");

        ProcessInstance processInstance = null;

        try {

            processInstance = startProcessInstance(processVars);

        } catch (Exception e) {

            assertNotNull(e);

        }

        LOG.debug("Test complete.");
    }

}
