package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_OUTGOING_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATION_VERIFICATION_POLL_INTERVAL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NUMBER_OF_REATTEMPTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUTPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUT_DAILY_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RUNNING_ERROR_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_VERIFICATION_POLL_INTERVAL;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestCreateOutgoingTransactionsServiceImpl;
import util.TestUtils;

/**
 * Test class for the create_madrid_transactions_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class CreateOutgoingTransactionsTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    protected TestCreateOutgoingTransactionsServiceImpl testCreateOutgoingTransactionsServiceImpl;

    @Before
    public void init() {
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(null);
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(null);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(null);

        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(null);
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(null);
        testCreateOutgoingTransactionsServiceImpl.setCreateManualMessagesStatusReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testEntireFlowHappyPath() {
        System.out.println("#############################################");
        System.out.println("###        testEntireFlowHappyPath        ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateManualMessagesStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask",
            automatedMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", manualMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 1);

        TestUtils.assertCompletion(historyService, testInstance);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn"})
    public void testErrorEvent1() {
        System.out.println("#############################################");
        System.out.println("###            testErrorEvent1            ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "fetchAutomatedChangesError", 1);
        TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 0);

        TestUtils.assertCompletion(historyService, testInstance);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn"})
    public void testErrorEvent2() {
        System.out.println("#############################################");
        System.out.println("###            testErrorEvent2            ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(ERROR);
        testCreateOutgoingTransactionsServiceImpl.setRecoverableConditionReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "processAutomatedChangeErrorEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 0);

        TestUtils.assertCompletion(historyService, testInstance);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn"})
    public void testErrorEvent3() {
        System.out.println("#############################################");
        System.out.println("###            testErrorEvent3            ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "fetchManualChangesError", 1);
        TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask",
            automatedMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 0);

        TestUtils.assertCompletion(historyService, testInstance);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn"})
    public void testErrorEvent4() {
        System.out.println("#############################################");
        System.out.println("###            testErrorEvent4            ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateManualMessagesStatusReturnObject(ERROR);
        testCreateOutgoingTransactionsServiceImpl.setRecoverableConditionReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "processManualChangeErrorEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask",
            automatedMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 0);

        TestUtils.assertCompletion(historyService, testInstance);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testIterativeErrorRecoverable1() {
        System.out.println("#############################################");
        System.out.println("###     testIterativeErrorRecoverable1    ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(ERROR);
        testCreateOutgoingTransactionsServiceImpl.setRecoverableConditionReturnObject(COMPLETE);

        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateManualMessagesStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask",
            automatedMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", manualMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "handleAutomatedIterativeErrorTask",
            automatedMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 1);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricVariableInstance> histList = historyService.createHistoricVariableInstanceQuery()
            .variableName(RUNNING_ERROR_MESSAGE).list();
        assertTrue(histList != null && !histList.isEmpty());
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testIterativeErrorRecoverable2() {
        System.out.println("#############################################");
        System.out.println("###     testIterativeErrorRecoverable2    ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = Arrays.asList(new String[]{"Blah1", "Blah2"});
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = Arrays.asList(new String[]{"Blah3", "Blah4"});
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(COMPLETE);

        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateManualMessagesStatusReturnObject(ERROR);
        testCreateOutgoingTransactionsServiceImpl.setRecoverableConditionReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask",
            automatedMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask", manualMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "handleManualIterativeErrorTask", manualMessageList.size());
        TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 1);

        TestUtils.assertCompletion(historyService, testInstance);

        List<HistoricVariableInstance> histList = historyService.createHistoricVariableInstanceQuery()
            .variableName(RUNNING_ERROR_MESSAGE).list();
        assertTrue(histList != null && !histList.isEmpty());
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/package_madrid_transactions_to_wipo.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/export/upload_madrid_packages_to_wipo.bpmn"})
    public void testHappyPathWithLoad() {
        System.out.println("#############################################");
        System.out.println("###         testHappyPathWithLoad         ###");
        System.out.println("#############################################");

        Map<String, Object> processVariables = getTypicalProcessVars();

        List<String> automatedMessageList = getMessageList(200);
        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageCollection(automatedMessageList);

        List<String> manualMessageList = getMessageList(100);
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageCollection(manualMessageList);

        testCreateOutgoingTransactionsServiceImpl.setPendingAutomatedMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateAutomatedMessagesStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setPendingManualMessageStatusReturnObject(COMPLETE);
        testCreateOutgoingTransactionsServiceImpl.setCreateManualMessagesStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(CREATE_OUTGOING_TRANSACTIONS, runtimeService,
            processVariables);
        boolean processTimedOut = false;

        try {
            JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);
        } catch (ActivitiException e) {
            if (e.getMessage().equals("time limit of 120000 was exceeded")) {
                // What is actually expected
                processTimedOut = true;
            } else {
                // What happens when "Asynchronous" is unchecked from key Service Tasks
                throw e;
            }
        }

        if (!processTimedOut) {
            // What should happen, if it didn't time out (like "testEntireFlowHappyPath")
            TestUtils.assertActivitiEventFired(historyService, "createPersistAutomatedChangeTask",
                automatedMessageList.size());
            TestUtils.assertActivitiEventFired(historyService, "createPersistManualChangeTask",
                manualMessageList.size());
            TestUtils.assertActivitiEventFired(historyService, "createMessagesToWipoEndEvent", 1);

            TestUtils.assertCompletion(historyService, testInstance);
        }
    }

    private List<String> getMessageList(int nbMessages) {
        List<String> messageList = new ArrayList<>();

        for (int i = 0; i < nbMessages; i++) {
            messageList.add("Blah" + i);
        }
        return messageList;
    }

    private Map<String, Object> getTypicalProcessVars() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(TRANSFER_ITEM, OUT_DAILY_PKG);
        processVariables.put(OUTPUT_FOLDER, "/c/path/to/output");
        processVariables.put(FAIL_FOLDER, "/c/path/to/output");
        processVariables.put(NUMBER_OF_REATTEMPTS, 0);
        processVariables.put(CREATION_VERIFICATION_POLL_INTERVAL, "PT1S");
        processVariables.put(UPLOAD_VERIFICATION_POLL_INTERVAL, "PT1S");
        return processVariables;
    }

    private void sleep(int seconds) {
        // Simulate a small delay in processing
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private int signalToSubprocess(String activityId) {
        List<Execution> executionList = runtimeService.createExecutionQuery().list();
        int nbSignals = 0;

        for (Execution execution : executionList) {
            Execution signalExec = runtimeService.createExecutionQuery().executionId(execution.getId())
                .activityId(activityId).singleResult();

            if (signalExec != null) {
                runtimeService.signal(signalExec.getId());
                nbSignals++;
            }
        }
        return nbSignals;
    }

}
