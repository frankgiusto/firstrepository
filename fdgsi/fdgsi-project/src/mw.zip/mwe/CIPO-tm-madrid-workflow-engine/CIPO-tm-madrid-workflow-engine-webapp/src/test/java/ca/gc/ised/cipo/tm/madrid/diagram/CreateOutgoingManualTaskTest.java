package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.IdentityService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import util.TestMadridMethodVarsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MadridWorkflowTestConfiguration.class})
public class CreateOutgoingManualTaskTest {

    protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private ProcessEngine processEngine;

    @Autowired
    private IdentityService identityService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private TestMadridMethodVarsService methodVarsService;

    @Autowired
    @Rule
    public ActivitiRule activitiSpringRule;

    private ProcessInstance startProcessInstance(Map<String, Object> processVars) {

        return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("createOutgoingManualTask",
            processVars);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_outgoing_manual_task.bpmn"})
    public void testDiagram() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testDiagram) started.");
        LOG.debug("------------");
        this.methodVarsService.reset();

        // This causes the groupId to be set.
        // this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.createConsoleTask",
        // ProcessFlowConstants.CANDIDATE_GROUP_ID, "BEST_GROUP");

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, new BigDecimal("12345"));

        ProcessInstance processInstance = startProcessInstance(processVars);

        String id = processInstance.getId();
        LOG.debug("Waiting for UserTask completion... ");
        Thread.sleep(1000);

        String taskId = null;

        List<Task> tasks = processEngine.getTaskService().createTaskQuery().list();
        if (tasks != null && !tasks.isEmpty()) {
            taskId = tasks.get(0).getId();
        }

        assertNotNull(taskId);

        List<IdentityLink> taskIdenLinks = taskService.getIdentityLinksForTask(taskId);
        IdentityLink link = taskIdenLinks.get(0);

        String groupId = link.getGroupId();

        assertEquals(groupId, "MC_TM_EXAMINER");

        taskService.complete(taskId);

        LOG.debug("Test complete.");
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_outgoing_manual_task.bpmn"})
    public void testMTSError() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testMTSError) started.");
        LOG.debug("------------");
        this.methodVarsService.reset();

        // This causes the syncConsoleTask to create an error
        this.methodVarsService.setMethodVar("TestMadridListenerServiceImpl.syncConsoleTask",
            ProcessFlowConstants.MTS_ERROR, new Boolean(true));

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, new BigDecimal("12345"));

        ProcessInstance processInstance = startProcessInstance(processVars);

        Thread.sleep(2000);
        LOG.debug("Completing signals... ");

        List<Task> tasks = taskService.createTaskQuery().list();

        assertTrue(tasks.isEmpty());

        List<Execution> execs = runtimeService.createExecutionQuery()
            .signalEventSubscriptionName(ProcessFlowConstants.SIGNAL_MTS_RECOVERY).list();

        assertEquals(execs.size(), 1);
        String execId = execs.get(0).getId();

        // No errors on syncConsoleTask this time
        this.methodVarsService.setMethodVar("TestMadridListenerServiceImpl.syncConsoleTask",
            ProcessFlowConstants.MTS_ERROR, new Boolean(false));

        // Signal that MTS is back up
        runtimeService.signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_RECOVERY, execId);

        // We should have a task now.
        tasks = taskService.createTaskQuery().list();

        assertFalse(tasks.isEmpty());
        Task task = tasks.get(0);

        this.taskService.complete(task.getId());

        LOG.debug("Test complete.");
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_outgoing_manual_task.bpmn"})
    public void testTwoProcesses() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testTwoProcesses) started.");
        LOG.debug("------------");
        this.methodVarsService.reset();

        this.methodVarsService.setMethodVar("TestMadridListenerServiceImpl.syncConsoleTask",
            ProcessFlowConstants.MTS_ERROR, new Boolean(true));

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, new BigDecimal("12345"));

        LOG.debug("Start first process... ");
        ProcessInstance processInstance = startProcessInstance(processVars);
        String firstProcessId = processInstance.getProcessDefinitionId();
        Thread.sleep(1000);

        LOG.debug("Start second process... ");
        this.methodVarsService.reset();
        processInstance = startProcessInstance(processVars);
        Thread.sleep(1000);

        List<Task> tasks = taskService.createTaskQuery().list();

        assertEquals(tasks.size(), 1);

        List<Execution> execs = runtimeService.createExecutionQuery()
            .signalEventSubscriptionName(ProcessFlowConstants.SIGNAL_MTS_RECOVERY).list();

        assertEquals(execs.size(), 1);
        String execId = execs.get(0).getId();

        LOG.debug("Completing User Tasks... ");
        Thread.sleep(1000);

        this.taskService.claim(tasks.get(0).getId(), "someGuy");
        this.taskService.complete(tasks.get(0).getId());

        tasks = taskService.createTaskQuery().list();

        assertTrue(tasks.isEmpty());

        LOG.debug("Completing signals... ");
        Thread.sleep(1000);

        // Make sure the error isn't thrown this time.
        this.methodVarsService.setMethodVar("TestMadridListenerServiceImpl.syncConsoleTask",
            ProcessFlowConstants.MTS_ERROR, new Boolean(false));

        runtimeService.signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_RECOVERY, execId);

        execs = runtimeService.createExecutionQuery()
            .signalEventSubscriptionName(ProcessFlowConstants.SIGNAL_MTS_RECOVERY).list();

        assertTrue(execs.isEmpty());

        LOG.debug("Completing User Tasks... ");
        Thread.sleep(1000);

        tasks = taskService.createTaskQuery().list();
        this.taskService.claim(tasks.get(0).getId(), "someGuy");
        this.taskService.complete(tasks.get(0).getId());
        Thread.sleep(1000);

        LOG.debug("Test complete.");
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/export/create_outgoing_manual_task.bpmn"})
    public void testGroupAssignment() throws InterruptedException {

        LOG.debug("------------");
        LOG.debug("Test (testGroupAssignment) started.");
        LOG.debug("------------");

        String groupId = "MC_TM_SUPERVISOR";

        this.methodVarsService.reset();

        this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.createConsoleTask",
            ProcessFlowConstants.CANDIDATE_GROUP_ID, groupId);

        Map<String, Object> processVars = new HashMap<String, Object>();
        processVars.put(ProcessFlowConstants.CONSOLE_TASK_ID, new BigDecimal("12345"));
        processVars.put(ProcessFlowConstants.CANDIDATE_GROUP_ID, groupId);

        ProcessInstance processInstance = startProcessInstance(processVars);

        LOG.debug("Waiting for UserTask completion... ");
        Thread.sleep(2000);

        List<Task> tasks = taskService.createTaskQuery().list();

        assertFalse(tasks.isEmpty());

        Task task = tasks.get(0);
        List<IdentityLink> idLinks = this.taskService.getIdentityLinksForTask(task.getId());

        assertFalse(idLinks.isEmpty());

        IdentityLink idLink = idLinks.get(0);

        String assignedGroup = idLink.getGroupId();

        assertEquals(groupId, assignedGroup);

        LOG.debug("Test complete.");
    }

}
