package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.GAP_REPORT_EMAIL_NOTIFICATION_STATUS;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Test service implementation for the {@generate-financial-gap-reports.bpmn} workflow delegate execution service.
 *
 * @author J. Greene
 *
 */
public class TestFinancialTransactionGapReportGenerationServiceImpl extends TestBusinessErrorHandlerImpl
    implements FinancialTransactionGapReportGenerationService {

    protected Integer gapReportEmailNotificationStatusReturnObject;

    /** {@inheritDoc} */
    @Override
    public void sendGapReportNotification(DelegateExecution execution) {
        if (getGapReportEmailNotificationStatusReturnObject() != null) {
            execution.setVariable(GAP_REPORT_EMAIL_NOTIFICATION_STATUS,
                getGapReportEmailNotificationStatusReturnObject());
        }
        System.out.println("[[sendGapReportNotification]]: " + execution.getVariables());
    }

    /**
     * @return the gapReportEmailNotificationStatusReturnObject
     */
    public Integer getGapReportEmailNotificationStatusReturnObject() {
        return gapReportEmailNotificationStatusReturnObject;
    }

    /**
     * @param gapReportEmailNotificationStatusReturnObject the gapReportEmailNotificationStatusReturnObject to set
     */
    public void setGapReportEmailNotificationStatusReturnObject(Integer gapReportEmailNotificationStatusReturnObject) {
        this.gapReportEmailNotificationStatusReturnObject = gapReportEmailNotificationStatusReturnObject;
    }

}
