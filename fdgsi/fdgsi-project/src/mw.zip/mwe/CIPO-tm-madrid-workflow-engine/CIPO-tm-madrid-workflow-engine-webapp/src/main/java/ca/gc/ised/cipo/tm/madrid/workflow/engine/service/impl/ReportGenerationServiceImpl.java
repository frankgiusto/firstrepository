package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.POLL_REPORT_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_GENERATION_CALLING_UPDATE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_GENERATION_INITIATION_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_JOB_ID_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_TYPE_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RGS_ERROR_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.SERVICE_FAULT_SEVERITY_THRESHOLD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSACTION_ID;

import java.io.Serializable;
import java.math.BigDecimal;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.report.RuntimeJobState;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.RgsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.ReportGenerationService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.ReportTypeEnumResolver;

/**
 * A service implementation that will perform common actions related to report
 * generation within the various flows.
 *
 * @author J. Greene
 *
 */
@Service
public class ReportGenerationServiceImpl extends BusinessErrorHandlerImpl
		implements ReportGenerationService, Serializable {

	private static final long serialVersionUID = -6817027137879670872L;

	@Autowired
	protected RuntimeService runtimeService;

	@Autowired
	protected RgsServiceManager rgsServiceManager;

	@Autowired
	protected MtsServiceManager mtsServiceManager;

	@Autowired
	protected MfsServiceManager mfsServiceManager;

	protected static final Logger LOG = LoggerFactory.getLogger(ReportGenerationServiceImpl.class);

	/**
	 * {@inheritDoc}
	 * <p>
	 * This method will determine the type of report that needs generating and
	 * then call the associated service operation to commence. The operation
	 * will return the report identifier that will be used in subsequent calls
	 * to check for completeness. The flow variable
	 * {@code reportGenerationInitiationStatus} will be set accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 */
	@Override
	public void initiateReportGeneration(DelegateExecution execution) {
		ReportTypeEnumResolver reportType = execution.getVariable(REPORT_TYPE_VAR, ReportTypeEnumResolver.class);
		BigDecimal packageId = null;
		BigDecimal transactionId = null;
		String reportJobId = null;
		Integer reportGenerationInitiationStatus = COMPLETE;

		try {
			if (reportType.getTypeOfObject().equals(ReportTypeEnumResolver.TypeOfObject.MTS)) {
				transactionId = execution.getVariable(TRANSACTION_ID, BigDecimal.class);
				reportJobId = mtsServiceManager.generateReport(transactionId, reportType.getMtsReportType());
			} else if (reportType.getTypeOfObject().equals(ReportTypeEnumResolver.TypeOfObject.MFS)) {
				packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);
				// MFS-CLEAN-SPR5 reportJobId =
				// mfsServiceManager.generateReport(packageId,
				// reportType.getMfsReportType());
			}
			if (StringUtils.isBlank(reportJobId)) {
				registerGenericMweBusinessError(execution, "[reportJobId] was returned blank or null!");
				reportGenerationInitiationStatus = ERROR;
			} else {
				execution.setVariable(REPORT_JOB_ID_VAR, reportJobId);
			}
		} catch (BpmnWebServiceCallException bpe) {
			execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
			reportGenerationInitiationStatus = ERROR;
		}

		execution.setVariable(REPORT_GENERATION_INITIATION_STATUS, reportGenerationInitiationStatus);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * This method will poll the status of a report generation request by the
	 * report generation service via web service operation. The report job ID is
	 * passed by the calling WSO. The flow variable {@code pollReportStatus}
	 * will be set accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 * <p>
	 * See
	 * {@link ReportGenerationServiceImpl#initiateReportGeneration(DelegateExecution).
	 * </p>
	 */
	@Override
	public void pollReportService(DelegateExecution execution) {
		Integer pollReportStatus = null;
		String reportJobId = execution.getVariable(REPORT_JOB_ID_VAR, String.class);
		try {
			RuntimeJobState rgsJobState = rgsServiceManager.pollReportService(reportJobId);
			if (rgsJobState == null) {
				registerGenericMweBusinessError(execution, "[rgsJobState] was returned as null!");
				pollReportStatus = ERROR;
			} else {
				switch (rgsJobState) {
				case COMPLETE:
					pollReportStatus = COMPLETE;
					break;
				case WAITING:
				case EXECUTING:
				case INITIALIZING:
					pollReportStatus = INCOMPLETE;
					break;
				case ERROR:
					pollReportStatus = RGS_ERROR_STATUS;
					registerGenericMweBusinessError(execution, "RGS returned the state: [" + rgsJobState.name()
							+ "] for reportJobId [" + reportJobId + "]");
					break;
				default:
					registerGenericMweBusinessError(execution, "Workflow engine cannot process report job ["
							+ reportJobId + "] with an unrecognized status of [" + rgsJobState.name() + "]");
					pollReportStatus = ERROR;

				}
			}
		} catch (BpmnWebServiceCallException bpe) {
			execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
			pollReportStatus = ERROR;
		}

		execution.setVariable(POLL_REPORT_STATUS, pollReportStatus);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * This method will determine which web service operation to notify that a
	 * report is ready and waiting to be downloaded by the report generation
	 * service. The flow variable {@code reportGenerationCallingUpdateStatus}
	 * will be set accordingly:
	 * </p>
	 * <p>
	 * {@code [   1]} if complete,<br/>
	 * {@code [  -1]} if an error occurred<br/>
	 * </p>
	 */
	@Override
	public void updateCallingService(DelegateExecution execution) {
		ReportTypeEnumResolver reportType = execution.getVariable(REPORT_TYPE_VAR, ReportTypeEnumResolver.class);
		String reportJobId = execution.getVariable(REPORT_JOB_ID_VAR, String.class);
		BigDecimal packageId = null;
		BigDecimal transactionId = null;

		Integer reportGenerationCallingUpdateStatus = COMPLETE;

		try {
			BigDecimal txAttachId = null;
			if (reportType.getTypeOfObject().equals(ReportTypeEnumResolver.TypeOfObject.MTS)) {
				transactionId = execution.getVariable(TRANSACTION_ID, BigDecimal.class);
				txAttachId = mtsServiceManager.generateReportNotification(reportJobId, transactionId,
						reportType.getMtsReportType());
			} else if (reportType.getTypeOfObject().equals(ReportTypeEnumResolver.TypeOfObject.MFS)) {
				packageId = execution.getVariable(PACKAGE_ID, BigDecimal.class);
				// MFS-CLEAN-SPR5 txAttachId =
				// mfsServiceManager.generateReportNotification(reportJobId,
				// packageId,
				// reportType.getMfsReportType());
			}
			LOG.info("Report persisted with attachment ID " + txAttachId);
		} catch (BpmnWebServiceCallException bpe) {
			execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
			reportGenerationCallingUpdateStatus = ERROR;
		}

		execution.setVariable(REPORT_GENERATION_CALLING_UPDATE_STATUS, reportGenerationCallingUpdateStatus);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * We'll cumulate an error message based on the possibility of one to many
	 * events of this type. For example, of 100 reports to generate, 2 may
	 * result in an RGS error status. These would be cumulated and sent as one
	 * warning message rather than one per.
	 * </p>
	 */
	@Override
	public void handleRgsErrorStatus(DelegateExecution execution) {
		handleCumulativeError(execution, null);
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Evaluates the WS error thrown in
	 * {@link ReportGenerationService#updateCallingService(DelegateExecution)}
	 * or
	 * {@link ReportGenerationService#initiateReportGeneration(DelegateExecution)}
	 * . If severe enough (code <= established threshold) then kick it to the
	 * error handler. Otherwise, handle through the cumulative message mechanism
	 * and continue.
	 * </p>
	 */
	@Override
	public void evaluateCallbackErrorSeverity(DelegateExecution execution) {
		Integer recoverableErrorCondition = COMPLETE;

		BusinessErrorLogItem businessErrorLogItem = execution.getVariable(ERR_MSG_OBJECT_VAR,
				BusinessErrorLogItem.class);
		BigDecimal transactionId = execution.getVariable(TRANSACTION_ID, BigDecimal.class);

		if (!businessErrorLogItem.isCipoServiceFaultOrigin()) {
			recoverableErrorCondition = ERROR;
		} else {
			// Check the fault return code. If it falls below the threshold,
			// assume not recoverable.
			if (businessErrorLogItem.getReturnCode() <= SERVICE_FAULT_SEVERITY_THRESHOLD) {
				recoverableErrorCondition = ERROR;
				LOG.error("A non-recoverable error occurred while processing transaction # [" + transactionId + "]");
			} else {
				handleCumulativeError(execution, "TRANSACTION ID: " + transactionId);
			}
		}

		execution.setVariable(RECOVERABLE_ERROR_CONDITION, recoverableErrorCondition);
	}

}
