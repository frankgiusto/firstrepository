package ca.gc.ised.cipo.tm.madrid.workflow.engine.web.servlet;

import java.lang.invoke.MethodHandles;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRegistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.DispatcherServlet;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.workflow.conf.MadridEngineConfigurationImpl;
import ca.gc.ised.cipo.workflow.web.filter.WorkflowEngineRequestLoggingFilter;

/**
 * Configuration of the Madrid Workflow Engine web application using Servlet 3.0
 * APIs.
 *
 * @author J. Greene
 */
public class MweWebConfigurer implements ServletContextListener {

	private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	private final String appServiceUrlPattern = ProcessFlowConstants.MWE_SERVICE_NAME + "/service/*";

	public static final String DATA_SOURCE_JNDI_NAME = "jdbc/activiti-madrid";

	public static final String TIME_MANAGER_JNDI_NAME = "tm/activiti";

	public static final String WORK_MANAGER_JNDI_NAME = "wm/activiti";

	public AnnotationConfigWebApplicationContext context;

	public void setContext(AnnotationConfigWebApplicationContext context) {
		this.context = context;
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext servletContext = sce.getServletContext();

		log.debug("Configuring Spring root application context");

		AnnotationConfigWebApplicationContext rootContext = null;

		if (context == null) {
			rootContext = new AnnotationConfigWebApplicationContext();
			rootContext.register(MadridEngineConfigurationImpl.class);
			rootContext.refresh();
		} else {
			rootContext = context;
		}

		servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, rootContext);

		initSpring(servletContext, rootContext);
		initRequestLoggingFilter(servletContext);

		log.debug("Web application fully configured");
	}

	/**
	 * Initializes the filter responsible for HTTP request logging.
	 *
	 * @param servletContext
	 */
	private void initRequestLoggingFilter(ServletContext servletContext) {
		log.debug("Registering HTTP request logging filter");
		WorkflowEngineRequestLoggingFilter loggingFilter = new WorkflowEngineRequestLoggingFilter();
		loggingFilter.setIncludePayload(Boolean.TRUE);
		loggingFilter.setIncludeQueryString(Boolean.TRUE);
		loggingFilter.setIncludeClientInfo(Boolean.FALSE);
		loggingFilter.setIncludeHeaders(Boolean.TRUE);
		loggingFilter.setBeforeMessagePrefix(" [");
		loggingFilter.setAfterMessagePrefix(" [");
		FilterRegistration.Dynamic requestLoggingFilter = servletContext.addFilter("requestLoggingFilter",
				loggingFilter);

		requestLoggingFilter.addMappingForUrlPatterns(null, Boolean.TRUE, appServiceUrlPattern);
		requestLoggingFilter.setAsyncSupported(Boolean.TRUE);
	}

	/**
	 * Initializes Spring and Spring MVC.
	 */
	private ServletRegistration.Dynamic initSpring(ServletContext servletContext,
			AnnotationConfigWebApplicationContext rootContext) {
		log.debug("Configuring Spring Web application context");
		AnnotationConfigWebApplicationContext dispatcherServletContext = new AnnotationConfigWebApplicationContext();
		dispatcherServletContext.setParent(rootContext);
		dispatcherServletContext.register(DispatcherServletConfiguration.class);

		log.debug("Registering Spring MVC Servlet");
		ServletRegistration.Dynamic dispatcherServlet = servletContext.addServlet("dispatcher",
				new DispatcherServlet(dispatcherServletContext));
		dispatcherServlet.addMapping(appServiceUrlPattern);
		dispatcherServlet.setLoadOnStartup(1);
		dispatcherServlet.setAsyncSupported(Boolean.TRUE);

		return dispatcherServlet;
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		log.info("Destroying Web application");
		WebApplicationContext ac = WebApplicationContextUtils.getRequiredWebApplicationContext(sce.getServletContext());
		if (ac != null) {
			AnnotationConfigWebApplicationContext gwac = (AnnotationConfigWebApplicationContext) ac;
			gwac.close();
		}
		log.debug("Web application destroyed");
	}
}
