package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.IdentityService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.User;
import org.activiti.engine.identity.UserQuery;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MadridWorkflowTestConfiguration.class})
public class ProcessMadridDesignationServiceTest {

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private ProcessEngine processEngine;

    @Autowired
    private IdentityService identityService;

    @Autowired
    private TaskService taskService;

    @Autowired
    @Rule
    public ActivitiRule activitiSpringRule;

    private ProcessInstance startProcessInstance(String processKey) {

        return activitiSpringRule.getRuntimeService().startProcessInstanceByKey(processKey);
    }

    @Test
    public void testEngine() throws InterruptedException {

        // List<Event> events = runtimeService.getProcessInstanceEvents(
        // "aef9d9cb-0783-11e8-a616-9eeda28474f8" );
        //
        // for ( Event event : events ) {
        // System.out.println( "Event: " + event.getId() );
        // }
        String processInstanceId = "aef9d9cb-0783-11e8-a616-9eeda28474f8";

        // runtimeService.activateProcessInstanceById( processInstanceId );

        // ExecutionQuery exQuery =
        // runtimeService.createExecutionQuery().executionId( processInstanceId
        // )
        // .signalEventSubscription( null );
        // List<Execution> execs = exQuery.list();
        // for ( Execution execution : execs ) {
        // System.out.println( "Found: " + execution.toString() );
        // }

        // runtimeService.deleteProcessInstance( processInstanceId, "Old
        // process" );
        //
        // taskService.deleteTask( "afd3980b-0783-11e8-a616-9eeda28474f8", true
        // );
        // TaskQuery query = taskService.createTaskQuery().taskId(
        // "afd3980b-0783-11e8-a616-9eeda28474f8" );
        // Task someTask = query.singleResult();
        // someTask.

        // taskService.complete( "afd3980b-0783-11e8-a616-9eeda28474f8" );

        // assertFalse( idList.isEmpty() );

    }

    // @Test
    public void testFetchlTasksValues() throws InterruptedException {

        List<IdentityLink> idList = taskService.getIdentityLinksForTask("7783798b-051f-11e8-8258-2c4d544c0c89");

        assertFalse(idList.isEmpty());

    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/SimpleUserTaskTest.bpmn"})
    public void testFetchIdentityLinks() throws InterruptedException {

        this.startProcessInstance("simpleUserTask");

        Task validTask = taskService.createNativeTaskQuery().singleResult();

        List<IdentityLink> idList = taskService.getIdentityLinksForTask(validTask.getId());

        assertNotNull(idList);

        idList = taskService.getIdentityLinksForTask("some-fake-task-id");

        assertNull(idList);

    }

    // @Test
    public void testFetchAllTasks() throws InterruptedException {

        TaskQuery taskQuery = taskService.createTaskQuery();

        List<Task> tasks = taskQuery.list();

        assertFalse(tasks.isEmpty());
    }

    // @Test
    public void testFetchUserTasks() throws InterruptedException {

        TaskQuery taskQuery = taskService.createTaskQuery();
        taskQuery.taskAssignee("testUser");

        List<Task> tasks = taskQuery.list();

        assertFalse(tasks.isEmpty());
    }

    // @Test
    public void testFetchGroupTasks() throws InterruptedException {

        TaskQuery taskQuery = taskService.createTaskQuery();
        taskQuery.taskCandidateGroup("testGroup");

        List<Task> tasks = taskQuery.list();

        assertFalse(tasks.isEmpty());
    }

    // @Test
    public void testCreateUserAndGroup() throws InterruptedException {

        UserQuery userQuery = identityService.createUserQuery();

        List<User> users = userQuery.list();

        User user = identityService.newUser("testUser");
        try {
            identityService.saveUser(user);
        } catch (Exception e) {
            System.out.println("User already exists");
        }

        Group group = identityService.newGroup("testGroup");
        group.setName("Test Group");
        group.setType("testType");
        try {
            identityService.saveGroup(group);
        } catch (Exception e) {
            System.out.println("Group already exists");
        }

        try {
            identityService.createMembership(user.getId(), group.getId());
        } catch (Exception e) {
            System.out.println("Membership already exists");
        }

        users = userQuery.list();

        assertFalse(users.isEmpty());
    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/SUC_2.1_ProcessIRDesignation.bpmn"})
    public void testForProcessDesignationWithFailure() throws InterruptedException {

        ProcessInstance processInstance = startProcessInstance("processMadridDesignation");
        String id = processInstance.getId();
        System.out.println("ID " + (id = processInstance.getId()));
        System.out.println("Current activity ID " + processInstance.getActivityId());
        System.out.println("Process definition key " + processInstance.getProcessDefinitionKey());
        Thread.sleep(2000);
        Map<String, Object> payload = Collections
            .<String, Object> singletonMap(ProcessFlowConstants.SERVICE_RESPONSE_VAR, Boolean.TRUE);
        processEngine.getRuntimeService().signal(id, payload);
        assertEquals(0, runtimeService.createProcessInstanceQuery().count());

    }

    // @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/SUC_2.1_ProcessIRDesignation.bpmn"})
    public void testForProcessDesignationWithSuccess() throws InterruptedException {

        ProcessInstance processInstance = startProcessInstance("processMadridDesignation");
        String id = processInstance.getId();
        System.out.println("ID " + (id = processInstance.getId()));
        System.out.println("Current activity ID " + processInstance.getActivityId());
        System.out.println("Process definition key " + processInstance.getProcessDefinitionKey());
        Thread.sleep(2000);
        Map<String, Object> payload = new HashMap<String, Object>();
        payload.put(ProcessFlowConstants.SERVICE_RESPONSE_VAR, Boolean.FALSE);
        payload.put(ProcessFlowConstants.ERR_MSG_DESC_VAR, "Sample test xxception message");

        processEngine.getRuntimeService().signal(id, payload);
        assertEquals(0, runtimeService.createProcessInstanceQuery().count());

    }

}
