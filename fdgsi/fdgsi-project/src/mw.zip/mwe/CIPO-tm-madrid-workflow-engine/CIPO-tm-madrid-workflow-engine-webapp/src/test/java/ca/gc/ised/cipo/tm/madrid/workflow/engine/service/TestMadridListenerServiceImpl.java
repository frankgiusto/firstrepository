package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.lang.invoke.MethodHandles;
import java.util.Map;
import java.util.Set;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.task.IdentityLink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl.MadridListenerServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import util.TestMadridMethodVarsService;

public class TestMadridListenerServiceImpl implements MadridListenerService {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Override
	/**
	 * {@inheritDoc}
	 */
	public void syncConsoleTask(DelegateTask delegateTask) {

		Map<String, Object> methodVars = methodVarsService.getMethodVars();

		if (methodVars != null) {

			Set<String> keys = methodVars.keySet();
			for (String key : keys) {
				delegateTask.getExecution().setVariable(key, methodVars.get(key));
			}

		}

		String groupId = (String) delegateTask.getExecution().getVariable(ProcessFlowConstants.CANDIDATE_GROUP_ID);
		String taskType = (String) delegateTask.getExecution().getVariable(ProcessFlowConstants.CONSOLE_TASK_TYPE);

		if (groupId != null) {

			// Delete existing Groups
			Set<IdentityLink> idLinks = delegateTask.getCandidates();
			for (IdentityLink identityLink : idLinks) {
				delegateTask.deleteCandidateGroup(identityLink.getGroupId());
			}

			delegateTask.addCandidateGroup(groupId);
		}

		// Set some variables on the UserTask
		if (taskType != null) {

			delegateTask.createVariableLocal(ProcessFlowConstants.CONSOLE_TASK_TYPE, taskType);
			delegateTask.createVariableLocal(ProcessFlowConstants.CONSOLE_TASK_ID, "abc123");

		}

		// If there is a MTS error, signal it
		Boolean throwError = (Boolean) delegateTask.getExecution().getVariable(ProcessFlowConstants.MTS_ERROR);
		if (throwError != null && throwError) {

			RuntimeService runtimeService = delegateTask.getExecution().getEngineServices().getRuntimeService();

			Set<IdentityLink> idLinks = delegateTask.getCandidates();
			for (IdentityLink identityLink : idLinks) {
				delegateTask.deleteCandidateGroup(identityLink.getGroupId());
			}

			runtimeService.signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_FAILURE, delegateTask.getExecutionId());

		}

	}

	@Override
	public void setTransactionDescValues(DelegateExecution execution) {

		// Let the production implementation do it's work.
		MadridListenerServiceImpl service = new MadridListenerServiceImpl();

		service.setTransactionDescValues(execution);

	}

	/**
	 * For whatever reason, variables in Error End Events can't be passed up to
	 * the Boundary Error Events that catch the error.
	 *
	 * This method solves the problem by setting the variable in the Super
	 * execution
	 *
	 *
	 */
	@Override
	public void promoteErrorMessageToCallingExecution(DelegateExecution execution) {

		Object errMsgObject = execution.getVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR);

		if (errMsgObject != null && execution.getSuperExecutionId() != null) {

			execution.getEngineServices().getRuntimeService().setVariable(execution.getSuperExecutionId(),
					ProcessFlowConstants.ERR_MSG_OBJECT_VAR, errMsgObject);

			// execution.getEngineServices().getRuntimeService().removeVariable(execution.getId(),
			// ProcessFlowConstants.ERR_MSG_OBJECT_VAR);

		}

	}

	@Override
	public void createUnknownTransactionTypeError(DelegateExecution execution) {

		// Fetch the transaction type from the process
		String transType = (String) execution.getVariable(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_TYPE);

		BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem(
				transType + " is not a recognized manual transaction type.");

		businessErrorLogItem.setCipoServiceFaultOrigin(true);
		businessErrorLogItem.setServiceName("MWE-test");
		businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
		businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

		execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public void debugUserTask(DelegateTask delegateTask) {

		LOG.debug(delegateTask.getExecution().getProcessDefinitionId() + "->"
				+ delegateTask.getExecution().getCurrentActivityId() + " [" + delegateTask.getEventName() + "]");

	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public void debugListener(DelegateExecution execution) {

		// Used to set debug triggers (eg.
		// activityId.equals("boundaryErrorLimitation");
		String id = execution.getId();
		String procDefId = execution.getProcessDefinitionId();
		String activityId = execution.getCurrentActivityId();
		String activityName = execution.getCurrentActivityName();
		String eventName = execution.getEventName();

		LOG.debug(procDefId + "->" + activityId + " [" + eventName + "]");

	}

	/**
	 *
	 * @param execution
	 */
	private void logCurrentVariables(DelegateExecution execution) {

		LOG.debug("Current Vars: ");
		Map<String, Object> varMap = execution.getVariables();
		if (varMap != null) {

			Set<String> keys = varMap.keySet();
			for (String key : keys) {
				LOG.debug(key + " = " + varMap.get(key));
			}

		}

	}

}
