package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

/**
 * A transfer request creator strategy for creating a DTF transfer request for a Madrid notification package (XML)
 *
 * @author J. Greene
 *
 */
public class NotificationXmlTransferRequestCreator extends AbstractNotificationTransferRequestCreator {

    /** {@inheritDoc} */
    @Override
    protected String getDtfSite() {
        return getEnvironment().getProperty("mwe.dtf.madrid.site.name");
    }

    /** {@inheritDoc} */
    @Override
    public String getFileNameDiscriminator() {
        return getEnvironment().getProperty("mwe.notification.xml.file.discriminator");
    }

    /** {@inheritDoc} */
    @Override
    public String getRemoteDir() {
        return getEnvironment().getProperty("mwe.dtf.madrid.ftp.notification.dir.xml");
    }

    /** {@inheritDoc} */
    @Override
    public String getRegexForTransactionType() {
        return getEnvironment().getProperty("mwe.notification.xml.regex");
    }

}
