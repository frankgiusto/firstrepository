package ca.gc.ised.cipo.tm.madrid.workflow.engine.util;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_IRREG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_MADRID_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUT_FINANCE_FEES;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.activation.DataHandler;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import ca.gc.ic.cipo.schema.dtf.RacfUser;
import ca.gc.ic.cipo.tm.mps.ImportPackage;
import ca.gc.ic.cipo.tm.schema.mps.ImportPackageType;
import ca.gc.ic.cipo.tm.schema.mps.PackageTypeEnum;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * General utilities class for the Madrid Workflow engine.
 *
 * @author J. Greene
 *
 */
public final class MweWorkflowUtil {

	private static final Logger LOG = LoggerFactory.getLogger(MweWorkflowUtil.class);

	private static final int BUFFER_SIZE = 4096;

	private static DatatypeFactory df = null;

	private static RacfUser mweRacfUser;

	@Autowired
	private static Environment env;

	static {
		try {
			df = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			throw new IllegalStateException("Error while trying to obtain a new instance of DatatypeFactory", e);
		}
	}

	/**
	 * Convenience method to convert a bean to a workflow input parameter map
	 * that the engine accepts.
	 *
	 * @param bean
	 *            the Java {@code Bean} to be converted.
	 * @return a {@code Map<String, Object>} representing the bean.
	 */
	public static Map<String, Object> convertModelToProcessVariables(Object bean) {
		Map<String, Object> objectAsMap = new HashMap<>();
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(bean.getClass());
			for (PropertyDescriptor descriptor : beanInfo.getPropertyDescriptors()) {
				Method readMethod = descriptor.getReadMethod();
				if (readMethod.getName().startsWith("get") && !readMethod.getName().equals("getClass")) {
					objectAsMap.put(descriptor.getName(), readMethod.invoke(bean));
				}
			}
		} catch (Exception e) {
			LOG.error("Error while introspecting bean.", e);
		}
		return objectAsMap;
	}

	/**
	 * Convenience method for moving files from a SOAP operation data stream to
	 * a file folder.
	 *
	 * @param dataHandler
	 *            The DataHandler object representing the file binary
	 * @param outputDirectoryString
	 *            The output directory
	 * @param packageFileName
	 *            The file name to be used locally for the downloaded package
	 *            data
	 * @throws Exception
	 *             If there are any complications with the file move.
	 */
	public static void moveFileStream(DataHandler dataHandler, String outputDirectoryString, String packageFileName)
			throws Exception {

		// Is there a better way to do this? Maybe.

		Path outputPath = Paths.get(outputDirectoryString);
		if (!Files.isDirectory(outputPath)) {
			// try creating it.
			Path createdOutputPath = Files.createDirectories(outputPath);
			outputPath = createdOutputPath;
		}

		Path outputFile = Paths.get(outputDirectoryString, packageFileName);
		long bytesWritten = Files.copy(dataHandler.getInputStream(), outputFile, StandardCopyOption.REPLACE_EXISTING);
		Long kbWritten = (bytesWritten / 1024L);
		LOG.debug("Wrote " + kbWritten + "KB to " + outputFile.toString());
	}

	/**
	 * Convenience method to unzip the downloaded package in place.
	 *
	 * @param packageFilePath
	 *            The file {@code Path} to be used locally for the downloaded
	 *            package data
	 * @return a collection of file names in the archive
	 * @throws IOException
	 *             if things go south
	 */
	public static List<String> unzipInPlace(Path packageFilePath) throws IOException {
		return unzipToFolder(packageFilePath.toString(), packageFilePath.getParent().toString());
	}

	/**
	 * Convenience method to unzip a package to a specified location.
	 *
	 * @param packageFileName
	 *            The fully qualified file name to be used locally for the
	 *            downloaded package data
	 * @param outputFolder
	 *            the output folder for the archive
	 * @return a collection of file names in the archive
	 * @throws IOException
	 *             if things go south
	 */
	public static List<String> unzipToFolder(String packageFileName, String outputFolder) throws IOException {

		List<String> entryNames = new ArrayList<>();
		File destination = new File(outputFolder);
		if (!destination.exists()) {
			destination.mkdir();
		}

		ZipInputStream zipIn = new ZipInputStream(new FileInputStream(packageFileName));
		try {
			ZipEntry entry = zipIn.getNextEntry();
			while (entry != null) {
				entryNames.add(entry.getName());

				// In case a file of the same name exists
				Path outputEntryPath = Paths.get(outputFolder, entry.getName());
				Files.deleteIfExists(outputEntryPath);

				if (!entry.isDirectory()) {
					BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outputEntryPath.toFile()));
					try {
						writeBytesToOutput(bos, zipIn);
					} finally {
						IOUtils.closeQuietly(bos);
					}
				} else {
					Files.createDirectory(outputEntryPath);
				}
				zipIn.closeEntry();
				entry = zipIn.getNextEntry();
			}
		} finally {
			IOUtils.closeQuietly(zipIn);
		}

		return entryNames;
	}

	/**
	 * Convenience method for moving files from one folder to another.
	 *
	 * @param file
	 *            The file to be moved
	 * @param outputDirectoryString
	 *            The output directory
	 * @throws IOException
	 *             If there are any complications with the file move.
	 */
	public static void moveFile(File file, String outputDirectoryString) throws IOException {
		Path filePath = Paths.get(file.getAbsolutePath());
		Path outputPath = Paths.get(outputDirectoryString);
		if (!Files.isDirectory(outputPath)) {
			// try creating it.
			outputPath = Files.createDirectories(outputPath);
		}

		Files.move(filePath, outputPath.resolve(filePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);
	}

	/**
	 * Converts a java.util.Date into an instance of XMLGregorianCalendar
	 * (stolen from cipo-ec-core).
	 *
	 * @param date
	 *            the {@code Date} to be converted
	 * @return the converted date
	 */
	public static XMLGregorianCalendar toXMLGregorianCalendar(Date date) {
		if (date == null) {
			return null;
		} else {
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(date.getTime());
			return df.newXMLGregorianCalendar(gc);
		}
	}

	/**
	 * Converts an XMLGregorianCalendar to an instance of java.util.Date (stolen
	 * from cipo-ec-core)
	 *
	 * @param xmlGC
	 *            the {@code XMLGregorianCalendar} to be converted.
	 * @return the converted date
	 */
	public static Date toDate(XMLGregorianCalendar xmlGC) {
		if (xmlGC == null) {
			return null;
		} else {
			return xmlGC.toGregorianCalendar().getTime();
		}
	}

	/**
	 * Creates a string builder for the basic layout of a business error message
	 * / mail item.
	 *
	 * @return the base {@code StringBuilder}
	 */
	public static StringBuilder getBaseMailStringBuilder() {
		StringBuilder baseMessageStringBuilder = new StringBuilder();
		// @formatter:off
		baseMessageStringBuilder.append("SOAP Fault").append(SystemUtils.LINE_SEPARATOR).append("\t")
				.append("Component:\t\t").append("%1$s").append(SystemUtils.LINE_SEPARATOR).append("\t")
				.append("Service name:\t\t").append("%2$s").append(SystemUtils.LINE_SEPARATOR).append("\t")
				.append("Return code:\t\t").append("%3$s").append(SystemUtils.LINE_SEPARATOR).append("\t")
				.append("Reason code:\t\t").append("%4$s").append(SystemUtils.LINE_SEPARATOR).append("\t")
				.append("Fault message:").append(SystemUtils.LINE_SEPARATOR).append(SystemUtils.LINE_SEPARATOR)
				.append("\t\t").append("%5$s").append(SystemUtils.LINE_SEPARATOR).append("\t\t----")
				.append(SystemUtils.LINE_SEPARATOR).append("\t\t").append("%6$s");
		// @formatter:on
		return baseMessageStringBuilder;
	}

	/**
	 * Convenience method to pipe bytes from a stream into an output stream.
	 *
	 * @param is
	 *            any output stream
	 * @param is
	 *            any input stream
	 * @throws IOException
	 */
	public static void writeBytesToOutput(OutputStream zos, InputStream is) throws IOException {
		int len = -1;
		byte[] buff = new byte[BUFFER_SIZE];
		while ((len = is.read(buff)) > 0) {
			zos.write(buff, 0, len);
		}
	}

	/**
	 * Convenience method to get a regular expression matcher for a transfer
	 * type
	 *
	 * @param transferItem
	 *            the transfer type of the package
	 * @return the regex matcher
	 */
	public static String getFileRegexForPackageType(String transferItem) {
		String regexString = null;
		switch (transferItem) {
		case IN_NOTIF_PKG:
			regexString = getRequiredConfigurationProperty("mwe.notification.xml.regex");
			break;
		case IN_NOTIF_IMG_PKG:
			regexString = getRequiredConfigurationProperty("mwe.notification.img.regex");
			break;
		case IN_NOTIF_PDF_PKG:
			regexString = getRequiredConfigurationProperty("mwe.notification.pdf.regex");
			break;
		case IN_IRREG_PKG:
			regexString = getRequiredConfigurationProperty("mwe.irregularities.xml.regex");
			break;
		case IN_FINANCE_FEES:
			regexString = getRequiredConfigurationProperty("mwe.cipo.finance.monthly.inbound.regex");
			break;
		case IN_MADRID_FEES:
			regexString = getRequiredConfigurationProperty("mwe.wipo.fees.regex");
			break;
		case OUT_FINANCE_FEES:
			regexString = getRequiredConfigurationProperty("mwe.cipo.finance.monthly.outbound.regex");
			break;
		default:
			LOG.error("No regex expression for type [" + transferItem + "]!");
		}
		return regexString;
	}

	/**
	 * Takes a {@code PackageUnit} (HWE construct) and transforms it into an {@
	 * ImportPackage} (HPS construct) for service operations.
	 *
	 * @param packageUnit
	 *            the PackageUnit to be transformed
	 * @param transferItem
	 *            the transfer item from the original request - used to
	 *            determine what types of files we are sending
	 * @return the transformed object
	 */
	public static ImportPackage transformPackageUnitToImportPackage(PackageUnit packageUnit, String transferItem) {
		ImportPackage importPackage = new ImportPackage();
		List<ImportPackageType> importPacakgeList = importPackage.getImportPackageRequest();
		PackageTypeEnum imgPackageType = null;
		PackageTypeEnum xmlPackageType = null;
		PackageTypeEnum pdfPackageType = null;

		switch (transferItem) {
		case IN_NOTIF_PKG:
		case IN_NOTIF_IMG_PKG:
		case IN_NOTIF_PDF_PKG:
			xmlPackageType = PackageTypeEnum.MADRID_NOTIFICATION_XML;
			imgPackageType = PackageTypeEnum.MADRID_NOTIFICATION_IMG;
			pdfPackageType = PackageTypeEnum.MADRID_NOTIFICATION_PDF;
			break;
		case IN_IRREG_PKG:
			xmlPackageType = PackageTypeEnum.MADRID_IRREGULARITY_XML;
			imgPackageType = PackageTypeEnum.MADRID_IRREGULARITY_PDF;
			break;
		case IN_MADRID_FEES:
			xmlPackageType = PackageTypeEnum.MADRID_FINANCE_PACKAGE;
			break;
		case IN_FINANCE_FEES:
			xmlPackageType = PackageTypeEnum.IFMS_FINANCIAL_FEEDBACK;
			break;
		default:
			break;
		}

		if (transferItem.equals(IN_NOTIF_PKG) || transferItem.equals(IN_NOTIF_IMG_PKG)
				|| transferItem.equals(IN_NOTIF_PDF_PKG)) {

			// Madrid weekly notification
			ImportPackageType xmlType = new ImportPackageType();
			xmlType.setPackageLocation(packageUnit.getXmlFileName());
			xmlType.setPackageType(xmlPackageType);
			importPacakgeList.add(xmlType);

			ImportPackageType imgType = new ImportPackageType();
			imgType.setPackageLocation(packageUnit.getImgFileName());
			imgType.setPackageType(imgPackageType);
			importPacakgeList.add(imgType);

			ImportPackageType pdfType = new ImportPackageType();
			pdfType.setPackageLocation(packageUnit.getPdfFileName());
			pdfType.setPackageType(pdfPackageType);
			importPacakgeList.add(pdfType);

		} else {
			// Only XML file packages
			ImportPackageType xmlFeesType = new ImportPackageType();
			xmlFeesType.setPackageLocation(packageUnit.getXmlFileName());
			xmlFeesType.setPackageType(xmlPackageType);
			importPacakgeList.add(xmlFeesType);
		}

		return importPackage;
	}

	public static RacfUser getRacfUser() {
		if (mweRacfUser == null) {
			mweRacfUser = new RacfUser();
			mweRacfUser.setUserId(env.getProperty("mwe.dtf.service.username"));
			mweRacfUser.setPassword(env.getProperty("mwe.dtf.service.password"));
		}
		return mweRacfUser;
	}

	/**
	 * Adds validation to a required configuration property look-up.
	 *
	 * @param propertyKey
	 *            The property key
	 * @return The property value
	 */
	public static String getRequiredConfigurationProperty(String propertyKey) {
		String propertyValue = null;

		propertyValue = env.getProperty(propertyKey);
		if (StringUtils.isBlank(propertyValue)) {
			throw new IllegalArgumentException(
					"Please provide a valid value for property [" + propertyKey + "] in the application configuration");
		}
		return propertyValue;
	}

}
