/*
 * Copyright (c) 2018 CIPO Created on Aug 22, 2018
 */
package ca.gc.ised.cipo.tm.madrid.diagram;

/**
 * Tests the Accounts Receivable BPMN flows.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
// @RunWith(SpringJUnit4ClassRunner.class)
// @ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class ProcessAccountsReceivableTest {

	// @Autowired
	// @Rule
	// public ActivitiRule activitiRule;
	//
	// @Autowired
	// protected HistoryService historyService;
	//
	// @Autowired
	// protected RuntimeService runtimeService;
	//
	// /**
	// * Convenience method to launch the process flow.
	// *
	// * @param processVars
	// * variables to be used on the flow
	// * @return reference to the process flow instance
	// */
	// private ProcessInstance startProcessInstance(Map<String, Object>
	// processVars) {
	// return
	// activitiRule.getRuntimeService().startProcessInstanceByKey("processAccountsReceivable",
	// processVars);
	// }
	//
	// // MFS-CLEAN-SPR5 @Test
	// // @Deployment(resources = {
	// //
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/process-accounts-receivable.bpmn",
	// //
	// "ca/gc/ised/cipo/tm/madrid/diagram/finance/send-accounts-receivable-to-financial-system.bpmn"
	// // })
	// // public void nothingToProcessTest() {
	// // System.out.println("#############################################");
	// // System.out.println("### process-accounts-receivable ###");
	// // System.out.println("### Nothing to process ###");
	// // System.out.println("#############################################");
	// //
	// // // Kick off the flow
	// // ProcessInstance testInstance = startProcessInstance(null);
	// //
	// // // Simulate a small delay in processing then fire the signal to
	// continue
	// // try {
	// // Thread.sleep(3000); // 3s
	// // } catch (InterruptedException e) {
	// // e.printStackTrace();
	// // }
	// //
	// // Execution signalExec = runtimeService.createExecutionQuery()
	// //
	// .processInstanceId(testInstance.getProcessInstanceId()).activityId(WAIT_FOR_MFS_SIGNAL_TASK_NAME)
	// // .singleResult();
	// //
	// // // Set the error message variable on the flow. Under success
	// conditions
	// // // this will be NULL
	// // runtimeService.setVariable(testInstance.getProcessInstanceId(),
	// // ERR_MSG_OBJECT_VAR, null);
	// // runtimeService.signal(signalExec.getId());
	// //
	// // TestUtils.assertCompletion(historyService, testInstance);
	// // TestUtils.assertActivitiEventFired(historyService, "processARDist",
	// 1);
	// // TestUtils.assertActivitiEventFired(historyService,
	// // "waitForMfsSignalTask", 1);
	// // TestUtils.assertActivitiEventFired(historyService, "fetchReadyARs",
	// 1);
	// // }

}
