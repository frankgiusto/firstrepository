package ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MFS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MWE_SERVICE_NAME;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.WAIT_FOR_MFS_SIGNAL_TASK_NAME;

import java.math.BigDecimal;
import java.util.concurrent.Future;

import javax.xml.ws.BindingProvider;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.runtime.Execution;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

// import ca.gc.ic.cipo.tm.mfs.GenerateAccountsReceivableDistributionResponse;
import ca.gc.ic.cipo.report.CipoServiceFault;
import ca.gc.ic.cipo.tm.mts.ReportTypeEnum;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.EmailMessageDetails;

/**
 * Manager class to handle the Madrid finance service calls and response as well
 * as any SOAP faults.
 *
 * @author J. Greene
 *
 */
@Service
public class MfsServiceManagerImpl extends AbstractServiceManager implements MfsServiceManager {

	// protected TMMadridFinancialFeeServicePortType mfsClient;

	@Value("${mwe.mfs.service.endpoint.hostname}")
	private String mfsHost;

	@Autowired
	protected RuntimeService runtimeService;

	@Autowired
	protected TaskExecutor taskExecutor;

	@Autowired
	private Environment env;

	// MFS-CLEAN-SPR5protected TMMadridFinancialFeeServicePortType mfsClient;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManagerI#
	 * processAccountReceivableDistributionAsync
	 * (org.activiti.engine.delegate.DelegateExecution)
	 */
	@Override
	public void processAccountReceivableDistributionAsync(DelegateExecution execution)
			throws BpmnWebServiceCallException {
		try {
			LOG.debug("--> Calling MFS : processAccountsReceivableDistribution (async)");

			// TODO Put it back when MFS is ready
			// Response<GenerateAccountsReceivableDistributionResponse>
			// asyncResponse =
			// getMfsClient().generateAccountsReceivableDistributionAsync();

			// Use a runnable to check on the progress of the async client call
			// TODO Put it back when MFS is ready
			// taskExecutor.execute(new
			// CompleteWsCallRunner(execution.getProcessInstanceId(),
			// asyncResponse));

		} catch (Throwable t) {
			handleWebServiceException(t, ProcessFlowConstants.MFS, "generateAccountsReceivableDistributionAsync");
		}
	}

	/**
	 * Wraps a service operation that will parse financial transactions from a
	 * financial package.
	 *
	 * @param packageId
	 *            the package ID of the package to be parsed
	 * @param transferItem
	 *            the transfer type of the package
	 * @throws BpmnWebServiceCallException
	 */
	@Override
	public void parsePackageToTransactions(BigDecimal packageId, String transferItem)
			throws BpmnWebServiceCallException {
		// MFS-CLEAN-SPR5 if (packageId == null) {
		// throw new IllegalArgumentException("Parameter [packageId] must not be
		// null");
		// }
		// if (transferItem == null) {
		// throw new IllegalArgumentException("Parameter [transferItem] must not
		// be null");
		// }
		// ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.FinancialPackageCategoryType
		// pkgType = null;
		//
		// if (transferItem.equals(IN_MADRID_FEES)) {
		// pkgType =
		// ca.gc.ic.cipo.tm.xmlschema.madrid.financialfee.FinancialPackageCategoryType.WIPO_FINANCIAL;
		// } else if (transferItem.equals(IN_FINANCE_FEES)) {
		// pkgType = FinancialPackageCategoryType.CIPO_FINANCIAL;
		// } else {
		// throw new BpmnWebServiceCallException("Unrecognized transfer item ["
		// + transferItem + "]!");
		// }
		//
		// try {
		// LOG.debug(
		// "--> Calling WSO : parsePackageToTransactions - with package ID " +
		// packageId + " and type " + pkgType);
		// getMfsClient().parsePackageToTransactions(packageId, pkgType);
		// // } catch (CipoServiceFault csf) {
		// // handleHpsSoapFault(csf);
		// } catch (Throwable t) {
		// handleWebServiceException(t, MFS, "parsePackageToTransactions");
		// }
	}

	/**
	 * Wraps a service operation to get email details (subject, body,
	 * receiver(s)) for notification purposes upon generation of a gap report
	 *
	 * @return A local bean to hold the transcribed information from the
	 *         operation
	 * @throws BpmnWebServiceCallException
	 */
	@Override
	public EmailMessageDetails getNotificationEmailContent() throws BpmnWebServiceCallException {
		EmailMessageDetails emailMessageDetails = null;
		// MFS-CLEAN-SPR5 GetNotificationEmail notificationEmailRequestObject =
		// new GetNotificationEmail();
		// notificationEmailRequestObject.setNotificationType(EmailNotificationCategoryType.GAP_REPORT);
		//
		// try {
		// LOG.debug("--> Calling WSO : getNotificationEmailContent");
		// GetNotificationEmailContentResponse response = getMfsClient()
		// .getNotificationEmailContent(notificationEmailRequestObject);
		//
		// if (response == null) {
		// throw new BpmnWebServiceCallException(
		// "MFS returned a null object for call to
		// [getNotificationEmailContent]");
		// } else {
		// throw new UnsupportedOperationException("Needs to be implemented");
		// // TODO: Response object is currently blank in MFS, revisit when
		// // it isn't.
		// // @formatter:off
		// // emailMessageDetails = new EmailMessageDetails();
		// //
		// //
		// emailMessageDetails.setToArray(response.getEmailContent().getRecipientEmail()
		// // .toArray(new
		// // String[response.getEmailContent().getRecipientEmail().size()]));
		// // emailMessageDetails.setSubject(
		// // response.getEmailContent().getSubjectFrc() + " / " +
		// // response.getEmailContent().getSubject());
		// // emailMessageDetails.setBody(
		// // response.getEmailContent().getBodyFrc() + "\n\n---\n\n" +
		// // response.getEmailContent().getBody());
		// // @formatter:on
		// }
		// // } catch (CipoServiceFault csf) {
		// // handleHpsSoapFault(csf);
		// } catch (Throwable t) {
		// handleWebServiceException(t, MFS, "getNotificationEmailContent");
		// }
		return emailMessageDetails;
	}

	/**
	 * Wraps an operation to perform reconciliation tasks on a financial
	 * transaction.
	 *
	 * @param transactionId
	 *            the transaction ID
	 * @throws BpmnWebServiceCallException
	 */
	@Override
	public void reconcileFinancialTransaction(BigDecimal transactionId) throws BpmnWebServiceCallException {
		if (transactionId == null) {
			throw new IllegalArgumentException("Parameter [transactionId] must not be null");
		}
		try {
			LOG.debug("--> Calling WSO : reconcileFinancialTransaction - with transaction ID " + transactionId);
			// MFS-CLEAN-SPR5
			// getMfsClient().reconcileFinancialTransaction(transactionId);
			// } catch (CipoServiceFault csf) {
			// handleHpsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, MFS, "reconcileFinancialTransaction");
		}
	}

	/**
	 * Wraps an operation to retrieve the reconciled fee distribution XML data
	 * for
	 *
	 * @param packageId
	 * @return
	 * @throws BpmnWebServiceCallException
	 */
	// MFS-CLEAN-SPR5 @Override
	// public ReconciledOutput generateReconciledFeeDistribution(BigDecimal
	// packageId) throws BpmnWebServiceCallException {
	// if (packageId == null) {
	// throw new IllegalArgumentException("Parameter [packageId] must not be
	// null");
	// }
	// ReconciledOutput output = null;
	// try {
	// LOG.debug("--> Calling WSO : generateReconciledFeeDistribution - with
	// package ID " + packageId);
	// output = getMfsClient().generateReconciledFeeDistribution(packageId);
	// // } catch (CipoServiceFault csf) {
	// // handleHpsSoapFault(csf);
	// } catch (Throwable t) {
	// handleWebServiceException(t, MFS, "generateReconciledFeeDistribution");
	// }
	// return output;
	// }

	/**
	 * Wraps an operation that will update a specific transaction's financial
	 * status.
	 *
	 * @param transactionId
	 *            the transaction ID
	 * @throws BpmnWebServiceCallException
	 */
	@Override
	public void updateApplicationsFinancialStatus(BigDecimal transactionId) throws BpmnWebServiceCallException {
		if (transactionId == null) {
			throw new IllegalArgumentException("Parameter [transactionId] must not be null");
		}
		try {
			LOG.debug("--> Calling WSO : updateApplicationsFinancialStatus - with transaction ID " + transactionId);
			// MFS-CLEAN-SPR5
			// getMfsClient().updateApplicationsFinancialStatus(transactionId);
			// } catch (CipoServiceFault csf) {
			// handleHpsSoapFault(csf);
		} catch (Throwable t) {
			handleWebServiceException(t, MFS, "updateApplicationsFinancialStatus");
		}
	}

	/**
	 * Wraps the call in MFS to generate a report of a specific type given the
	 * package ID associated with the report input data.
	 *
	 * @param packageId
	 *            the package ID pertaining to the report generation
	 * @param reportTypeCode
	 *            the type of report to be generated
	 * @return the report job ID for use when polling for report progress from
	 *         report service
	 * @throws BpmnWebServiceCallException
	 */
	// @Override
	public String generateReport(BigDecimal packageId, ReportTypeEnum reportTypeCode)
			throws BpmnWebServiceCallException {
		String reportJobId = null;
		// MFS-CLEAN-SPR5 if (packageId == null) {
		// throw new IllegalArgumentException("Parameter [packageId] must not be
		// null");
		// }
		// if (reportTypeCode == null) {
		// throw new IllegalArgumentException("Parameter [reportTypeCode] must
		// not be null");
		// }
		//
		// try {
		// LOG.debug("--> Calling WSO : generateReport - with package ID " +
		// packageId);
		// reportJobId = getMfsClient().generateReport(packageId, null,
		// reportTypeCode);
		// LOG.debug("--> WSO : generateReport - returned with ID " +
		// reportJobId);
		// // } catch (CipoServiceFault csf) {
		// // handleHpsSoapFault(csf);
		// } catch (Throwable t) {
		// handleWebServiceException(t, ProcessFlowConstants.MFS,
		// "generateReport");
		// }

		return reportJobId;
	}

	/**
	 * Wraps a call to MFS to notify HTS that a report is ready for consumption.
	 *
	 * @param reportJobId
	 *            the report job ID of the completed report in RGS
	 * @param packageId
	 *            the package ID pertaining to the report generation
	 * @param reportTypeCode
	 *            the type of report to be generated
	 * @return the attachment ID of the attachment that was created in the INTL
	 *         DB as a result of this call
	 * @throws BpmnWebServiceCallException
	 */
	// @Override
	public BigDecimal generateReportNotification(String reportJobId, BigDecimal packageId,
			ReportTypeEnum reportTypeCode) throws BpmnWebServiceCallException {
		BigDecimal attachmentId = null;

		// MFS-CLEAN-SPR5 if (packageId == null) {
		// throw new IllegalArgumentException("Parameter [packageId] must not be
		// null");
		// }
		// if (reportJobId == null) {
		// throw new IllegalArgumentException("Parameter [reportJobId] must not
		// be null");
		// }
		// if (reportTypeCode == null) {
		// throw new IllegalArgumentException("Parameter [reportTypeCode] must
		// not be null");
		// }
		//
		// try {
		// LOG.debug("--> Calling WSO : generateReportNotification - with job ID
		// " + reportJobId);
		// attachmentId = getMfsClient().generateReportNotification(reportJobId,
		// packageId, null, reportTypeCode);
		// LOG.debug("--> WSO : generateReportNotification - returned with ID "
		// + attachmentId);
		// // } catch (CipoServiceFault csf) {
		// // handleHpsSoapFault(csf);
		// } catch (Throwable t) {
		// handleWebServiceException(t, MFS, "generateReportNotification");
		// }
		return attachmentId;
	}

	protected void handleHpsSoapFault(CipoServiceFault fault) throws BpmnWebServiceCallException {
		BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(fault.getFaultInfo());

		BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::CipoServiceFault::");
		serviceException.setBusinessErrorLogItem(businessErrorLogItem);
		throw serviceException;
	}

	protected String getMfsHost() {
		if (StringUtils.isBlank(mfsHost)) {
			throw new IllegalArgumentException(
					"Please provide a valid value for property [mwe.mfs.service.endpoint.hostname] in the application configuration");
		}
		return mfsHost;
	}

	// MFS-CLEAN-SPR5 protected TMMadridFinancialFeeServicePortType
	// getMfsClient() {
	// if (mfsClient == null) {
	// mfsClient =
	// TMMadridFinancialFeeServiceFactory.createClient(getMfsHost());
	// }
	//
	// return mfsClient;
	// }

	/** {@inheritDoc} */
	@Override
	protected BindingProvider getBindingProvider() {
		// MFS-CLEAN-SPR5return (BindingProvider) getMfsClient();
		return null;
	}

	/*
	 * An inner class to handle the asynchronous task of checking the async WS
	 * client call to import transactions. Checks the Future<?> type for errors
	 * and handles them appropriately. Finally signals the execution to
	 * continue.
	 */
	private class CompleteWsCallRunner implements Runnable {

		protected String processInstanceId;

		protected Future<?> response;

		protected final Logger LOGX = LoggerFactory.getLogger(CompleteWsCallRunner.class);

		/**
		 * @param processInstanceId
		 * @param response
		 */
		public CompleteWsCallRunner(String processInstanceId, Future<?> response) {
			this.processInstanceId = processInstanceId;
			this.response = response;
		}

		/** {@inheritDoc} */
		@Override
		public void run() {
			LOGX.debug("Waiting for async HFS operation client call to return.");
			BusinessErrorLogItem businessErrorLogItem = null;
			long sleepTime = Long
					.parseLong(env.getProperty("mwe.madrid.transaction.import.poll.period.millis", "1000"));
			try {
				while (!response.isDone()) {
					Thread.sleep(sleepTime);
				}

				response.get();
			} catch (Exception ex) {
				Throwable t = ex.getCause();
				if (t instanceof CipoServiceFault) {
					CipoServiceFault fault = (CipoServiceFault) t;
					businessErrorLogItem = buildBusinessErrorLogItem(fault.getFaultInfo());
				} else {
					businessErrorLogItem = new BusinessErrorLogItem(t.getMessage());
					businessErrorLogItem.setComponentAcronym(ProcessFlowConstants.MTS);
					businessErrorLogItem.setServiceName(MWE_SERVICE_NAME);
				}
			}

			Execution signalExec = runtimeService.createExecutionQuery().processInstanceId(processInstanceId)
					.activityId(WAIT_FOR_MFS_SIGNAL_TASK_NAME).singleResult();
			LOGX.debug("Signalling restart of execution [" + signalExec.getId() + "]");

			// Set the error message variable on the flow. Under success
			// conditions this will be NULL
			runtimeService.setVariable(processInstanceId, ERR_MSG_OBJECT_VAR, businessErrorLogItem);
			runtimeService.signal(signalExec.getId());
		}
	}
}
