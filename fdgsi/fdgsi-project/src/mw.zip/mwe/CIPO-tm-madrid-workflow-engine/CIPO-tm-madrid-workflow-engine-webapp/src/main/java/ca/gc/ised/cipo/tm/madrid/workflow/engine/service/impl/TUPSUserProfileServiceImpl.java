package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.userprofile.client.UserProfileServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.schema.AuthorityType;
import ca.gc.ic.cipo.tm.userprofile.schema.BaseUserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileService;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TUPSUserProfileService;

@Service(value = "TUPSUserProfileService")
public class TUPSUserProfileServiceImpl implements TUPSUserProfileService {

	@Value("${mwe.tups.service.endpoint.hostname}")
	private String authHostUrl;

	private UserProfileService tupsClient;

	/**
	 * Maintains a singleton of the TUPS Client per session. THis will prevent
	 * the TUPS client to get created when involking the service multiple times
	 *
	 * @return UserProfileService the service client
	 */
	private UserProfileService getTupsClient() {

		if (tupsClient == null) {
			tupsClient = UserProfileServiceFactory.createClient(authHostUrl);
		}
		return tupsClient;
	}

	@Override
	public UserProfile getUserProfile(UserProfileType userProfileType) throws CIPOServiceFault {

		return getTupsClient().getUserProfile(userProfileType);
	}

	@Override
	public HeartbeatResponseType getHeartbeat() throws CIPOServiceFault {

		return getTupsClient().getHeartbeat();
	}

	@Override
	public List<String> listAuthorityTypes(AuthorityType authorityType) throws CIPOServiceFault {

		return getTupsClient().listAuthorityTypes(authorityType);
	}

	@Override
	public List<BaseUserProfile> searchUserProfiles(UserAuthority userAuthority) throws CIPOServiceFault {

		return getTupsClient().searchUserProfiles(userAuthority);
	}

}
