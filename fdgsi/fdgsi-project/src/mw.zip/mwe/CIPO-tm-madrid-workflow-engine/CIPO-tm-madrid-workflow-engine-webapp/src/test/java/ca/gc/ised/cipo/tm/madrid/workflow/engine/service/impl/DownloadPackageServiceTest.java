package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;

import javax.activation.DataHandler;

import org.activiti.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.BeanUtils;

import ca.gc.ic.cipo.patents.dtf.trs.CreateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.DownloadResponse;
import ca.gc.ic.cipo.patents.dtf.trs.GetTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestStateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.RequestStateCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestXsd;
import ca.gc.ic.cipo.schema.dtf.ServiceResponse;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.exception.FilePreviouslyDownloadedException;
import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.WipoInboundTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem.Status;

/**
 * Tests the delegate functions of the {@code DownloadPackageServiceImpl} class.
 *
 * @author J. Greene
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(MweWorkflowUtil.class)
public class DownloadPackageServiceTest {

    @Mock
    private DtfServiceManager mockDtfServiceManager;

    @Mock
    private PackageDownloadLogService mockPackageDownloadLogService;

    @Mock
    DelegateExecution mockExecution;

    @InjectMocks
    private DownloadPackageServiceImpl downloadPackageServiceImpl = new DownloadPackageServiceImpl();

    private String testRequestId = "999999999";

    private DownloadLogItem testDownloadLogItem;

    private TransferRequestStateXsd testReturnedState;

    private TransferRequestStateResponse testTxRequestStateResponse;

    private DownloadResponse testDownloadResponse;

    private CreateTransferRequest testCreateTransferReqeust;

    private TransferRequestXsd testTransferRequestXsd;

    private TransferRequestXsd testTransferRequestXsdReturned;

    private TransferRequestParamXsd testTransferRequestParamXsd;

    private WipoInboundTransferRequestCreator mockStrategy;

    private CreateResponse testCreateResponse;

    @Before
    public void init() throws Exception {
        MockitoAnnotations.initMocks(this);

        testReturnedState = new TransferRequestStateXsd();
        testTxRequestStateResponse = new TransferRequestStateResponse();
        testDownloadResponse = new DownloadResponse();
        testCreateTransferReqeust = new CreateTransferRequest();
        testTransferRequestXsd = new TransferRequestXsd();
        testTransferRequestParamXsd = new TransferRequestParamXsd();
        testTransferRequestXsdReturned = new TransferRequestXsd();
        testCreateResponse = new CreateResponse();

        PowerMockito.mockStatic(MweWorkflowUtil.class);

        mockStrategy = mock(WipoInboundTransferRequestCreator.class);
        when(mockDtfServiceManager.getInboundTransferRequestCreateStrategy(anyString())).thenReturn(mockStrategy);

        when(mockExecution.getVariable(TRANSFER_ITEM, String.class)).thenReturn(IN_NOTIF_PKG);
        doNothing().when(mockExecution).setVariable(anyString(), any(Object.class));
        when(mockExecution.getVariable(TRANSFER_REQ_ID_VAR, String.class)).thenReturn(testRequestId);

        doNothing().when(mockPackageDownloadLogService).insertLogEntry(any(DownloadLogItem.class));
        doNothing().when(mockPackageDownloadLogService).updateLogEntry(any(DownloadLogItem.class));

        testDownloadLogItem = new DownloadLogItem(testRequestId, IN_NOTIF_PKG, "TESTFILE.ZIP", "/c/temp/blah", null);
        testDownloadLogItem.setDlLogId(99999L);
        when(mockExecution.getVariable(TRANSFER_REQUEST_LOG, DownloadLogItem.class)).thenReturn(testDownloadLogItem);

        when(mockDtfServiceManager.downloadStagedFiles(anyInt())).thenReturn(testDownloadResponse);

        when(mockStrategy.createTransferReqeust(any(DelegateExecution.class), any(PackageDownloadLogService.class)))
            .thenReturn(testCreateTransferReqeust);
        when(mockDtfServiceManager.createTransferRequest(eq(testCreateTransferReqeust))).thenReturn(testCreateResponse);
        when(mockDtfServiceManager.createBusinessErrorLogItem(any(ServiceResponse.class)))
            .thenReturn(new BusinessErrorLogItem("MOCK"));
    }

    @Test
    public void testCreateTransferRequest1() throws IllegalAccessException, InvocationTargetException {
        System.out.println("#############################################");
        System.out.println("###       testCreateTransferRequest1      ###");
        System.out.println("#############################################");

        initCreateTransferRequestTests();

        // Happy path
        downloadPackageServiceImpl.createTransferRequest(mockExecution);
        verify(mockPackageDownloadLogService).insertLogEntry(any(DownloadLogItem.class));
    }

    // No longer a valid test. Downloading a previously downloaded file is accepted.
    // @Test
    public void testCreateTransferRequest2() throws IllegalAccessException, InvocationTargetException,
        FilePreviouslyDownloadedException, NoDownloadHistoryException {
        System.out.println("#############################################");
        System.out.println("###       testCreateTransferRequest2      ###");
        System.out.println("#############################################");

        initCreateTransferRequestTests();

        // Package already downloaded
        when(mockStrategy.createTransferReqeust(any(DelegateExecution.class), any(PackageDownloadLogService.class)))
            .thenThrow(FilePreviouslyDownloadedException.class);

        downloadPackageServiceImpl.createTransferRequest(mockExecution);
        verify(mockExecution).setVariable(TR_CREATE_STATUS, NOTHING_TO_DO);
    }

    @Test
    public void testCreateTransferRequest3() throws IllegalAccessException, InvocationTargetException,
        FilePreviouslyDownloadedException, NoDownloadHistoryException {
        System.out.println("#############################################");
        System.out.println("###       testCreateTransferRequest3      ###");
        System.out.println("#############################################");

        initCreateTransferRequestTests();

        // No transfer request ID returned (for whatever reason)
        when(mockStrategy.createTransferReqeust(any(DelegateExecution.class), any(PackageDownloadLogService.class)))
            .thenReturn(testCreateTransferReqeust);
        testCreateResponse.getTransferRequest().setRequestId(null);
        downloadPackageServiceImpl.createTransferRequest(mockExecution);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockExecution).setVariable(TR_CREATE_STATUS, ERROR);
    }

    @Test
    public void testCreateTransferRequest4() throws IllegalAccessException, InvocationTargetException,
        FilePreviouslyDownloadedException, NoDownloadHistoryException, BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###       testCreateTransferRequest4      ###");
        System.out.println("#############################################");

        initCreateTransferRequestTests();

        reset(mockDtfServiceManager);
        BpmnWebServiceCallException mockException = new BpmnWebServiceCallException("MOCK");
        when(mockDtfServiceManager.getInboundTransferRequestCreateStrategy(anyString())).thenReturn(mockStrategy);
        when(mockDtfServiceManager.createTransferRequest(eq(testCreateTransferReqeust))).thenThrow(mockException);

        // service manager throws BpmnWebServiceCallException
        when(mockStrategy.createTransferReqeust(any(DelegateExecution.class), any(PackageDownloadLogService.class)))
            .thenReturn(testCreateTransferReqeust);
        testCreateResponse.getTransferRequest().setRequestId(null);
        downloadPackageServiceImpl.createTransferRequest(mockExecution);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockExecution).setVariable(TR_CREATE_STATUS, ERROR);
    }

    @Test
    public void testCreateTransferRequest5() throws IllegalAccessException, InvocationTargetException,
        FilePreviouslyDownloadedException, NoDownloadHistoryException, BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###       testCreateTransferRequest5      ###");
        System.out.println("#############################################");

        initCreateTransferRequestTests();

        reset(mockStrategy);
        NoDownloadHistoryException ndhe = new NoDownloadHistoryException("MOCK");
        when(mockStrategy.createTransferReqeust(any(DelegateExecution.class), any(PackageDownloadLogService.class)))
            .thenThrow(ndhe);

        // No download history - first time running HWE
        when(mockStrategy.createTransferReqeust(any(DelegateExecution.class), any(PackageDownloadLogService.class)))
            .thenReturn(testCreateTransferReqeust);
        testCreateResponse.getTransferRequest().setRequestId(null);
        downloadPackageServiceImpl.createTransferRequest(mockExecution);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockExecution).setVariable(TR_CREATE_STATUS, ERROR);
    }

    private void initCreateTransferRequestTests() throws IllegalAccessException, InvocationTargetException {
        testTransferRequestParamXsd.setParameterCode(ParamNameCode.FILE_NAME.codeValue());
        testTransferRequestParamXsd.setParameterValue("TESTFILE.ZIP");
        testTransferRequestXsd.getParameters().add(testTransferRequestParamXsd);
        testCreateTransferReqeust.setTransferRequest(testTransferRequestXsd);

        BeanUtils.copyProperties(testTransferRequestXsd, testTransferRequestXsdReturned);
        testTransferRequestXsdReturned.setRequestId(testRequestId);

        testCreateResponse.setReasonCode(0);
        testCreateResponse.setReturnCode(0);
        testCreateResponse.setTransferRequest(testTransferRequestXsdReturned);
    }

    @Test
    public void testVerifyPackageTransferHappy() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###    testVerifyPackageTransferHappy     ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        // Happy path
        testReturnedState.setStateCode(RequestStateCode.COMPLETED.codeValue());

        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, COMPLETE);
        verify(mockPackageDownloadLogService).updateLogEntry(any(DownloadLogItem.class));
    }

    @Test
    public void testVerifyPackageTransferFail2() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###    testVerifyPackageTransferFail2    ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        testReturnedState.setStateCode(RequestStateCode.FAILED.codeValue());

        // failed
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, ERROR);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockPackageDownloadLogService).updateLogEntry(any(DownloadLogItem.class));

    }

    @Test
    public void testVerifyPackageTransferFail3() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###    testVerifyPackageTransferFail3    ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        // failed alternate
        testReturnedState.setStateCode(RequestStateCode.CANCELLED.codeValue());
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, ERROR);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockPackageDownloadLogService).updateLogEntry(any(DownloadLogItem.class));
    }

    @Test
    public void testVerifyPackageTransferInProgress1() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("### testVerifyPackageTransferInProgress1  ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        testReturnedState.setStateCode(RequestStateCode.INITIATED.codeValue());

        // initiated
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, INCOMPLETE);
        assertEquals(testDownloadLogItem.getDlStatus(), DownloadLogItem.Status.INPROGRESS.getValue());
    }

    @Test
    public void testVerifyPackageTransferInProgress2() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("### testVerifyPackageTransferInProgress2  ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        testReturnedState.setStateCode(RequestStateCode.IN_PROGRESS.codeValue());

        // in progress
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, INCOMPLETE);
        assertEquals(testDownloadLogItem.getDlStatus(), DownloadLogItem.Status.INPROGRESS.getValue());
    }

    @Test
    public void testVerifyPackageTransferInProgress3() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("### testVerifyPackageTransferInProgress3  ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        testReturnedState.setStateCode(RequestStateCode.READY_FOR_PROCESSING.codeValue());

        // ready for processing
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, INCOMPLETE);
        assertEquals(testDownloadLogItem.getDlStatus(), DownloadLogItem.Status.INPROGRESS.getValue());

    }

    @Test
    public void testVerifyPackageTransferUnknown1() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###   testVerifyPackageTransferUnknown1   ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        testReturnedState.setStateCode("BLLABGUGUGALBBLBLBBLABLBALBLBALBA");

        // returned status is unknown to HWE and the DTF service client
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, ERROR);
    }

    @Test
    public void testVerifyPackageTransferUnknown2() throws BpmnWebServiceCallException {
        System.out.println("#############################################");
        System.out.println("###   testVerifyPackageTransferUnknown2   ###");
        System.out.println("#############################################");

        initVerifyPackageTransferTests();

        testReturnedState.setStateCode(RequestStateCode.PURGED.codeValue()); // We don't do anything with this one.

        // returned status is meaningless to this particular mockExecution
        downloadPackageServiceImpl.verifyPackageTransfer(mockExecution);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockExecution).setVariable(PACKAGE_TRANSFER_STATE, ERROR);
    }

    private void initVerifyPackageTransferTests() throws BpmnWebServiceCallException {
        testReturnedState = new TransferRequestStateXsd();
        testReturnedState.setRequestId(testRequestId);
        testTxRequestStateResponse = new TransferRequestStateResponse();
        testTxRequestStateResponse.setTxRequestState(testReturnedState);
        testTxRequestStateResponse.setReasonCode(0);
        testTxRequestStateResponse.setReturnCode(0);

        when(mockExecution.getVariable(TRANSFER_REQ_ID_VAR, String.class)).thenReturn(testRequestId);
        when(mockDtfServiceManager.getTransferRequestState(any(GetTransferRequestState.class)))
            .thenReturn(testTxRequestStateResponse);
        when(mockExecution.getVariable(NUMBER_OF_REATTEMPTS, Integer.class)).thenReturn(0);
    }

    @Test
    public void testVerifyPackageMove1() throws Exception {
        System.out.println("#############################################");
        System.out.println("###         testVerifyPackageMove1        ###");
        System.out.println("#############################################");

        initTransferPackageToOutputTests();

        DownloadLogItem happyItem = new DownloadLogItem();
        happyItem.setDlLogId(99999L);
        happyItem.setDlDate(new Date());
        happyItem.setDlStatus(Status.SUCCESS.getValue());
        happyItem.setFileName("TESTFILE.ZIP");
        happyItem.setTargetLocation("/c/blah/bloo/blah");
        happyItem.setFileRegex("FUHFUHFUH99999_TESTFILE.ZIP");
        when(mockPackageDownloadLogService.getDownloadLogItemById(any(Long.class))).thenReturn(happyItem);

        // Happy path
        downloadPackageServiceImpl.verifyPackageMove(mockExecution);
        verify(mockExecution).setVariable(STAGING_TRANSFER_STATUS, COMPLETE);
    }

    @Test
    public void testVerifyPackageMove2() throws Exception {
        System.out.println("#############################################");
        System.out.println("###         testVerifyPackageMove2        ###");
        System.out.println("#############################################");

        initTransferPackageToOutputTests();

        DownloadLogItem happyItem = new DownloadLogItem();
        happyItem.setDlLogId(99999L);
        happyItem.setDlStatus(Status.DTF_STAGED.getValue());
        happyItem.setFileName("TESTFILE.ZIP");
        happyItem.setTargetLocation("/c/blah/bloo/blah");
        when(mockPackageDownloadLogService.getDownloadLogItemById(any(Long.class))).thenReturn(happyItem);

        // PowerMockito.when(MweWorkflowUtil.class, "fileExists", anyString(), anyString()).thenReturn(false);

        downloadPackageServiceImpl.verifyPackageMove(mockExecution);
        verify(mockExecution).setVariable(STAGING_TRANSFER_STATUS, INCOMPLETE);
    }

    @Test
    public void testVerifyPackageMove3() throws Exception {
        System.out.println("#############################################");
        System.out.println("###         testVerifyPackageMove3        ###");
        System.out.println("#############################################");

        initTransferPackageToOutputTests();

        DownloadLogItem happyItem = new DownloadLogItem();
        happyItem.setDlLogId(99999L);
        happyItem.setDlStatus(Status.FAIL.getValue());
        happyItem.setFileName("TESTFILE.ZIP");
        happyItem.setTargetLocation("/c/blah/bloo/blah");
        when(mockPackageDownloadLogService.getDownloadLogItemById(any(Long.class))).thenReturn(happyItem);

        downloadPackageServiceImpl.verifyPackageMove(mockExecution);
        verify(mockExecution).setVariable(eq(ERR_MSG_OBJECT_VAR), any(BusinessErrorLogItem.class));
        verify(mockExecution).setVariable(STAGING_TRANSFER_STATUS, ERROR);
    }

    private void initTransferPackageToOutputTests() {
        testDownloadResponse.setReasonCode(0);
        testDownloadResponse.setReturnCode(0);
        DataHandler testDataHandler = mock(DataHandler.class);
        testDownloadResponse.setZipStream(testDataHandler);

        when(mockExecution.getVariable(OUTPUT_FOLDER, String.class)).thenReturn("FUHFUHFUH_FOLDER");
        when(mockExecution.getVariable("packageFileName", String.class)).thenReturn("FUHFUHFUH99999.zip");

    }

}
