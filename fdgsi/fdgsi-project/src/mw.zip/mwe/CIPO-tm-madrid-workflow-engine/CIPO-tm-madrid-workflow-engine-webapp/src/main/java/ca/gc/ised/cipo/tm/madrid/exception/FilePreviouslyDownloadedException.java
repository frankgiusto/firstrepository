package ca.gc.ised.cipo.tm.madrid.exception;

/**
 * A simple exception class for catching this condition.
 *
 * @author J. Greene
 *
 */
public class FilePreviouslyDownloadedException extends Exception {

    private static final long serialVersionUID = 2946598431714245458L;

    public FilePreviouslyDownloadedException(String message) {
        super(message);
    }

}
