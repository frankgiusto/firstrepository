package ca.gc.ised.cipo.tm.mwe;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;

@javax.jws.WebService(endpointInterface = "ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType", targetNamespace = "http://cipo.ised.gc.ca/tm/mwe", serviceName = "MadridWorkflowEngineService", portName = "MadridWorkflowEngineServiceSOAP")
public class MadridWorkflowEngineServiceBindingImpl {

	@Autowired
	private MadridWorkflowEngineServicePortType madridWorkflowService;

	@Resource
	WebServiceContext wsContext;

	@PostConstruct
	public void init() {

		if (wsContext != null) {
			MessageContext mc = wsContext.getMessageContext();
			if (mc != null) {
				ServletContext servletContext = (ServletContext) mc.get(MessageContext.SERVLET_CONTEXT);
				SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, servletContext);
			}
		}
	}

	public HeartbeatResponseType getHeartbeat() throws MWEServiceFault {

		HeartbeatResponseType res = this.madridWorkflowService.getHeartbeat();

		return res;
	}

	public void assignUserTasks(AssignUserTasksRequest assignUserTasksRequest) throws MWEServiceFault {

		this.madridWorkflowService.assignUserTasks(assignUserTasksRequest);
	}

	public void unassignUserTasks(UnassignUserTasksRequest unassignUserTasksRequest) throws MWEServiceFault {

		this.madridWorkflowService.unassignUserTasks(unassignUserTasksRequest);
	}

	public void reassignTaskGroup(ReassignTaskGroupRequest reassignTaskGroupRequest) throws MWEServiceFault {

		this.madridWorkflowService.reassignTaskGroup(reassignTaskGroupRequest);
	}

	public void completeUserTask(CompleteUserTaskRequest completeUserTaskRequest) throws MWEServiceFault {

		this.madridWorkflowService.completeUserTask(completeUserTaskRequest);
	}

	public void createNotification(CreateNotificationRequest createNotificationRequest) throws MWEServiceFault {

		this.madridWorkflowService.createNotification(createNotificationRequest);
	}

	public void ackNotification(AckNotificationRequest ackNotificationRequest) throws MWEServiceFault {

		this.madridWorkflowService.ackNotification(ackNotificationRequest);
	}

}