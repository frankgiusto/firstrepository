package ca.gc.ised.cipo.tm.madrid.clients;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.lang.invoke.MethodHandles;
import java.util.Map;

import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.ws.MadridWorkflowServiceImpl;
import ca.gc.ised.cipo.tm.mwe.AckNotificationRequest;
import ca.gc.ised.cipo.tm.mwe.AssignUserTasksRequest;
import ca.gc.ised.cipo.tm.mwe.CompleteUserTaskRequest;
import ca.gc.ised.cipo.tm.mwe.ReassignTaskGroupRequest;
import ca.gc.ised.cipo.tm.mwe.UnassignUserTasksRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class MadridWorkflowServiceTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private MadridWorkflowServiceImpl madridWorkflowServiceImpl;

	@Autowired
	@Rule
	public ActivitiRule activitiSpringRule;

	@SuppressWarnings("unused")
	private ProcessInstance startProcessInstance(String key, Map<String, Object> processVars) {

		return activitiSpringRule.getRuntimeService().startProcessInstanceByKey(key, processVars);
	}

	@Test
	public void testAssignUserTasksRequestValidation() {

		Boolean success = true;
		String errStr = null;

		AssignUserTasksRequest req = new AssignUserTasksRequest();

		// Auth Id
		try {

			req.setAuthId("");
			req.getTaskIdList().add("taskId");
			req.setAssigneeId("userId");

			madridWorkflowServiceImpl.assignUserTasks(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Authority Id"));

		// Tasklist
		req = new AssignUserTasksRequest();
		success = true;

		try {

			req.setAuthId("authId");
			req.getTaskIdList().clear();
			req.setAssigneeId("userId");

			madridWorkflowServiceImpl.assignUserTasks(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Task Id"));

		// Assignee Id
		req = new AssignUserTasksRequest();
		success = true;

		try {

			req.setAuthId("authId");
			req.getTaskIdList().add("taskId");
			req.setAssigneeId(null);

			madridWorkflowServiceImpl.assignUserTasks(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("User Id"));

	}

	@Test
	public void testUnassignUserTasksRequestValidation() throws InterruptedException {

		Boolean success = true;
		String errStr = null;

		UnassignUserTasksRequest req = new UnassignUserTasksRequest();

		// Auth Id
		try {

			req.setAuthId("");
			req.getTaskIdList().add("taskId");

			madridWorkflowServiceImpl.unassignUserTasks(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Authority Id"));

		// Tasklist
		req = new UnassignUserTasksRequest();
		success = true;

		try {

			req.setAuthId("authId");
			req.getTaskIdList().clear();

			madridWorkflowServiceImpl.unassignUserTasks(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Task Id"));

	}

	@Test
	public void testReassignTaskGroupRequestValidation() {

		Boolean success = true;
		String errStr = null;

		ReassignTaskGroupRequest req = new ReassignTaskGroupRequest();

		// Auth Id
		try {

			req.setAuthId("");
			req.getTaskIdList().add("taskId");
			req.setGroupId("groupId");

			madridWorkflowServiceImpl.reassignTaskGroup(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Authority Id"));

		// Tasklist
		req = new ReassignTaskGroupRequest();
		success = true;

		try {

			req.setAuthId("authId");
			req.getTaskIdList().clear();
			req.setGroupId("groupId");

			madridWorkflowServiceImpl.reassignTaskGroup(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Task Id"));

		// Group Id
		req = new ReassignTaskGroupRequest();
		success = true;

		try {

			req.setAuthId("authId");
			req.getTaskIdList().add("taskId");
			req.setGroupId(null);

			madridWorkflowServiceImpl.reassignTaskGroup(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Group Id"));

	}

	@Test
	public void testCompleteUserTaskRequestValidation() {

		Boolean success = true;
		String errStr = null;

		CompleteUserTaskRequest req = new CompleteUserTaskRequest();

		// Task Id
		try {

			req.setTaskId("");
			req.setAssigneeId("userId");

			madridWorkflowServiceImpl.completeUserTask(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Task Id"));

		// User Id
		req = new CompleteUserTaskRequest();
		success = true;

		try {

			req.setTaskId("taskId");
			req.setAssigneeId(null);

			madridWorkflowServiceImpl.completeUserTask(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("User Id"));

	}

	@Test
	public void testAckNotificationRequestValidation() {

		Boolean success = true;
		String errStr = null;

		AckNotificationRequest req = new AckNotificationRequest();

		// Tasklist
		req = new AckNotificationRequest();
		success = true;

		try {

			req.getTaskIdList().clear();
			req.setAssigneeId("userId");

			madridWorkflowServiceImpl.ackNotification(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("Task Id"));

		// Assignee Id
		req = new AckNotificationRequest();
		success = true;

		try {

			req.getTaskIdList().add("taskId");
			req.setAssigneeId(null);

			madridWorkflowServiceImpl.ackNotification(req);

		} catch (Exception e) {
			success = false;
			errStr = e.getMessage();
		}

		assertFalse(success);
		assertTrue(errStr.contains("User Id"));

	}

}
