package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUTPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_GATHER_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_LOCATION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_LOCATION_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQ_ID_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_PACKAGE_VERIFY_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_TR_STATUS;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.patents.dtf.trs.CreateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.GetTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestStateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.model.RequestStateCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.UploadOutgoingPackageService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.OfficeToIbTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * A service that will handle delegated task actions from the {@code upload_hague_packages_to_wipo.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
@Service
public class UploadOutgoingPackageServiceImpl extends BusinessErrorHandlerImpl
    implements UploadOutgoingPackageService, Serializable {

    protected static final Logger LOG = LoggerFactory.getLogger(UploadOutgoingPackageServiceImpl.class);

    private static final long serialVersionUID = -6691624213942178495L;

    @Autowired
    protected DtfServiceManager dtfServiceManager;

    /**
     * {@inheritDoc}
     * <p>
     * Looks for export packages in the export folder and creates a collection of file paths to pass to the subprocess
     * as variable {@code packageLocationList}. The process variable {@code packageGatherStatus} is set accordingly:
     * </p>
     * {@code [  1]} successful package creation,<br/>
     * {@code [ 10]} if no packages were found,<br/>
     * {@code [ -1]} if an error occurred
     * <p>
     * </p>
     */
    @Override
    public void prepareUploadPackage(DelegateExecution execution) {
        Integer packageGatherStatus = COMPLETE;
        List<String> packageLocationList = null;

        String outputFolder = execution.getVariable(OUTPUT_FOLDER, String.class);

        Path outputFolderPath = Paths.get(outputFolder);
        if (Files.exists(outputFolderPath) && Files.isDirectory(outputFolderPath)) {
            File outputFolderFile = new File(outputFolder);
            File[] outputFolderFiles = outputFolderFile.listFiles();

            if (outputFolderFiles.length > 0) {
                packageLocationList = new ArrayList<>();
                for (File outputFile : outputFolderFiles) {
                    if (outputFile.isFile()) {
                        packageLocationList.add(outputFile.getAbsolutePath());
                    }
                }
                if (packageLocationList.size() > 0) {
                    execution.setVariable(PACKAGE_LOCATION_LIST, packageLocationList);
                } else {
                    packageGatherStatus = NOTHING_TO_DO;
                    LOG.debug("No export files were found in output directory [" + outputFolder + "].");
                }
            } else {
                packageGatherStatus = NOTHING_TO_DO;
                LOG.debug("No export files were found in output directory [" + outputFolder + "].");
            }
        } else {
            packageGatherStatus = ERROR;
            registerGenericMweBusinessError(execution, "Unable to find location path [" + outputFolder + "]");
        }

        execution.setVariable(PACKAGE_GATHER_STATUS, packageGatherStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Creates a transfer request via DTF to upload the CIPO Hague package. The process variable
     * {@code transferRequestId} is set accordingly. The other process variable, {@code uploadTrStatus} is set according
     * to the following:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [  -1]} if an exception occurred<br/>
     * </p>
     */
    @Override
    public void createTransferRequest(DelegateExecution execution) {
        Integer uploadTrStatus = COMPLETE;

        OfficeToIbTransferRequestCreator txCreator = new OfficeToIbTransferRequestCreator();

        try {

            CreateTransferRequest outgoingTransferRequest = txCreator.createOutgoingTransferRequest(execution,
                dtfServiceManager.getEnvironment());

            CreateResponse response = dtfServiceManager.createTransferRequest(outgoingTransferRequest);

            String transferRequestId = response.getTransferRequest().getRequestId();
            if (StringUtils.isBlank(transferRequestId)) {
                registerGenericMweBusinessError(execution, "No transfer request ID was returned from service!");
                uploadTrStatus = ERROR;
            } else {
                execution.setVariableLocal(TRANSFER_REQ_ID_VAR, transferRequestId);
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            uploadTrStatus = ERROR;
        } catch (IOException ioe) {
            registerGenericMweBusinessError(execution, "Cannot create the upload data for the transfer request!", ioe);
            uploadTrStatus = ERROR;
        }

        execution.setVariableLocal(UPLOAD_TR_STATUS, uploadTrStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Verifies the DTF upload process and reports on the progress and the sets the process variable
     * {@code packageVerifyStatus} according to the outcome of the verification:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [   0]} if incomplete,<br/>
     * {@code [  -1]} if an exception occurred (no retry), <br/>
     * </p>
     */
    @Override
    public void verifyPackageTransfer(DelegateExecution execution) {
        TransferRequestStateXsd inputState = new TransferRequestStateXsd();
        String requestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);
        inputState.setRequestId(requestId);
        Integer packageVerifyStatus = COMPLETE;

        GetTransferRequestState request = new GetTransferRequestState();
        request.setRacfUser(MweWorkflowUtil.getRacfUser());
        request.setTransferRequestState(inputState);

        try {
            TransferRequestStateResponse response = dtfServiceManager.getTransferRequestState(request);

            RequestStateCode returnedStateCode = RequestStateCode
                .getEnumByCodeValue(response.getTxRequestState().getStateCode());
            if (returnedStateCode == null) {
                registerGenericMweBusinessError(execution, "Request State Code ["
                    + response.getTxRequestState().getStateCode() + "] is unknown to this application.");
                packageVerifyStatus = ERROR;
            } else {
                switch (returnedStateCode) {
                    case FAILED:
                    case CANCELLED:
                        BusinessErrorLogItem businessErrorLogItem = dtfServiceManager
                            .createBusinessErrorLogItem(response);
                        businessErrorLogItem.setMessage("DTF Transfer for request #" + requestId + " failed.");
                        execution.setVariable(ERR_MSG_OBJECT_VAR, businessErrorLogItem);
                        packageVerifyStatus = ERROR;
                        LOG.info("Transfer request #" + requestId + " failed.");
                        break;
                    case IN_PROGRESS:
                    case INITIATED:
                    case READY_FOR_PROCESSING:
                        packageVerifyStatus = INCOMPLETE;
                        LOG.info("Transfer request #" + requestId + " is incomplete.");
                        break;
                    case COMPLETED:
                        packageVerifyStatus = COMPLETE;
                        LOG.info("Transfer request #" + requestId + " succeeded!");
                        break;
                    default:
                        // No handling available for other edge cases
                        registerGenericMweBusinessError(execution,
                            "Unable to process the DTF transfer state [" + returnedStateCode.codeValue() + "]");
                        packageVerifyStatus = ERROR;
                }
            }

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            packageVerifyStatus = ERROR;
        }

        execution.setVariable(UPLOAD_PACKAGE_VERIFY_STATUS, packageVerifyStatus);
    }

    /** {@inheritDoc} */
    @Override
    public void cleanUp(DelegateExecution execution) {
        String packageLocation = execution.getVariableLocal(PACKAGE_LOCATION, String.class);
        Path packageLocationPath = Paths.get(packageLocation);

        try {
            Files.deleteIfExists(packageLocationPath);
        } catch (IOException ioe) {
            LOG.warn("Could not clean up (remove) file [" + packageLocation + "] upon successful upload.");
        }
    }

    /** {@inheritDoc} */
    @Override
    public void movePackageToFail(DelegateExecution execution) {
        String failFolder = execution.getVariable(FAIL_FOLDER, String.class);
        String packageLocation = execution.getVariableLocal(PACKAGE_LOCATION, String.class);
        File packageLocationFile = new File(packageLocation);

        if (packageLocationFile != null) {
            try {
                MweWorkflowUtil.moveFile(packageLocationFile, failFolder);
            } catch (IOException ioe) {
                LOG.warn("Could not move file [" + packageLocation + "] to failure folder [" + failFolder + "].");
            }
        }
    }

}
