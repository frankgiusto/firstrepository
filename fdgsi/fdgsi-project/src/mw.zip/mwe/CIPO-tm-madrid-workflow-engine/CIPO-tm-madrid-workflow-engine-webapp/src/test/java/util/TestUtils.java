package util;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.runtime.ProcessInstance;

/**
 * Utility class to help with JUnit tests and clean up the clutter in the test logic.
 *
 * @author J. Greene
 *
 */
public final class TestUtils {

    /**
     * Asserts the Activiti event fired during process flow mockExecution.
     *
     * @param historyService the {@code HistoryService} object pointing to the process engine instance
     * @param eventName the name of the Activiti event
     * @param count the number of times it is expected to fire (0 if not expected to fire)
     */
    public static void assertActivitiEventFired(HistoryService historyService, String eventName, int count) {
        List<HistoricActivityInstance> activitiInstances = historyService.createHistoricActivityInstanceQuery().list();
        boolean eventFired = false;
        int x = 0;
        for (HistoricActivityInstance inst : activitiInstances) {
            if (inst.getActivityId().equals(eventName)) {
                assertNotNull("Historic activity instance " + inst.getActivityId() + " has no start time",
                    inst.getStartTime());
                assertNotNull("Historic activity instance " + inst.getActivityId() + " has no end time",
                    inst.getEndTime());
                eventFired = true;
                x++;
            }
        }
        if (count > 0 && !eventFired) {
            fail("The event or task named '" + eventName + "' did not fire");
        }
        if (x != count) {
            fail("Expected event or task named '" + eventName + "' to fire " + count + " times but instead fired " + x
                + " times");
        }
    }

    /**
     * Asserts the process did complete.
     *
     * @param historyService the {@code HistoryService} object pointing to the process engine instance
     * @param instance the process instance related to the test
     */
    public static void assertCompletion(HistoryService historyService, ProcessInstance instance) {
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
            .processInstanceId(instance.getProcessInstanceId()).singleResult();

        // Make sure the process instance actually ended.
        Date endTime = historicProcessInstance.getEndTime();
        assertNotNull("Process instance " + instance.getProcessInstanceId() + " did not end", endTime);
    }

    /**
     * Convenience method to start a process instance and log the fact that it started for debugging purposes.
     *
     * @param processKey the process key related to the flow to be started
     * @param runtimeService the {@code RuntimeService} service needed to start the process.
     * @param processVariables the process variables (if any)
     * @return
     */
    public static ProcessInstance startProcessInstance(String processKey, RuntimeService runtimeService,
                                                       Map<String, Object> processVariables) {
        ProcessInstance testInstance = null;
        if (processVariables == null) {
            testInstance = runtimeService.startProcessInstanceByKey(processKey);
        } else {
            testInstance = runtimeService.startProcessInstanceByKey(processKey, processVariables);
        }

        System.out.println("Process instance started with ID " + testInstance.getProcessInstanceId());
        return testInstance;
    }

    /**
     * Convenience method to start a process instance and log the fact that it started for debugging purposes.
     *
     * @param processKey the process key related to the flow to be started
     * @param runtimeService the {@code RuntimeService} service needed to start the process.
     * @return
     */
    public static ProcessInstance startProcessInstance(String processKey, RuntimeService runtimeService) {
        return startProcessInstance(processKey, runtimeService, null);
    }
}
