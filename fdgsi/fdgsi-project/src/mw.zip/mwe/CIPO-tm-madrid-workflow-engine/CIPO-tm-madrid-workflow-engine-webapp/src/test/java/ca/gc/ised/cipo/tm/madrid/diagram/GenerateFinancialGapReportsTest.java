package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.GENERATE_FINANCIAL_GAP_REPORTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_SERVICE_POLL_INTERVAL_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REPORT_TYPE_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RGS_ERROR_STATUS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionGapReportGenerationServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestReportGenerationServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.model.ReportTypeEnumResolver;
import util.TestUtils;

/**
 * A test class for the {@code generate-financial-gap-reports.bpmn} workflow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class GenerateFinancialGapReportsTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    protected TestFinancialTransactionGapReportGenerationServiceImpl testFinancialTransactionGapReportGenerationServiceImpl;

    @Autowired
    protected TestReportGenerationServiceImpl testReportGenerationServiceImpl;

    @Before
    public void init() {
        testFinancialTransactionGapReportGenerationServiceImpl.setGapReportEmailNotificationStatusReturnObject(null);

        // Happy path for the report sub-process (not tested here)
        testReportGenerationServiceImpl.setPersistReportStatus(COMPLETE);
        testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);
        testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn"})
    public void happyPathTest() {
        System.out.println("#############################################");
        System.out.println("###             happyPathTest             ###");
        System.out.println("#############################################");

        testFinancialTransactionGapReportGenerationServiceImpl
            .setGapReportEmailNotificationStatusReturnObject(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(GENERATE_FINANCIAL_GAP_REPORTS, runtimeService,
            getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "generateGapReportsEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "notifyUsersOfGapReportSuccessTask", 1);
    }

    // TODO Put back when "getReportTypesForTest" is fixed @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn"})
    public void subReportErrorTest() {
        System.out.println("#############################################");
        System.out.println("###          subReportErrorTest           ###");
        System.out.println("#############################################");

        testFinancialTransactionGapReportGenerationServiceImpl
            .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
        testReportGenerationServiceImpl.setReportGenerationInitiationStatus(ERROR);
        testReportGenerationServiceImpl.setRecoverableErrorStatus(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(GENERATE_FINANCIAL_GAP_REPORTS, runtimeService,
            getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "notifyUsersOfGapReportSuccessTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorHandlerEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "generateGapReportsSubprocessErrorEndEvent", 1);
    }

    // TODO Put back when "getReportTypesForTest" is fixed @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn"})
    public void rgsErrorStateTest() {
        System.out.println("#############################################");
        System.out.println("###          rgsErrorStateTest            ###");
        System.out.println("#############################################");

        testFinancialTransactionGapReportGenerationServiceImpl
            .setGapReportEmailNotificationStatusReturnObject(COMPLETE);
        testReportGenerationServiceImpl.setReportGenerationInitiationStatus(COMPLETE);
        testReportGenerationServiceImpl.setPersistReportStatus(RGS_ERROR_STATUS);
        testReportGenerationServiceImpl.setReportGenerationCallingUpdateStatus(COMPLETE);

        ProcessInstance testInstance = TestUtils.startProcessInstance(GENERATE_FINANCIAL_GAP_REPORTS, runtimeService,
            getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "businessErrorHandlerEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "handleRgsErrorStatusTask", getReportTypesForTest().size());
        TestUtils.assertActivitiEventFired(historyService, "notifyUsersOfGapReportSuccessTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "generateGapReportsEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/finance/generate-financial-gap-reports.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/core/report_generation_subprocess.bpmn"})
    public void emailNotificationErrorTest() {
        System.out.println("#############################################");
        System.out.println("###      emailNotificationErrorTest       ###");
        System.out.println("#############################################");

        testFinancialTransactionGapReportGenerationServiceImpl.setGapReportEmailNotificationStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(GENERATE_FINANCIAL_GAP_REPORTS, runtimeService,
            getParameterMap());

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        TestUtils.assertActivitiEventFired(historyService, "notifyUsersOfGapReportErrorEndEvent", 1);
        TestUtils.assertActivitiEventFired(historyService, "generateGapReportsEndEvent", 0);
        TestUtils.assertActivitiEventFired(historyService, "businessErrorHandlerEndEvent", 1);
    }

    protected Map<String, Object> getParameterMap() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(PACKAGE_ID, new BigDecimal(10001L));
        processVariables.put(REPORT_SERVICE_POLL_INTERVAL_VAR, "PT1S");
        processVariables.put(REPORT_TYPE_LIST, getReportTypesForTest());
        return processVariables;
    }

    protected List<ReportTypeEnumResolver> getReportTypesForTest() {
        List<ReportTypeEnumResolver> reportTypeList = new ArrayList<>();
        // TODO Put it back when we figure out the values
        // reportTypeList.add(new ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_GAP_PDF));
        // reportTypeList.add(new ReportTypeEnumResolver(ReportTypeEnum.FINANCIAL_GAP_XLS));
        return reportTypeList;
    }
}
