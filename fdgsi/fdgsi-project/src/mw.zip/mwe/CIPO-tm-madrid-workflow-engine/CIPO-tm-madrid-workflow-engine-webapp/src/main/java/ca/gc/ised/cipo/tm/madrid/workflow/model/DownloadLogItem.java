package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.CustomDateSerializer;

/**
 * A domain object to represent a download log entry in the datastore.
 *
 * @author J. Greene
 *
 */
public final class DownloadLogItem implements Serializable, Comparable<DownloadLogItem> {

    private static final long serialVersionUID = -3867832171124755582L;

    private Long dlLogId;

    private String xferReqId;

    private String packageType;

    private String fileName;

    private String targetLocation;

    private String fileRegex;

    private String dlStatus;

    private Date dlDate;

    private String msg;

    private Date xferReqDate;

    public DownloadLogItem() {
    }

    public DownloadLogItem(String xferReqId, String packageType, String fileName, String outputDirectoryString,
                           String fileRegex) {
        this.xferReqId = xferReqId;
        this.packageType = packageType;
        this.fileName = fileName;
        this.fileRegex = fileRegex;
        this.targetLocation = outputDirectoryString;
        this.dlStatus = Status.INPROGRESS.getValue();
        this.xferReqDate = new Date();
    }

    public enum Status {
      //@formatter:off
        SUCCESS("success"),
        FAIL("fail"),
        INPROGRESS("in progress"),
        DTF_STAGED("dtf staged"),
        FAILWITHRETRY("fail with retry"),
        FAILNOTFOUND("fail (not found)");
      //@formatter:on
        private String value;

        private Status(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

    }

    /**
     * @return the dlLogId
     */
    public Long getDlLogId() {
        return dlLogId;
    }

    /**
     * @param dlLogId the dlLogId to set
     */
    public void setDlLogId(Long dlLogId) {
        this.dlLogId = dlLogId;
    }

    /**
     * @return the xferReqId
     */
    public String getXferReqId() {
        return xferReqId;
    }

    /**
     * @param xferReqId the xferReqId to set
     */
    public void setXferReqId(String xferReqId) {
        this.xferReqId = xferReqId;
    }

    /**
     * @return the packageType
     */
    public String getPackageType() {
        return packageType;
    }

    /**
     * @param packageType the packageType to set
     */
    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the fileRegex
     */
    public String getFileRegex() {
        return fileRegex;
    }

    /**
     * @param fileRegex the fileRegex to set
     */
    public void setFileRegex(String stagedPkgName) {
        this.fileRegex = stagedPkgName;
    }

    /**
     * @return the dlStatus
     */
    public String getDlStatus() {
        return dlStatus;
    }

    /**
     * @param dlStatus the dlStatus to set
     */
    public void setDlStatus(String dlStatus) {
        this.dlStatus = dlStatus;
    }

    /**
     * @return the dlDate
     */
    @JsonSerialize(using = CustomDateSerializer.class)
    public Date getDlDate() {
        return dlDate;
    }

    /**
     * @param dlDate the dlDate to set
     */
    public void setDlDate(Date dlDate) {
        this.dlDate = dlDate;
    }

    /**
     * @return the xferReqDate
     */
    @JsonSerialize(using = CustomDateSerializer.class)
    public Date getXferReqDate() {
        return xferReqDate;
    }

    /**
     * @param xferReqDate the xferReqDate to set
     */
    public void setXferReqDate(Date xferReqDate) {
        this.xferReqDate = xferReqDate;
    }

    /**
     * @return the targetLocation
     */
    public String getTargetLocation() {
        return targetLocation;
    }

    /**
     * @param targetLocation the targetLocation to set
     */
    public void setTargetLocation(String targetLocation) {
        this.targetLocation = targetLocation;
    }

    /**
     * @return the msg
     */
    public String getMsg() {
        return msg;
    }

    /**
     * @param msg the msg to set
     */
    public void setMsg(String msg) {
        this.msg = msg;
    }

    /** {@inheritDoc} */
    @Override
    public int compareTo(DownloadLogItem o) {
        return this.xferReqDate.compareTo(o.xferReqDate) * -1;
    }

}
