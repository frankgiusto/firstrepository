package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;
import java.util.Date;

/**
 * A simple bean to hold a group of package files for processing.
 *
 * @author J. Greene
 *
 */
public class PackageUnit implements Serializable, Comparable<PackageUnit> {

    private static final long serialVersionUID = 2L;

    private String xmlFileName;

    private String imgFileName;

    private String pdfFileName;

    private Date xmlRetrieveDate;

    private Date imgRetrieveDate;

    /**
     * @return the xmlFileName
     */
    public String getXmlFileName() {
        return xmlFileName;
    }

    /**
     * @param xmlFileName the xmlFileName to set
     */
    public void setXmlFileName(String xmlFileName) {
        this.xmlFileName = xmlFileName;
    }

    /**
     * @return the imgFileName
     */
    public String getImgFileName() {
        return imgFileName;
    }

    /**
     * @param imgFileName the imgFileName to set
     */
    public void setImgFileName(String imgFileName) {
        this.imgFileName = imgFileName;
    }

    /**
     * @return the xmlRetrieveDate
     */
    public Date getXmlRetrieveDate() {
        return xmlRetrieveDate;
    }

    /**
     * @param xmlRetrieveDate the xmlRetrieveDate to set
     */
    public void setXmlRetrieveDate(Date xmlRetrieveDate) {
        this.xmlRetrieveDate = xmlRetrieveDate;
    }

    /**
     * @return the imgRetrieveDate
     */
    public Date getImgRetrieveDate() {
        return imgRetrieveDate;
    }

    /**
     * @param imgRetrieveDate the imgRetrieveDate to set
     */
    public void setImgRetrieveDate(Date imgRetrieveDate) {
        this.imgRetrieveDate = imgRetrieveDate;
    }

    /**
     * @return the pdfFileName
     */
    public String getPdfFileName() {
        return pdfFileName;
    }

    /**
     * @param pdfFileName the pdfFileName to set
     */
    public void setPdfFileName(String pdfFileName) {
        this.pdfFileName = pdfFileName;
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((imgFileName == null) ? 0 : imgFileName.hashCode());
        result = prime * result + ((xmlFileName == null) ? 0 : xmlFileName.hashCode());
        result = prime * result + ((pdfFileName == null) ? 0 : pdfFileName.hashCode());
        return result;
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        PackageUnit other = (PackageUnit) obj;
        if (imgFileName == null) {
            if (other.imgFileName != null) {
                return false;
            }
        } else if (!imgFileName.equals(other.imgFileName)) {
            return false;
        }
        if (xmlFileName == null) {
            if (other.xmlFileName != null) {
                return false;
            }
        } else if (!xmlFileName.equals(other.xmlFileName)) {
            return false;
        }
        if (pdfFileName == null) {
            if (other.pdfFileName != null) {
                return false;
            }
        } else if (!pdfFileName.equals(other.pdfFileName)) {
            return false;
        }
        return true;
    }

    /** {@inheritDoc} */
    @Override
    public int compareTo(PackageUnit o) {
        // Orders file names from oldest to newest based on WIPOs YYYYMM or YYYYWW format
        String s1 = this.xmlFileName;
        String s2 = o.getXmlFileName();

        return s1.compareTo(s2);
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return "PackageUnit [xmlFileName=" + xmlFileName + ", imgFileName=" + imgFileName + ", pdfFileName="
            + pdfFileName + "]";
    }

}
