package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

public interface MadridDelegateService {

	void checkForExistingMarks(DelegateExecution execution) throws Exception;

	void checkForNotifications(DelegateExecution execution) throws Exception;

	void createConsoleTask(DelegateExecution execution);

	void updateConsoleTaskStatus(DelegateExecution execution);

	void notifyAdmin(DelegateExecution execution);

	void fetchTransactions(DelegateExecution execution);

}
