package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import ca.gc.ised.cipo.tm.madrid.exception.UserAuthorityException;

public interface MadridUserAuthorityService {

	/**
	 * A method to verify that the a user is able to be assigned a task
	 *
	 * @param userId
	 *            The id of the user being assigned to the task
	 * @param authId
	 *            The id of the user assigning the task
	 * @param taskId
	 *            The id of the task
	 *
	 * @return
	 */
	public Boolean verifyAssignAuthority(String authId, String taskId, String userId) throws UserAuthorityException;

	/**
	 * A method to verify a user has authority to assign a task
	 *
	 * @param authId
	 *            The id of the user assigning the task
	 * @param taskId
	 *            The id of the task
	 * @return
	 */
	public Boolean verifyUnassignAuthority(String authId, String taskId) throws UserAuthorityException;

	/**
	 * A method to verify a user has authority to complete a task
	 *
	 * @param userId
	 *            The id of the user completing the task
	 * @param taskId
	 *            The id of the task
	 * @return
	 */
	public Boolean verifyTaskCompletionAuthority(String taskId, String userId) throws UserAuthorityException;

	/**
	 * A method to verify a user has authority to re-assign the group of a task
	 *
	 * @param userId
	 *            The id of the user completing the task
	 * @param taskId
	 *            The id of the task
	 * @return
	 */
	public Boolean verifyReassignTaskGroup(String authId, String taskId, String groupId) throws UserAuthorityException;

	/**
	 * A method to verify a user has authority to acknowledge a notification
	 * task
	 *
	 * @param userId
	 *            The id of the user acknowledging the notification task
	 * @param taskId
	 *            The id of the task
	 * @return
	 */
	public Boolean verifyAckNotificationAuthority(String taskId, String userId) throws UserAuthorityException;

}
