package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code send_reconciled_fees_to_financial_system.bpmn} process flow, which is a call activity in
 * {@code process_hague_financial_transactions_from_wipo.bpmn}
 *
 * @author J. Greene
 *
 */
public interface FinancialTransactionSubmitService extends BusinessErrorHandler {

    /**
     * Service task method responsible for creating a DTF transfer request to send the reconciled fee XML file to the
     * financial system.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void createTransferRequestFeeXmlToIfms(DelegateExecution execution);

    /**
     * Service task method responsible for validating the success of the DTF transfer upload.
     *
     * @see FinancialTransactionReconcileService#createTransferRequestFeeXmlToIfms(DelegateExecution)
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void verifyFeeXmlTransferRequest(DelegateExecution execution);

    /**
     * Service task method responsible for updating the status of the XML file transfer to the financial system.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void updateFeeXmlDropStatus(DelegateExecution execution);

    /**
     * Service task method responsible for moving the prepared upload package to an archive folder upon failure.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void movePackageToFailFolder(DelegateExecution execution);

    /**
     * Cleans up files left in the outgoing staging area locally.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution
     */
    void cleanUp(DelegateExecution execution);
}
