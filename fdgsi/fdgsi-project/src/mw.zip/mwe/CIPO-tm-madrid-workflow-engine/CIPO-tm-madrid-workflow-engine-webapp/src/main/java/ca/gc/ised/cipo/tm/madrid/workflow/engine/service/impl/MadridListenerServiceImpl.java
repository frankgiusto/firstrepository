package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;
import java.util.Set;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.task.IdentityLink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MadridListenerService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

@Service
public class MadridListenerServiceImpl implements MadridListenerService {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Value("${mwe.mts.service.endpoint.hostname}")
	private String mtsHostUrl;

	@Value("${application.acronym}")
	private String serviceName;

	@Autowired
	MtsServiceManager mtsServiceManager;

	@Override
	public void syncConsoleTask(DelegateTask delegateTask) {

		// Pull vars off the process flow
		BigDecimal consoleTaskId = (BigDecimal) delegateTask.getExecution()
				.getVariable(ProcessFlowConstants.CONSOLE_TASK_ID);

		String groupId = (String) delegateTask.getExecution().getVariable(ProcessFlowConstants.CANDIDATE_GROUP_ID);
		String taskType = (String) delegateTask.getExecution().getVariable(ProcessFlowConstants.CONSOLE_TASK_TYPE);

		String userTaskId = delegateTask.getId();

		// If we were given a group Id for the Task, set it.
		if (groupId != null) {

			// Remove any other groups assigned.
			Set<IdentityLink> idLinks = delegateTask.getCandidates();
			for (IdentityLink identityLink : idLinks) {
				delegateTask.deleteCandidateGroup(identityLink.getGroupId());
			}

			// Assign the given one.
			delegateTask.addCandidateGroup(groupId);

		}

		// Set some variables on the UserTask
		if (taskType != null) {

			delegateTask.createVariableLocal(ProcessFlowConstants.CONSOLE_TASK_TYPE, taskType);
			delegateTask.createVariableLocal(ProcessFlowConstants.CONSOLE_TASK_ID, consoleTaskId.toString());

		}

		try {

			LOG.debug("Updating console Task.");
			mtsServiceManager.updateConsoleTaskReference(userTaskId, consoleTaskId);

		} catch (Exception e) {

			LOG.error("Creating MTS Failure Signal: " + e.getMessage());

			// Remove and assigned groups so the task can get deleted.
			Set<IdentityLink> idLinks = delegateTask.getCandidates();
			for (IdentityLink identityLink : idLinks) {
				delegateTask.deleteCandidateGroup(identityLink.getGroupId());
			}

			// TODO Add more descriptive error
			delegateTask.getExecution().setVariable(ProcessFlowConstants.ERR_MSG_DESC_VAR, e.getMessage());

			// We can't throw exceptions in UserTask listeners. Instead we
			// signal an error.
			RuntimeService runtimeService = delegateTask.getExecution().getEngineServices().getRuntimeService();
			runtimeService.signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_FAILURE, delegateTask.getExecutionId());

		}

	}

	/**
	 * This method takes the String array and separates it into id and type.
	 *
	 */
	@Override
	public void setTransactionDescValues(DelegateExecution execution) {

		String[] transDesc = (String[]) execution.getVariable(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_DESC);

		if (transDesc != null && transDesc.length == 2) {

			execution.createVariableLocal(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID, transDesc[0]);
			execution.createVariableLocal(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_TYPE, transDesc[1]);

		}

	}

	/**
	 * For whatever reason, variables in Error End Events can't be passed up to
	 * the Boundary Error Events that catch the error.
	 *
	 * This method solves the problem by setting the variable in the Super
	 * execution
	 *
	 *
	 */
	@Override
	public void promoteErrorMessageToCallingExecution(DelegateExecution execution) {

		Object errMsgObject = execution.getVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR);

		if (errMsgObject != null) {

			execution.getEngineServices().getRuntimeService().setVariable(execution.getSuperExecutionId(),
					ProcessFlowConstants.ERR_MSG_OBJECT_VAR, execution.getVariable("errorMsgObject"));

		}

	}

	@Override
	/**
	 * Used in the process manual transactions process when a transaction with a
	 * unexpected type is encountered.
	 *
	 * {@inheritDoc}
	 */
	public void createUnknownTransactionTypeError(DelegateExecution execution) {

		// Fetch the transaction type from the process
		String transType = (String) execution.getVariable(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_TYPE);

		BusinessErrorLogItem businessErrorLogItem = new BusinessErrorLogItem(
				transType + " is not a recognized manual transaction type.");

		businessErrorLogItem.setCipoServiceFaultOrigin(true);
		businessErrorLogItem.setServiceName(serviceName);
		businessErrorLogItem.setProcessInstanceId(execution.getProcessInstanceId());
		businessErrorLogItem.setProcessDefinitionName(execution.getCurrentActivityName());

		execution.setVariable(ProcessFlowConstants.ERR_MSG_OBJECT_VAR, businessErrorLogItem);

	}

	/**
	 * This method is only implemented in the testing version of this class
	 */
	@Override
	public void debugUserTask(DelegateTask delegateTask) {

	}

	/**
	 * This method is only implemented in the testing version of this class
	 */
	@Override
	public void debugListener(DelegateExecution execution) {

	}

}
