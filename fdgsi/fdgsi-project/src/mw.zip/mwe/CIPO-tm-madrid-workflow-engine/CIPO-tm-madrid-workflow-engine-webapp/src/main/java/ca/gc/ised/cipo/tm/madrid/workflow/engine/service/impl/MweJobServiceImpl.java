package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_OUTGOING_MANUAL_TASK;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_OUTGOING_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DOWNLOAD_INCOMING_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_IRREG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_MADRID_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUT_DAILY_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_OUTGOING_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PERSIST_INCOMING_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PROCESS_AUTOMATED_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PROCESS_AUTOMATED_TRANSACTION_PAIRS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.REMOTE_FILE_NAME;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_OUTGOING_PACKAGE;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.runtime.ProcessInstance;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManagerImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.BusinessErrorLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MweJobService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingMonthlyFinPkgJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingPackageDownloadJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingPackagePersistJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingProcessManualTransJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingMessageJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingMonthlyFinPkgJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingTaskJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.SystemInfo;

/**
 * A simple service layer class responsible for stop/start process engine job actions related to the Madrid TM workflow
 * process definitions.
 *
 * @author J. Greene
 *
 */
@Service
public class MweJobServiceImpl implements MweJobService {

    protected static final Logger LOG = LoggerFactory.getLogger(MweJobServiceImpl.class);

    protected final DateFormat POM_DATE_FORMAT = new SimpleDateFormat("yyyyMMddHHmmssz");

    protected final DateFormat OUTPUT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");

    protected final String nl = System.getProperty("line.separator");

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected DtfServiceManager dtfServiceManager;

    @Autowired
    protected MpsServiceManager mpsServiceManager;

    @Autowired
    protected MfsServiceManager mfsServiceManager;

    @Autowired
    protected MtsServiceManagerImpl mtsServiceManager;

    // @Autowired
    // protected RgsServiceManager rgsServiceManager;

    @Autowired
    protected PackageDownloadLogService packageDownloadLogService;

    @Autowired
    protected BusinessErrorLogService businessErrorLogService;

    @Autowired
    Environment env;

    @Override
    public String processManualTransactions(IncomingProcessManualTransJob job) {

        String processId = null;
        String processKey = "processManualTransactions";
        BigDecimal specifiedTransId = null;
        Map<String, Object> processVars = new HashMap<String, Object>();

        // If a transaction Id is provided, we ignore all other search criteria.
        if (job != null && job.getTransId() != null) {

            try {
                specifiedTransId = new BigDecimal(job.getTransId());
            } catch (NumberFormatException e) {
                specifiedTransId = null;
            }

            processVars.put(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID, specifiedTransId);

        }

        // else {
        //
        // throw new IllegalArgumentException("At this time, a Transaction Id is
        // mandatory.");
        //
        // }

        processId = runtimeService.startProcessInstanceByKey(processKey, processVars).getProcessInstanceId();

        return processId;
    }

    @Override
    public String processAutomatedTransactions() {
        evaluateProcessState(PROCESS_AUTOMATED_TRANSACTIONS, null, null);
        ProcessInstance instance = runtimeService.startProcessInstanceByKey(PROCESS_AUTOMATED_TRANSACTIONS);
        String infoString = "Started - PROCESS AUTOMATED TRANSACTIONS flow with process instance ID: "
            + instance.getProcessInstanceId();
        LOG.debug(infoString);
        return instance.getProcessInstanceId();
    }

    @Override
    public String processAutomatedTransactionPairs() {
        evaluateProcessState(PROCESS_AUTOMATED_TRANSACTION_PAIRS, null, null);
        ProcessInstance instance = runtimeService.startProcessInstanceByKey(PROCESS_AUTOMATED_TRANSACTION_PAIRS);
        String infoString = "Started - PROCESS AUTOMATED TRANSACTION PAIRS flow with process instance ID: "
            + instance.getProcessInstanceId();
        LOG.debug(infoString);
        return instance.getProcessInstanceId();
    }

    /** {@inheritDoc} */
    @Override
    public IncomingPackageDownloadJob downloadIncomingPackage(IncomingPackageDownloadJob incomingPackageDownloadJob) {
        // verify model
        StringBuilder errorString = new StringBuilder();
        String transferItem = incomingPackageDownloadJob.getTransferItem();
        if (StringUtils.isBlank(transferItem)) {
            errorString.append(nl + "Missing [transferItem]");
        } else {
            if (!(transferItem.equals(IN_NOTIF_PKG) || transferItem.equals(IN_NOTIF_IMG_PKG)
                || transferItem.equals(IN_NOTIF_PDF_PKG) || transferItem.equals(IN_IRREG_PKG)
                || transferItem.equals(IN_MADRID_FEES) || transferItem.equals(IN_FINANCE_FEES))) {
                errorString.append(nl + "[transferItem] must be one of: '" + IN_NOTIF_PKG + "', '" + IN_NOTIF_IMG_PKG
                    + "', '" + IN_NOTIF_PDF_PKG + "', '" + IN_IRREG_PKG + "', '" + IN_MADRID_FEES + "', '"
                    + IN_FINANCE_FEES + "' ");
            }
        }
        String outputFolderPath = null;
        switch (transferItem) {
            case IN_NOTIF_PKG:
                outputFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.xml");
                break;
            case IN_NOTIF_IMG_PKG:
                outputFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.img");
                break;
            case IN_NOTIF_PDF_PKG:
                outputFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.pdf");
                break;
            case IN_IRREG_PKG:
                outputFolderPath = env.getProperty("mwe.incoming.staging.dir.irregularities.xml");
                break;
            case IN_MADRID_FEES:
                outputFolderPath = env.getProperty("mwe.incoming.staging.dir.financial.wipo.xml");
                break;
            case IN_FINANCE_FEES:
                outputFolderPath = env.getProperty("mwe.incoming.staging.dir.financial.cipo.xml");
            default:
                errorString.append(nl + "Unrecognized transfer item: " + transferItem);
        }
        incomingPackageDownloadJob.setOutputFolder(outputFolderPath);

        if (errorString.length() > 0) {
            throw new IllegalArgumentException(errorString.toString());
        }

        // other defaults
        IncomingPackageDownloadJob workingJob = new IncomingPackageDownloadJob();
        BeanUtils.copyProperties(incomingPackageDownloadJob, workingJob);

        if (StringUtils.isBlank(workingJob.getDownloadVerificationRetryPeriod())) {
            workingJob.setDownloadVerificationRetryPeriod(
                env.getProperty("mwe.madrid.package.download.default.poll.period", "PT10M"));
        }
        if (StringUtils.isBlank(workingJob.getMoveVerificationPollPeriod())) {
            workingJob.setMoveVerificationPollPeriod(
                env.getProperty("mwe.madrid.package.download.move.default.poll.period", "PT60S"));
        }

        if (StringUtils.isNotBlank(workingJob.getRemoteFileName())) {
            evaluateProcessState(DOWNLOAD_INCOMING_PACKAGE, REMOTE_FILE_NAME, workingJob.getRemoteFileName());
        } else {
            evaluateProcessState(DOWNLOAD_INCOMING_PACKAGE, TRANSFER_ITEM, transferItem);
        }

        // start process flow
        Map<String, Object> processVariables = MweWorkflowUtil.convertModelToProcessVariables(workingJob);

        LOG.info("STARTING - DOWNLOAD WIPO PACKAGE WITH THE FOLLOWING PARAMETERS: " + processVariables);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(DOWNLOAD_INCOMING_PACKAGE,
            processVariables);
        workingJob.setProcessInstanceId(instance.getProcessInstanceId());
        return workingJob;
    }

    /** {@inheritDoc} */
    @Override
    public IncomingPackagePersistJob persistIncomingPackage(IncomingPackagePersistJob incomingPackagePersistJob) {
        // validate model
        StringBuilder errorString = new StringBuilder();
        String transferItem = incomingPackagePersistJob.getTransferItem();
        if (StringUtils.isBlank(transferItem)) {
            errorString.append(nl + "Missing [transferItem]");
        } else {
            if (!(transferItem.equals(IN_NOTIF_PKG) || transferItem.equals(IN_NOTIF_IMG_PKG)
                || transferItem.equals(IN_NOTIF_PDF_PKG) || transferItem.equals(IN_IRREG_PKG)
                || transferItem.equals(IN_MADRID_FEES) || transferItem.equals(IN_FINANCE_FEES))) {
                errorString.append(nl + "[transferItem] must be one of: '" + IN_NOTIF_PKG + "', '" + IN_NOTIF_IMG_PKG
                    + "', '" + IN_NOTIF_PDF_PKG + "', '" + IN_IRREG_PKG + "', '" + IN_MADRID_FEES + "', '"
                    + IN_FINANCE_FEES + "' ");
            }
        }

        String inputFolderPath = null;
        String failFolderPath = null;
        switch (transferItem) {
            case IN_NOTIF_PKG:
                inputFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.xml");
                failFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.fail");
                break;
            case IN_NOTIF_IMG_PKG:
                inputFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.img");
                failFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.fail");
                break;
            case IN_NOTIF_PDF_PKG:
                inputFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.pdf");
                failFolderPath = env.getProperty("mwe.incoming.staging.dir.notification.fail");
                break;
            case IN_IRREG_PKG:
                inputFolderPath = env.getProperty("mwe.incoming.staging.dir.irregularities.xml");
                failFolderPath = env.getProperty("mwe.incoming.staging.dir.irregularities.fail");
                break;
            case IN_MADRID_FEES:
                inputFolderPath = env.getProperty("mwe.incoming.staging.dir.financial.wipo.xml");
                failFolderPath = env.getProperty("mwe.incoming.staging.dir.financial.wipo.fail");
                break;
            case IN_FINANCE_FEES:
                inputFolderPath = env.getProperty("mwe.incoming.staging.dir.financial.cipo.xml");
                failFolderPath = env.getProperty("mwe.incoming.staging.dir.financial.cipo.fail");
                break;
            default:
                errorString.append(nl + "Unrecognized transfer item: " + transferItem);
        }

        incomingPackagePersistJob.setInputFolder(inputFolderPath);
        incomingPackagePersistJob.setFailFolder(failFolderPath);

        if (errorString.length() > 0) {
            throw new IllegalArgumentException(errorString.toString());
        }

        // other defaults
        IncomingPackagePersistJob workingJob = new IncomingPackagePersistJob();
        BeanUtils.copyProperties(incomingPackagePersistJob, workingJob);

        if (workingJob.getNumberOfReattempts() == null) {
            workingJob.setNumberOfReattempts(
                Integer.parseInt(env.getProperty("mwe.madrid.package.persist.default.reattempt.count", "0")));
        }

        if (workingJob.getPersistVerificationPollPeriod() == null) {
            workingJob.setPersistVerificationPollPeriod(
                env.getProperty("mwe.madrid.package.persist.verification.poll.period", "PT30S"));
        }

        evaluateProcessState(PERSIST_INCOMING_PACKAGE, TRANSFER_ITEM, transferItem);

        // Start process flow
        Map<String, Object> processVariables = MweWorkflowUtil.convertModelToProcessVariables(workingJob);
        LOG.info("STARTING - PERSIST WIPO PACKAGE WITH THE FOLLOWING PARAMETERS: " + processVariables);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(PERSIST_INCOMING_PACKAGE, processVariables);
        workingJob.setProcessInstanceId(instance.getProcessInstanceId());
        return workingJob;
    }

    /** {@inheritDoc} */
    @Override
    public String processIncomingIdTransactions() {
        // TODO Auto-generated method stub
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public String processIncomingFinancialTransactions(BigDecimal packageId) {
        // TODO Auto-generated method stub
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public String processFinancialFeeUpdate(BigDecimal packageId) {
        // TODO Auto-generated method stub
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public String createOutgoingMessages() {
        ProcessInstance instance = runtimeService.startProcessInstanceByKey(CREATE_OUTGOING_TRANSACTIONS);

        return instance.getProcessInstanceId();
    }

    /** {@inheritDoc} */
    @Override
    public OutgoingMessageJob packageOutgoingMessages(OutgoingMessageJob outgoingMessageJob) {
        StringBuilder errorString = new StringBuilder();

        String outputFolderPath = env.getProperty("mwe.outgoing.staging.dir.office-to-ib.pkg");
        outgoingMessageJob.setOutputFolder(outputFolderPath);

        if (errorString.length() > 0) {
            throw new IllegalArgumentException(errorString.toString());
        }

        OutgoingMessageJob workingJob = new OutgoingMessageJob();
        BeanUtils.copyProperties(outgoingMessageJob, workingJob);

        if (workingJob.getNumberOfReattempts() == null) {
            workingJob.setNumberOfReattempts(
                Integer.parseInt(env.getProperty("mwe.madrid.package.assembly.default.reattempt.count", "0")));
        }

        if (workingJob.getTransferItem() == null) {
            workingJob.setTransferItem(OUT_DAILY_PKG);
        }

        if (workingJob.getCreationVerificationPollInterval() == null) {
            workingJob.setCreationVerificationPollInterval(
                env.getProperty("mwe.madrid.package.create.verification.poll.period", "PT30S"));
        }

        if (workingJob.getUploadVerificationPollInterval() == null) {
            workingJob.setUploadVerificationPollInterval(
                env.getProperty("mwe.madrid.package.upload.verification.poll.period", "PT30S"));
        }

        evaluateProcessState(PACKAGE_OUTGOING_TRANSACTIONS, null, null);

        // Start process flow
        Map<String, Object> processVariables = MweWorkflowUtil.convertModelToProcessVariables(workingJob);
        LOG.info("STARTING - PACKAGE OUTGOING MESSAGES WITH THE FOLLOWING PARAMETERS: " + processVariables);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(PACKAGE_OUTGOING_TRANSACTIONS,
            processVariables);
        workingJob.setProcessInstanceId(instance.getProcessInstanceId());
        return workingJob;
    }

    /** {@inheritDoc} */
    @Override
    public OutgoingMessageJob uploadOutgoingMessagePackage(OutgoingMessageJob outgoingMessageJob) {
        StringBuilder errorString = new StringBuilder();
        String transferItem = outgoingMessageJob.getTransferItem();

        if (StringUtils.isBlank(transferItem)) {
            errorString.append(nl + "Missing [transferItem]");
        } else {
            // There's only one option for now, but that may change in the
            // future.
            if (!(transferItem.equals(OUT_DAILY_PKG))) {
                errorString.append(nl + "[transferItem] must be: '" + OUT_DAILY_PKG + "' ");
            }
        }

        String outputFolderPath = null;
        String failFolderPath = null;
        if (transferItem.equals(OUT_DAILY_PKG)) {
            outputFolderPath = env.getProperty("mwe.outgoing.staging.dir.office-to-ib.pkg");
            failFolderPath = env.getProperty("mwe.outgoing.staging.dir.office-to-ib.fail");
        } else {
            errorString.append(nl + "No default staging folders in properties for transfer item " + transferItem);
        }

        outgoingMessageJob.setOutputFolder(outputFolderPath);
        outgoingMessageJob.setFailFolder(failFolderPath);

        if (errorString.length() > 0) {
            throw new IllegalArgumentException(errorString.toString());
        }

        OutgoingMessageJob workingJob = new OutgoingMessageJob();
        BeanUtils.copyProperties(outgoingMessageJob, workingJob);

        // Defaults
        if (workingJob.getUploadVerificationPollInterval() == null) {
            workingJob.setUploadVerificationPollInterval(
                env.getProperty("mwe.madrid.package.upload.default.poll.period", "PT5M"));
        }

        evaluateProcessState(UPLOAD_OUTGOING_PACKAGE, TRANSFER_ITEM, transferItem);

        // Start process flow
        Map<String, Object> processVariables = MweWorkflowUtil.convertModelToProcessVariables(workingJob);
        LOG.info("STARTING - UPLOAD OUTGOING PACKAGE WITH THE FOLLOWING PARAMETERS: " + processVariables);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(UPLOAD_OUTGOING_PACKAGE, processVariables);
        workingJob.setProcessInstanceId(instance.getProcessInstanceId());
        return workingJob;
    }

    @Override
    public OutgoingMessageJob createOutgoingManualTask(OutgoingTaskJob outgoingTaskJob) {
        OutgoingMessageJob workingJob = new OutgoingMessageJob();
        BeanUtils.copyProperties(outgoingTaskJob, workingJob);

        Map<String, Object> processVariables = MweWorkflowUtil.convertModelToProcessVariables(outgoingTaskJob);
        LOG.info("STARTING - UPLOAD OUTGOING PACKAGE WITH THE FOLLOWING PARAMETERS: " + processVariables);

        ProcessInstance instance = runtimeService.startProcessInstanceByKey(CREATE_OUTGOING_MANUAL_TASK,
            processVariables);

        workingJob.setProcessInstanceId(instance.getProcessInstanceId());
        return workingJob;
    }

    /** {@inheritDoc} */
    @Override
    public OutgoingMonthlyFinPkgJob uploadOutgoingMonthlyFinancePackageJob(OutgoingMonthlyFinPkgJob outgoingMonthlyFinPkgJob) {
        // TODO Auto-generated method stub
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public IncomingMonthlyFinPkgJob downloadIncomingMonthlyFinancePackageJob(IncomingMonthlyFinPkgJob incomingMonthlyFinPkgJob) {
        // TODO Auto-generated method stub
        return null;
    }

    /** {@inheritDoc} */
    @Override
    public SystemInfo getSystemInfo() {
        SystemInfo systemInfo = new SystemInfo();
        ResourceBundle bundle = null;

        try {
            bundle = ResourceBundle.getBundle("mwe-version");
        } catch (Exception ex) {
            LOG.warn("Can't load properties file.", ex);
            systemInfo.setVersion(SystemInfo.STATUS_INDETERMINATE);
            systemInfo.setBuildDateAndTime(SystemInfo.STATUS_INDETERMINATE);
        }

        if (bundle != null) {
            systemInfo.setVersion(bundle.getString("implementationVersion"));
            try {
                String implementationBuildTimestampString = bundle.getString("implementationBuildTimestamp") + "GMT";
                Date implementationBuildTimestampDate = POM_DATE_FORMAT.parse(implementationBuildTimestampString);
                systemInfo.setBuildDateAndTime(OUTPUT_DATE_FORMAT.format(implementationBuildTimestampDate));
            } catch (ParseException pe) {
                systemInfo.setBuildDateAndTime(bundle.getString("implementationBuildTimestamp"));
            }
        }

        dtfServiceManager.updateServiceStatus(systemInfo);
        mpsServiceManager.updateServiceStatus(systemInfo);
        mtsServiceManager.updateServiceStatus(systemInfo);
        // TODO: not ready mfsServiceManager.updateServiceStatus(systemInfo);
        // rgsServiceManager.updateServiceStatus(systemInfo);

        return systemInfo;
    }

    /** {@inheritDoc} */
    @Override
    public List<DownloadLogItem> getDownloadLogItems(String xferReqId, Integer topX, String packageType) {
        List<DownloadLogItem> returnedLogItems;
        DownloadLogItem searchReferenceItem = new DownloadLogItem();
        if (StringUtils.isNotBlank(xferReqId)) {
            searchReferenceItem.setXferReqId(xferReqId);
        }
        if (StringUtils.isNotBlank(packageType)) {
            searchReferenceItem.setPackageType(packageType);
        }

        if (StringUtils.isBlank(xferReqId) && StringUtils.isBlank(packageType)) {
            returnedLogItems = packageDownloadLogService.getAllDownloadLogItems();
        } else {
            returnedLogItems = packageDownloadLogService.getDownloadLogItems(searchReferenceItem);
        }
        Collections.sort(returnedLogItems);

        while (topX != null && topX.intValue() > 0 && returnedLogItems.size() > topX.intValue()) {
            returnedLogItems.remove(topX.intValue());
        }

        return returnedLogItems;
    }

    /*
     * Queries the engine to see if a process with this name is already running. For MWE, it's fairly straightforward -
     * the same process should not be running more than once.
     */
    protected void evaluateProcessState(String processDefinitionKey, String procVariableName,
                                        Object procVariableValue) {
        List<ProcessInstance> processInstanceList = runtimeService.createProcessInstanceQuery()
            .includeProcessVariables().processDefinitionKey(processDefinitionKey).list();

        if (processInstanceList != null && !processInstanceList.isEmpty()) {
            // For debugging purposes output all the Ids currently running
            String listOfprocessIds = "";
            for (ProcessInstance pi : processInstanceList) {
                listOfprocessIds += pi.getProcessInstanceId() + " \\ ";
            }

            if (procVariableName == null) {
                throw new IllegalStateException("MWE cannot run another instance of [" + processDefinitionKey
                    + "] because an instance is already running. Process Instance Ids [ " + listOfprocessIds + " ]");
            } else {
                for (ProcessInstance pi : processInstanceList) {
                    Object varValue = pi.getProcessVariables().get(procVariableName);
                    if (varValue.equals(procVariableValue)) {
                        throw new IllegalStateException("MWE cannot run another instance of [" + processDefinitionKey
                            + "] with variable [" + procVariableValue
                            + "] because an instance is already running. Process Instance Ids [ " + listOfprocessIds
                            + " ]");
                    }
                }
            }
        }
    }

    /** {@inheritDoc} */
    @Override
    public List<ProcessInstance> getOngoingProcessList(String processDefinitionKey) {
        return (runtimeService.createProcessInstanceQuery().includeProcessVariables()
            .processDefinitionKey(processDefinitionKey).list());
    }

    @Override
    public void deleteProcessInstance(ProcessInstance processInstance) {
        runtimeService.deleteProcessInstance(processInstance.getId(), "Requested by user");
    }

    /** {@inheritDoc} */
    @Override
    public List<BusinessErrorLogItem> getBusinessErrorLogItems(String componentAcronym, Integer topX) {
        List<BusinessErrorLogItem> returnedLogItems;
        BusinessErrorLogItem searchReferenceItem = new BusinessErrorLogItem();

        if (StringUtils.isNotBlank(componentAcronym)) {
            searchReferenceItem.setComponentAcronym(componentAcronym);
            returnedLogItems = businessErrorLogService.getBusinessErrorLogItemsByFields(searchReferenceItem);
        } else {
            returnedLogItems = businessErrorLogService.getAllBusinessErrorLogItems();
        }
        Collections.sort(returnedLogItems);

        while (topX != null && topX.intValue() > 0 && returnedLogItems.size() > topX.intValue()) {
            returnedLogItems.remove(topX.intValue());
        }

        return returnedLogItems;
    }

}
