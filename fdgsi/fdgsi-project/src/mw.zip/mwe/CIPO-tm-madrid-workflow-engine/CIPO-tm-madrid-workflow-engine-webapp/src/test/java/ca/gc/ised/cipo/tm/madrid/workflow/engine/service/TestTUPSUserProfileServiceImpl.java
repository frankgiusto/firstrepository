package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityCategory;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityGroup;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;
import ca.gc.ic.cipo.tm.userprofile.schema.AuthorityType;
import ca.gc.ic.cipo.tm.userprofile.schema.BaseUserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;

@Repository(value = "TUPSUserProfileService")
public class TestTUPSUserProfileServiceImpl implements TUPSUserProfileService {

	@Value("${mwe.tups.service.endpoint.hostname}")
	private String authHostUrl;

	// private UserProfileService tupsClient;

	private Map<String, UserProfile> users;

	/**
	 * Maintains a singleton of the TUPS Client per session. THis will prevent
	 * the TUPS client to get created when involking the service multiple times
	 *
	 * @return UserProfileService the service client
	 */
	// private UserProfileService getTupsClient() {
	//
	// if ( tupsClient == null ) {
	// tupsClient = UserProfileServiceFactory.createClient( authHostUrl );
	// }
	// return tupsClient;
	// }

	private Map<String, UserProfile> getUsers() {

		if (users == null) {
			users = new HashMap<String, UserProfile>();
			String[] userArray = { "DataCorM", "TMexamiM", "TMOBopeM", "TMOBsupM", "TMoperaM", "TMsuperM", "MADRID1",
					"MADRID2", "MADRID3", "MADRID4", "MADRID5", "MADRID6" };
			for (String userId : userArray) {
				UserProfile p = new UserProfile();
				p.setUsername(userId);
				p.setEmail(userId + "@ic.gc.ca");
				p.setName(userId + " Name");
				if (userId.equals("DataCorM")) {
					UserAuthority ua = new UserAuthority();
					ua.setSectionAuthority("DATA CORRECTION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.ADMINISTRATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_DIVISION_MANAGER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("DATA CORRECTION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.ADMINISTRATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_OFFICE_MANAGER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("DATA CORRECTION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.ADMINISTRATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_SECTION_MANAGER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("DATA CORRECTION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.ADMINISTRATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_UNIT_MANAGER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("DATA CORRECTION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_OPERATOR.value());
					p.getUserAuthorities().add(ua);
				}

				if (userId.equals("TMexamiM")) {
					UserAuthority ua = new UserAuthority();
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_EXAMINER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_OPERATOR.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_EXAMINER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_EXPERT_EXAMINER.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("TMOBopeM")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("OPPS45");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TMOB_OPERATOR.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("TMOBsupM")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("OPPS45");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.SUPERVISOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TMOB_SUPERVISOR.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("TMoperaM")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TMOB_OPERATOR.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("TMsuperM")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_EXPERT_EXAMINER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_EFILING.value());
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MEF_EXAMINER.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("EXAMINATION");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.SUPERVISOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_SUPERVISOR.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("MADRID1")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");

					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_OPERATOR.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("MADRID2")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");

					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_OPERATOR.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_EXAMINER.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("MADRID3")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");

					ua.setIntlAuthorityGroup(IntlAuthorityGroup.SUPERVISOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_SUPERVISOR.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_OPERATOR.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.EXAMINER.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_EXAMINER.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("MADRID4")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");

					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TMOB_OPERATOR.value());
					p.getUserAuthorities().add(ua);
				}
				if (userId.equals("MADRID5")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");

					ua.setIntlAuthorityGroup(IntlAuthorityGroup.SUPERVISOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TMOB_SUPERVISOR.value());
					p.getUserAuthorities().add(ua);

					ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");
					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TMOB_OPERATOR.value());
					p.getUserAuthorities().add(ua);

				}
				if (userId.equals("MADRID6")) {
					UserAuthority ua = new UserAuthority();
					ua.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.value());
					ua.setSectionAuthority("FORMALITIES");

					ua.setIntlAuthorityGroup(IntlAuthorityGroup.OPERATOR.value());
					ua.setIntlAuthorityRole(IntlAuthorityRole.MC_TM_OPERATOR.value());
					p.getUserAuthorities().add(ua);
				}
				users.put(userId, p);
			}
		}
		return users;
	}

	@Override
	public UserProfile getUserProfile(UserProfileType userProfileType) throws CIPOServiceFault {

		return getUsers().get(userProfileType.getUserName());
		// return getTupsClient().getUserProfile(userProfileType);
	}

	@Override
	public HeartbeatResponseType getHeartbeat() throws CIPOServiceFault {

		HeartbeatResponseType hb = new HeartbeatResponseType();
		try {
			hb.setIpAddress(InetAddress.getLocalHost().getHostAddress());
			hb.setStatus("online");
			hb.setNodeName(InetAddress.getLocalHost().getHostName());
		} catch (Exception e) {
		}
		return hb;
		// return getTupsClient().getHeartbeat();
	}

	private List<String> getIntlAuthorityCategories() {

		List<String> ret = new ArrayList<String>();
		for (IntlAuthorityCategory c : IntlAuthorityCategory.values()) {
			ret.add(c.value());
		}
		return ret;
	}

	private List<String> getIntlAuthorityGroups() {

		List<String> ret = new ArrayList<String>();
		for (IntlAuthorityGroup c : IntlAuthorityGroup.values()) {
			ret.add(c.value());
		}
		return ret;
	}

	private List<String> getIntlAuthorityRoles() {

		List<String> ret = new ArrayList<String>();
		for (IntlAuthorityRole c : IntlAuthorityRole.values()) {
			ret.add(c.value());
		}
		return ret;
	}

	private List<String> getSectionAuthorities() {

		List<String> ret = new ArrayList<String>();
		String[] testArray = { "FORMALITIES", "EXAMINATION", "OPPS45", "DATA CORRECTION", "JOURNAL", "DECLREGN", "AAR",
				"TMR" };
		for (String userId : testArray) {
			ret.add(userId);
		}
		return ret;
	}

	@Override
	public List<String> listAuthorityTypes(AuthorityType authorityType) throws CIPOServiceFault {

		if (authorityType.equals(AuthorityType.INTL_AUTHORITY_CATEGORY)) {
			return getIntlAuthorityCategories();
		}
		if (authorityType.equals(AuthorityType.INTL_AUTHORITY_GROUP)) {
			return getIntlAuthorityGroups();
		}
		if (authorityType.equals(AuthorityType.INTL_AUTHORITY_ROLE)) {
			return getIntlAuthorityRoles();
		}
		if (authorityType.equals(AuthorityType.SECTION_AUTHORITY)) {
			return getSectionAuthorities();
		}
		throw new CIPOServiceFault("Authority Type not found", new ServiceFaultDetails());
		// return getTupsClient().listAuthorityTypes(userAuthority);
	}

	@Override
	public List<BaseUserProfile> searchUserProfiles(UserAuthority userAuthority) throws CIPOServiceFault {

		// TODO Implement the SearchUserProfiles Mock Test
		return new ArrayList<BaseUserProfile>();
		// return getTupsClient().searchUserProfiles(userAuthority);
	}

}
