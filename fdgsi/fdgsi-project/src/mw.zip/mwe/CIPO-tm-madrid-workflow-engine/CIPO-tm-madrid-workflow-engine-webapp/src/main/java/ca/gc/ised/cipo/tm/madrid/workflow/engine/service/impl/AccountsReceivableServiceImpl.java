/*
 * Copyright (c) 2018 CIPO Created on Aug 15, 2018
 */
package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.AR_PACKAGE_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DTF_TRANSFER_REQUEST_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;

import java.io.Serializable;
import java.util.ArrayList;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.schema.mps.PackageDetail;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.AccountsReceivableService;

/**
 *
 *
 * @author D.Rodrigues
 * @version 1.0
 */
@Service
public class AccountsReceivableServiceImpl extends BusinessErrorHandlerImpl
    implements AccountsReceivableService, Serializable {

    /** Unique serial ID. */
    private static final long serialVersionUID = 2847389765681840960L;

    @Autowired
    protected MfsServiceManager mfsServiceManager;

    @Autowired
    protected MpsServiceManager mpsServiceManager;

    /**
     * Default constructor.
     */
    public AccountsReceivableServiceImpl() {
        // no op
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * ca.gc.ised.cipo.id.hague.workflow.engine.service.AccountsReceivableService#processAccountReceivableDistribution(
     * org.activiti.engine.delegate.DelegateExecution)
     */
    @Override
    public void processAccountReceivableDistribution(DelegateExecution execution) {
        try {
            // Call HFS to have it process any AR transactions into a package (this is an async call)
            mfsServiceManager.processAccountReceivableDistributionAsync(execution);

            // Success - reset the error variable stored on the flow
            execution.setVariable(ERR_MSG_OBJECT_VAR, null);

        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        } catch (Throwable t) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, createGenericMweBusinessErrorLogItem(t.getMessage()));
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * ca.gc.ised.cipo.id.hague.workflow.engine.service.AccountsReceivableService#fetchAccountsReceivablePackages(org.
     * activiti.engine.delegate.DelegateExecution)
     */
    @Override
    public void fetchAccountsReceivablePackages(DelegateExecution execution) {

        // TODO for now this method will not return any results. All handling of the AR package will be done manually
        // using the Hague Console
        execution.setVariable(AR_PACKAGE_LIST, new ArrayList<PackageDetail>());

        // try {
        // // Get the list of AR packages that are ready for dispatch. May be NULL
        // List<PackageDetail> transactionDetails = hpsServiceManager.getArPackageList();
        // execution.setVariable(AR_PACKAGE_LIST, transactionDetails);
        //
        // } catch (BpmnWebServiceCallException bpe) {
        // execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
        // }
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * ca.gc.ised.cipo.id.hague.workflow.engine.service.AccountsReceivableService#exportAccountsReceivablePackage(org.
     * activiti.engine.delegate.DelegateExecution)
     */
    @Override
    public void exportAccountsReceivablePackage(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development
    }

    @Override
    public void createArTransferRequestToIfms(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development. For now AR packages will be
        // manually picked up by authorized users via the Hague Console. Edits to the AR XML will be made manually if
        // required and then the file will be manually sent to IFMS
    }

    @Override
    public void verifyArTransferRequest(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development
        execution.setVariable(DTF_TRANSFER_REQUEST_STATUS, COMPLETE);
    }

    @Override
    public void cleanUpSharedFiles(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development
    }

    @Override
    public void moveSharedFilesToFailFolder(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development
    }

    @Override
    public void setPackageStatusSent(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development
    }

    @Override
    public void setPackageStatusFailed(DelegateExecution execution) {
        // TODO This method should be implemented in R2 of Accounts Receivable development
    }

}
