package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

/**
 * A transfer request creator strategy for creating a DTF transfer request for a Madrid notification package (images)
 *
 * @author J. Greene
 *
 */
public class NotificationImgTransferRequestCreator extends AbstractNotificationTransferRequestCreator {

    /** {@inheritDoc} */
    @Override
    protected String getDtfSite() {
        return getEnvironment().getProperty("mwe.dtf.madrid.site.name");
    }

    /** {@inheritDoc} */
    @Override
    public String getFileNameDiscriminator() {
        return getEnvironment().getProperty("mwe.notification.img.file.discriminator");
    }

    /** {@inheritDoc} */
    @Override
    public String getRemoteDir() {
        return getEnvironment().getProperty("mwe.dtf.madrid.ftp.notification.dir.images");
    }

    /** {@inheritDoc} */
    @Override
    public String getRegexForTransactionType() {
        return getEnvironment().getProperty("mwe.notification.img.regex");
    }

}
