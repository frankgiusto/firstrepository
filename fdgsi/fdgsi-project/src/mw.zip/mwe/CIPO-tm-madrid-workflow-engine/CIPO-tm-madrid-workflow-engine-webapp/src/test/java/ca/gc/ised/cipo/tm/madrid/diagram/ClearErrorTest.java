package ca.gc.ised.cipo.tm.madrid.diagram;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;

import org.activiti.engine.IdentityService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import util.TestMadridMethodVarsService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class ClearErrorTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private IdentityService identityService;

	@Autowired
	private TaskService taskService;

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Autowired
	@Rule
	public ActivitiRule activitiSpringRule;

	@SuppressWarnings({ "unused" })
	// @Test
	public void setTaskValues() throws Exception {

		// The offending Task
		String taskId = "cc146ab0-64dd-11e8-a7b2-d6f4ac4146cb";

		// Set variables
		String assignedUser = null;
		String assignedGroup = null;
		HashMap<String, String> processVars = new HashMap<String, String>();
		processVars.put("transId", "12806");

		Task task = null;

		task = this.taskService.createTaskQuery().taskId(taskId).singleResult();

		if (assignedUser != null) {
			this.taskService.unclaim(taskId);
			this.taskService.claim(taskId, assignedUser);
		}

		if (assignedGroup != null) {
			List<IdentityLink> identities = this.taskService.getIdentityLinksForTask(taskId);

			for (IdentityLink identityLink : identities) {
				this.taskService.deleteGroupIdentityLink(taskId, identityLink.getGroupId(), identityLink.getType());
			}

			this.taskService.addGroupIdentityLink(taskId, assignedGroup, IdentityLinkType.CANDIDATE);
		}

		for (String key : processVars.keySet()) {

			String procId = task.getProcessInstanceId();

			this.runtimeService.setVariables(procId, processVars);

		}

	}

	@Test
	// @Deployment(resources =
	// {"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn"})
	public void testClearMTSError() throws InterruptedException {

		LOG.debug("------------");
		LOG.debug("Test (testClearMTSError) started.");
		LOG.debug("------------");
		this.methodVarsService.reset();

		List<Execution> execs = runtimeService.createExecutionQuery()
				.signalEventSubscriptionName(ProcessFlowConstants.SIGNAL_MTS_RECOVERY).list();

		for (Execution execution : execs) {

			LOG.debug("Found stalled process (" + execution.getId() + ").");

			// Make sure the delegates don't create errors.
			this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.checkForExistingMarks",
					ProcessFlowConstants.MTS_ERROR, new Boolean(false));

			this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.createConsoleTask",
					ProcessFlowConstants.MTS_ERROR, new Boolean(false));

			this.methodVarsService.setMethodVar("TestMadridListenerServiceImpl.syncConsoleTask",
					ProcessFlowConstants.MTS_ERROR, new Boolean(false));

			this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.updateConsoleTaskStatus",
					ProcessFlowConstants.MTS_ERROR, new Boolean(false));

			// Signal that MTS is back up
			runtimeService.signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_RECOVERY, execution.getId());
			Thread.sleep(5000);

			// If there are any Tasks, complete them
			Task task = taskService.createTaskQuery().processInstanceId(execution.getProcessInstanceId())
					.singleResult();

			// Maybe it's in a sub-process
			if (task == null) {

				// Get the sub-process
				ProcessInstance proc = runtimeService.createProcessInstanceQuery()
						.superProcessInstanceId(execution.getProcessInstanceId()).singleResult();

				if (proc != null) {

					task = taskService.createTaskQuery().processInstanceId(proc.getId()).singleResult();

				}

			}

			if (task != null) {

				LOG.debug("Completing Task (" + task.getId() + ").");

				this.taskService.complete(task.getId());

			} else {

				LOG.debug("No Tasks");

			}

		}

	}

}
