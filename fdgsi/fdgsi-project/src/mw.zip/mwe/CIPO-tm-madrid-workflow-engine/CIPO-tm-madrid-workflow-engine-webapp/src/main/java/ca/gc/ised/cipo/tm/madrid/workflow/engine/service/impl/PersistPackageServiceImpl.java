package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR_WITH_RETRY;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_PKG_DOWNLOAD_FILE_FULL_PATH;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_IRREG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_MADRID_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.MFS_SPLIT_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NUMBER_OF_REATTEMPTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_FETCH_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_PERSISTENCE_VERIFY_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_UNIT_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_UNIT_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PERSISTED_PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PERSIST_PACKAGE_CALL_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mps.ImportPackage;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MfsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PersistPackageService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * A service that will handle delegated task actions from the {@code persist_package_data.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
@Service
public class PersistPackageServiceImpl extends BusinessErrorHandlerImpl implements PersistPackageService, Serializable {

    protected static final Logger LOG = LoggerFactory.getLogger(PersistPackageServiceImpl.class);

    private static final long serialVersionUID = -4778450512431701160L;

    @Autowired
    MpsServiceManager mpsServiceManager;

    @Autowired
    MfsServiceManager mfsServiceManager;

    @Autowired
    PackageDownloadLogService packageDownloadLogService;

    @Autowired
    Environment env;

    /**
     * {@inheritDoc}
     * <p>
     * Determines whether or not package(s) waiting in the staging area are to be persisted. Sets process variables with
     * the file name(s) and if there is anything to process. If a previous package file or unit failed and there is a
     * package of that type in the fail folder, prevent it from continuing until the issue is addressed and the package
     * is removed from the fail folder. For weekly bulletins only: Checks to see if the bulletin file and the image file
     * are present as they are both needed for processing. {@code packageFetchStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  1]} if packages found,<br/>
     * {@code [ -1]} if errors occur,<br/>
     * {@code [ 10]} if no packages were found
     */
    @Override
    public void getPackagesFromStaging(DelegateExecution execution) {
        String transferItem = execution.getVariable(TRANSFER_ITEM, String.class);
        String inputFolder = execution.getVariable(INPUT_FOLDER, String.class);
        String failFolder = execution.getVariable(FAIL_FOLDER, String.class);
        Integer pacakgeFetchStatus = COMPLETE;

        if (transferItem.equals(IN_NOTIF_PKG) || transferItem.equals(IN_NOTIF_IMG_PKG)
            || transferItem.equals(IN_NOTIF_PDF_PKG) || transferItem.equals(IN_IRREG_PKG)
            || transferItem.equals(IN_MADRID_FEES) || transferItem.equals(IN_FINANCE_FEES)) {

            if (failedPackagesExistForType(transferItem, failFolder)) {
                registerGenericMweBusinessError(execution, "Cannot import package of type " + transferItem
                    + " while packages of that type exist in the fail folder.");
                pacakgeFetchStatus = ERROR;
            } else {
                try {
                    List<PackageUnit> packageUnitList = null;
                    if (transferItem.equals(IN_FINANCE_FEES)) {
                        // We can create a package unit here since we know the
                        // exact name and location of the downloaded
                        // item(s)
                        String feedbackFileFullPath = execution.getVariable(FIN_PKG_DOWNLOAD_FILE_FULL_PATH,
                            String.class);
                        packageUnitList = getPackageUnitForCipoFeedbackFile(feedbackFileFullPath);
                    } else {
                        packageUnitList = getPackageGroupList(inputFolder, transferItem);
                    }
                    if (packageUnitList.isEmpty()) {
                        LOG.debug("Unable to get package group for items in " + inputFolder);
                        pacakgeFetchStatus = NOTHING_TO_DO;
                    } else {
                        execution.setVariable(PACKAGE_UNIT_LIST, packageUnitList);
                        pacakgeFetchStatus = COMPLETE;
                    }
                } catch (Exception ex) {
                    registerGenericMweBusinessError(execution, ex.getMessage());
                    pacakgeFetchStatus = ERROR;
                }
            }
        } else {
            registerGenericMweBusinessError(execution, "Invalid package type: " + transferItem);
            pacakgeFetchStatus = ERROR;
        }
        execution.setVariable(PACKAGE_FETCH_STATUS, pacakgeFetchStatus);
    }

    /*
     * Determine if there are failed packages in the fail folder for this type of package. If so, prevent the workflow
     * engine from importing further packages of that type. At this point, we know the fail folder is a legitimate
     * directory, but we can't make any assumptions as to what's in it.
     */
    protected boolean failedPackagesExistForType(String transferItem, String failFolder) {
        boolean failedPackagesExist = false;

        File failFolderFile = new File(failFolder);

        if (failFolderFile.exists() && failFolderFile.isDirectory()) {

            File[] failFolderFiles = failFolderFile.listFiles();

            if (failFolderFiles.length > 0) {
                for (File failFile : failFolderFiles) {
                    if (failFile.isFile()) {
                        String fileRegexForPackageType = getFileRegexForPackageType(transferItem);
                        if (failFile.getName().matches(fileRegexForPackageType)) {
                            failedPackagesExist = true;
                        }
                    }
                }
            }
        }

        return failedPackagesExist;
    }

    /*
     * Creates a PackageUnit List that just contains one XML package file.
     */
    protected List<PackageUnit> getPackageUnitForCipoFeedbackFile(String feedbackFileFullPath) {
        List<PackageUnit> packageUnitList = new ArrayList<>();
        PackageUnit feedbackPackageUnit = new PackageUnit();
        feedbackPackageUnit.setXmlFileName(feedbackFileFullPath);
        packageUnitList.add(feedbackPackageUnit);
        return packageUnitList;
    }

    /*
     * Gets a collection of package groups for processing. A package group may consist of an xml file/archive pointer, a
     * pdf file/archive pointer, and an image archive pointer OR some other combination of the aforementioned. It's
     * possible that there may be more than one set of units from past attempts so we won't assume only one pair per run
     * of the workflow.
     *
     */
    protected List<PackageUnit> getPackageGroupList(String inputFolder, String transferItem) throws Exception {
        List<PackageUnit> packageUnitList = new ArrayList<>();

        Path inputFolderPath = Paths.get(inputFolder);
        if (Files.exists(inputFolderPath) && Files.isDirectory(inputFolderPath)) {
            File inputFolderFile = new File(inputFolder);
            File[] inputFolderFiles = inputFolderFile.listFiles();

            // Iterate over the list of files in the input folder to find ones
            // matching the transfer item.
            if (inputFolderFiles == null || inputFolderFiles.length == 0) {
                LOG.debug("Unable to detect files at: " + inputFolder);
            } else {
                LOG.debug("Evaluating the following files for grouping: " + Arrays.toString(inputFolderFiles));
                String[] groupTransferTypes = null;

                LOG.debug(
                    "Attempting to get package groups for files in " + inputFolder + " and for type " + transferItem);

                String transferItemFileNameMatcher = getFileRegexForPackageType(transferItem);

                switch (transferItem) {
                    case IN_NOTIF_PKG:
                    case IN_NOTIF_IMG_PKG:
                    case IN_NOTIF_PDF_PKG:
                        groupTransferTypes = new String[]{IN_NOTIF_PKG, IN_NOTIF_IMG_PKG, IN_NOTIF_PDF_PKG};
                        break;
                    case IN_IRREG_PKG:
                    case IN_MADRID_FEES:
                        // Nothing here for now - possibly a grouping here but not
                        // sure.
                        break;
                    default:
                        throw new IllegalArgumentException("Value of arg [transferItem] is invalid: " + transferItem);
                }

                // get a collection (or not) of the file type
                List<File> matchingFileList = new ArrayList<>();
                if (inputFolderFiles.length > 0) {
                    for (File file : inputFolderFiles) {
                        if (file.isFile() && file.getName().matches(transferItemFileNameMatcher)) {
                            matchingFileList.add(file);
                            LOG.debug("File " + file.getName() + " matches " + transferItemFileNameMatcher);
                        } else {
                            LOG.debug("File " + file.getName() + " does not match with " + transferItemFileNameMatcher);
                        }
                    }

                    if (matchingFileList.size() > 0) {
                        for (File matchingFile : matchingFileList) {

                            if (groupTransferTypes == null) {
                                // no paired file, just the one xml
                                PackageUnit packageUnit = new PackageUnit();
                                packageUnit.setXmlFileName(matchingFile.getAbsolutePath());

                                // Add this package to the list to work with
                                packageUnitList.add(packageUnit);
                            } else {
                                // Find all members of a unit, add to the
                                // collection
                                try {
                                    // Create a package unit based on the file
                                    // from the matching list
                                    PackageUnit packageUnit = packageDownloadLogService
                                        .createPackageUnitWithRelatedDownloadItems(matchingFile.getName(),
                                            groupTransferTypes);

                                    // Determine if the package unit is complete
                                    // according to the type.
                                    boolean isPackageComplete = true;
                                    switch (transferItem) {
                                        case IN_NOTIF_PKG:
                                        case IN_NOTIF_IMG_PKG:
                                        case IN_NOTIF_PDF_PKG:
                                            isPackageComplete = (StringUtils.isNotBlank(packageUnit.getXmlFileName()))
                                                && (StringUtils.isNotBlank(packageUnit.getPdfFileName()))
                                                && (StringUtils.isNotBlank(packageUnit.getImgFileName()));
                                            break;
                                        case IN_IRREG_PKG:
                                        case IN_MADRID_FEES:
                                            // Nothing here for now - possibly a
                                            // grouping here but not sure.
                                            break;
                                        default:
                                            break;
                                    }

                                    // Add this package to the list to work with
                                    if (isPackageComplete) {
                                        packageUnitList.add(packageUnit);
                                    }
                                } catch (NoDownloadHistoryException ndhe) {
                                    LOG.debug("Could not find a complete group for package processing for file "
                                        + matchingFile.getName());
                                }
                            }
                        }
                    }
                }
            }
            // Sort the list so old ones are processed first
            Collections.sort(packageUnitList);
        } else {
            throw new Exception("Input folder location [" + inputFolder + "] does not exist.");
        }

        return packageUnitList;
    }

    /**
     * {@inheritDoc}
     * <p>
     * Calls a web service that will initiate an operation to persist the package data in the INTL DB.
     * {@code persistPackageCallStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [ 1]} if call to persist package was returned successfully,<br/>
     * {@code [ -1]} if there was an error returned from the service
     * </p>
     */
    @Override
    public void persistPackageData(DelegateExecution execution) {
        PackageUnit packageUnit = execution.getVariableLocal(PACKAGE_UNIT_ITEM, PackageUnit.class);
        Integer persistPackageCallStatus = COMPLETE;
        String transferItem = execution.getVariable(TRANSFER_ITEM, String.class);
        ImportPackage importPackage = MweWorkflowUtil.transformPackageUnitToImportPackage(packageUnit, transferItem);

        try {
            BigDecimal packageId = mpsServiceManager.processPackage(importPackage, packageUnit);

            if (packageId == null) {
                registerGenericMweBusinessError(execution, "Variable packageId was returend as null");
                persistPackageCallStatus = ERROR;
            } else {
                execution.setVariableLocal(PERSISTED_PACKAGE_ID, packageId);
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            persistPackageCallStatus = ERROR;
        }
        execution.setVariableLocal(PERSIST_PACKAGE_CALL_STATUS, persistPackageCallStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Calls a web service that will split the financial package into financial transactions, among other tasks. The
     * variable {@code hfsSplitStatus} will be set accordingly:
     * </p>
     * <p>
     * {@code [ 1]} if the financial transactions were split successfully, or, <br/>
     * {@code [ -1]} if there was an error returned from the service
     * </p>
     */
    @Override
    public void splitFinancialTransactions(DelegateExecution execution) {
        Integer mfsSplitStatus = COMPLETE;
        String transferItem = execution.getVariable(TRANSFER_ITEM, String.class);

        BigDecimal packageId = execution.getVariableLocal(PERSISTED_PACKAGE_ID, BigDecimal.class);
        try {
            mfsServiceManager.parsePackageToTransactions(packageId, transferItem);
            execution.setVariable(PACKAGE_ID, packageId); // For the call
            // activity version of this process flow
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            mfsSplitStatus = ERROR;
        }
        execution.setVariableLocal(MFS_SPLIT_STATUS, mfsSplitStatus);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Calls a web service that return the status of the previous persist operation. The process variable
     * {@code packagePersistenceStatus} will be set according to the following:<br/>
     * {@code [  1]} package was persisted successfully,<br/>
     * {@code [ -1]} error persisting package (no retry),<br/>
     * {@code [-10]} error persisting package - with retry,<br/>
     * {@code [  0]} the persistence operation is ongoing.
     *
     * @see PersistPackageService#persistPackageData(DelegateExecution)
     */
    @Override
    public void verifyPackagePersisted(DelegateExecution execution) {
        BigDecimal persistedPackageId = execution.getVariableLocal(PERSISTED_PACKAGE_ID, BigDecimal.class);
        PackageUnit packageUnit = execution.getVariableLocal(PACKAGE_UNIT_ITEM, PackageUnit.class);
        Integer packagePersistenceVerifyStatus = COMPLETE;
        String infoString = "Variable packageStatus returned with value [%s]";

        try {
            PackageStatusEnum packageStatus = mpsServiceManager.getPackageProcessingStatus(persistedPackageId,
                packageUnit);

            if (packageStatus == null) {
                execution.setVariableLocal(PERSIST_PACKAGE_CALL_STATUS, ERROR);
            } else {

                switch (packageStatus) {
                    case IB_TO_OFFICE_UNPROCESSED:
                    case MPS_IMPORT_SPLIT_TRANSACTIONS:
                        packagePersistenceVerifyStatus = INCOMPLETE;
                        break;
                    case MPS_IMPORT_COMPLETE:
                        cleanUpPackageData(packageUnit);
                        break;
                    case MPS_IMPORT_VALIDATION_ERROR:
                    case MPS_IMPORT_ERROR:
                        Integer loopCounter = execution.getVariableLocal("loopCounter", Integer.class);
                        String loopReattemptCounter = "numberOfReattemptsLocal" + loopCounter;
                        Integer numReattemptsLocal = execution.getVariableLocal(loopReattemptCounter, Integer.class);
                        if (numReattemptsLocal == null) {
                            Integer numReattempts = execution.getVariable(NUMBER_OF_REATTEMPTS, Integer.class);
                            execution.setVariableLocal(loopReattemptCounter, numReattempts);
                            numReattemptsLocal = numReattempts;
                        }

                        if (numReattemptsLocal > 0) {
                            packagePersistenceVerifyStatus = ERROR_WITH_RETRY;
                            execution.setVariableLocal(loopReattemptCounter, --numReattemptsLocal);
                        } else {
                            registerGenericMweBusinessError(execution,
                                String.format(infoString, packageStatus.value()));
                            packagePersistenceVerifyStatus = ERROR;
                        }
                        break;
                    default:
                        registerGenericMweBusinessError(execution,
                            "Variable packageStatus returned with unrecognized value [" + packageStatus.value() + "]");
                        packagePersistenceVerifyStatus = ERROR;
                }
                LOG.debug(String.format(infoString, packageStatus.value()));
            }
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            packagePersistenceVerifyStatus = ERROR;
        }
        execution.setVariableLocal(PACKAGE_PERSISTENCE_VERIFY_STATUS, packagePersistenceVerifyStatus);
    }

    /** {@inheritDoc} */
    @Override
    public void movePackageToFail(DelegateExecution execution) {
        PackageUnit badPackageUnit = execution.getVariableLocal(PACKAGE_UNIT_ITEM, PackageUnit.class);
        String failFolder = execution.getVariable(FAIL_FOLDER, String.class);
        File failureFolderFile = new File(failFolder);

        try {
            FileUtils.moveFileToDirectory(new File(badPackageUnit.getXmlFileName()), failureFolderFile, true);
            if (badPackageUnit.getImgFileName() != null) {
                FileUtils.moveFileToDirectory(new File(badPackageUnit.getImgFileName()), failureFolderFile, true);
            }
            if (badPackageUnit.getPdfFileName() != null) {
                FileUtils.moveFileToDirectory(new File(badPackageUnit.getPdfFileName()), failureFolderFile, true);
            }
        } catch (IOException ioe) {
            LOG.warn("IO Exception while trying to move package [" + badPackageUnit.toString() + "] to " + failFolder);
        }

    }

    protected void cleanUpPackageData(PackageUnit packageUnit) {
        try {
            Path xmlPath = Paths.get(packageUnit.getXmlFileName());
            if (Files.deleteIfExists(xmlPath)) {
                LOG.debug("Cleaned up and removed file " + packageUnit.getXmlFileName());
            }
            if (packageUnit.getImgFileName() != null) {
                Path imgPath = Paths.get(packageUnit.getImgFileName());
                if (Files.deleteIfExists(imgPath)) {
                    LOG.debug("Cleaned up and removed file " + packageUnit.getImgFileName());
                }
            }
            if (packageUnit.getPdfFileName() != null) {
                Path pdfPath = Paths.get(packageUnit.getPdfFileName());
                if (Files.deleteIfExists(pdfPath)) {
                    LOG.debug("Cleaned up and removed file " + packageUnit.getPdfFileName());
                }
            }
        } catch (Exception ex) {
            LOG.warn("Persist package file clean-up was unable to successfully remove files.");
        }
    }

    /**
     * Convenience method to get a regular expression matcher for a transfer type
     *
     * @param transferItem the transfer type of the package
     * @return the regex matcher
     */
    protected String getFileRegexForPackageType(String transferItem) {
        String regexString = null;
        switch (transferItem) {
            case IN_NOTIF_PKG:
                regexString = env.getProperty("mwe.notification.xml.regex");
                break;
            case IN_NOTIF_IMG_PKG:
                regexString = env.getProperty("mwe.notification.img.regex");
                break;
            case IN_NOTIF_PDF_PKG:
                regexString = env.getProperty("mwe.notification.pdf.regex");
                break;
            case IN_IRREG_PKG:
                regexString = env.getProperty("mwe.irregularities.xml.regex");
                break;
            case IN_MADRID_FEES:
                regexString = env.getProperty("mwe.wipo.fees.regex");
                break;
            case IN_FINANCE_FEES:
                regexString = env.getProperty("mwe.cipo.finance.monthly.inbound.regex");
                break;
            default:
                LOG.error("No regex expression for type [" + transferItem + "]!");
        }
        return regexString;
    }
}
