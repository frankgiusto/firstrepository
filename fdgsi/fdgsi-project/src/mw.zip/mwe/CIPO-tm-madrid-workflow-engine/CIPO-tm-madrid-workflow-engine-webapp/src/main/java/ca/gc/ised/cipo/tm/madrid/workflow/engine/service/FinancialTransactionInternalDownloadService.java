package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code download_financial_system_status_package.bpmn} process flow, which is a call activity in
 * {@code process_hague_financial_transactions_from_wipo.bpmn}
 *
 * @author J. Greene
 *
 */
public interface FinancialTransactionInternalDownloadService extends BusinessErrorHandler {

    /**
     * Service task method responsible for retrieving the financial system reply file from DTF.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void createFinSysFeedbackTransferRequest(DelegateExecution execution);

    /**
     * Service task method responsible for verifying the download status of the financial system reply file via DTF.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void verifyFinSysFeedbackDownload(DelegateExecution execution);

    /**
     * Service task method responsible for moving the financial system reply file from DTF staging to our local staging
     * area.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void movePackageToStaging(DelegateExecution execution);

    /**
     * Service task method responsible for calling the operation to update the transfer request in DTF to "Processed".
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void sendTransferConfirmation(DelegateExecution execution);
}
