package ca.gc.ised.cipo.tm.madrid.workflow.model;

/**
 * Parent class to all job beans.
 *
 * @author J. Greene
 *
 */
public class MweJob {

    protected String processInstanceId;

    /**
     * @return the processInstanceId
     */
    public String getProcessInstanceId() {
        return processInstanceId;
    }

    /**
     * @param processInstanceId the processInstanceId to set
     */
    public void setProcessInstanceId(String executionId) {
        this.processInstanceId = executionId;
    }

}
