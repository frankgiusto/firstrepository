package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * A bean to represent input parameters for the download financial update package sub-process call activity in the
 * finance flow.
 *
 * @author J. Greene
 *
 */
public class IncomingMonthlyFinPkgJob extends MweJob implements Serializable {

    private static final long serialVersionUID = -1632662260714291929L;

    private String finPkgDownloadVerificationPollPeriod;

    private String finPkgFileNotFoundRetryPeriod;

    private String finPkgPersistInputFolder;

    private String finPkgDownloadTransferItem;

    private String finPkgDownloadRemoteFileNameRegex;

    /**
     * @return the finPkgDownloadVerificationPollPeriod
     */
    public String getFinPkgDownloadVerificationPollPeriod() {
        return finPkgDownloadVerificationPollPeriod;
    }

    /**
     * @param finPkgDownloadVerificationPollPeriod the finPkgDownloadVerificationPollPeriod to set
     */
    public void setFinPkgDownloadVerificationPollPeriod(String finPkgDownloadVerificationPollPeriod) {
        this.finPkgDownloadVerificationPollPeriod = finPkgDownloadVerificationPollPeriod;
    }

    /**
     * @return the finPkgFileNotFoundRetryPeriod
     */
    public String getFinPkgFileNotFoundRetryPeriod() {
        return finPkgFileNotFoundRetryPeriod;
    }

    /**
     * @param finPkgFileNotFoundRetryPeriod the finPkgFileNotFoundRetryPeriod to set
     */
    public void setFinPkgFileNotFoundRetryPeriod(String finPkgFileNotFoundRetryPeriod) {
        this.finPkgFileNotFoundRetryPeriod = finPkgFileNotFoundRetryPeriod;
    }

    /**
     * @return the finPkgPersistInputFolder
     */
    public String getFinPkgPersistInputFolder() {
        return finPkgPersistInputFolder;
    }

    /**
     * @param finPkgPersistInputFolder the finPkgPersistInputFolder to set
     */
    public void setFinPkgPersistInputFolder(String finPkgPersistInputFolder) {
        this.finPkgPersistInputFolder = finPkgPersistInputFolder;
    }

    /**
     * @return the finPkgDownloadTransferItem
     */
    public String getFinPkgDownloadTransferItem() {
        return finPkgDownloadTransferItem;
    }

    /**
     * @param finPkgDownloadTransferItem the finPkgDownloadTransferItem to set
     */
    public void setFinPkgDownloadTransferItem(String finPkgDownloadTransferItem) {
        this.finPkgDownloadTransferItem = finPkgDownloadTransferItem;
    }

    /**
     * @return the finPkgDownloadRemoteFileNameRegex
     */
    public String getFinPkgDownloadRemoteFileNameRegex() {
        return finPkgDownloadRemoteFileNameRegex;
    }

    /**
     * @param finPkgDownloadRemoteFileNameRegex the finPkgDownloadRemoteFileNameRegex to set
     */
    public void setFinPkgDownloadRemoteFileNameRegex(String finPkgDownloadRemoteFileNameRegex) {
        this.finPkgDownloadRemoteFileNameRegex = finPkgDownloadRemoteFileNameRegex;
    }

    @Override
    public String toString() {
     // @formatter:off
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("finPkgDownloadVerificationPollPeriod", finPkgDownloadVerificationPollPeriod)
            .append("finPkgFileNotFoundRetryPeriod", finPkgFileNotFoundRetryPeriod)
            .append("finPkgPersistInputFolder", finPkgPersistInputFolder)
            .append("finPkgDownloadTransferItem", finPkgDownloadTransferItem)
            .append("finPkgDownloadRemoteFileNameRegex", finPkgDownloadRemoteFileNameRegex)
            .append("processInstanceId", processInstanceId)
            .toString();
     // @formatter:on
    }
}
