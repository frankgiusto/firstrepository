package ca.gc.ised.cipo.tm.madrid.workflow.engine.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * A DAO class for managing Activiti's history data as Activiti does not provide an API for this. There are open change
 * requests for Activiti to add this functionality, but they (much like a lot of other desired functionality in
 * Activiti) have not been acted upon. There is a general consensus among the forums that this is an acceptable
 * work-around.
 *
 * @author J. Greene
 *
 */
@Repository
public class ActivitiHistoryPurgeDao {

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected HistoryService historyService;

    protected NamedParameterJdbcTemplate jdbcTemplate;

    protected static final Logger LOG = LoggerFactory.getLogger(ActivitiHistoryPurgeDao.class);

    private static final String STD_WHERE = " WHERE PROC_INST_ID_ in (:procInstIds)";

    private static final String SQL_DEL_HI_ACTINST = "DELETE FROM ACT_HI_ACTINST";

    private static final String SQL_DEL_HI_ATTACHMENT = "DELETE FROM ACT_HI_ATTACHMENT";

    private static final String SQL_DEL_HI_COMMENT = "DELETE FROM ACT_HI_COMMENT";

    private static final String SQL_DEL_HI_DETAIL = "DELETE FROM ACT_HI_DETAIL";

    private static final String SQL_DEL_HI_IDENTITYLINK = "DELETE FROM ACT_HI_IDENTITYLINK";

    private static final String SQL_DEL_HI_PROCINST = "DELETE FROM ACT_HI_PROCINST";

    private static final String SQL_DEL_HI_TASKINST = "DELETE FROM ACT_HI_TASKINST";

    private static final String SQL_DEL_HI_VARINST = "DELETE FROM ACT_HI_VARINST";

    @Transactional
    public void purgeOldHistoryEntries(int olderThanNumberOfDays) {

        Date cutoffDate = DateUtils.addDays(new Date(), -(olderThanNumberOfDays));

        // Don't purge anything that is still active (an outside possibility, no matter how remote).
        List<HistoricProcessInstance> historicList = historyService.createHistoricProcessInstanceQuery()
            .finishedBefore(cutoffDate).list();
        List<String> procInstIds = new ArrayList<>();

        for (HistoricProcessInstance inst : historicList) {
            procInstIds.add(inst.getId());
        }

        int i = 0;
        if (!procInstIds.isEmpty()) {
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue("procInstIds", procInstIds);

            i += jdbcTemplate.update(SQL_DEL_HI_ACTINST + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_ATTACHMENT + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_COMMENT + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_DETAIL + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_IDENTITYLINK + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_PROCINST + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_TASKINST + STD_WHERE, params);
            i += jdbcTemplate.update(SQL_DEL_HI_VARINST + STD_WHERE, params);
        }
        LOG.debug(
            "Removed " + i + " old Activiti history items from more than " + olderThanNumberOfDays + " days ago.");
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

}
