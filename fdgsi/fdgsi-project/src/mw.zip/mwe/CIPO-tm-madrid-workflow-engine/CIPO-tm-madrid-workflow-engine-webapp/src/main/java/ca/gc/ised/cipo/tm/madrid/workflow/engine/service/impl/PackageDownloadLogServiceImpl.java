package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUT_DAILY_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUT_FINANCE_FEES;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.dao.PackageDownloadLogDao;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem.Status;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * A service class to front the DAO class for MWE's package download log.
 *
 * @author J. Greene
 *
 */
@Service
public class PackageDownloadLogServiceImpl implements PackageDownloadLogService {

    protected static final Logger LOG = LoggerFactory.getLogger(PackageDownloadLogServiceImpl.class);

    protected PackageDownloadLogDao dao;

    protected Environment env;

    @Autowired
    PackageDownloadLogServiceImpl(PackageDownloadLogDao dao, Environment env) {
        this.dao = dao;
        this.env = env;
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void insertLogEntry(DownloadLogItem downloadLogItem) {
        checkColumnSize(downloadLogItem);
        dao.insertLogEntry(downloadLogItem);
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void updateLogEntry(DownloadLogItem downloadLogItem) {
        checkColumnSize(downloadLogItem);
        dao.updateLogEntry(downloadLogItem);
    }

    // Watch for column length restrictions.
    protected void checkColumnSize(DownloadLogItem downloadLogItem) {
        String message = downloadLogItem.getMsg();
        if (StringUtils.isNotBlank(message) && message.length() > 2000) {
            downloadLogItem.setMsg(message.substring(0, 1975) + "\n(more...)");
        }
    }

    /** {@inheritDoc} */
    @Override
    public boolean wasFileDownloadedSuccessfully(String fileName) {
        boolean fileDownloadedSuccessfully = true;
        DownloadLogItem queryItem = new DownloadLogItem();
        if (fileName != null) {
            queryItem.setFileName(fileName);

        }
        queryItem.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());

        List<DownloadLogItem> logItems = dao.getDownloadLogItemsByFields(queryItem);
        if (logItems == null || logItems.isEmpty()) {
            fileDownloadedSuccessfully = false;
        }
        return fileDownloadedSuccessfully;
    }

    /** {@inheritDoc} */
    @Override
    @Transactional
    public void purgeOldLogEntries(int olderThanNumberOfDays) {
        dao.purgeOldLogEntries(olderThanNumberOfDays);
    }

    /** {@inheritDoc} */
    @Override
    public DownloadLogItem getDownloadLogItemById(Long id) {
        List<DownloadLogItem> logItems = null;
        DownloadLogItem logItem = null;
        DownloadLogItem queryItem = new DownloadLogItem();
        queryItem.setDlLogId(id);

        logItems = dao.getDownloadLogItemsByFields(queryItem);

        if (logItems != null && !logItems.isEmpty()) {
            logItem = logItems.get(0);
        }
        return logItem;
    }

    /** {@inheritDoc} */
    @Override
    public DownloadLogItem getPreviouslyDownloadedByType(String type) {

        if (type == IN_FINANCE_FEES || type == OUT_FINANCE_FEES || type == OUT_DAILY_PKG) {
            throw new IllegalArgumentException("type [" + type + "] is not an accepted value");
        }

        DownloadLogItem previouslyDownloadedItem = null;

        DownloadLogItem queryItem = new DownloadLogItem();
        queryItem.setDlStatus(DownloadLogItem.Status.SUCCESS.getValue());
        queryItem.setPackageType(type);

        List<DownloadLogItem> logItems = dao.getDownloadLogItemsByFields(queryItem);
        if (logItems != null && !logItems.isEmpty()) {
            for (DownloadLogItem item : logItems) {
                if (previouslyDownloadedItem == null) {
                    previouslyDownloadedItem = item;
                } else {
                    // The file names for the download packages contain a simplified date string that will tell us which
                    // WIPO package is the most recent based on a string compare.
                    if (previouslyDownloadedItem.getFileName().compareTo(item.getFileName()) < 0) {
                        previouslyDownloadedItem = item;
                    }
                }
            }
        }

        return previouslyDownloadedItem;
    }

    protected DownloadLogItem getDownloadedItemByNameAndType(String fileName, String packageType) {
        DownloadLogItem logItem = null;
        DownloadLogItem queryItem = new DownloadLogItem();
        queryItem.setFileName(fileName);
        queryItem.setPackageType(packageType);
        queryItem.setDlStatus(Status.SUCCESS.getValue());

        List<DownloadLogItem> logItems = dao.getDownloadLogItemsByFields(queryItem);
        if (logItems != null && !logItems.isEmpty()) {
            logItem = logItems.get(0);
        }
        return logItem;
    }

    /** {@inheritDoc} */
    @Override
    public List<DownloadLogItem> getDownloadLogItems(DownloadLogItem searchReferenceItem) {
        return dao.getDownloadLogItemsByFields(searchReferenceItem);
    }

    /** {@inheritDoc} */
    @Override
    public List<DownloadLogItem> getAllDownloadLogItems() {
        return dao.getAllDownloadLogItems();
    }

    /** {@inheritDoc} */
    @Override
    public PackageUnit createPackageUnitWithRelatedDownloadItems(String fileName, String[] groupTransferTypes)
        throws NoDownloadHistoryException {
        PackageUnit packageUnit = new PackageUnit();
        String discriminator;
        String associatedName;
        String msgString = "Cannot find download history for or existence of file [%s]";
        DownloadLogItem item;

        for (String transferType : groupTransferTypes) {
            discriminator = getDiscriminatorAssociatedWithType(transferType);
            associatedName = discriminator + fileName.substring(discriminator.length());
            item = getDownloadedItemByNameAndType(associatedName, transferType);
            if (item == null) {
                throw new NoDownloadHistoryException(String.format(msgString, associatedName));
            } else {
                Path historyItemFilePath = Paths.get(item.getTargetLocation(), item.getFileName());
                if (Files.exists(historyItemFilePath)) {
                    if (transferType.equals(IN_NOTIF_PKG)) {
                        packageUnit.setXmlFileName(historyItemFilePath.toString());
                    } else if (transferType.equals(IN_NOTIF_IMG_PKG)) {
                        packageUnit.setImgFileName(historyItemFilePath.toString());
                    } else if (transferType.equals(IN_NOTIF_PDF_PKG)) {
                        packageUnit.setPdfFileName(historyItemFilePath.toString());
                    }
                } else {
                    throw new NoDownloadHistoryException(String.format(msgString, historyItemFilePath.toString()));
                }
            }
        }

        return packageUnit;
    }

    private String getDiscriminatorAssociatedWithType(String transferType) {
        if (transferType.equals(IN_NOTIF_PKG)) {
            return env.getProperty("mwe.notification.xml.file.discriminator");
        } else if (transferType.equals(IN_NOTIF_IMG_PKG)) {
            return env.getProperty("mwe.notification.img.file.discriminator");
        } else if (transferType.equals(IN_NOTIF_PDF_PKG)) {
            return env.getProperty("mwe.notification.pdf.file.discriminator");
        } else {
            return null;
        }
    }
}
