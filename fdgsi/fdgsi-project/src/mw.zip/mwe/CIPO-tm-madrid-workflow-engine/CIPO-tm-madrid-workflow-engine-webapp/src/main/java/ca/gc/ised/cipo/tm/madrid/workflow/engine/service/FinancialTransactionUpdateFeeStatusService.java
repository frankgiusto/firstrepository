package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code update_financial_fee_status.bpmn} process flow, which is a call activity in
 * {@code process_hague_financial_transactions_from_wipo.bpmn}
 *
 * @author J. Greene
 *
 */
public interface FinancialTransactionUpdateFeeStatusService extends BusinessErrorHandler {

    /**
     * Service task method responsible for getting a list of updated financial transactions to be re-reconciled through
     * HFS.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getUpdatedFinancialTransactions(DelegateExecution execution);

    /**
     * Service task method responsible for submitting an updated financial transaction to be re-reconciled through HFS.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void updateReconciledFeeTransaction(DelegateExecution execution);

    /**
     * Service task method responsible for evaluating and collecting iterative errors that may occur in the looping
     * subprocess.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void handleIterativeError(DelegateExecution execution);

    /**
     * Service task method to call the operation to set the package status after fee update is completed without errors.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void updatePkgStatusPostFeeUpdate(DelegateExecution execution);

}
