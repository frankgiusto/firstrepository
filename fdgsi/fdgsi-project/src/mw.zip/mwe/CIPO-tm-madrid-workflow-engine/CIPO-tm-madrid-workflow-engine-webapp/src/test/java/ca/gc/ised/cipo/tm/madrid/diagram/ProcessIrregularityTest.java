package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import util.TestMadridMethodVarsService;
import util.TestUtils;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class ProcessIrregularityTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private TaskService taskService;

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Autowired
	@Rule
	public ActivitiRule activitiSpringRule;

	private ProcessInstance startProcessInstance(Map<String, Object> processVars) {

		return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("processIrregularity", processVars);
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn" })
	public void testDiagram() throws InterruptedException {

		LOG.debug("Test (processIrregularity) started.");
		this.methodVarsService.reset();

		Map<String, Object> processVars = new HashMap<String, Object>();
		// processVars.put("notifyAdminDelay", "PT2H");

		ProcessInstance processInstance = startProcessInstance(processVars);

		String id = processInstance.getId();
		LOG.debug("Waiting for first UserTask completion... ");
		Thread.sleep(3000);

		// The task is created within the CreateConsoleTask sub-process... get
		// it's ID
		ProcessInstance subProcessInstance = runtimeService.createProcessInstanceQuery()
				.superProcessInstanceId(processInstance.getId()).singleResult();

		assertNotNull(subProcessInstance);

		// Fetch the created Task
		Task task = processEngine.getTaskService().createTaskQuery().processInstanceId(subProcessInstance.getId())
				.singleResult();

		assertNotNull(task);

		// Fetch the assigned group
		String groupId = null;

		List<IdentityLink> taskIdenLinks = taskService.getIdentityLinksForTask(task.getId());
		if (taskIdenLinks != null && !taskIdenLinks.isEmpty()) {
			groupId = taskIdenLinks.get(0).getGroupId();
		}

		assertEquals("MC_TM_SUPERVISOR", groupId);

		LOG.debug("Completing User Task... ");
		this.taskService.complete(task.getId());

		ProcessInstance foundProcess = this.runtimeService.createProcessInstanceQuery().processInstanceId(id)
				.singleResult();

		assertNull(foundProcess);

		LOG.debug("Test complete.");
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn" })
	public void testNotifyAdmin() throws InterruptedException {

		LOG.debug("Test (processIrregularity) started.");
		this.methodVarsService.reset();

		Map<String, Object> processVars = new HashMap<String, Object>();

		// This will shorten the timer from 60 days to 3 seconds.
		processVars.put("notifyAdminDelay", "PT3S");

		ProcessInstance processInstance = startProcessInstance(processVars);

		String id = processInstance.getId();
		LOG.debug("Waiting for first UserTask completion... ");
		Thread.sleep(15000);

		// The task is created within the CreateConsoleTask sub-process... get
		// it's ID
		ProcessInstance subProcessInstance = runtimeService.createProcessInstanceQuery()
				.superProcessInstanceId(processInstance.getId()).singleResult();

		assertNotNull(subProcessInstance);

		// Fetch the created Task
		Task task = processEngine.getTaskService().createTaskQuery().processInstanceId(subProcessInstance.getId())
				.singleResult();

		assertNotNull(task);

		// Make sure we traveled down the timer path
		HistoryService historyService = this.processEngine.getHistoryService();

		// NOTE: This is hard to test because the delay is 60 days in prod.
		// TestUtils.assertActivitiEventFired(historyService,
		// "notifyAdminTimer", 1);
		// TestUtils.assertActivitiEventFired(historyService, "notifyAdmin", 1);
		// TestUtils.assertActivitiEventFired(historyService, "notifyEndEvent",
		// 1);

		LOG.debug("Completing User Task... ");
		this.taskService.complete(task.getId());

		ProcessInstance foundProcess = this.runtimeService.createProcessInstanceQuery().processInstanceId(id)
				.singleResult();

		assertNull(foundProcess);

		LOG.debug("Test complete");
	}

	// @Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn" })
	public void testError() throws InterruptedException {

		LOG.debug("Test (processIrregularity) started.");
		this.methodVarsService.reset();

		// This will cause the test methods indicated to set the listed
		// variables
		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.checkForExistingMarks",
				ProcessFlowConstants.ERR_MSG_IND_VAR, new Boolean(true));
		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.checkForExistingMarks",
				ProcessFlowConstants.ERR_MSG_DESC_VAR, "An error occurred checking Marks.");

		Map<String, Object> processVars = new HashMap<String, Object>();

		String processId = null;
		try {

			processId = startProcessInstance(processVars).getId();

		} catch (Exception e) {
			LOG.error(e.getMessage());
		}

		// Make sure we traveled down the timer path
		HistoryService historyService = this.processEngine.getHistoryService();
		TestUtils.assertActivitiEventFired(historyService, "callActivityErrorBoundaryEvent", 1);
		TestUtils.assertActivitiEventFired(historyService, "errorEndEvent", 1);

		LOG.debug("Test complete.");
	}

}
