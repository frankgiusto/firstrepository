package ca.gc.ised.cipo.tm.madrid.workflow.ws;

import ca.gc.ic.cipo.common.service.AbstractCipoService;

public class MadridWorkflowService extends AbstractCipoService {

    @Override
    public String getComponentAcronym() {

        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getServiceAcronym() {

        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getServiceName() {

        // TODO Auto-generated method stub
        return "MadridWorkflowEngine";
    }

}
