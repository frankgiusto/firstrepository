package ca.gc.ised.cipo.tm.madrid.clients;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.springframework.beans.factory.annotation.Value;

import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.TransactionRequest;
import ca.gc.ic.cipo.tm.mts.client.common.MadridTransactionServiceFactory;

// @RunWith(SpringJUnit4ClassRunner.class)
// @ContextConfiguration(classes = {MadridWorkflowTestConfiguration.class})
public class MadridTransactionServiceTest {

    @Value("${mwe.mts.service.endpoint.hostname}")
    private String mtsHostUrl;

    // @Test
    public void selfTest() throws Exception {

        Service testService = Service.create(new URL(""), new QName(""));

    }

    // @Test
    public void testForExistingMark() throws InterruptedException {

        MadridTransactionServicePortType port = MadridTransactionServiceFactory
            .createMadridTransactionClient("http://wasdevciposprayer.ic.gc.ca:80");

        ExistingMarkRequest req = new ExistingMarkRequest();

        req.setIrTranId(new BigDecimal(1328));

        ExistingMarkResponse res = null;
        try {

            res = port.checkExistingMark(req);

        } catch (Exception e) {

            System.out.println("ERROR! " + e.getMessage());
        }

        assertTrue(res.isMarkExists());

    }

    // @Test
    public void testForNonExistingMark() throws InterruptedException {

        MadridTransactionServicePortType port = MadridTransactionServiceFactory
            .createMadridTransactionClient(mtsHostUrl);

        ExistingMarkRequest req = new ExistingMarkRequest();
        req.setIrTranId(new BigDecimal(32285));

        // ExistingMarkResponce res = null;

        ExistingMarkResponse res = null;
        try {

            res = port.checkExistingMark(req);

        } catch (Exception e) {

            System.out.println("ERROR! " + e.getMessage());
        }

        assertFalse(res.isMarkExists());

    }

    // @Test
    public void testForProcessIRNonRenewal() throws InterruptedException {

        MadridTransactionServicePortType port = MadridTransactionServiceFactory
            .createMadridTransactionClient("http://cipodev.ic.gc.ca");

        AutomaticProcessingCriteria req = new AutomaticProcessingCriteria();

        TransactionRequest tReq = req.getTransactionRequest();
        if (tReq == null) {
            tReq = new TransactionRequest();
            req.setTransactionRequest(tReq);
        }

        tReq.setIrTranId(new BigDecimal(32285));

        // ExistingMarkResponce res = null;

        AutomatedProcessResponse res = null;
        try {

            // to-do
            // res = port.processIRNonRenewal( req );

        } catch (Exception e) {

            System.out.println("ERROR! " + e.getMessage());
        }

        assertNull(res);

    }

}
