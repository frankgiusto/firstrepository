/*
 * Copyright (c) 2018 CIPO Created on August 29, 2018
 */
package ca.gc.ised.cipo.tm.madrid.mock;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.BindingProvider;

import ca.gc.ic.cipo.tm.mps.ImportPackage;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.UpdatePackageStatusType;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.AbstractServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MpsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;

/**
 * A mock object to simulate calls to MPS.
 */
public class MpsServiceManagerMock extends AbstractServiceManager implements MpsServiceManager {

    private static List<TransactionDetail> transactions = new ArrayList<TransactionDetail>();

    /**
     * Constructor.
     */
    public MpsServiceManagerMock() {
        // No op
    }

    @Override
    public BigDecimal processPackage(ImportPackage importPackage, PackageUnit packageUnit)
        throws BpmnWebServiceCallException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PackageStatusEnum getPackageProcessingStatus(BigDecimal packageId, PackageUnit packageUnit)
        throws BpmnWebServiceCallException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public BigDecimal exportPackage(String packageLocation) throws BpmnWebServiceCallException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void updatePackageStatus(UpdatePackageStatusType updatePackageStatusType)
        throws BpmnWebServiceCallException {
        // TODO Auto-generated method stub

    }

    @Override
    protected BindingProvider getBindingProvider() {
        // TODO Auto-generated method stub
        return null;
    }

}