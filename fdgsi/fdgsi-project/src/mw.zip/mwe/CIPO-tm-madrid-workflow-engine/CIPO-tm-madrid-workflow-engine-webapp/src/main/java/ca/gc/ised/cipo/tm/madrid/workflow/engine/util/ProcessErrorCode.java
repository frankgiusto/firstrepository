package ca.gc.ised.cipo.tm.madrid.workflow.engine.util;

/**
 * The Enum ProcessErrorCode defines the types of WFE Faults
 *
 * @author hamerg
 */
public enum ProcessErrorCode {

    SYSTEM_ERROR(Integer.valueOf(1)),

    MTS_UNAVAILABLE(Integer.valueOf(2)),

    TUPS_UNAVAILABLE(Integer.valueOf(3)),

    AUTHORIZATION_FAILURE(Integer.valueOf(4)),

    INVALID_TASK_ID(Integer.valueOf(5)),

    INVALID_PROCESS_ID(Integer.valueOf(6));

    private Integer reasonCode;

    private ProcessErrorCode(Integer reasonCode) {
	this.reasonCode = reasonCode;
    }

    public Integer getReasonCode() {
	return this.reasonCode;
    }

}
