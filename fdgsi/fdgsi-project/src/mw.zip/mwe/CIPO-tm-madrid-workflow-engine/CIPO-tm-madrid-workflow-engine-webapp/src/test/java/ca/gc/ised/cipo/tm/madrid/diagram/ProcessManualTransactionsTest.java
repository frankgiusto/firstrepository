package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.assertEquals;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import util.TestMadridMethodVarsService;
import util.TestUtils;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class ProcessManualTransactionsTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private TaskService taskService;

	@Autowired
	protected HistoryService historyService;

	@Autowired
	private TestMadridMethodVarsService methodVarsService;

	@Autowired
	@Rule
	public ActivitiRule activitiSpringRule;

	private ProcessInstance startProcessInstance(Map<String, Object> processVars) {

		return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("processManualTransactions",
				processVars);
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/import/process_manual_transactions.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForNotifications.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.11_ProcessIRLimitation.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.7.2_ProcessIRCancellation-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_1.3_ProcessIRCorrection.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.6.2_ProcessIRCeasingOfEffect-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.4.3_ProcessDesignation-PartialOwnershipChange.bpmn" })
	public void testDiagram() throws InterruptedException {

		LOG.debug("BPMN Test (processManualTransactions) happy path started.");

		this.methodVarsService.reset();

		// NOTE: This has been successfully tested with up to 1000 transactions
		// but it takes ~10 min to complete using in-memory DB
		List<String[]> tranSet = this.createFetchTransactionsData(30);

		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.fetchTransactions",
				ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_DESC_LIST, tranSet);

		Map<String, Object> processVars = new HashMap<String, Object>();

		// Start the process.
		ProcessInstance processInstance = startProcessInstance(processVars);
		String processId = processInstance.getId();

		LOG.debug("Waiting for UserTask completion... ");
		Thread.sleep(5000);

		List<Task> tasks = processEngine.getTaskService().createTaskQuery().list();

		LOG.debug(tasks.size() + " tasks found");

		assertEquals(tasks.size(), tranSet.size());

		while (!tasks.isEmpty()) {

			Task task = tasks.get(0);

			this.getProcessChain(task);

			LOG.debug("Completing Task -> Id:[" + task.getId() + "]");
			taskService.complete(task.getId());

			tasks = processEngine.getTaskService().createTaskQuery().list();

		}

		tasks = processEngine.getTaskService().createTaskQuery().list();
		assertEquals(tasks.size(), 0);

		LOG.debug("Test complete.");
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/import/process_manual_transactions.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForNotifications.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.11_ProcessIRLimitation.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.7.2_ProcessIRCancellation-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_1.3_ProcessIRCorrection.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.6.2_ProcessIRCeasingOfEffect-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.4.3_ProcessDesignation-PartialOwnershipChange.bpmn" })
	public void testExistingMarkError() throws InterruptedException {

		LOG.debug("BPMN Test (processManualTransactions) error path started.");

		this.methodVarsService.reset();
		Map<String, Object> processVars = new HashMap<String, Object>();

		// This emulates data returned from the MTS when requesting manual
		// transactions
		List<String[]> tranSet = this.createFetchTransactionsData(10);

		// Set give the fifth entry a bad transaction type
		// tranSet.set(5, new String[] { tranSet.get(5)[0], "bad-type" });

		// This will emulate calling fetchTransactionList() on the MTS
		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.fetchTransactions",
				ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_DESC_LIST, tranSet);

		// This causes the checkForExistingMarks to create an error
		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.checkForExistingMarks",
				ProcessFlowConstants.ERR_MSG_IND_VAR, new Boolean(true));

		// Start the process.
		try {

			ProcessInstance processInstance = startProcessInstance(processVars);
			String processId = processInstance.getId();

		} catch (Exception e) {
			// TODO: handle exception
		}

		TestUtils.assertActivitiEventFired(historyService, "handleGeneralError", tranSet.size());

		LOG.debug("Waiting for UserTask completion... ");
		Thread.sleep(5000);

		LOG.debug("Test complete.");
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/import/process_manual_transactions.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForNotifications.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.11_ProcessIRLimitation.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.7.2_ProcessIRCancellation-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_1.3_ProcessIRCorrection.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.6.2_ProcessIRCeasingOfEffect-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.4.3_ProcessDesignation-PartialOwnershipChange.bpmn" })
	public void testUnknownTypeError() throws InterruptedException {

		LOG.debug("BPMN Test (processManualTransactions) error path started.");

		this.methodVarsService.reset();
		Map<String, Object> processVars = new HashMap<String, Object>();

		// This emulates data returned from the MTS when requesting manual
		// transactions
		List<String[]> tranSet = this.createFetchTransactionsData(10);

		// Set give the fifth entry a bad transaction type
		tranSet.set(5, new String[] { tranSet.get(5)[0], "bad-type" });

		// This will emulate calling fetchTransactionList() on the MTS
		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.fetchTransactions",
				ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_DESC_LIST, tranSet);

		// Start the process.
		try {

			ProcessInstance processInstance = startProcessInstance(processVars);
			String processId = processInstance.getId();

		} catch (Exception e) {
			// TODO: handle exception
		}

		List<Task> tasks = processEngine.getTaskService().createTaskQuery().list();

		LOG.debug(tasks.size() + " tasks found");

		assertEquals(tasks.size(), tranSet.size() - 1);

		TestUtils.assertActivitiEventFired(historyService, "handleGeneralError", 1);

		LOG.debug("Waiting for UserTask completion... ");
		Thread.sleep(5000);

		LOG.debug("Test complete.");
	}

	@Test
	@Deployment(resources = { "ca/gc/ised/cipo/tm/madrid/diagram/import/process_manual_transactions.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForExistingMark.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CreateConsoleTask.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/core/CheckForNotifications.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.11_ProcessIRLimitation.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.7.2_ProcessIRCancellation-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_1.3_ProcessIRCorrection.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.6.2_ProcessIRCeasingOfEffect-Partial.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.12_ProcessIrregularity.bpmn",
			"ca/gc/ised/cipo/tm/madrid/diagram/manual/SUC_2.4.3_ProcessDesignation-PartialOwnershipChange.bpmn" })
	public void testGetTransactionsError() throws InterruptedException {

		LOG.debug("BPMN Test (processManualTransactions) error path started.");

		this.methodVarsService.reset();
		Map<String, Object> processVars = new HashMap<String, Object>();

		// This emulates data returned from the MTS when requesting manual
		// transactions
		List<String[]> tranSet = this.createFetchTransactionsData(2);

		// This will emulate calling fetchTransactionList() on the MTS
		this.methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.fetchTransactions",
				ProcessFlowConstants.MTS_ERROR, new Boolean(true));

		// Start the process.
		try {

			ProcessInstance processInstance = startProcessInstance(processVars);
			String processId = processInstance.getId();

		} catch (Exception e) {
			// TODO: handle exception
		}

		TestUtils.assertActivitiEventFired(historyService, "handleGeneralError1", 1);

		LOG.debug("Waiting for UserTask completion... ");
		Thread.sleep(5000);

		LOG.debug("Test complete.");
	}

	/**
	 * This emulates the MTS returning a list of manual transactions of an
	 * arbitrary size.
	 *
	 * @param size
	 * @return
	 */
	private List<String[]> createFetchTransactionsData(Integer size) {

		List<String[]> transActions = new ArrayList<String[]>(size);

		String[] types = { "MPR_LIMITATION", "MPR_PARTIAL_CANCELLATION", "MC_CORRECTION",
				"MPR_PARTIAL_CEASING_OF_EFFECT", "MI_IRREGULARITY_NOTIFICATION", "MPR_PARTIAL_CHANGE_OF_OWNERSHIP" };

		int typeIndex = 0;
		Integer transId = 10000;

		for (int i = 0; i < size; i++) {

			transActions.add(new String[] { (transId++).toString(), types[typeIndex++] });

			if (typeIndex >= types.length) {
				typeIndex = 0;
			}
		}

		return transActions;
	}

	/**
	 *
	 * @param task
	 * @return
	 */
	private List<String> getProcessChain(Task task) {

		ArrayList<String> chain = new ArrayList<String>();

		String executionId = task.getExecutionId();

		while (executionId != null) {

			Execution exec = runtimeService.createExecutionQuery().executionId(executionId).singleResult();

			if (exec != null && exec.getParentId() != null) {
				executionId = exec.getParentId();
			} else if (exec != null && exec.getSuperExecutionId() != null) {
				executionId = exec.getSuperExecutionId();
			} else {

				executionId = null;
			}

			if (exec.getActivityId() != null) {

				chain.add(exec.getActivityId());

			} else {

				chain.add(null);

			}

		}

		return chain;
	}

}
