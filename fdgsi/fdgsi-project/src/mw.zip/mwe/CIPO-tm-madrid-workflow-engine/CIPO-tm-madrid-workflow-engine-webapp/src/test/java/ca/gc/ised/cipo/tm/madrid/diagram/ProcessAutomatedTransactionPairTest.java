/*
 * Copyright (c) 2018 CIPO Created on May 18, 2018
 */
package ca.gc.ised.cipo.tm.madrid.diagram;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.mock.MtsServiceManagerMock;
import util.TestUtils;

/**
 * A test class for the ProcessAutomatedTransactionPair Activiti process flow.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MadridWorkflowTestConfiguration.class})
@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:package_log_before.sql"),
    @Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:package_log_after.sql")})
public class ProcessAutomatedTransactionPairTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessAutomatedTransactionPairTest.class);

    @Autowired
    @Rule
    public ActivitiRule activitiSpringRule;

    @Autowired
    protected HistoryService historyService;

    /**
     * Constrcutor.
     */
    public ProcessAutomatedTransactionPairTest() {
        // no op
    }

    /**
     * Convenience method to launch the process flow.
     *
     * @param processVars variables to be used on the flow
     * @return reference to the process flow instance
     */
    private ProcessInstance startProcessInstance(Map<String, Object> processVars) {
        return activitiSpringRule.getRuntimeService().startProcessInstanceByKey("processAutomatedPairsFromWipo",
            processVars);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/ProcessAutomatedPairsFromWIPO.bpmn"})
    public void testNoPendingTransactions() throws InterruptedException {
        LOGGER.debug("\n\n-- JUnit Test for 0 unprocessed transaction pairs --");
        MtsServiceManagerMock.setUprocessedTransactions(new ArrayList<TransactionDetail>());

        // Kick off the flow
        ProcessInstance testInstance = startProcessInstance(null);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiSpringRule, 30000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "listAutomatedPairs", 1);
        TestUtils.assertActivitiEventFired(historyService, "processAutomatedPairTask", 0);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/ProcessAutomatedPairsFromWIPO.bpmn"})
    public void testOnePendingTransaction() throws InterruptedException {
        LOGGER.debug("\n\n-- JUnit Test for 1 unprocessed transaction pair --");

        // Add one Transaction for this test case
        List<TransactionDetail> testTransactions = new ArrayList<TransactionDetail>();
        TransactionDetail trans1 = new TransactionDetail();
        trans1.setTransactionId(new BigDecimal(5000)); // No Notification console task for this
        testTransactions.add(trans1);
        MtsServiceManagerMock.setUprocessedTransactions(testTransactions);

        // Kick off the flow
        ProcessInstance testInstance = startProcessInstance(null);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiSpringRule, 30000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "listAutomatedPairs", 1);
        TestUtils.assertActivitiEventFired(historyService, "processAutomatedPairTask", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/ProcessAutomatedPairsFromWIPO.bpmn"})
    public void testTwoPendingTransactions() throws InterruptedException {
        LOGGER.debug("\n\n-- JUnit Test for 2 unprocessed transaction pairs --");

        // Add one Transaction for this test case
        List<TransactionDetail> testTransactions = new ArrayList<TransactionDetail>();
        TransactionDetail trans1 = new TransactionDetail();
        trans1.setTransactionId(new BigDecimal(5001));
        testTransactions.add(trans1);

        TransactionDetail trans2 = new TransactionDetail();
        trans2.setTransactionId(new BigDecimal(5002));
        testTransactions.add(trans2);

        MtsServiceManagerMock.setUprocessedTransactions(testTransactions);

        // Kick off the flow
        ProcessInstance testInstance = startProcessInstance(null);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiSpringRule, 30000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "listAutomatedPairs", 1);
        TestUtils.assertActivitiEventFired(historyService, "processAutomatedPairTask", 2);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/ProcessAutomatedPairsFromWIPO.bpmn"})
    public void testGeneralErrorHandling() throws InterruptedException {
        LOGGER.debug("\n\n-- JUnit Test for General Error Handling --");

        // Add one Error Transaction for this test case (MTS Mock will detect an ID of -1 and throw an exception
        List<TransactionDetail> testTransactions = new ArrayList<TransactionDetail>();
        TransactionDetail trans1 = new TransactionDetail();
        trans1.setTransactionId(new BigDecimal(-1));
        testTransactions.add(trans1);
        MtsServiceManagerMock.setUprocessedTransactions(testTransactions);

        // Kick off the flow
        ProcessInstance testInstance = startProcessInstance(null);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiSpringRule, 30000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "listAutomatedPairs", 1);
        TestUtils.assertActivitiEventFired(historyService, "processAutomatedPairTask", 0);
        TestUtils.assertActivitiEventFired(historyService, "handleGeneralErrorTask", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/ProcessAutomatedPairsFromWIPO.bpmn"})
    public void testIterativeErrorHandling() throws InterruptedException {
        LOGGER.debug("\n\n-- JUnit Test for Iterative Error Handling 1 --");

        // Add one Error Transaction for this test case (MTS Mock will detect an ID of -1 and throw an exception
        List<TransactionDetail> testTransactions = new ArrayList<TransactionDetail>();
        TransactionDetail trans1 = new TransactionDetail();
        trans1.setTransactionId(new BigDecimal(-2));
        testTransactions.add(trans1);

        TransactionDetail trans2 = new TransactionDetail();
        trans2.setTransactionId(new BigDecimal(5002));
        testTransactions.add(trans2);

        MtsServiceManagerMock.setUprocessedTransactions(testTransactions);

        // Kick off the flow
        ProcessInstance testInstance = startProcessInstance(null);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiSpringRule, 30000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "listAutomatedPairs", 1);
        TestUtils.assertActivitiEventFired(historyService, "processAutomatedPairTask", 2);
        TestUtils.assertActivitiEventFired(historyService, "testIterativeErrorTask", 1);
        TestUtils.assertActivitiEventFired(historyService, "handleGeneralErrorTask", 0);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/automated/ProcessAutomatedPairsFromWIPO.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/core/CreateNotificationTask.bpmn"})
    public void testUserNotification() throws InterruptedException {
        LOGGER.debug("\n\n-- JUnit Test for Automated Transaction Pair requiring a separate User Notification task --");

        // Add one Transaction which requires a user notification
        List<TransactionDetail> testTransactions = new ArrayList<TransactionDetail>();
        TransactionDetail trans1 = new TransactionDetail();
        trans1.setTransactionId(new BigDecimal(5005)); // Id 5005 = user notification required
        testTransactions.add(trans1);

        MtsServiceManagerMock.setUprocessedTransactions(testTransactions);

        // Kick off the flow
        ProcessInstance testInstance = startProcessInstance(null);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiSpringRule, 30000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);
        TestUtils.assertActivitiEventFired(historyService, "listAutomatedPairs", 1);
        TestUtils.assertActivitiEventFired(historyService, "processAutomatedPairTask", 1);

        List<ProcessInstance> instanceList = activitiSpringRule.getRuntimeService().createProcessInstanceQuery()
            .processDefinitionKey("createNotification").list();

        // Ensure there is one instance of the "CreateNotification" manual task running
        assertNotNull("The list of CreateNotification flows should NOT be NULL", instanceList);
        assertEquals("There should be one (1) instance of the CreateNotification flow running", instanceList.size(), 1);
        LOGGER.debug("createNotification Task Process ID = " + instanceList.get(0).getProcessInstanceId());
    }
}
