package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.*;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;

import ca.gc.ic.cipo.tm.mts.TransactionDetail;

/**
 * Test service implementation for the {@code process_hague_financial_transactions_from_wipo.bpmn} workflow delegate
 * execution service.
 *
 * @author J. Greene
 *
 */
public class TestFinancialTransactionReconcileServiceImpl extends TestBusinessErrorHandlerImpl
    implements FinancialTransactionReconcileService {

    protected Integer financialTransactionListGetStatusReturnObject;

    protected Integer financialTransactionReconcileStatusReturnObject;

    protected Integer recoverableErrorConditionReturnObject;

    protected Integer generateReconciledXmlStatusReturnObject;

    protected Integer reconciledSetStatusReturnObject;

    /** {@inheritDoc} */
    @Override
    public void setProcessFlowVariables(DelegateExecution execution) {
        System.out.println("[[setProcessFlowVariables]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void getFinancialTransactionCollection(DelegateExecution execution) {
        if (getFinancialTransactionListGetStatusReturnObject() != null) {
            execution.setVariable(FINANCIAL_TRANSACTION_LIST_GET_STATUS,
                getFinancialTransactionListGetStatusReturnObject());
        }
        System.out.println("[[getFinancialTransactionCollection]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void reconcileFinancialTransaction(DelegateExecution execution) {
        if (getFinancialTransactionReconcileStatusReturnObject() != null) {
            execution.setVariable(FINANCIAL_TRANSACTION_RECONCILE_STATUS,
                getFinancialTransactionReconcileStatusReturnObject());
        }
        System.out.println("[[reconcileFinancialTransaction]] GLOBAL: " + execution.getVariables());
        System.out.println("[[reconcileFinancialTransaction]]  LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void generateReconciledFeeXml(DelegateExecution execution) {
        if (getGenerateReconciledXmlStatusReturnObject() != null) {
            execution.setVariable(GENERATE_RECONCILED_XML_STATUS, getGenerateReconciledXmlStatusReturnObject());
        }
        System.out.println("[[generateReconciledFeeXml]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void handleIterativeError(DelegateExecution execution) {
        if (getRecoverableErrorConditionReturnObject() != null) {
            execution.setVariable(RECOVERABLE_ERROR_CONDITION, getRecoverableErrorConditionReturnObject());
        }

        TransactionDetail transactionDetail = execution.getVariableLocal(TRANSACTION_DETAIL, TransactionDetail.class);
        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
        if (runningErrorMessageList == null) {
            runningErrorMessageList = new ArrayList<>();
        }
        runningErrorMessageList.add("Blah blah blah " + transactionDetail.getTransactionId());
        execution.setVariable(RUNNING_ERROR_MESSAGE, runningErrorMessageList);

        execution.setVariable(RECONCILED_INDICATOR, Boolean.FALSE);

        System.out.println("[[handleIterativeError]] GLOBAL: " + execution.getVariables());
        System.out.println("[[handleIterativeError]]  LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void updatePkgStatusPostReconcile(DelegateExecution execution) {
        if (getReconciledSetStatusReturnObject() != null) {
            execution.setVariable(RECONCILED_SET_STATUS, getReconciledSetStatusReturnObject());
        }
        System.out.println("[[updatePkgStatusPostReconcile]]: " + execution.getVariables());
    }

    /**
     * @return the financialTransactionListGetStatusReturnObject
     */
    public Integer getFinancialTransactionListGetStatusReturnObject() {
        return financialTransactionListGetStatusReturnObject;
    }

    /**
     * @param financialTransactionListGetStatusReturnObject the financialTransactionListGetStatusReturnObject to set
     */
    public void setFinancialTransactionListGetStatusReturnObject(Integer financialTransactionListGetStatusReturnObject) {
        this.financialTransactionListGetStatusReturnObject = financialTransactionListGetStatusReturnObject;
    }

    /**
     * @return the financialTransactionReconcileStatusReturnObject
     */
    public Integer getFinancialTransactionReconcileStatusReturnObject() {
        return financialTransactionReconcileStatusReturnObject;
    }

    /**
     * @param financialTransactionReconcileStatusReturnObject the financialTransactionReconcileStatusReturnObject to set
     */
    public void setFinancialTransactionReconcileStatusReturnObject(Integer financialTransactionReconcileStatusReturnObject) {
        this.financialTransactionReconcileStatusReturnObject = financialTransactionReconcileStatusReturnObject;
    }

    /**
     * @return the recoverableErrorConditionReturnObject
     */
    public Integer getRecoverableErrorConditionReturnObject() {
        return recoverableErrorConditionReturnObject;
    }

    /**
     * @param recoverableErrorConditionReturnObject the recoverableErrorConditionReturnObject to set
     */
    public void setRecoverableErrorConditionReturnObject(Integer recoverableErrorConditionReturnObject) {
        this.recoverableErrorConditionReturnObject = recoverableErrorConditionReturnObject;
    }

    /**
     * @return the generateReconciledXmlStatusReturnObject
     */
    public Integer getGenerateReconciledXmlStatusReturnObject() {
        return generateReconciledXmlStatusReturnObject;
    }

    /**
     * @param generateReconciledXmlStatusReturnObject the generateReconciledXmlStatusReturnObject to set
     */
    public void setGenerateReconciledXmlStatusReturnObject(Integer generateReconciledXmlStatusReturnObject) {
        this.generateReconciledXmlStatusReturnObject = generateReconciledXmlStatusReturnObject;
    }

    /**
     * @return the reconciledSetStatusReturnObject
     */
    public Integer getReconciledSetStatusReturnObject() {
        return reconciledSetStatusReturnObject;
    }

    /**
     * @param reconciledSetStatusReturnObject the reconciledSetStatusReturnObject to set
     */
    public void setReconciledSetStatusReturnObject(Integer reconciledSetStatusReturnObject) {
        this.reconciledSetStatusReturnObject = reconciledSetStatusReturnObject;
    }

}
