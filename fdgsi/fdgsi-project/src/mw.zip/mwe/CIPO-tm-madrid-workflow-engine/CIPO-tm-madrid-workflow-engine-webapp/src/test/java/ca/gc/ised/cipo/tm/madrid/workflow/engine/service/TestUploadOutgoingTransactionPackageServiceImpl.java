package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_GATHER_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_LOCATION_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQ_ID_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_PACKAGE_VERIFY_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPLOAD_TR_STATUS;

import java.util.List;
import java.util.UUID;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * A test service class to be used for unit testing the
 * upload_madrid_packages_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
public class TestUploadOutgoingTransactionPackageServiceImpl extends TestBusinessErrorHandlerImpl
		implements UploadOutgoingPackageService {

	private Integer packageGatherStatusReturnObject;

	private Integer packageVerifyStatusReturnObject;

	private Integer uploadTrStatusReturnObject;

	private List<String> packatgeListReturnObject;

	/** {@inheritDoc} */
	@Override
	public void prepareUploadPackage(DelegateExecution execution) {
		if (getPackageGatherStatusReturnObject() != null) {
			execution.setVariable(PACKAGE_GATHER_STATUS, getPackageGatherStatusReturnObject());
		}
		if (getPackageGatherStatusReturnObject().equals(ERROR)) {
			execution.setVariable(ERR_MSG_OBJECT_VAR,
					"Excecution ID: " + execution.getId() + " - Error with create upload package.");
		}
		if (getPackatgeListReturnObject() != null) {
			execution.setVariable(PACKAGE_LOCATION_LIST, getPackatgeListReturnObject());
		}
		System.out.println("[[prepareUploadPackage]]: " + execution.getVariables());
	}

	/** {@inheritDoc} */
	@Override
	public void createTransferRequest(DelegateExecution execution) {
		execution.setVariableLocal(TRANSFER_REQ_ID_VAR, UUID.randomUUID().toString());
		if (getUploadTrStatusReturnObject() != null) {
			execution.setVariableLocal(UPLOAD_TR_STATUS, getUploadTrStatusReturnObject());
		}
		System.out.println("[[createTransferRequest]] LOCAL: " + execution.getVariablesLocal());
		System.out.println("[[createTransferRequest]] GLOBAL: " + execution.getVariables());
	}

	/** {@inheritDoc} */
	@Override
	public void verifyPackageTransfer(DelegateExecution execution) {
		if (getPackageVerifyStatusReturnObject() != null) {
			execution.setVariableLocal(UPLOAD_PACKAGE_VERIFY_STATUS, getPackageVerifyStatusReturnObject());
			execution.setVariableLocal(TRANSFER_REQ_ID_VAR, UUID.randomUUID().toString());
		}
		if (getPackageVerifyStatusReturnObject().equals(ERROR)) {
			execution.setVariable(ERR_MSG_OBJECT_VAR,
					"Excecution ID: " + execution.getId() + " - Error with verify upload package transfer.");
		}
		if (getPackageVerifyStatusReturnObject().equals(INCOMPLETE)) {
			setPackageVerifyStatusReturnObject(COMPLETE);
		}
		System.out.println("[[verifyPackageTransfer]] LOCAL: " + execution.getVariablesLocal());
		System.out.println("[[verifyPackageTransfer]] GLOBAL: " + execution.getVariables());
	}

	/** {@inheritDoc} */
	@Override
	public void cleanUp(DelegateExecution execution) {
		System.out.println("[[cleanUp]]: " + execution.getVariablesLocal());
	}

	/** {@inheritDoc} */
	@Override
	public void movePackageToFail(DelegateExecution execution) {
		System.out.println("[[movePackageToFail]]: " + execution.getVariablesLocal());
	}

	/**
	 * @return the packageGatherStatusReturnObject
	 */
	public Integer getPackageGatherStatusReturnObject() {
		return packageGatherStatusReturnObject;
	}

	/**
	 * @param packageGatherStatusReturnObject
	 *            the packageGatherStatusReturnObject to set
	 */
	public void setPackageGatherStatusReturnObject(Integer packageCreateStatusReturnObject) {
		this.packageGatherStatusReturnObject = packageCreateStatusReturnObject;
	}

	/**
	 * @return the packageVerifyStatusReturnObject
	 */
	public Integer getPackageVerifyStatusReturnObject() {
		return packageVerifyStatusReturnObject;
	}

	/**
	 * @param packageVerifyStatusReturnObject
	 *            the packageVerifyStatusReturnObject to set
	 */
	public void setPackageVerifyStatusReturnObject(Integer packageVerifyStatusReturnObject) {
		this.packageVerifyStatusReturnObject = packageVerifyStatusReturnObject;
	}

	/**
	 * @return the packatgeListReturnObject
	 */
	public List<String> getPackatgeListReturnObject() {
		return packatgeListReturnObject;
	}

	/**
	 * @param packatgeListReturnObject
	 *            the packatgeListReturnObject to set
	 */
	public void setPackatgeListReturnObject(List<String> packatgeListReturnObject) {
		this.packatgeListReturnObject = packatgeListReturnObject;
	}

	/**
	 * @return the uploadTrStatusReturnObject
	 */
	public Integer getUploadTrStatusReturnObject() {
		return uploadTrStatusReturnObject;
	}

	/**
	 * @param uploadTrStatusReturnObject
	 *            the uploadTrStatusReturnObject to set
	 */
	public void setUploadTrStatusReturnObject(Integer uploadTrStatusReturnObject) {
		this.uploadTrStatusReturnObject = uploadTrStatusReturnObject;
	}

}
