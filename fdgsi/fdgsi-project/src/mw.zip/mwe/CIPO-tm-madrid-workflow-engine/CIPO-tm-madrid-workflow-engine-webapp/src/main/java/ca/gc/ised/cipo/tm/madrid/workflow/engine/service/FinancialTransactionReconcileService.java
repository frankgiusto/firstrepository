package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code process_hague_financial_transactions_from_wipo.bpmn} process flow.
 *
 * @author J. Greene
 *
 */
public interface FinancialTransactionReconcileService extends BusinessErrorHandler {

    /**
     * Service task method responsible for fetching a collection of financial transaction IDs from a service for
     * processing.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void getFinancialTransactionCollection(DelegateExecution execution);

    /**
     * Service task method responsible for feeding the individual financial transaction to the service that will process
     * them.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void reconcileFinancialTransaction(DelegateExecution execution);

    /**
     * Service task method responsible for calling the service to generate the reconciled fee XML file.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void generateReconciledFeeXml(DelegateExecution execution);

    /**
     * Service task method responsible for evaluating and collecting iterative errors that may occur in the looping
     * subprocess.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void handleIterativeError(DelegateExecution execution);

    /**
     * EVENT LISTENER: To be used to set variables from HWE configuration parameters. Since this process flow kicks off
     * automatically from the package process flow, it would be too bulky to carry forward the dozens of configurable
     * parameters so we will do it here.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void setProcessFlowVariables(DelegateExecution execution);

    /**
     * Service task method to call the operation to set the package status after reconciliation is completed without
     * errors.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void updatePkgStatusPostReconcile(DelegateExecution execution);

}
