package ca.gc.ised.cipo.tm.madrid.workflow.engine.util;

/**
 * Container for constants related to Activity workflow
 *
 * @author J. Greene
 */
public final class ProcessFlowConstants {

    /** For global business error handling */
    public static final String ERR_MSG_IND_VAR = "ERROR_CONDITION";

    public static final String ERR_CAUSE = "errorCause";

    public static final String ERR_MSG_DESC_VAR = "errorMsgDescription";

    public static final String SIGNAL_MTS_FAILURE = "mts-failure-signal";

    public static final String SIGNAL_MTS_RECOVERY = "mts-recovery-signal";

    public static final String PROCESS_MADRID_DESIGNATION_KEY = "processMadridDesignation";

    public static final String CALLING_PROCESS_NAME = "callingProcessName";

    public static final String SERVICE_RESPONSE_VAR = "success";

    public static final String MARK_EXISTS_VAR = "markExists";

    public static final String INTL_REGISTRY_NUMBER = "irNumber";

    public static final String INTL_REGISTRY_TRANSACTION_ID = "irTranId";

    public static final String INTL_REGISTRY_TRANSACTION_TYPE = "irTranType";

    public static final String INTL_REGISTRY_TRANSACTION_DESC_LIST = "transDescs";

    public static final String INTL_REGISTRY_TRANSACTION_DESC = "transDesc";

    public static final String MTS_ERROR = "mtsError";

    public static final String CANDIDATE_GROUP_ID = "candidateGroupId";

    public static final String CONSOLE_TASK_ID = "consoleTaskId";

    public static final String CONSOLE_TASK_ID_LIST = "consoleTaskIdList";

    public static final String CONSOLE_TASK_TYPE = "consoleTaskType";

    public static final String CONSOLE_TASK_STATUS = "consoleTaskStatus";

    public static final String MWE_SERVICE_NAME = "MadridWorkflowEngine";

    private ProcessFlowConstants() {

    }

    // LOB acronyms

    public static final String DTF = "DTF";

    public static final String RGS = "RGS";

    public static final String MPS = "MPS";

    public static final String MTS = "MTS";

    public static final String MFS = "MFS";

    public static final String MWE = "MWE";

    // Staging folder suffixes

    public static final String XML = "xml";

    public static final String IMG = "img";

    public static final String FAIL = "fail";

    public static final String PKG = "pkg";

    // Staging folder path names - note these were once useful when directory names were derived but not necessary now.

    public static final String MWE_OUTGOING_STAGING_DIR_FINANCIAL_PKG = "mwe.outgoing.staging.dir.financial.pkg";

    public static final String MWE_OUTGOING_STAGING_DIR_FINANCIAL_FAIL = "mwe.outgoing.staging.dir.financial.fail";

    public static final String MWE_INCOMING_STAGING_DIR_FINANCIAL_CIPO_XML = "mwe.incoming.staging.dir.financial.cipo.xml";

    public static final String MWE_INCOMING_STAGING_DIR_FINANCIAL_CIPO_FAIL = "mwe.incoming.staging.dir.financial.cipo.fail";

    public static final String MWE_INCOMING_STAGING_DIR_FINANCIAL_WIPO_XML = "mwe.incoming.staging.dir.financial.wipo.xml";

    public static final String MWE_INCOMING_STAGING_DIR_FINANCIAL_WIPO_FAIL = "mwe.incoming.staging.dir.financial.wipo.fail";

    // Process flow variables
    public static final String REPORT_GENERATION_SUBPROCESS = "reportGenerationSubprocess";

    public static final String DOWNLOAD_INCOMING_PACKAGE = "downloadWipoMadridPackage";

    public static final String PERSIST_INCOMING_PACKAGE = "persistPackageData";

    public static final String PROCESS_INCOMING_TM_TRANSACTIONS = "processTmTransactionsFromWipo";

    public static final String PROCESS_INCOMING_FINANCIAL_TRANSACTIONS = "processMadridFinancialTransactionsFromWipo";

    public static final String CREATE_OUTGOING_MANUAL_TRANSACTIONS = "createMadridManualTransactionsToWipo";

    public static final String CREATE_OUTGOING_TRANSACTIONS = "createMadridTransactionsToWipo";

    public static final String PACKAGE_OUTGOING_TRANSACTIONS = "packageWipoMadridTransactions";

    public static final String UPLOAD_OUTGOING_PACKAGE = "uploadWipoMadridPackages";

    public static final String SEND_RECONCILED_FEES_TO_FIN_SYSTEM = "sendReconciledFeesToFinSystem";

    public static final String DOWNLOAD_FINANCIAL_SYSTEM_STATUS_PACKAGE = "downloadFinancialSystemStatusPackage";

    public static final String UPDATE_FINANCIAL_FEE_STATUS = "updateFinancialFeeStatus";

    public static final String GENERATE_FINANCIAL_GAP_REPORTS = "generateFinancialGapReports";

    public static final String REPORT_GEN_SUBPROCESS_STATUS = "reportGenSubprocessStatus";

    public static final String ASYNC_OPERATION_STATUS = "asyncOperationStatus";

    // Persist package flow variables
    public static final String PACKAGE_FETCH_STATUS = "packageFetchStatus";

    public static final String PERSIST_PACKAGE_CALL_STATUS = "persistPackageCallStatus";

    public static final String PACKAGE_PERSISTENCE_VERIFY_STATUS = "packagePersistenceVerifyStatus";

    public static final String PERSIST_VERIFICATION_POLL_PERIOD = "persistVerificationPollPeriod";

    public static final String PERSISTED_PACKAGE_ID = "persistedPackageId";

    public static final String PACKAGE_UNIT_LIST = "packageUnitList";

    public static final String PACKAGE_UNIT_ITEM = "packageUnit";

    public static final String NUMBER_OF_REATTEMPTS = "numberOfReattempts";

    public static final String MFS_SPLIT_STATUS = "mfsSplitStatus";

    public static final String PACKAGE_ID = "packageId";

    public static final String TRANSACTION_ID = "transactionId";

    public static final String TRANSACTION_DETAIL = "transactionDetail";

    public static final String TRANSACTION_DETAIL_LIST = "transactionDetailList";

    // TM Transaction processing variables

    public static final String GET_PDF_TRANSACTION_STATUS = "getPdfTransactionsStatus";

    public static final String GET_IMPORT_TRANSACTION_STATUS = "getImportTransactionsStatus";

    public static final String IMPORT_TRANSACTION_STATUS = "importTransactionStatus";

    public static final String IMPORT_PENDING_TRANSACTION_DETAILS_COLLECTION = "importPendingTransactionDetailsCollection";

    public static final String IMPORT_PENDING_TRANSACTION_DETAILS = "importPendingTransactionDetails";

    public static final String TRANSACTION_ID_COLLECTION = "transactionIdCollection";

    public static final String TRANSACTION_IMPORT_POLL_PERIOD = "mwe.transaction.import.poll.period";

    // Manual Transactions variables
    public static final String TRANSACTION_TYPE = "transactionType";

    public static final String WAIT_FOR_MTS_SIGNAL_TASK_NAME = "waitForMtsSignalTask";

    public static final String CREATE_OUTGOING_MANUAL_TASK = "createOutgoingManualTask";

    // Automated Transactions variables
    public static final String PROCESS_AUTOMATED_TRANSACTIONS = "processAutomatedTransactionsFromWipo";

    public static final String PROCESS_AUTOMATED_TRANSACTION_PAIRS = "processAutomatedPairsFromWipo";

    public static final String AUTOMATED_TRANSACTION_COLLECTION = "automatedTransactionCollection";

    public static final String WAIT_FOR_MFS_SIGNAL_TASK_NAME = "waitForMfsSignalTask";

    // Finance flow variables
    public static final String FINANCIAL_TRANSACTION_LIST_GET_STATUS = "financialTransactionListGetStatus";

    public static final String FINANCIAL_TRANSACTION_RECONCILE_STATUS = "financialTransactionReconcileStatus";

    public static final String RECOVERABLE_ERROR_CONDITION = "recoverableErrorCondition";

    public static final String GENERATE_RECONCILED_XML_STATUS = "generateReconciledXmlStatus";

    public static final String TRANSACTION_ID_LIST = "transactionIdList";

    public static final String UPDATE_FEE_DROP_STATUS = "updateFeeDropStatus";

    public static final String VERIFY_FIN_FILIE_UPLOAD_STATUS = "verifyFinFileUploadStatus";

    public static final String SKIP_FINANCE_TRANSFERS = "skipFinanceTransfers";

    public static final String FIN_FILE_UPLOAD_REQUEST_STATUS = "finFileUploadRequestStatus";

    public static final String FIN_PKG_PERSIST_NUMBER_OF_REATTEMPTS = "finPkgPersistNumberOfReattempts";

    public static final String FIN_PKG_UPLOAD_STAGING_FOLDER = "finPkgUploadStagingFolder";

    public static final String FIN_PKG_UPLOAD_FILE_NAME = "finPkgUploadFileName";

    public static final String FIN_PKG_UPLOAD_STAGING_FAIL_FOLDER = "finPkgUploadStagingFailureFolder";

    public static final String FIN_PKG_PERSIST_INPUT_FOLDER = "finPkgPersistInputFolder";

    public static final String FIN_PKG_PERSIST_FAIL_FOLDER = "finPkgPersistFailureFolder";

    public static final String FIN_PKG_PERSIST_TRANSFER_ITEM = "finPkgPersistTransferItem";

    public static final String FIN_PKG_PERSIST_VERIFICATION_POLL_PERIOD = "finPkgPersistVerificationPollPeriod";

    public static final String PACKAGE_MOVE_TO_STAGING_STATUS = "packageMoveToStagingStatus";

    public static final String VERIFY_FIN_PACKAGE_DOWNLOAD_TRANSFER_STATUS = "verifyFinPackageDownloadTransferStatus";

    public static final String FIN_PKG_DOWNLOAD_REQUEST_STATUS = "finPkgDownloadRequestStatus";

    public static final String FIN_PKG_DOWNLOAD_VERIFICATION_POLL_PERIOD = "finPkgDownloadVerificationPollPeriod";

    public static final String FIN_PKG_FILE_NOT_FOUND_RETRY_PERIOD = "finPkgFileNotFoundRetryPeriod";

    public static final String FIN_PKG_DOWNLOAD_FAIL_FOLDER = "finPkgDownloadFailFolder";

    public static final String FIN_PKG_DOWNLOAD_NUMBER_OF_RETRIES = "finPkgDownloadNumberOfRetries";

    public static final String FIN_PKG_DOWNLOAD_TRANSFER_ITEM = "finPkgDownloadTransferItem";

    public static final String FIN_PKG_DOWNLOAD_FILE_FULL_PATH = "finPkgDownloadFileFullPath";

    public static final String FIN_PKG_DOWNLOAD_REMOTE_FILE_NAME_REGEX = "finPkgDownloadRemoteFileNameRegex";

    public static final String FETCH_FIN_SYSTEM_PACKAGE_TRANSACTION_STATUS = "fetchFinSystemPackageTransactionsStatus";

    public static final String UPDATE_FEE_STATUS_STATUS = "updateFeeStatusStatus";

    public static final String FIN_PACKAGE_ID = "finPackageId";

    public static final String FIN_STATUS_UPDATE_TRANSACTION_DETAIL_LIST = "finStatusUpdateTransactionDetailList";

    public static final String FIN_STATUS_UPDATE_TRANSACTION_DETAIL = "finStatusUpdateTransactionDetail";

    public static final String GAP_REPORT_DATA_GENERATION_STATUS = "gapReportDataGenerationStatus";

    public static final String GAP_REPORT_EMAIL_NOTIFICATION_STATUS = "gapReportEmailNotificationStatus";

    public static final String REPORT_TYPE_LIST = "reportTypeList";

    public static final String RECONCILED_INDICATOR = "reconciledIndicator";

    public static final String RECONCILED_SET_STATUS = "reconciledSetStatus";

    public static final String FEE_STATUS_UPDATE_INDICATOR = "feeStatusUpdateIndicator";

    public static final String FEE_STATUS_UPDATE_STATUS = "feeStatusUpdateStatus";

    public static final String BYPASS_GAP_REPORT_NOTIFICATION = "bypassGapReportNotification";

    public static final String AR_PACKAGE_LIST = "arPackageList";

    public static final String DTF_TRANSFER_REQUEST_STATUS = "dtfTransferRequestStatus";

    // Outgoing message flow variables

    public static final String FETCH_PENDING_MSG_STATUS = "fetchPendingMsgsStatus";

    public static final String FETCH_PENDING_AUTOMATED_MSG_STATUS = "fetchPendingAutomatedMsgsStatus";

    public static final String FETCH_PENDING_MANUAL_MSG_STATUS = "fetchPendingManualMsgsStatus";

    public static final String CREATE_AND_PERSIST_AUTOMATED_MESSAGE_STATUS = "createAndPersistAutomatedMessageStatus";

    public static final String CREATE_AND_PERSIST_MANUAL_MESSAGE_STATUS = "createAndPersistManualMessageStatus";

    public static final String CREATE_UPLOAD_PACKAGE_STATUS = "createUploadPackageStatus";

    public static final String PACKAGE_GATHER_STATUS = "packageGatherStatus";

    public static final String UPLOAD_TR_STATUS = "uploadTrStatus";

    public static final String UPLOAD_PACKAGE_VERIFY_STATUS = "packageVerifyStatus";

    public static final String CREATION_VERIFICATION_POLL_INTERVAL = "creationVerificationPollInterval";

    public static final String UPLOAD_VERIFICATION_POLL_INTERVAL = "uploadVerificationPollInterval";

    public static final String PENDING_AUTOMATED_MESSAGES = "pendingAutomatedMessages";

    public static final String PENDING_MANUAL_MESSAGES = "pendingManualMessages";

    public static final String PENDING_MESSAGE = "pendingMessage";

    public static final String PENDING_AUTOMATED_MESSAGE = "pendingAutomatedMessage";

    public static final String PENDING_MANUAL_MESSAGE = "pendingManualMessage";

    public static final String PACKAGE_LOCATION_LIST = "packageLocationList";

    public static final String PACKAGE_LOCATION = "packageLocation";

    public static final String CREATED_PACKAGE_ID = "createdPackageId";

    public static final String CREATE_PACKAGE_CALL_STATUS = "createPackageCallStatus";

    public static final String PACKAGE_CREATION_VERIFY_STATUS = "packageCreationVerifyStatus";

    // Report generation variables
    public static final String REPORT_GENERATION_INITIATION_STATUS = "reportGenerationInitiationStatus";

    public static final String POLL_REPORT_STATUS = "pollReportStatus";

    public static final String REPORT_GENERATION_CALLING_UPDATE_STATUS = "reportGenerationCallingUpdateStatus";

    public static final String REPORT_TYPE_VAR = "reportType";

    public static final String REPORT_JOB_ID_VAR = "reportJobId";

    public static final String REPORT_SERVICE_POLL_INTERVAL_VAR = "reportServicePollInterval";

    public static final String REPORT_GENERATION_RECOVERABLE_ERROR_MESSAGE = "reportGenRecoverableErrorMessage";

    // Package download variables

    public static final String TR_CREATE_STATUS = "trCreateStatus";

    public static final String PACKAGE_TRANSFER_STATE = "packageTransferState";

    public static final String STAGING_TRANSFER_STATUS = "stagingTransferStatus";

    public static final String DOWNLOAD_VERIFICATION_RETRY_PERIOD = "downloadVerificationRetryPeriod";

    public static final String MOVE_VERIFICATION_POLL_PERIOD = "moveVerificationPollPeriod";

    public static final String DTF_PACKAGE_TEMP_NAME_PREFIX = "DTF_PKG";

    // Process flow decision types
    public static final Integer ERROR_WITH_RETRY = -10;

    public static final Integer ERROR = -1;

    public static final Integer INCOMPLETE = 0;

    public static final Integer NO = -1;

    public static final Integer COMPLETE = 1;

    public static final Integer OK = 1;

    public static final Integer NOTHING_TO_DO = 10;

    public static final Integer FILE_NOT_FOUND_ON_SERVER = 10;

    public static final Integer RGS_ERROR_STATUS = -2;

    // Activiti multi-instance variables
    public static final String NR_OF_INSTANCES = "nrOfInstances";

    public static final String NR_OF_COMPLETED_INSTANCES = "nrOfCompletedInstances";

    public static final String NR_OF_ACTIVE_INSTANCES = "nrOfActiveInstances";

    public static final String LOOP_COUNTER = "loopCounter";

    public static final String ERROR_COUNT = "recoverableErrorCount";

    // Constants for transfer items
    public static final String IN_NOTIF_PKG = "MDNOTIFXML";

    public static final String IN_NOTIF_IMG_PKG = "MDNOTIFIMG";

    public static final String IN_NOTIF_PDF_PKG = "MDNOTIFPDF";

    public static final String IN_IRREG_PKG = "MDIRREGXML";

    public static final String IN_MADRID_FEES = "MDFEES";

    public static final String IN_FINANCE_FEES = "MDRECFEEMFBK";

    public static final String OUT_FINANCE_FEES = "MDRECFEEMDIS";

    public static final String OUT_DAILY_PKG = "MDOFF2IBPKG";

    // Staging directory variables

    public static final String REMOTE_FILE_NAME = "remoteFileName";

    public static final String TRANSFER_ITEM = "transferItem";

    public static final String INPUT_FOLDER = "inputFolder";

    public static final String OUTPUT_FOLDER = "outputFolder";

    public static final String FAIL_FOLDER = "failFolder";

    // For global business error handling
    public static final String ERR_MSG_OBJECT_VAR = "errorMsgObject";

    public static final String SUBPROCESS_STATUS_VAR = "subprocessStatusVariable";

    public static final String RUNNING_ERROR_MESSAGE = "runningErrorMessage";

    // Transfer request variable names
    public static final String TRANSFER_REQ_ID_VAR = "transferRequestId";

    public static final String TRANSFER_REQUEST_LOG = "transferRequestItemLog";

    // Service Fault Severity

    public static final Integer SERVICE_FAULT_SEVERITY_THRESHOLD = -99;

    // RegEx
    public static final String YYYY_MM_REGEX_SEGMENT = "20[0-9][0-9][0-9][0-9]";

}
