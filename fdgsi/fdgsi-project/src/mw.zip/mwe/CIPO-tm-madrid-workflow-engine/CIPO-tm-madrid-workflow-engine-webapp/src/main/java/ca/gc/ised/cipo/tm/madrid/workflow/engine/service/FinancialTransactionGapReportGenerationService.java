package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This interface describes a service that will handle delegated task actions from the
 * {@code generate-financial-gap-reports.bpmn} process flow, which is a call activity in
 * {@code process_hague_financial_transactions_from_wipo.bpmn}
 *
 * @author J. Greene
 *
 */
public interface FinancialTransactionGapReportGenerationService extends BusinessErrorHandler {

    /**
     * Service task method responsible for sending an email notification that the gap report was created.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void sendGapReportNotification(DelegateExecution execution);

}
