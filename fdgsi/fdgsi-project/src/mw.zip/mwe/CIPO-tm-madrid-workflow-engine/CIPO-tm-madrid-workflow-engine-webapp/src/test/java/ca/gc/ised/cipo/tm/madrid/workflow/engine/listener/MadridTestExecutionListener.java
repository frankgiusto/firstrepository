package ca.gc.ised.cipo.tm.madrid.workflow.engine.listener;

import java.lang.invoke.MethodHandles;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * An ExecutionListener that logs the flow of all components that implement it.
 *
 * This should be injected into the Spring configuration using the key "testExecutionListener"
 *
 * @author hamerg
 *
 */
public class MadridTestExecutionListener implements ExecutionListener {

    protected static final Logger LOG = LoggerFactory.getLogger( MethodHandles.lookup().lookupClass() );

    /**
     *
     */
    private static final long serialVersionUID = -22470408211199215L;


    @Override
    public void notify( DelegateExecution delegateExecution ) {

        LOG.debug( "Componenet: id=" + delegateExecution.getCurrentActivityId() + " -> Event="
            + delegateExecution.getEventName() );

    }

}
