package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import java.lang.invoke.MethodHandles;

import org.activiti.engine.impl.pvm.delegate.ActivityExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.ProcessMadridDesignationService;

/**
 * Implementation for ProcessMadridDesignation service. Responsible for delegating to Madrid Transaction service for the
 * processing of madrid designation. This is a service task that makes a web service call
 *
 * Please see Activiti BPMN workflow ca\gc\ised\cipo\tm\madrid\diagram\automated\SUC_2.1_ProcessIRDesignation.bpmn for
 * details
 *
 * @author sagary
 *
 */
@Service("processMadridDesignationService")
public class ProcessMadridDesignationServiceImpl implements ProcessMadridDesignationService {

    private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Override
    public void processMaridDesignation(final ActivityExecution activityExecution) throws Exception {
        LOG.debug("About to Process Madrid Designation");
        // get the execution ID - the ID needs to be part of web service call (part of parameters)
        String executionId = activityExecution.getId();
        LOG.debug("Execution ID to be sent to Process Madrid Designation web service " + executionId);
        // for now just print it on console for testing purposes
        System.out.println("Execution ID " + executionId);
        // When the web service is ready, call the web service - or for now just simulate a long running task
        // pass in the activity execution ID
        Thread.sleep(5000L);
    }
}
