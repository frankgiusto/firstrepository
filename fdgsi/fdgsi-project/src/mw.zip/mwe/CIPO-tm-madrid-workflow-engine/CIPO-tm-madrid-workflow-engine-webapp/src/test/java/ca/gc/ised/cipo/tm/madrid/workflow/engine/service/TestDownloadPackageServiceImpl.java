package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR_WITH_RETRY;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_TRANSFER_STATE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.STAGING_TRANSFER_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TR_CREATE_STATUS;

import java.io.Serializable;
import java.util.UUID;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;

/**
 * A test service class to be used for unit testing the download_hague_package_from_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
public class TestDownloadPackageServiceImpl extends TestBusinessErrorHandlerImpl
    implements DownloadPackageService, Serializable {

    private static final long serialVersionUID = 1305521924288845600L;

    protected String createTransferRequestReturnObject;

    protected Integer verifyPackageTransferReturnObject;

    protected Integer stagingTransferReturnObject;

    protected Integer loopIterationThrowError;

    protected Integer loopIterationIncomplete;

    protected Integer trCreateStatus;

    /** {@inheritDoc} */
    @Override
    public void createTransferRequest(DelegateExecution execution) {
        String out;
        if (StringUtils.isBlank(getCreateTransferRequestReturnObject())) {
            out = UUID.randomUUID().toString();
        } else {
            out = getCreateTransferRequestReturnObject();
        }
        execution.setVariable(TR_CREATE_STATUS, getTrCreateStatus());
        execution.setVariable("transferRequestId", out);
        System.out.println("[[createTransferRequest]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void verifyPackageTransfer(DelegateExecution execution) {
        Integer packageTransferState = getVerifyPackageTransferReturnObject();
        // To test looping - set value for next iteration.
        if (packageTransferState.equals(ERROR_WITH_RETRY)) {
            setVerifyPackageTransferReturnObject(COMPLETE);
            setStagingTransferReturnObject(COMPLETE);

        }
        if (packageTransferState.equals(INCOMPLETE)) {
            if (loopIterationIncomplete-- == 0) {
                setVerifyPackageTransferReturnObject(COMPLETE);
                setStagingTransferReturnObject(COMPLETE);
            }
        }
        if (packageTransferState.equals(ERROR)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with package transfer.");
        }
        execution.setVariable(PACKAGE_TRANSFER_STATE, packageTransferState);
        System.out.println("[[verifyPackageTransfer]]:" + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void queueTransferPackageToOutputFolder(DelegateExecution execution) {
        System.out.println("[[transferPackageToOutputFolder]]:" + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void verifyPackageMove(DelegateExecution execution) {
        Integer status = execution.getVariable(STAGING_TRANSFER_STATUS, Integer.class);
        if (status != null && status.equals(INCOMPLETE)) {
            execution.setVariable(STAGING_TRANSFER_STATUS, COMPLETE);
        } else {
            execution.setVariable(STAGING_TRANSFER_STATUS, getStagingTransferReturnObject());
            if (getStagingTransferReturnObject().equals(ERROR)) {
                execution.setVariable(ERR_MSG_OBJECT_VAR,
                    "Excecution ID: [" + execution.getId() + "] Process Definition ID: ["
                        + execution.getProcessDefinitionId() + "] Business key: [" + execution.getProcessBusinessKey()
                        + "] Process Instance: [" + execution.getProcessInstanceId() + "] Current activity id: ["
                        + execution.getCurrentActivityId() + "] Current activity name: ["
                        + execution.getCurrentActivityName() + "] --> Error with package transfer to output folder.");
            }
        }
        System.out.println("[[verifyPackageMove]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void sendTransferConfirmation(DelegateExecution execution) {
        System.out.println("[[confirmTransfer]]: " + execution.getVariables());
    }

    /**
     * @return the verifyPackageTransferReturnObject
     */
    public Integer getVerifyPackageTransferReturnObject() {
        return verifyPackageTransferReturnObject;
    }

    /**
     * @param verifyPackageTransferReturnObject the verifyPackageTransferReturnObject to set
     */
    public void setVerifyPackageTransferReturnObject(Integer verifyPackageTransferReturnObject) {
        this.verifyPackageTransferReturnObject = verifyPackageTransferReturnObject;
    }

    /**
     * @return the createTransferRequestReturnObject
     */
    public String getCreateTransferRequestReturnObject() {
        return createTransferRequestReturnObject;
    }

    /**
     * @param createTransferRequestReturnObject the createTransferRequestReturnObject to set
     */
    public void setCreateTransferRequestReturnObject(String createTransferRequestReturnObject) {
        this.createTransferRequestReturnObject = createTransferRequestReturnObject;
    }

    /**
     * @return the loopIterationThrowError
     */
    public Integer getLoopIterationThrowError() {
        return loopIterationThrowError;
    }

    /**
     * @param loopIterationThrowError the loopIterationThrowError to set
     */
    public void setLoopIterationThrowError(Integer loopIterationThrowError) {
        this.loopIterationThrowError = loopIterationThrowError;
    }

    /**
     * @return the loopIterationIncomplete
     */
    public Integer getLoopIterationIncomplete() {
        return loopIterationIncomplete;
    }

    /**
     * @param loopIterationIncomplete the loopIterationIncomplete to set
     */
    public void setLoopIterationIncomplete(Integer loopIterationIncomplete) {
        this.loopIterationIncomplete = loopIterationIncomplete;
    }

    /**
     * @return the stagingTransferReturnObject
     */
    public Integer getStagingTransferReturnObject() {
        return stagingTransferReturnObject;
    }

    /**
     * @return the trCreateStatus
     */
    public Integer getTrCreateStatus() {
        return trCreateStatus;
    }

    /**
     * @param trCreateStatus the trCreateStatus to set
     */
    public void setTrCreateStatus(Integer trCreateStatus) {
        this.trCreateStatus = trCreateStatus;
    }

    /**
     * @param stagingTransferReturnObject the stagingTransferReturnObject to set
     */
    public void setStagingTransferReturnObject(Integer stagingTransferReturnObject) {
        this.stagingTransferReturnObject = stagingTransferReturnObject;
    }

    @Override
    public void waitOneMinute(DelegateExecution execution) {
        try {
            Thread.sleep(1000); // Actually a second, this is JUnit testing...
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
