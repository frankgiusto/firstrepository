package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Domain object to contain fields for starting a WIPO package persistence job.
 *
 * @author J. Greene
 *
 */
public final class IncomingPackagePersistJob extends MweJob implements Serializable {

    private static final long serialVersionUID = -1547143570035441275L;

    private Integer numberOfReattempts;

    private String inputFolder;

    private String failFolder;

    private String transferItem;

    private String persistVerificationPollPeriod;

    private String finPkgDownloadFileFullPath;

    /**
     * @return the persistVerificationPollPeriod
     */
    public String getPersistVerificationPollPeriod() {
        return persistVerificationPollPeriod;
    }

    /**
     * @param persistVerificationPollPeriod the persistVerificationPollPeriod to set
     */
    public void setPersistVerificationPollPeriod(String persistVerificationPollPeriod) {
        this.persistVerificationPollPeriod = persistVerificationPollPeriod;
    }

    /**
     * @return the numberOfReattempts
     */
    public Integer getNumberOfReattempts() {
        return numberOfReattempts;
    }

    /**
     * @param numberOfReattempts the numberOfReattempts to set
     */
    public void setNumberOfReattempts(Integer numberOfReattempts) {
        this.numberOfReattempts = numberOfReattempts;
    }

    /**
     * @return the inputFolder
     */
    public String getInputFolder() {
        return inputFolder;
    }

    /**
     * @param inputFolder the inputFolder to set
     */
    public void setInputFolder(String inputFolder) {
        this.inputFolder = inputFolder;
    }

    /**
     * @return the failFolder
     */
    public String getFailFolder() {
        return failFolder;
    }

    /**
     * @param failFolder the failFolder to set
     */
    public void setFailFolder(String failFolder) {
        this.failFolder = failFolder;
    }

    /**
     * @return the transferItem
     */
    public String getTransferItem() {
        return transferItem;
    }

    /**
     * @param transferItem the transferItem to set
     */
    public void setTransferItem(String transferItem) {
        this.transferItem = transferItem;
    }

    /**
     * @return the finPkgDownloadFileFullPath
     */
    public String getFinPkgDownloadFileFullPath() {
        return finPkgDownloadFileFullPath;
    }

    /**
     * @param finPkgDownloadFileFullPath the finPkgDownloadFileFullPath to set
     */
    public void setFinPkgDownloadFileFullPath(String finPkgDownloadFileFullPath) {
        this.finPkgDownloadFileFullPath = finPkgDownloadFileFullPath;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        // @formatter:off
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("inputFolder", inputFolder)
            .append("failFolder", failFolder)
            .append("numberOfReattempts", numberOfReattempts)
            .append("transferItem", transferItem)
            .append("persistVerificationPollPeriod", persistVerificationPollPeriod)
            .append("finPkgDownloadFileFullPath", finPkgDownloadFileFullPath)
            .append("processInstanceId", processInstanceId)
            .toString();
        // @formatter:on
    }

}
