/*
 * Copyright (c) 2018 CIPO Created on May 22, 2018
 */
package ca.gc.ised.cipo.tm.madrid.mock;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.BindingProvider;

import ca.gc.ic.cipo.schema.ws.common.ServiceFaultDetails;
import ca.gc.ic.cipo.tm.mts.AutomatedProcessResponse;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.AutomaticProcessingPairCriteria;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.CheckForNotificationsRequest;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskIdsResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskResponse;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.ExistingMarkRequest;
import ca.gc.ic.cipo.tm.mts.ExistingMarkResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessResponse;
import ca.gc.ic.cipo.tm.mts.ManualProcessingCriteria;
import ca.gc.ic.cipo.tm.mts.OfficeToIbProcessActions;
import ca.gc.ic.cipo.tm.mts.OfficeToIbTransactionResponse;
import ca.gc.ic.cipo.tm.mts.ProcessActionCategoryType;
import ca.gc.ic.cipo.tm.mts.ProcessActionsMeta;
import ca.gc.ic.cipo.tm.mts.ReportTypeEnum;
import ca.gc.ic.cipo.tm.mts.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.AbstractServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.MtsServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * A mock object to simulate calls to MTS.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public class MtsServiceManagerMock extends AbstractServiceManager implements MtsServiceManager {

	private static List<TransactionDetail> transactions = new ArrayList<TransactionDetail>();

	/**
	 * Constructor.
	 */
	public MtsServiceManagerMock() {
		// No op
	}

	/**
	 * Used for setting test data for a given JUnit test.
	 *
	 * @param testTransactions
	 *            the list of transactions to test with
	 */
	public static void setUprocessedTransactions(List<TransactionDetail> testTransactions) {
		transactions.clear();
		transactions.addAll(testTransactions);
	}

	@Override
	public List<TransactionDetail> getTransactionList(TransactionCriteria transactionCriteria)
			throws BpmnWebServiceCallException {

		// If one of the transactions has an ID of -1 throw a CipoServiceFault.
		// This is a error test condition
		for (TransactionDetail transaction : transactions) {
			if (transaction.getTransactionId().intValue() == -1) {
				ServiceFaultDetails sfd = new ServiceFaultDetails();
				sfd.setComponentAcronym("tm");
				sfd.setEnErrorMsg("Test error");
				sfd.setFrErrorMsg("Erreur de test");
				sfd.setReasonCode(1);
				sfd.setReturnCode(-99);
				sfd.setServiceName("mts");
				CIPOServiceFault csf = new CIPOServiceFault("Test Error", sfd);
				throw new BpmnWebServiceCallException(csf.getMessage(), csf);
			}
		}

		// Success test - return pre-populated list
		return transactions;
	}

	@Override
	public AutomatedProcessResponse processAutomatedTransaction(AutomaticProcessingCriteria apc)
			throws BpmnWebServiceCallException {

		AutomatedProcessResponse apr = new AutomatedProcessResponse();

		// For tests a negative Transactions ID will return an error
		if (apc.getTransactionRequest().getIrTranId().intValue() == -2) {
			ServiceFaultDetails sfd = new ServiceFaultDetails();
			sfd.setComponentAcronym("TM");
			sfd.setServiceName("MTS");
			sfd.setReturnCode(-1);
			sfd.setReasonCode(1);
			sfd.setEnErrorMsg("Test error");
			sfd.setFrErrorMsg("FR-Test error");

			BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(sfd);

			BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::TEST_CIPOServiceFault::");
			serviceException.setBusinessErrorLogItem(businessErrorLogItem);
			throw serviceException;

		} else if (apc.getTransactionRequest().getIrTranId().intValue() == 2000) {
			// Create a need for a Notification user task
			ConsoleTaskResponse ctr = new ConsoleTaskResponse();
			ctr.setAuthorityId("ADMIN");
			ctr.setConsoleTaskId(new BigDecimal(20));

			apr.getConsoleTaskBag().add(ctr);
		}

		return apr;
	}

	@Override
	public AutomatedProcessResponse processAutomatedTransactionPair(AutomaticProcessingPairCriteria appc)
			throws BpmnWebServiceCallException {

		AutomatedProcessResponse apr = new AutomatedProcessResponse();

		// For tests a negative Transactions ID will return an error
		if (appc.getTransactionMeta().getIrTranId().intValue() == -2) {
			ServiceFaultDetails sfd = new ServiceFaultDetails();
			sfd.setComponentAcronym("TM");
			sfd.setServiceName("MTS");
			sfd.setReturnCode(-1);
			sfd.setReasonCode(1);
			sfd.setEnErrorMsg("Test error");
			sfd.setFrErrorMsg("FR-Test error");

			BusinessErrorLogItem businessErrorLogItem = buildBusinessErrorLogItem(sfd);

			BpmnWebServiceCallException serviceException = new BpmnWebServiceCallException("::TEST_CIPOServiceFault::");
			serviceException.setBusinessErrorLogItem(businessErrorLogItem);
			throw serviceException;

		} else if (appc.getTransactionMeta().getIrTranId().intValue() == 5005) {
			ConsoleTaskResponse ctr = new ConsoleTaskResponse();
			ctr.setAuthorityId("ADMIN");
			ctr.setConsoleTaskId(new BigDecimal(25));
			apr.getConsoleTaskBag().add(ctr);
		}

		return apr;
	}

	@Override
	public ManualProcessResponse processManualTransaction(ManualProcessingCriteria criteria)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateConsoleTaskStatus(BigDecimal consoleTaskId, ConsoleTaskStatusType statusType)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateConsoleTaskReference(String userTaskId, BigDecimal consoleTaskId)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub

	}

	@Override
	public ExistingMarkResponse checkExistingMark(ExistingMarkRequest req) throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OfficeToIbProcessActions getOfficeToIbProcessActions(ProcessActionCategoryType type)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OfficeToIbTransactionResponse createOfficeToIbTransaction(ProcessActionsMeta processActionsMeta)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ManualProcessResponse createOfficeToIbManualTask(ProcessActionsMeta processActionsMeta)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected BindingProvider getBindingProvider() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String generateReport(BigDecimal transactionId, ReportTypeEnum reportTypeCode)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigDecimal generateReportNotification(String reportJobId, BigDecimal transactionId,
			ReportTypeEnum reportTypeCode) throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConsoleTaskIdsResponse checkForNotifications(CheckForNotificationsRequest req)
			throws BpmnWebServiceCallException {
		// TODO Auto-generated method stub
		return null;
	}
}