package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_UPLOAD_PACKAGE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR_WITH_RETRY;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NUMBER_OF_REATTEMPTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_CREATION_VERIFY_STATUS;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Test service class for the package_madrid_transactions_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
public class TestPackageOutgoingTransactionsServiceImpl extends TestBusinessErrorHandlerImpl
    implements PackageOutgoingTransactionsService {

    private Integer createUploadPackageStatusReturnObject;

    private Integer packageCreationVerifyStatusReturnObject;

    /** {@inheritDoc} */
    @Override
    public void createUploadTransactionPackage(DelegateExecution execution) {
        if (getCreateUploadPackageStatusReturnObject() != null) {
            execution.setVariableLocal(CREATE_UPLOAD_PACKAGE_STATUS, getCreateUploadPackageStatusReturnObject());
        }
        if (getCreateUploadPackageStatusReturnObject().equals(ERROR)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with creating the package.");
        }
        if (getCreateUploadPackageStatusReturnObject().equals(ERROR_WITH_RETRY)) {
            // Allows the process to loop only once.
            setCreateUploadPackageStatusReturnObject(COMPLETE);
        }
        System.out.println("[[createUploadTransactionPackage]] " + execution.getVariables());

        if (getPackageCreationVerifyStatusReturnObject() != null) {
            execution.setVariableLocal(PACKAGE_CREATION_VERIFY_STATUS, getPackageCreationVerifyStatusReturnObject());
        }
    }

    @Override
    public void verifyPackageCreated(DelegateExecution execution) {
        Integer out = null;

        if (getPackageCreationVerifyStatusReturnObject() != null) {
            out = getPackageCreationVerifyStatusReturnObject();
            execution.setVariableLocal(PACKAGE_CREATION_VERIFY_STATUS, out);
        }

        if (out.equals(INCOMPLETE)) {
            setPackageCreationVerifyStatusReturnObject(ERROR);
        }
        if (out.equals(ERROR)) {
            execution.setVariableLocal(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with package persist.");
        }
        if (out.equals(ERROR_WITH_RETRY)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error (with retry) with package persist.");
            Integer loopCounter = execution.getVariableLocal("loopCounter", Integer.class);
            String loopReattemptCounter = "numberOfReattemptsLocal" + loopCounter;
            Integer numReattemptsLocal = execution.getVariableLocal(loopReattemptCounter, Integer.class);
            if (numReattemptsLocal == null) {
                Integer numReattempts = execution.getVariable(NUMBER_OF_REATTEMPTS, Integer.class);
                execution.setVariableLocal(loopReattemptCounter, numReattempts);
                numReattemptsLocal = new Integer(numReattempts);
            }

            if (numReattemptsLocal > 0) {
                execution.setVariableLocal(PACKAGE_CREATION_VERIFY_STATUS, ERROR_WITH_RETRY);
                execution.setVariableLocal(loopReattemptCounter, --numReattemptsLocal);
            } else {
                execution.setVariableLocal(PACKAGE_CREATION_VERIFY_STATUS, COMPLETE);
            }
        }
        System.out.println("[[verifyPackageCreated]]: " + execution.getVariablesLocal());
    }

    /**
     * @return the createUploadPackageStatusReturnObject
     */
    public Integer getCreateUploadPackageStatusReturnObject() {
        return createUploadPackageStatusReturnObject;
    }

    /**
     * @param createUploadPackageStatusReturnObject the createUploadPackageStatusReturnObject to set
     */
    public void setCreateUploadPackageStatusReturnObject(Integer createUploadPackageStatusReturnObject) {
        this.createUploadPackageStatusReturnObject = createUploadPackageStatusReturnObject;
    }

    public Integer getPackageCreationVerifyStatusReturnObject() {
        return packageCreationVerifyStatusReturnObject;
    }

    public void setPackageCreationVerifyStatusReturnObject(Integer packageCreationVerifyStatusReturnObject) {
        this.packageCreationVerifyStatusReturnObject = packageCreationVerifyStatusReturnObject;
    }

}
