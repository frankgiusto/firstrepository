package ca.gc.ised.cipo.tm.madrid.workflow.engine.web.rest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.DelegationState;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;

@Controller
public class MadridWorkflowStatusController {

	private static final Logger log = LoggerFactory.getLogger(MadridWorkflowStatusController.class);

	@Autowired
	private RuntimeService runtimeService;

	@Autowired
	private ProcessEngine processEngine;

	@Autowired
	private TaskService taskService;

	@Autowired
	private RequestMappingHandlerMapping requestMappingHandlerMapping;

	@RequestMapping(value = "/wfState", method = RequestMethod.GET)
	public String wfState(ModelMap model) {
		return this.mweStatus(model);
	}

	@RequestMapping(value = "/mweStatus", method = RequestMethod.GET)
	public String mweStatus(ModelMap model) {

		log.debug("Call to: mweStatus()");

		List<Task> tasks = taskService.createTaskQuery().orderByTaskCreateTime().desc().list();

		List<DisplayTask> displayTasks = new ArrayList<DisplayTask>(tasks.size());
		for (Task task : tasks) {
			displayTasks.add(new DisplayTask(task));
		}

		model.addAttribute("activeTasks", displayTasks);

		List<ProcessInstance> procList = runtimeService.createProcessInstanceQuery().includeProcessVariables().list();
		model.addAttribute("procList", procList);

		return "/view/workflowStatus.jsp";

	}

	@RequestMapping(value = "/displayTask", method = RequestMethod.GET)
	public String displayTask(@RequestParam(required = true, value = "taskId") String taskId, ModelMap model) {

		log.debug("Call to: mweStatus()");

		Task task = taskService.createTaskQuery().taskId(taskId).includeTaskLocalVariables().singleResult();

		model.addAttribute("displayTask", task);

		this.getProcessChain(task);

		return "/view/displayTask.jsp";

	}

	private List<String> getProcessChain(Task task) {

		ArrayList<String> chain = new ArrayList<String>();

		String executionId = task.getExecutionId();

		while (executionId != null) {

			chain.add(executionId);

			Execution exec = runtimeService.createExecutionQuery().executionId(executionId).singleResult();
			ProcessInstance proc = runtimeService.createProcessInstanceQuery()
					.processInstanceId(task.getProcessInstanceId()).singleResult();

			if (exec != null && exec.getParentId() != null) {
				executionId = exec.getParentId();
			} else {
				executionId = null;
			}

		}

		return chain;
	}

	/**
	 * A 'decorated' version of the Acitivti Task for display on the status
	 * page.
	 *
	 * @author hamerg
	 *
	 */
	public class DisplayTask implements Task {

		protected Task task;

		public DisplayTask(Task task) {
			this.task = task;
		}

		public String getGroup() {

			String groupString = "";

			List<IdentityLink> idents = taskService.getIdentityLinksForTask(this.getId());

			if (idents != null && !idents.isEmpty()) {
				IdentityLink idLink = idents.get(0);
				groupString = idLink.getGroupId();
			}

			return groupString;
		}

		public String getTransactionId() {

			String transId = "";

			return transId;
		}

		@Override
		public String getId() {
			return task.getId();
		}

		@Override
		public String getName() {

			String typeValue = (String) processEngine.getTaskService().getVariablesLocal(task.getId())
					.get(ProcessFlowConstants.CONSOLE_TASK_TYPE);

			if (typeValue == null) {
				typeValue = task.getName().toLowerCase();
			}

			return typeValue;
		}

		@Override
		public String getAssignee() {
			return task.getAssignee();
		}

		@Override
		public Date getCreateTime() {
			return task.getCreateTime();
		}

		@Override
		public String getDescription() {
			return task.getDescription();
		}

		@Override
		public int getPriority() {
			return task.getPriority();
		}

		@Override
		public String getOwner() {
			return task.getOwner();
		}

		@Override
		public String getProcessInstanceId() {
			return task.getProcessInstanceId();
		}

		@Override
		public String getExecutionId() {
			return task.getExecutionId();
		}

		@Override
		public String getProcessDefinitionId() {
			return task.getProcessDefinitionId();
		}

		@Override
		public String getTaskDefinitionKey() {
			return task.getTaskDefinitionKey();
		}

		@Override
		public Date getDueDate() {
			return task.getDueDate();
		}

		@Override
		public String getCategory() {
			return task.getCategory();
		}

		@Override
		public String getParentTaskId() {
			return task.getParentTaskId();
		}

		@Override
		public String getTenantId() {
			return task.getTenantId();
		}

		@Override
		public String getFormKey() {
			return task.getFormKey();
		}

		@Override
		public Map<String, Object> getTaskLocalVariables() {
			return task.getTaskLocalVariables();
		}

		@Override
		public Map<String, Object> getProcessVariables() {
			return task.getProcessVariables();
		}

		@Override
		public void setName(String name) {
		}

		@Override
		public void setLocalizedName(String name) {
		}

		@Override
		public void setDescription(String description) {
		}

		@Override
		public void setLocalizedDescription(String description) {
		}

		@Override
		public void setPriority(int priority) {
		}

		@Override
		public void setOwner(String owner) {
		}

		@Override
		public void setAssignee(String assignee) {
		}

		@Override
		public DelegationState getDelegationState() {
			return null;
		}

		@Override
		public void setDelegationState(DelegationState delegationState) {
		}

		@Override
		public void setDueDate(Date dueDate) {
		}

		@Override
		public void setCategory(String category) {
		}

		@Override
		public void delegate(String userId) {
		}

		@Override
		public void setParentTaskId(String parentTaskId) {
		}

		@Override
		public void setTenantId(String tenantId) {
		}

		@Override
		public void setFormKey(String formKey) {
		}

		@Override
		public boolean isSuspended() {
			return false;
		}

	}

}
