package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Describes a service that will perform common actions related to report generation within the various flows.
 *
 * @author J. Greene
 *
 */
public interface ReportGenerationService extends BusinessErrorHandler {

    /**
     * Initiates the report generation for the report provided by the process variable {@code reportType}.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void initiateReportGeneration(DelegateExecution execution);

    /**
     * Polls the report service for completion.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void pollReportService(DelegateExecution execution);

    /**
     * Updates the calling service with the result of the report generation.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void updateCallingService(DelegateExecution execution);

    /**
     * Handles the situation where the report generation service returns an ERROR status when polling for report
     * completion.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void handleRgsErrorStatus(DelegateExecution execution);

    /**
     * Evaluates the error severity of a potential error resulting from the callback WS call.
     *
     * @param execution The Activiti context object that holds information and variables related to the current process
     *            execution.
     */
    void evaluateCallbackErrorSeverity(DelegateExecution execution);

}
