package ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;

import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;

/**
 * A transfer request creator strategy for creating a DTF transfer request for a Madrid financial package (monthly)
 *
 * @author J. Greene
 *
 */
public class MonthlyFinanceTransferRequestCreator extends AbstractWipoInboundTransferRequestCreator {

    /** {@inheritDoc} */
    @Override
    protected String getDtfSite() {
        return getEnvironment().getProperty("mwe.dtf.madrid.site.name.secure");
    }

    /** {@inheritDoc} */
    @Override
    protected void setParamCollection(List<TransferRequestParamXsd> paramList, DelegateExecution execution,
                                      DownloadLogItem lastDownloadLogItem) {
        TransferRequestParamXsd remoteDirParam = new TransferRequestParamXsd();
        remoteDirParam.setParameterCode(ParamNameCode.REMOTE_DIR.codeValue());
        remoteDirParam.setParameterValue(getRemoteDir());
        paramList.add(remoteDirParam);

        String fileNameParameter = execution.getVariable(ProcessFlowConstants.REMOTE_FILE_NAME, String.class);

        if (StringUtils.isBlank(fileNameParameter)) {
            fileNameParameter = determineNextFileName(lastDownloadLogItem);
        }

        TransferRequestParamXsd fileParam = new TransferRequestParamXsd();
        fileParam.setParameterCode(ParamNameCode.FILE_NAME.codeValue());
        fileParam.setParameterValue(fileNameParameter);
        paramList.add(fileParam);
    }

    /*
     * Determine the next file name by adding a month to the last file successfully downloaded (or bump year if month is
     * 12).
     */
    protected String determineNextFileName(DownloadLogItem lastDownloadLogItem) {
        String nextFileName = null;
        String currentFileName = lastDownloadLogItem.getFileName();

        // Filename format should be CA-ID-yyyymm.xml.
        Integer yearInt = Integer.parseInt(currentFileName.substring(6, 10));
        Integer monthInt = Integer.parseInt(currentFileName.substring(10, 12));

        if (monthInt > 11) {
            monthInt = 1;
            yearInt++;
        } else {
            monthInt++;
        }

        nextFileName = currentFileName.substring(0, 6) + yearInt + StringUtils.leftPad(monthInt.toString(), 2, "0")
            + currentFileName.substring(12);

        return nextFileName;
    }

    protected String getRemoteDir() {
        return getEnvironment().getProperty("mwe.dtf.madrid.finance.ftp.dir");
    }

}
