/*
 * Copyright (c) 2018 CIPO Created on Aug 2, 2018
 */
package ca.gc.ised.cipo.tm.madrid.mock;

import ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender;

/**
 *
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public class MailSenderMock extends JndiSimpleMailSender {

    /*
     * (non-Javadoc)
     * 
     * @see ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender#send(java.lang.String, java.lang.String, java.lang.String,
     * java.lang.String)
     */
    @Override
    public void send(String from, String to, String subject, String text) {
        // TODO Auto-generated method stub
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender#send(java.lang.String, java.lang.String, java.lang.String,
     * java.lang.String, java.lang.Exception)
     */
    @Override
    public void send(String from, String to, String subject, String text, Exception exception) {
        // TODO Auto-generated method stub
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender#send(java.lang.String, java.lang.String[], java.lang.String,
     * java.lang.String)
     */
    @Override
    public void send(String from, String[] tos, String subject, String text) {
        // TODO Auto-generated method stub
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender#send(java.lang.String, java.lang.String[], java.lang.String,
     * java.lang.String, java.lang.Exception)
     */
    @Override
    public void send(String from, String[] tos, String subject, String text, Exception exception) {
        // TODO Auto-generated method stub
    }

}
