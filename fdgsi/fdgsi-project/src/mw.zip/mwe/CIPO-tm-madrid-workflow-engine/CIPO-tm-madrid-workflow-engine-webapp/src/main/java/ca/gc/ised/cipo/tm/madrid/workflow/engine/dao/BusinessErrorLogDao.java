package ca.gc.ised.cipo.tm.madrid.workflow.engine.dao;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;

/**
 * A simple DAO object to control logging of business (workflow-related) errors for internal purposes.
 *
 * @author J. Greene
 *
 */
@Repository
public class BusinessErrorLogDao {

    protected static final Logger LOG = LoggerFactory.getLogger(BusinessErrorLogDao.class);

    protected NamedParameterJdbcTemplate jdbcTemplate;

    public void insertBusinessErrorLogEntry(BusinessErrorLogItem businessErrorLogItem) {
        try {
            // @formatter:off
	        String sql =
	            "insert into mwe_business_error_log "
	             + "(business_error_log_id, "
	             + " message, "
	             + " return_code, "
	             + " reason_code, "
	             + " component_acronym, "
	             + " service_name, "
	             + " error_message_en, "
	             + " error_message_fr, "
	             + " process_instance_id, "
	             + " process_definition_name)"
	             + " values("
	             + "         :businessErrorLogId, "
	             + "         :message, "
	             + "         :returnCode, "
                 + businessErrorLogItem.getReasonCode() + ", "              // + "         :reasonCode, "
                 + "'" + businessErrorLogItem.getComponentAcronym() + "', " // + "         :componentAcronym, "
                 + "'" + businessErrorLogItem.getServiceName() + "', "      // + "         :serviceName, "
	             + "         :errorMessageEn, "
	             + "         :errorMessageFr, "
	             + "         :processInstanceId, "
	             + "         :processDefinitionName)";
			// @formatter:on

            GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
            SqlParameterSource businessErrorItemNamedParameters = new BeanPropertySqlParameterSource(
                businessErrorLogItem);

            jdbcTemplate.update(sql, businessErrorItemNamedParameters, keyHolder,
                new String[]{"business_error_log_id"});

            businessErrorLogItem.setBusinessErrorLogId(keyHolder.getKey().longValue());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void purgeOldBusinessErrorLogEntries(int olderThanNumberOfDays) {
        Date cutoffDate = DateUtils.addDays(new Date(), -(olderThanNumberOfDays + 1));
        String sql = "delete from mwe_business_error_log where created_date < :cutoffDate";
        int i = jdbcTemplate.update(sql, Collections.singletonMap("cutoffDate", cutoffDate));
        LOG.debug("Removed " + i + " old log instance(s) from more than " + olderThanNumberOfDays + " days ago.");
    }

    public List<BusinessErrorLogItem> getBusinessErrorLogItemsByFields(BusinessErrorLogItem item) {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from mwe_business_error_log where ");

        Map<String, Object> paramMap = new HashMap<>();
        int whereCount = 0;

        if (item.getBusinessErrorLogId() != null) {
            sql.append("business_error_log_id = :businessErrorLogId");
            whereCount++;
            paramMap.put("businessErrorLogId", item.getBusinessErrorLogId());
        }
        if (item.getReturnCode() != null) {
            if (whereCount > 0) {
                sql.append(" and ");
            }
            sql.append("return_code = :returnCode");
            whereCount++;
            paramMap.put("returnCode", item.getReturnCode());
        }
        if (item.getReasonCode() != null) {
            if (whereCount > 0) {
                sql.append(" and ");
            }
            sql.append("reason_code = :reasonCode");
            whereCount++;
            paramMap.put("reasonCode", item.getReasonCode());
        }
        if (StringUtils.isNotBlank(item.getComponentAcronym())) {
            if (whereCount > 0) {
                sql.append(" and ");
            }
            sql.append("lower(component_acronym) = :componentAcronym");
            whereCount++;
            paramMap.put("componentAcronym", item.getComponentAcronym().toLowerCase());
        }
        if (StringUtils.isNotBlank(item.getServiceName())) {
            if (whereCount > 0) {
                sql.append(" and ");
            }
            sql.append("lower(service_name) = :serviceName");
            whereCount++;
            paramMap.put("serviceName", item.getServiceName().toLowerCase());
        }
        if (item.getProcessInstanceId() != null) {
            if (whereCount > 0) {
                sql.append(" and ");
            }
            sql.append("process_instance_id = :processInstanceId");
            whereCount++;
            paramMap.put("processInstanceId", item.getProcessInstanceId());
        }

        return jdbcTemplate.query(sql.toString(), paramMap,
            BeanPropertyRowMapper.newInstance(BusinessErrorLogItem.class));
    }

    public List<BusinessErrorLogItem> getAllBusinessErrorLogItems() {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from mwe_business_error_log");

        return jdbcTemplate.query(sql.toString(), BeanPropertyRowMapper.newInstance(BusinessErrorLogItem.class));
    }

    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

}
