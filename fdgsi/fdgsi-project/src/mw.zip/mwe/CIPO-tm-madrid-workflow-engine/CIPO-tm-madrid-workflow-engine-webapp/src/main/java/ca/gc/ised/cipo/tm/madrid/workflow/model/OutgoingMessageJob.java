package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Domain object to contain fields for starting an outgoing message job (messages from Office to IB).
 *
 * @author J. Greene
 *
 */
public final class OutgoingMessageJob extends MweJob implements Serializable {

    private static final long serialVersionUID = 1628585904777632324L;

    private String transferItem;

    private String outputFolder;

    private String failFolder;

    private String creationVerificationPollInterval;

    private String uploadVerificationPollInterval;

    private Integer numberOfReattempts;

    /**
     * @return the transferItem
     */
    public String getTransferItem() {
        return transferItem;
    }

    /**
     * @param transferItem the transferItem to set
     */
    public void setTransferItem(String transferItem) {
        this.transferItem = transferItem;
    }

    /**
     * @return the outputFolder
     */
    public String getOutputFolder() {
        return outputFolder;
    }

    /**
     * @param outputFolder the outputFolder to set
     */
    public void setOutputFolder(String outputFolder) {
        this.outputFolder = outputFolder;
    }

    /**
     * @return the failFolder
     */
    public String getFailFolder() {
        return failFolder;
    }

    /**
     * @param failFolder the failFolder to set
     */
    public void setFailFolder(String failFolder) {
        this.failFolder = failFolder;
    }

    /**
     * @return the creationVerificationPollInterval
     */
    public String getCreationVerificationPollInterval() {
        return creationVerificationPollInterval;
    }

    /**
     * @param creationVerificationPollInterval the creationVerificationPollInterval to set
     */
    public void setCreationVerificationPollInterval(String creationVerificationPollInterval) {
        this.creationVerificationPollInterval = creationVerificationPollInterval;
    }

    /**
     * @return the uploadVerificationPollInterval
     */
    public String getUploadVerificationPollInterval() {
        return uploadVerificationPollInterval;
    }

    /**
     * @param uploadVerificationPollInterval the uploadVerificationPollInterval to set
     */
    public void setUploadVerificationPollInterval(String uploadVerificationPollInterval) {
        this.uploadVerificationPollInterval = uploadVerificationPollInterval;
    }

    /**
     * @return the numberOfReattempts
     */
    public Integer getNumberOfReattempts() {
        return numberOfReattempts;
    }

    /**
     * @param numberOfReattempts the numberOfReattempts to set
     */
    public void setNumberOfReattempts(Integer numberOfReattempts) {
        this.numberOfReattempts = numberOfReattempts;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        // @formatter:off
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("numberOfReattempts", numberOfReattempts)
            .append("processInstanceId", processInstanceId)
            .append("transferItem", transferItem)
            .append("outputFolder", outputFolder)
            .append("failFolder", failFolder)
            .append("creationVerificationPollInterval", creationVerificationPollInterval)
            .append("uploadVerificationPollInterval", uploadVerificationPollInterval)
            .toString();
        // @formatter:on
    }
}
