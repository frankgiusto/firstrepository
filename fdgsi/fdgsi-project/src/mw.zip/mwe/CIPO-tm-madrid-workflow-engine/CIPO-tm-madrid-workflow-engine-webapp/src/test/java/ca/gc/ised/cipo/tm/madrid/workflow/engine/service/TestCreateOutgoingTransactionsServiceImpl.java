package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_AND_PERSIST_AUTOMATED_MESSAGE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_AND_PERSIST_MANUAL_MESSAGE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FETCH_PENDING_AUTOMATED_MSG_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FETCH_PENDING_MANUAL_MSG_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_AUTOMATED_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_AUTOMATED_MESSAGES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_MANUAL_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PENDING_MANUAL_MESSAGES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RUNNING_ERROR_MESSAGE;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * A test service class to be used for unit testing the create_madrid_transactions_to_wipo.bpmn process flow.
 *
 * @author J. Greene
 *
 */
public class TestCreateOutgoingTransactionsServiceImpl extends TestBusinessErrorHandlerImpl
    implements CreateOutgoingTransactionsService {

    private Integer pendingAutomatedMessageStatusReturnObject;

    private Integer pendingManualMessageStatusReturnObject;

    private Integer createAutomatedMessagesStatusReturnObject;

    private Integer createManualMessagesStatusReturnObject;

    private Integer recoverableConditionReturnObject;

    private List<String> pendingAutomatedMessageCollection;

    private List<String> pendingManualMessageCollection;

    /** {@inheritDoc} */
    @Override
    public void getOfficeToIbAutomaticProcessActions(DelegateExecution execution) {
        if (getPendingAutomatedMessageStatusReturnObject() != null) {
            execution.setVariable(FETCH_PENDING_AUTOMATED_MSG_STATUS, getPendingAutomatedMessageStatusReturnObject());
        }
        if (getPendingAutomatedMessageCollection() != null) {
            execution.setVariable(PENDING_AUTOMATED_MESSAGES, getPendingAutomatedMessageCollection());
        }
        if (getPendingAutomatedMessageStatusReturnObject().equals(ERROR)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with fetching pending messages.");
        }

        System.out.println("[[getPendingTransactionCollection]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void getOfficeToIbManualProcessActions(DelegateExecution execution) {
        if (getPendingManualMessageStatusReturnObject() != null) {
            execution.setVariable(FETCH_PENDING_MANUAL_MSG_STATUS, getPendingManualMessageStatusReturnObject());
        }
        if (getPendingManualMessageCollection() != null) {
            execution.setVariable(PENDING_MANUAL_MESSAGES, getPendingManualMessageCollection());
        }
        if (getPendingManualMessageStatusReturnObject().equals(ERROR)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with fetching pending messages.");
        }

        System.out.println("[[getPendingTransactionCollection]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void createOfficeToIbTransaction(DelegateExecution execution) {
        if (getCreateAutomatedMessagesStatusReturnObject() != null) {
            execution.setVariableLocal(CREATE_AND_PERSIST_AUTOMATED_MESSAGE_STATUS,
                getCreateAutomatedMessagesStatusReturnObject());
        }
        if (getCreateAutomatedMessagesStatusReturnObject().equals(ERROR)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with importing message.");
        }
        System.out.println("[[createAndPersistTransaction]] EXTERNAL: " + execution.getVariables());
        System.out.println("[[createAndPersistTransaction]] LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void createOfficeToIbManualTask(DelegateExecution execution) {
        if (getCreateManualMessagesStatusReturnObject() != null) {
            execution.setVariableLocal(CREATE_AND_PERSIST_MANUAL_MESSAGE_STATUS,
                getCreateManualMessagesStatusReturnObject());
        }
        if (getCreateManualMessagesStatusReturnObject().equals(ERROR)) {
            execution.setVariable(ERR_MSG_OBJECT_VAR,
                "Excecution ID: " + execution.getId() + " - Error with importing message.");
        }
        System.out.println("[[createAndPersistTransaction]] EXTERNAL: " + execution.getVariables());
        System.out.println("[[createAndPersistTransaction]] LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void handleAutomatedIterativeError(DelegateExecution execution) {
        if (getRecoverableConditionReturnObject() != null) {
            execution.setVariableLocal(RECOVERABLE_ERROR_CONDITION, getRecoverableConditionReturnObject());
        }
        String pendingMessage = execution.getVariableLocal(PENDING_AUTOMATED_MESSAGE, String.class);
        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
        if (runningErrorMessageList == null) {
            runningErrorMessageList = new ArrayList<>();
        }
        runningErrorMessageList.add("Blah blah blah " + pendingMessage);
        execution.setVariable(RUNNING_ERROR_MESSAGE, runningErrorMessageList);
        System.out.println("[[handleIterativeError]] EXTERNAL: " + execution.getVariables());
        System.out.println("[[handleIterativeError]] LOCAL: " + execution.getVariablesLocal());
    }

    /** {@inheritDoc} */
    @Override
    public void handleManualIterativeError(DelegateExecution execution) {
        if (getRecoverableConditionReturnObject() != null) {
            execution.setVariableLocal(RECOVERABLE_ERROR_CONDITION, getRecoverableConditionReturnObject());
        }
        String pendingMessage = execution.getVariableLocal(PENDING_MANUAL_MESSAGE, String.class);
        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
        if (runningErrorMessageList == null) {
            runningErrorMessageList = new ArrayList<>();
        }
        runningErrorMessageList.add("Blah blah blah " + pendingMessage);
        execution.setVariable(RUNNING_ERROR_MESSAGE, runningErrorMessageList);
        System.out.println("[[handleIterativeError]] EXTERNAL: " + execution.getVariables());
        System.out.println("[[handleIterativeError]] LOCAL: " + execution.getVariablesLocal());
    }

    public Integer getPendingAutomatedMessageStatusReturnObject() {
        return pendingAutomatedMessageStatusReturnObject;
    }

    public void setPendingAutomatedMessageStatusReturnObject(Integer pendingAutomatedMessageStatusReturnObject) {
        this.pendingAutomatedMessageStatusReturnObject = pendingAutomatedMessageStatusReturnObject;
    }

    public Integer getPendingManualMessageStatusReturnObject() {
        return pendingManualMessageStatusReturnObject;
    }

    public void setPendingManualMessageStatusReturnObject(Integer pendingManualMessageStatusReturnObject) {
        this.pendingManualMessageStatusReturnObject = pendingManualMessageStatusReturnObject;
    }

    public Integer getCreateAutomatedMessagesStatusReturnObject() {
        return createAutomatedMessagesStatusReturnObject;
    }

    public void setCreateAutomatedMessagesStatusReturnObject(Integer createAutomatedMessagesStatusReturnObject) {
        this.createAutomatedMessagesStatusReturnObject = createAutomatedMessagesStatusReturnObject;
    }

    public Integer getCreateManualMessagesStatusReturnObject() {
        return createManualMessagesStatusReturnObject;
    }

    public void setCreateManualMessagesStatusReturnObject(Integer createManualMessagesStatusReturnObject) {
        this.createManualMessagesStatusReturnObject = createManualMessagesStatusReturnObject;
    }

    public List<String> getPendingAutomatedMessageCollection() {
        return pendingAutomatedMessageCollection;
    }

    public void setPendingAutomatedMessageCollection(List<String> pendingAutomatedMessageCollection) {
        this.pendingAutomatedMessageCollection = pendingAutomatedMessageCollection;
    }

    public List<String> getPendingManualMessageCollection() {
        return pendingManualMessageCollection;
    }

    public void setPendingManualMessageCollection(List<String> pendingManualMessageCollection) {
        this.pendingManualMessageCollection = pendingManualMessageCollection;
    }

    public Integer getRecoverableConditionReturnObject() {
        return recoverableConditionReturnObject;
    }

    public void setRecoverableConditionReturnObject(Integer recoverableConditionReturnObject) {
        this.recoverableConditionReturnObject = recoverableConditionReturnObject;
    }

}
