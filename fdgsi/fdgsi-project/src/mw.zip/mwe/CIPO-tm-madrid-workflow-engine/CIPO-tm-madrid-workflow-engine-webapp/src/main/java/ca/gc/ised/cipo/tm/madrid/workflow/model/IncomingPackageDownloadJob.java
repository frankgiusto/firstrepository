package ca.gc.ised.cipo.tm.madrid.workflow.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Domain object to contain fields for starting a Madrid WIPO package download job.
 *
 * @author J. Greene
 *
 */
public final class IncomingPackageDownloadJob extends MweJob implements Serializable {

    private static final long serialVersionUID = -1652540189943583526L;

    private String transferItem;

    private String outputFolder;

    private String downloadVerificationRetryPeriod;

    private String moveVerificationPollPeriod;

    private String remoteFileName;

    /**
     * @return the transferItem
     */
    public String getTransferItem() {
        return transferItem;
    }

    /**
     * @param transferItem the transferItem to set
     */
    public void setTransferItem(String transferItem) {
        this.transferItem = transferItem;
    }

    /**
     * @return the outputFolder
     */
    public String getOutputFolder() {
        return outputFolder;
    }

    /**
     * @param outputFolder the outputFolder to set
     */
    public void setOutputFolder(String outputFolder) {
        this.outputFolder = outputFolder;
    }

    /**
     * @return the downloadVerificationRetryPeriod
     */
    public String getDownloadVerificationRetryPeriod() {
        return downloadVerificationRetryPeriod;
    }

    /**
     * @param downloadVerificationRetryPeriod the downloadVerificationRetryPeriod to set using ISO 8601 durations.
     */
    public void setDownloadVerificationRetryPeriod(String downloadVerificationRetryPeriod) {
        this.downloadVerificationRetryPeriod = downloadVerificationRetryPeriod;
    }

    /**
     * @return the remoteFileName
     */
    public String getRemoteFileName() {
        return remoteFileName;
    }

    /**
     * @param remoteFileName the remoteFileName to set
     */
    public void setRemoteFileName(String fileName) {
        this.remoteFileName = fileName;
    }

    /**
     * @return the moveVerificationPollPeriod
     */
    public String getMoveVerificationPollPeriod() {
        return moveVerificationPollPeriod;
    }

    /**
     * @param moveVerificationPollPeriod the moveVerificationPollPeriod to set
     */
    public void setMoveVerificationPollPeriod(String moveVerificationRetryPeriod) {
        this.moveVerificationPollPeriod = moveVerificationRetryPeriod;
    }

    @Override
    public String toString() {
     // @formatter:off
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
            .append("transferItem", transferItem)
            .append("outputFolder", outputFolder)
            .append("downloadVerificationRetryPeriod", downloadVerificationRetryPeriod)
            .append("moveVerificationPollPeriod", moveVerificationPollPeriod)
            .append("remoteFileName", remoteFileName)
            .append("processInstanceId", processInstanceId)
            .toString();
     // @formatter:on
    }
}
