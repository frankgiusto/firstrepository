CREATE TABLE MWE_DOWNLOAD_LOG 
  ( 
     DL_LOG_ID       NUMBER NOT NULL AUTO_INCREMENT PRIMARY KEY, 
     XFER_REQ_ID     VARCHAR2(50 char) NOT NULL, 
     PACKAGE_TYPE    VARCHAR2(50 char) NOT NULL,
     FILE_NAME       VARCHAR2(255 char), 
     TARGET_LOCATION VARCHAR2(2000 char) NOT NULL,
     FILE_REGEX      VARCHAR2(255 char), 
     DL_STATUS       VARCHAR2(20 char), 
     DL_DATE         TIMESTAMP,
     MSG             VARCHAR2(513 char),
     XFER_REQ_DATE   TIMESTAMP
  ); 
  
CREATE TABLE MWE_BUSINESS_ERROR_LOG 
    (
        BUSINESS_ERROR_LOG_ID       NUMBER NOT NULL AUTO_INCREMENT PRIMARY KEY, 
        MESSAGE                     VARCHAR2(512 char), 
        RETURN_CODE                 INTEGER, 
        REASON_CODE                 INTEGER, 
        COMPONENT_ACRONYM           VARCHAR2(10 char), 
        SERVICE_NAME                VARCHAR2(50 char),
        ERROR_MESSAGE_EN            VARCHAR2(512 char), 
        ERROR_MESSAGE_FR            VARCHAR2(512 char), 
        PROCESS_INSTANCE_ID         VARCHAR2(64 char),
        PROCESS_DEFINITION_NAME     VARCHAR2(256 char),
        CREATED_DATE                TIMESTAMP DEFAULT SYSDATE
    );  