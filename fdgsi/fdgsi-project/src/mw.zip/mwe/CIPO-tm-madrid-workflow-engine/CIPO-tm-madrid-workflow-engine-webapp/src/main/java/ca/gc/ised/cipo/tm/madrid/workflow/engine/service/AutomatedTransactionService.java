/*
 * Copyright (c) 2018 CIPO Created on May 16, 2018
 */
package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * This workflow service is responsible for handling SOAP calls and other process flow requirements when handling
 * automated Madrid ST.96 transactions.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public interface AutomatedTransactionService {

    /**
     * Gets the collection of pending automated transactions from MTS. This collection is set as a variable on the
     * Activiti process flow instance this method was called from.
     * <p>
     * {@code [ 1]} - OK<br/>
     * {@code [-1]} - Error<br/>
     * </p>
     *
     * @param execution the Activiti context of the process flow instance this method is called from
     */
    void getPendingAutomatedTransactionCollection(DelegateExecution execution);

    /**
     * Gets the collection of pending automated transaction pairs from MTS. This collection is set as a variable on the
     * Activiti process flow instance this method was called from.
     * <p>
     * {@code [ 1]} - OK<br/>
     * {@code [-1]} - Error<br/>
     * </p>
     *
     * @param execution the Activiti context of the process flow instance this method is called from
     */
    void getPendingAutomatedPairsCollection(DelegateExecution execution);

    /**
     * Calls the appropriate web service to process a given automated transaction. The result will be set on the
     * Activiti process as a variable.
     * <p>
     * {@code [ 1]} - OK<br/>
     * {@code [-1]} - Error<br/>
     * </p>
     *
     * @param execution the Activiti context of the process flow instance this method is called from
     */
    void processAutomatedTransaction(DelegateExecution execution);

    /**
     * Calls the appropriate web service to process a given automated pair of transactions. The result will be set on
     * the Activiti process as a variable.
     * <p>
     * {@code [ 1]} - OK<br/>
     * {@code [-1]} - Error<br/>
     * </p>
     *
     * @param execution the Activiti context of the process flow instance this method is called from
     */
    void processAutomatedPair(DelegateExecution execution);

    /**
     * Handles errors that are recoverable - move on to next item in the collection.
     * <p>
     * {@code [ 1]} - OK<br/>
     * {@code [-1]} - Error<br/>
     * </p>
     *
     * @param execution the Activiti context of the process flow instance this method is called from
     */
    public void handleIterativeError(DelegateExecution execution);
}
