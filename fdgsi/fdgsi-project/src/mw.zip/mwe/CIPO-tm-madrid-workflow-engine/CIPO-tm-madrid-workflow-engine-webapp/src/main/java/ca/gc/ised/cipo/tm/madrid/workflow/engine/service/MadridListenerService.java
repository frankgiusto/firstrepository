package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;

public interface MadridListenerService {

	void syncConsoleTask(DelegateTask delegateTask);

	void setTransactionDescValues(DelegateExecution execution);

	void promoteErrorMessageToCallingExecution(DelegateExecution execution);

	void createUnknownTransactionTypeError(DelegateExecution execution);

	void debugUserTask(DelegateTask delegateTask);

	void debugListener(DelegateExecution execution);

}
