/*
 * Copyright (c) 2018 CIPO Created on Aug 22, 2018
 */
package ca.gc.ised.cipo.tm.madrid.mock;

/**
 * This is the interface for the HFS service manager.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
// MFS-CLEAN-SPR5 public class MfsServiceManagerMock implements
// MfsServiceManager {
public class MfsServiceManagerMock {

	// MFS-CLEAN-SPR5 /**
	// * Default constructor.
	// */
	// public MfsServiceManagerMock() {
	// // no op
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// *
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#processAccountReceivableDistributionAsync(
	// * org.activiti.engine.delegate.DelegateExecution)
	// */
	// @Override
	// public void processAccountReceivableDistributionAsync(DelegateExecution
	// executionContext)
	// throws BpmnWebServiceCallException {
	//
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#parsePackageToTransactions(java.math.
	// * BigDecimal, java.lang.String)
	// */
	// @Override
	// public void parsePackageToTransactions(BigDecimal packageId, String
	// transferItem)
	// throws BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#getNotificationEmailContent()
	// */
	// @Override
	// public EmailMessageDetails getNotificationEmailContent() throws
	// BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// *
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#reconcileFinancialTransaction(java.math.
	// * BigDecimal)
	// */
	// @Override
	// public void reconcileFinancialTransaction(BigDecimal transactionId)
	// throws BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// *
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#generateReconciledFeeDistribution(java.
	// * math.BigDecimal)
	// */
	// @Override
	// public ReconciledOutput generateReconciledFeeDistribution(BigDecimal
	// packageId) throws BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// *
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#updateApplicationsFinancialStatus(java.
	// * math.BigDecimal)
	// */
	// @Override
	// public void updateApplicationsFinancialStatus(BigDecimal transactionId)
	// throws BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#generateReport(java.math.BigDecimal,
	// * ca.gc.ic.cipo.schema.id.ihfs.ReportTypeEnum)
	// */
	// @Override
	// public String generateReport(BigDecimal packageId, ReportTypeEnum
	// reportTypeCode)
	// throws BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	// return null;
	// }
	//
	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// ca.gc.ised.cipo.id.hague.workflow.engine.service.mgr.HfsServiceManager#generateReportNotification(java.lang.
	// * String, java.math.BigDecimal,
	// ca.gc.ic.cipo.schema.id.ihfs.ReportTypeEnum)
	// */
	// @Override
	// public BigDecimal generateReportNotification(String reportJobId,
	// BigDecimal packageId,
	// ReportTypeEnum reportTypeCode)
	// throws BpmnWebServiceCallException {
	// // TODO Auto-generated method stub
	// return null;
	// }

}
