package ca.gc.ised.cipo.tm.madrid.workflow.engine.util;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import org.junit.Before;

/**
 * Test class for the {@link MweWorkflowUtil}.
 *
 *
 * @author J. Greene
 *
 */
public class MweWorkflowUtilTest {

    @Before
    public void init() throws IOException {
        // File baseDir = new File(baseDirString);
        // FileUtils.deleteDirectory(baseDir);
    }

    /**
     * This test is to be done manually as there's no way to guarantee the directory structure of an automated system
     * (i.e. Bamboo).
     */
    // @Test
    public void moveFileStreamTest() {

        String baseDirString = "c:/temp/filetests/";

        javax.activation.DataSource source = new FileDataSource("c:/temp/test.zip");
        DataHandler handler = new DataHandler(source);

        String outputFolder = baseDirString.concat("testoutput01");

        try {
            MweWorkflowUtil.moveFileStream(handler, outputFolder, "99999.zip");
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Should have no exceptions.");
        }

        outputFolder = baseDirString.concat("testoutput03/");
        try {
            MweWorkflowUtil.moveFileStream(handler, outputFolder, "99999.zip");
        } catch (Exception ex) {
            ex.printStackTrace();
            fail("Should have no exceptions.");
        }

        outputFolder = "//prod.prv/Shared";
        try {
            MweWorkflowUtil.moveFileStream(handler, outputFolder, "99999.zip");
            fail("Should have exceptions.");
        } catch (Exception ex) {
            System.out.println("Hurray!");
            ex.printStackTrace();
        }
    }

    /**
     * This test is to be done manually as there's no way to guarantee the directory structure of an automated system
     * (i.e. Bamboo).
     */
    // @Test
    public void moveFileTest() {
        String origFileString = "c:/temp/filetests/testinput01/test.zip";
        String outputFolder = "c:/temp/filetests/testoutput99";

        File origFile = new File(origFileString);

        try {
            MweWorkflowUtil.moveFile(origFile, outputFolder);
            assertFalse(origFile.exists());
        } catch (IOException ex) {
            ex.printStackTrace();
            fail("Should have no exceptions.");
        }
    }

    /**
     * This test is to be done manually as there's no way to guarantee the directory structure of an automated system
     * (i.e. Bamboo).
     */
    // @Test
    @SuppressWarnings("unused")
    public void unzipToFolderTest() throws IOException {
        String packageFileName = "C:/Temp/IntegrationTests/DTF_PKG_0000.zip";

        List<String> entryNames = MweWorkflowUtil.unzipToFolder(packageFileName, "C:/Temp/IntegrationTests/hold");

    }

    /**
     * This test is to be done manually as there's no way to guarantee the directory structure of an automated system
     * (i.e. Bamboo).
     */
    // @Test
    @SuppressWarnings("unused")
    public void unzipInPlaceTest() throws IOException {
        Path packageFilePath = Paths.get("C:/Temp/IntegrationTests/DTF_PKG_0001.zip");

        List<String> entryNames = MweWorkflowUtil.unzipInPlace(packageFilePath);

    }

    //@formatter:off
    /*
    @Test
    public void testTransformPackageUnitToImportPackage() {
        System.out.println("###############################################");
        System.out.println("### testTransformPackageUnitToImportPackage ###");
        System.out.println("###############################################");

        String transferItem;
        String xmlFileLoc = "/blah/blah/blah/blah.xml";
        String imgFileLoc = "/blah/blah/blah/blah.";

        // Weekly bulletin
        PackageUnit bulletinUnit = new PackageUnit();
        bulletinUnit.setImgFileName(imgFileLoc);
        bulletinUnit.setXmlFileName(xmlFileLoc);
        transferItem = IN_HAGUE_PKG;

        ImportPackage i1 = MweWorkflowUtil.transformPackageUnitToImportPackage(bulletinUnit, transferItem);
        for (ImportPackageType importPackageType : i1.getImportPackageRequest()) {
            if (importPackageType.getPackageLocation().equals(xmlFileLoc)) {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.HAGUE_WEEKLY_BULLETIN_XML);
            } else {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.HAGUE_WEEKLY_BULLETIN_IMG);
            }
        }

        transferItem = IN_HAGUE_IMG_PKG;

        ImportPackage i2 = MweWorkflowUtil.transformPackageUnitToImportPackage(bulletinUnit, transferItem);
        for (ImportPackageType importPackageType : i2.getImportPackageRequest()) {
            if (importPackageType.getPackageLocation().equals(xmlFileLoc)) {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.HAGUE_WEEKLY_BULLETIN_XML);
            } else {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.HAGUE_WEEKLY_BULLETIN_IMG);
            }
        }

        // Confidential copies
        PackageUnit ccUnit = new PackageUnit();
        ccUnit.setImgFileName(imgFileLoc);
        ccUnit.setXmlFileName(xmlFileLoc);
        transferItem = IN_HAGUE_SECURE_PKG;

        ImportPackage i3 = MweWorkflowUtil.transformPackageUnitToImportPackage(ccUnit, transferItem);
        for (ImportPackageType importPackageType : i3.getImportPackageRequest()) {
            if (importPackageType.getPackageLocation().equals(xmlFileLoc)) {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.CONFIDENTIAL_COPY_XML);
            } else {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.CONFIDENTIAL_COPY_IMG);
            }
        }

        transferItem = IN_HAGUE_SECURE_IMG_PKG;

        ImportPackage i4 = MweWorkflowUtil.transformPackageUnitToImportPackage(ccUnit, transferItem);
        for (ImportPackageType importPackageType : i4.getImportPackageRequest()) {
            if (importPackageType.getPackageLocation().equals(xmlFileLoc)) {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.CONFIDENTIAL_COPY_XML);
            } else {
                assertEquals(importPackageType.getPackageType(), PackageTypeEnum.CONFIDENTIAL_COPY_IMG);
            }
        }

        // WIPO Fees
        PackageUnit wipoFeesUnit = new PackageUnit();
        ccUnit.setXmlFileName(xmlFileLoc);
        transferItem = IN_HAGUE_FEES;

        ImportPackage i5 = MweWorkflowUtil.transformPackageUnitToImportPackage(wipoFeesUnit, transferItem);
        assertTrue(i5.getImportPackageRequest().size() == 1);
        assertEquals(i5.getImportPackageRequest().get(0).getPackageType(), PackageTypeEnum.HAGUE_FINANCE_PACKAGE);

        // CIPO Feedback
        PackageUnit cipoFeesUnit = new PackageUnit();
        ccUnit.setXmlFileName(xmlFileLoc);
        transferItem = IN_FINANCE_FEES;

        ImportPackage i6 = MweWorkflowUtil.transformPackageUnitToImportPackage(cipoFeesUnit, transferItem);
        assertTrue(i6.getImportPackageRequest().size() == 1);
        assertEquals(i6.getImportPackageRequest().get(0).getPackageType(), PackageTypeEnum.IFMS_FINACIAL_FEEDBACK);

    }
     */
    //@formatter:on
}
