package ca.gc.ised.cipo.tm.madrid.clients;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.lang.invoke.MethodHandles;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.userprofile.client.UserProfileServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityCategory;
import ca.gc.ic.cipo.tm.userprofile.schema.AuthorityType;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileService;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;
import ca.gc.ised.cipo.tm.madrid.conf.MadridWorkflowTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TUPSUserProfileService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { MadridWorkflowTestConfiguration.class })
public class MadridUserProfileServiceTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@Value("${mwe.tups.service.endpoint.hostname}")
	private String authHostUrl;

	@Autowired
	private TUPSUserProfileService port;

	@Test
	public void testHeartbeat() throws InterruptedException {

		LOG.debug("----- Start testHeartbeat()");

		HeartbeatResponseType res = null;

		try {
			res = port.getHeartbeat();
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
		}

		assertNotNull(res);

		assertNotNull(res.getNodeName());

		LOG.debug("Status: " + res.getStatus());
		LOG.debug("IP: " + res.getIpAddress());
		LOG.debug("Node: " + res.getNodeName());

		LOG.debug("----- End testHeartbeat()");
	}

	// @Test
	public void testUserProfile() throws InterruptedException {

		LOG.debug("----- Start testUserProfile()");

		UserProfileService client = UserProfileServiceFactory.createClient("http://cipodev.ic.gc.ca");

		UserProfileType req = new UserProfileType();

		// We test against the user_id from the AUTHORITIES table, not the LDAP
		// user name.
		req.setAuthorityId("GOYETTI2");
		req.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.toString());

		UserProfile res = null;

		try {

			res = client.getUserProfile(req);

		} catch (Exception e) {
			LOG.error("Error : " + e.getMessage());
		}

		assertNotNull(res);

		assertNotNull(res.getName());

		int i = 0;

		LOG.debug("Name: " + res.getName());
		List<UserAuthority> auths = res.getUserAuthorities();
		String roles = "[";
		for (UserAuthority userAuthority : auths) {
			roles += userAuthority.getIntlAuthorityRole() + ", ";
		}

		LOG.debug("Auth: " + roles + "]");

		LOG.debug("----- End testUserProfile()");
	}

	@Test
	public void testMissingUserProfile() throws InterruptedException {

		LOG.debug("----- Start testMissingUserProfile()");

		UserProfileType req = new UserProfileType();
		req.setUserName("missinguser");

		UserProfile res = null;

		try {
			res = port.getUserProfile(req);
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
		}

		assertNull(res);

		LOG.debug("----- End testMissingUserProfile()");
	}

	@Test
	public void testListAuthorityTypes() throws InterruptedException {

		LOG.debug("----- Start testListAuthorityTypes()");

		List<String> res = null;

		try {
			res = port.listAuthorityTypes(AuthorityType.INTL_AUTHORITY_ROLE);
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
		}

		assertNotNull(res);

		assertFalse(res.isEmpty());

		for (String authType : res) {
			LOG.debug("Auth: " + authType);
		}

		LOG.debug("----- End testListAuthorityTypes()");
	}

}