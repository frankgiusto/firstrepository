package ca.gc.ised.cipo.tm.madrid.workflow.engine.service;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FEE_STATUS_UPDATE_INDICATOR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FEE_STATUS_UPDATE_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FETCH_FIN_SYSTEM_PACKAGE_TRANSACTION_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_STATUS_UPDATE_TRANSACTION_DETAIL;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FIN_STATUS_UPDATE_TRANSACTION_DETAIL_LIST;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RECOVERABLE_ERROR_CONDITION;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.RUNNING_ERROR_MESSAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.UPDATE_FEE_STATUS_STATUS;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;

/**
 * Test service implementation for the {@code update_financial_fee_status.bpmn} workflow delegate execution service.
 *
 * @author J. Greene
 *
 */
public class TestFinancialTransactionUpdateFeeStatusServiceImpl extends TestBusinessErrorHandlerImpl
    implements FinancialTransactionUpdateFeeStatusService {

    protected Integer fetchFinSystemPackageTransactionsStatusReturnObject;

    protected Integer updateFeeStatusStatusReturnObject;

    protected Integer recoverableConditionReturnObject;

    protected Integer feeStatusUpdateStatusReturnObject;

    /** {@inheritDoc} */
    @Override
    public void getUpdatedFinancialTransactions(DelegateExecution execution) {
        if (getFetchFinSystemPackageTransactionsStatusReturnObject() != null) {
            execution.setVariable(FETCH_FIN_SYSTEM_PACKAGE_TRANSACTION_STATUS,
                getFetchFinSystemPackageTransactionsStatusReturnObject());
        }
        List<Integer> packageIdList = new ArrayList<>();
        packageIdList.add(1000000);
        packageIdList.add(1000001);
        execution.setVariable(FIN_STATUS_UPDATE_TRANSACTION_DETAIL_LIST, packageIdList);
        System.out.println("[[getUpdatedFinancialTransactions]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void updateReconciledFeeTransaction(DelegateExecution execution) {
        if (getUpdateFeeStatusStatusReturnObject() != null) {
            execution.setVariable(UPDATE_FEE_STATUS_STATUS, getUpdateFeeStatusStatusReturnObject());
        }
        System.out.println("[[updateReconciledFeeTransaction]]: " + execution.getVariables());
    }

    /** {@inheritDoc} */
    @Override
    public void handleIterativeError(DelegateExecution execution) {
        execution.setVariable(FEE_STATUS_UPDATE_INDICATOR, Boolean.FALSE);
        if (getRecoverableConditionReturnObject() != null) {
            execution.setVariable(RECOVERABLE_ERROR_CONDITION, getRecoverableConditionReturnObject());
        }

        Integer packageId = execution.getVariableLocal(FIN_STATUS_UPDATE_TRANSACTION_DETAIL, Integer.class);
        @SuppressWarnings("unchecked")
        List<String> runningErrorMessageList = execution.getVariable(RUNNING_ERROR_MESSAGE, List.class);
        if (runningErrorMessageList == null) {
            runningErrorMessageList = new ArrayList<>();
        }
        runningErrorMessageList.add("Blah blah blah " + packageId);
        execution.setVariable(RUNNING_ERROR_MESSAGE, runningErrorMessageList);

        System.out.println("[[handleIterativeError]]: " + execution.getVariables());
    }

    /**
     * @return the fetchFinSystemPackageTransactionsStatusReturnObject
     */
    public Integer getFetchFinSystemPackageTransactionsStatusReturnObject() {
        return fetchFinSystemPackageTransactionsStatusReturnObject;
    }

    /**
     * @param fetchFinSystemPackageTransactionsStatusReturnObject the
     *            fetchFinSystemPackageTransactionsStatusReturnObject to set
     */
    public void setFetchFinSystemPackageTransactionsStatusReturnObject(Integer fetchFinSystemPackageTransactionsStatusReturnObject) {
        this.fetchFinSystemPackageTransactionsStatusReturnObject = fetchFinSystemPackageTransactionsStatusReturnObject;
    }

    /** {@inheritDoc} */
    @Override
    public void updatePkgStatusPostFeeUpdate(DelegateExecution execution) {
        if (getFeeStatusUpdateStatusReturnObject() != null) {
            execution.setVariable(FEE_STATUS_UPDATE_STATUS, getFeeStatusUpdateStatusReturnObject());
        }
        System.out.println("[[updatePkgStatusPostFeeUpdate]]: " + execution.getVariables());
    }

    /**
     * @return the updateFeeStatusStatusReturnObject
     */
    public Integer getUpdateFeeStatusStatusReturnObject() {
        return updateFeeStatusStatusReturnObject;
    }

    /**
     * @param updateFeeStatusStatusReturnObject the updateFeeStatusStatusReturnObject to set
     */
    public void setUpdateFeeStatusStatusReturnObject(Integer updateFeeStatusStatusReturnObject) {
        this.updateFeeStatusStatusReturnObject = updateFeeStatusStatusReturnObject;
    }

    /**
     * @return the recoverableConditionReturnObject
     */
    public Integer getRecoverableConditionReturnObject() {
        return recoverableConditionReturnObject;
    }

    /**
     * @param recoverableConditionReturnObject the recoverableConditionReturnObject to set
     */
    public void setRecoverableConditionReturnObject(Integer recoverableConditionReturnObject) {
        this.recoverableConditionReturnObject = recoverableConditionReturnObject;
    }

    /**
     * @return the feeStatusUpdateStatusReturnObject
     */
    public Integer getFeeStatusUpdateStatusReturnObject() {
        return feeStatusUpdateStatusReturnObject;
    }

    /**
     * @param feeStatusUpdateStatusReturnObject the feeStatusUpdateStatusReturnObject to set
     */
    public void setFeeStatusUpdateStatusReturnObject(Integer feeStatusUpdateStatusReturnObject) {
        this.feeStatusUpdateStatusReturnObject = feeStatusUpdateStatusReturnObject;
    }

}
