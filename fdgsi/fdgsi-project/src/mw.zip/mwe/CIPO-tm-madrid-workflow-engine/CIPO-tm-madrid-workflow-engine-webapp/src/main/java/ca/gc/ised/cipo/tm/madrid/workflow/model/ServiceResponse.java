package ca.gc.ised.cipo.tm.madrid.workflow.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceResponse {

    @JsonProperty("success")
    private boolean success;

    @JsonProperty(value = "exceptionMessage", defaultValue = "")
    private String exceptionMessage;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getExceptionMessage() {
        if (success) {
            exceptionMessage = "";
        }
        return exceptionMessage;
    }

    public void setExceptionMessage(String exceptionMessage) {
        this.exceptionMessage = exceptionMessage;
    }

    @Override
    public String toString() {
        return "ServiceResponse [success=" + success + ", exceptionMessage=" + exceptionMessage + "]";
    }

}
