package ca.gc.ised.cipo.tm.madrid.diagram;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR_WITH_RETRY;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.FAIL_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_FINANCE_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_MADRID_FEES;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NOTHING_TO_DO;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.NUMBER_OF_REATTEMPTS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_ID;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PERSIST_INCOMING_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PERSIST_VERIFICATION_POLL_PERIOD;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.test.JobTestHelper;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.activiti.engine.test.Deployment;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ised.cipo.tm.madrid.conf.MweCoreSpringTestConfiguration;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestFinancialTransactionReconcileServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestPersistPackageServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.TestTmTransactionsServiceImpl;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.PackageUnit;
import util.TestMadridMethodVarsService;
import util.TestUtils;

/**
 * Test class for the persist_package_data.bpmn process flow.
 *
 * @author J. Greene
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MweCoreSpringTestConfiguration.class)
public class PersistIncomingPackageTest {

    @Autowired
    protected ManagementService managementService;

    @Autowired
    protected ProcessEngine processEngine;

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected TaskService taskService;

    @Autowired
    protected HistoryService historyService;

    @Autowired
    @Rule
    public ActivitiRule activitiRule;

    @Autowired
    private TestMadridMethodVarsService methodVarsService;

    @Autowired
    protected TestPersistPackageServiceImpl testPersistPackageServiceImpl;

    @Autowired
    protected TestFinancialTransactionReconcileServiceImpl financialTransactionReconcileServiceImpl;

    @Autowired
    protected TestTmTransactionsServiceImpl testTmTransactionsServiceImpl;

    @Before
    public void init() {
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(null);
        testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(null);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(null);

        financialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(null);

        testTmTransactionsServiceImpl.setGetPdfTransactionsStatusReturnObject(null);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn",
        "ca/gc/ised/cipo/tm/madrid/diagram/finance/process_madrid_financial_transactions_from_wipo.bpmn"})
    public void testHappyPathForWipoFinPkg() {
        System.out.println("#############################################");
        System.out.println("###      testHappyPathForWipoFinPkg       ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        processVariables.put(PACKAGE_ID, "10001");
        processVariables.put(TRANSFER_ITEM, IN_MADRID_FEES);
        List<PackageUnit> testPackages = createDummyPackageUnitList(1);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        // Just to short circuit. Don't actually want to run through this monster!
        financialTransactionReconcileServiceImpl.setFinancialTransactionListGetStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 1000L);

        // Look for the process variables created in the history to get an idea of the mockExecution path.
        TestUtils.assertCompletion(historyService, testInstance);

        // Ensure the nothing to persist end event fired once.
        TestUtils.assertActivitiEventFired(historyService, "persistWipoHaguePackageEndEvent", 1);

    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testHappyPathForWipoTMPkg() {
        System.out.println("#############################################");
        System.out.println("###      testHappyPathForWipoTMPkg        ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        processVariables.put(PACKAGE_ID, "10001");
        processVariables.put(TRANSFER_ITEM, IN_NOTIF_PKG);

        List<PackageUnit> testPackages = createDummyPackageUnitList(1);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        // Don't want to get into this one either
        testTmTransactionsServiceImpl.setGetPdfTransactionsStatusReturnObject(ERROR);

        methodVarsService.setMethodVar("TestMadridDelegateServiceImpl.fetchTransactions",
            ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_DESC_LIST, new ArrayList<String[]>());

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 1000L);

        // Look for the process variables created in the history to get an idea of the mockExecution path.
        TestUtils.assertCompletion(historyService, testInstance);

        // Ensure the nothing to persist end event fired once.
        TestUtils.assertActivitiEventFired(historyService, "persistWipoHaguePackageEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testHappyPathForCipoFinPkg() {
        System.out.println("#############################################");
        System.out.println("###      testHappyPathForCipoFinPkg       ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        processVariables.put(PACKAGE_ID, "10001");
        processVariables.put(TRANSFER_ITEM, IN_FINANCE_FEES);
        List<PackageUnit> testPackages = createDummyPackageUnitList(1);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 1000L);

        // Look for the process variables created in the history to get an idea of the mockExecution path.
        TestUtils.assertCompletion(historyService, testInstance);

        // Ensure the nothing to persist end event fired once.
        TestUtils.assertActivitiEventFired(historyService, "persistWipoHaguePackageEndEvent", 1);

    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testPersistFinancialWithError() {
        System.out.println("#############################################");
        System.out.println("###     testPersistFinancialWithError     ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();
        processVariables.remove(TRANSFER_ITEM);
        processVariables.put(TRANSFER_ITEM, IN_MADRID_FEES);

        List<PackageUnit> testPackages = createDummyPackageUnitList(1);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);
        testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure error handler fired for each iteration
        TestUtils.assertActivitiEventFired(historyService, "handlePackagePersistErrorTask", testPackages.size());
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testSubprocessLoop() {
        // Happy-path through the subprocess to test looping
        System.out.println("#############################################");
        System.out.println("###           testSubprocessLoop          ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        processVariables.put(TRANSFER_ITEM, IN_FINANCE_FEES);
        List<PackageUnit> testPackages = createDummyPackageUnitList(3);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 90000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure happy-path end event fired X times.
        TestUtils.assertActivitiEventFired(historyService, "persistPackageSubprocessEndEvent", testPackages.size());

        // Make sure overall end event fired once
        TestUtils.assertActivitiEventFired(historyService, "persistWipoHaguePackageEndEvent", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testNoPackageToStage() {
        System.out.println("#############################################");
        System.out.println("###          testNoPackageToStage         ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        // Set the process variable for the service task to return nothing to do
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(NOTHING_TO_DO);
        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        // Look for the process variables created in the history to get an idea of the mockExecution path.
        TestUtils.assertCompletion(historyService, testInstance);

        // Ensure the nothing to persist end event fired once.
        TestUtils.assertActivitiEventFired(historyService, "nothingToPersistEndEvent", 1);

    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testErrorFetchPkgs() {
        System.out.println("#############################################");
        System.out.println("###           testErrorFetchPkgs          ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        // Set the process variable for the service task to return nothing to do
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(ERROR);
        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        // Look for the process variables created in the history to get an idea of the mockExecution path.
        TestUtils.assertCompletion(historyService, testInstance);

        // Ensure the nothing to persist end event fired once.
        TestUtils.assertActivitiEventFired(historyService, "persistWipoHaguePackageErrorEndEvent", 1);

    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testPackagePersistCallReturn() {
        System.out.println("#############################################");
        System.out.println("###      testPackagePersistCallReturn     ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        List<PackageUnit> testPackages = createDummyPackageUnitList(3);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(ERROR);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure error handler fired only once (we don't want to process further packages if one fails).
        TestUtils.assertActivitiEventFired(historyService, "handlePackagePersistErrorTask", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testPackagePersistVerifyError() {
        System.out.println("#############################################");
        System.out.println("###      testPackagePersistVerifyError    ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        List<PackageUnit> testPackages = createDummyPackageUnitList(3);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(ERROR);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure error handler fired only once (we don't want to process further packages if one fails).
        TestUtils.assertActivitiEventFired(historyService, "handlePackagePersistErrorTask", 1);
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testPackagePersistIncomplete() {
        System.out.println("#############################################");
        System.out.println("###      testPackagePersistIncomplete     ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();

        List<PackageUnit> testPackages = createDummyPackageUnitList(1);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(INCOMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 60000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure the persist task fired twice for each iteration (retry then error)
        TestUtils.assertActivitiEventFired(historyService, "verifyPersistedTask", (testPackages.size() * 2));
        // Make sure error handler fired for each iteration
        TestUtils.assertActivitiEventFired(historyService, "handlePackagePersistErrorTask", testPackages.size());
    }

    @Test
    @Deployment(resources = {"ca/gc/ised/cipo/tm/madrid/diagram/import/persist_package_data.bpmn"})
    public void testPackageVerifyErrorWithRetry() {
        System.out.println("#############################################");
        System.out.println("###    testPackageVerifyErrorWithRetry    ###");
        System.out.println("#############################################");
        Map<String, Object> processVariables = getTypicalProcessVars();
        processVariables.put(NUMBER_OF_REATTEMPTS, 2);

        List<PackageUnit> testPackages = createDummyPackageUnitList(1);
        processVariables.put(TRANSFER_ITEM, IN_NOTIF_PKG);
        testPersistPackageServiceImpl.setPackageFetchStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPersistPackageCallStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackagePersistVerifyStatusReturnObject(ERROR_WITH_RETRY);
        testPersistPackageServiceImpl.setHfsSplitStatusReturnObject(COMPLETE);
        testPersistPackageServiceImpl.setPackageUnitListReturnObject(testPackages);

        // Don't want to get into this one either
        testTmTransactionsServiceImpl.setGetPdfTransactionsStatusReturnObject(ERROR);

        ProcessInstance testInstance = TestUtils.startProcessInstance(PERSIST_INCOMING_PACKAGE, runtimeService,
            processVariables);

        JobTestHelper.waitForJobExecutorToProcessAllJobs(activitiRule, 120000L, 1000L);

        TestUtils.assertCompletion(historyService, testInstance);

        // Make sure the persist task fired for each iteration number of times allowed to reattempt plus one
        TestUtils.assertActivitiEventFired(historyService, "persistPackageDataTask",
            (testPackages.size() * ((Integer) processVariables.get(NUMBER_OF_REATTEMPTS) + 1)));
    }

    private List<PackageUnit> createDummyPackageUnitList(int numEntries) {
        List<PackageUnit> packageUnitList = new ArrayList<>();

        for (int i = 0; i < numEntries; i++) {
            PackageUnit p = new PackageUnit();
            p.setImgFileName("file" + i + ".zip");
            p.setXmlFileName("xmlFile" + i + ".zip");
            packageUnitList.add(p);
        }

        return packageUnitList;
    }

    protected Map<String, Object> getTypicalProcessVars() {
        Map<String, Object> processVariables = new HashMap<>();
        processVariables.put(TRANSFER_ITEM, IN_NOTIF_PKG);
        processVariables.put(INPUT_FOLDER, "/c/path/to/input");
        processVariables.put(FAIL_FOLDER, "/c/path/to/output");
        processVariables.put(PERSIST_VERIFICATION_POLL_PERIOD, "PT1S");
        return processVariables;
    }

    private void sleep(int seconds) {
        // Simulate a small delay in processing
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
