package ca.gc.ised.cipo.tm.madrid.workflow.engine.web.rest;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.CREATE_OUTGOING_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DOWNLOAD_INCOMING_PACKAGE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_IMG_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PDF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.IN_NOTIF_PKG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_OUTGOING_TRANSACTIONS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PERSIST_INCOMING_PACKAGE;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.activiti.engine.task.Task;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.support.ResourcePropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.MweJobService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingPackageDownloadJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingPackagePersistJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.IncomingProcessManualTransJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingMessageJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.OutgoingTaskJob;
import ca.gc.ised.cipo.tm.madrid.workflow.model.SystemInfo;

/**
 * Rest controller providing support of rest api for starting a Activiti BPMN process instance along with any incoming
 * process instance variables if any
 *
 * @author sagary
 */
@RestController
public class MadridRestController {

    private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    @Autowired
    private ProcessEngine processEngine;

    @Autowired
    Environment env;

    @Autowired
    MweJobService mweJobService;

    @PostConstruct
    public void init() {

        String classPathResource = "ca/gc/ised/cipo/tm/madrid/diagram/";

        processEngine.getRepositoryService().createDeployment().addClasspathResource(classPathResource).deploy();

    }

    /**
     * Call responsible for handling the manual Tasks based on unprocessed transactions
     *
     * @param
     * @return text to describe the job (not meant for machine consumption)
     */
    @PostMapping(path = "/process-manual-trans-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> processManualTransactions() {

        LOG.debug("Starting an import job");
        ResponseEntity<String> response;

        try {

            String processId = mweJobService.processManualTransactions(null);

            response = new ResponseEntity<>(
                "Process manual transactions job (" + processId + ") created with no parameters.", HttpStatus.CREATED);

        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    /**
     * Call responsible for creating a manual Tasks based on a unprocessed transaction
     *
     * @param processTransJob JSON object that represents the call parameters
     * @return text to describe the job (not meant for machine consumption)
     */
    @PostMapping(path = "/process-one-manual-trans-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> processOneManualTransactions(@RequestBody IncomingProcessManualTransJob processTransJob) {

        LOG.debug("Starting an import job");
        ResponseEntity<String> response;

        try {

            String processId = mweJobService.processManualTransactions(processTransJob);

            response = new ResponseEntity<>("Process manual transactions job (" + processId
                + ") created with the following parameters:: " + processTransJob.toString(), HttpStatus.CREATED);

        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    /**
     * This REST call will kick off the workflow for processing any Automated Transactions in the International database
     * which are in 'Ready for Processing' state. Typically this workflow is not invoked directly but is a sub-flow to
     * the 'persist_package_data.bpmn', however, for testing and development purposes it is useful.
     *
     * @return the process ID of the workflow that kicked off
     */
    @PostMapping(path = "/process-automated-transactions-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startAutomatedTransactionProcessJob() {

        LOG.debug("Starting an automated transaction processing job");
        ResponseEntity<String> response;

        try {
            String infoString = mweJobService.processAutomatedTransactions();
            response = new ResponseEntity<>(
                "Automated transaction processing job created./nProcess Instance ID = [" + infoString + "]",
                HttpStatus.CREATED);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    /**
     * This REST call will kick off the workflow for processing any Automated Transaction Pairs in the International
     * database which are in 'Ready for Processing' state. Typically this workflow is not invoked directly but is a
     * sub-flow to the 'persist_package_data.bpmn', however, for testing and development purposes it is useful.
     *
     * @return the process ID of the workflow that kicked off
     */
    @PostMapping(path = "/process-automated-transaction-pairs-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startAutomatedTransactionPairProcessJob() {

        LOG.debug("Starting an automated transaction pair processing job");
        ResponseEntity<String> response;

        try {
            String infoString = mweJobService.processAutomatedTransactionPairs();
            response = new ResponseEntity<>(
                "Automated transaction pair processing job created./nProcess Instance ID = [" + infoString + "]",
                HttpStatus.CREATED);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    /**
     * Call responsible for processing of downloaded Madrid packages.
     *
     * @param persistJob JSON object that represents the call parameters
     * @return text to describe the job (not meant for machine consumption)
     */
    @PostMapping(path = "/persist-incoming-package-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startPersistPackageJob(@RequestBody IncomingPackagePersistJob persistJob) {

        LOG.debug("Starting a package persist job");
        ResponseEntity<String> response;

        try {
            IncomingPackagePersistJob workingJob = mweJobService.persistIncomingPackage(persistJob);
            response = new ResponseEntity<>(
                "Package persist job created with the following parameters: " + workingJob.toString(),
                HttpStatus.CREATED);
        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    /**
     * Call responsible for handling the DTF download of Madrid packages and putting them in local staging for further
     * processing.
     *
     * @param importJob JSON object that represents the call parameters
     * @return text to describe the job (not meant for machine consumption)
     */
    @PostMapping(path = "/download-incoming-package-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startDownloadPackageJob(@RequestBody IncomingPackageDownloadJob importJob) {

        LOG.debug("Starting an import job");
        ResponseEntity<String> response;

        try {
            IncomingPackageDownloadJob workingJob;
            workingJob = mweJobService.downloadIncomingPackage(importJob);
            response = new ResponseEntity<>(
                "Import job created with the following parameters: " + workingJob.toString(), HttpStatus.CREATED);
        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    /**
     * Call responsible for handling the DTF download of the 3 Madrid notification packages (XML, image and PDF) and
     * putting them in local staging for further processing.
     *
     * @return text to describe the job (not meant for machine consumption)
     */
    @PostMapping(path = "/download-notification-packages-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startDownloadNotificationPackagesJob() {

        LOG.debug("Starting an import notification job");
        IncomingPackageDownloadJob importJob = new IncomingPackageDownloadJob();
        ResponseEntity<String> response;

        try {
            importJob.setTransferItem(IN_NOTIF_PKG);
            startDownloadPackageJob(importJob);

            importJob.setTransferItem(IN_NOTIF_IMG_PKG);
            startDownloadPackageJob(importJob);

            importJob.setTransferItem(IN_NOTIF_PDF_PKG);
            startDownloadPackageJob(importJob);

            response = new ResponseEntity<>("Import notification jobs created", HttpStatus.CREATED);
        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    @PostMapping(path = "/create-outgoing-transactions-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startCreateOutgoingJob() {
        LOG.debug("Starting a create outgoing transactions job");
        ResponseEntity<String> response;

        try {
            mweJobService.createOutgoingMessages();
            response = new ResponseEntity<>("Transaction create job created", HttpStatus.CREATED);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }
        return response;
    }

    @PostMapping(path = "/package-outgoing-transactions-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startPackagingOutgoingMessagesJob(@RequestBody OutgoingMessageJob outgoingMessageJob) {

        LOG.debug("Starting a package outgoing transactions job");
        ResponseEntity<String> response;

        try {
            OutgoingMessageJob workingJob = mweJobService.packageOutgoingMessages(outgoingMessageJob);
            response = new ResponseEntity<>(
                "Outgoing message packaging job created with the following parameters: " + workingJob.toString(),
                HttpStatus.CREATED);
        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    @PostMapping(path = "/upload-outgoing-package-job", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> startUploadOutgoingMessagePackageJob(@RequestBody OutgoingMessageJob outgoingMessageJob) {

        LOG.debug("Starting a message package upload to WIPO job");
        ResponseEntity<String> response;

        try {
            OutgoingMessageJob workingJob = mweJobService.uploadOutgoingMessagePackage(outgoingMessageJob);
            response = new ResponseEntity<>(
                "Upload message package to WIPO job created with the following parameters: " + workingJob.toString(),
                HttpStatus.CREATED);
        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    @PostMapping(path = "/create-outgoing-manual-task", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> createOutgoingManualTask(@RequestBody OutgoingTaskJob outgoingTaskJob) {

        LOG.debug("Assigning a manual task to a group in Madrid Console");
        ResponseEntity<String> response;

        try {
            OutgoingMessageJob workingJob = mweJobService.createOutgoingManualTask(outgoingTaskJob);
            response = new ResponseEntity<>(
                "Create outgoing manual task with the following parameters: " + workingJob.toString(),
                HttpStatus.CREATED);
        } catch (IllegalArgumentException iax) {
            LOG.warn("Bad arguments for call", iax);
            response = new ResponseEntity<String>(iax.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (IllegalStateException isx) {
            LOG.warn("Process already running", isx);
            response = new ResponseEntity<String>(isx.getMessage(), HttpStatus.CONFLICT);
        }

        return response;
    }

    @PostMapping(path = "/delete-all-ongoing-processes", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> deleteAllOngoingProcesses() {
        List<ProcessInstance> processInstanceList = new ArrayList<>();
        String message = "";

        processInstanceList.addAll(mweJobService.getOngoingProcessList(DOWNLOAD_INCOMING_PACKAGE));
        processInstanceList.addAll(mweJobService.getOngoingProcessList(PERSIST_INCOMING_PACKAGE));
        processInstanceList.addAll(mweJobService.getOngoingProcessList(CREATE_OUTGOING_TRANSACTIONS));
        processInstanceList.addAll(mweJobService.getOngoingProcessList(PACKAGE_OUTGOING_TRANSACTIONS));

        for (ProcessInstance processInstance : processInstanceList) {
            mweJobService.deleteProcessInstance(processInstance);

            if (!message.isEmpty()) {
                message += ", ";
            }
            message += "Deleted Process Instance " + processInstance.getId() + " ("
                + processInstance.getProcessDefinitionKey() + ")";
        }
        return new ResponseEntity<String>(message, HttpStatus.OK);
    }

    /**
     * A REST call that will display the currently running processes and the User Tasks awaiting completion.
     *
     * @return
     */
    @RequestMapping(value = "/wfStateOld", method = RequestMethod.GET)
    public Object wfState() {

        String strVal = "Processes/Tasks: <br/>";

        strVal += "<br/>";

        List<Task> tasks = processEngine.getTaskService().createTaskQuery().orderByTaskCreateTime().desc().list();

        for (Task task : tasks) {

            ProcessInstance process = processEngine.getRuntimeService().createProcessInstanceQuery()
                .includeProcessVariables().processInstanceId(task.getProcessInstanceId()).singleResult();

            String typeValue = (String) processEngine.getTaskService().getVariablesLocal(task.getId())
                .get(ProcessFlowConstants.CONSOLE_TASK_TYPE);
            if (typeValue == null) {
                typeValue = task.getName();
            }

            strVal += "Process Id: " + process.getId() + " (" + process.getProcessDefinitionName() + ") <br/>";

            String taskId = task.getId();

            String groupName = "";

            List<IdentityLink> idList = processEngine.getTaskService().getIdentityLinksForTask(taskId);

            for (IdentityLink identityLink : idList) {
                if (IdentityLinkType.CANDIDATE.equals(identityLink.getType())) {
                    groupName = identityLink.getGroupId();
                }
            }

            String transId = "<unknown>";
            Map<String, Object> vars = process.getProcessVariables();
            if (vars != null && !vars.isEmpty()) {
                transId = (String) vars.get(ProcessFlowConstants.INTL_REGISTRY_TRANSACTION_ID);
            }

            strVal += "&nbsp&nbsp&nbsp&nbspTask Id: " + taskId + " (user=" + task.getAssignee() + ", group=" + groupName
                + ", transId=" + transId + ") - " + typeValue;
            strVal += "<br/><br/>";

        }

        // Look for 'stalled' processes
        List<Execution> execs = processEngine.getRuntimeService().createExecutionQuery()
            .signalEventSubscriptionName(ProcessFlowConstants.SIGNAL_MTS_RECOVERY).list();

        if (execs != null && !execs.isEmpty()) {

            strVal += "Processes awaiting MTS Recovery Signal: ";
            strVal += "<a href=\"http://w0918143.prod.prv:9080/app/cipo/tm/mwe/service/sendMtsRecoverySignal?execId=all\">Signal All</a>";
            strVal += "<br/><br/>";

            for (Execution execution : execs) {

                String execId = execution.getId();

                strVal += "Execution Id: ";
                strVal += "<a href=\"http://w0918143.prod.prv:9080/app/cipo/tm/mwe/service/sendMtsRecoverySignal?execId=";
                strVal += execId + "\">";
                strVal += execution.getId() + "</a> (" + execution.getProcessInstanceId() + ") <br/><br/>";

            }

        }

        strVal += "<br/><br/>";

        return strVal;
    }

    @RequestMapping(value = "/sendMtsRecoverySignal", method = RequestMethod.GET)
    public Object sendMtsRecoverySignal(@RequestParam("execId") String execId) {

        String strValue = "";

        if ("all".equals(execId)) {

            this.processEngine.getRuntimeService().signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_RECOVERY);

            strValue += "MTS Recovery signal sent to all processes.";

        } else {

            this.processEngine.getRuntimeService().signalEventReceived(ProcessFlowConstants.SIGNAL_MTS_RECOVERY,
                execId);

            strValue += "MTS Recovery signal sent to " + execId + " process.";

        }

        return strValue;
    }

    /**
     * Just a simple method to determine if service is up and running for internal testing purposes. This is subject to
     * be changed or removed
     *
     * @return
     */
    @RequestMapping(path = "/rest", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    @ResponseBody
    public Object greetings() {

        Map<String, String> result = new HashMap<>();
        result.put("message", "Madrid Workflow Engine is up and running");
        return result;
    }

    /**
     * Internal use only: System status.
     *
     * @return System status JSON
     */
    @GetMapping(path = "/system-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<SystemInfo> getSystemInfo() {

        SystemInfo systemInfo = mweJobService.getSystemInfo();

        ResponseEntity<SystemInfo> responseEntity = new ResponseEntity<>(systemInfo, HttpStatus.OK);
        return responseEntity;
    }

    /**
     * Internal use only: Download log data
     *
     * @param xferReqId The transfer request type
     * @param topX Top (X) records
     * @param packageType Package type
     * @return Download log data (JSON)
     */
    @GetMapping(path = "/download-log", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<List<DownloadLogItem>> getDownloadLogItems(@RequestParam(value = "xferReqId", required = false) String xferReqId,
                                                                     @RequestParam(value = "topX", required = false) Integer topX,
                                                                     @RequestParam(value = "packageType", required = false) String packageType) {

        List<DownloadLogItem> searchResultList = mweJobService.getDownloadLogItems(xferReqId, topX, packageType);

        ResponseEntity<List<DownloadLogItem>> responseEntity;
        if (searchResultList == null || searchResultList.isEmpty()) {
            List<DownloadLogItem> nullList = null;
            responseEntity = new ResponseEntity<>(nullList, HttpStatus.NOT_FOUND);
        } else {
            responseEntity = new ResponseEntity<>(searchResultList, HttpStatus.OK);
        }

        return responseEntity;
    }

    /**
     * Internal use only: Business log data
     *
     * @param componentAcronym The component acronym of the throwing app
     * @param topX Top (X) records
     * @return Business error data (JSON)
     */
    @GetMapping(path = "/business-error-log", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<List<BusinessErrorLogItem>> getBusinessErrorLogItems(@RequestParam(value = "componentAcronym", required = false) String componentAcronym,
                                                                               @RequestParam(value = "topX", required = false) Integer topX) {

        List<BusinessErrorLogItem> searchResultList = mweJobService.getBusinessErrorLogItems(componentAcronym, topX);

        ResponseEntity<List<BusinessErrorLogItem>> responseEntity;
        if (searchResultList == null || searchResultList.isEmpty()) {
            List<BusinessErrorLogItem> nullList = null;
            responseEntity = new ResponseEntity<>(nullList, HttpStatus.NOT_FOUND);
        } else {
            responseEntity = new ResponseEntity<>(searchResultList, HttpStatus.OK);
        }

        return responseEntity;
    }

    /**
     * Convenience operation to see what configuration parameters MWE is operating within. Is there a better way to
     * gleen these? Probably, but it's not an essential operation so revisit at a later date.
     *
     * @return The Map of configuration properties sorted alphabetically.
     */
    @SuppressWarnings("rawtypes")
    @GetMapping(path = "/mwe-properties", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Map<String, Object>> getHweAppProperties() {
        Map<String, Object> sortedPropertiesMap = new TreeMap<>();
        Map<String, Object> overrideMap = new HashMap<>();
        MutablePropertySources envPropSources = ((ConfigurableEnvironment) env).getPropertySources();
        for (Object element : envPropSources) {
            PropertySource source = (PropertySource) element;
            if (source instanceof ResourcePropertySource) {
                System.out.println("Getting properties found in " + source.getName());
                sortedPropertiesMap.putAll(((ResourcePropertySource) source).getSource());
            }
            if (source instanceof PropertiesPropertySource) {
                System.out.println("Getting properties found in " + source.getName());
                if (source.getName().equalsIgnoreCase("localOverrideSource")) {
                    overrideMap.putAll(((PropertiesPropertySource) source).getSource());
                } else {
                    sortedPropertiesMap.putAll(((PropertiesPropertySource) source).getSource());
                }
            }
        }
        sortedPropertiesMap.putAll(overrideMap);

        return new ResponseEntity<>(sortedPropertiesMap, HttpStatus.OK);
    }

}