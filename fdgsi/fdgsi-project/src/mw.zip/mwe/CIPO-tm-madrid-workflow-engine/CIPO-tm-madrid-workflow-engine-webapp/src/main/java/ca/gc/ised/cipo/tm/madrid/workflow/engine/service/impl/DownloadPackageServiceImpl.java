package ca.gc.ised.cipo.tm.madrid.workflow.engine.service.impl;

import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.COMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.DTF_PACKAGE_TEMP_NAME_PREFIX;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERROR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.ERR_MSG_OBJECT_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.INCOMPLETE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.OUTPUT_FOLDER;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.PACKAGE_TRANSFER_STATE;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.STAGING_TRANSFER_STATUS;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_ITEM;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQUEST_LOG;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TRANSFER_REQ_ID_VAR;
import static ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants.TR_CREATE_STATUS;

import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.patents.dtf.trs.CreateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.CreateTransferRequest;
import ca.gc.ic.cipo.patents.dtf.trs.DownloadResponse;
import ca.gc.ic.cipo.patents.dtf.trs.GetTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.TransferRequestStateResponse;
import ca.gc.ic.cipo.patents.dtf.trs.UpdateTransferRequestState;
import ca.gc.ic.cipo.patents.dtf.trs.model.ParamNameCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.RequestStateCode;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestParamXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestStateXsd;
import ca.gc.ic.cipo.patents.dtf.trs.model.TransferRequestXsd;
import ca.gc.ised.cipo.tm.madrid.exception.BpmnWebServiceCallException;
import ca.gc.ised.cipo.tm.madrid.exception.NoDownloadHistoryException;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.mgr.DtfServiceManager;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.DownloadPackageService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.service.PackageDownloadLogService;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.strategy.WipoInboundTransferRequestCreator;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.MweWorkflowUtil;
import ca.gc.ised.cipo.tm.madrid.workflow.engine.util.ProcessFlowConstants;
import ca.gc.ised.cipo.tm.madrid.workflow.model.BusinessErrorLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem;
import ca.gc.ised.cipo.tm.madrid.workflow.model.DownloadLogItem.Status;

/**
 * A service that will handle delegated task actions from the {@code download_madrid_package_from_wipo.bpmn} process
 * flow.
 *
 * @author J. Greene
 *
 */
@Service
public class DownloadPackageServiceImpl extends BusinessErrorHandlerImpl
    implements DownloadPackageService, Serializable {

    @Autowired
    protected DtfServiceManager dtfServiceManager;

    @Autowired
    protected PackageDownloadLogService packageDownloadLogService;

    @Autowired
    protected TaskExecutor taskExecutor;

    private static final long serialVersionUID = -1541917917427792661L;

    protected static final Logger LOG = LoggerFactory.getLogger(DownloadPackageServiceImpl.class);

    /**
     * {@inheritDoc}
     * <p>
     * Creates a transfer request via DTF to download the latest WIPO Madrid protocol package based on the the
     * parameters passed in to the process instance from the service responsible for its execution. The process variable
     * {@code transferRequestId} is set accordingly. The process variable {@code trCreateStatus} is set accordingly:
     * </p>
     * <p>
     * {@code [  10]} if there's nothing to transfer (file previously downloaded)<br/>
     * {@code [  -1]} if the transfer request failed, <br/>
     * {@code [   1]} if file wasn't previously downloaded (success)<br/>
     * </p>
     *
     */
    @Override
    public void createTransferRequest(DelegateExecution execution) {
        String transferItem = execution.getVariable(TRANSFER_ITEM, String.class);
        WipoInboundTransferRequestCreator trCreateStrategy = dtfServiceManager
            .getInboundTransferRequestCreateStrategy(transferItem);
        String outputDirectoryString = execution.getVariable(OUTPUT_FOLDER, String.class);
        Integer trCreateStatus = COMPLETE;

        try {
            CreateTransferRequest request = trCreateStrategy.createTransferReqeust(execution,
                packageDownloadLogService);
            CreateResponse response = dtfServiceManager.createTransferRequest(request);

            String transferRequestId = response.getTransferRequest().getRequestId();
            if (StringUtils.isBlank(transferRequestId)) {
                registerGenericMweBusinessError(execution, "No transfer request ID was returned from service!");
                trCreateStatus = ERROR;
            } else {
                execution.setVariable(TRANSFER_REQ_ID_VAR, transferRequestId);
                LOG.info("Created transfer request #" + transferRequestId);

                String overrideFileName = execution.getVariable(ProcessFlowConstants.REMOTE_FILE_NAME, String.class);
                String fileSearchRegex = getTransferRequestParameterValue(request.getTransferRequest(),
                    ParamNameCode.FILE_REGEX.codeValue());

                // log transfer
                DownloadLogItem downloadLogItem = new DownloadLogItem(transferRequestId, transferItem, overrideFileName,
                    outputDirectoryString, fileSearchRegex);
                packageDownloadLogService.insertLogEntry(downloadLogItem);
                execution.setVariable(TRANSFER_REQUEST_LOG, downloadLogItem);
            }
        } catch (NoDownloadHistoryException ndhe) {
            registerGenericMweBusinessError(execution, ndhe.getMessage());
            trCreateStatus = ERROR;
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            trCreateStatus = ERROR;
        }
        execution.setVariable(TR_CREATE_STATUS, trCreateStatus);
    }

    /**
     * {@inheritDoc}
     * <p>
     * Verifies the DTF download process and reports on the progress and the sets the process variable
     * {@code packageTransferState} according to the outcome of the verification:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [   0]} if incomplete,<br/>
     * {@code [  -1]} if transfer failed or error occurred (no retry), <br/>
     * {@code [ -10]} if transfer failed but a retry is specified
     * </p>
     */
    @Override
    public void verifyPackageTransfer(DelegateExecution execution) {
        TransferRequestStateXsd inputState = new TransferRequestStateXsd();
        String requestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);
        inputState.setRequestId(requestId);
        Integer packageTransferState = null;
        Status downloadStatus = Status.INPROGRESS;
        String downloadMessage = null;

        GetTransferRequestState request = new GetTransferRequestState();
        request.setTransferRequestState(inputState);
        DownloadLogItem downloadLogItem = execution.getVariable(TRANSFER_REQUEST_LOG, DownloadLogItem.class);

        try {
            TransferRequestStateResponse response = dtfServiceManager.getTransferRequestState(request);

            RequestStateCode returnedStateCode = RequestStateCode
                .getEnumByCodeValue(response.getTxRequestState().getStateCode());
            if (returnedStateCode == null) {
                downloadMessage = "Request State Code [" + response.getTxRequestState().getStateCode()
                    + "] is unknown to this application.";
                registerGenericMweBusinessError(execution, downloadMessage);
                packageTransferState = ERROR;
                downloadStatus = Status.FAIL;
            } else {
                switch (returnedStateCode) {
                    case FAILED:
                    case CANCELLED:
                        BusinessErrorLogItem businessErrorLogItem = dtfServiceManager
                            .createBusinessErrorLogItem(response);
                        businessErrorLogItem.setMessage("DTF Transfer for request #" + requestId + " failed.");
                        execution.setVariable(ERR_MSG_OBJECT_VAR, businessErrorLogItem);
                        packageTransferState = ERROR;
                        downloadMessage = "Transfer request #" + requestId + " failed.";
                        LOG.info(downloadMessage);
                        downloadStatus = Status.FAIL;
                        break;
                    case IN_PROGRESS:
                    case INITIATED:
                    case READY_FOR_PROCESSING:
                        packageTransferState = INCOMPLETE;
                        downloadMessage = "Transfer request #" + requestId + " is in progress.";
                        LOG.info(downloadMessage);
                        break;
                    case COMPLETED:
                        packageTransferState = COMPLETE;
                        downloadMessage = "Transfer request #" + requestId + " succeeded!";
                        LOG.info(downloadMessage);
                        downloadStatus = Status.DTF_STAGED;
                        break;
                    default:
                        // No handling available for other edge cases
                        downloadMessage = "Unable to process the DTF transfer state [" + returnedStateCode.codeValue()
                            + "]";
                        registerGenericMweBusinessError(execution, downloadMessage);
                        packageTransferState = ERROR;
                        downloadStatus = Status.FAIL;
                }
            }
            downloadLogItem.setDlStatus(downloadStatus.getValue());
            downloadLogItem.setMsg(downloadMessage);
            packageDownloadLogService.updateLogEntry(downloadLogItem);
        } catch (BpmnWebServiceCallException bpe) {
            execution.setVariable(ERR_MSG_OBJECT_VAR, bpe.getBusinessErrorLogItem());
            packageTransferState = ERROR;
            failDownloadItem(downloadLogItem, bpe.getMessage());
        }

        execution.setVariable(PACKAGE_TRANSFER_STATE, packageTransferState);

    }

    /**
     * {@inheritDoc}
     * <p>
     * Fetches the downloaded package from DTF staging and initiates a move to the provided output folder. The existence
     * of the moved file is checked in the next workflow task.
     * </p>
     */
    @Override
    public void queueTransferPackageToOutputFolder(DelegateExecution execution) {
        Integer requestId = Integer.parseInt(execution.getVariable(TRANSFER_REQ_ID_VAR, String.class));
        String outputDirectoryString = execution.getVariable(OUTPUT_FOLDER, String.class);
        DownloadLogItem downloadLogItem = execution.getVariable(TRANSFER_REQUEST_LOG, DownloadLogItem.class);

        taskExecutor.execute(new DownloadAndMoveRunner(downloadLogItem, requestId, outputDirectoryString));
    }

    /**
     * {@inheritDoc}
     * <p>
     * Verifies whether the move async task completed successfully or not. Process variable
     * {@code stagingTransferStatus} will be set accordingly:
     * </p>
     * <p>
     * {@code [   1]} if complete,<br/>
     * {@code [   0]} if incomplete,<br/>
     * {@code [  -1]} if an exception occurred
     * </p>
     *
     */
    @Override
    public void verifyPackageMove(DelegateExecution execution) {
        Integer stagingTransferStatus = INCOMPLETE;
        boolean asyncMoveErrorsFound = false;
        boolean complete = true;

        try {
            DownloadLogItem downloadLogItem = execution.getVariable(TRANSFER_REQUEST_LOG, DownloadLogItem.class);
            // Look for error updates in the log first
            DownloadLogItem persistedLogItem = packageDownloadLogService
                .getDownloadLogItemById(downloadLogItem.getDlLogId());
            if (persistedLogItem.getDlStatus() != null
                && persistedLogItem.getDlStatus().equals(Status.FAIL.getValue())) {
                registerGenericMweBusinessError(execution,
                    "An exception occurred while trying to move the data package asyncronously.  See log.");
                stagingTransferStatus = ERROR;
                asyncMoveErrorsFound = true;
            }

            if (persistedLogItem.getDlStatus() != null
                && persistedLogItem.getDlStatus().equals(Status.DTF_STAGED.getValue())) {
                complete = false;
            }

            if (!asyncMoveErrorsFound && complete) {
                stagingTransferStatus = COMPLETE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            registerGenericMweBusinessError(execution,
                "An exception occurred while trying to move the data package asyncronously.  See log.");
            stagingTransferStatus = ERROR;
        }

        execution.setVariable(STAGING_TRANSFER_STATUS, stagingTransferStatus);
    }

    /** {@inheritDoc} */
    @Override
    public void sendTransferConfirmation(DelegateExecution execution) {
        String requestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);
        TransferRequestStateXsd inputState = new TransferRequestStateXsd();
        inputState.setRequestId(requestId);
        inputState.setStateCode(RequestStateCode.PROCESSED.codeValue());

        UpdateTransferRequestState request = new UpdateTransferRequestState();
        request.setTransferRequestState(inputState);

        try {
            TransferRequestStateResponse response = dtfServiceManager.setTransferRequestState(request);
            if (!response.getTxRequestState().getStateCode().equals(request.getTransferRequestState().getStateCode())) {
                // Not a show stopper if it wasn't updated. But will warn anyway.
                LOG.warn("Transfer request ID " + requestId
                    + " was processed successfully but was unable to be set accordingly in DTF.");
            }
        } catch (BpmnWebServiceCallException bpe) {
            LOG.warn(bpe.getMessage());
        }

    }

    /*
     * Extracts a parameter value from the transfer request object. Contingent upon there being only one parameter of
     * that type.
     */
    protected String getTransferRequestParameterValue(TransferRequestXsd transferRequest, String codeValue) {
        String parameterValue = null;

        for (TransferRequestParamXsd param : transferRequest.getParameters()) {
            if (param.getParameterCode().equals(codeValue)) {
                parameterValue = param.getParameterValue();
                break;
            }
        }

        return parameterValue;
    }

    /**
     * Will download packages from DTF and move them to local staging asynchronously in order to prevent timeout issues
     * with Activiti transactions. Some package files are large and take a while to transfer/move.
     *
     * @param downloadLogItem The log item related to this download for log update
     * @param requestId The DTF request ID of the original transfer request
     * @param outputDirectoryString The output directory
     */
    private class DownloadAndMoveRunner implements Runnable {

        private DownloadLogItem downloadLogItem;

        private Integer requestId;

        private String outputDirectoryString;

        public DownloadAndMoveRunner(DownloadLogItem downloadLogItem, Integer requestId, String outputDirectoryString) {
            this.downloadLogItem = downloadLogItem;
            this.requestId = requestId;
            this.outputDirectoryString = outputDirectoryString;
        }

        /** {@inheritDoc} */
        @Override
        public void run() {
            DownloadResponse response;

            try {
                response = dtfServiceManager.downloadStagedFiles(requestId);
                DataHandler dataHandler = response.getZipStream();

                if (dataHandler == null) {
                    String msg = "Data object from DTF is null!";
                    failDownloadItem(downloadLogItem, msg);
                }

                String packageFileName = DTF_PACKAGE_TEMP_NAME_PREFIX.concat(requestId.toString()).concat(".zip");

                MweWorkflowUtil.moveFileStream(dataHandler, outputDirectoryString, packageFileName);
                // See if the file is there
                Path packageFilePath = Paths.get(outputDirectoryString, packageFileName);
                if (Files.exists(packageFilePath)) {
                    // unzip the package in place.
                    List<String> entryNames = MweWorkflowUtil.unzipInPlace(packageFilePath);

                    // remove the old DTF archive
                    Files.deleteIfExists(packageFilePath);

                    Date downloadDate = new Date();
                    int iterCount = 0;
                    for (String entryName : entryNames) {
                        if (iterCount++ == 0) {
                            downloadLogItem.setDlDate(downloadDate);
                            downloadLogItem.setFileName(entryName);
                            downloadLogItem.setDlStatus(Status.SUCCESS.getValue());
                            packageDownloadLogService.updateLogEntry(downloadLogItem);
                        } else {
                            // if there's more than one file in the DTF archive, create new download log items for each
                            // for tracking purposes.
                            DownloadLogItem relatedDownloadLogItem = new DownloadLogItem();
                            BeanUtils.copyProperties(relatedDownloadLogItem, downloadLogItem);
                            relatedDownloadLogItem.setFileName(entryName);
                            relatedDownloadLogItem.setDlDate(downloadDate);
                            packageDownloadLogService.insertLogEntry(relatedDownloadLogItem);
                        }
                    }
                    LOG.info("Successfully moved package '" + packageFileName + "'");
                }
            } catch (BpmnWebServiceCallException e) {
                failDownloadItem(downloadLogItem, e.getMessage());
            } catch (Exception ex) {
                failDownloadItem(downloadLogItem, ex.getMessage());
            }

        }
    }

    protected void failDownloadItem(DownloadLogItem downloadLogItem, String msg) {
        downloadLogItem.setDlStatus(Status.FAIL.getValue());
        downloadLogItem.setMsg(msg);
        packageDownloadLogService.updateLogEntry(downloadLogItem);
    }

    /*
     * This method will hopefully not stay and is meant to test if life would be better without Activiti's timer, who
     * sometimes forget to wake up.
     */
    @Override
    public void waitOneMinute(DelegateExecution execution) {
        String requestId = execution.getVariable(TRANSFER_REQ_ID_VAR, String.class);

        LOG.debug("Entering 'waitOneMinute' for Transfer Request ID " + requestId);
        try {
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        LOG.debug("Exiting 'waitOneMinute' for Transfer Request ID " + requestId);
    }

}
