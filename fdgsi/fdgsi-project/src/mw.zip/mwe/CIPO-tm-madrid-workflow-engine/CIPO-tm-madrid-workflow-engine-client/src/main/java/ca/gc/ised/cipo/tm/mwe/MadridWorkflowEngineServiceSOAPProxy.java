package ca.gc.ised.cipo.tm.mwe;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;

public class MadridWorkflowEngineServiceSOAPProxy{

    protected Descriptor _descriptor;

    public class Descriptor {
        private ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineService _service = null;
        private ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineService();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getMadridWorkflowEngineServiceSOAP();
        }

        public ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("", "MadridWorkflowEngineServiceSOAP");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public MadridWorkflowEngineServiceSOAPProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
    }

    public MadridWorkflowEngineServiceSOAPProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public HeartbeatResponseType getHeartbeat() throws MWEServiceFault {
        return _getDescriptor().getProxy().getHeartbeat();
    }

    public void assignUserTasks(AssignUserTasksRequest assignUserTasksRequest) throws MWEServiceFault {
        _getDescriptor().getProxy().assignUserTasks(assignUserTasksRequest);
    }

    public void unassignUserTasks(UnassignUserTasksRequest unassignUserTasksRequest) throws MWEServiceFault {
        _getDescriptor().getProxy().unassignUserTasks(unassignUserTasksRequest);
    }

    public void reassignTaskGroup(ReassignTaskGroupRequest reassignTaskGroupRequest) throws MWEServiceFault {
        _getDescriptor().getProxy().reassignTaskGroup(reassignTaskGroupRequest);
    }

    public void completeUserTask(CompleteUserTaskRequest completeUserTaskRequest) throws MWEServiceFault {
        _getDescriptor().getProxy().completeUserTask(completeUserTaskRequest);
    }

    public void createNotification(CreateNotificationRequest createNotificationRequest) throws MWEServiceFault {
        _getDescriptor().getProxy().createNotification(createNotificationRequest);
    }

    public void ackNotification(AckNotificationRequest ackNotificationRequest) throws MWEServiceFault {
        _getDescriptor().getProxy().ackNotification(ackNotificationRequest);
    }

}