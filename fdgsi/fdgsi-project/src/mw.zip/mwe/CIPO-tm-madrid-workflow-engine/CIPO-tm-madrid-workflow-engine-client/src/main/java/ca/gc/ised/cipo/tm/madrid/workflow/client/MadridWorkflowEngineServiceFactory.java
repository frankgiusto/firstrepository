package ca.gc.ised.cipo.tm.madrid.workflow.client;

import java.util.Map;

import javax.xml.ws.BindingProvider;

import ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineService;
import ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType;

public class MadridWorkflowEngineServiceFactory {

    public static MadridWorkflowEngineServicePortType createMadridWorkflowEngineClient(String hostName) {

	MadridWorkflowEngineService service = new MadridWorkflowEngineService();
	MadridWorkflowEngineServicePortType port = service.getMadridWorkflowEngineServiceSOAP();

	String endpointUrl = String.format("%s/app/scr/api/cipo/tm/mwe/MadridWorkflowEngineService", hostName);

	Map<String, Object> ctx = ((BindingProvider) port).getRequestContext();
	ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

	return port;

    }

}
