import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.lang.invoke.MethodHandles;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ised.cipo.tm.madrid.workflow.client.MadridWorkflowEngineServiceFactory;
import ca.gc.ised.cipo.tm.mwe.AckNotificationRequest;
import ca.gc.ised.cipo.tm.mwe.AssignUserTasksRequest;
import ca.gc.ised.cipo.tm.mwe.GetHeartbeat;
import ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType;
import ca.gc.ised.cipo.tm.mwe.ReassignTaskGroupRequest;
import ca.gc.ised.cipo.tm.mwe.UnassignUserTasksRequest;

public class ClientTest {

	protected static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	// private String mweHost = "http://cipodev.ic.gc.ca";
	// private String mweHost = "http://wasdevciposprayer.ic.gc.ca:80";
	private String mweHost = "http://w0918143.prod.prv:9080";

	// @Test
	public void heartbeatTest() {

		LOG.debug("Heartbeat Test");
		MadridWorkflowEngineServicePortType port = MadridWorkflowEngineServiceFactory
				.createMadridWorkflowEngineClient(mweHost);

		String ipAddress = null;

		try {

			GetHeartbeat req = new GetHeartbeat();

			HeartbeatResponseType res = port.getHeartbeat();

			if (res != null) {

				ipAddress = res.getIpAddress();

			}

		} catch (Exception e) {
			LOG.error(e.getMessage());
		}

		LOG.debug("Heartbeat returned IP of " + ipAddress);

		assertNotNull(ipAddress);

	}

	// @Test
	public void assignUserTaskTest() {

		LOG.debug("assignUserTasks Test");

		Boolean errorOccurred = false;

		MadridWorkflowEngineServicePortType port = MadridWorkflowEngineServiceFactory
				.createMadridWorkflowEngineClient(mweHost);

		try {

			AssignUserTasksRequest req = new AssignUserTasksRequest();
			req.setAuthId("MADRID3");
			req.setAssigneeId("MADRID3");
			req.getTaskIdList().add("cc146ab0-64dd-11e8-a7b2-d6f4ac4146cb");

			port.assignUserTasks(req);

		} catch (Exception e) {

			errorOccurred = true;
			LOG.error(e.getMessage());

		}

		assertFalse(errorOccurred);

	}

	// @Test
	public void unassignUserTasksTest() {

		LOG.debug("unassignUserTasks Test");

		Boolean errorOccurred = false;

		MadridWorkflowEngineServicePortType port = MadridWorkflowEngineServiceFactory
				.createMadridWorkflowEngineClient(mweHost);

		try {

			UnassignUserTasksRequest req = new UnassignUserTasksRequest();
			req.setAuthId("MADRID3");
			req.getTaskIdList().add("cc146ab0-64dd-11e8-a7b2-d6f4ac4146cb");

			port.unassignUserTasks(req);

		} catch (Exception e) {

			errorOccurred = true;
			LOG.error(e.getMessage());

		}

		assertFalse(errorOccurred);

	}

	// @Test
	public void reassignTaskGroupTest() {

		LOG.debug("reassignTaskGroup Test");

		Boolean errorOccurred = false;

		MadridWorkflowEngineServicePortType port = MadridWorkflowEngineServiceFactory
				.createMadridWorkflowEngineClient(mweHost);

		try {

			ReassignTaskGroupRequest req = new ReassignTaskGroupRequest();
			req.setAuthId("MADRID3");
			req.setGroupId("MC_TM_OPERATOR");
			req.getTaskIdList().add("cc146ab0-64dd-11e8-a7b2-d6f4ac4146cb");

			port.reassignTaskGroup(req);

		} catch (Exception e) {

			errorOccurred = true;
			LOG.error(e.getMessage());

		}

		assertFalse(errorOccurred);

	}

	// @Test
	public void ackNotificationTest() {

		LOG.debug("AckNotificationTest Test");
		MadridWorkflowEngineServicePortType port = MadridWorkflowEngineServiceFactory
				.createMadridWorkflowEngineClient(mweHost);

		AckNotificationRequest req = null;

		Boolean success = null;

		try {

			req = new AckNotificationRequest();

			req.setAssigneeId("MADRID3");
			List<String> taskList = req.getTaskIdList();
			taskList.add("ce25f594-5e87-11e8-960e-eed1b28ed2a4");

			port.ackNotification(req);

			success = true;

		} catch (Exception e) {
			LOG.error(e.getMessage());
		}

		LOG.debug(" ");

		assertTrue(success);

	}

}
