function setClickedButton(button) {
    // Set the button as clicked.
    document.getElementById(button).value = 'true';
}

function setAction(button) {
    // Set the action hidden fields to the name of the button.
    // This works for IE and other browsers.
    var name = button.name;
    $('#action').val(name);
    return true;
}

function confirmAction(element, msg) {
    
    var rc = confirm(msg);

    if (rc) {
        setAction(element);
    }
    
    return rc;
}

