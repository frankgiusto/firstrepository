function launchMessagedetailDialog(msgId) {
 
  //console.log("launch..");
 
  $(document).trigger( "open.wb-lbx", [
      [
          {
              src: "/app/cipo/tm/madridconsole/messagedetail?transid="+msgId,
              type: "ajax",
          },
      ],
      true
  ]);             
}    

//
// This function is used to display the Transaction Detail (XML) of the Original Transaction
// that the Correction is being applied against.
function launchMessagedetailCorrectionDialog(recordIdentifier, irNumber) {
//  document.getElementsByName("messageDetailDialogh2").textContent = 'new text';

  $(document).trigger( "open.wb-lbx", [
      [
          {
              src: "/app/cipo/tm/madridconsole/messagedetailcorrection?recordIdentifier="+recordIdentifier +"&&irNumber="+irNumber,
              type: "ajax"
          },
      ],
      true
  ]);   
  
//  jQuery(document).ready(function($) {   
//    
//    $( document ).on( "wb-ready.wb", function( event )  {   
//      document.getElementsByName("messageDetailDialogh2").textContent = 'new text';
//      $('[name=messageDetailDialogh2]').html = headerText;
//    }); 
//  });
  

  
}    

function btnDisableAndSpin (button) {
  
  button.prop("disabled", true);
  button.find('i').toggleClass('fa fa-spinner fa-spin');
  
}


function btnEnableStopSpin (button) {
  
  button.prop("disabled", false);
  button.find('i').toggleClass('fa fa-spinner fa-spin');

}

function btnDisable (button) {
  
  button.prop("disabled", true);
  
}

function btnEnable(button) {

  button.prop("disabled", false);
  
}


function showCorrectionDiff() {
  
  var corrOrig = document.getElementById("corrOrig").value;
  var corrNew = document.getElementById("corrNew").value;
  var ds;
  
  if (document.getElementById("correctionContent").value  == "false") {
    ds = corrNew;
  } else {
    var dmp = new diff_match_patch();
    var d = dmp.diff_main(corrOrig, corrNew);

    dmp.diff_cleanupSemantic(d);
    ds = dmp.diff_prettyHtml(d).replace(/&para;/g, '');
    
  }
  
  document.getElementById('showdiff').innerHTML = '<pre>' + ds + '</pre>';;
  $(document).trigger("open.wb-lbx", [[ { src: "#resetDialog", type: "inline" }], true]);     

}


function showWipoIntrepidDiff(id, modalTitle) {
 
  var wipoValue = $("#wipoValue"+ id).val();
  var intrepidValue = $("#intrepidValue"+ id).val();  

  if (typeof intrepidValue == 'undefined'){
      intrepidValue = '';    
  }

  if (typeof wipoValue == 'undefined'){
    wipoValue = '';    
  }
  
  var dmp = new diff_match_patch();
  var d = dmp.diff_main(intrepidValue, wipoValue);

  dmp.diff_cleanupSemantic(d);
  ds = dmp.diff_prettyHtml(d).replace(/&para;/g, '');
  
  document.getElementById('showWipoIntrepiddiff').innerHTML = '<pre>' + ds + '</pre>';;
  document.getElementById('WipoIntrepid_modal_id').getElementsByTagName('h2')[0].innerHTML = '' + modalTitle + '';
  $(document).trigger("open.wb-lbx", [[ { src: "#WipoIntrepid_modal_id", type: "inline" }], true]);     

}
   
function displayEditDialog(index) {

  var magnificPopup = $.magnificPopup.instance; 
       
  if (magnificPopup)
      magnificPopup.close(); 

  $(document).trigger( "open.wb-lbx", [
    [
        {
            src: "#centred-popup-edit_" + index,
            type: "inline",
        },
    ],
    true
  ]);   

  wb.doc.on('mfpClose', function (e) {
      var magnificPopup = $.magnificPopup.instance; 
             
      if (magnificPopup)
          magnificPopup.close(); 
   }); 
}   

function displayClaimsDialog(index) {

  var magnificPopup = $.magnificPopup.instance; 
       
  if (magnificPopup)
      magnificPopup.close(); 

  $(document).trigger( "open.wb-lbx", [
    [
        {
            src: "#centred-claims_" + index,
            type: "inline",
        },
    ],
    true
  ]);   

  wb.doc.on('mfpClose', function (e) {
      var magnificPopup = $.magnificPopup.instance; 
             
      if (magnificPopup)
          magnificPopup.close(); 
   }); 
}   

function processTask(url, fn, ir, trId, tId, aId) {

  var taskcanbeprocessed = getUnprocessedTasksForIR(ir, aId);
 
  if( taskcanbeprocessed === false) {
    return;
  }
  $('html, body').css("cursor", "wait");  
  $.ajax({
         url: url,
         method: 'post',
         async: true, 
         data: { filenumber: fn,
                irNum: ir,
                transIds: trId,
                taskId: tId,
                aId: aId
              }/*,
         
         success: function(xhr, textStatus, errorThrown) {
           alert("Success " + xhr.responseText + " status " + xhr.status);
           alert("Success resp " + response.responseText + " status " + response.status);
           alert("text status " + textStatus);
           alert("errorThrown " + errorThrown);
           
           $('html, body').css("cursor", "default");
           window.location.href=url;
         },
         error: function(xhr, textStatus, errorThrown) {  
           alert("Error processing tasks " + xhr.responseText + " status " + xhr.status);
           alert("Error resp " + response.responseText + " status " + response.status);
           alert("text status " + textStatus);
           alert("errorThrown " + errorThrown);
           
           $('html, body').css("cursor", "default");
           showErrorMessageWithoutStatusCode(xhr.responseText);
         },
         complete: function (json, type) { //type return "success" or "parsererror"
           if (type == "parsererror") {
               alert("parsererror");
           }
           if (type == "success") {
             alert("success");
             
           }
         } */
     })
    .done  (function(data, textStatus, jqXHR)        { 
      //alert("Success: " + jqXHR.responseText);
      $('html, body').css("cursor", "default");
      
      if(jqXHR.responseText !== 'undefined' && jqXHR.responseText != null ) {
        
        var index = jqXHR.responseText.indexOf("Error 200:");
        
        if(index != -1) { // return error
          showErrorMessageWithoutStatusCode(jqXHR.responseText);
        } else { // no error
          window.location.href=url;
        }
      }
    })
    .fail  (function(jqXHR, textStatus, errorThrown) { 
      //alert("Error"); 
    })
    //.always(function(jqXHROrData, textStatus, jqXHROrErrorThrown)     { alert("complete " + jqXHROrErrorThrown); })
    ;
}

function getSelectedTaskIds(table) {

  var table = $(table).DataTable();  
  var data = table.$('input, select').serialize();
  
  var idlist = data.split("&");
  var ids="";        
  var id=[];
  
  for (var i = 0, len = idlist.length; i < len;i++){
      id = idlist[i].split("=");
      ids += "ids="+id[0]+"&";
   }
  return ids;
}

function displayMessages(errorMsg, infoMsg) {
  
  if (infoMsg != null && infoMsg != '') {
      showSuccessMessage(infoMsg);
  } 
  if (errorMsg != null && errorMsg != '') {
    showErrorMessage(errorMsg);
  } 
}
   
function removeSortingPaging (theDataTable) {

  // If num of rows less then 2, remove ordering functionality
  var rowcnt = theDataTable.api().page.info().recordsTotal;
  if (rowcnt < 2) {
    theDataTable.find("thead th").unbind('click.DT');
    theDataTable.find("thead th").removeClass("sorting");
    theDataTable.find("thead th").removeClass("sorting_asc");
    theDataTable.find("thead th").removeClass("sorting_desc");
  }
  // If num of rows less then 11, remove paging and show functionality
  if (rowcnt < 11) {
    theDataTable.prev().css({ 'display': "none" });
    theDataTable.next().css({ 'display': "none" });
  }

}

function highlightCurrentNavMenuItem(referer) {
  
  if(referer.indexOf("taskBucket") != -1) {
      $('#taskbucket_menu').addClass('wb-navcurr');
  } else {
      $('#mytasks_menu').addClass('wb-navcurr');
  }
}

function getItagByFileName( fullfilename) {
  var filename_ext = fullfilename.substr(fullfilename.lastIndexOf('.')+1,fullfilename.length);
  return getItagByFiletype(filename_ext);
}


function getItagByFiletype( fileformat) {

  var itag = "";

  switch (fileformat.toLowerCase()) {
      case "png":
      case "tif":
      case "tiff":
      case "gif":
      case "bmp":
      case "jpg":
      case "jpeg":
          itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-image text-success\"></i>";
          break;
      case "pdf":
          itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-pdf text-danger\"></i>";
          break;
      case "doc":
      case "docx":
          itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-word text-primary\"></i>";
          break;
      case "xls":
          itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-excel text-success\"></i>";
          break;
      case "xml":
          itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-code text-success\"></i>";
          break;
      case "zip":
          itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-zip\"></i>";
          break;
  }

  return itag;
}



var frenchContext = {
    "sProcessing":     "Traitement en cours...",
    "sSearch":         "Rechercher&nbsp;:",
    "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
    "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
    "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
    "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
    "sInfoPostFix":    "",
    "sLoadingRecords": "Chargement en cours...",
    "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
    "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
    "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
    },
    "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
    },
    "select": {
            "rows": {
                _: "%d lignes séléctionnées",
                0: "Aucune ligne séléctionnée",
                1: "1 ligne séléctionnée"
            }  
    }
}

var englishContext ={
  "sEmptyTable":     "No data available in table",
  "sInfo":           "Showing _START_ to _END_ of _TOTAL_ entries",
  "sInfoEmpty":      "Showing 0 to 0 of 0 entries",
  "sInfoFiltered":   "(filtered from _MAX_ total entries)",
  "sInfoPostFix":    "",
  "sInfoThousands":  ",",
  "sLengthMenu":     "Show _MENU_ entries",
  "sLoadingRecords": "Loading...",
  "sProcessing":     "Processing...",
  "sSearch":         "Search:",
  "sZeroRecords":    "No matching records found",
  "oPaginate": {
      "sFirst":    "First",
      "sLast":     "Last",
      "sNext":     "Next",
      "sPrevious": "Previous"
  },
  "oAria": {
      "sSortAscending":  ": activate to sort column ascending",
      "sSortDescending": ": activate to sort column descending"
  }
}

if (tableLang == "en") {
  var dataTableoLanguage = englishContext;
} else {
  var dataTableoLanguage = frenchContext;
}
