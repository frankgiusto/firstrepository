function resetGrouptoAllForSupervisor()
{
    // check if the user is a supervisor
    $.getJSON("/app/cipo/tm/madridconsole/dashboard/issuper",function(responseText) {
         
            // reset the filter group option to All for supervisor only
            if(responseText.issuper == true) {
                $("#id_filter_group").val("All");
                //console.log("reseting group page recvd = " + $('#id_filter_group').val());
            }
        }); 
    //console.log("reseting group page " + $('#id_filter_group').val());
}

// This is called when clear filter is pressed from filter.jsp
function resetAdditonalFilters() {
    resetGrouptoAllForSupervisor();
}

// this will check if the user is a supervisor so that certain filter options can be hidden 
// will also remove the on hold status filter
function hideFilterOptions()
{
     $.getJSON("/app/cipo/tm/madridconsole/dashboard/issuper",function(responseText) {
            // hide the assign tasks and unassign tasks buttons
            if(responseText.issuper == true) {
                
                // hide filter users
                $('#lbl_filter_users').hide();
                $('#id_filter_users').hide();
                
                // hide filter assigned to (previous called claimed_unclaimed)
                $('#lbl_filter_claimed').hide();
                $('#id_filter_claimed').val('');
                $('#id_filter_claimed').hide();
            }
    }); 
    // also remove the on hold and closed-unprocessed status filter option
    $('#id_filter_status option[value="H"]').remove();
    $('#id_filter_status option[value="CU"]').remove();
}
        
function reloadCurrentPage()
{
    $('#notificationTaskDatatable').DataTable( {          
                "bDestroy": true, 
                "order" : [[4, "asc" ],[1, "asc" ],[2, "asc"],[6, "asc"],[3, "asc"]],
                /* "stateSave": true,  */
                "columnDefs": [
                            {"targets": [0,5,7], "orderable": false },
                            {"targets": [0,7], "width": "2%" },
                            {"targets": [1,2,4], "width": "10%" },
                            {"targets": [3,5], "width": "20%" },
                            {"targets": [6], "width": "16%" },
                            {"targets": [0,7], "className": "text-center" }], 
                "deferRender": true, 
                "filter": false,
                "serverSide": true,   
                "oLanguage" : dataTableoLanguage,
                "ajax": {"url" :"/app/cipo/tm/madridconsole/notifications/notiftabledata/1",
                     "data": function ( data ) {
                        data.id_filter_iair = $('#id_filter_iair').val();
                        data.id_filter_referfileid = $('#id_filter_referfileid').val();
                        data.startdate = $('#startdate').val();
                        data.enddate = $('#enddate').val();
                        data.id_filter_status = $('#id_filter_status').val();
                        data.id_filter_group = $('#id_filter_group').val();
                        data.id_filter_desc = $('#id_filter_desc').val();
                        //data.id_filter_claimed = $('#id_filter_claimed').val();
                        //data.id_filter_users = $('#id_filter_users').val();
                        },
                       "error": function (xhr, textStatus, errorThrown) {
                           //alert("Error " + xhr.responseText);
                           //alert("text status " + textStatus);
                           //alert("errorThrown " + errorThrown);
                           showErrorMessageWithoutStatusCode(xhr.responseText);
                       }/*,
                        "complete": function (json, type) { //type return "success" or "parsererror"
                          if (type == "parsererror") {
                              alert("parsererror");
                          }
                          if (type == "success") {
                            alert("success");
                          }
                        }*/
                    },
                "dom": "<\"top\"il>rt<\"bottom\"fp><\"clear\">",
                "initComplete": function(settings, json){ 
                        removeSortingPaging(this);
                    },
                    
    } );
    
    updateButtons();
    //console.log("reloading page " + $('#id_filter_group').val());
    //console.log("filter status page " + $('#id_filter_status').val());
}

function acknowledge() {
       
    // Disable the Button
    btnDisableAndSpin( $("#acknowledge_id"));
  
    $('html, body').css("cursor", "wait");  
    $.ajax({
          url: "/app/cipo/tm/madridconsole/notifications/acknowledge?"+getSelectedTaskIds('#notificationTaskDatatable'),
          method: 'post',
          async: true, 
          contentType: "application/json",
          success: function(response) {
            
              $('html, body').css("cursor", "default");  
              
              //alert("success " + response.status);
              displayMessage(response);
              
              // redisplay the datatables
              reloadCurrentPage();
              
              // Re-Enbale  the Button
              btnEnableStopSpin( $("#acknowledge_id"));

          },
          error: function(response) {                     
              alert("error "+response.status);
              showErrorMessage(response.message);
              
              // Re-Enbale  the Button
              btnEnableStopSpin( $("#acknowledge_id"));

          }
      });
    
}

// update the buttons based on what the status filter option is. If Unprocessed or All, enable, else disable    
function updateButtons() {
    
    //console.log("updating buttons " + checkStatusFilter());
    $('#acknowledge_id').prop('disabled', !checkStatusFilter());
}
