    
  function loadSavedAttachFileButtonToggle() {
    $('#btnAddFile').attr('disabled', false);
  }

  // Add a fill to the list of Attachments  
  function addfile() {

    var fullpathfiletoattach = document.getElementById('attachmentInfo.file').value;
    var filenamefiletoattach = fullpathfiletoattach.split('\\').pop();
    var filenameItag = getItagByFileName(fullpathfiletoattach);

    document.getElementById('listOfAttachedFiles').appendChild(document.getElementById("attachmentInfo.file"));
    document.getElementById("attachmentInfo.file").setAttribute("name", filenamefiletoattach);
    document.getElementById("attachmentInfo.file").setAttribute("id", filenamefiletoattach);    


     var input=document.createElement('input');
     input.type="file";
     input.id="attachmentInfo.file";
     input.accept="image/tiff,text/plain,application/pdf,.tif";
     input.onchange=loadSavedAttachFileButtonToggle;
     document.getElementById('inputFileLocation').appendChild(input);
     document.getElementById("attachmentInfo.file").className = "form-control full-width brdr-tp brdr-rght brdr-bttm brdr-lft";

     var removeText = document.getElementById("removeText").value;
     
    var line = $(
        '<li id=\"' + filenamefiletoattach + 'line' +'\" class=\"nowrap list-unstyled\"><hr class=\"mrgn-tp-sm mrgn-bttm-sm\"></li>')
        .appendTo($('#listOfAttachements'));

     var ispan = $('<i id=\"' + filenamefiletoattach + 'display' +'\" />').appendTo($('#listOfAttachements'));

    var filei = $('' +  getItagByFileName(fullpathfiletoattach) +  
        '<a >' + filenamefiletoattach + '</a>').appendTo(ispan);

    var a = $(
        '<a class=\"small pull-right\" href=\"#\" onclick=\"removefile(\''
           + filenamefiletoattach + '\');\" >' + removeText + '<\a>').appendTo(filei);

  
    document.getElementById('attachmentInfo.file').value = "";
    $('#btnAddFile').attr('disabled', true);

    checkNumbOfFiles();

  }

  //  Remove a file from the list of Attachments.       
  function removefile(fileName) {

    var lineabove = document.getElementById(fileName + "line");
    lineabove.parentNode.removeChild(lineabove);

    var filedisplaylineabove = document.getElementById(fileName + "display");
    filedisplaylineabove.parentNode.removeChild(filedisplaylineabove);
    
    var element = document.getElementById(fileName);
    element.parentNode.removeChild(element);
    
    checkNumbOfFiles();

  }
  
  // Check the number of files that have been added by the user,  if there are no
  // files added, then display the message "None".
  function checkNumbOfFiles() {
  
      if ($("#listOfAttachements input[type=file] ").length > 0) {
        $('#fileNone').css({ 'display': "none" });
      } else {
          $('#fileNone').css({ 'display': "block" });
      }
      
  }
  
  function removeCitedMarkPopup(citedMarkIndex) {
   
    $('#removeCitedMarkNumber').html(citedMarkIndex);
    $(document).trigger("open.wb-lbx", [[ { src: "#citedMarkRemoveDialog", type: "inline" }], true]);
    param = ctx + "/obtainCitedMarks?addAnotherMark=false&removeCitedMark=" + citedMarkIndex;
    
  }
  
  function removeCitedMark() {
    
    $('#citedMarksTable').dataTable( {
      "bDestroy": true,
      "ajax":  {"url": param},
      "searching" :false,
      "bInfo" : false,
      "pageLength": 100,
      "ordering":false,
      "oLanguage" : dataTableoLanguage,
      "dom": "",
      "initComplete":function( settings, json){
          // Set the window location to the FIRST Cited Mark on the Screen.
          window.location.hash = $(".citedMarkh2:first").attr("id");
      },
      "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap" }]
   });
    
  }
  
  function addAnotherCitedMark() {
    // 
    param = ctx + "/obtainCitedMarks?addAnotherMark=true";
    $('#citedMarksTable').dataTable( {
      "bDestroy": true,
      "ajax":  {"url": param},
      "searching" :false,
      "bInfo" : false,
      "pageLength": 100,
      "ordering":false,
      "oLanguage" : dataTableoLanguage,
      "dom": "",
      "initComplete":function( settings, json){
          // Set the window location to the LAST Cited Mark on the Screen.
          window.location.hash = $(".citedMarkh2:last").attr("id");
      },
      "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap" }]
    });
  }
 
  
  function loadSavedFileButtonToggle(intCitedMarksCnt){
    $('#btnAddCitedMarkFile' + intCitedMarksCnt).removeAttr("disabled");
    
  }
 
  function enableSubmitButton(){
    $('#citedMark_btn_select_id').removeAttr("disabled");
    
  }
  
  function onFieldChange(field, value) {
    
    var fields = field.split('_');

    var strField = fields[0];
    var strIncr = fields[1];
    $.ajax({
      type: "POST",
      url: ctx + "/updateCitedMarks",
      data: {strField: strField, strIncr: strIncr , strValue: value}
    });
   
  }
  
  function searchFilingNumber(intCitedMarksCnt){
    
    var strFilingNumber = document.getElementById('filingnNumber_' + intCitedMarksCnt).value;
 
    $.ajax({
      type: "POST",
      url: ctx + "/searchFilingNumber",
      data: {strFilingNumber: strFilingNumber,intCitedMarksCnt: intCitedMarksCnt },
       error: function(response) {
//         alert("error "+response.status); 
//          alert("error "+response.message); 
       },
      success: function(data){  // reload the Cited Marks Data.
          if (data.status == "E") {   // Cited Mark Error- Not Found
              document.getElementById("error.label.7.i_" + intCitedMarksCnt ).innerHTML = data.message;
              document.getElementById("error.label.7.i_section" + intCitedMarksCnt ).style.display = "block";
          } else 
          if (data.status == "M") {    // MULTIPLE File numbers are present, allow the user to select the correct one.
            
              // the pop-up
              $(document).trigger( "open.wb-lbx", [
                  [
                       {
                         src: "#citedMarksSelection_modal_id",
                         type: "inline",                             
                       }
                  ]
              ]);
              
              // Disable the "Select" button until, the user has selected an item.,
              $('#citedMark_btn_select_id').prop("disabled", true);
              
              // Clear the Datatabel
              $('#citedMark_list_table_id').DataTable( {
                "bDestroy"    : true,
                "ordering"    : false,
                "columnDefs"  : [ 
                    {"targets": [0], "width": "2%" },
                    {"targets": [1], "width": "%35" },
                    {"targets": [0], "className": "text-center" }
                ],
                "dom": "",
                "initComplete": function(settings, json) { 
                    removeSortingPaging(this);
                }                               
              }).clear();
              
              // Load the Datatable
              for (var j = 0; j < data.groundsOfOppositionList.length; j++){
                $('#citedMark_list_table_id').DataTable().row.add( [
                    '<input type="radio" name="id" onclick="enableSubmitButton();" value="' + j + '">',
                    data.groundsOfOppositionList[j].filingNumber
                 ]).draw();
              }
            
          } else {  // Success a Single Cited Mark was added .... reload /redisplay the cited marks data
              var param = ctx + "/obtainCitedMarks?addAnotherMark=false";
              $('#citedMarksTable').dataTable( {
                "bDestroy": true,
                "ajax":  {"url": param},
                "searching" :false,
                "bInfo" : false,
                "pageLength": 100,
                "ordering":false,
                "oLanguage" : dataTableoLanguage,
                "dom": "",
                "initComplete":function( settings, json){
                    // Set the window location to the LAST Cited Mark on the Screen.
                    window.location.hash = $(".citedMarkh2:last").attr("id");
                },
                "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap" }]
              });
          }
      }
    });
    
  }
  
