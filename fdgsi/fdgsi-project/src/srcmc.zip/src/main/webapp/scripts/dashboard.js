function reloadCurrentPage()
    {
        //console.log("reloading my tasks page");
    
    $('#manualTaskDatatable').DataTable( {         
                "bDestroy": true,   
                "order" : [[4, "asc" ],[1, "asc" ],[2, "asc"],[3, "asc"]],
                /* "stateSave": true,  */
                 "columnDefs": [
                            {"targets": [0,5,7,8], "orderable": false },
                            {"targets": [0,7,8], "width": "2%" },
                            {"targets": [1,2,6,4], "width": "10%" },
                            {"targets": [3,5], "width": "27%" },
                            {"targets": [0,7,8], "className": "text-center" }
                            ],          
                "deferRender": true, 
                "filter": false,
                "serverSide": true,    
                "oLanguage" : dataTableoLanguage,
                "ajax": {"url" :"/app/cipo/tm/madridconsole/mytasks/mytaskstabledata/2",
                     "data": function ( data ) {
                            data.id_filter_iair = $('#id_filter_iair').val();
                            data.id_filter_referfileid = $('#id_filter_referfileid').val();
                            data.startdate = $('#startdate').val();
                            data.enddate = $('#enddate').val();
                            data.id_filter_status = $('#id_filter_status').val();
                            data.id_filter_desc = $('#id_filter_desc').val();
                            //data.id_filter_group = $('#id_filter_group').val();
                           // data.id_filter_claimed = $('#id_filter_claimed').val();
                           // data.id_filter_users = $('#id_filter_users').val();
                        },
                        "error": function (xhr, textStatus, errorThrown) {
                          showErrorMessageWithoutStatusCode(xhr.responseText);
                        }
                    },
                "dom": "<\"top\"il>rt<\"bottom\"fp><\"clear\">",
                "initComplete": function(settings, json){ 
                    removeSortingPaging(this);
                }
                    
    } );
    
    updateButtons();
    
     //console.log("reloading page");
}

function unclaimtasks() {
   
    $('html, body').css("cursor", "wait");  
    $.ajax({
            url: "/app/cipo/tm/madridconsole/mytasks/unclaimtasks?"+getSelectedTaskIds('#manualTaskDatatable'),
            method: 'post',
            async: true, 
            contentType: "application/json",
            success: function(response) {
              
                $('html, body').css("cursor", "default");  
              
                //alert("success " + response.status);
                displayMessage(response);
                
                // redisplay the datatables
                reloadCurrentPage();
            },
            error: function(response) {                     
                //alert("error "+response.status);
                showErrorMessage(response.message);
            }
        });
}

// this will check if the user is a supervisor so that certain filter options can be hidden 
function hideFilterOptionsForSupervisor()
{
     $.getJSON("/app/cipo/tm/madridconsole/dashboard/issuper",function(responseText) {
            // hide the assign tasks and unassign tasks buttons
            if(responseText.issuper == true) {
                
                //console.log("hide filter options for supervisor on my tasks");
                // hide filter group
                $('#lbl_filter_group').hide();
                $('#id_filter_group').val('');
                $('#id_filter_group').hide();
                
                // hide filter users
                $('#lbl_filter_users').hide();
                $('#id_filter_users').val('');
                $('#id_filter_users').hide();
                
                // hide filter claimed/unclaimed
                $('#lbl_filter_claimed').hide();
                $('#id_filter_claimed').val('');
                $('#id_filter_claimed').hide();
            }
    }); 
}

// update the buttons based on what the status filter option is. If Unprocessed or All, enable, else disable    
function updateButtons() {
            
    //console.log("updating buttons " + checkStatusFilter());
    $('#unclaimtasks_id').prop('disabled', !checkStatusFilter());
}

// Just need a dummy function here as its called by filter.jsp and nothing additional needs to be done on this page
function resetAdditonalFilters() {
}
