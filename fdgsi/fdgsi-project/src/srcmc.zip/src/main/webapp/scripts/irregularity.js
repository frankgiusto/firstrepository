function confirmClicked() {

  if ($('#sendIrregualrityResponse').is(':checked')) {
    $("#proceedSelection").css({'display' : "none" });
    $("#irregularitySelection").css({'display' : "none" });
  } else {  // if Correct Irregularity and Re-Send the Message to IB 
    if ($('#correctIrregularity').is(':checked')) {
      $("#irregularityCommentsInputReq").css({'display' : "none" });
      $("#errorSummaryDiv").css({'display' : "none" });
      $("#proceedSelection").css({'display' : "none" });
      $("#irregularitySelection").css({'display' : "none" });
      $("#confirmAcknowledgeIrregularity").css({'display' : "block" });
    } else {  // if Acknowledge irregularity
      document.getElementById("irregularityform").submit(); 
    }
  }

  if ($('#sendIrregualrityResponse').is(':checked')) {
    $("#irregularityComments").css({'display' : "block"});
    $("#irregularityCommentsSelection").css({'display' : "block" });
  }
}

function cancelIrregularityResponse() {
  $("#irregularityComments").css({'display' : "none"});
  $("#irregularityCommentsSelection").css({'display' : "none" });
  $("#proceedSelection").css({'display' : "block" });
  $("#irregularitySelection").css({'display' : "block" });
  $("#irregularityCommentsInputReq").css({'display' : "none" });
  $("#errorSummaryDiv").css({'display' : "none" });
}

function cancelAcknowledgeResponse (){
  
  $("#proceedSelection").css({'display' : "block" });
  $("#irregularitySelection").css({'display' : "block" });
  $("#confirmAcknowledgeIrregularity").css({'display' : "none" });

}

function submitForm() {
  

  document.getElementById("irregularityform").submit(); 
}