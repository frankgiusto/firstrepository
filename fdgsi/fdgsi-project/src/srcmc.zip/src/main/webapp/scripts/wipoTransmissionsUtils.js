function validateStartAndEndDate(displayTab) {
  var startDate = $('#'+ displayTab + 'startdate' ).val();
  var endDate = $('#'+ displayTab + 'enddate' ).val();

  $("#" + displayTab + "ErrorSummaryDiv").css({ 'display': "none" });

  if ($('#' + displayTab + 'periodcode').val() == 0) {
        if ((Date.parse(endDate) < Date.parse(startDate))) {
            $("#" + displayTab + "ErrorSummaryDiv").css({ 'display': "block" });
          return false;
      } else {
          return true;
      }
  } else {
      return true;
  }    
}

function searchPackages() {
  
    // Check which Panel is currently being displayed.
    displayTab = activeTab();

    // Hide all Status Messages.
    hideAllStatusMessages(displayTab);
    
    if (!validateStartAndEndDate(displayTab)) {
        return;
    }

    // If there ever is a problem loading of the table. 
    $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) { 
        $("#errorModal").show();
    };
    
   var pkgDefaultOrder;
    
    if (displayTab == "bulletin") {
      pkgDefaultOrder =  [
        4, "desc"
      ]
    }
    else {
      pkgDefaultOrder =  [
          2, "desc"
      ]
    }
    
    var param = ctx + "/package/bulletinpackagetabledata?typelist="+$("#"+ displayTab +"typecode").val()+"&&periodlist="+$("#"+ displayTab +"periodcode").val()+"&&statuslist="+$("#"+ displayTab +"statuscode").val()+"&&startdate="+$("#"+ displayTab +"startdate").val()+"&&enddate="+$("#"+ displayTab +"enddate").val();
    $('#'+ displayTab +'packagetabledata').dataTable( {
         "bDestroy": true,
         "ajax":  {"url": param,
           "error": function (xhr, textStatus, errorThrown) {
             showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
             // RE-enable the search button 
             enableSearchButton('#'+ displayTab +"SerachButton", false);
           }
         },
         "searching" :true,
          "ordering":true, 
          "bInfo" : true,
          "initComplete": function(settings, json){  
              removeSortingPaging(this);
              // RE-enable the search button 
              enableSearchButton('#'+ displayTab +"SerachButton", false);
          },
          "oLanguage" : dataTableoLanguage,
          "order": [pkgDefaultOrder],
          "dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
          "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap" }]
    } );
    
    // Display the bulletin search Results
    $("#" + displayTab + "SearchList").css({ 'display': "block" });
    
}


function getTransactionData(packageid)
{
  
  // Check which Panel is currently being displayed.
  displayTab = activeTab();
  
  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);
  
  // Disable the bulletin search and results
  $("#" + displayTab + "Serach, #" + displayTab + "SearchList").css({ 'display': "none" });
  
  // Enable the Pack Detail Display and Transactions List  
  $("#" + displayTab + "PackageDisplay, #" + displayTab + "transactionList, #" + displayTab + "PreviousButton ").css({ 'display': "block" });
  
  // Get Package Detail information (for top of screen)
  $.ajax({
      url:  ctx + "/package/getPackageDetail?packageid="+packageid,
      cache: false,
      type: "GET",
      success: function(data){
          $('#' + displayTab + 'pkgId').text(data.pkgId);
          $('#' + displayTab + 'pkgfilename').text(data.pkgfilename);
          $('#' + displayTab + 'pkgType').text(data.pkgType);
          $('#' + displayTab + 'pkgPbltnDate').text(data.pkgPbltnDate);
          $('#' + displayTab + 'pkgTransDate').text(data.pkgTransDate);
          $('#' + displayTab + 'pkgTransStatus').text(data.pkgTransStatus);
      },
      error: function (xhr, textStatus, errorThrown) {
        showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
      }
    });
  
    // Get Transaction List information (for the bottom of the screen), based on the Package Id.
    var param = ctx + "/transaction/bulletinTransactiontabledatpasspkgid?packageid="+packageid;;
    $('#' + displayTab + 'transactionlisttabledata').dataTable( {
        "bDestroy": true,
         "ajax":  {"url": param,
             "error": function (xhr, textStatus, errorThrown) {
               showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
             }
         },
          "searching" :true,
          "ordering":true, 
          "bInfo" : true,
          "initComplete": function(settings, json){   
            removeSortingPaging(this);
          },
          "oLanguage" : dataTableoLanguage,
          "dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
          "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap"}] 
    });

    //Scroll to the top
    $(window).scrollTop(0);
    
}

function getTransactionDetailData(transid)
{

  // Check which Panel is currently being displayed.
  displayTab = activeTab();

  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);
  
  // Disable the bulletin search and results
  $("#" + displayTab + "transactionList, #" + displayTab + "PackageDisplay").css({ 'display': "none" });

  // Enable the PackDisplay and Transactons List  
  $("#" + displayTab + "transactionDetailList, #" + displayTab + "transactionPackageDisplay, #" + displayTab + "PreviousButton").css({ 'display': "block" });

  // Get Trans Details (for top of screen), based on the Trans Id.
  $.ajax({
      url:  ctx + "/transaction/getTransDetails?transid="+transid,
      cache: false,
      type: "GET",
      success: function(data){
          $('#' + displayTab + 'transid').text(data.transid);
          $('#' + displayTab + 'transType').text(data.transType);
          $('#' + displayTab + 'transCreateDate').text(data.transCreateDate);
          $('#' + displayTab + 'transUpdatedDate').text(data.transUpdatedDate);
          $('#' + displayTab + 'transrnumber').text(data.transrnumber);
          if (displayTab == "OfficetoIB" ) {
            $('#' + displayTab + 'transDomesticApplNumb').text(data.transDomesticApplNumb);
          } else {
            $('#' + displayTab + 'transrecordid').text(data.transrecordid);
          }  
          $('#' + displayTab + 'transstatus').text(data.transstatus);
      },
      error: function (xhr, textStatus, errorThrown) {
        showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
      }
  });

  // Get Transaction EVENT List information (for the bottom of the screen), based on the Trans Id.
  var param = ctx + "/transaction/bulletinTransactiondetail/?transid="+transid;
 $('#' + displayTab + 'eventlisttabledata').dataTable( {
         "bDestroy": true,
         "ajax":  {"url": param,
             "error": function (xhr, textStatus, errorThrown) {
               showErrorMessageWithoutStatusCode(xhr.responseText);
             }
          },
          "searching" :true,
          "ordering":true,
          "bInfo" : true,
          "initComplete": function(settings, json){ 
            removeSortingPaging(this);
          },
          "oLanguage" : dataTableoLanguage,
          "dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
          "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap"}] 
    });

 //Scroll to the top
 $(window).scrollTop(0);

}


function getPackageEventsData(packageId)
{
  // Check which Panel is currently being displayed.
  displayTab = activeTab();

  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);

  // Disable the bulletin search and results
  $("#" + displayTab + "Serach, #" + displayTab + "SearchList").css({ 'display': "none" });
  
  // Enable the Pack Detail Display and Events List  
  $("#" + displayTab + "PackageDisplay, #" + displayTab + "packageDetailList, #" + displayTab + "PreviousButton ").css({ 'display': "block" });
  
  // Get Package Detail information (for top of screen)
  $.ajax({
      url:  ctx + "/package/getPackageDetail?packageid="+packageId,
      cache: false,
      type: "GET",
      success: function(data){
          $('#' + displayTab + 'pkgId').text(data.pkgId);
          $('#' + displayTab + 'pkgfilename').text(data.pkgfilename);
          $('#' + displayTab + 'pkgType').text(data.pkgType);
          $('#' + displayTab + 'pkgPbltnDate').text(data.pkgPbltnDate);
          $('#' + displayTab + 'pkgTransDate').text(data.pkgTransDate);
          $('#' + displayTab + 'pkgTransStatus').text(data.pkgTransStatus);
      },
      error: function (xhr, textStatus, errorThrown) {
        showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
      }
    });
  
  // Get Package EVENT List information (for the bottom of the screen), based on the Package Id.
  var param = ctx + "/package/bulletinPackageEventsdetail/?packageid="+packageId;
 $('#' + displayTab + 'packageeventlisttabledata').dataTable( {
         "bDestroy": true,
         "ajax":  {"url": param,
             "error": function (xhr, textStatus, errorThrown) {
               showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
             }
          },
          "searching" :false,
          "ordering":true,
          "bInfo" : true,
          "initComplete": function(settings, json){ 
              removeSortingPaging(this);
          },
          "oLanguage" : dataTableoLanguage,
          "dom": "<\"top\"il>rt<\"bottom\"fp><\"clear\">",
          "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap"}] 
    });
    //Scroll to the top
    $(window).scrollTop(0);
  
}

function getPackageErrorEventData(packageId, eventId) {

  // Check which Panel is currently being displayed.
  displayTab = activeTab();
  
  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);
  
$.ajax({
       url:  ctx + "/package/getPackageErrorEventData?packageId="+packageId   +"&&eventId="+eventId,
       cache: false,
       type: "GET",
       success: function(data){
           //Scroll to the top
           $(window).scrollTop(0);
           document.getElementById(displayTab + 'MessageContent').innerHTML = data.additionalInfo;
           $("#" + displayTab + "InfoModal").show();
         },
         error: function (xhr, textStatus, errorThrown) {
             showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
         }
   });

}


 function getErrorEventlData(transId, eventId) {
 
   // Check which Panel is currently being displayed.
   displayTab = activeTab();
   
   // Hide all Status Messages.
   hideAllStatusMessages(displayTab);
   
 $.ajax({
        url:  ctx + "/transaction/getErrorEventlData?transId="+transId   +"&&eventId="+eventId,
        cache: false,
        type: "GET",
        success: function(data){
            //Scroll to the top
            $(window).scrollTop(0);
            document.getElementById('messageContent').innerHTML = data.additionalInfo;
            $("#myModal").show();
          },
          error : function (xhr, textStatus, errorThrown) {
              showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
          }
    });
 
 }
 

 function getTransactionDetailAttachmentData(transid)
 {
   // Check which Panel is currently being displayed.
   displayTab = activeTab();

   // Hide all Status Messages.
   hideAllStatusMessages(displayTab);
   
     // Disable the bulletin search and results
     $("#" + displayTab + "transactionList, #" + displayTab + "PackageDisplay").css({ 'display': "none" });

     // Enable the PackDisplay and Transactons List  
     $("#" + displayTab + "transactionAttachmentList, #" + displayTab + "transactionPackageDisplay, #" + displayTab + "PreviousButton").css({ 'display': "block" });


     // Get Trans Details (for top of screen), based on the Trans Id.
     $.ajax({
         url:  ctx + "/transaction/getTransDetails?transid="+transid,
         cache: false,
         type: "GET",
         success: function(data){
             $('#' + displayTab + 'transid').text(data.transid);
             $('#' + displayTab + 'transType').text(data.transType);
             $('#' + displayTab + 'transCreateDate').text(data.transCreateDate);
             $('#' + displayTab + 'transUpdatedDate').text(data.transUpdatedDate);
             $('#' + displayTab + 'transrnumber').text(data.transrnumber);
             if (displayTab == "OfficetoIB" ) {
               $('#' + displayTab + 'transDomesticApplNumb').text(data.transDomesticApplNumb);
             } else {
               $('#' + displayTab + 'transrecordid').text(data.transrecordid);
             }  
             $('#' + displayTab + 'transstatus').text(data.transstatus);
         },
         error: function (xhr, textStatus, errorThrown) {
           showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
         }
     });

     // Get Transaction ATTACHMENT List information (for the bottom of the screen), based on the Trans Id.
     var param = ctx + "/transaction/bulletinTransactionattachetail/?transid="+transid;
     $('#' + displayTab + 'attachmentlisttabledata').dataTable( {
          "bDestroy": true,
          "ajax":  {"url": param,
              "error": function (xhr, textStatus, errorThrown) {
                showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
              }
           },
           "searching" :true,
           "ordering":true, 
           "bInfo" : true,
           "initComplete": function(settings, json){ 
               removeSortingPaging(this);
           },
           "oLanguage" : dataTableoLanguage,
           "dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
           "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap"}] 
     });
     
     //Scroll to the top
     $(window).scrollTop(0);
     
 }


 
 
function getPackageAttachmentData(packageid)
{
  // Check which Panel is currently being displayed.
  displayTab = activeTab();
  
  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);

  // Disable the search and results
  $("#" + displayTab + "Serach, #" + displayTab + "SearchList").css({ 'display': "none" });

  // Enable the Pack Detail Display and A List  
  $("#" + displayTab + "PackageDisplay, #" + displayTab + "packageAttachmentList, #" + displayTab + "PreviousButton ").css({ 'display': "block" });
    
  // Get Package Detail information (for top of screen)
  $.ajax({
      url:  ctx + "/package/getPackageDetail?packageid="+packageid,
      cache: false,
      type: "GET",
      success: function(data){
          $('#' + displayTab + 'pkgId').text(data.pkgId);
          $('#' + displayTab + 'pkgfilename').text(data.pkgfilename);
          $('#' + displayTab + 'pkgType').text(data.pkgType);
          $('#' + displayTab + 'pkgPbltnDate').text(data.pkgPbltnDate);
          $('#' + displayTab + 'pkgTransDate').text(data.pkgTransDate);
          $('#' + displayTab + 'pkgTransStatus').text(data.pkgTransStatus);
      },
      error: function (xhr, textStatus, errorThrown) {
        showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
      }
    });
    
    // Get Attachment List information (for the bottom of the screen), based on the Package Id.
    var param = ctx + "/package/bulletinPackagetabledatpasspkgid?packageid="+packageid;
    $('#' + displayTab + 'packageattachmentlisttabledata').dataTable( {
         "bDestroy": true,
         "ajax":  {"url": param,
             "error": function (xhr, textStatus, errorThrown) {
               showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
             }
          },
          "searching" :true,
          "ordering":true, 
          "bInfo" : true,
          "initComplete": function(settings, json){ 
              removeSortingPaging(this);
          },
          "oLanguage" : dataTableoLanguage,
          "dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
          "columnDefs": [{"orderable": false, "targets": -1, class: "nowrap"}] 
    });

    //Scroll to the top
    $(window).scrollTop(0);

    
}


function onDateSelectChange(nameSelect)
{
 
    // Check which Panel is currently being displayed.
    displayTab = activeTab();
    
    // Hide all Status Messages.
    hideAllStatusMessages(displayTab);

    //if (nameSelect && nameSelect.selectedIndex) {
    var val = nameSelect.options[nameSelect.selectedIndex].value;

    if ($('#' + displayTab + 'periodcode').val() == 0) { $('#' + displayTab + 'AdmDivCheck').prop('hidden', false); } else { $('#' + displayTab + 'AdmDivCheck').prop('hidden', true); }  
            
    if(val == '0' || val == null){
        var dateNewFormat, onlyDate, today = new Date();
        dateNewFormat = today.getFullYear() + '-' + (today.getMonth() + 1);

        onlyDate = today.getDate();

        if (onlyDate.toString().length == 2) {
            dateNewFormat += '-' + onlyDate;
        }
        else {
            dateNewFormat += '-0' + onlyDate;
        }
        
        $('#' + displayTab + 'enddate').val(dateNewFormat);      
    }
}
            
 
function goToPrevious()
{
  
  // Check which Panel is currently being displayed.
  displayTab = activeTab();
  
  if ((document.getElementById(displayTab +"transactionList").style.display === 'block')  ||
     (document.getElementById(displayTab +"packageAttachmentList").style.display === 'block') ||
     (document.getElementById(displayTab +"packageDetailList").style.display === 'block'))
  {
  
    // Disable the Pack Detail Display and Transactons List 
    $("#" + displayTab + "PackageDisplay, #" + displayTab + "transactionList, #" + displayTab + "packageAttachmentList, #" + displayTab + "packageDetailList, #" + displayTab + "PreviousButton").css({ 'display': "none" });

    // Enable the bulletin search and results   
    $("#"  + displayTab + "Serach, #"  + displayTab +  "SearchList").css({ 'display': "block" });
  
  } else 
  if ((document.getElementById( displayTab + "transactionDetailList").style.display === 'block') ||
      (document.getElementById( displayTab + "transactionAttachmentList").style.display === 'block'))  
  {

    // Disable the Transaction Detail Display and Transactons Detail    
    $("#" + displayTab + "transactionDetailList, #" + displayTab + "transactionAttachmentList, #" + displayTab + "transactionPackageDisplay ").css({ 'display': "none" });

    // Enable the Package Detail and the Transaction List   
    $("#" + displayTab + "transactionList, #" + displayTab + "PackageDisplay").css({ 'display': "block" });
   
  }

  //Scroll to the top
  $(window).scrollTop(0);
  
}

function enableSearchButton(button, flag) {

   $(button).prop("disabled", flag);
   
}

function getFinancialTransactionData(packageid){

  
  // Check which Panel is currently being displayed.
  displayTab = activeTab();
  
  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);
  
  // Disable the Financial Search and Results
  $("#financialSerach, #financialSearchList").css({ 'display': "none" });

  // Enable the Financial Detail Display  
  $("#financialDetails, #financialDetailsPreviousButton").css({ 'display': "block" });
  
  // Get Financial information 
  $.ajax({
      url:  ctx + "/transaction/financialTransactiontabledatpasspkgid?packageid="+packageid,
      cache: false,
      type: "GET",
      success: function(data){
          $('#pkgId').text(data.pkgId);
          $('#pkgfilename').text(data.pkgfilename);
          $('#pkgType').text(data.pkgType);
          $('#pkgPbltnDate').text(data.pkgPbltnDate);
          $('#pkgTransDate').text(data.pkgTransDate);
          $('#pkgTransStatus').text(data.pkgTransStatus);
          
          $("#urlofimport, #urlofgappdf, #urlofgapxsl, #noreportsavaiable").css({ 'display': "none" });
            
          if (typeof data.urlofimport !== 'undefined'){
              $("#urlofimport").css({ 'display': "block" });
               document.getElementById("urlofimporthref").href = data.urlofimport;
          } 
           
          if(typeof data.urlofgappdf !== 'undefined'){
              $("#urlofgappdf").css({ 'display': "block" });
               document.getElementById("urlofgappdfhref").href = data.urlofgappdf;
           }
          if(typeof data.urlofgapxsl !== 'undefined'){
              $("#urlofgapxsl").css({ 'display': "block" });
               document.getElementById("urlofgapxslhref").href = data.urlofgapxsl;
           }
          if ((typeof data.urlofimport === 'undefined') && (typeof data.urlofgappdf === 'undefined') && (typeof data.urlofgapxsl === 'undefined')){
              $("#noreportsavaiable").css({ 'display': "block" });
          }
      
      },
      error : function (xhr, textStatus, errorThrown) {
        showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
      }
  
  });

  //Scroll to the top
  $(window).scrollTop(0);

}

function goToFinancialPrevious()
{
if (document.getElementById("financialDetails").style.display === 'block')
{

  // Disable the Pack Detail Display and Transactons List 
  $("#financialDetails, #financialPreviousButton").css({ 'display': "none" });

  // Enable the bulletin search and results   
  $("#financialSerach, #financialSearchList").css({ 'display': "block" });

  //Scroll to the top
  $(window).scrollTop(0);
} 

}
         
function activeTab() {

  var attr = document.getElementById("tab-panel-ibtooffice").attributes;
  if (attr['aria-hidden'].value === "false") {
    return  "bulletin";
  }
  
  attr = document.getElementById("tab-panel-officetoib").attributes;
  if (attr['aria-hidden'].value === "false") {
    return  "OfficetoIB";
  }   

  attr = document.getElementById("tab-panel-financial").attributes;
  if (attr['aria-hidden'].value === "false") {
    return  "financial";
  }   

  
}


function searchFinancialPackages() {
    
  // Check which Panel is currently being displayed.
  displayTab = activeTab();

  // Hide all Status Messages.
  hideAllStatusMessages(displayTab);
  
  if (!validateStartAndEndDate(displayTab)) {
    return;
  }
  
  // If there ever is a problem loading of the table.
  $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) { 
      $("#errorModal").show();
  };

  var param = ctx + "/package/financialpackagetabledata/?typelist="+$("#typecode").val()+"&&periodlist="+$("#financialperiodcode").val()+"&&statuslist="+$("#statuscode").val()+"&&startdate="+$("#financialstartdate").val()+"&&enddate="+$("#financialenddate").val();
  $('#financepackagetabledata').dataTable( {
      "bDestroy": true,
       "ajax":  {"url": param,
           "error": function (xhr, textStatus, errorThrown) {
             showErrorMessageWithoutStatusCode(displayTab, xhr.responseText);
             // RE-enable the search button 
             enableSearchButton('#'+ displayTab +"SerachButton", false);
           }
        },
        "searching" :true,
        "ordering":true, 
        "bInfo" : true,
        "initComplete": function(settings, json){ 
          removeSortingPaging(this);
          // RE-enable the search button 
          enableSearchButton('#'+ displayTab +"SerachButton", false);
        },
        "oLanguage" : dataTableoLanguage,
        "order": [[2,"desc"]],
        "dom": "<\"top\"ilf>rt<\"bottom\"p><\"clear\">",
        "columnDefs": [{"orderable": false, "targets": -1 , class: "nowrap"}] 
  } );

  // Display the bulletin search Results
  var financialSearchList  = document.getElementById("financialSearchList");
  financialSearchList.style.display = "block";

  
}

