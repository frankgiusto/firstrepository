function reloadCurrentPage()
{
  $('#taskBucketDatatable').DataTable( {  
      "bDestroy": true,   
      "columnDefs": [
                  {"targets": [0,5,8,9], "orderable": false },
                  {"targets": [0,8,9], "width": "2%" },
                  {"targets": [1,2,7,4], "width": "10%" },
                  {"targets": [3,5], "width": "18%" },
                  {"targets": [7], "width": "18%" },
                  {"targets": [0,8,9], "className": "text-center" }],                             
          filter : false,
          "oLanguage" : dataTableoLanguage,
          order : [[4, "asc" ],[1, "asc" ],[2, "asc"], [6,"asc"],[3, "asc"]],
          "serverSide": true,  
          "ajax": {"url" :"/app/cipo/tm/madridconsole/taskbucket/buckettabledata/3",
                   "data": function ( data ) {
                          data.id_filter_iair = $('#id_filter_iair').val();
                          data.id_filter_referfileid = $('#id_filter_referfileid').val();
                          data.startdate = $('#startdate').val();
                          data.enddate = $('#enddate').val();
                          data.id_filter_status = $('#id_filter_status').val();
                          data.id_filter_group = $('#id_filter_group').val();
                          data.id_filter_claimed = $('#id_filter_claimed').val();
                          data.id_filter_users = $('#id_filter_users').val();
                          data.id_filter_desc = $('#id_filter_desc').val();
                      },
                      "error": function (xhr, textStatus, errorThrown) {
                        showErrorMessageWithoutStatusCode(xhr.responseText);
                    }
                  },
          "dom": "<\"top\"il>rt<\"bottom\"fp><\"clear\">",
          "initComplete": function(settings, json){ 
              removeSortingPaging(this);
          }
  } );
  updateButtons();
  //console.log('reloading page');
}

// this will check if the user is not a supervisor so that certain buttons can be hidden    
function hideButtonsBasedOnRole()
{
   $.getJSON("/app/cipo/tm/madridconsole/dashboard/issuper",function(responseText) {
          // hide the assign tasks and unassign tasks buttons
          //console.log("hiding buttons");
          if(responseText.issuper == false) {
              $('#assigntasks_id').hide();
              $('#reassigngroup_id').hide();
              $('#unassigntasks_id').hide();
          } else {
             //console.log("hiding buttons for super");
              $('#id_filter_group option[value="All"]').remove();
              
              // set the current role/group to the last Retrieved Group so that if it changes, we can update users list       
              $("#lastRetrievedGroup").val($("#role_select").val());  
              $("#lastFilterGroup").val($("#role_select").val());
              //console.log("Last ret = " + $('#lastRetrievedGroup').val());
            }
    }); 
}

// this is called when the tasks are being assigned/claimed
function checkForUncompletedTasks(claimOrAssign) {
  
  var irNums = new Array();
  $("input:checkbox:checked").each(function () {
    
    var chkid = $(this).attr("id");
    var tokens = chkid.split("selection");
    
    if(tokens.length == 2) {
      irNums.push(tokens[1]);
    }
  });
 
  if(irNums.length == 0) {
    showMessage(claimOrAssign);
    return;
  }
  var actIds = new Array();
  $("input:checkbox:checked").each(function () {

    actIds.push($(this).attr("name"));
  });
 
  getUnprocessedTasksForMultipleIRs(irNums, actIds, claimOrAssign);
}

function claimtasks() 
{
  
  $('html, body').css("cursor", "wait");  
  
  $.ajax({
          url: "/app/cipo/tm/madridconsole/taskbucket/claimtasks?"+getSelectedTaskIds('#taskBucketDatatable'),
          method: 'post',
          async: true, 
          contentType: "application/json",
          success: function(response) {

              $('html, body').css("cursor", "default");  
            
              displayMessage(response);
              
              // redisplay the datatables
              reloadCurrentPage();
          },
          error: function(response) {                     
              showErrorMessage(response.message);
          }
      });
}

function assigntasks() 
{
  //console.log("Last value = " + $('#lastRetrievedGroup').val());
  //console.log("current value = " + $('#lastFilterGroup').val());
  if($("#lastRetrievedGroup").val() == '') {
      $("#lastRetrievedGroup").val($("#role_select").val());
      $("#lastFilterGroup").val($("#role_select").val());
  }
  
  // reload users only if the filter group has changed from the last retrieved one
  if($('#lastFilterGroup').val() != $('#lastRetrievedGroup').val()) {
      //console.log("reloading users");
      reloadUsers();
      $("#lastRetrievedGroup").val($("#lastFilterGroup").val());
  }
  //console.log("assign tasks = " + $('#lastFilterGroup').val());
}

function reassigntaskstogroup() 
{
  // TODO reload groups should be done on the tasks selected.  
  //console.log("Last value = " + $('#lastRetrievedGroup').val());
  //console.log("current value = " + $('#lastFilterGroup').val());
  if($("#lastRetrievedGroup").val() == '') {
      $("#lastRetrievedGroup").val($("#role_select").val());
      $("#lastFilterGroup").val($("#role_select").val());
  }
  
  // reload groups only if the filter group has changed from the last retrieved one
  if($('#lastFilterGroup').val() != $('#lastRetrievedGroup').val()) {
      //console.log("reloading users");
      //reloadGroups();
      $("#lastRetrievedGroup").val($("#lastFilterGroup").val());
  }
  //console.log("assign tasks = " + $('#lastFilterGroup').val());
}

function unassigntasks() {
  
  $('html, body').css("cursor", "wait");  
  $.ajax({
    url: $('#contextpath_id').val()+"/taskbucket/unassigntasks?"+getSelectedTaskIds('#taskBucketDatatable'),
    method: 'post',
    async: true, 
    contentType: "application/json",
    success: function(response) {
      
        $('html, body').css("cursor", "default");  
      
        //alert("success " + response.status);
        displayMessage(response);
        
        // redisplay the datatables
        reloadCurrentPage();
    },
    error: function(response) {                     
        //alert("error "+response.status);
        showErrorMessage(response.message);
    }
  });
}

// update the buttons based on what the status filter option is. If Unprocessed or All, enable, else disable    
function updateButtons() 
{
  $('#claimtasks_id').prop('disabled', !checkStatusFilter());
  $('#assigntasks_id').prop('disabled', !checkStatusFilter());
  $('#reassigngroup_id').prop('disabled', !checkStatusFilter());
  $('#unassigntasks_id').prop('disabled', !checkStatusFilter() || checkAssignedToFilter() );
}

// Just need a dummy function here as its called by filter.jsp and nothing additional needs to be done on this page
function resetAdditonalFilters() 
{
}
      