# TODO - Describe the steps to follow for proper configuration

Configuration files for CIPO-tm-madrid-console module

Please follow the steps below for an initial setup:

1- Copy config.properties under /cipo/config/

