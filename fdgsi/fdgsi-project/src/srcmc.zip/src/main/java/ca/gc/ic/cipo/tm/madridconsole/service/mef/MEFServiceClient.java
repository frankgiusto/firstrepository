package ca.gc.ic.cipo.tm.madridconsole.service.mef;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.irpi.GetIRPIURLSession;
import ca.gc.ic.cipo.tm.irpi.IRPIServiceFactory;
import ca.gc.ic.cipo.tm.irpi.IRPIURLSessionRequest;
import ca.gc.ic.cipo.tm.irpi.IRPIURLSessionResponse;
import ca.gc.ic.cipo.tm.irpi.TMUserId;
import ca.gc.ic.cipo.tm.irpi.TMUserIdType;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.util.ServiceUtil;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

/**
 * The Class MEFServiceClient is a Trademark IRPI/MEF Service web service client.
 *
 * @author kaurs
 */
@Service
public class MEFServiceClient {

    /** The mef/irpi host name. Gets the host name from the intl database INTL_CNFGN_PARM table */
    @Value("${mc.tm.irpi.services.host.name}")
    private String irpiHostName;

    @Autowired
    SendErrorEmail sendErrorEmail;

    /** The logger. */
    protected static Logger logger = Logger.getLogger(MEFServiceClient.class);

    /**
     * Gets the client.
     *
     * @return the client
     * @throws MCServerException
     */
    private GetIRPIURLSession getClient() throws MCServerException {

        GetIRPIURLSession client = IRPIServiceFactory.createClient(irpiHostName);

        if (client == null) {
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mef.serviceunavailable"));
        }
        return client;
    }

    /**
     * Gets the IRPIURL session for office user.
     *
     * @param username the ldap username to login
     * @return the IRPIURL session for office user
     * @throws MCServerException the MC server exception
     */
    public String getIRPIURLSessionForOfficeUser(String username) throws MCServerException {

        logger.debug("Method: getIRPIURLSessionForOfficeUser - username - " + username);

        GetIRPIURLSession client = getClient();

        // Construct the TM User Object
        TMUserId tmUser = new TMUserId();
        tmUser.setUserId(username);
        tmUser.setUserType(TMUserIdType.OFFICE_USER);

        // Construct the Request Session Object
        IRPIURLSessionRequest session = new IRPIURLSessionRequest();
        session.setUser(tmUser);

        // Call the client Service
        IRPIURLSessionResponse response = null;

        try {
            response = client.getIRPIURLSession(session);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MEF, true);
            if (response != null) {
                return response.getUrl();
            }
        } catch (ca.gc.ic.cipo.tm.irpi.CIPOServiceFault e) {
            logger.error("Method: getIRPIURLSessionForOfficeUser - CIPO service fault message for user " + username
                + ": " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MEF, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mef.launchmef"), e);
        } catch (Throwable e) {
            logger.error("Method: getIRPIURLSessionForOfficeUser - Received Throwable to MEF for user: " + username
                + " Error: " + e.getMessage());
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MEF, irpiHostName,
                "getIRPIURLSession(), username=" + username, e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mef.launchmef"), e);
        }

        return ""; // should not get here
    }

    /**
     * getHeartbeat for the MEF (Madrid E-Filing).
     *
     * @return ca.gc.ic.cipo.schema.HeartbeatResponseType
     */
    public HeartbeatResponseType getHeartbeat() throws Exception {

        logger.debug("Method: getHeartbeat for MEF");

        HeartbeatResponseType getHeartbeatResponse = new HeartbeatResponseType();
        try {
            getHeartbeatResponse = getClient().getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   " + irpiHostName);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MEF, true);
        } catch (Throwable tow) {
            getHeartbeatResponse.setIpAddress("");
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            logger.error("Method: getHeartbeat - Throwable Exception: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MEF, irpiHostName, "getHeartbeat()", tow.getMessage());
        }

        return getHeartbeatResponse;
    }
}
