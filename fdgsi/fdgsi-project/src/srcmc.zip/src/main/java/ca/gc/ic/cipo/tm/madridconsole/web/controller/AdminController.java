package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.web.exception.CustomGenericException;
import ca.gc.ic.cipo.tm.madridconsole.service.intl.IAdminPageDataTableService;

/**
 * This is the main Controller for obtaining Administration Status information.
 * 
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    private static Logger LOGGER = Logger.getLogger(AdminController.class.getName());
    
    @Autowired
    private IAdminPageDataTableService dataTableService;

 
     @RequestMapping(value = "/getheartbeat", method = RequestMethod.GET)
     public void getHeartBeatStatus(HttpServletRequest request, HttpServletResponse response) {
         
         response.setContentType("application/json;charset=ISO-8859-15");
         response.setHeader("Cache-Control", "no-store");
         PrintWriter out;
         String listHeartBeatStatus = null;
         try {
             out = response.getWriter();
             listHeartBeatStatus = dataTableService.getHeartBeatDataTableResponse();
   
             if (listHeartBeatStatus != null) {
                 out.print(listHeartBeatStatus);
             }
         } catch (Exception se) {
             LOGGER.warn("Madird Console runtime exception. check the data", se);
             throw new CustomGenericException("code1", "serviceerror");
         }
         
     }
     @RequestMapping(value = "/errorprocesses/list", method = RequestMethod.GET)
     public void getErrorProcesses(HttpServletRequest request, HttpServletResponse response) {
         
         response.setContentType("application/json;charset=ISO-8859-15");
         response.setHeader("Cache-Control", "no-store");
         PrintWriter out;
         String listHeartBeatStatus = null;
         try {
             out = response.getWriter();
             listHeartBeatStatus = dataTableService.getErrorProceeseDataTableResponse();
   
//             if (listHeartBeatStatus != null) {
                 out.print(listHeartBeatStatus);
//             }
         } catch (Exception se) {
             LOGGER.warn("Madird Console runtime exception. check the data", se);
             throw new CustomGenericException("code1", "serviceerror");
         }
         
     }
     
     @RequestMapping(value = "/sendrecovery/{executionId}", method = RequestMethod.GET)
     public void sendrecovery(@PathVariable String executionId)  {

         LOGGER.debug("Method: sendrecovery - executionId: " + executionId);
         
         try {
             dataTableService.sendrecovery(executionId);
           
         } catch (Exception se) {
             LOGGER.warn("Madird Console runtime exception. check the data", se);
             throw new CustomGenericException("code1", "serviceerror");
         }
     }
     

     @RequestMapping(value = "/jarFiles", method = RequestMethod.GET)
     public void getJarFiles(HttpServletRequest request, HttpServletResponse response) {
         Enumeration resEnum;
         
         response.setContentType("application/json;charset=ISO-8859-15");
         response.setHeader("Cache-Control", "no-store");
         PrintWriter out;
         String listHeartBeatStatus = null;
         
         try {
             out = response.getWriter();
             listHeartBeatStatus = dataTableService.getJarFilesDataTableResponse(request.getServletContext());
         
             if (listHeartBeatStatus != null) {
                 out.print(listHeartBeatStatus);
             }
         } catch (Exception se) {
             LOGGER.warn("Madird Console runtime exception. check the data", se);
             throw new CustomGenericException("code1", "serviceerror");
         }
     }
}