package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.math.BigInteger;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

@Controller
@SessionAttributes("wipogs")
public class FileNumberLockContoller {

    private static Logger logger = Logger.getLogger(FileNumberLockContoller.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    /**
     * @param request
     * @return 
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    @Autowired
    TransactionServiceClient transactionServiceClient;


    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * Release Lock for File Number/Extension/User ID.
     *
     * @param wipogs - GoodServiceWipoBean (from Session Bean)
     *
     */
    @SuppressWarnings("unused")
    @RequestMapping(value = "/releaseLock", method = RequestMethod.POST)
    public void releaseLock(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                             final ModelMap modelMap, HttpServletRequest request, Locale locale, HttpSession session,
                             HttpServletResponse response) {
        
        logger.debug("Method: releaseLock(),  fileNumber: " + gsBean.getFileNumberLocked());
        
        try {
            if (gsBean.getFileNumberLocked() != 0)
            {
                transactionServiceClient.releaseLock(gsBean);
            }
        } catch (MCServerException e) {
            logger.error("Method: releaseLock(), ERROR:  " + e.getMessage());
        }
    }

}
