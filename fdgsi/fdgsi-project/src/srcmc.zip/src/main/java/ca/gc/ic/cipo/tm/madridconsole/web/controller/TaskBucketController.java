package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.web.IDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.StatusResponse;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

/**
 * The Class TaskBucketController handles the requests from the task bucket view and returns the response.
 */
@Controller
@RequestMapping("/taskbucket")
public class TaskBucketController {

    /** The logger. */
    private static Logger logger = Logger.getLogger(TaskBucketController.class.getName());

    /** The data table service. */
    @Autowired
    private IDataTableService dataTableService;

    /** The mwe client. */
    @Autowired
    private WorkflowEngineServiceClient mweClient;

    /** The user profile service. */
    @Autowired
    private UserProfileServiceClient userProfileService;

    /**
     * Handles the request to get the Task bucket page.
     *
     * @param locale the locale
     * @param model the model
     * @return the string the jsp page to go to
     */
    @RequestMapping(value = "/taskBucket", method = RequestMethod.GET)
    public String taskBucket(Locale locale, Model model) {

        return "taskBucket";
    }

    /**
     * Handle request from task bucket page.
     *
     * @param tableNum the table num of the datatable being displayed on task bucket page
     * @param request the request
     * @param response the response
     */
    @RequestMapping(value = "/buckettabledata/{tableNum}", method = RequestMethod.GET)
    public void displayTaskBucketPage(@PathVariable int tableNum, HttpServletRequest request,
                                      HttpServletResponse response) {

        logger.debug("Method: displayTaskBucketPage");

        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");

        try {
            PrintWriter out = response.getWriter();
            out.print(dataTableService.getDataTableResponse(request, tableNum));

        } catch (MCServerException | IOException e) {

            try {
                logger.error("Method: displayTaskBucketPage with tableNum " + tableNum);
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());

            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }

    /**
     * Handles the request to claim the selected manual tasks when the user clicks the 'Assign to self' button on the
     * all tasks page. Calls the Madrid Workflow Engine Service to assign the selected tasks to the logged in user.
     *
     * @param tasklist the tasklist contains the ids of the tasks that should be assigned to the logged in user
     * @param request the http request sent when the user clicks the 'assign to self' button
     * @param response the response sent back once the tasks have been assigned
     * @param session the http session when the request is made
     */
    @RequestMapping(value = "/claimtasks", method = RequestMethod.POST)
    public @ResponseBody StatusResponse claimtasks(@RequestParam(value = "ids", required = true) List<String> tasklist,
                                                   HttpServletRequest request, HttpServletResponse response,
                                                   HttpSession session) {

        logger.debug(
            "Method: claimtasks: task ids " + tasklist + " assigned to " + userProfileService.getParentId(request));

        StatusResponse resp = new StatusResponse();

        if (tasklist.isEmpty()) {
            resp.setStatus(StatusResponse.INFO);
            resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.assigntasknone"));
        } else {
            try {
                int failedAssignments = mweClient.assignUserTask(tasklist, userProfileService.getParentId(request),
                    userProfileService.getParentId(request));
                if (failedAssignments > 0) {
                    if (tasklist.size() > 1) {
                        if (failedAssignments == tasklist.size()) { // all failed
                            resp.setStatus(StatusResponse.ERROR);
                            resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.failedtoassignall"));
                        } else {
                            resp.setStatus(StatusResponse.SUCCESS);
                            resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.failedtoassignsome"));
                        }
                    } else {
                        resp.setStatus(StatusResponse.ERROR);
                        resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.failedtoassignone"));
                    }
                } else {
                    resp.setStatus(StatusResponse.SUCCESS);
                    if (tasklist.size() > 1) {
                        resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.assigntasks"));
                    } else {
                        resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.assigntask"));
                    }
                }
            } catch (MCServerException e) {

                logger.error("Method: claimtasks: task ids " + tasklist + " assigned to "
                    + userProfileService.getParentId(request));
                logger.error("Exception: ", e);
                resp.setStatus(StatusResponse.ERROR);
                resp.setMessage(e.getMessage());
            }
        }
        return resp;
    }

    /**
     * Handles the request to assign the selected manual tasks when the supervisor clicks the 'Assign to user' button on
     * the all tasks page. Calls the Madrid Workflow Engine Service to assign the selected tasks to the selected user.
     *
     * @param tasklist the tasklist contains the ids of the tasks that should be assigned to the selected user
     * @param request the http request sent when the user clicks the 'assign to user' button
     * @param response the response sent back once the tasks have been assigned
     * @param session the http session when the request is made
     */
    @RequestMapping(value = "/assigntasks", method = RequestMethod.POST)
    public @ResponseBody StatusResponse assigntasks(@RequestParam(value = "ids", required = true) List<String> tasklist,
                                                    @RequestParam(value = "assignto", required = true) String assignTo,
                                                    HttpServletRequest request, HttpServletResponse response,
                                                    HttpSession session) {
        logger.debug("Method: assigntasks: task ids " + tasklist + " assigned to " + assignTo + " by "
            + userProfileService.getParentId(request));

        StatusResponse resp = new StatusResponse();

        if (tasklist.isEmpty()) {
            resp.setStatus(StatusResponse.INFO);
            resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.assigntasknone"));
        } else {
            try {

                mweClient.assignUserTask(tasklist, assignTo, userProfileService.getParentId(request), false);
                resp.setStatus(StatusResponse.SUCCESS);
                if (tasklist.size() > 1) {
                    resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.assigntasks"));
                } else {
                    resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.assigntask"));
                }

            } catch (MCServerException e) {

                logger.debug("Method: assigntasks: task ids " + tasklist + " assigned to " + assignTo + " by "
                    + userProfileService.getParentId(request));
                logger.error("Exception: ", e);
                resp.setStatus(StatusResponse.ERROR);
                resp.setMessage(e.getMessage());
            }
        }
        return resp;
    }

    /**
     * Handles the request to unassign the selected manual tasks when the supervisor clicks the 'Unassign from user'
     * button on the all tasks page. Calls the Madrid Workflow Engine Service to unassign the selected tasks and put it
     * back to the group.
     *
     * @param tasklist the tasklist contains the ids of the tasks that should be unassigned
     * @param request the http request sent when the user clicks the 'unassign from user' button
     * @param response the response sent back once the tasks have been unassigned
     * @param session the http session when the request is made
     */
    @RequestMapping(value = "/unassigntasks", method = RequestMethod.POST)
    public @ResponseBody StatusResponse unassigntasks(@RequestParam(value = "ids", required = true) List<String> tasklist,
                                                      HttpServletRequest request, HttpServletResponse response,
                                                      HttpSession session) {

        logger.debug("Method: unassigntasks: task ids " + tasklist + " by " + userProfileService.getParentId(request));

        StatusResponse resp = new StatusResponse();

        if (tasklist.isEmpty()) {
            resp.setStatus(StatusResponse.INFO);
            resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.unassigntasknone"));
        } else {
            try {

                mweClient.unassignUserTask(tasklist, userProfileService.getParentId(request));
                resp.setStatus(StatusResponse.SUCCESS);
                if (tasklist.size() > 1) {
                    resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.unassigntasks"));
                } else {
                    resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.unassigntask"));
                }

            } catch (MCServerException e) {

                logger.error(
                    "Method: unassigntasks: task ids " + tasklist + " by " + userProfileService.getParentId(request));
                logger.error("Exception: ", e);
                resp.setStatus(StatusResponse.ERROR);
                resp.setMessage(e.getMessage());
            }
        }
        return resp;
    }

    /**
     * Handles the request to assign the selected manual tasks when the supervisor clicks the 'Reassign group' button on
     * the all tasks page. Calls the Madrid Workflow Engine Service to assign the selected tasks to the selected group.
     *
     * @param tasklist the tasklist contains the ids of the tasks that should be assigned to the selected grou[
     * @param request the http request sent when the user clicks the 'reassign group' button
     * @param response the response sent back once the tasks have been assigned
     * @param session the http session when the request is made
     */
    @RequestMapping(value = "/assigntaskstogroup", method = RequestMethod.POST)
    public @ResponseBody StatusResponse assigntaskstogroup(@RequestParam(value = "ids", required = true) List<String> tasklist,
                                                           @RequestParam(value = "assignto", required = true) String assignTo,
                                                           HttpServletRequest request, HttpServletResponse response,
                                                           HttpSession session) {
        logger.debug("Method: assigntaskstogroup: task ids " + tasklist + " assigned to " + assignTo + " by "
            + userProfileService.getParentId(request));

        StatusResponse resp = new StatusResponse();

        if (tasklist.isEmpty()) {
            resp.setStatus(StatusResponse.INFO);
            resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.reassigntasknone"));
        } else {
            if (assignTo.equals("undefined")) {
                resp.setStatus(StatusResponse.ERROR);
                resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.reassigntaskgroup"));
            } else {
                try {

                    mweClient.reassignTaskGroup(tasklist, assignTo, userProfileService.getParentId(request));
                    resp.setStatus(StatusResponse.SUCCESS);
                    if (tasklist.size() > 1) {
                        resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.reassigntasks"));
                    } else {
                        resp.setMessage(MadridConsoleUtils.getMessage("mc.tasks.reassigntask"));
                    }

                } catch (MCServerException e) {

                    logger.debug("Method: assigntaskstogroup: task ids " + tasklist + " assigned to " + assignTo
                        + " by " + userProfileService.getParentId(request));
                    logger.error("Exception: ", e);
                    resp.setStatus(StatusResponse.ERROR);
                    resp.setMessage(e.getMessage());
                }
            }
        }
        return resp;
    }
}
