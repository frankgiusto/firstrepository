package ca.gc.ic.cipo.tm.madridconsole.service.mfs;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mfs.TMMadridFinancialFeeServicePortType;
import ca.gc.ic.cipo.tm.mfs.client.TMMadridFinancialFeeServiceFactory;

/**
 * The Class MFSServiceClient is a Trademark Financial service client.
 *
 */
@Service
public class MFSServiceClient {

    /** The MFS host name from the intl database INTL_CNFGN_PARM table */
    @Value("${mc.transaction.server}")
    private String mfsServiceHost;

    @Autowired
    SendErrorEmail sendErrorEmail;

    /** The logger. */
    protected static Logger logger = Logger.getLogger(MFSServiceClient.class);

    /**
     * Gets the TIRS client.
     *
     * @return the client
     * @throws MCServerException
     */
    private TMMadridFinancialFeeServicePortType getClient() throws MCServerException {

        TMMadridFinancialFeeServicePortType mfsClient = TMMadridFinancialFeeServiceFactory
            .createClient(mfsServiceHost);

        if (mfsClient == null) {
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mfs.serviceunavailable"));
        }
        return mfsClient;
    }

    /**
     * getHeartbeat() for MFS (fee Service).
     *
     * @return import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
     */
    public HeartbeatResponseType getHeartbeat() {

        logger.debug("Method: getHeartbeat for MFS");

        HeartbeatResponseType getHeartbeatResponse = new HeartbeatResponseType();
        try {
            getHeartbeatResponse = getClient().getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   " + mfsServiceHost);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MFS, true);

        } catch (Throwable tow) {
            tow.printStackTrace();
            getHeartbeatResponse.setIpAddress(mfsServiceHost);
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            logger.error("Method: Throwable Exception: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MFS, mfsServiceHost, "getHeartbeat()", tow.getMessage());

        }

        return getHeartbeatResponse;
    }

}
