package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationCategoryType;

public class FinalGoodsServicesWrapper {

    private boolean isFromWipo;

    private boolean isEdited;

    private int classNum;

    private GoodsServicesLimitationCategoryType goodsServicesLimitationCategoryType;

    public boolean isFromWipo() {
        return isFromWipo;
    }

    public void setFromWipo(boolean isFromWipo) {
        this.isFromWipo = isFromWipo;
    }

    public boolean isEdited() {
        return isEdited;
    }

    public void setEdited(boolean isEdited) {
        this.isEdited = isEdited;
    }

    public int getClassNum() {
        return classNum;
    }

    public void setClassNum(int classNum) {
        this.classNum = classNum;
    }

    public GoodsServicesLimitationCategoryType getGoodsServicesLimitationCategoryType() {
        return goodsServicesLimitationCategoryType;
    }

    public void setGoodsServicesLimitationCategoryType(GoodsServicesLimitationCategoryType goodsServicesLimitationCategoryType) {
        this.goodsServicesLimitationCategoryType = goodsServicesLimitationCategoryType;
    }

}
