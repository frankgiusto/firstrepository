package ca.gc.ic.cipo.tm.madridconsole.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import ca.gc.ic.cipo.schema.ADUserProfile;
import ca.gc.ic.cipo.stf.uas.ProfileResponse;
import ca.gc.ic.cipo.stf.uas.UserAuthServiceFactory;
import ca.gc.ic.cipo.stf.uas.UserAuthServicePortType;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridGroup;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;

/**
 * The Class MadridAuthenticationFilter performs authentication into the Madrid console after user submits login
 * credentials from the login page.
 *
 * @author giustof
 */
public class MadridAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    protected static Logger logger = Logger.getLogger(MadridAuthenticationFilter.class);

    @Value("${mc.ws.common.services.host.name}")
    private String commonServiceHost;

    @Autowired
    SendErrorEmail sendErrorEmail;

    @Autowired
    private UserProfileServiceClient userProfileService;

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
        throws AuthenticationException {

        logger.debug("Attempting Authentication...");

        String username = obtainUsername(request);
        String password = obtainPassword(request);

        if (username == null) {
            username = "";
        }
        if (password == null) {
            password = "";
        }
        UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);

        // Allow subclasses to set the "details" property
        setDetails(request, authRequest);

        return authenticate(request, authRequest, password);
    }

    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
                                              AuthenticationException failed)
        throws IOException, ServletException {
        super.unsuccessfulAuthentication(request, response, failed);
    }

    /**
     * Perform Authentication.
     *
     * @param auth
     * @param password
     * @return
     * @throws AuthenticationException
     */
    public Authentication authenticate(HttpServletRequest request, Authentication auth, String password)
        throws AuthenticationException {

        logger.debug("Authenticating...");

        // User logging Authentication here.
        ProfileResponse pResp = null;
        try {
            UserAuthServicePortType client = UserAuthServiceFactory.createClient(commonServiceHost);
            pResp = client.authorizeBySamId(auth.getName(), password);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.UAS, true);
        } catch (Exception e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.UAS, commonServiceHost, "authenticate()", e.getMessage());
            throw new BadCredentialsException("authentication.service.not.available");
        }

        // Check if the request succeeded
        // Handle a few of the common errors, everything else is reported
        // to the user as a general error:
        // 1) Unknown user -1,7
        // 2) Bad credentials -1,10
        // 3) Missing user id -1,12 (should be caught during JSF validation)
        // 4) Missing password -1,13 (should be caught during JSF validation)
        int returnCode = pResp.getReturnCode();
        int reasonCode = pResp.getReasonCode();

        if (returnCode < 1) {
            logger.debug(String.format("Authorization error. Return code/reason code [%s, %s] %s", returnCode,
                reasonCode, pResp.getEnErrorMsg()));

            // Since an error has occurred apply a message key
            // to the request parameters so that when the login page is
            // redisplayed a warning message may be shown to the user
            if (returnCode == -1 && reasonCode == 7) {
                throw new BadCredentialsException("authentication.message.invalid.userid");

            } else if (returnCode == -1 && reasonCode == 10) {
                throw new BadCredentialsException("authentication.message.invalid.credentials");

            } else if (returnCode == -1 && reasonCode == 12) {
                throw new BadCredentialsException("authentication.message.userid.required");

            } else if (returnCode == -1 && reasonCode == 13) {
                throw new BadCredentialsException("authentication.message.password.required");

            } else {
                // The return-reason is a system ERROR, log it
                logger.error(String.format("Error calling UAS authorizeBySamId(). Return code/reason code [%s, %s] %s",
                    returnCode, reasonCode, pResp.getEnErrorMsg()));
                throw new BadCredentialsException("authentication.service.not.available");
            }
        }

        // At this point the user is authenticated, store this LDAP profile in the session
        ADUserProfile userProfile = pResp.getUserProfile();

        // Check if the user is a valid Madrid user - connect to TUPS to verify and get the list of valid roles he has
        UserProfile profile = null;
        List<GrantedAuthority> auths = new ArrayList<GrantedAuthority>();

        try {
            profile = userProfileService.getUserProfile(auth.getName());
            if (profile != null) {

                // set the current profile
                userProfileService.setCurrentUserProfile(request, profile);
                boolean roleselected = false;

                // get the valid user authorities
                List<UserAuthority> userAuthorities = userProfileService.getUserAuthorities(profile);
                for (UserAuthority tupAuth : userAuthorities) {
                    auths.add(new SimpleGrantedAuthority(MadridGroup.getMadridGroupName(tupAuth.getIntlAuthorityRole())
                        + "-" + tupAuth.getAuthorityId()));

                    if (tupAuth.getAuthorityId().equalsIgnoreCase(profile.getAuthorityId()) && !roleselected) {

                        // set the current authority role for the drop down on the top right corner to the main profile
                        // to the first matching
                        userProfileService.setCurrentSelectedRole(request, tupAuth.getIntlAuthorityRole());
                        userProfileService.setAuthorityId(request, tupAuth.getAuthorityId());
                        roleselected = true;
                    }
                }

                /*
                 * HttpSession currentSession = request.getSession(true); if (currentSession != null) {
                 * currentSession.setAttribute("currentLoggedUserProfile", profile);
                 * currentSession.setAttribute("currentSelectedRole", userAuthorities.get(0).getIntlAuthorityRole());
                 * currentSession.setAttribute("authorityId", userAuthorities.get(0).getAuthorityId()); } else {
                 * logger.error("No session could be created"); // return; }
                 */

            }
        } catch (MCServerException e) {
            if (e.getErrorCode() == 100) {
                e.printStackTrace();
                logger.warn("Authentication Service is not available", e);
                throw new BadCredentialsException("authentication.service.not.available");
            } else {
                e.printStackTrace();
                logger.warn("Invalid credentials", e);
                throw new BadCredentialsException("authentication.message.invalid.madridcredentials");
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.warn("Authentication Service is not available", e);
            throw new BadCredentialsException("authentication.service.not.available");
        }

        logger.debug("Successful Authentication.");

        return new UsernamePasswordAuthenticationToken(auth.getName() + " (" + profile.getAuthorityId() + ")", password,
            auths/* auth.getAuthorities() */);
    }

}
