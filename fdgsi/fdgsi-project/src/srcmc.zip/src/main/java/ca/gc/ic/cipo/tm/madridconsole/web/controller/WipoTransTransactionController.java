package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.util.Locale;

import javax.activation.DataHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.service.intl.IDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.CustomGenericException;
import ca.gc.ic.cipo.tm.mps.GetAttachmentResponse;
import ca.gc.ic.cipo.tm.mts.GetTransactionAttachmentResponse;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;

@Controller
@RequestMapping("/transaction")
public class WipoTransTransactionController {

    private static Logger LOGGER = Logger.getLogger(WipoTransTransactionController.class.getName());

    @Autowired
    private IDataTableService dataTableService;

    /**|
     * This method is used to retrieve Transaction Detail information.
     * 
     */
    @RequestMapping(value = "/getTransDetails", method = RequestMethod.GET)
    public void getTransDetails(HttpServletRequest request, HttpServletResponse response,
                               @RequestParam(value = "transid", required = false) String transid,
                                Model model,
                               Locale loc, HttpSession session) {

        LOGGER.debug("Method: getTransDetails, transid: " + transid );

        String transactionDetail = null;
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;
        
        try {
            out = response.getWriter();
            transactionDetail = dataTableService.getTransactionDetail(Long.parseLong(transid), loc);

            if (transactionDetail != null) {
                out.print(transactionDetail);
            }
            
        } catch (Exception se) {
            LOGGER.error("Exception received while processing the input data of transid: " + transid  );
            LOGGER.warn("Madird Console runtime exception. check the data", se);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
           }
        }
       
    }    

    @RequestMapping(value = "/bulletinTransactiontabledatpasspkgid", method = RequestMethod.GET)
    public void getBulletinDetailInfo(@RequestParam(value = "packageid", required = true) Long packageId,
                               HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
                               HttpSession session) {
        
        LOGGER.debug("Method: bulletinTransactiontabledatpasspkgid, packageid: " + packageId );
        
        String transactionDetailList = null;
        
        model.addAttribute("packageId", packageId);
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;

        try {
            
            out = response.getWriter();
            transactionDetailList = dataTableService.getBulletinDataTableResponse( Long.toString(packageId), loc);
            
            if (transactionDetailList != null) {
                out.print(transactionDetailList);
            }
            
        } catch (Exception e) {
            LOGGER.error("Exception received while processing packageId: " + packageId  );
            LOGGER.error("Exception:", e);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }
    }

    
    @RequestMapping(value = "/financialTransactiontabledatpasspkgid", method = RequestMethod.GET)
    public void getFinancialPackageDetail(@RequestParam(value = "packageid", required = true) Long packageId,
                               HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
                               HttpSession session) {
        
        LOGGER.debug("Method: getFinancialPackageDetail, packageid: " + packageId );
        
        String financailDetail = null;
        
        model.addAttribute("packageId", packageId);
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;

        try {
            
            out = response.getWriter();
            financailDetail = dataTableService.getFinancialTransactionDetail(packageId, loc);
            
            if (financailDetail != null) {
                out.print(financailDetail);
            }
            
        } catch (Exception e) {
            LOGGER.error("Exception received while processing packageId: " + packageId  );
            LOGGER.error("Exception:", e);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }
    }

    
//    @RequestMapping(value = "/bulletinTransactiondetail", method = RequestMethod.GET)
//    public void redirectBulletinDetailView(@RequestParam(value = "transid", required = true) Long transId,
//                               HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
//                               HttpSession session)
//        throws Exception  {
//        
//        LOGGER.debug("Method: bulletinTransactiondetail, transid: " + transId );
//
//        model.addAttribute("transId", transId);
//        String eventDetailList = null; 
//        
//        response.setContentType("application/json;charset=ISO-8859-15");
//        response.setHeader("Cache-Control", "no-store");
//        PrintWriter out;
//
//        try {
//            
//            out = response.getWriter();
//            eventDetailList = dataTableService.getTransactionEventsList( Long.toString(transId), loc);
//            if (eventDetailList != null) {
//                out.print(eventDetailList);
//            }
// 
//        } catch (Exception e) {
//            LOGGER.error("Exception received while processing transId: " + transId  );
//            LOGGER.error("Exception:", e);
//        }
//
//    }

    
    @RequestMapping(value = "/bulletinTransactionattachetail", method = RequestMethod.GET)
    public void getTransactionattachetail(@RequestParam(value = "transid", required = true) String transId,
                               HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
                               HttpSession session) {
        
        LOGGER.debug("Method: getTransactionattachetail, transId: " + transId );
        
        model.addAttribute("transId", transId);
        String attachmentlList = null; 
        
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;

        try {
            
            out = response.getWriter();
            attachmentlList = dataTableService.getTransactionAttachments(Long.parseLong(transId), loc);
            if (attachmentlList != null) {
                out.print(attachmentlList);
            }
 
        } catch (Exception se) {
            LOGGER.error("Exception received while processing the input data of transId: " + transId  );
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }
    }
    
//    @RequestMapping(value = "/getErrorEventlData", method = RequestMethod.GET)
//    public void getErrorEventlData(@RequestParam(value = "transId", required = true) Long transId,
//                                   @RequestParam(value = "eventId", required = true) Long eventId,
//        HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
//        HttpSession session)
//        throws Exception  {
//        
//        LOGGER.debug("Method: getErrorEventlData, transId: " + transId  + ", eventId: " + eventId);
//        
//        String errorEventlData = null;
//        response.setContentType("application/json;charset=ISO-8859-15");
//        response.setHeader("Cache-Control", "no-store");
//        PrintWriter out;
//        
//        out = response.getWriter();
//        try {
//            errorEventlData = dataTableService.getEventErrorData(transId, eventId);
//        
//            if (errorEventlData != null) {
//                out.print(errorEventlData);
//            }
//        } catch (Exception se) {
//            LOGGER.error("Exception received while processing the input data of transId: " + transId  );
//            LOGGER.warn("Madird Console runtime exception. check the data", se);
//            throw new CustomGenericException("code1", "serviceerror");
//        }
//    }
//    
    
    /**
     * This method is used to obtain and Download a Transaction attachment (based on an Attachment ID).
     * 
     * @param attachmentId Attachment ID
     */
    @RequestMapping(value = "/getReport/{attachmentId}", method = RequestMethod.GET)
    public void getReport(@PathVariable long attachmentId, HttpServletRequest request, HttpServletResponse response,
                              HttpSession session){

        LOGGER.debug("Method: getReport, attachmentId: " + attachmentId );
        try { 
            GetAttachmentResponse getAttachmentResponse = dataTableService.getPackageAttachment(attachmentId); 
            byte[] reportfile = this.getContentAsByteArray(getAttachmentResponse.getAttachmentContent());
    
           String fileName = getAttachmentResponse.getFileRef();
           response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
           response.setHeader("Content-Type", "application/octet-stream");
           response.setHeader("Content-Length", String.valueOf(reportfile.length));
    
            OutputStream outputStream = null;
            try {
                outputStream = response.getOutputStream();
    
                outputStream.write(reportfile);
                outputStream.flush();
    
            } finally {
                if (null != outputStream) {
                    outputStream.close();
                }
            }
        } catch (Exception e) {
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
           }
        }
    }
    @RequestMapping(value = "/getTransactionAttachmentContent/{attachmentId}", method = RequestMethod.GET)
    public void getTransactionAttachmentContent(@PathVariable long attachmentId, HttpServletRequest request, HttpServletResponse response,
                              HttpSession session){

        LOGGER.debug("Method: getTransactionAttachmentContent, attachmentId: " + attachmentId );

        try {
            AttachmentDetail attachmentDetail = dataTableService.getAttachment(attachmentId);
            
             byte[] reportfile = this.getContentAsByteArray(attachmentDetail.getFileContent());
    
           String fileName = attachmentDetail.getFileName();
           response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
           response.setHeader("Content-Type", "application/octet-stream");
           response.setHeader("Content-Length", String.valueOf(reportfile.length));
    
            OutputStream outputStream = null;
            try {
                outputStream = response.getOutputStream();
    
                outputStream.write(reportfile);
                outputStream.flush();
    
            } finally {
                if (null != outputStream) {
                    outputStream.close();
                }
            }
        } catch (Exception e) {
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }
    }

    
    @RequestMapping(value = "/getTransactionContent/{transId}", method = RequestMethod.GET)
    public void getTransactionContent(@PathVariable long transId, HttpServletRequest request, HttpServletResponse response,
                              HttpSession session) {

        LOGGER.debug("Method: getTransactionContent, transId: " + transId );
        try {
           TransactionDetail transactionDetail = dataTableService.getXML(transId);
            
           byte[] reportfile = transactionDetail.getXmlContent();
    
           response.setHeader("Content-Disposition", "attachment; filename=" + transId + ".xml");
           response.setHeader("Content-Type", "application/octet-stream");
           response.setHeader("Content-Length", String.valueOf(reportfile.length));
    
            OutputStream outputStream = null;
            try {
                outputStream = response.getOutputStream();
    
                outputStream.write(reportfile);
                outputStream.flush();
    
            } finally {
                if (null != outputStream) {
                    outputStream.close();
                }
            }
        } catch (Exception e) {
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }

    }
    
    public byte[] getContentAsByteArray(DataHandler handler) throws IOException {
        byte[] bytes = null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        handler.writeTo(bos);
        bos.flush();
        bos.close();
        bytes = bos.toByteArray();

        return bytes;
    }

}