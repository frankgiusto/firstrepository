package ca.gc.ic.cipo.tm.madridconsole.service.tups;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridGroup;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.util.ServiceUtil;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.userprofile.client.UserProfileServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityCategory;
import ca.gc.ic.cipo.tm.userprofile.schema.BaseUserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.CIPOServiceFault;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfile;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileService;
import ca.gc.ic.cipo.tm.userprofile.schema.UserProfileType;

/**
 * The Class UserProfileServiceClient is a Trademark User Profile Service (TUPS) web service client.
 *
 * @author kaurs
 */
@Service
public class UserProfileServiceClient {

    /** The tups host name from the intl database INTL_CNFGN_PARM table. */
    @Value("${mc.tm.user.profile.services.host.name}")
    private String tupsHostName;

    @Autowired
    SendErrorEmail sendErrorEmail;

    /** The logger. */
    protected static Logger logger = Logger.getLogger(UserProfileServiceClient.class);

    /**
     * Gets the client.
     *
     * @return the client
     * @throws MCServerException
     */
    private UserProfileService getClient() throws MCServerException {
        UserProfileService client = UserProfileServiceFactory.createClient(tupsHostName);

        if (client == null) {
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tups.serviceunavailable"), 100);
        }

        return client;
    }

    /**
     * Gets the user profile for the logged in user.
     *
     * @param userName the user name of the person logged in
     * @return the user profile of the person logged in
     * @throws CIPOServiceFault
     * @throws Exception the exception
     */
    public UserProfile getUserProfile(String userName) throws MCServerException {

        logger.debug("Method: getUserProfile: getting user profile by username - " + userName);

        UserProfileType request = new UserProfileType();
        request.setUserName(userName);
        request.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.name());

        UserProfile profile;
        String[] params = new String[1];
        params[0] = userName;

        try {
            profile = getClient().getUserProfile(request);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TUPS, true);
        } catch (CIPOServiceFault e) {

            logger.error("Method: getUserProfile: Error getting user profile by username - " + userName);
            logger.error("Method: getUserProfile: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TUPS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tups.userprofile", params), e);

        } catch (Throwable e) {

            logger.error("Method: getUserProfile: Error getting user profile by username - " + userName);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TUPS, tupsHostName,
                "getUserProfile(request)", e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tups.userprofile", params), e);
        }

        logger
            .debug("Profile details from TUPS - username = " + profile.getUsername() + " name = " + profile.getName());

        for (UserAuthority auth : profile.getUserAuthorities()) {
            logger.debug("role - " + auth.getIntlAuthorityRole());
        }

        return profile;
    }

    /**
     * Gets the user profiles in INTREPID for the current user's role.
     *
     * @param group the group
     * @return the user profiles for a user role
     * @throws CIPOServiceFault the CIPO service fault
     */
    public List<BaseUserProfile> getUserProfilesForUserRole(HttpServletRequest request, String groupAuthId)
        throws MCServerException {

        UserAuthority authority = new UserAuthority();
        String role = this.getCurrentSelectedRole(request);
        String group = "", authId = "";

        if (!groupAuthId.isEmpty()) {
            int index = groupAuthId.lastIndexOf("-");
            if (index != -1) {
                group = groupAuthId.substring(0, index);
                authId = groupAuthId.substring(index + 1);
            } else {
                group = groupAuthId;
            }
            role = MadridGroup.getTupsAuthority(group);
        }
        authority.setIntlAuthorityRole(role);
        authority.setIntlAuthorityCategory(IntlAuthorityCategory.MADRID_CONSOLE.name());

        logger.debug(
            "Method: getUserProfile: Error getting user profile by group - " + group + " authority " + authority);

        String[] params = new String[1];
        params[0] = group;

        try {
            List<BaseUserProfile> listBaseUserProfile = getClient().searchUserProfiles(authority);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TUPS, true);
            return listBaseUserProfile;
        } catch (CIPOServiceFault e) {

            logger.error(
                "Method: getUserProfile: Error getting user profile by group - " + group + " authority " + authority);
            logger.error("Method: getUserProfile: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TUPS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tups.userprofileforgroup", params), e);

        } catch (Throwable e) {

            logger.error(
                "Method: getUserProfile: Error getting user profile by group - " + group + " authority " + authority);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TUPS, tupsHostName,
                "getUserProfile(request)", e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tups.userprofileforgroup", params), e);
        }
    }

    /**
     * Sets the current profile of the logged in user.
     *
     * @param profile the current logged in user's profile
     */
    public void setCurrentUserProfile(HttpServletRequest request, UserProfile profile) {
        request.getSession().setAttribute("currentLoggedUserProfile", profile.getUsername());
        request.getSession().setAttribute("parentId", profile.getParentUserName());
    }

    /**
     * Gets the current profile of the logged in user from HttpSession.
     *
     * @return the current profile of the user
     * @throws CIPOServiceFault
     * @throws MCServerException
     */
    public UserProfile getCurrentUserProfile(HttpServletRequest request) throws MCServerException {
        return getUserProfile(((String) request.getSession().getAttribute("currentLoggedUserProfile")));
    }

    /**
     * Sets the current selected role for the logged in user.
     *
     * @param role the new current selected role
     */
    public void setCurrentSelectedRole(HttpServletRequest request, String role) {
        request.getSession().setAttribute("currentSelectedRole", role);
    }

    /**
     * Gets the current selected role of the logged in user from HttpSession.
     *
     * @return the current selected role
     */
    public String getCurrentSelectedRole(HttpServletRequest request) {
        return ((String) request.getSession().getAttribute("currentSelectedRole"));
    }

    /**
     * Gets the LDAP username from HttpSession.
     *
     * @return the LDAP username
     */
    public String getLdapUsername(HttpServletRequest request) {
        // return getCurrentUserProfile(request).getUsername();
        return ((String) request.getSession().getAttribute("currentLoggedUserProfile"));
    }

    /**
     * Gets the authority id for tasks assignments from HttpSession.
     *
     * @return the authority id
     */
    public String getAuthorityId(HttpServletRequest request) {
        return ((String) request.getSession().getAttribute("authorityId"));
    }

    public void setAuthorityId(HttpServletRequest request, String authId) {
        request.getSession().setAttribute("authorityId", authId);
    }

    /**
     * Gets the parent id for tasks assignments from HttpSession.
     *
     * @return the parent id
     */
    public String getParentId(HttpServletRequest request) {

        return ((String) request.getSession().getAttribute("parentId"));
        // return getCurrentUserProfile(request).getParentUserName();
    }

    /**
     * Gets the list of user authorities for a current logged in user from HttpSession.
     *
     * @return the parent id
     * @throws MCServerException
     */
    public List<UserAuthority> getUserAuthorities(HttpServletRequest request) throws MCServerException {

        return getUserAuthorities(getCurrentUserProfile(request));
    }

    public List<UserAuthority> getUserAuthorities(UserProfile profile) {

        List<UserAuthority> validAuthorities = new ArrayList<UserAuthority>();

        // first parse thru the authorities to see if the user is a supervisor. If so
        // we just need the one authority to be returned.
        for (UserAuthority tupAuth : profile.getUserAuthorities()) {
            if (tupAuth.getIntlAuthorityGroup().equalsIgnoreCase("SUPERVISOR")) {
                validAuthorities.add(tupAuth);
            }
        }
        if (validAuthorities.isEmpty()) {
            return profile.getUserAuthorities();
        } else {
            return validAuthorities;
        }
    }

    /**
     * getHeartbeat for the Trademark User Profile Service.
     *
     * @return ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType
     */
    public ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeat() {

        logger.debug("Method: getHeartbeat for TUPS");

        ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeatResponse = new ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType();
        try {
            getHeartbeatResponse = getClient().getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   " + tupsHostName);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TUPS, true);

        } catch (Throwable tow) {
            tow.printStackTrace();
            getHeartbeatResponse.setIpAddress(tupsHostName);
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TUPS, tupsHostName,
                "getHeartbeat()", tow.getMessage());
            logger.error("Method: Throwable Exception: ", tow);
        }

        return getHeartbeatResponse;
    }
}
