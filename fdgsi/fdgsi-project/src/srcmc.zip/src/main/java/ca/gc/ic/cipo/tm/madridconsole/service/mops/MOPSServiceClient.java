package ca.gc.ic.cipo.tm.madridconsole.service.mops;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mops.MOPSClient;
import ca.gc.ic.cipo.tm.mops.MOPSServiceFactory;
import ca.gc.ic.cipo.tm.mops.MOPSServiceResponse;

/**
 * The Class MOPSServiceClient is a Trademark Madrid Monitor Service (MOPS) web service client.
 *
 * @author kaurs
 */
@Service
public class MOPSServiceClient {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(MOPSServiceClient.class);

    @Autowired
    SendErrorEmail sendErrorEmail;

    /**
     * Gets the WIPO MOPS client.
     *
     * @return the client
     * @throws MCServerException
     */
    private MOPSClient getClient() throws MCServerException {

        MOPSClient client = MOPSServiceFactory.createClient();

        if (client == null) {
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mops.serviceunavailable"));
        }
        return client;
    }

    /**
     * Gets the MADRID registration by IR number from MOPS.
     *
     * @param irNum the international registration number (String)
     * @return MOPSServiceResponse - the MADRID registration by IR number
     * @throws MCServerException the MC server exception
     */
    public MOPSServiceResponse getMadridRegistrationByIRNumber(String irNum) throws MCServerException {

        logger.debug("Method: getMadridRegistrationByIRNumber - IR# " + irNum);

        String[] params = new String[1];
        params[0] = irNum;

        try {
            MOPSServiceResponse mOPSServiceResponse = getClient().getMadridRegistrationByIRNumber(irNum);
            // logger.debug("XML-WIPO = " + mOPSServiceResponse.getXml());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MOPS, true);
            return mOPSServiceResponse;

        } catch (Exception e) {

            logger.error("Method: getMadridRegistrationByIRNumber: Error connecting to WIPO MOPS for IR# " + irNum
                + ": " + e.getMessage());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MOPS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mops.madridreg", params), e);

        } catch (Throwable e) {
            logger.error("Method: getMadridRegistrationByIRNumber: Received Throwable: " + e.getMessage());
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MOPS, "",
                "getMadridRegistrationByIRNumber(irNum), irNum=" + irNum, e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mops.madridreg"), e);
        }
    }
}
