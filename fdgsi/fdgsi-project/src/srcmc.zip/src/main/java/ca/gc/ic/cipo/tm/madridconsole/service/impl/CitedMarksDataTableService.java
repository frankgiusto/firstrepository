package ca.gc.ic.cipo.tm.madridconsole.service.impl;


import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;
import ca.gc.ic.cipo.tm.mts.TrademarkInfo;

/**
 *
 * Service for retrieving Cited Marks data.
 *
 */
@Service
public class CitedMarksDataTableService {

    private ServletContext servletContext;

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    // Language to be displayed on Screen.
    Locale locale = null;
    
    @SuppressWarnings("deprecation")
    public String generateCitedMarks(GoodServiceWipoBean gsBean) throws IOException {
        
        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();
        
        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();
        JSONArray taskColumn = new JSONArray();
        
        // Language to be displayed on Screen.
        locale = new Locale(gsBean.getMf3a().getMf3aRequest().getLanguageCode());

        int intCitedMarksCnt = 0;

        for (GroundsOfOpposition groundsOfOppostion : gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag()) 
        {
   
            intCitedMarksCnt++;
            taskColumn = new JSONArray();
            StringBuilder finalResponse = new StringBuilder();
     
            
            finalResponse.append("<div class=\"panel panel-info\" >");
            finalResponse.append(generateHeader(intCitedMarksCnt));
            finalResponse.append("&nbsp;");
            finalResponse.append("<section id=\"error.label.7.i_section" + intCitedMarksCnt + "\" class=\"alert alert-danger \" style=\"margin-left: 25px; display: none\"  > ");
            finalResponse.append("<h2 class=\"h4\" id=\"error.label.7.i_" + intCitedMarksCnt + "\">");
            finalResponse.append("</h2>");
            finalResponse.append("</section>");
            finalResponse.append(generateLabel("mc.mf3a.label.7.i"));
            finalResponse.append("<div class=\"row\">");
            finalResponse.append("<div class=\"col-md-3\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.filing.date"));
            finalResponse.append(generateDate("filingDate_" + intCitedMarksCnt, gsBean, intCitedMarksCnt, groundsOfOppostion.getFilingDate()));
            finalResponse.append("</div>");
            
            finalResponse.append("<div class=\"col-md-3\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.filing.number"));

            if(groundsOfOppostion.getFilingNumber() != null && !groundsOfOppostion.getFilingNumber().isEmpty()) {
                finalResponse.append(generateNumber("filingnNumber_" + intCitedMarksCnt, groundsOfOppostion.getFilingNumber(), " readonly "));
            } else {
                finalResponse.append("<div class=\"input-group\">");
                finalResponse.append(generateNumber("filingnNumber_" + intCitedMarksCnt, "", ""));
                finalResponse.append("<span class=\"input-group-btn\"> ");
                finalResponse.append("<button class=\"btn btn-primary \" onclick=\"searchFilingNumber(" + intCitedMarksCnt + ");\" type=\"button\"> ");
                finalResponse.append("<span class=\"glyphicon glyphicon-search\"></span> ");
                finalResponse.append("</button>");
                finalResponse.append("</span>");
                finalResponse.append("</div>");
                finalResponse.append("<span class=\"small\" style=\"margin-left: 25px;\" >"+ messageSource.getMessage("mc.mf3a.filing.number.help.label", null, locale )  + "</span> ");            
            }
            finalResponse.append("</div>");   // end of div  col-md-3
     
            finalResponse.append("<div class=\"col-md-3\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.priority.date"));
            finalResponse.append(generateDate("priorityDate_" + intCitedMarksCnt, gsBean, intCitedMarksCnt,  groundsOfOppostion.getPriorityDate()));
            finalResponse.append("</div>");  // end of div  col-md-3
    
            finalResponse.append("</div>");   // end of div row
    
            finalResponse.append(generateLabel("mc.mf3a.label.7.ii"));
            finalResponse.append("<div class=\"row\">");
            
            finalResponse.append("<div class=\"col-md-3\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.registration.date"));
            finalResponse.append(generateDate("registrationDate_" + intCitedMarksCnt, gsBean, intCitedMarksCnt,groundsOfOppostion.getRegistrationDate() ));
            finalResponse.append("</div>");
    
            finalResponse.append("<div class=\"col-md-3\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.registration.number"));
            finalResponse.append(generateNumber("registrationNumber_" + intCitedMarksCnt, groundsOfOppostion.getRegistrationNumber(), " readonly "));
            finalResponse.append("</div>");  // end of div  col-md-3
    
            finalResponse.append("</div>");  // end of div row
    
            // Name and address of owner
            finalResponse.append("<div class=\"form-group\">");  
            finalResponse.append(generateLabel("mc.mf3a.label.7.iii"));
            finalResponse.append(generateNameAndAddress("nameAndAddress_" + intCitedMarksCnt, gsBean, intCitedMarksCnt, groundsOfOppostion.getNameAndAddress()));
            finalResponse.append("</div>");  // end of form-group
            
            // Reproduction of the mark
            finalResponse.append("<div class=\"form-group\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.iv"));
            finalResponse.append(generateReproductionOfMark("reproductionOfMark_" + intCitedMarksCnt, gsBean, intCitedMarksCnt, groundsOfOppostion.getTrademarkInfo()));
            finalResponse.append("</div>");  // end of form-group
    
            // List of the relevant goods and/or services (this list may be in the language of the earlier application ro registration)
            finalResponse.append("<div class=\"form-group\">");
            finalResponse.append(generateLabel("mc.mf3a.label.7.v"));
            if(groundsOfOppostion.getFilingNumber() != null && !groundsOfOppostion.getFilingNumber().isEmpty()) {
                finalResponse.append(generateListOfGandS("listofGoodsAndServices_" + intCitedMarksCnt, gsBean, intCitedMarksCnt, ""));
            } else {
                finalResponse.append(generateListOfGandS("listofGoodsAndServices_" + intCitedMarksCnt, gsBean, intCitedMarksCnt, " readonly "));
            }
            finalResponse.append("</div>");  // end of form-group
            finalResponse.append("</div>");   // end of div panel
            taskColumn.put(finalResponse);
            taskList.put(taskColumn);     
        
        }
        try {
            taskResults.put("data", taskList);
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return taskResults.toString();
    }
    
    
    public String generateHeader(int intCitedMarksCnt) {
        
        StringBuilder response = new StringBuilder();
   
        response.append("<header class=\"panel-heading\">");
        response.append("<h2 class=\"panel-title citedMarkh2\" id=\"citedMarkh2" + intCitedMarksCnt + "\" >" + messageSource.getMessage("mc.mf3a.cited.mark.label", null, locale )  + " " + intCitedMarksCnt ); 
        response.append("<a class=\"wb-lbx lbx-modal mrgn-lft-sm pull-right wb-init wb-lbx-inited\" onclick=\"removeCitedMarkPopup('" + intCitedMarksCnt + "');\" role=\"button\" href=\"#\" >");
        response.append("<span class=\"glyphicon glyphicon-remove\" ></span></a>");
        response.append("</h2>");
        response.append("</header>");
        
        return response.toString();
    }
  
    public String generateLabel(String strLabel) {
        StringBuilder response = new StringBuilder();
   
        response.append("<label id=\"filingDateAndNumberLabel\" class=\" control-label\" ");
        response.append("style=\"margin-left: 25px\" for=\"input7i\"> ");
        response.append(messageSource.getMessage(strLabel, null, locale ) );
        response.append("</label>");
       
        return response.toString();
    }
    
    public String generateDate(String strId, GoodServiceWipoBean gsBean, int intCitedMarksCnt, Date dateValue ) {
        StringBuilder response = new StringBuilder();
   
        response.append("<div class=\"input-group date mrgn-bttm-md \" style=\"margin-left: 25px\">  ");
        response.append("<div >  ");
        response.append("<input class=\"form-control \" type=\"text\" readonly ");
        if (dateValue != null) {
            response.append("value=" + DateFormats.getISOSDF().format(dateValue) );
        }
        response.append(" id=\"" + strId +"\"  name=\"" + strId +"\"  >  ");
        response.append("</div> ");
        response.append("</div> ");
        
        return response.toString();
    }
    
    public String generateNumber(String strId, String strFieldValue, String strReadOnly) {
        StringBuilder response = new StringBuilder();
   
        response.append("<div class=\"mrgn-bttm-md\" style=\"margin-left: 25px\"> ");
        response.append("<input type=\"text\" class=\"form-control full-width\" id=\"" + strId +"\" ");
        response.append(" style=\"\" class=\"form-control full-width\" " + strReadOnly );
        if (strFieldValue != null && !strFieldValue.equals("")) {
            response.append(" value=" + strFieldValue );
        }
        response.append( "  /> ");
        response.append("</div>");
      
        return response.toString();
    }
    
    public String generateNameAndAddress(String strId, GoodServiceWipoBean gsBean, int intCitedMarksCnt, String strNameAndAddress) {
        StringBuilder response = new StringBuilder();
   
        response.append("<div class=\"mrgn-bttm-md\" style=\"margin-left: 25px; margin-right: 15px\"> ");
        response.append("<textarea id=\"" + strId + "\"  escape=\"false\" style=\"resize: none;\"  rows=\"5\" ");
        response.append("class=\"form-control full-width\" readonly ");
        response.append(" >");
        if (strNameAndAddress != null){
            response.append(strNameAndAddress);
        }
        response.append("</textarea> ");
        response.append("</div>");
      
        return response.toString();
    }
    public String generateListOfGandS(String strId, GoodServiceWipoBean gsBean, int intCitedMarksCnt, String strReadOnly) {
        StringBuilder response = new StringBuilder();
   
        response.append("<div class=\"mrgn-bttm-md\" style=\"margin-left: 25px; margin-right: 15px\"> ");
        response.append("<textarea id=\"" + strId + "\"  escape=\"false\" style=\"resize: none; white-space: normal;\"  rows=\"10\" ");
        response.append("class=\"form-control full-width\" wrap=\"\" ");
        response.append(strReadOnly);
        response.append(" onblur=\"onFieldChange('" + strId + "' , this.value )\" >");
        if (gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag().get(intCitedMarksCnt -1).getNiceClassCode() != null)
            response.append(gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag().get(intCitedMarksCnt -1).getNiceClassCode());
        response.append("</textarea> ");
        response.append("</div>");
        
      
        return response.toString();
    }
    public String generateReproductionOfMark(String strId, GoodServiceWipoBean gsBean, int intCitedMarksCnt, TrademarkInfo trademarkInfo) throws IOException {
        StringBuilder response = new StringBuilder();
   
        response.append("<div class=\"mrgn-bttm-md\" style=\"margin-left: 25px; margin-right: 15px\"> ");
        response.append("<input type=\"text\" id=\"" + strId + " \" " );
        response.append("class=\"form-control full-width\" readonly ");
        if (trademarkInfo != null && trademarkInfo.getTrademarkDescription() != null) {
            response.append("value=\"" + trademarkInfo.getTrademarkDescription() + "\""  );
        }
        response.append(" onblur=\"onFieldChange('" + strId + "', this.value )\" >");
        response.append("</div>");
        
        
        response.append("<ul class=\"list-unstyled mrgn-tp-md\" style=\"margin-left: 25px; margin-right: 15px\"> ");
        response.append("<li class=\"nowrap list-unstyled\"> ");
        response.append("<div class=\"input-group\"> ");
        response.append(" </div> ");
        response.append(" </li>   ");
        response.append(" </ul> ");
        
        response.append("<div id=\"displayImg" + intCitedMarksCnt + "\" class=\"mrgn-bttm-md\" style=\"margin-left: 40px; ");
        if (trademarkInfo != null && trademarkInfo.getTrademarkAttachment() != null && trademarkInfo.getTrademarkAttachment().getFileContent() != null) {
            response.append(" display: block  \"  > ");
        } else {
            response.append(" display: none  \"  > ");

        }
        response.append("<div class=\"cipo-img-container\" > ");                            
        response.append("<div class=\"cipo-thumbnail-container\"> ");
        response.append("<a href=\"\" rel=\"external\" target=\"_blank\" ><span class=\"force-read-before\" data-attributetitlebeforeof=\"id-hatemile-display-1984393055690382-17\"> </span><span class=\"force-read-before\" data-attributetargetbeforeof=\"id-hatemile-display-1984393055690382-17\"></span>  ");
        response.append("<img id=\"myImage" + intCitedMarksCnt + "\" ");
        if (trademarkInfo != null && trademarkInfo.getTrademarkAttachment() != null && trademarkInfo.getTrademarkAttachment().getFileContent() != null) {
            
            InputStream in = trademarkInfo.getTrademarkAttachment().getFileContent().getInputStream();
            in.reset();
            String encoded = new String();
            byte [] bt = IOUtils.toByteArray(in);
            encoded=DatatypeConverter.printBase64Binary(bt );
            response.append(" src=\"data:image/gif;base64," + encoded + "\" ");
            
        } else {
            response.append(" src=\"\" ");
        }
        response.append("class=\"cipo-thumbnail\"></a> ");
        response.append("</div> ");
        response.append("</div> ");
        response.append("</div> ");
      
      return response.toString();
    }

    
    
}
