package ca.gc.ic.cipo.tm.madridconsole.util;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContext;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import ca.gc.ic.cipo.tm.userprofile.enums.IntlAuthorityRole;

/**
 * Enum for the Madrid Groups used in the Console.
 *
 * @author kaurs
 */
public enum MadridGroup {

    // @formatter:off
    MC_Madrid_TM_Supervisor(IntlAuthorityRole.MC_TM_SUPERVISOR, "dashboard.label.tmsuper", true),
    MC_Madrid_TMOB_Supervisor(IntlAuthorityRole.MC_TMOB_SUPERVISOR, "dashboard.label.tmobsuper",  true),
    MC_Madrid_TM_Operator(IntlAuthorityRole.MC_TM_OPERATOR, "dashboard.label.tmoperator", false),
    MC_Madrid_TM_Examiner(IntlAuthorityRole.MC_TM_EXAMINER, "dashboard.label.tmexaminer", false),
    MC_Madrid_TMOB_Operator(IntlAuthorityRole.MC_TMOB_OPERATOR, "dashboard.label.tmoboperator", false);
    // @formatter:on

    /** The tups authority. */
    private IntlAuthorityRole tupsAuthority;

    /** The madrid group name. */
    private String madridGroupName;

    /** The is supervisor. */
    private boolean isSupervisor;

    /**
     * Instantiates a new madrid group.
     *
     * @param tupsAuthority the tups authority
     * @param groupName the group name
     * @param supervisor the supervisor
     */
    MadridGroup(IntlAuthorityRole tupsAuthority, String groupName, boolean supervisor) {
        this.tupsAuthority = tupsAuthority;
        this.madridGroupName = groupName;
        this.isSupervisor = supervisor;
    }

    /**
     * Gets the Madrid group name.
     *
     * @param authority the authority
     * @return the madrid group name
     */
    public static String getMadridGroupName(String authority) {

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
        LocaleContext localeContext = LocaleContextHolder.getLocaleContext();

        Locale locale = null;
        if (localeContext != null) {
            locale = localeContext.getLocale();
        } else {
            locale = new Locale("en");
        }

        for (MadridGroup status : MadridGroup.values()) {
            if (status.tupsAuthority.value().equals(authority)) {
                return messageSource.getMessage(status.madridGroupName, null,
                    locale/* LocaleContextHolder.getLocale() */);
            }
        }
        return new String();
    }

    /**
     * Gets the Trademark user profile service authority name.
     *
     * @param groupname the groupname
     * @return the tups authority
     */
    public static String getTupsAuthority(String groupname) {

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        for (MadridGroup status : MadridGroup.values()) {
            if (messageSource.getMessage(status.madridGroupName, null, new Locale("en")).equals(groupname)) {
                return status.tupsAuthority.name();
            }
        }
        return new String();
    }

    /**
     * Checks if this group is a supervisor.
     *
     * @param authority the authority
     * @return true, if is supervisor
     */
    public static boolean isSupervisor(String authority) {
        for (MadridGroup status : MadridGroup.values()) {
            if (status.tupsAuthority.value().equals(authority)) {
                return status.isSupervisor;
            }
        }
        return false;
    }
}
