package ca.gc.ic.cipo.tm.madridconsole.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.web.bean.PackageCriteria;
import ca.gc.ic.cipo.tm.mps.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mps.GetAttachment;
import ca.gc.ic.cipo.tm.mps.GetAttachmentResponse;
import ca.gc.ic.cipo.tm.mps.GetPackage;
import ca.gc.ic.cipo.tm.mps.MadridPackageServicePortType;
import ca.gc.ic.cipo.tm.mps.factory.MadridPackageServiceFactory;
import ca.gc.ic.cipo.tm.schema.mps.EventDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.PackageTypeEnum;

@Service
public class WipoTransPackageWSClient {

    protected static final Logger LOGGER = Logger.getLogger(WipoTransPackageWSClient.class);

    @Value("${mc.pkg.server}")
    private String mpsHostName;

    MadridPackageServicePortType madridPackageServicePortType = null;
    
    @Autowired
    SendErrorEmail sendErrorEmail;

    @SuppressWarnings("deprecation")
    public List<PackageDetail> getPackageInfo(String type, int period, String language, String status, String startDate,
                                              String endDate)
        throws Exception {

        LOGGER.debug("Method: getPackageInfo, type: " + type + " url: " + mpsHostName + " language: " + language);

        List<PackageDetail> response = null;
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);

            PackageCriteria searchCriteria = new PackageCriteria();
            if (startDate != null && startDate.length() > 0) {
                searchCriteria.setCreatedStartDate(DateFormats.getISOSDF().parse(startDate));
            }

            if (endDate != null && endDate.length() > 0) {
                searchCriteria.setCreatedEndDate(DateFormats.getISOSDF().parse(endDate));
            }

            // Set the Status.
            if (!status.isEmpty()) {
                List<PackageStatusEnum> packageStatusCodeList = new ArrayList<PackageStatusEnum>();
                packageStatusCodeList.add(PackageStatusEnum.valueOf(status));
                searchCriteria.setStatusCode(packageStatusCodeList);
            }

            // Set the Package Type
            List<PackageTypeEnum> packageTypeCode = new ArrayList<PackageTypeEnum>();
            packageTypeCode.add(PackageTypeEnum.valueOf(type));
            searchCriteria.setPackageTypeCode(packageTypeCode);

            // Make the call to the Service
            response = madridPackageServicePortType.getPackageList(searchCriteria);
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (CIPOServiceFault e) {
            LOGGER.error("Package service received CIPOServiceFault Console Method; getPackageInfo, url: " + mpsHostName
                + ", type: " + type + ", status: " + status + ", language: " + language);
            LOGGER.error("CIPOServiceFault Recevied: ", e);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);
            throw (new Exception());
        } catch (Throwable tow) {
            LOGGER.error("Package service has internal issue. Console Method; getPackageInfo, url: " + mpsHostName
                + ", type: " + type + ", status: " + status + ", language: " + language);
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getPackageList()", tow.getMessage() );
            throw (new Exception());
        }
        return response;

    }

    public PackageDetail getPackageFile(Long packageId) throws Exception {

        LOGGER.debug("Method: getPackageFile, packageId: " + packageId + ", url: " + mpsHostName);

        GetPackage packageFileWsRequest = new GetPackage();
        PackageDetail response = null;
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);

            packageFileWsRequest.setPackageId(packageId.intValue());

            response = madridPackageServicePortType.getPackage(packageId.intValue(), true, true, true);
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (CIPOServiceFault ce) {
            LOGGER.error("Package service received CIPOServiceFault Console Method; getPackageFile, url: " + mpsHostName
                + ", packageId: " + packageId + ", Package Service Call: getPackage");
            LOGGER.error("CIPOServiceFault Recevied: ", ce);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);
            throw (new Exception());
        } catch (Throwable tow) {
            LOGGER.error("Package service has internal issue. Console Method; getPackageFile, url: " + mpsHostName
                + ", packageId: " + packageId + ", Package Service Call: getPackage");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getPackage()", tow.getMessage() );
            throw (new Exception());
        }

        return response;

    }

    public PackageDetail getPackageBasicInfo(Long packageId) throws Exception {

        LOGGER.debug("Method: getPackageBasicInfo, packageId: " + packageId + ", url: " + mpsHostName);

        GetPackage packageFileWsRequest = new GetPackage();
        PackageDetail response = null;
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);
            packageFileWsRequest.setPackageId(packageId.intValue());

            response = madridPackageServicePortType.getPackage(packageId.intValue(), false, false, false);
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (CIPOServiceFault ce) {
            LOGGER.error("Package service received CIPOServiceFault Console Method; getPackageBasicInfo, url: "
                + mpsHostName + ", packageId: " + packageId + ", Package Service Call: getPackage");
            LOGGER.error("CIPOServiceFault Recevied: ", ce);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);
            throw (new Exception());
        } catch (Throwable tow) {
            LOGGER.error("Package service has internal issue. Console Method; getPackageBasicInfo, url: " + mpsHostName
                + ", packageId: " + packageId + ", Package Service Call: getPackage");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getPackage(packageId, false, false, false)", tow.getMessage() );
            throw (new Exception());
        }

        return response;
    }

    public PackageDetail getPackageInfo(Long packageId) throws Exception {

        LOGGER.debug("Method: getPackageInfo, packageId: " + packageId + ", url: " + mpsHostName);

        GetPackage packageFileWsRequest = new GetPackage();
        PackageDetail response = null;
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);
            packageFileWsRequest.setPackageId(packageId.intValue());

            response = madridPackageServicePortType.getPackage(packageId.intValue(), true, false, true);
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (CIPOServiceFault ce) {
            LOGGER.error("Package service received CIPOServiceFault Console Method; getPackageInfo, url: " + mpsHostName
                + ", packageId: " + packageId + ", Package Service Call: getPackage");
            LOGGER.error("CIPOServiceFault Recevied: ", ce);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);
            throw ce;
        } catch (Throwable tow) {
            LOGGER.error("Package service has internal issue. Console Method; getPackageInfo, url: " + mpsHostName
                + ", packageId: " + packageId + ", Package Service Call: getPackage");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getPackage(packageId, true, false, true)", tow.getMessage() );
            throw (new Exception());
        }

        return response;
    }

    public GetAttachmentResponse getAttachment(long id) throws Exception {

        LOGGER.debug("Method: getAttachment, id: " + id + ", url: " + mpsHostName);

        GetAttachmentResponse response = null;
        GetAttachment request = new GetAttachment();
        request.setAttachmentId(new Long(id).intValue());
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);
            response = madridPackageServicePortType.getPackageAttachment(request);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (CIPOServiceFault ce) {
            LOGGER.error("Package service received CIPOServiceFault Console Method; getAttachment, url: " + mpsHostName
                + ", id: " + id + ", Package Service Call: getPackageAttachment");
            LOGGER.error("CIPOServiceFault Recevied: ", ce);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);
            throw (new Exception());
        } catch (Throwable tow) {
            LOGGER.error("Package service has internal issue. Console Method: getAttachment, url: " + mpsHostName
                + ", id: " + id + ", Package Service Call: getPackageAttachment");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getPackageAttachment()", tow.getMessage() );
            throw (new Exception());
        }
        return response;

    }

    /**
     * This method make the call to the MPS, to obtain a List of package Events, for a given Package id.
     *
     * @param packageId Package Id.
     * @return List<EventDetail> Package Detail class
     * @exception Exception
     */
    public List<EventDetail> getPackageEvents(Long packageId) throws Exception {

        LOGGER.debug("Method: getPackageEvents, packageId: " + packageId + ", url: " + mpsHostName);

        List<EventDetail> listEventsData = null;
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);
            listEventsData = madridPackageServicePortType.getPackageEventList(packageId.intValue());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (CIPOServiceFault ce) {
            LOGGER.error("Package service received CIPOServiceFault Console Method; getPackageEventList, url: "
                + mpsHostName + ", packageId: " + packageId + ", Package Service Call: getPackageEventList");
            LOGGER.error("CIPOServiceFault Recevied: ", ce);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);
            throw ce;
        } catch (Throwable tow) {
            LOGGER.error("Package service has internal issue. Console Method; getPackageInfo, url: " + mpsHostName
                + ", packageId: " + packageId + ", Package Service Call: getPackageEventList");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getPackageEventList(), packageId=" + packageId, tow.getMessage() );
            throw (new Exception());
        }

        return listEventsData;
    }
    /**
     */
    public ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeat() {

        LOGGER.debug("Method: getHeartbeat " );

        ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeatResponse = new ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType();
        try {
            madridPackageServicePortType = MadridPackageServiceFactory.createClient(mpsHostName);
            getHeartbeatResponse = madridPackageServicePortType.getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   "  + mpsHostName);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MPS, true);

        } catch (Throwable tow) {
            getHeartbeatResponse.setIpAddress(mpsHostName);
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MPS, mpsHostName,
                "getHeartbeat()", tow.getMessage() );

        }

        return getHeartbeatResponse;
    }
}
