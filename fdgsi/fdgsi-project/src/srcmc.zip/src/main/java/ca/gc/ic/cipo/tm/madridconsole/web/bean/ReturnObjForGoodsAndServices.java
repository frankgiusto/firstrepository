package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.util.ArrayList;
import java.util.List;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationCategoryType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;

public class ReturnObjForGoodsAndServices {

    private int niceClass;

    private ClassDescriptionType wipoGSType;

    private String wipoCategory = "";

    private List<GoodsServicesClaimsType> intrepidGSType;

    private List<GoodsServicesClaimsType> finalGSType; // this will only be set when we do a copy over to final col from
    // INTREPID or WIPO

    private List<FinalGoodsServicesWrapper> finalGSWrapper = new ArrayList<FinalGoodsServicesWrapper>();

    private int associatedIntrepidIndex = -1;

    public ReturnObjForGoodsAndServices(int niceClass, ClassDescriptionType wipoGS,
                                        List<GoodsServicesClaimsType> intrepidGS) {

        this.niceClass = niceClass;
        this.wipoGSType = wipoGS;
        this.intrepidGSType = intrepidGS;
    }

    public int getNiceClass() {
        return niceClass;
    }

    public void setNiceClass(int niceClass) {
        this.niceClass = niceClass;
    }

    public ClassDescriptionType getWipoGSType() {
        return wipoGSType;
    }

    public void setWipoGSType(ClassDescriptionType wipoGSType) {
        this.wipoGSType = wipoGSType;
    }

    public List<GoodsServicesClaimsType> getIntrepidGSType() {
        return intrepidGSType;
    }

    public void setIntrepidGSType(List<GoodsServicesClaimsType> intrepidClass) {
        this.intrepidGSType = intrepidClass;
    }

    public String getWipoCategory() {
        return wipoCategory;
    }

    public void setWipoCategory(String wipoCategory) {
        this.wipoCategory = wipoCategory;
    }

    public List<GoodsServicesClaimsType> getFinalGSType() {
        return finalGSType;
    }

    public void setFinalGSType(List<GoodsServicesClaimsType> finalGSType) {
        this.finalGSType = finalGSType;
    }

    public void addFinalGSType(int intrepidIndex, GoodsServicesClaimsType gscType) {

        int count = 1;
        if (finalGSType == null) {
            if (intrepidGSType != null) {
                count = intrepidGSType.size();
            }
            finalGSType = new ArrayList<GoodsServicesClaimsType>(count);
            for (int i = 0; i < count; i++) {
                finalGSType.add(i, null);
            }
        }

        finalGSType.set(intrepidIndex, gscType);
    }

    public boolean isFinalGSTypeSet() {

        if (finalGSType != null) {
            for (GoodsServicesClaimsType gscType : finalGSType) {
                if (gscType != null) {
                    for (FinalGoodsServicesWrapper finalGS : finalGSWrapper) {
                        if (finalGS.getClassNum() == Integer.parseInt(gscType.getClassification().getClassNumber())) {
                            if (finalGS.getGoodsServicesLimitationCategoryType() != null && finalGS
                                .getGoodsServicesLimitationCategoryType() != GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                                return true;
                            }

                        }
                    }
                }
            }
        }
        return false;
    }

    public int getAssociatedIntrepidIndex() {
        return associatedIntrepidIndex;
    }

    public void setAssociatedIntrepidIndex(int associatedIntrepidIndex) {
        this.associatedIntrepidIndex = associatedIntrepidIndex;
    }

    public List<FinalGoodsServicesWrapper> getFinalGSWrapper() {
        return finalGSWrapper;
    }

    public void setFinalGSWrapper(List<FinalGoodsServicesWrapper> finalGSWrapper) {
        this.finalGSWrapper = finalGSWrapper;
    }

}
