package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;

public class InfoRelatedToRemark implements Serializable {

        
        String filingDateAndNumber;         // VII (i) Filing date and number,and if any, priority date  
        String regDateAndNumber;            // VII (ii) Registration date and number (if available): 
        String nameAndAddressOfOwner;       // VII (iii) Name and address of owner
        String reproductionOfTheMark;       // VII (iv) Reproduction of the mark:
        String listOfTheRelevantGoodsServices; // VII (v) List of the relevant goods and/or services (this list may be in the language of the earlier application ro registration): 

        
        public String getFilingDateAndNumber() {
            return filingDateAndNumber;
        }

        
        public void setFilingDateAndNumber(String filingDateAndNumber) {
            this.filingDateAndNumber = filingDateAndNumber;
        }

        
        public String getRegDateAndNumber() {
            return regDateAndNumber;
        }

        
        public void setRegDateAndNumber(String regDateAndNumber) {
            this.regDateAndNumber = regDateAndNumber;
        }

        
        public String getNameAndAddressOfOwner() {
            return nameAndAddressOfOwner;
        }

        
        public void setNameAndAddressOfOwner(String nameAndAddressOfOwner) {
            this.nameAndAddressOfOwner = nameAndAddressOfOwner;
        }

        
        public String getReproductionOfTheMark() {
            return reproductionOfTheMark;
        }

        
        public void setReproductionOfTheMark(String reproductionOfTheMark) {
            this.reproductionOfTheMark = reproductionOfTheMark;
        }

        
        public String getListOfTheRelevantGoodsServices() {
            return listOfTheRelevantGoodsServices;
        }

        
        public void setListOfTheRelevantGoodsServices(String listOfTheRelevantGoodsServices) {
            this.listOfTheRelevantGoodsServices = listOfTheRelevantGoodsServices;
        }

    }

    