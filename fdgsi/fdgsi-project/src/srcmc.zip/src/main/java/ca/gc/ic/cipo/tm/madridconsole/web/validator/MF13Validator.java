package ca.gc.ic.cipo.tm.madridconsole.web.validator;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;

public class MF13Validator  {
    
    // Log4J logger.
    private final Logger logger = Logger.getLogger(getClass());
      
    
    public void validate (GoodServiceWipoBean goodServiceWipoBean, Errors errors) {

        // Unfortunately...at this time there is nothing to validate.  However, I am told this will
        // will change in the future.
        
        logger.debug("Validate MF13: " + goodServiceWipoBean.getMf13().toString());          
    }
}
