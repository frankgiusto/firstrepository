package ca.gc.ic.cipo.tm.madridconsole.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

/**
 * The Class MadridAuthenticationEntryPoint additionally detects session timeout via ajax requests and sends back
 * appropriate error code so client can take appropriate action.
 * 
 * @author giustof
 */
public class MadridAuthenticationEntryPoint extends LoginUrlAuthenticationEntryPoint {

    public MadridAuthenticationEntryPoint(String loginFormUrl) {
        super(loginFormUrl);
    }

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         org.springframework.security.core.AuthenticationException authException)
        throws IOException, ServletException {
        String xrequestedWith = request.getHeader("x-requested-with");
        if (xrequestedWith != null && xrequestedWith.equals("XMLHttpRequest") && authException != null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
        }

        else {

            super.commence(request, response, authException);
        }
    }
}
