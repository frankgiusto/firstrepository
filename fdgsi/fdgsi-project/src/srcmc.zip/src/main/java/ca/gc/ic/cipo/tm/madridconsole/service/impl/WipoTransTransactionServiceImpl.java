package ca.gc.ic.cipo.tm.madridconsole.service.impl;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ca.gc.ic.cipo.tm.madridconsole.service.intl.WipoTransTransactionService;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransTransactionWSClient;
//import ca.gc.ic.cipo.tm.mts.EventDetail;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;

@Service
public class WipoTransTransactionServiceImpl implements WipoTransTransactionService {
    
    protected static final Logger LOGGER = Logger.getLogger(WipoTransPackageServiceImpl.class);
    
    @Autowired
    private WipoTransTransactionWSClient wipoTransTransactionWSClient;

    /**
     * This will get the List of Packages, to display in the Search Results 
     * 
     * @param packageId A Package Id
     * @return List<TransactionDetail> A List of Transaction Detail (TransactionDetail(
     * @throws Exception
     */
    public List<TransactionDetail> getTransactionsInfo(String packageId ) throws Exception {
        
        LOGGER.debug("Method: getTransactionsInfo, packageId: " + packageId );
        
       List<TransactionDetail> transactionDetailList = null;;
       transactionDetailList = wipoTransTransactionWSClient.getTransactionInfo(packageId);

       return transactionDetailList;

    }
    
//    /** {@inheritDoc} */
//    @Override
//    public List<EventDetail> getEventsInfo(String packageId ) throws Exception {
//        
//        LOGGER.debug("Method: getEventsInfo, packageId: " + packageId );
//        
//        List<EventDetail> eventDetailList = null;
//        eventDetailList = transactionWSClient.getEventsInfo(packageId);
//
//        LOGGER.debug("getEventsInfo Number of Events: " + eventDetailList.size() );
//
//        return eventDetailList;
//
//    }
    
}
