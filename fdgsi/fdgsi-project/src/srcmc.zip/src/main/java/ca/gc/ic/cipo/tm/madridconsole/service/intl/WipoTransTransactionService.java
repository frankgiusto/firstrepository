package ca.gc.ic.cipo.tm.madridconsole.service.intl;

import java.util.List;

import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
//import ca.gc.ic.cipo.tm.mts.EventDetail;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;

public interface WipoTransTransactionService {

    List<TransactionDetail> getTransactionsInfo(String packageId) throws CIPOServiceFault, Exception;
    

}