package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;
import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForGoodsAndServicesForNANR;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

/**
 * The Class ProcessPartialCeasingOOController handles the NANR Partial Ceasing of Effect (O/O) manual task.
 */
@Controller
@SessionAttributes("wipogs")
public class ProcessPartialCeasingOOController {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(ProcessPartialCeasingOOController.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    /** The message source. */
    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * Gets the bean used to transfer data from View and Controller.
     *
     * @param request the request
     * @return the wipo gs
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    /** The TM App service to retrieve data from TIRS. */
    @Autowired
    protected TradMarkApplicationService tmAppService;

    /** The MWE client. */
    @Autowired
    protected WorkflowEngineServiceClient mweClient;

    /** The user profile service. */
    @Autowired
    protected UserProfileServiceClient userProfileService;

    /**
     * Inits the binder.
     *
     * @param binder the binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * The default handler (page=0).
     *
     * @param fileNumberStr the file number of the application associated to the selected task being processed.
     * @param transIds the trans ids associated to the selected task being processed.
     * @param taskId the task id associated to the selected task being processed.
     * @param actId the MWE activity task id associated to the selected task being processed.
     * @param type the type of the task being processed.
     * @param gsBean the gs bean used to send and receive data between the view and controller
     * @param modelMap the model map
     * @param request the request
     * @param session the session
     * @return the initial page
     */
    @RequestMapping(value = "/processtask/partialceasingoo", method = RequestMethod.POST)
    public String displayNANPartialCeasingPage(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                               @RequestParam(value = "transIds", required = false) List<String> transIds,
                                               @RequestParam(value = "irNum", required = false) String irNum,
                                               @RequestParam(value = "taskId", required = false) String taskId,
                                               @RequestParam(value = "aId", required = false) String actId,
                                               @RequestParam(value = "type", required = false) String type,
                                               @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                               final ModelMap modelMap, HttpServletRequest request,
                                               HttpServletResponse response, HttpSession session) {

        logger.debug("Method: displayNANPartialCeasingPage: File: " + fileNumberStr + ", Task ID: " + taskId
            + ", actId " + actId + ", type " + type + ", transIds " + transIds + ", IR# " + irNum);

        if (fileNumberStr != null) {
            int fileNumber = Integer.parseInt(fileNumberStr);

            ArrayList<String> actIds = new ArrayList<String>();
            actIds.add(actId);

            try {
                // Acquire lock
                transactionServiceClient.acquireLock(gsBean, fileNumber, 0, userProfileService.getLdapUsername(request));

                // assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                        transactionServiceClient.releaseLock( gsBean);
                    } catch (IOException e) {
                        logger.error("Exception: ", e);
                        // e.printStackTrace();
                    }
                }
            } catch (MCServerException e) {
                logger.error("Error assigning task to current user " + userProfileService.getParentId(request)
                    + " due to - " + e.getMessage(), e);
                try {
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                    transactionServiceClient.releaseLock(gsBean);
                    return "ptOOPartialCeasing";
                } catch (Exception e1) {
                    logger.error("Exception: ", e1);
                }
            }

            if (gsBean == null) {
                gsBean = new GoodServiceWipoBean();
            }
            gsBean.clearCache();
            gsBean.setTaskId(new BigDecimal(taskId));
            gsBean.setInternationalRegistrationNumber(irNum);

            if (transIds != null) { // take the first transId for now
                try {
                    tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                        new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.OOPARTIALCEASING_FORM);
                } catch (MCServerException e) {

                    try {
                        logger.debug("Method: displayNANPartialCeasingPage: Error generating GoodsServicesBean File: "
                            + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", type " + type
                            + ", transIds " + transIds + ", IR# " + irNum +" Exception: ", e);
                        response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                        transactionServiceClient.releaseLock( gsBean);
                    } catch (Exception e1) {
                        logger.error("Exception: ", e1);
                    }
                }
            } else {
                logger.error("Transaction ID is missing for task " + taskId + " activity task - " + actId);
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        "Transaction ID is missing for task " + taskId + " activity task - " + actId);
                    transactionServiceClient.releaseLock(gsBean);
                } catch (Exception e) {
                    logger.error("Exception: ", e);
                }
            }
        }

        return "ptOOPartialCeasing";
    }

    /**
     * Displays the first screen to select the options when processing the NANR partial ceasing manual task.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo", method = RequestMethod.GET)
    public String prepareGsSelectPage(final ModelMap modelMap,
                                      final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                      HttpServletRequest request) {

        logger.debug("Method: prepareGsSelectPage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptOOPartialCeasing";
    }

    /**
     * Process any user selected input from the first screen when processing partial ceasing of effect OO manual task.
     *
     * @param gsBean the bean containing the data from the view
     * @param model the model
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/merge", method = RequestMethod.POST)
    public String handleGsSelectSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, ModelMap model,
                                           final HttpServletRequest request, final HttpServletResponse response,
                                           HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = gsBean.getAction();

        logger.debug("Method: handleGsSelectSubmitForm with action " + action);

        String viewName = "ptOOPartialCeasing";

        viewName = "redirect:/processtask/partialceasingoo/wipomerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {
            gsBean.setAction(ActionDispatcher.ACTION_NEXT);

            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                viewName = "redirect:/processtask/partialceasingoo/wipomerge";
            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT)) {
                try {
                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine to complete task
                    try {
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.noadjustmsg", null, LocaleContextHolder.getLocale()));

                    } catch (MCServerException e) {

                        // What happens if MWE cannot complete task but MTS has marked it Processed?
                        // TODO: The task will not appear on the console. MTS Needs to handle it.
                        logger.error("Error completing Goods and Services Task by MWE - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId());
                        logger.error("Exception: ", e);
                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.noadjustmsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    }

                } catch (MCServerException e) {

                    logger.error("Error submitting goods and services request to MTS - ");
                    logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                        + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                        + gsBean.getActivityTaskId());
                    logger.error("Exception: ", e);
                    redirectAttributes.addFlashAttribute("errorMsg",
                        messageSource.getMessage("mc.goodsandservices.label.noadjustmsgerr", null,
                            LocaleContextHolder.getLocale()) + e.getMessage());
                } finally {

                     // Release the LOCK on the File Number/Extension
                     try {
                         transactionServiceClient.releaseLock(gsBean);
                     } catch (MCServerException e) {
                         logger.error("/processtask/partialceasingoo/merget, (ACTION NEXT) Errors attempting to release Lock." + e.getMessage() );
                     }
                }

                // go back to the calling page
                viewName = "redirect:" + session.getAttribute("refererPage");

                session.setAttribute("wipogs", null);

            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) {
                try {
                    gsBean.copyAllToFinalFromWipo(false);
                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine to complete task
                    try {
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.acceptwipomsg", null, LocaleContextHolder.getLocale()));

                    } catch (MCServerException e) {

                        // What happens if MWE cannot complete task but MTS has marked it Processed?
                        // TODO: The task will not appear on the console. MTS Needs to handle it.
                        logger.error("Error completing Goods and Services Task by MWE - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId());
                        logger.error("Exception: ", e);
                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.acceptwipomsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    }
                } catch (MCServerException e) {

                    logger.error("Error submitting goods and services request to MTS - ");
                    logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                        + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                        + gsBean.getActivityTaskId());
                    logger.error("Exception: ", e);

                    redirectAttributes.addFlashAttribute("errorMsg",
                        messageSource.getMessage("mc.goodsandservices.label.acceptwipomsgerr", null,
                            LocaleContextHolder.getLocale()) + e.getMessage());
                } finally {

                    // Release the LOCK on the File Number/Extension
                    try {
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (MCServerException e) {
                        logger.error("/processtask/partialceasingoo/merge, (ACTION NEXT) Errors attempting to release Lock." + e.getMessage() );
                    }
               }

                viewName = "redirect:" + session.getAttribute("refererPage");

                session.setAttribute("wipogs", null);
            }
        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/MF3A/submit, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }
        }
        return viewName;
    }

    /**
     * Prepare the second page when processing G&S where the statements from WIPO and INTREPID are merged and adjusted.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/wipomerge", method = RequestMethod.GET)
    public String prepareGsMergePage(final ModelMap modelMap,
                                     final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                     HttpServletRequest request) {

        logger.debug("Method: prepareGsMergePage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptOOPartialCeasingMerge";
    }

    /**
     * Process any actions on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/wipomerge", method = RequestMethod.POST)
    public String handleGsMergeSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                          final HttpServletRequest request, final HttpServletResponse response,
                                          HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = gsBean.getAction();

        logger.debug("Method: handleGsMergeSubmitForm with action " + action);

        String viewName = "ptOOPartialCeasingMerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {
            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                viewName = "redirect:/processtask/partialceasingoo/review";
            }
        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_PREVIOUS.equalsIgnoreCase(action)) {
            gsBean.setHideMarksSupportingIR(true);
            viewName = "redirect:/processtask/partialceasingoo";

        } else if (ActionDispatcher.ACTION_SAVE.equalsIgnoreCase(action)) {

            if (gsBean.isHideMarksSupportingIR()) {

                if (!gsBean.gsInFinal()) {

                    // Total Ceasing of Effect, go to MF9 screen
                    viewName = "redirect:/processtask/MF9";
                } else {
                    gsBean.setHideMarksSupportingIR(false);
                    viewName = "redirect:/processtask/partialceasingoo/wipomerge";
                }
            } else {
                // in case the marks supported IR are displayed but user
                // removes the G&S on that page
                if (!gsBean.gsInFinal()) {

                    // Total Ceasing of Effect, go to MF9 screen
                    viewName = "redirect:/processtask/MF9";
                }
            }
        } else if (action.startsWith(ActionDispatcher.ACTION_SAVE + "_")) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);
            gsBean.updateMarksForIR(tokens[1]);
            gsBean.setHideMarksSupportingIR(true);

            // go to MF9 screen
            viewName = "redirect:/processtask/MF9";
        }

        return viewName;
    }

    private void outputFinalStatement(GoodServiceWipoBean gsBean, int index, final HttpServletResponse response) {

        JSONArray finalStatements = new JSONArray();
        ClassDescriptionType finalGS = gsBean.getGoodsAndServicesNANR().get(index).getFinalGSType();

        boolean finalStmtIsEmpty = true;
        if (finalGS != null) {

            for (OrderedTextType ordType : finalGS.getGoodsServicesDescriptionText()) {
                if (ordType.getLanguageCode().equalsIgnoreCase(gsBean.getLangCode().value())) {
                    finalStatements.put(ordType.getValue());
                    finalStmtIsEmpty = false;
                }
            }
            if (finalStmtIsEmpty) {
                finalStatements.put("");
            }
        }
        try {
            PrintWriter out = response.getWriter();
            JSONObject result = new JSONObject();

            result.put("count", finalStatements.length());
            result.put("finalStmtIsEmpty", finalStmtIsEmpty);
            result.put("finalStatements", finalStatements);
            result.put("removeAll", gsBean.isRemoveAllOption());
            out.print(result);
        } catch (IOException | JSONException e) {
            try {
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }

    /**
     * Process the copy the WIPO statement into the final table cell action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/copyfromwipo", method = RequestMethod.POST)
    public void handleCopyWIPOStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                        @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                        final HttpServletRequest request, final HttpServletResponse response,
                                        HttpSession session) {

        logger.debug("Method: handleCopyWIPOStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_MOVEWIPOTOMERGE)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.copyWIPOStatementToFinalForNANR(new Integer(tokens[2]));

            outputFinalStatement(gsBean, new Integer(tokens[2]), response);
        }
    }

    /**
     * Process the copy all WIPO statements into the final table action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/copyallfromwipo", method = RequestMethod.POST)
    public void handleCopyAllWIPOStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                           @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                           final HttpServletRequest request, final HttpServletResponse response,
                                           HttpSession session) {

        logger.debug("Method: handleCopyAllWIPOStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_COPYALLFROMWIPO)) {

            gsBean.copyAllToFinalFromWipoForNANR();

            // JSON Array to store the row of the same nice class that are affected
            JSONArray gsList = new JSONArray();

            List<ReturnObjForGoodsAndServicesForNANR> retObjs = gsBean.getGoodsAndServicesNANR();

            try {
                PrintWriter out = response.getWriter();
                JSONObject result = new JSONObject();
                boolean finalStmtIsEmpty = true;

                int index = 0;
                for (ReturnObjForGoodsAndServicesForNANR retGS : retObjs) {

                    JSONArray finalStatements = new JSONArray();
                    ClassDescriptionType finalGS = gsBean.getGoodsAndServicesNANR().get(index).getFinalGSType();

                    if (finalGS != null) {

                        for (OrderedTextType ordType : finalGS.getGoodsServicesDescriptionText()) {
                            if (ordType.getLanguageCode().equalsIgnoreCase(gsBean.getLangCode().value())) {
                                finalStatements.put(ordType.getValue());
                                finalStmtIsEmpty = false;
                            }
                        }
                    }

                    if (finalStmtIsEmpty) {
                        finalStatements.put("");
                    }
                    JSONObject gsRow = new JSONObject();
                    gsRow.put("row", retGS.getNiceClass() + "_" + index);
                    gsRow.put("nice", retGS.getNiceClass());
                    gsRow.put("countstmt", finalStatements.length());
                    gsRow.put("finalStatements", finalStatements);
                    gsRow.put("finalStmtIsEmpty", finalStmtIsEmpty);
                    gsList.put(gsRow);

                    finalStmtIsEmpty = true;
                    index++;
                }
                result.put("count", gsList.length());
                result.put("gsList", gsList);
                out.print(result);

            } catch (IOException | JSONException e) {
                try {
                    logger.error("Exception: ", e);
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                } catch (IOException e1) {
                    logger.error("Exception: ", e1);
                }
            }
        }
    }

    /**
     * Process the remove the data in the final table cell action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/removecelldata", method = RequestMethod.POST)
    public void handleRemoveFinalCellData(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                          @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                          final HttpServletRequest request, final HttpServletResponse response,
                                          HttpSession session) {

        logger.debug("Method: handleRemoveFromFinal with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_REMOVEFROMFINAL)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.removeWipoStatementFromFinalForNANR(new Integer(tokens[2]));

            outputFinalStatement(gsBean, new Integer(tokens[2]), response);
        }
    }

    /**
     * Process removing all final statements action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/removeallfromfinal", method = RequestMethod.POST)
    public void handleRemoveAllFromFinal(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                         @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                         final HttpServletRequest request, final HttpServletResponse response,
                                         HttpSession session) {

        logger.debug("Method: handleRemoveAllFromFinal with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_REMOVEALLFROMFINAL)) {

            gsBean.removeAllFromFinalForNANR();

            // return a response that really does not matter
            outputFinalStatement(gsBean, 0, response);
        }
    }

    /**
     * Process the edit final action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialceasingoo/editfinal", method = RequestMethod.POST)
    public void handleEditFinal(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                @RequestParam(required = true, defaultValue = "", value = "updatedText") String updatedText,
                                final HttpServletRequest request, final HttpServletResponse response,
                                HttpSession session) {

        logger.debug("Method: handleEditFinal with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_EDITFINAL)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            String finalStatement = gsBean.editFinalForNANR(new Integer(tokens[2]), updatedText);

            try {
                PrintWriter out = response.getWriter();
                JSONObject result = new JSONObject();
                result.put("finalStatement", finalStatement);
                out.print(result);
            } catch (IOException | JSONException e) {
                try {
                    logger.error("Exception: ", e);
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                } catch (IOException e1) {
                    logger.error("Exception: ", e1);
                }
            }
        }
    }
}
