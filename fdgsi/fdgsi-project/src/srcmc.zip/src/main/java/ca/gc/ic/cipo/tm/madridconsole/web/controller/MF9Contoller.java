package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.madridconsole.web.validator.MF9Validator;

@Controller
@SessionAttributes("wipogs")
public class MF9Contoller {

    private static Logger logger = Logger.getLogger(MF9Contoller.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * @param request
     * @return
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    @Autowired
    private TradMarkApplicationService tmAppService;

    @Autowired
    private WorkflowEngineServiceClient mweClient;

    @Autowired
    private UserProfileServiceClient userProfileService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * The default handler (page=0).
     *
     * @param fileNumberStr the file number of the application associated to the selected task being processed.
     * @param transIds the trans ids associated to the selected task being processed.
     * @param taskId the task id associated to the selected task being processed.
     * @param actId the MWE activity task id associated to the selected task being processed.
     * @param type the type of the task being processed.
     * @param gsBean the gs bean used to send and receive data between the view and controller
     * @param modelMap the model map
     * @param request the request
     * @param session the session
     * @return the initial page
     */
    @RequestMapping(value = "/processtask/MF9", method = RequestMethod.POST)
    public String displayTotalCeasingMF9Page(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                             @RequestParam(value = "transIds", required = false) List<String> transIds,
                                             @RequestParam(value = "irNum", required = false) String irNum,
                                             @RequestParam(value = "taskId", required = false) String taskId,
                                             @RequestParam(value = "aId", required = false) String actId,
                                             @RequestParam(value = "type", required = false) String type,
                                             @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                             final ModelMap modelMap, HttpServletRequest request,
                                             HttpServletResponse response, HttpSession session) {

        logger.debug("Method: displayTotalCeasingMF9Page: File: " + fileNumberStr + ", Task ID: " + taskId + ", actId "
            + actId + ", type " + type + ", transIds " + transIds + ", IR# " + irNum);

        if (fileNumberStr != null) {
            int fileNumber = Integer.parseInt(fileNumberStr);

            ArrayList<String> actIds = new ArrayList<String>();
            actIds.add(actId);

            try {
                // Acquire lock
                transactionServiceClient.acquireLock(gsBean, fileNumber, 0, userProfileService.getLdapUsername(request));

                // assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));

                        // Release the LOCK on the File Number/Extension
                        try {
                            transactionServiceClient.releaseLock(gsBean);
                        } catch (MCServerException ex) {
                            logger.error("/processtask/MF3A, Errors attempting to release Lock." + ex.getMessage() );
                        }
                        return "ptOOPartialCeasing";
                    } catch (IOException e) {
                        logger.error("Exception: ", e);
                    }
                }
            } catch (MCServerException e) {
                logger.error("Error assigning task to current user " + userProfileService.getParentId(request)
                    + " due to - " + e.getMessage(), e);
                try {
                    logger.error("Exception: ", e);
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                    // Release the LOCK on the File Number/Extension
                    try {
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (MCServerException e1) {
                        logger.error("/processtask/MF9/submit, Errors attempting to release Lock." + e1.getMessage() );
                    }
                    return "ptOOPartialCeasing";
                } catch (IOException e1) {
                    logger.error("Exception: ", e1);
                }
            }  catch (Throwable e) {
                logger.error("Method: displayTotalCeasingMF9Page: File: " + fileNumberStr + ", Task ID: " + taskId
                    + ", actId " + actId + ", type " + type + ", transIds " + transIds + "Error assigning task to current user "
                    + userProfileService.getParentId(request)
                    + " due to Throwable - " + e.getMessage(), e);

                try {
                    response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("mc.error.mts.gettransaction"));
                    transactionServiceClient.releaseLock(gsBean);
                    return "ptOOPartialCeasing";
                } catch (Exception e1) {
                    logger.error("Exception: ", e1);
                }
            }

            if (gsBean == null) {
                gsBean = new GoodServiceWipoBean();
            }
            gsBean.clearCache();
            gsBean.setTaskId(new BigDecimal(taskId));
            gsBean.setInternationalRegistrationNumber(irNum);

            if (transIds != null) { // take the first transId for now
                try {
                    tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                        new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.TOTALCEASINGOO_FORM);
                } catch (MCServerException e) {

                    try {
                        logger.debug("Method: displayTotalCeasingMF9Page: Error generating GoodsServicesBean File: "
                            + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", type " + type
                            + ", transIds " + transIds + ", IR# " + irNum);
                        logger.error("Exception: ", e);
                        response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                        transactionServiceClient.releaseLock(gsBean);
                        return "redirect:" + session.getAttribute("refererPage");
                    } catch (Exception e1) {
                        logger.error("Exception: ", e1);
                    }
                }
            } else {
                logger.error("Transaction ID is missing for task " + taskId + " activity task - " + actId);
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        "Transaction ID is missing for task " + taskId + " activity task - " + actId);
                    transactionServiceClient.releaseLock(gsBean);
                    return "redirect:" + session.getAttribute("refererPage");
                } catch (Exception e) {
                    logger.error("Exception: ", e);
                }
            }
        }

        return "redirect:/processtask/MF9";
    }

    /**
     * POST (i.e. Get) Request - for MF9. Obtain the values for the pre-populated fields on the form.
     *
     * @param wipogs - GoodServiceWipoBean
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/MF9", method = RequestMethod.GET)
    public String MF9(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                      final ModelMap modelMap, Locale locale, HttpServletRequest request, HttpSession session,
                      HttpServletResponse response) {

        logger.debug("/processtask/MF9  gsBean " + gsBean.toString());

        String taskId = gsBean.getTaskId().toString();
        String transId = gsBean.getTransactionId().toString();
        String irNum = gsBean.getInternationalRegistrationNumber();
        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
        String viewName = "MF9";

        logger.debug("/processtask/MF9  method = RequestMethod.GET, transIds: " + transId + ", task: " + taskId);

        try {
            tmAppService.obtainMF9(request, gsBean, taskId, transId);
        } catch (MCServerException e) {
            try {
                logger.error("Method: MF9: Error obtaing MF9 Data: " + ", Task ID: " + taskId + ", transId " + transId
                    + ", IR# " + irNum + " Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.mf9.infomsg.error", null, locale) + " - " + e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        }

        gsBean.setTaskId(new BigDecimal(taskId));
        gsBean.setInternationalRegistrationNumber(irNum);

        return viewName;

    }

    /**
     * Post Request (Submit) - for MF9. Validate (and assuming it passes validation) submit the MF9 to WIPO via the MTS.
     *
     * @param wipogs - GoodServiceWipoBean
     * @param errors - BindingResult
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/MF9/submit", method = RequestMethod.POST)
    public String gsSelectsubmitForm(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     Locale locale, ModelMap model, final HttpServletRequest request,
                                     final HttpServletResponse response, HttpSession session,
                                     final RedirectAttributes redirectAttributes) {

        logger.debug("/processtask/MF9 RequestMethod.POST, " + gsBean.getMf9().toString());

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
        String viewName = "";

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(actionVal)) {

            // Perform validation
            MF9Validator validator = new MF9Validator();
            validator.validate(gsBean, errors);
            if (errors.hasErrors()) {
                model.addAttribute("errors", errors);
                return "MF9";
            }

            try {

                // Process the MF9 (i.e., submit it to WIPO)
                tmAppService.processMF9(request, gsBean);

                // Call Workflow Engine to Complete Task
                mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                // Send the Success Message
                redirectAttributes.addFlashAttribute("infoMsg",
                    messageSource.getMessage("mc.mf9.infomsg.success", null, locale));

            } catch (MCServerException e) {
                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.mf9.infomsg.error", null, locale) + " - " + e.getMessage());
            } finally {

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock(gsBean);
                } catch (MCServerException e) {
                    logger.error("/processtask/MF9/submit, Errors attempting to release Lock." + e.getMessage() );
                }
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(actionVal)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock( gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/MF9/submit, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }

        }

        // Assuming everything has been successful, so far, clear out the GoodServiceWipoBean Data.
        session.setAttribute("wipogs", null);

        return viewName;

    }
}
