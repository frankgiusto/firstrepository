package ca.gc.ic.cipo.tm.madridconsole.service;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.userprofile.schema.BaseUserProfile;

/**
 *
 * Service for retrieving user list to assign tasks to
 *
 * @author timyu
 *
 */
@Service
public class UserListDataTableService {

    private final static Logger logger = Logger.getLogger(UserListDataTableService.class);

    @Autowired
    private UserProfileServiceClient userProfileService;

    public String getDataTableResponse(HttpServletRequest request, String searchName, String group)
        throws MCServerException, JSONException {

        String searchTerm = request.getParameter("search[value]");
        if (StringUtils.isNotBlank(request.getParameter("start"))) {
        }

        if (StringUtils.isNotBlank(searchTerm)) {
            searchTerm = searchTerm.toLowerCase();
        }

        if (StringUtils.isNotBlank(searchName)) {
            searchTerm = searchName.toLowerCase();
        } else {
            searchName = "a";
        }

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        List<BaseUserProfile> userProfList = Collections.emptyList();

        userProfList = userProfileService.getUserProfilesForUserRole(request, group);

        for (BaseUserProfile userProf : userProfList) {

            if (StringUtils.isBlank(searchName) || (StringUtils.isNotBlank(searchName)
                && StringUtils.containsIgnoreCase(userProf.getName(), searchName))) {
                JSONArray taskColumn = new JSONArray();
                taskColumn.put(userProf.getParentUserName() == null ? "" : userProf.getParentUserName());
                taskColumn.put(userProf.getName() == null ? "" : userProf.getName());
                taskColumn.put(userProf.getUsername() == null ? "" : userProf.getUsername());
                taskColumn.put(userProf.getParentUserName() == null ? "" : userProf.getParentUserName());
                taskColumn.put(userProf.getSecurityLevelCode() == 2 ? "Y" : "");
                taskList.put(taskColumn);
            }
        }

        taskResults.put("iTotalRecords", userProfList.size());
        taskResults.put("iTotalDisplayRecords", userProfList.size());
        taskResults.put("spicyMeatball", "ya baby!");
        taskResults.put("data", taskList);

        return taskResults.toString();
    }
}
