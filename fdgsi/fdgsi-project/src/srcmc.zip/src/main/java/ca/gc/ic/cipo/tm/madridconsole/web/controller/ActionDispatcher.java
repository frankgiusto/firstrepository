package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.util.Map;

import org.apache.commons.collections.map.ListOrderedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;

@Component
public class ActionDispatcher {

    /** Form ids. */
    public static final int TYPE_FORM_ID = 1;

    public static final int GOS_SELECT_FORM_ID = 2;

    public static final int GOS_MERGE_FORM_ID = 3;

    public static final int GOS_FINISH_FORM_ID = 4;

    /** Actions. */
    public static final String ACTION_NEXT = "next";

    public static final String ACTION_PREVIOUS = "previous";

    public static final String ACTION_SAVE = "save";

    public static final String ACTION_EDIT = "edit";

    public static final String ACTION_REMOVE = "remove";

    public static final String ACTION_CANCEL = "cancel";

    public static final String ACTION_SEARCH = "search";

    public static final String ACTION_SELECT = "select";

    public static final String ACTION_CREATE = "create";

    public static final String ACTION_VIEW = "view";

    public static final String ACTION_NOTIFY = "notify";

    public static final String ACTION_MOVEINTREPIDTOMERGE = "moveintrepidtomerge";

    public static final String ACTION_MOVEWIPOTOMERGE = "movewipotomerge";

    public static final String ACTION_REMOVEFROMFINAL = "removefromfinal";

    public static final String ACTION_EDITFINAL = "editfinal";

    public static final String ACTION_REMOVEALLFROMFINAL = "removeallfromfinal";

    public static final String ACTION_COPYALLFROMWIPO = "copyallfromwipo";

    public static final String ACTION_COPYALLFROMINTREPID = "copyallfromintrepid";

    public static final String ACTION_ASSOCTOWIPO = "assoctowipo";

    public static final String ACTION_REMOVEMARKS = "removemarks";

    /** Form names. */
    public static final String GOS_SELECT_FORM_NAME = "ptDOGoodandService";

    public static final String GOS_MERGE_FORM_NAME = "ptDOGoodandServiceMerge";

    public static final String GOS_FINISH_FORM_NAME = "ptDOGoodandResult";

    private static final ListOrderedMap GOS_ACCEPT_ALLFLOW = new ListOrderedMap();
    static {
        GOS_ACCEPT_ALLFLOW.put(GOS_SELECT_FORM_ID, GOS_SELECT_FORM_NAME);
        GOS_ACCEPT_ALLFLOW.put(GOS_FINISH_FORM_ID, GOS_FINISH_FORM_NAME);
    }

    private static final ListOrderedMap GOS_NO_EFFECT_FLOW = new ListOrderedMap();
    static {
        GOS_ACCEPT_ALLFLOW.put(GOS_SELECT_FORM_ID, GOS_SELECT_FORM_NAME);
        GOS_ACCEPT_ALLFLOW.put(GOS_FINISH_FORM_ID, GOS_FINISH_FORM_NAME);
    }

    private static final ListOrderedMap GOS_ACCEPT_ADJUST_FLOW = new ListOrderedMap();
    static {
        GOS_ACCEPT_ADJUST_FLOW.put(GOS_SELECT_FORM_ID, GOS_SELECT_FORM_NAME);
        GOS_ACCEPT_ADJUST_FLOW.put(GOS_MERGE_FORM_ID, GOS_MERGE_FORM_NAME);
        GOS_ACCEPT_ADJUST_FLOW.put(GOS_FINISH_FORM_ID, GOS_FINISH_FORM_NAME);
    }

    /** Message resource bundle. */
    @Autowired
    protected MessageSource messageSource;

    public String buildView(String action, long formId, long serviceItemType, Map<String, Object> params) {
        ModelAndView mv = null;

        // Selects the view based on the application type,
        // current form id and action.
        String viewName = null;
        if (action.equals(ACTION_NEXT)) {
            if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO) {

                Integer nextKey = (Integer) GOS_ACCEPT_ALLFLOW.nextKey(Integer.valueOf((int) formId));
                if (nextKey != null) {
                    viewName = (String) GOS_ACCEPT_ALLFLOW.get(nextKey);
                }

            } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT) {

                Integer nextKey = (Integer) GOS_ACCEPT_ADJUST_FLOW.nextKey(Integer.valueOf((int) formId));
                if (nextKey != null) {
                    viewName = (String) GOS_ACCEPT_ADJUST_FLOW.get(nextKey);
                }
            } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT) {

                Integer nextKey = (Integer) GOS_NO_EFFECT_FLOW.nextKey(Integer.valueOf((int) formId));
                if (nextKey != null) {
                    viewName = (String) GOS_NO_EFFECT_FLOW.get(nextKey);
                }
            }
        } else if (action.equals(ACTION_PREVIOUS)) {
            if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO) {

                Integer prevKey = (Integer) GOS_ACCEPT_ALLFLOW.previousKey(Integer.valueOf((int) formId));
                if (prevKey != null) {
                    viewName = (String) GOS_ACCEPT_ALLFLOW.get(prevKey);
                }

            } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT) {

                Integer prevKey = (Integer) GOS_ACCEPT_ADJUST_FLOW.previousKey(Integer.valueOf((int) formId));
                if (prevKey != null) {
                    viewName = (String) GOS_ACCEPT_ADJUST_FLOW.get(prevKey);
                }
            } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT) {

                Integer prevKey = (Integer) GOS_NO_EFFECT_FLOW.previousKey(Integer.valueOf((int) formId));
                if (prevKey != null) {
                    viewName = (String) GOS_NO_EFFECT_FLOW.get(prevKey);
                }
            }
        } else {
            // Stays on the same form
            if (serviceItemType == MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT) {
                viewName = (String) GOS_NO_EFFECT_FLOW.get(Integer.valueOf((int) formId));
            } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT) {
                viewName = (String) GOS_ACCEPT_ADJUST_FLOW.get(Integer.valueOf((int) formId));
            } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO) {
                viewName = (String) GOS_ACCEPT_ALLFLOW.get(Integer.valueOf((int) formId));
            }
        }
        return viewName;
    }

    /**
     *
     * @param action
     * @param formId
     * @param applicationType
     * @param params
     * @return
     */
    public ModelAndView buildModelAndView(String action, long formId, long serviceItemType,
                                          Map<String, Object> params) {

        String viewName = this.buildView(action, formId, serviceItemType, params);
        ModelAndView mv = null;
        mv = new ModelAndView(
            new RedirectView(messageSource.getMessage(viewName + ".url", null, LocaleContextHolder.getLocale())),
            params);

        return mv;
    }

    /**
     *
     * @param formId
     * @param applicationType
     * @return
     */
    public static StepInfo getStepInfo(int formId, long serviceItemType) {

        StepInfo info = new StepInfo();

        ListOrderedMap formFlow = getFormFlow(serviceItemType);

        // excludes first and last form
        info.setNumberOfSteps(formFlow.size() - 1);
        for (int i = 1; i < formFlow.size(); i++) {
            Integer flowFormId = (Integer) formFlow.get(i);
            if (formId == flowFormId.intValue()) {
                info.setCurrentStep(i);
            }
            info.addFormName((Integer) i, (String) formFlow.get(flowFormId));
        }

        return info;
    }

    public int getFormId(int stepNumber, long serviceItemType) {
        return (Integer) getFormFlow(serviceItemType).get(stepNumber);
    }

    public int getStepNumber(int formId, long serviceItemType) {
        int stepNo = 0;

        ListOrderedMap formFlow = getFormFlow(serviceItemType);

        // excludes first and last form
        for (int i = 1; i < formFlow.size(); i++) {
            Integer flowFormId = (Integer) formFlow.get(i);
            if (formId == flowFormId.intValue()) {
                stepNo = i;
                break;
            }
        }

        return stepNo;
    }

    public static String getFormName(int stepNumber, long serviceItemType) {
        return (String) getFormFlow(serviceItemType).getValue(stepNumber);

    }

    public static ListOrderedMap getFormFlow(long serviceItemType) {
        ListOrderedMap formFlow = null;

        if (serviceItemType == MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT) {
            formFlow = GOS_NO_EFFECT_FLOW;
        } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT) {
            formFlow = GOS_ACCEPT_ADJUST_FLOW;
        } else if (serviceItemType == MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO) {
            formFlow = GOS_ACCEPT_ALLFLOW;
        } else {
            throw new IllegalArgumentException("Unrecognized application type" + serviceItemType);
        }

        return formFlow;
    }
}
