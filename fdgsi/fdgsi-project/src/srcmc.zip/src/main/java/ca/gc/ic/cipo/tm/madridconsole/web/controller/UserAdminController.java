package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.service.UserListDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

@Controller
@RequestMapping("/useradmin")
public class UserAdminController {

    @Autowired
    private UserListDataTableService dataTableService;

    @Value("${mc.ws.common.services.host.name}")
    private String commonServiceHost;

    /** The logger. */
    protected static Logger logger = Logger.getLogger(UserAdminController.class.getName());

    @RequestMapping(value = "/groupmanage", method = RequestMethod.GET)
    public String taskBucket(Locale locale, Model model, HttpSession session) {
        grouplistInit(model, session);
        return "groupmanage";
    }

    @RequestMapping(value = "/userlist", method = {RequestMethod.GET, RequestMethod.POST})
    public void getListOfUsersForGroup(@RequestParam(required = false, defaultValue = "", value = "searchName") String searchName,
                                       @RequestParam(required = false, defaultValue = "", value = "group") String group,
                                       HttpServletRequest request, HttpServletResponse response) {

        logger.debug("Method: getListOfUsersForGroup searchName " + searchName + ", group " + group);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        try {
            PrintWriter out = response.getWriter();
            out.print(dataTableService.getDataTableResponse(request, searchName, group));
        } catch (MCServerException | JSONException | IOException e) {
            try {
                logger.error("Method: getListOfUsersForGroup searchName " + searchName + ", group " + group);
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }

    private void grouplistInit(Model model, HttpSession session) {
        Map<String, String> userGroups = new LinkedHashMap<String, String>();
        userGroups.put("Admin", "Administrator");
        userGroups.put("Madrid TM Operator", "Madrid TM Operator");
        userGroups.put("Madrid TM Examiner", "Madrid TM Examiner");
        userGroups.put("TMOB Operator", "TMOB Operator");

        userGroups.put("Madrid TM Supervisor", "Madrid TM Supervisor");
        userGroups.put("Super Admin", "Super Admin");
        // userGroups.put("OF-EXPERT_EXAMINER", "OF-EXPERT_EXAMINER");
        // userGroups.put("OF-EXAMINER", "OF-EXAMINER");
        // userGroups.put("OF-FINANCE", "OF-FINANCE");
        // userGroups.put("OF-EFILER", "OF-EFILER");
        // userGroups.put("OF-OFFICE_ERROR", "OF-OFFICE_ERROR");
        // userGroups.put("OF-ADMIN_ERROR", "OF-ADMIN_ERROR");

        model.addAttribute("usergroups", userGroups);
    }
}
