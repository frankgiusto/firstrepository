package ca.gc.ic.cipo.tm.madridconsole.util;

import java.util.ArrayList;
import java.util.List;

import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;

/**
 * The Class CitedMarksSearchResponse that send the status back on an AJAX call.
 */
public class CitedMarksSearchResponse {

    /** The state of the AJAX response message to be displayed to the user - success, error, warning or info. */
    private String status;

    /** The message to be displayed to the user. */
    private String message;

    /** The Constant ERROR. */
    public static final String ERROR = "E";

    /** The Constant WARNING. */
    public static final String MULTIPLE = "M";

    /** The Constant SUCCESS. */
    public static final String SUCCESS = "S";

    /** Used for MF3a form - possible Cited Marks*/
    List<GroundsOfOpposition> groundsOfOppositionList = new ArrayList<GroundsOfOpposition>();
        
    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    
    public List<GroundsOfOpposition> getGroundsOfOppositionList() {
        return groundsOfOppositionList;
    }

    
    public void setGroundsOfOppositionList(List<GroundsOfOpposition> groundsOfOppositionList) {
        this.groundsOfOppositionList = groundsOfOppositionList;
    }

}
