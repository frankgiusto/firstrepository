package ca.gc.ic.cipo.tm.madridconsole.service.intl;

import javax.servlet.ServletContext;


public interface IAdminPageDataTableService {

    public String getHeartBeatDataTableResponse()
        throws Exception;

    public String sendrecovery(String executionId)
        throws Exception;
    
    String getJarFilesDataTableResponse(ServletContext context) throws Exception;

    String getErrorProceeseDataTableResponse() throws Exception;

    
}