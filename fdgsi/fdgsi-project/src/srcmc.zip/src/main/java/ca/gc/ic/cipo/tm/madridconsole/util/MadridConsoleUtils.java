package ca.gc.ic.cipo.tm.madridconsole.util;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContext;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

/**
 * Utilities that are used by the Madrid Console.
 */
public class MadridConsoleUtils {

    /**
     * getMessage
     *
     * @param strPropName - string from the Properties File
     * @return string - message to be displayed in the proper Locale (ie., Eng or Fre)
     */
    public static String getMessage(String strPropName) {

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        return messageSource.getMessage(strPropName, null, getLocaleContext());
    }

    /**
     * getMessage
     *
     * @param strPropName - string from the Properties File
     * @param params - string of params used in conjunction with strPropName
     * @return string - message to be displayed in the proper Locale (ie., Eng or Fre)
     */
    public static String getMessage(String strPropName, String[] params) {

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        return messageSource.getMessage(strPropName, params, getLocaleContext());
    }

    /**
     * getLocaleContext
     *
     * @return Locale
     */
    public static Locale getLocaleContext() {
        LocaleContext localeContext = LocaleContextHolder.getLocaleContext();

        Locale locale = null;
        if (localeContext != null) {
            locale = localeContext.getLocale();
        } else {
            locale = new Locale("en");
        }
        return locale;
    }

}
