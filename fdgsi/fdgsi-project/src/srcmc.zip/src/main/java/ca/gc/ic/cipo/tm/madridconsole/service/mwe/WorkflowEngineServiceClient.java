package ca.gc.ic.cipo.tm.madridconsole.service.mwe;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridGroup;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.util.ServiceUtil;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ised.cipo.tm.madrid.workflow.client.MadridWorkflowEngineServiceFactory;
import ca.gc.ised.cipo.tm.mwe.AckNotificationRequest;
import ca.gc.ised.cipo.tm.mwe.AssignUserTasksRequest;
import ca.gc.ised.cipo.tm.mwe.CompleteUserTaskRequest;
import ca.gc.ised.cipo.tm.mwe.FetchRecoverableProcessesRequest;
import ca.gc.ised.cipo.tm.mwe.FetchRecoverableProcessesResponse;
import ca.gc.ised.cipo.tm.mwe.FetchTaskInformationRequest;
import ca.gc.ised.cipo.tm.mwe.FetchTaskInformationResponse;
import ca.gc.ised.cipo.tm.mwe.ForwardTaskStatusType;
import ca.gc.ised.cipo.tm.mwe.MadridWorkflowEngineServicePortType;
import ca.gc.ised.cipo.tm.mwe.ReassignTaskGroupRequest;
import ca.gc.ised.cipo.tm.mwe.SignalRecoverableProcessesRequest;
import ca.gc.ised.cipo.tm.mwe.UnassignUserTasksRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class WorkflowEngineServiceClient is a Workflow Engine web service client.
 *
 * @author kaurs
 */
@Service
public class WorkflowEngineServiceClient {

    /** The mwe host name from the intl database INTL_CNFGN_PARM table. */
    @Value("${mc.mwe.host.name}")
    private String mweHostName;

    /** The send error email. */
    @Autowired
    SendErrorEmail sendErrorEmail;

    /** The logger. */
    protected static Logger logger = Logger.getLogger(WorkflowEngineServiceClient.class);

    /**
     * Gets the Workflow engine client.
     *
     * @return the client
     * @throws MCServerException
     */
    private MadridWorkflowEngineServicePortType getClient() throws MCServerException {

        MadridWorkflowEngineServicePortType mweClient = null;
        try {
            mweClient = MadridWorkflowEngineServiceFactory.createMadridWorkflowEngineClient(mweHostName);
        } catch (Throwable throwable) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "getClient()", throwable.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.serviceunavailable"));
        }
        if (mweClient == null) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "getClient() ",
                "Error obtaining Client for Work flow Engine");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.serviceunavailable"));
        }
        return mweClient;
    }

    /**
     * Calls the Madrid Workfkow engine to acknowledge notifications by a given user.
     *
     * @param activityTaskIds the activity task ids of the notifications being acknowledged
     * @param acknowledgeByUserId the user id of the user acknowledging the notification
     * @throws MCServerException the MC server exception
     */
    public void acknowledgeNotification(List<String> activityTaskIds, String acknowledgeByUserId)
        throws MCServerException {

        logger.debug("Method: acknowledgeNotification - activityTaskId " + activityTaskIds + " acknowledgeByUserId "
            + acknowledgeByUserId);

        AckNotificationRequest paramAckNotificationRequest = new AckNotificationRequest();
        paramAckNotificationRequest.setAssigneeId(acknowledgeByUserId);
        paramAckNotificationRequest.getTaskIdList().addAll(activityTaskIds);

        try {
            getClient().ackNotification(paramAckNotificationRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
        } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

            logger.error("Method: acknowledgeNotification - activityTaskId " + activityTaskIds + " acknowledgeByUserId "
                + acknowledgeByUserId);
            logger.error("Method: acknowledgeNotification - CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.acknotification"), e);

        } catch (Throwable e) {

            logger.error("Method: acknowledgeNotification - activityTaskId " + activityTaskIds + " acknowledgeByUserId "
                + acknowledgeByUserId);
            logger.error("Method: acknowledgeNotification, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "ackNotification()", e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.acknotification"), e);
        }
    }

    /**
     * Calls the Madrid Workflow engine to assign users tasks to a user by a supervisor or by self.
     *
     * @param activityTaskIds the activity task ids to be assigned
     * @param assignTo to whom the tasks are being assigned
     * @param assignedBy by whom the tasks are being assigned by
     * @return true, if successful
     * @throws MCServerException the MC server exception
     */
    public int assignUserTask(List<String> activityTaskIds, String assignTo, String assignedBy)
        throws MCServerException {

        return assignUserTask(activityTaskIds, assignTo, assignedBy, true);
    }

    /**
     * Calls the Madrid Workflow engine to assign users tasks to a user by a supervisor or by self.
     *
     * @param activityTaskIds the activity task ids to be assigned
     * @param assignTo to whom the tasks are being assigned
     * @param assignedBy by whom the tasks are being assigned by
     * @param validate the validate
     * @return the int the num of failed assignments as tasks were already assigned
     * @throws MCServerException the MC server exception
     */
    public int assignUserTask(List<String> activityTaskIds, String assignTo, String assignedBy, boolean validate)
        throws MCServerException {

        logger.debug("Method: assignUserTask - activityTaskId " + activityTaskIds + " assignTo " + assignTo
            + ", assignedBy " + assignedBy);

        int failedAssignments = 0;
        String user;
        List<String> finalActIds = new ArrayList<String>();

        // validate should be false for supervisor reassigning tasks from one user to other or from one group to user
        if (validate) {
            for (String actId : activityTaskIds) {
                user = fetchTaskInformation(actId).getAssignedUserId();
                if (user != null) {
                    if (!user.equalsIgnoreCase(assignTo)) {
                        // assigned to someone else, ignore
                        failedAssignments++;
                    } else {
                        // is assigned to me, ignore
                    }
                } else {
                    // not assigned to a user already
                    finalActIds.add(actId);
                }
            }
        } else {
            finalActIds.addAll(activityTaskIds);
        }
        if (finalActIds.size() > 0) {
            AssignUserTasksRequest assignUserTask = new AssignUserTasksRequest();
            assignUserTask.setAssigneeId(assignTo);
            assignUserTask.setAuthId(assignedBy);
            assignUserTask.getTaskIdList().addAll(activityTaskIds);

            try {
                getClient().assignUserTasks(assignUserTask);
                sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

            } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

                logger.error("Method: assignUserTask - activityTaskId " + activityTaskIds + " assignTo " + assignTo
                    + ", assignedBy " + assignedBy);
                logger.error("Method: assignUserTask - CIPO service fault message: " + e.getMessage());
                ServiceUtil.objectToXML(e.getFaultInfo());
                sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.assignusertask"), e);

            } catch (Throwable e) {

                logger.error("Method: assignUserTask - activityTaskId " + activityTaskIds + " assignTo " + assignTo
                    + ", assignedBy " + assignedBy);
                logger.error("Method: assignUserTask - Received Throwable");

                sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName,
                    "assignUserTasks(), assignTo=" + assignTo + ", assignedBy=" + assignedBy, e.getMessage());

                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.assignusertask"), e);
            }
        }
        return failedAssignments; // if failedAssignments is > 0 then we display an appropriate message to user in the
                                  // callee function
    }

    /**
     * Calls the Madrid Workfkow engine to Unassign user tasks from a user by a supervisor.
     *
     * @param activityTaskIds the activity task ids
     * @param unassignedBy the unassigned by
     * @throws MCServerException the MC server exception
     */
    public void unassignUserTask(List<String> activityTaskIds, String unassignedBy) throws MCServerException {

        logger.debug("Method: unassignUserTask - activityTaskId " + activityTaskIds + " unassignedBy " + unassignedBy);

        UnassignUserTasksRequest unassignUserTask = new UnassignUserTasksRequest();
        unassignUserTask.setAuthId(unassignedBy);
        unassignUserTask.getTaskIdList().addAll(activityTaskIds);

        try {
            getClient().unassignUserTasks(unassignUserTask);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

        } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

            logger.error(
                "Method: unassignUserTask - activityTaskId " + activityTaskIds + " unassignedBy " + unassignedBy);
            logger.error("Method: unassignUserTask - CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.unassignusertask"), e);

        } catch (Throwable e) {

            logger.error(
                "Method: unassignUserTask - activityTaskId " + activityTaskIds + " unassignedBy " + unassignedBy);
            logger.error("Method: unassignUserTask, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName,
                "unassignUserTasks(), unassignedBy=" + unassignedBy, e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.unassignusertask"), e);
        }
    }

    /**
     * Calls the Madrid Workfkow engine to complete a given task.
     *
     * @param activityTaskId the activity task id of the task being completed
     * @param completedBy the user completing the task
     * @throws MCServerException the MC server exception
     */
    public void completeTask(String activityTaskId, String completedBy) throws MCServerException {

        completeTask(activityTaskId, completedBy, null, null);
    }

    /**
     * Calls the Madrid Workfkow engine to complete a given task such as irregularity and partial ownership where a
     * forward status is needed for further action from MWE such as creating notifications etc.
     *
     * @param activityTaskId the activity task id of the task being completed
     * @param completedBy the user completing the task
     * @param strForwardTaskStatusType - either IRREG_NO_RESPONSE, IRREG_CORRECT_AND_RESPOND,
     *            PART_OWNERSHIP_DESIGNATION, PART_OWNERSHIP_RESTRICTION, PART_OWNERSHIP_BOTH
     * @param authId the auth id
     * @throws MCServerException the MC server exception
     */
    public void completeTask(String activityTaskId, String completedBy, ForwardTaskStatusType strForwardTaskStatusType,
                             String authId)
        throws MCServerException {

        logger.debug("Method: completeTask - activityTaskId " + activityTaskId + ", completedBy " + completedBy
            + ", strForwardTaskStatusType "
            + ((strForwardTaskStatusType != null) ? strForwardTaskStatusType.value() : " "));

        CompleteUserTaskRequest completeUserTask = new CompleteUserTaskRequest();
        completeUserTask.setAssigneeId(completedBy);
        completeUserTask.setTaskId(activityTaskId);
        if (strForwardTaskStatusType != null) {
            completeUserTask.setForwardTaskStatus(strForwardTaskStatusType);
        }
        if (authId != null) {
            completeUserTask.setAuthorityId(authId);
        }

        try {
            getClient().completeUserTask(completeUserTask);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

        } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

            if (strForwardTaskStatusType != null) {
                logger.error("Method: completeTask - activityTaskId " + activityTaskId + ", completedBy " + completedBy
                    + ", strForwardTaskStatusType "
                    + ((strForwardTaskStatusType != null) ? strForwardTaskStatusType.value() : " "));
            }
            logger.error("Method: completeTask - CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.completetask"), e);

        } catch (Throwable e) {

            logger.error("Method: completeTask - activityTaskId " + activityTaskId + ", completedBy " + completedBy
                + ", strForwardTaskStatusType "
                + ((strForwardTaskStatusType != null) ? strForwardTaskStatusType.value() : " "));
            logger.error("Method: completeTask - Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName,
                "completeUserTask(), activityTaskId=" + activityTaskId + ", completedBy=" + completedBy,
                e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.completetask"), e);
        }
    }

    /**
     * getHeartbeat for the Madrid Workflow Engine.
     *
     * @return ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType
     */
    public ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeat() {

        logger.debug("Method: getHeartbeat for MWE");

        ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeatResponse = new ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType();
        try {
            getHeartbeatResponse = getClient().getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   " + mweHostName);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

        } catch (Throwable tow) {
            tow.printStackTrace();
            getHeartbeatResponse.setIpAddress(mweHostName);
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "getHeartbeat()", tow.getMessage());
            logger.error("Method: Throwable Exception: ", tow);
        }

        return getHeartbeatResponse;
    }
    
    /**
     * fetchRecoverableProcesses for the Madrid Workflow Engine.
     *
     * @return FetchRecoverableProcessesResponse
     */
    public FetchRecoverableProcessesResponse getErrorProcesses() {

        logger.debug("Method: getErrorProcesses");

        FetchRecoverableProcessesRequest fetchRecoverableProcessesRequest = new FetchRecoverableProcessesRequest();
        FetchRecoverableProcessesResponse fetchRecoverableProcessesResponse = new FetchRecoverableProcessesResponse();
        try {
            fetchRecoverableProcessesResponse = getClient().fetchRecoverableProcesses(fetchRecoverableProcessesRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

        } catch (Throwable tow) {
            tow.printStackTrace();
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "fetchRecoverableProcesses()", tow.getMessage());
            logger.error("Method: Throwable Exception: ", tow);
        }

        return fetchRecoverableProcessesResponse;
    }

    /**
     * Calls the Madrid Workfkow engine to assign users tasks to a user by a supervisor.
     *
     * @param activityTaskIds the activity task ids to be assigned
     * @param assignTo to whom the tasks are being assigned
     * @param assignedBy by whom the tasks are being assigned by
     * @throws MCServerException the MC server exception
     */
    public void reassignTaskGroup(List<String> activityTaskIds, String assignTo, String assignedBy)
        throws MCServerException {

        logger.debug("Method: reassignTaskGroup - activityTaskId " + activityTaskIds + " assignTo " + assignTo
            + ", assignedBy " + assignedBy);

        ReassignTaskGroupRequest reassignTask = new ReassignTaskGroupRequest();
        reassignTask.setGroupId(MadridGroup.getTupsAuthority(assignTo));
        reassignTask.setAuthId(assignedBy);
        reassignTask.getTaskIdList().addAll(activityTaskIds);

        try {
            getClient().reassignTaskGroup(reassignTask);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

        } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

            logger.error("Method: reassignTaskGroup - activityTaskId " + activityTaskIds + " assignTo " + assignTo
                + ", assignedBy " + assignedBy);
            logger.error("Method: reassignTaskGroup - CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.reassigntaskgroup"), e);

        } catch (Throwable e) {

            logger.error("Method: reassignTaskGroup - activityTaskId " + activityTaskIds + " assignTo " + assignTo
                + ", assignedBy " + assignedBy);
            logger.error("Method: reassignTaskGroup - Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "getHeartbeat()", e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.reassigntaskgroup"), e);
        }
    }

    /**
     * Calls the Madrid Workfkow engine to fetch information about a task such as what groups can it be assigned to..
     *
     * @param activityTaskId the activity task id of the task for which information is being fetched
     * @return the fetch task information response
     * @throws MCServerException the MC server exception
     */
    public FetchTaskInformationResponse fetchTaskInformation(String activityTaskId) throws MCServerException {

        logger.debug("Method: fetchTaskInformation - activityTaskId " + activityTaskId);

        FetchTaskInformationRequest paramFetchTaskInformationRequest = new FetchTaskInformationRequest();
        paramFetchTaskInformationRequest.setTaskId(activityTaskId);

        try {
            FetchTaskInformationResponse resp = getClient().fetchTaskInformation(paramFetchTaskInformationRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

            return resp;

        } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

            logger.error("Method: fetchTaskInformation - activityTaskId " + activityTaskId);
            logger.error("Method: fetchTaskInformation - CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.reassigntaskgroup"), e);

        } catch (Throwable e) {

            logger.error("Method: fetchTaskInformation - activityTaskId " + activityTaskId);
            logger.error("Method: fetchTaskInformation, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "getAuthorityRoleList()", e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.reassigntaskgroup"), e);
        }
    }
    

    /**
     */
    public void signalRecoverableProcesses(String executionId) throws MCServerException {

         logger.debug("Method: signalRecoverableProcesses - executionIdList: " + executionId);

        SignalRecoverableProcessesRequest signalRecoverableProcessesRequest = new SignalRecoverableProcessesRequest();
        signalRecoverableProcessesRequest.getExecutionIdList().add(executionId);

        try {
             getClient().signalRecoverableProcesses(signalRecoverableProcessesRequest);
             sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);

        } catch (ca.gc.ised.cipo.tm.mwe.MWEServiceFault e) {

            logger.error("Method: signalRecoverableProcesses - executionIdList " + executionId);
            logger.error("Method: signalRecoverableProcesses - CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MWE, true);
            
            // TODO fix error handling
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.reassigntaskgroup"), e);

        } catch (Throwable e) {

            logger.error("Method: signalRecoverableProcesses - executionIdList " + executionId);
            logger.error("Method: signalRecoverableProcesses, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MWE, mweHostName, "signalRecoverableProcesses()", e.getMessage());
            
            // TODO fix error handling
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mwe.reassigntaskgroup"), e);
        }
    }
}
