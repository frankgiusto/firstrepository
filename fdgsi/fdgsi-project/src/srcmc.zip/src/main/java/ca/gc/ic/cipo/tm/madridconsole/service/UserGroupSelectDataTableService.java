package ca.gc.ic.cipo.tm.madridconsole.service;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.userprofile.schema.BaseUserProfile;

/**
 *
 * Service for retrieving user & group list at task assignment page
 *
 * @author timyu
 *
 */
@Service
public class UserGroupSelectDataTableService {

    @Autowired
    private UserProfileServiceClient userProfileService;

    @Autowired
    private WorkflowEngineServiceClient workflowService;

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    /** The Constant log. */
    private final static Logger logger = Logger.getLogger(UserGroupSelectDataTableService.class);

    public String getUserDataTableResponse(HttpServletRequest request, String searchName, String group)
        throws MCServerException {

        String searchTerm = request.getParameter("search[value]");
        if (StringUtils.isNotBlank(request.getParameter("start"))) {
        }

        if (StringUtils.isNotBlank(searchTerm)) {
            searchTerm = searchTerm.toLowerCase();
        }

        if (StringUtils.isNotBlank(searchName)) {
            searchTerm = searchName.toLowerCase();
        } /*
           * else { searchName = "a"; }
           */

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        List<BaseUserProfile> userProfList = Collections.emptyList();

        userProfList = userProfileService.getUserProfilesForUserRole(request, group);

        for (BaseUserProfile userProf : userProfList) {

            if (StringUtils.isBlank(searchName)
                || (StringUtils.isNotBlank(searchName) && userProf.getName().equals(searchName))) {
                JSONArray taskColumn = new JSONArray();
                taskColumn.put(userProf.getName() == null ? "" : userProf.getName());
                taskColumn.put(userProf.getName() == null ? "" : userProf.getName());
                taskColumn.put(userProf.getUsername() == null ? "" : userProf.getUsername());
                taskColumn.put(userProf.getParentUserName() == null ? "" : userProf.getParentUserName());
                taskColumn.put(userProf.getSecurityLevelCode() == 2 ? "Y" : "");
                taskList.put(taskColumn);
            }
        }

        try {
            taskResults.put("iTotalRecords", userProfList.size());
            taskResults.put("iTotalDisplayRecords", userProfList.size());
            taskResults.put("spicyMeatball", "ya baby!");
            taskResults.put("data", taskList);

        } catch (JSONException e) {
            logger.error("Method: getUserDataTableResponse: Error retrieving user profiles due to JSON processing error"
                + ": " + e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.jsonerror"), e);
        }
        return taskResults.toString();
    }

    @SuppressWarnings("unused")
    public String getGroupDataTableResponse(HttpServletRequest request, List<String> tasklist)
        throws MCServerException {

        String searchTerm = null;
        int startRow = 0;
        int rowsPerPage = 10;
        int sortColumnIndex = 0;

        /* Get request parameters */
        String sortColumn = request.getParameter("order[0][column]");

        String sortDirection = request.getParameter("order[0][dir]");
        searchTerm = request.getParameter("search[value]");
        if (StringUtils.isNotBlank(request.getParameter("start"))) {
            startRow = Integer.valueOf(request.getParameter("start"));
            rowsPerPage = Integer.valueOf(request.getParameter("length"));
            sortColumnIndex = Integer.valueOf(sortColumn).intValue();
        }

        if (StringUtils.isNotBlank(searchTerm)) {
            searchTerm = searchTerm.toLowerCase();
        }

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        Map<String, String> groupMap = getGroupList(tasklist); // TODO: get it from MWE

        for (Map.Entry<String, String> entry : groupMap.entrySet()) {
            JSONArray taskColumn = new JSONArray();
            taskColumn.put(entry.getKey());
            taskColumn.put(entry.getValue());
            taskList.put(taskColumn);
        }
        try {
            taskResults.put("iTotalRecords", groupMap.size());
            taskResults.put("iTotalDisplayRecords", groupMap.size());
            taskResults.put("spicyMeatball", "ya baby!");
            taskResults.put("data", taskList);

        } catch (JSONException e) {
            logger.error(
                "Method: getGroupDataTableResponse: Error retrieving group information due to JSON processing error"
                    + ": " + e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.jsonerror"), e);
        }

        return taskResults.toString();
    }

    // get group list from workflow service
    private Map<String, String> getGroupList(List<String> tasklist) throws MCServerException {
        Map<String, String> userGroups = new LinkedHashMap<String, String>();

        // Will do this post CIF where we will validate which groups the task can be assigned to.
        // For now the Supervisor is responsible for the group he is reassigning a task to.
        /*
         * if (tasklist != null && tasklist.size() > 0) {
         *
         * // since all tasks are of the same type for reassigning, we can fetch information with first task
         * List<String> groups = workflowService.fetchTaskInformation(tasklist.get(0)).getAuthorityRoleList();
         *
         * for (String group : groups) { userGroups.put(MadridGroup.getMadridGroupName(group),
         * MadridGroup.getMadridGroupName(group)); } }
         */

        userGroups.put("Madrid TM Examiner",
            messageSource.getMessage("dashboard.label.tmexaminer", null, LocaleContextHolder.getLocale()));
        userGroups.put("Madrid TM Operator",
            messageSource.getMessage("dashboard.label.tmoperator", null, LocaleContextHolder.getLocale()));
        userGroups.put("Madrid TM Supervisor",
            messageSource.getMessage("dashboard.label.tmsuper", null, LocaleContextHolder.getLocale()));
        userGroups.put("TMOB Operator",
            messageSource.getMessage("dashboard.label.tmoboperator", null, LocaleContextHolder.getLocale()));
        userGroups.put("TMOB Supervisor",
            messageSource.getMessage("dashboard.label.tmobsuper", null, LocaleContextHolder.getLocale()));

        return userGroups;
    }
}
