package ca.gc.ic.cipo.tm.madridconsole.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;

import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.client.common.MadridTransactionServiceFactory;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.schema.HeartbeatResponseType;
//import ca.gc.ic.cipo.schema.id.hts.EventDetail;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.TransactionCriteria;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
@Service
public class WipoTransTransactionWSClient {

    protected static final Logger LOGGER = Logger.getLogger(WipoTransTransactionWSClient.class);

    MadridTransactionServicePortType madridTransactionServicePortType = null;

    @Value("${mc.transaction.server}")
    private String mtsHostName;
    
    @Autowired
    SendErrorEmail sendErrorEmail;

    public TransactionDetail getXML(long id)
        throws Exception {

        LOGGER.debug("Method: getXML, id: " + id + ", Transaction Service Call: getTransation");
        
        TransactionDetail response = null;
        try {
            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient( mtsHostName);
            response = madridTransactionServicePortType.getTransaction(new BigDecimal(id), true, true);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        }  catch (CIPOServiceFault csf) {
            LOGGER.error("Transaction service has CipoServiceFault. Method: getXML, url: " 
                + mtsHostName + ", id: " + id
                + ", Transaction Service Call: getTransation");
            LOGGER.error("CipoServiceFault: ", csf);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw (new Exception());
        }  catch (Throwable tow) {
            LOGGER.error("Transaction service has internal issue. Method: getXML, url: " 
                + mtsHostName + ", id: " + id
                + ", Transaction Service Call: getTransation");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, mtsHostName,
                "getTransaction(), id=" + id, tow.getMessage() );

            throw (new Exception());
        }
        return response;

    }

    public  List<TransactionDetail> getTransactionInfo(String packageId)
        throws Exception {

        LOGGER.debug("Mehtod: getTransactionInfo, packageId: " + packageId
            + ", Transaction Service Call: getTransactionList");
        
       TransactionCriteria transactionCriteria = new TransactionCriteria();
        List<BigDecimal> packageList = new ArrayList<BigDecimal>();
        
        packageList.add(new BigDecimal(packageId));
        transactionCriteria.setPackageIdList(packageList);
        
        List<TransactionDetail> response = null;
        
        try {
            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient(mtsHostName);
            
            // Make the call to the Service    
            response = madridTransactionServicePortType.getTransactionList(transactionCriteria);
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            
        }  catch (CIPOServiceFault csf) {
            LOGGER.error("Transaction service has CIPOServiceFault. Console Method: getTransactionInfo, url: " 
                + mtsHostName
                + ", packageId: " + packageId + ", Transaction Service Call: getTransactionList");
            LOGGER.error("CIPOServiceFault: ", csf);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw (new Exception());
        }  catch (Throwable tow) {
            LOGGER.error("Transaction service has internal issue. Console Method: getTransactionInfo, url: "
                + mtsHostName 
                + ", packageId: " + packageId + ", Transaction Service Call: getTransactionList");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, mtsHostName,
                "getTransactionList()", tow.getMessage() );
            throw (new Exception());
        }
        
        return response;
    }

    public  TransactionDetail getTransactionDetail(Long transid)
        throws Exception {

        LOGGER.debug("Mehtod: getTransactionDetail, transid: " + transid
            + ", Transaction Service Call: getTransaction");
                
        TransactionDetail transactionDetail = new TransactionDetail();
        try {
            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient(mtsHostName);

            // Make the call to the Service    
            transactionDetail = madridTransactionServicePortType.getTransaction(new BigDecimal(transid), false, false); 
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            
        }  catch (CIPOServiceFault csf) {
            LOGGER.error("Transaction service has CipoServiceFault. Console Method: getTransactionDetail, url: " 
                + mtsHostName 
                + ", transid: " + transid
                + ", Transaction Service Call: getTransaction");
            LOGGER.error("CipoServiceFault: ", csf);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw (new Exception());
        }  catch (Throwable tow) {
            LOGGER.error("Transaction service has internal issue. Console Method; getTransactionDetail, url: " + mtsHostName 
                + ", transid: " + transid
                + ", Transaction Service Call: getTransaction");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, mtsHostName,
                "getTransactionDetail()", tow.getMessage() );
           throw (new Exception());
        }
        
        return transactionDetail;
    }

    public  TransactionDetail getTransactionAttachments(Long transid)
        throws Exception {

        LOGGER.debug("Method: getTransactionAttachments, transid: " + transid + ", url: "  + mtsHostName
            + ", Transaction Service Call: getTransaction");
        
        TransactionDetail transactionDetail = new TransactionDetail();
        try {
            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient(mtsHostName);
            
            // Make the call to the Service    
            transactionDetail = madridTransactionServicePortType.getTransaction(new BigDecimal(transid), false, false); 
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            
        }  catch (CIPOServiceFault csf) {
            LOGGER.error("Transaction service has CipoServiceFault. Console Method: getTransactionAttachments, url: " 
                + mtsHostName  + ", transid: " + transid
                + ", Transaction Service Call: getTransaction");
            LOGGER.error("CipoServiceFault: ", csf);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw (new Exception());
        }  catch (Throwable tow) {
             LOGGER.error("Transaction service has internal issue. Console Method; getTransactionAttachments, url: " 
                 + mtsHostName 
                + ", transid: " + transid + ", Transaction Service Call: getTransaction");
             LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
             sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, mtsHostName,
                 "getTransaction(id, false, false)", tow.getMessage() );
            throw (new Exception());
        }
        
        return transactionDetail;
    }

    public  AttachmentDetail getAttachment(Long attachmentid)
        throws Exception {

        LOGGER.debug("Method: getAttachment, attachmentid: " + attachmentid + ", url: "  + mtsHostName
            + ", Transaction Service Call: getTransactionAttachment");
        
        AttachmentDetail attachmentDetail = new AttachmentDetail();
        try {
            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient(mtsHostName);
            
            // Make the call to the Service    
            attachmentDetail = madridTransactionServicePortType.getTransactionAttachment(new BigDecimal(attachmentid));
            
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            
        }  catch (CIPOServiceFault csf) {
            LOGGER.error("Transaction service has CipoServiceFault. Console Method: getAttachment, url: " 
                + mtsHostName + ", attachmentid: " + attachmentid
                + ", Transaction Service Call: getTransactionAttachment");
            LOGGER.error("CipoServiceFault: ", csf);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw (new Exception());
        }  catch (Throwable tow) {
            LOGGER.error("Transaction service has internal issue. Console Method; getAttachment, url: " + mtsHostName 
                + ", attachmentid: " + attachmentid
                + ", Transaction Service Call: getTransactionAttachment");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, mtsHostName,
                "getTransactionAttachment(id)", tow.getMessage() );
            throw (new Exception());
        }
        
        return attachmentDetail;
    }

    
    
//    public  List<EventDetail> getEventsInfo(String transid)
//        throws Exception {
//
//        List<EventDetail> response = null;
//        
//        LOGGER.debug("Method: getEventsInfo, transid: " + transid + ", url: "  + MadridConsoleWebApp.getInstance().getTransactionServices());
//        
//        try {
//            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient(mtsHostName);
//            
//            // Make the call to the Service    
//            response = madridTransactionServicePortType.getTransactionEventList(new BigDecimal(transid));
//            
//        }  catch (CIPOServiceFault csf) {
//            LOGGER.error("Transaction service has CipoServiceFault. Console Method: getEventsInfo, url: " 
//                + mtsHostName
//                + ", transid: " + transid
//                + ", Transaction Service Call: getTransactionEventList");
//            LOGGER.error("CipoServiceFault: ", csf);
//            throw (new Exception());
//        }  catch (Throwable tow) {
//            LOGGER.error("Transaction service has internal issue. Console Method; getEventsInfo, url: " 
//                + mtsHostName 
//                + ", transid: " + transid  + ", Transaction Service Call: getTransactionEventList");
//            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
//            throw (new Exception());
//        }
//        
//        return response;
//    }
    /**
     */
    @SuppressWarnings("null")
    public ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeat() {

        LOGGER.debug("Method: getHeartbeat " );

        ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType getHeartbeatResponse = new ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType();
        try {
            madridTransactionServicePortType = MadridTransactionServiceFactory.createMadridTransactionClient(mtsHostName);
            getHeartbeatResponse = madridTransactionServicePortType.getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   "  + mtsHostName);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
         } catch (Throwable tow) {
            getHeartbeatResponse.setIpAddress(mtsHostName);
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            LOGGER.error("Throwable Exception Recevied, Throwable: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, mtsHostName,
                "getHeartbeat()", tow.getMessage() );
        }

        return getHeartbeatResponse;
    }
}
