package ca.gc.ic.cipo.tm.madridconsole.service.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.service.intl.WipoTransPackageService;
import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransPackageWSClient;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.PackageBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForPkg;
import ca.gc.ic.cipo.tm.schema.mps.EventDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageDetail;


@Service
public class WipoTransPackageServiceImpl implements WipoTransPackageService {

    protected static final Logger LOGGER = Logger.getLogger(WipoTransPackageServiceImpl.class);

    @Autowired
    private ServletContext servletContext;

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    @Autowired
    private WipoTransPackageWSClient wipoTransPackageWSClient;

    List<PackageBean> packageList;

    /**
     * This will get the List of Packages, to display in the Search Results 
     * 
     * @param type - The Package Type to Search for
     * @param period - The period
     * @param loc - Local
     * @param status - package status
     * @param startdate - start Date
     * @param enddate - end date 
     * 
     * @return ReturnObjForPkg - which is a list of packages (i.e., a list of PackageBean)
     * 
     * @throws Exception
     */
    public ReturnObjForPkg getPackageList(String type, int period, Locale loc, String status, String startdate,
                                          String enddate)
        throws Exception {
        
        LOGGER.debug("Method: getPackageList, type: " + type + ", period: " + period + ", status: " + status + ", startdate: " + startdate + ", enddate: " + enddate );

        packageList = new ArrayList<PackageBean>();

        List<PackageDetail> response_packageInfo  = null;
        
        try {
            response_packageInfo = wipoTransPackageWSClient.getPackageInfo(type, period, loc.getLanguage(), status, startdate,
                enddate);

            LOGGER.debug("Method: getPackageList, Number of packages: " + response_packageInfo.size() );
            
            for (int x = 0; x < response_packageInfo.size(); x++) {
            
                PackageDetail pkg = response_packageInfo.get(x);
                
                StringBuilder pdfLink = new StringBuilder();
                PackageBean pb = new PackageBean();
                
                pb.setPackageId(pkg.getPackageId().toString());
                pb.setTransactionDate(DateFormats.getISOSDFDateTime().format(pkg.getCreatedOn()).toString());
                
                pb.setType(pkg.getPackageType().getCategory()); 
                pb.setStatus(pkg.getCurrentStatus().getCategory()); 
                    
                pb.setIntlPubId(pkg.getIntlPblctnId());
                pb.setNumberOfAttachments(pkg.getAttachments().size());
                pb.setIntlPubId(pkg.getIntlPblctnId());
 
                if(pkg.getIntlPblctnDt() != null ) {
                    pb.setIntlPubDate(DateFormats.getISOSDF().format(pkg.getIntlPblctnDt()).toString());
                } else {
                    pb.setIntlPubDate("");
                }
            
                pdfLink = new StringBuilder();

                // if the Package Status is MPS_EXPORT_BUILD_PACKAGE, then it currently is being packaged,
                // which may be a long process, therefore do not show any Actions, until the process is
                // complete
                 if (!pkg.getCurrentStatus().getCategory().equalsIgnoreCase("MPS_EXPORT_BUILD_PACKAGE")) {
                    
                    pdfLink.append("<a class=\"btn btn-xs\" style=\"background-color: transparent;\"  title=\"" + messageSource.getMessage("wipotransmissions.icon.download.title", null, loc) + "\"  href='").append(servletContext.getContextPath())
                        .append("/package/getPackageFile/" + pb.getPackageId()
                            + "'><i class=\" fas fa-download fa-lg\" aria-hidden=\"true\" ></i>" + "</a>");
  
                     // Transactions
                     pdfLink.append("<button class=\"btn  btn-xs\" style=\"background-color: transparent;\"  title=\"" + messageSource.getMessage("wipotransmissions.icon.view.transactions.title", null, loc) + "\" href=\"#\"  onclick=getTransactionData(" + pb.getPackageId() 
                          + "); ><i class=\" far fa-list-alt fa-lg\" aria-hidden=\"true\" ></i>" + "</button>");

                     // Attachments for the Package (if there are any)
                     if (pkg.getAttachments().size() > 0) {
                         pdfLink.append("<button class=\"btn btn-xs\" style=\"background-color: transparent;\"  title=\"" + messageSource.getMessage("wipotransmissions.icon.view.attachments.title", null, loc) + "\" href=\"#\"  onclick=getPackageAttachmentData(" + pkg.getPackageId() 
                             + ")><i class=\" fas fa-paperclip fa-lg\" aria-hidden=\"true\" ></i>" + "</button>");
                     }
                     // Package Events
                     pdfLink.append("<button class=\"btn btn-xs\" style=\"background-color: transparent;\" title=\"" + messageSource.getMessage("wipotransmissions.icon.view.events.title", null, loc) + "\" onclick=getPackageEventsData(" + pkg.getPackageId()
                     + ")> <span class=\"fa-layers fa-fw\"><i class=\"far fa-calendar fa-lg\" aria-hidden=\"true\" ></i>" 
                     +  "<span class=\"fa-layers-text\" data-fa-transform=\"shrink-8 down-3\" style=\"font-weight:900\">31</span></span>"
                     + "</button>");
                     
                     // For MADRID_OFFICE_TO_IB allow download of Notifications
                     if (pkg.getPackageType().getCategory().equalsIgnoreCase("MADRID_NOTIFICATION_XML")) {
                         pdfLink.append("<a class=\"btn btn-xs\" style=\"background-color: transparent;\"  title=\"" + messageSource.getMessage("wipotransmissions.icon.download.notification", null, loc) + "\"  href='").append(servletContext.getContextPath())
                         .append("/package/getPackageNotification/" + pb.getPackageId()
                             + "'><i class=\" far fa-bell fa-lg\" aria-hidden=\"true\" ></i>" + "</a>");
                     }

                 }
                pb.setActions(pdfLink.toString());
                packageList.add(pb);
            }
        } catch (Exception ex) {
            LOGGER.error("Exception Recevied getPackageList(), type: " + type + ", period: " + period 
                + ", loc: " + loc + ", status: " + status + ", startdate: " + startdate + ", enddate: " + enddate);
            ex.printStackTrace();
            throw ex;
       }            
 
        return new ReturnObjForPkg(packageList);
    }
    /**
     * Obtain a list of events (EventDetail) for a Package Id.
     * 
     * @param packageId - Package Id (String)
     * @return List<EventDetail> - List of EventDetail objects
     * @throws Exception
     */
    public List<EventDetail> getEventsInfo(String packageId) throws Exception {
        
        List<EventDetail> listEventDetail = null; 
        listEventDetail = wipoTransPackageWSClient.getPackageEvents(Long.parseLong(packageId));
        return listEventDetail;   
    }
 
 }