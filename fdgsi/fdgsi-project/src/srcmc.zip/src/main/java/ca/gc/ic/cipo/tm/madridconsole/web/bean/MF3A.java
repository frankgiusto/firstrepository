package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;


public class MF3A implements Serializable {

    private static final long serialVersionUID = 1L;
    
    List<File> mf3aFiles = new ArrayList<>();

    ProcessManualReportRequest mf3aRequest = new ProcessManualReportRequest();

    
    public List<File> getMf3aFiles() {
        return mf3aFiles;
    }

    
    public void setMf3aFiles(List<File> mf3aFiles) {
        this.mf3aFiles = mf3aFiles;
    }

    
    public ProcessManualReportRequest getMf3aRequest() {
        return mf3aRequest;
    }

    
    public void setMf3aData(ProcessManualReportRequest mf3aRequest) {
        this.mf3aRequest = mf3aRequest;
    }

    @Override
    public String toString() {
        return "MF3A [mf3aRequest=" + 
            "IpOffice: " +  mf3aRequest.getIpOffice()+
            ", IrNumber: " +  mf3aRequest.getIrNumber()+
            ", LanguageCode: " +  mf3aRequest.getLanguageCode()+
            ", OwnerName: " +  mf3aRequest.getOwnerName()+
//            ", GroundsOfOppositionCodes: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getGroundsOfOppositionCodes()+
//            ", ProvisionalRefusalScope: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getProvisionalRefusalScope()+
//            ", OpponentName: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getProvisionalRefusalDetail().getOpponentName()+
//            ", OpponentAddress: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getProvisionalRefusalDetail().getOpponentAddress()+
//            ", ProvisionalRefusalInfo: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getProvisionalRefusalDetail().getProvisionalRefusalInfo()+
//            ", TimeLimitDate: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getReviewOrFileAppeal().getTimeLimitDate()+
//            ", RegistrarAuthority: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getReviewOrFileAppeal().getRegistrarAuthority()+
//            ", CorrespondanceLanguage: " +  mf3aRequest.getManualReportForm().getProvisionalRefusalMF3AType().getReviewOrFileAppeal().getCorrespondanceLanguage()+
            "]";
    }



    
}
