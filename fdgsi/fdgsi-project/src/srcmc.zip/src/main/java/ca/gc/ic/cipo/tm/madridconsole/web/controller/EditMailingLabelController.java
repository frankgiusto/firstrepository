package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.madridconsole.web.validator.EditMailingLabelValidator;
import ca.gc.ic.cipo.tm.madridconsole.web.validator.MF9Validator;

@Controller
@SessionAttributes("wipogs")
public class EditMailingLabelController {

    private static Logger logger = Logger.getLogger(EditMailingLabelController.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;
    
    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * @param request
     * @return
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    @Autowired
    private TradMarkApplicationService tmAppService;

    @Autowired
    private WorkflowEngineServiceClient mweClient;

    @Autowired
    private UserProfileServiceClient userProfileService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * This will obtain the "current" Mailing Label, to be displayed on the screen, for the user to update.
     
     *
     */
    @RequestMapping(value = "/processtask/editMailingLabel", method = RequestMethod.POST)
    public String displayEditMailingLabelPage(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                              @RequestParam(value = "irNum", required = false) String irNum,
                                              @RequestParam(value = "transIds", required = false) List<String> transIds,
                                              @RequestParam(value = "taskId", required = false) String taskId,
                                              @RequestParam(value = "aId", required = false) String actId,
                                              @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, Locale locale, Model model,
                                              final ModelMap modelMap, HttpServletRequest request,
                                             HttpServletResponse response, HttpSession session) {

        logger.debug("Method: displayEditMailingLabelPage  RequestMethod.POST");

        int fileNumber = 0;
        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
        
        try {

                fileNumber = Integer.parseInt(fileNumberStr);
                ArrayList<String> actIds = new ArrayList<String>();
                actIds.add(actId);
   
                // Assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                    } catch (Exception e) {
                        logger.error("Exception: ", e);
                    }
                }

                if (gsBean == null) {
                    gsBean = new GoodServiceWipoBean();
                }
                gsBean.clearCache();
                tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                    new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.EDIT_MAILING_LABEL_FORM);

        } catch (MCServerException e) {
            logger.error("Error processing displayEditMailingLabelPage: filenumber: " + fileNumberStr + ", transIds.get(0): "
                + transIds.get(0) + ",irNum: " + irNum);
            logger.error(
                messageSource.getMessage("mc.edit.mailing.address.error.procssing", null, locale) + " - " + e.getMessage());

            // Display "Error" information Message.
            try {
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.edit.mailing.address.error.procssing", null, locale) + " - " + e.getMessage());
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
                e1.printStackTrace();
            }
        }

        gsBean.setTransactionId(new BigDecimal(transIds.get(0)));
        gsBean.setInternationalRegistrationNumber(irNum);
        return "redirect:/processtask/editMailingLabel";
    }

    /**
     * POST (i.e. Get) Request - for EmailMailingLabel. Obtain the values for the pre-populated fields on the form.
     *
     * @param wipogs - GoodServiceWipoBean
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/editMailingLabel", method = RequestMethod.GET)
    public String prepareSelectPage(final ModelMap modelMap, final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                    HttpServletRequest request) {

        logger.debug("Method: displayEditMailingLabelPage  RequestMethod.GET");
        
        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);
        // populate the model Map as needed
        return "EditMailingLabel";
    }


    /**
     * Depending upon the Action that this method is called with
     * 
     * If Action is NEXT....Submit the Mailing Label, for processing by MTS.
     * Once this is done, then complete the task (calling worklfow.completeTask)
     *
     * If Action is CANCEL....returning to the refering page.

     * @param wipogs - GoodServiceWipoBean
     * @param errors - BindingResult
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/editMailingLabel/submit", method = RequestMethod.POST)
    public String gsEditMailingLabelSubmitForm(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     Locale locale, ModelMap model, final HttpServletRequest request,
                                     final HttpServletResponse response, HttpSession session,
                                     final RedirectAttributes redirectAttributes) {

        logger.debug("/processtask/EditMailingLabel/submit RequestMethod.POST ");

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
        String viewName = "";

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(actionVal)) {
            
            // Perform validation
            EditMailingLabelValidator validator = new EditMailingLabelValidator();
            validator.validate(gsBean, errors);
            if (errors.hasErrors()) {
                model.addAttribute("errors", errors);
                return "EditMailingLabel";
            }
   
            try {
    
                // Process the EmailMailingLabel (i.e., submit new Email Mailing Label)
                tmAppService.processEditMailingLabel(request, gsBean);
    
                // Call Workflow Engine to Complete Task
                mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));
    
                // Send the Success Message
                redirectAttributes.addFlashAttribute("infoMsg",
                    messageSource.getMessage("mc.edit.mailing.address.success", null, locale));
    
            } catch (MCServerException e) {
                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.edit.mailing.address.error.procssing", null, locale) + " - " + e.getMessage());
            }
            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(actionVal)) {

            viewName = "redirect:" + session.getAttribute("refererPage");
            
        }
 
        // Assuming everything has been successful, so far, clear out the GoodServiceWipoBean Data.
        session.setAttribute("wipogs", null);

        return viewName;

    }
    
    
    /**
     * This is the GET, used to submit the Email Mailing Address information, used for the Courtsy Letter to WIPO. 
     * For Example: this method will be executed when the user changes or switches Language  (i.e., English to French and visa-versa), after they
     * have done a Submit, wich resulted in Error Messages
     *
     * @param gsBean - GoodServiceWipoBean
     * @param errors - BindingResult
     * @param locale - Locale
     * @param session - HttpSession
     * @param request -HttpServletRequest
     * @param redirectAttributes - RedirectAttributes
     * @return String - JSP
     *
     */
    @RequestMapping(value = "/processtask/editMailingLabel/submit", method = RequestMethod.GET)
    public String gsEditMailingLabelSubmitFormGet(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     Locale locale, ModelMap model, final HttpServletRequest request,
                                     final HttpServletResponse response, HttpSession session,
                                     final RedirectAttributes redirectAttributes) {

        logger.debug("/processtask/EditMailingLabel/submit RequestMethod.GET ");

        return "EditMailingLabel";

    }
}
