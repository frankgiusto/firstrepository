package ca.gc.ic.cipo.tm.madridconsole.service.impl;

import java.io.File;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.madridconsole.service.intl.IAdminPageDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.service.mef.MEFServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mfs.MFSServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tirs.TIRSServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransPackageWSClient;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransTransactionWSClient;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransUtils;
import ca.gc.ised.cipo.tm.mwe.FetchRecoverableProcessesResponse;
import ca.gc.ised.cipo.tm.mwe.RecoverableProcess;

/**
 *
 * Service for retrieving data for Wipo Transmissions datatable
 *
 */
@Service
public class WipoTransAdminPageDataTableService implements IAdminPageDataTableService {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(WipoTransAdminPageDataTableService.class);

    @Autowired
    private WipoTransPackageWSClient wipoTransPackageWSClient;

    @Autowired
    private WipoTransTransactionWSClient wipoTransTransactionWSClient;

    @Autowired
    private WorkflowEngineServiceClient workflowEngineServiceClient;

    @Autowired
    private TIRSServiceClient tIRSServiceClient;

    @Autowired
    private MEFServiceClient mEFServiceClient;

    @Autowired
    private MFSServiceClient mFSServiceClient;

    @Autowired
    private UserProfileServiceClient userProfileServiceClient;

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    @Autowired
    private ServletContext servletContext;

    @Override
    public String getHeartBeatDataTableResponse() throws Exception {
        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        HeartbeatResponseType heartbeatResponseType = wipoTransPackageWSClient.getHeartbeat();

        JSONArray taskColumn = new JSONArray();

        taskColumn.put("MPS");
        taskColumn.put(heartbeatResponseType.getIpAddress());
        taskColumn.put(heartbeatResponseType.getNodeName());
        taskColumn.put(heartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        heartbeatResponseType = wipoTransTransactionWSClient.getHeartbeat();
        taskColumn = new JSONArray();
        taskColumn.put("MTS");
        taskColumn.put(heartbeatResponseType.getIpAddress());
        taskColumn.put(heartbeatResponseType.getNodeName());
        taskColumn.put(heartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        heartbeatResponseType = workflowEngineServiceClient.getHeartbeat();
        taskColumn = new JSONArray();
        taskColumn.put("MWE");
        taskColumn.put(heartbeatResponseType.getIpAddress());
        taskColumn.put(heartbeatResponseType.getNodeName());
        taskColumn.put(heartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        heartbeatResponseType = mFSServiceClient.getHeartbeat();
        taskColumn = new JSONArray();
        taskColumn.put("MFS");
        taskColumn.put(heartbeatResponseType.getIpAddress());
        taskColumn.put(heartbeatResponseType.getNodeName());
        taskColumn.put(heartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType mefHeartbeatResponseType = mEFServiceClient.getHeartbeat();
        taskColumn = new JSONArray();
        taskColumn.put("MEF");
        taskColumn.put(mefHeartbeatResponseType.getIpAddress());
        taskColumn.put(mefHeartbeatResponseType.getNodeName());
        taskColumn.put(mefHeartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        ca.gc.ic.cipo.schema.HeartbeatResponseType tIRSheartbeatResponseType = null;
        tIRSheartbeatResponseType = tIRSServiceClient.getHeartbeat();
        taskColumn = new JSONArray();
        taskColumn.put("TIRS");
        taskColumn.put(tIRSheartbeatResponseType.getIpAddress());
        taskColumn.put(tIRSheartbeatResponseType.getNodeName());
        taskColumn.put(tIRSheartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        HeartbeatResponseType tupsHeartbeatResponseType = userProfileServiceClient.getHeartbeat();
        taskColumn = new JSONArray();
        taskColumn.put("TUPS");
        taskColumn.put(tupsHeartbeatResponseType.getIpAddress());
        taskColumn.put(tupsHeartbeatResponseType.getNodeName());
        taskColumn.put(tupsHeartbeatResponseType.getStatus().toUpperCase());
        taskList.put(taskColumn);

        try {

            taskResults.put("data", taskList);
        } catch (Exception se) {
            throw se;
        }

        return taskResults.toString();

    }

    @Override
    public String getErrorProceeseDataTableResponse() throws Exception {

        Locale loc = new Locale("en");
        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        FetchRecoverableProcessesResponse fetchRecoverableProcessesResponse = new FetchRecoverableProcessesResponse();

        JSONArray taskList = new JSONArray();
        JSONArray taskColumn = new JSONArray();
        StringBuilder pdfLink = new StringBuilder();
        fetchRecoverableProcessesResponse = workflowEngineServiceClient.getErrorProcesses();

        logger.debug("method: getErrorProceeseDataTableResponse Numb of Errors: "
            + fetchRecoverableProcessesResponse.getRecoverableProcessList().size());

        for (int x = 0; x < fetchRecoverableProcessesResponse.getRecoverableProcessList().size(); x++) {

            RecoverableProcess recoverableProcess = fetchRecoverableProcessesResponse.getRecoverableProcessList()
                .get(x);
            taskColumn = new JSONArray();
            taskColumn.put(DateFormats.getISOSDF().format(recoverableProcess.getProcessStartTime()).toString());
            taskColumn.put(recoverableProcess.getExecutionId());
            try {
                taskColumn.put(messageSource.getMessage(
                    WipoTransUtils.transactionTypeEnum.valueOf(recoverableProcess.getTransactionType()).typeMsg(), null,
                    loc));
            } catch (Exception iae) {
                taskColumn.put(recoverableProcess.getTransactionType());
            }

            taskColumn.put(recoverableProcess.getCallingProcess());
            taskColumn.put(recoverableProcess.getErrorMsg());
            pdfLink = new StringBuilder();
            pdfLink
                .append("<a class=\"btn btn-primary btn-xs\" style=\"\"  title=\""
                    + messageSource.getMessage("wipotransmissions.icon.download.title", null, loc) + "\"  href='")
                .append(servletContext.getContextPath())
                .append("/admin/sendrecovery/" + recoverableProcess.getExecutionId()
                    + "'><i class=\" fas fa-cogs mrgn-tp-sm\" aria-hidden=\"true\" ></i>" + "</a>");
            taskColumn.put(pdfLink);
            taskList.put(taskColumn);

       }

        try {
            taskResults.put("data", taskList);
        } catch (Exception se) {
            throw se;
        }

        return taskResults.toString();

    }

    @Override
    public String getJarFilesDataTableResponse(ServletContext context) throws Exception {
        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        JSONArray taskColumn = new JSONArray();
        String[] f = new File(context.getRealPath("WEB-INF/lib")).list();
        for (int i = 0; i <= f.length - 1; i++) {
            if (f[i].contains("CIPO") || f[i].contains("cipo") || f[i].contains("madrid")) {
                taskColumn = new JSONArray();
                taskColumn.put(f[i].split("\\.")[0].substring(0, f[i].split("\\.")[0].length() - 2));
                taskColumn.put(f[i].substring(f[i].split("\\.")[0].length() - 1, f[i].length() - 4));

                taskList.put(taskColumn);
            }
        }
        try {

            taskResults.put("data", taskList);
        } catch (Exception se) {
            throw se;
        }
        return taskResults.toString();

    }
    
    public String sendrecovery(String executionId)
        throws Exception {
        
        workflowEngineServiceClient.signalRecoverableProcesses(executionId);
        return null;
    }


}
