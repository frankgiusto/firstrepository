package ca.gc.ic.cipo.tm.madridconsole.service.intl;

import java.util.List;
import java.util.Locale;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForPkg;
import ca.gc.ic.cipo.tm.schema.mps.EventDetail;

public interface WipoTransPackageService {

    ReturnObjForPkg getPackageList(String type, int perid, Locale loc, String status, String startDate, String endDate)
        throws Exception;

    List<EventDetail> getEventsInfo(String packageId) throws Exception;
}