package ca.gc.ic.cipo.tm.madridconsole.web.validator;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;

public class MF3AValidator  {
    
    // Log4J logger.
    private final Logger logger = Logger.getLogger(getClass());
      
    
    public void validate (GoodServiceWipoBean goodServiceWipoBean, Errors errors) {

        logger.debug("Validate MF3A: " + goodServiceWipoBean.getMf3a().toString());          

//        // Check if "Office making the notification " has been entered (i.e., it is required!)
//        if (goodServiceWipoBean.getMf3a().getOfficeMakingNotification() == null || goodServiceWipoBean.getMf3a().getOfficeMakingNotification().isEmpty()) {
//            errors.rejectValue("mf3a.officeMakingNotification", null, "mc.mf3a.error.office.making.notification.req");
//        }
//        
//        // Check if "Number of the International Registration " has been entered (i.e., it is required!)
//        if (goodServiceWipoBean.getMf3a().getNumbOfTheIntlReg() == null || goodServiceWipoBean.getMf3a().getNumbOfTheIntlReg().isEmpty()) {
//            errors.rejectValue("mf3a.numbOfTheIntlReg", null, "mc.mf3a.error.numb.of.intl.reg.req");
//        }
//
//        // Check if "Number of the International Registration " has been entered (i.e., it is required!)
//        if (goodServiceWipoBean.getMf3a().getNameOfHolder() == null || goodServiceWipoBean.getMf3a().getNameOfHolder().isEmpty()) {
//            errors.rejectValue("mf3a.nameOfHolder", null, "mc.mf3a.error.name.of.holder.req");
//        }
//        
    }
}
