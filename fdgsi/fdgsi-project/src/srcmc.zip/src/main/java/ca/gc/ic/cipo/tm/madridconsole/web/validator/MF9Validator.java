package ca.gc.ic.cipo.tm.madridconsole.web.validator;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;

public class MF9Validator  {
    
    // Log4J logger.
    private final Logger logger = Logger.getLogger(getClass());
      
    
    public void validate (GoodServiceWipoBean goodServiceWipoBean, Errors errors) {

        logger.debug("Validate MF9: " + goodServiceWipoBean.getMf9().toString());          

        // Check if  Facts and Decisions affecting the basic application  (i.e., Section I(V on MF9 Form)  has been entered (i.e., it is required!)
        if (goodServiceWipoBean.getMf9().getMf9Request().getManualReportForm().getCeasingOfEffectMF9Type().getCeasingOfEffectDecision() == null 
            || goodServiceWipoBean.getMf9().getMf9Request().getManualReportForm().getCeasingOfEffectMF9Type().getCeasingOfEffectDecision().trim().isEmpty()) {
            errors.rejectValue("mf9.mf9Request.manualReportForm.ceasingOfEffectMF9Type.ceasingOfEffectDecision", null, "mc.mf9.error.facts.and.decisions.req");
        }

        
        // Check if Effective Date (i.e., Section V on MF9 Form)  has been entered (i.e., it is required!)
        if (goodServiceWipoBean.getMf9().getMf9Request().getManualReportForm().getCeasingOfEffectMF9Type().getCeasingEffectiveInfo() == null 
            || goodServiceWipoBean.getMf9().getMf9Request().getManualReportForm().getCeasingOfEffectMF9Type().getCeasingEffectiveInfo().isEmpty()) {
            errors.rejectValue("mf9.mf9Request.manualReportForm.ceasingOfEffectMF9Type.ceasingEffectiveInfo", null, "mc.mf9.error.effective.date.req");
        }
    }
}
