package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;

import _int.wipo.standards.xmlschema.st96.common.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.IrregularityType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridCorrectionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionCategoryType;
import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClassificationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesStatementType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;

/**
 * The Class GoodServiceWipoBean is the Model containing the data for all Manual tasks.
 */
public class GoodServiceWipoBean implements Serializable {

    private static final long serialVersionUID = 5008816676258959714L;

    /** The international registration number. */
    String internationalRegistrationNumber;

    /** The international registration number for previous owner in case of partial ownership. */
    String internationalRegistrationNumberForPreviousOwner;

    /** Comments from WIPO. */
    List<String> wipoComments = new ArrayList<String>();

    /** Comments from WIPO for previous owner in case of partial ownership. */
    List<String> wipoCommentsForPreviousOwner = new ArrayList<String>();

    /** The REST category type of the task such as LIMITATION, PARTIAL CEASING, PARTIAL OWNERSHIP etc. */
    MadridProtectionRestrictionCategoryType restCategoryType = MadridProtectionRestrictionCategoryType.LIMITATION;

    /** The Correction type. */
    MadridCorrectionType correctionType = new MadridCorrectionType();

    /* Correction Record Identifier */
    String correctionRecordIdentifier = new String();

    /* Correction IR Number */
    String correctionIRNumber = new String();

    /* Correction Orig Trans */
    String correctionOrigTrans = new String();

    /* Correction Corrected Trans */
    String correctionCorrTrans = new String();

    /* Correction contains the Corrected Content */
    Boolean correctionContent = false;;

    /** The Irregularity types. */
    List<IrregularityType> irregularityTypes = new ArrayList<IrregularityType>();

    /** File Number Locked **/
    int fileNumberLocked;

    /** File Extension Locked **/
    int fileExtensionLocked;

    String mailingLabel = new String();

    /** The Language code to use for manual task from INTREPID. */
    ISOLanguageCodeType langCode = ISOLanguageCodeType.EN;

    /** The Id of the task. */
    BigDecimal taskId;

    /** The Id of the transaction. */
    BigDecimal transactionId;

    /** The activity task id from MWE associated with the task. */
    String activityTaskId;

    /** The application from INTREPID. */
    TrademarkApplicationType application;

    /** The INTREPID G&S types. */
    List<GoodsServicesClaimsType> intrepidGsTypes = new ArrayList<GoodsServicesClaimsType>();

    /** The INTREPID G&S types for NANR Partial Ceasing and Basic Application. */
    SortedMap<Integer, List<BasicMarksByNiceClass>> intrepidGsTypesForBasicMarks = new TreeMap<Integer, List<BasicMarksByNiceClass>>();

    /** Action being performed when processing manual tasks. */
    private String action;

    /** Application type. */
    private Long applicationType;

    /** Service Item type containing the selected G&S option such as accept all, with adjustment or no effect etc. */
    private Long serviceItemType;

    /** The gs list for good and services tasks as well as MADRID designation for new owner in partial ownership. */
    List<ReturnObjForGoodsAndServices> gsList = new ArrayList<ReturnObjForGoodsAndServices>();

    /** The prevgs list for the MADRID protection restriction for previous owner in partial ownership. */
    List<ReturnObjForGoodsAndServices> prevgsList = new ArrayList<ReturnObjForGoodsAndServices>();

    /** The gs list for good and services tasks for NA NAR Partial Ceasing. */
    List<ReturnObjForGoodsAndServicesForNANR> gsListNANR = new ArrayList<ReturnObjForGoodsAndServicesForNANR>();

    /** The gs list for basic applications that make up an IR for NA/NR Partial Ceasing and Basic Applications tasks. */
    List<ReturnObjForBasicMarks> basicMarksWithGS = new ArrayList<ReturnObjForBasicMarks>();

    private TransactionDetail transactionDetail;

    /** Original Transaction that was sent to WIPO */
    private TransactionDetail origTransactionDetail;

    /** Used for MF3a form */
    private MF3A mf3a;

    /** Used for MF3a form - possible Cited Marks */
    List<GroundsOfOpposition> groundsOfOppositionList = new ArrayList<GroundsOfOpposition>();

    /** Used for the MF9 form */
    private MF9 mf9;

    /** Used for the MF13 form displayed when saving on G&S Limitation screen */
    private MF13 mf13;

    /** For irregularity manual tasks */
    private IrregularityDetail irregularityDetail;

    /** Copy all flag on WIPO column in G&S manual task page */
    private boolean copyAllOptionForWIPO;

    /** Copy all flag on INTREPID column in G&S manual task page */
    private boolean copyAllOptionForINTREPID;

    /** Remove all flag on Final column in G&S manual task page */
    private boolean removeAllOption = false;

    /** Copy all flag on WIPO column in G&S manual task page for previous owner in partial ownership manual task */
    private boolean copyAllOptionForWIPOForPreviousOwner;

    /** Copy all flag on INTREPID column in G&S manual task page for previous owner in partial ownership manual task */
    private boolean copyAllOptionForINTREPIDForPreviousOwner;

    /** Remove all flag on final column in G&S manual task page for previous owner in partial ownership manual task */
    private boolean removeAllOptionForPreviousOwner = false;

    /** Hide the trademarks that support the IR table on NANR Partial Ceasing of effect table */
    private boolean hideMarksSupportingIR = true;

    public static final int COPY_FROM_WIPO = 1;

    public static final int COPY_FROM_INTREPID = 2;

    public static final int ASSOCIATE_TO_WIPO = 3;

    /** Type of the transaction being processed */
    private String formType;

    public TrademarkApplicationType getApplication() {
        return application;
    }

    public void setApplication(TrademarkApplicationType application) {
        this.application = application;
    }

    public String getInternationalRegistrationNumber() {
        return internationalRegistrationNumber;
    }

    public void setInternationalRegistrationNumber(String internationalRegistrationNumber) {
        this.internationalRegistrationNumber = internationalRegistrationNumber;
    }

    public String getInternationalRegistrationNumberForPreviousOwner() {
        return internationalRegistrationNumberForPreviousOwner;
    }

    public void setInternationalRegistrationNumberForPreviousOwner(String internationalRegistrationNumber) {
        this.internationalRegistrationNumberForPreviousOwner = internationalRegistrationNumber;
    }

    public List<String> getWipoComments() {
        return wipoComments;
    }

    public boolean isWipoCommentEmpty() {
        boolean isEmpty = true;

        if (CollectionUtils.isEmpty(wipoComments)) {
            isEmpty = true;
        } else {
            for (String wipoComment : wipoComments) {
                // if anyone of the comment is not empty, then return false.
                if (StringUtils.isNotBlank(wipoComment)) {
                    isEmpty = false;
                    break;
                }
            }
        }
        return isEmpty;
    }

    public List<GoodsServicesClaimsType> getIntrepidGsTypes() {
        return intrepidGsTypes;
    }

    public void setIntrepidGsTypes(List<GoodsServicesClaimsType> intrepidGsTypes) {
        this.intrepidGsTypes = intrepidGsTypes;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Long getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(Long applicationType) {
        this.applicationType = applicationType;
    }

    public Long getServiceItemType() {
        return serviceItemType;
    }

    public void setServiceItemType(Long serviceItemType) {
        this.serviceItemType = serviceItemType;
    }

    public MadridProtectionRestrictionCategoryType getRestCategoryType() {
        return restCategoryType;
    }

    public void setRestCategoryType(MadridProtectionRestrictionCategoryType restCategoryType) {
        this.restCategoryType = restCategoryType;
    }

    public BigDecimal getTaskId() {
        return taskId;
    }

    public void setTaskId(BigDecimal taskId) {
        this.taskId = taskId;
    }

    public BigDecimal getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(BigDecimal transactionId) {
        this.transactionId = transactionId;
    }

    public ISOLanguageCodeType getLangCode() {
        return langCode;
    }

    public void setLangCode(ISOLanguageCodeType langCode) {
        this.langCode = langCode;
    }

    public MF3A getMf3a() {
        return mf3a;
    }

    public void setMf3a(MF3A mf3a) {
        this.mf3a = mf3a;
    }

    public List<GroundsOfOpposition> getGroundsOfOppositionList() {
        return groundsOfOppositionList;
    }

    public void setGroundsOfOppositionList(List<GroundsOfOpposition> groundsOfOppositionList) {
        this.groundsOfOppositionList = groundsOfOppositionList;
    }

    public MF9 getMf9() {
        return mf9;
    }

    public void setMf9(MF9 mf9) {
        this.mf9 = mf9;
    }

    public MF13 getMf13() {
        return mf13;
    }

    public void setMf13(MF13 mf13) {
        this.mf13 = mf13;
    }

    public IrregularityDetail getIrregularityDetail() {
        if (irregularityDetail == null) {
            irregularityDetail = new IrregularityDetail();
        }
        return irregularityDetail;
    }

    public void setIrregularityDetail(IrregularityDetail irregularityDetail) {
        this.irregularityDetail = irregularityDetail;
    }

    public MadridCorrectionType getCorrectionType() {
        return correctionType;
    }

    public void setCorrectionType(MadridCorrectionType correctionType) {
        this.correctionType = correctionType;
    }

    public String getCorrectionRecordIdentifier() {
        return correctionRecordIdentifier;
    }

    public void setCorrectionRecordIdentifier(String correctionRecordIdentifier) {
        this.correctionRecordIdentifier = correctionRecordIdentifier;
    }

    public String getCorrectionIRNumber() {
        return correctionIRNumber;
    }

    public void setCorrectionIRNumber(String correctionIRNumber) {
        this.correctionIRNumber = correctionIRNumber;
    }

    public String getCorrectionOrigTrans() {
        return correctionOrigTrans;
    }

    public void setCorrectionOrigTrans(String correctionOrigTrans) {
        this.correctionOrigTrans = correctionOrigTrans;
    }

    public String getCorrectionCorrTrans() {
        return correctionCorrTrans;
    }

    public void setCorrectionCorrTrans(String correctionCorrTrans) {
        this.correctionCorrTrans = correctionCorrTrans;
    }

    public Boolean getCorrectionContent() {
        return correctionContent;
    }

    public void setCorrectionContent(Boolean correctionContent) {
        this.correctionContent = correctionContent;
    }

    public List<ReturnObjForGoodsAndServices> getGoodsAndServices() {
        return gsList;
    }

    public List<ReturnObjForGoodsAndServices> getGoodsAndServicesForPreviousOwner() {
        return prevgsList;
    }

    public List<ReturnObjForGoodsAndServicesForNANR> getGoodsAndServicesNANR() {
        return gsListNANR;
    }

    public void setTransactionDetail(TransactionDetail transaction) {
        transactionDetail = transaction;
    }

    public TransactionDetail getTransactionDetail() {
        return transactionDetail;
    }

    public TransactionDetail getOrigTransactionDetail() {
        return origTransactionDetail;
    }

    public void setOrigTransactionDetail(TransactionDetail origTransactionDetail) {
        this.origTransactionDetail = origTransactionDetail;
    }

    public List<IrregularityType> getIrregularityTypes() {
        return irregularityTypes;
    }

    public void setIrregularityTypes(List<IrregularityType> irregularityTypes) {
        this.irregularityTypes = irregularityTypes;
    }

    public int getFileNumberLocked() {
        return fileNumberLocked;
    }

    public void setFileNumberLocked(int fileNumberLocked) {
        this.fileNumberLocked = fileNumberLocked;
    }

    public int getFileExtensionLocked() {
        return fileExtensionLocked;
    }

    public void setFileExtensionLocked(int fileExtensionLocked) {
        this.fileExtensionLocked = fileExtensionLocked;
    }

    public String getMailingLabel() {
        return mailingLabel;
    }

    public void setMailingLabel(String mailingLabel) {
        this.mailingLabel = mailingLabel;
    }

    public String getActivityTaskId() {
        return activityTaskId;
    }

    public void setActivityTaskId(String activityTaskId) {
        this.activityTaskId = activityTaskId;
    }

    public boolean isCopyAllOptionForWIPO() {
        return copyAllOptionForWIPO;
    }

    public void setCopyAllOptionForWIPO(boolean copyAllOption) {
        this.copyAllOptionForWIPO = copyAllOption;
    }

    public boolean isRemoveAllOption() {
        return removeAllOption;
    }

    public void setRemoveAllOption(boolean removeAllOption) {
        this.removeAllOption = removeAllOption;
    }

    public boolean isCopyAllOptionForINTREPID() {
        return copyAllOptionForINTREPID;
    }

    public void setCopyAllOptionForINTREPID(boolean copyAllOptionForINTREPID) {
        this.copyAllOptionForINTREPID = copyAllOptionForINTREPID;
    }

    public boolean isCopyAllOptionForWIPOForPreviousOwner() {
        return copyAllOptionForWIPOForPreviousOwner;
    }

    public void setCopyAllOptionForWIPOForPreviousOwner(boolean copyAllOptionForWIPOForPreviousOwner) {
        this.copyAllOptionForWIPOForPreviousOwner = copyAllOptionForWIPOForPreviousOwner;
    }

    public boolean isCopyAllOptionForINTREPIDForPreviousOwner() {
        return copyAllOptionForINTREPIDForPreviousOwner;
    }

    public void setCopyAllOptionForINTREPIDForPreviousOwner(boolean copyAllOptionForINTREPIDForPreviousOwner) {
        this.copyAllOptionForINTREPIDForPreviousOwner = copyAllOptionForINTREPIDForPreviousOwner;
    }

    public boolean isRemoveAllOptionForPreviousOwner() {
        return removeAllOptionForPreviousOwner;
    }

    public void setRemoveAllOptionForPreviousOwner(boolean removeAllOptionForPreviousOwner) {
        this.removeAllOptionForPreviousOwner = removeAllOptionForPreviousOwner;
    }

    public List<String> getWipoCommentsForPreviousOwner() {
        return wipoCommentsForPreviousOwner;
    }

    public boolean isHideMarksSupportingIR() {
        return hideMarksSupportingIR;
    }

    public void setHideMarksSupportingIR(boolean hideMarksSupportingIR) {
        this.hideMarksSupportingIR = hideMarksSupportingIR;
    }

    /**
     * Check if there are any Goods and Services in Final. For now we can check if the Remove All Option is enabled.
     *
     * @return true, if successful
     */
    public boolean gsInFinal() {
        return removeAllOption;
    }

    /**
     * Check if there are any Goods and Services in Final for Previous Owner. For now we can check if the Remove All
     * Option is enabled.
     *
     * @return true, if successful
     */
    public boolean gsInFinalForPreviousOwner() {
        return removeAllOptionForPreviousOwner;
    }

    /**
     * Update goods and services so that WIPO and INTREPID statements are mapped for the same Nice Class. In case of
     * claims from INTREPID, all INTREPID statements for that class will be associated to the WIPO statement of the same
     * class. If WIPO has multiple statements for the same class, then all INTREPID statements for that class will be
     * replicated and associated to each of the WIPO statements for that class. The copyAll flags will be set based on
     * the data we get from WIPO and INTREPID.
     *
     * @param gsTypes the G&S types from WIPO for new owner in case of partial ownership
     * @param gsLimitTypes the G&S limit types from WIPO
     * @param gsRemoveTypes the G&S remove types from WIPO
     * @param previousOwner flag to indicate if the G&S are for the previous owner in case of partial ownership
     */
    public void updateGoodsAndServices(List<ClassDescriptionType> gsTypes, List<ClassDescriptionType> gsLimitTypes,
                                       List<ClassDescriptionType> gsRemoveTypes, boolean previousOwner) {

        Integer classno;

        SortedMap<Integer, List<ReturnObjForGoodsAndServices>> goods = new TreeMap<Integer, List<ReturnObjForGoodsAndServices>>();
        SortedMap<Integer, List<ReturnObjForGoodsAndServices>> services = new TreeMap<Integer, List<ReturnObjForGoodsAndServices>>();

        List<ReturnObjForGoodsAndServices> gsList = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();

        // Goods are from nice classes 1-34, Services 35-45
        for (ClassDescriptionType wipoClass : gsTypes) {

            classno = Integer.parseInt(wipoClass.getClassNumber());
            if (classno < 35) {
                ReturnObjForGoodsAndServices good = new ReturnObjForGoodsAndServices(classno, wipoClass, null);

                if (goods.get(classno) == null) {
                    goods.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                }
                goods.get(classno).add(good);
            } else {
                ReturnObjForGoodsAndServices service = new ReturnObjForGoodsAndServices(classno, wipoClass, null);
                if (services.get(classno) == null) {
                    services.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                }
                services.get(classno).add(service);
            }
        }

        for (ClassDescriptionType wipoClass : gsLimitTypes) {

            classno = Integer.parseInt(wipoClass.getClassNumber());
            if (classno < 35) {
                ReturnObjForGoodsAndServices good = new ReturnObjForGoodsAndServices(classno, wipoClass, null);
                good.setWipoCategory(GoodsServicesLimitationCategoryType.LIST_LIMITED_TO.value());

                if (goods.get(classno) == null) {
                    goods.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                }
                goods.get(classno).add(good);
            } else {
                ReturnObjForGoodsAndServices service = new ReturnObjForGoodsAndServices(classno, wipoClass, null);
                service.setWipoCategory(GoodsServicesLimitationCategoryType.LIST_LIMITED_TO.value());
                if (services.get(classno) == null) {
                    services.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                }
                services.get(classno).add(service);
            }
        }

        for (ClassDescriptionType wipoClass : gsRemoveTypes) {

            classno = Integer.parseInt(wipoClass.getClassNumber());
            if (classno < 35) {
                ReturnObjForGoodsAndServices good = new ReturnObjForGoodsAndServices(classno, wipoClass, null);
                good.setWipoCategory(GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST.value());
                if (goods.get(classno) == null) {
                    goods.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                }
                goods.get(classno).add(good);
            } else {
                ReturnObjForGoodsAndServices service = new ReturnObjForGoodsAndServices(classno, wipoClass, null);
                service.setWipoCategory(GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST.value());
                if (services.get(classno) == null) {
                    services.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                }
                services.get(classno).add(service);
            }
        }

        // Now parse the goods and services from INTREPID
        for (GoodsServicesClaimsType intrepidClass : getIntrepidGsTypes()) {

            if (intrepidClass.getClassification() != null
                && intrepidClass.getClassification().getClassNumber() != null) {
                classno = Integer.parseInt(intrepidClass.getClassification().getClassNumber());
                List<ReturnObjForGoodsAndServices> retObjs = null;

                if (classno < 35) {
                    // there is a WIPO entry for this class
                    if (goods.containsKey(classno)) {
                        //
                        retObjs = goods.get(classno);

                        for (ReturnObjForGoodsAndServices retObj : retObjs) {
                            if (retObj.getIntrepidGSType() == null) {
                                retObj.setIntrepidGSType(new ArrayList<GoodsServicesClaimsType>());
                            }
                            retObj.getIntrepidGSType().add(intrepidClass);
                        }
                        goods.put(classno, retObjs);

                    } else {
                        // no WIPO entry, just add INTREPID G&S
                        List<GoodsServicesClaimsType> intrepidGSTypes = new ArrayList<GoodsServicesClaimsType>();
                        intrepidGSTypes.add(intrepidClass);
                        ReturnObjForGoodsAndServices good = new ReturnObjForGoodsAndServices(classno, null,
                            intrepidGSTypes);

                        if (goods.get(classno) == null) {
                            goods.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                        }
                        goods.get(classno).add(good);
                    }

                } else {
                    // there is a WIPO entry for this class
                    if (services.containsKey(classno)) {

                        retObjs = services.get(classno);

                        for (ReturnObjForGoodsAndServices retObj : retObjs) {
                            if (retObj.getIntrepidGSType() == null) {
                                retObj.setIntrepidGSType(new ArrayList<GoodsServicesClaimsType>());
                            }
                            retObj.getIntrepidGSType().add(intrepidClass);
                        }
                        services.put(classno, retObjs);
                    } else {
                        // no WIPO entry, just add INTREPID G&S
                        List<GoodsServicesClaimsType> intrepidGSTypes = new ArrayList<GoodsServicesClaimsType>();
                        intrepidGSTypes.add(intrepidClass);
                        ReturnObjForGoodsAndServices service = new ReturnObjForGoodsAndServices(classno, null,
                            intrepidGSTypes);

                        if (services.get(classno) == null) {
                            services.put(classno, new ArrayList<ReturnObjForGoodsAndServices>());
                        }
                        services.get(classno).add(service);
                    }
                }
            }
        }

        // copy all option will be disabled if we have multiple statements from WIPO or INTREPID for the same class.
        // It will also be disabled if we don't have any data from WIPO or INTREPID.
        boolean copyAllForWIPO = gsLimitTypes.size() > 0 || gsRemoveTypes.size() > 0 || gsTypes.size() > 0;
        boolean multipleWIPOStatements = false;

        for (Integer key : goods.keySet()) {

            // if already set to false, no need to check further
            if (!copyAllForWIPO) {
                break;
            }
            // if we have multiple WIPO statements for the same class
            if (goods.get(key).size() > 1) {
                multipleWIPOStatements = true;
            }
        }
        for (Integer key : services.keySet()) {

            // if already set to false, no need to check further
            if (!copyAllForWIPO) {
                break;
            }
            // if we have multiple WIPO statements for the same class
            if (services.get(key).size() > 1) {
                multipleWIPOStatements = true;
            }
        }
        copyAllForWIPO = !multipleWIPOStatements && copyAllForWIPO;

        boolean copyAllForINTREPID = getIntrepidGsTypes().size() > 0 && !multipleWIPOStatements;
        boolean multipleINTREPIDStatements = false;

        for (Integer key : goods.keySet()) {

            // if already set to false, no need to check further
            if (!copyAllForINTREPID) {
                break;
            }
            // if we don't have multiple WIPO statements for the same class
            if (goods.get(key).size() == 1) {
                // check if we have multiple INTREPID statements for the same class
                if (goods.get(key).get(0).getIntrepidGSType() != null
                    && goods.get(key).get(0).getIntrepidGSType().size() > 1) {
                    multipleINTREPIDStatements = true;
                }
            }
        }
        for (Integer key : services.keySet()) {

            // if already set to false, no need to check further
            if (!copyAllForINTREPID) {
                break;
            }
            // if we don't have multiple WIPO statements for the same class
            if (services.get(key).size() == 1) {
                // check if we have multiple INTREPID statements for the same class
                if (services.get(key).get(0).getIntrepidGSType() != null
                    && services.get(key).get(0).getIntrepidGSType().size() > 1) {
                    multipleINTREPIDStatements = true;
                }
            }
        }

        copyAllForINTREPID = !multipleINTREPIDStatements && copyAllForINTREPID;

        // Now make sure if multipleINTREPIDStatements is true then copyToWIPO should also be false
        // We don't want both to be displayed if there are multiple statements for the same class in INTREPID
        if (multipleINTREPIDStatements) {
            copyAllForWIPO = false;
        }
        if (previousOwner) {
            copyAllOptionForWIPOForPreviousOwner = copyAllForWIPO;
            copyAllOptionForINTREPIDForPreviousOwner = copyAllForINTREPID;
        } else {
            copyAllOptionForWIPO = copyAllForWIPO;
            copyAllOptionForINTREPID = copyAllForINTREPID;
        }
        for (Integer key : goods.keySet()) {
            gsList.addAll(goods.get(key));
        }
        for (Integer key : services.keySet()) {
            gsList.addAll(services.get(key));
        }
    }

    /**
     * Update goods and services so that WIPO and INTREPID statements are mapped for the same Nice Class. If WIPO has
     * multiple statements for the same class, then all INTREPID statements for that class will be replicated and
     * associated to each of the WIPO statements for that class. The copyAll flags will be set based on the data we get
     * from WIPO.
     *
     * @param gsTypes the G&S types from WIPO for new owner in case of partial ownership
     */
    public void updateGoodsAndServicesForNANR(List<ClassDescriptionType> gsTypes) {

        Integer classno;

        SortedMap<Integer, List<ReturnObjForGoodsAndServicesForNANR>> goods = new TreeMap<Integer, List<ReturnObjForGoodsAndServicesForNANR>>();
        SortedMap<Integer, List<ReturnObjForGoodsAndServicesForNANR>> services = new TreeMap<Integer, List<ReturnObjForGoodsAndServicesForNANR>>();

        // Goods are from nice classes 1-34, Services 35-45
        for (ClassDescriptionType wipoClass : gsTypes) {

            classno = Integer.parseInt(wipoClass.getClassNumber());
            if (classno < 35) {
                ReturnObjForGoodsAndServicesForNANR good = new ReturnObjForGoodsAndServicesForNANR(classno, wipoClass,
                    null);

                if (goods.get(classno) == null) {
                    goods.put(classno, new ArrayList<ReturnObjForGoodsAndServicesForNANR>());
                }
                goods.get(classno).add(good);
            } else {
                ReturnObjForGoodsAndServicesForNANR service = new ReturnObjForGoodsAndServicesForNANR(classno,
                    wipoClass, null);
                if (services.get(classno) == null) {
                    services.put(classno, new ArrayList<ReturnObjForGoodsAndServicesForNANR>());
                }
                services.get(classno).add(service);
            }
        }

        // Now parse the goods and services from INTREPID
        for (Integer intrepidClass : intrepidGsTypesForBasicMarks.keySet()) {

            List<ReturnObjForGoodsAndServicesForNANR> retObjs = null;

            if (intrepidClass < 35) {
                // there is a WIPO entry for this class
                if (goods.containsKey(intrepidClass)) {
                    //
                    retObjs = goods.get(intrepidClass);

                    for (ReturnObjForGoodsAndServicesForNANR retObj : retObjs) {
                        if (retObj.getIntrepidGSType() == null) {
                            retObj.setIntrepidGSType(new ArrayList<BasicMarksByNiceClass>());
                        }
                        retObj.getIntrepidGSType().addAll(intrepidGsTypesForBasicMarks.get(intrepidClass));
                    }
                    goods.put(intrepidClass, retObjs);

                } else {
                    // no WIPO entry, just add INTREPID G&S
                    List<BasicMarksByNiceClass> intrepidGSTypes = new ArrayList<BasicMarksByNiceClass>();
                    intrepidGSTypes.addAll(intrepidGsTypesForBasicMarks.get(intrepidClass));

                    ReturnObjForGoodsAndServicesForNANR good = new ReturnObjForGoodsAndServicesForNANR(intrepidClass,
                        null, intrepidGSTypes);

                    if (goods.get(intrepidClass) == null) {
                        goods.put(intrepidClass, new ArrayList<ReturnObjForGoodsAndServicesForNANR>());
                    }
                    goods.get(intrepidClass).add(good);
                }

            } else {
                // there is a WIPO entry for this class
                if (services.containsKey(intrepidClass)) {

                    retObjs = services.get(intrepidClass);

                    for (ReturnObjForGoodsAndServicesForNANR retObj : retObjs) {
                        if (retObj.getIntrepidGSType() == null) {
                            retObj.setIntrepidGSType(new ArrayList<BasicMarksByNiceClass>());
                        }
                        retObj.getIntrepidGSType().addAll(intrepidGsTypesForBasicMarks.get(intrepidClass));
                    }
                    services.put(intrepidClass, retObjs);
                } else {
                    // no WIPO entry, just add INTREPID G&S
                    List<BasicMarksByNiceClass> intrepidGSTypes = new ArrayList<BasicMarksByNiceClass>();
                    intrepidGSTypes.addAll(intrepidGsTypesForBasicMarks.get(intrepidClass));

                    ReturnObjForGoodsAndServicesForNANR service = new ReturnObjForGoodsAndServicesForNANR(intrepidClass,
                        null, intrepidGSTypes);

                    if (services.get(intrepidClass) == null) {
                        services.put(intrepidClass, new ArrayList<ReturnObjForGoodsAndServicesForNANR>());
                    }
                    services.get(intrepidClass).add(service);
                }
            }
        }

        // copy all option will be disabled if we have multiple statements from WIPO for the same class.
        // It will also be disabled if we don't have any data from WIPO.
        boolean copyAllForWIPO = gsTypes.size() > 0;

        for (Integer key : goods.keySet()) {

            // if already set to false, no need to check further
            if (!copyAllForWIPO) {
                break;
            }
            // if we have multiple WIPO statements for the same class
            if (goods.get(key).size() > 1) {
                copyAllForWIPO = false;
            }
        }
        for (Integer key : services.keySet()) {

            // if already set to false, no need to check further
            if (!copyAllForWIPO) {
                break;
            }
            // if we have multiple WIPO statements for the same class
            if (services.get(key).size() > 1) {
                copyAllForWIPO = false;
            }
        }

        copyAllOptionForWIPO = copyAllForWIPO;

        for (Integer key : goods.keySet()) {
            gsListNANR.addAll(goods.get(key));
        }
        for (Integer key : services.keySet()) {
            gsListNANR.addAll(services.get(key));
        }
    }

    /**
     * Clears the cache.
     */
    public void clearCache() {

        gsList.clear();
        gsListNANR.clear();
        prevgsList.clear();

        wipoComments.clear();
        wipoCommentsForPreviousOwner.clear();

        intrepidGsTypes.clear();
        intrepidGsTypesForBasicMarks.clear();
        irregularityTypes.clear();

        basicMarksWithGS.clear();

        activityTaskId = null;
        application = null;
        applicationType = null;
        internationalRegistrationNumber = null;
        internationalRegistrationNumberForPreviousOwner = null;
        transactionDetail = null;
        transactionId = null;
        taskId = null;
        restCategoryType = null;
        irregularityDetail = null;
        removeAllOption = false;
        removeAllOptionForPreviousOwner = false;
        hideMarksSupportingIR = true;
    }

    /**
     * Update remove all option for the final column on the manual tasks page.
     */
    public void updateRemoveAllOption() {

        List<ReturnObjForGoodsAndServices> gsList = getGoodsAndServices();

        setRemoveAllOption(false);

        for (ReturnObjForGoodsAndServices gsObj : gsList) {
            if (gsObj.isFinalGSTypeSet()) {
                setRemoveAllOption(true);
                break;
            }
        }
    }

    /**
     * Update remove all option for previous owner for partial ownership on the manual tasks page.
     */
    public void updateRemoveAllOptionForPreviousOwner() {

        List<ReturnObjForGoodsAndServices> gsList = getGoodsAndServicesForPreviousOwner();

        setRemoveAllOptionForPreviousOwner(false);

        for (ReturnObjForGoodsAndServices gsObj : gsList) {
            if (gsObj.isFinalGSTypeSet()) {
                setRemoveAllOptionForPreviousOwner(true);
                break;
            }
        }
    }

    /**
     * Update remove all option for the final column on the manual tasks page.
     */
    public void updateRemoveAllOptionForNANR() {

        List<ReturnObjForGoodsAndServicesForNANR> gsList = getGoodsAndServicesNANR();

        setRemoveAllOption(false);

        for (ReturnObjForGoodsAndServicesForNANR gsObj : gsList) {
            if (gsObj.getFinalGSType() != null) {
                setRemoveAllOption(true);
                break;
            }
        }
    }

    /**
     * Associate an INTREPID statement to a WIPO statement.
     *
     * @param niceClass the nice class for which the statements are being associated
     * @param rowIndex the row index the of the row on the G&S manual task table
     * @param intrepidIndex the index of the INTREPID statement in case of multiple statements associated to a WIPO
     *            statement
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public void associateInterpidToWipo(Integer niceClass, Integer rowIndex, Integer intrepidIndex,
                                        boolean previousOwner, int action) {

        List<ReturnObjForGoodsAndServices> retObjs = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();

        int index = 0;
        for (ReturnObjForGoodsAndServices retGS : retObjs) {
            if (index == rowIndex) {
                // reset the final GS if there is already an associate INTREPID index
                if (retGS.getFinalGSType() != null && retGS.getAssociatedIntrepidIndex() != -1) {
                    if (action != COPY_FROM_INTREPID) {
                        retGS.getFinalGSType().set(retGS.getAssociatedIntrepidIndex(), null);
                    }
                }
                if (intrepidIndex == retGS.getAssociatedIntrepidIndex()) {
                    retGS.setAssociatedIntrepidIndex(-1); // the user wants to toggle the association or we are copying
                                                          // from INTREPID
                } else {
                    if (action != COPY_FROM_INTREPID) {
                        retGS.setAssociatedIntrepidIndex(intrepidIndex);
                    }
                }
            } else {
                // reset the association if the same INTREPID index is set for all other rows for the same nice class
                if ((retGS.getNiceClass() == niceClass)) {
                    if (retGS.getAssociatedIntrepidIndex() == intrepidIndex) {
                        retGS.setAssociatedIntrepidIndex(-1);
                    }
                    if (retGS.getFinalGSType() != null) {
                        retGS.getFinalGSType().set(intrepidIndex, null);
                    }
                }
            }
            index++;
        }

        if (previousOwner) {
            updateRemoveAllOptionForPreviousOwner();
        } else {
            updateRemoveAllOption();
        }
    }

    /**
     * Return the list of rows that have associate to WIPO set.
     *
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public String getAssociateInterpidToWipoList(boolean previousOwner) {

        List<ReturnObjForGoodsAndServices> retObjs = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();

        int index = 0;
        String result = "";
        for (ReturnObjForGoodsAndServices retGS : retObjs) {

            if (retGS.getAssociatedIntrepidIndex() > -1) {
                if (!result.isEmpty()) {
                    result += ";";
                }
                result += retGS.getNiceClass() + "_" + index + "_" + retGS.getAssociatedIntrepidIndex();
            }
            index++;
        }
        return result;
    }

    /**
     * Copy the INTREPID statement to final for the NICE class at intrepidIndex in row with rowIndex.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     * @param intrepidIndex the index of the INTREPID statement in case of multiple statements associated to a WIPO
     *            statement
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public String copyIntrepidStatementToFinal(int rowIndex, int intrepidIndex, boolean previousOwner) {

        List<ReturnObjForGoodsAndServices> goodsAndServices = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();
        ReturnObjForGoodsAndServices selectedGS = goodsAndServices.get(rowIndex);
        String finalStmtStr = "";

        associateInterpidToWipo(selectedGS.getNiceClass(), rowIndex, intrepidIndex, previousOwner, COPY_FROM_INTREPID);
        // selectedGS.setAssociatedIntrepidIndex(-1);

        if (goodsAndServices.get(rowIndex).getIntrepidGSType() != null) {
            GoodsServicesClaimsType gsctSelected = goodsAndServices.get(rowIndex).getIntrepidGSType()
                .get(intrepidIndex);

            // update the final G&S
            selectedGS.addFinalGSType(intrepidIndex, (GoodsServicesClaimsType) SerializationUtils.clone(gsctSelected));

            FinalGoodsServicesWrapper finalWrapper = new FinalGoodsServicesWrapper();
            finalWrapper.setClassNum(Integer.parseInt(gsctSelected.getClassification().getClassNumber()));
            finalWrapper.setEdited(false);
            finalWrapper.setFromWipo(false);
            finalWrapper.setGoodsServicesLimitationCategoryType(null);

            boolean existed = false;
            for (FinalGoodsServicesWrapper existingWrapper : selectedGS.getFinalGSWrapper()) {
                if (existingWrapper.getClassNum() == finalWrapper.getClassNum()) {
                    existingWrapper.setEdited(finalWrapper.isEdited());
                    existingWrapper.setFromWipo(finalWrapper.isFromWipo());

                    existed = true;
                }
            }

            if (!existed) {
                selectedGS.getFinalGSWrapper().add(finalWrapper);
            }

            if (previousOwner) {
                setRemoveAllOptionForPreviousOwner(true);
            } else {
                setRemoveAllOption(true);
            }

            finalStmtStr = gsctSelected.getStatement().getStatementDescription().getValue();
        } else {
            selectedGS.addFinalGSType(intrepidIndex, null);
        }
        return finalStmtStr;
    }

    /**
     * Copy all statements from INTREPID to final.
     *
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public void copyAllToFinalFromIntrepid(boolean previousOwner) {

        // first remove all from final
        // removeAllFromFinal(previousOwner);

        List<ReturnObjForGoodsAndServices> goodsAndServices = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();

        // The INTREPID index will always be 0 as we should only one INTREPID statement if copy all option is enabled
        for (int index = 0; index < goodsAndServices.size(); index++) {
            copyIntrepidStatementToFinal(index, 0, previousOwner);
        }
    }

    /**
     * Copy all statements from WIPO to final.
     *
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public void copyAllToFinalFromWipo(boolean previousOwner) {

        // first remove all from final
        // removeAllFromFinal(previousOwner);

        List<ReturnObjForGoodsAndServices> goodsAndServices = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();

        for (int index = 0; index < goodsAndServices.size(); index++) {
            copyWIPOStatementToFinal(index, 0, previousOwner);
        }
    }

    /**
     * Copy all statements from WIPO to final for NANR Partial Ceasing of Effect.
     */
    public void copyAllToFinalFromWipoForNANR() {

        // first remove all from final
        removeAllFromFinalForNANR();

        List<ReturnObjForGoodsAndServicesForNANR> goodsAndServices = getGoodsAndServicesNANR();

        for (int index = 0; index < goodsAndServices.size(); index++) {
            copyWIPOStatementToFinalForNANR(index);
        }
    }

    /**
     * Removes all statements from final.
     *
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public void removeAllFromFinal(boolean previousOwner) {

        List<ReturnObjForGoodsAndServices> goodsAndServices = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();
        for (ReturnObjForGoodsAndServices gsObj : goodsAndServices) {
            gsObj.setFinalGSType(null);
            gsObj.setAssociatedIntrepidIndex(-1);
        }
        if (previousOwner) {
            setRemoveAllOptionForPreviousOwner(false);
        } else {
            setRemoveAllOption(false);
        }
    }

    /**
     * Removes all statements from final for NANR Partial Ceasing of Effect.
     */
    public void removeAllFromFinalForNANR() {

        List<ReturnObjForGoodsAndServicesForNANR> goodsAndServices = getGoodsAndServicesNANR();

        for (ReturnObjForGoodsAndServicesForNANR gsObj : goodsAndServices) {
            gsObj.setFinalGSType(null);
        }
        setRemoveAllOption(false);
    }

    /**
     * Edits the final statement for the NICE class at rowIndex with the updated text.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     * @param updatedText the updated text to replace in the final statement
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public String editFinal(int rowIndex, int intrepidIndex, String updatedText, boolean previousOwner) {

        GoodsServicesClaimsType finalGsType = null;

        if (previousOwner) {
            finalGsType = getGoodsAndServicesForPreviousOwner().get(rowIndex).getFinalGSType().get(intrepidIndex);
            getGoodsAndServicesForPreviousOwner().get(rowIndex).getFinalGSWrapper().get(intrepidIndex).setEdited(true);
        } else {
            finalGsType = getGoodsAndServices().get(rowIndex).getFinalGSType().get(intrepidIndex);
            getGoodsAndServices().get(rowIndex).getFinalGSWrapper().get(intrepidIndex).setEdited(true);
        }

        // update the final G&S
        GoodsServicesStatementType gsstatement = new GoodsServicesStatementType();
        LocalizedTextType localText = new LocalizedTextType();
        localText.setLanguageCode(getLangCode().value());
        localText.setValue(updatedText);
        gsstatement.setStatementDescription(localText);

        finalGsType.setStatement(gsstatement);

        return localText.getValue();
    }

    /**
     * Edits the final statement for the NICE class at rowIndex with the updated text for NANR Partial Ceasing of
     * Effect.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     * @param updatedText the updated text to replace in the final statement
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public String editFinalForNANR(int rowIndex, String updatedText) {

        ClassDescriptionType finalGsType = getGoodsAndServicesNANR().get(rowIndex).getFinalGSType();

        List<OrderedTextType> wipodescList = finalGsType.getGoodsServicesDescriptionText();

        // update the description of the statement for the language code set for the bean
        for (OrderedTextType wipodesc : wipodescList) {
            if (wipodesc.getLanguageCode().toUpperCase().equalsIgnoreCase(getLangCode().value())) {
                wipodesc.setValue(updatedText);
            }
        }
        return updatedText;
    }

    /**
     * Removes the statement for the NICE class at rowIndex from Final.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     * @param intrepidIndex row index to the INTREPID GS associated to the nice class
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public void removeStatementFromFinal(int rowIndex, int intrepidIndex, boolean previousOwner) {

        // clear the final G&S
        List<ReturnObjForGoodsAndServices> goodsAndServices = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();
        ReturnObjForGoodsAndServices selectedGS = goodsAndServices.get(rowIndex);

        selectedGS.getFinalGSType().set(intrepidIndex, null);
        selectedGS.setAssociatedIntrepidIndex(-1);

        if (previousOwner) {
            updateRemoveAllOptionForPreviousOwner();
        } else {
            updateRemoveAllOption();
        }
    }

    /**
     * Removes the WIPO statement for the NICE class at rowIndex from Final for NANR Partial Ceasing of Effect.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     */
    public void removeWipoStatementFromFinalForNANR(int rowIndex) {

        // clear the final G&S
        List<ReturnObjForGoodsAndServicesForNANR> goodsAndServices = getGoodsAndServicesNANR();
        ReturnObjForGoodsAndServicesForNANR selectedGS = goodsAndServices.get(rowIndex);

        selectedGS.setFinalGSType(null);
        updateRemoveAllOptionForNANR();
    }

    /**
     * Copy the WIPO statement to final for the NICE class in row with rowIndex and associated to the INTREPID statement
     * at intrepidIndex.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     * @param intrepidIndex the index of the INTREPID statement in case of multiple statements associated to a WIPO
     *            statement
     * @param previousOwner flag to indicate if this association is for previous owner in partial ownership case
     */
    public String copyWIPOStatementToFinal(int rowIndex, int intrepidIndex, boolean previousOwner) {

        // get the WIPO statement
        List<ReturnObjForGoodsAndServices> goodsAndServices = (previousOwner) ? getGoodsAndServicesForPreviousOwner()
            : getGoodsAndServices();

        ReturnObjForGoodsAndServices selectedGS = goodsAndServices.get(rowIndex);

        ClassDescriptionType wipoGsType = selectedGS.getWipoGSType();
        String finalStmtStr = "";

        if (wipoGsType != null) {

            // get the associated INTREPID statement
            List<GoodsServicesClaimsType> gsIntrepidTypes = goodsAndServices.get(rowIndex).getIntrepidGSType();

            if (gsIntrepidTypes != null) {
                GoodsServicesClaimsType gsctSelected = gsIntrepidTypes.get(intrepidIndex);

                // no need to call associate as that would have to done first. UI ensures that an
                // association has been done first.
                // associateInterpidToWipo(selectedGS.getNiceClass(), rowIndex, intrepidIndex, previousOwner,
                // COPY_FROM_WIPO);

                // this needs to be done again after associateInterpidToWipo() as it may have been reset
                // selectedGS.setAssociatedIntrepidIndex(intrepidIndex);

                // clone and update the final G&S
                selectedGS.addFinalGSType(intrepidIndex,
                    (GoodsServicesClaimsType) SerializationUtils.clone(gsctSelected));

                GoodsServicesStatementType finalGS = selectedGS.getFinalGSType().get(intrepidIndex).getStatement();

                LocalizedTextType localType = new LocalizedTextType();

                List<OrderedTextType> wipodescList = wipoGsType.getGoodsServicesDescriptionText();

                for (OrderedTextType wipodesc : wipodescList) {
                    if (wipodesc.getLanguageCode().toUpperCase().equalsIgnoreCase(getLangCode().value())) {
                        finalStmtStr = wipodesc.getValue();

                    }

                }
                localType.setValue(finalStmtStr);
                localType.setLanguageCode(getLangCode().value());
                finalGS.setStatementDescription(localType);

            } else {
                GoodsServicesClaimsType gsType = new GoodsServicesClaimsType();

                // convert the WIPO G&S to GoodsServicesClaimsType
                resetGsType(gsType, wipoGsType);

                // update the final G&S
                selectedGS.addFinalGSType(intrepidIndex, gsType);
                finalStmtStr = gsType.getStatement().getStatementDescription().getValue();
            }

            GoodsServicesLimitationCategoryType limitationType = StringUtils.isNotBlank(selectedGS.getWipoCategory())
                ? GoodsServicesLimitationCategoryType.fromValue(selectedGS.getWipoCategory())
                : GoodsServicesLimitationCategoryType.LIST_LIMITED_TO;

            if (limitationType != GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                if (previousOwner) {
                    setRemoveAllOptionForPreviousOwner(true);
                } else {
                    setRemoveAllOption(true);
                }
            }

            FinalGoodsServicesWrapper finalWrapper = new FinalGoodsServicesWrapper();
            finalWrapper.setClassNum(Integer.parseInt(wipoGsType.getClassNumber()));
            finalWrapper.setEdited(false);
            finalWrapper.setFromWipo(true);

            finalWrapper.setGoodsServicesLimitationCategoryType(limitationType);

            boolean existed = false;
            for (FinalGoodsServicesWrapper existingWrapper : selectedGS.getFinalGSWrapper()) {
                if (existingWrapper.getClassNum() == finalWrapper.getClassNum()) {
                    existingWrapper.setEdited(finalWrapper.isEdited());
                    existingWrapper.setFromWipo(finalWrapper.isFromWipo());

                    existed = true;
                }
            }

            if (!existed) {
                selectedGS.getFinalGSWrapper().add(finalWrapper);
            }

        } else {
            selectedGS.addFinalGSType(intrepidIndex, null);
            selectedGS.setAssociatedIntrepidIndex(-1);
        }
        return finalStmtStr;
    }

    /**
     * Copy the WIPO statement to final for the NICE class in row with rowIndex.
     *
     * @param rowIndex the row index the of the row on the G&S manual task table
     */
    public void copyWIPOStatementToFinalForNANR(int rowIndex) {

        List<ReturnObjForGoodsAndServicesForNANR> goodsAndServices = getGoodsAndServicesNANR();

        // get the WIPO statement
        ClassDescriptionType wipoGsType = goodsAndServices.get(rowIndex).getWipoGSType();

        ReturnObjForGoodsAndServicesForNANR selectedGS = goodsAndServices.get(rowIndex);

        if (wipoGsType != null) {
            selectedGS.setFinalGSType((ClassDescriptionType) SerializationUtils.clone(wipoGsType));
            setRemoveAllOption(true);
        }
    }

    /**
     * Reset the G&S from WIPO ClassDescriptionType to GoodsServicesClaimsType.
     *
     * @param gs the G&S to reset to
     * @param ct the G&S from WIPO to convert
     */
    private void resetGsType(GoodsServicesClaimsType gs, ClassDescriptionType ct) {

        GoodsServicesClassificationType clType = new GoodsServicesClassificationType();
        clType.setClassNumber(ct.getClassNumber());
        clType.setClassificationVersion("11");
        GoodsServicesStatementType statementType = new GoodsServicesStatementType();
        LocalizedTextType localType = new LocalizedTextType();

        String value = "";
        List<OrderedTextType> wipodescList = ct.getGoodsServicesDescriptionText();

        for (OrderedTextType wipodesc : wipodescList) {
            if (wipodesc.getLanguageCode().toUpperCase().equalsIgnoreCase(getLangCode().value())) {
                value = wipodesc.getValue();
            }
        }
        localType.setValue(value);
        localType.setLanguageCode(getLangCode().value());
        statementType.setStatementDescription(localType);

        gs.setStatement(statementType);
        gs.setClassification(clType);
    }

    public List<ReturnObjForBasicMarks> getBasicMarksWithGS() {
        return basicMarksWithGS;
    }

    public void setBasicMarksWithGS(List<ReturnObjForBasicMarks> basicMarksWithGS) {
        this.basicMarksWithGS = basicMarksWithGS;
    }

    /**
     * Adds the basic marks retrieved from INTREPID.
     *
     * @param fileNumber the file number
     * @param extCounter the ext counter
     * @param gsTypes the gs types
     */
    public void addBasicMarks(int fileNumber, int extCounter, List<GoodsServicesType> gsTypes, String markStatus,
                              String modifiedDate) {

        basicMarksWithGS.add(new ReturnObjForBasicMarks(fileNumber, extCounter, gsTypes, markStatus, modifiedDate));
    }

    /**
     * Adds the INTREPID G&S types for basic marks based on the Nice Class.
     *
     * @param niceClass the nice class
     * @param fileNumber the file number
     * @param extCounter the ext counter
     * @param gsType the gs type
     */
    public void addIntrepidGsTypesForBasicMarks(int niceClass, int fileNumber, int extCounter, GoodsServicesType gsType,
                                                String markStatus, String modifiedDate) {

        if (intrepidGsTypesForBasicMarks.get(niceClass) == null) {
            intrepidGsTypesForBasicMarks.put(niceClass, new ArrayList<BasicMarksByNiceClass>());
        }
        intrepidGsTypesForBasicMarks.get(niceClass)
            .add(new BasicMarksByNiceClass(fileNumber, extCounter, gsType, markStatus, modifiedDate));
    }

    /**
     * Update the marks that support the IR.
     *
     * @param marksSupportingIR the marks that support the IR
     */
    public void updateMarksForIR(String marksSupportingIR) {

        if (marksSupportingIR != null && !marksSupportingIR.isEmpty()) {
            String[] fileNumAndExts = marksSupportingIR.split(",");
            String fileNum = "";
            String extCount = "0";
            int index;

            for (String fileNumAndExt : fileNumAndExts) {
                index = fileNumAndExt.indexOf("(");
                fileNum = fileNumAndExt;
                extCount = "0";
                if (index != -1) {
                    fileNum = fileNumAndExt.substring(0, index);
                    extCount = fileNumAndExt.substring(index + 1, fileNumAndExt.indexOf(")"));
                }
                for (ReturnObjForBasicMarks basicmark : basicMarksWithGS) {
                    if (basicmark.getFileNumber() == Integer.parseInt(fileNum)
                        && basicmark.getExtensionCounter() == Integer.parseInt(extCount)) {
                        basicmark.setSelected(true);
                        break;
                    }
                }
            }
        }
    }

    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }
}
