package ca.gc.ic.cipo.tm.madridconsole.util;


import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.mail.Session;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Scope;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.stereotype.Component;

import ca.gc.ic.cipo.mail.SimpleMailSender;
import ca.gc.ic.cipo.mail.jndi.JndiSimpleMailSender;

@Scope(value = "singleton")
@Component
public class SendErrorEmail  {

    // Logger.
    private static Logger logger = Logger.getLogger(SendErrorEmail.class.getName());

   // Sender Mail
    @Value("${mc.error.email.sender}")
   private String errorEmailSender;

    // Recipient
   @Value("${mc.error.email.recipients}")
   private String[] errorEmailRecipients;

   // Webshpere Mail Session1
   @Value("${mc.jndi.mail.session}")
   private String jndiMailSession;

   // Environment
   @Value("${mc.mail.env}")
   private String mcEnvironment;

   // Indicator on whether to Send Error Emails (true or false)
   @Value("${mc.send.error.email}")
   private String sendErrorEmail;

    @Autowired
    private SimpleMailSender mailSender;

    public final String MWE = "MWE";
    public final String MFS = "MFS";
    public final String MTS = "MTS";
    public final String MPS = "MPS";
    public final String TIRS = "TIRS";
    public final String MEF = "MEF";
    public final String UAS = "UAS";
    public final String MOPS = "MOPS";
    public final String TUPS = "TUPS";

    public enum serviceName {
        MWE("Madrid Workflow Engine (MWE)"),
        MFS("Madrid Financial Fee Service (MFS)"),
        MTS("Madrid Transaction Service (MTS)"),
        MPS("Madrid Package Service (MPS)"),
        UAS("User Auth Service (UAS)"),
        MEF("Madrid E-Filing Service (MEF)"),
        MOPS("Madrid Online Portal Service (MOPS)"),
        TUPS("Trademark User Profile Service (TUPS)"),
        TIRS("Trademark Information Retrieval Common Service (TIRS)");

        private String serviceNameMsg;

        serviceName(String serviceNameMsg) {
            this.serviceNameMsg = serviceNameMsg;
        }

        public String serviceNameMsg() {
            return serviceNameMsg;
        }
    }

    Map<String, Boolean> serviceMap = new HashMap<>();

    @Bean
    public JndiObjectFactoryBean mailSessionFactoryBean() {
           JndiObjectFactoryBean mailSessionFactoryBean = new JndiObjectFactoryBean();
           mailSessionFactoryBean.setJndiName(jndiMailSession);
           mailSessionFactoryBean.setResourceRef(true);
           return mailSessionFactoryBean;
    }

    @Bean
    @DependsOn("mailSessionFactoryBean")
    public JndiSimpleMailSender mailSender() {

           Session mailSession = (Session) mailSessionFactoryBean().getObject();

           JndiSimpleMailSender mailSender = new JndiSimpleMailSender();
           mailSender.setDefaultEncoding(StandardCharsets.UTF_8.name());
           mailSender.setSession(mailSession);

           return mailSender;
    }

 	/**
	 * Constructor.
	 */
	private SendErrorEmail() {
        serviceMap.put(MWE, true);
        serviceMap.put(MFS, true);
        serviceMap.put(MTS, true);
        serviceMap.put(MPS, true);
        serviceMap.put(MEF, true);
        serviceMap.put(UAS, true);
        serviceMap.put(TIRS, true);
        serviceMap.put(MOPS, true);
        serviceMap.put(TUPS, true);
	}

	@SuppressWarnings("unused")
    public void updateServiceStatus (String strService, Boolean updateValue ) {

	    // Send email indicating that the service is now Up and Running
       boolean sendEmail = Boolean.valueOf(sendErrorEmail);
        if (serviceMap.get(strService).equals(false) && !serviceMap.get(strService).equals(updateValue)) {
	        if (sendEmail) {
                StringBuilder emailBody = new StringBuilder();
                emailBody.append("Madrid Console received notification that the following service is Now Available. ");
                emailBody.append(System.lineSeparator());
                emailBody.append(System.lineSeparator());

                emailBody.append("Date/Time: \t" + new SimpleDateFormat("yyyy/MM/dd HH:mm").format(new Date()));
                emailBody.append(System.lineSeparator());
                emailBody.append(System.lineSeparator());

                emailBody.append("Environment: \t" +  mcEnvironment );
                emailBody.append(System.lineSeparator());
                emailBody.append(System.lineSeparator());

               emailBody.append("Service: \t" +  serviceName.valueOf(strService).serviceNameMsg() );
               emailBody.append(System.lineSeparator());
               emailBody.append(System.lineSeparator());

               logger.debug(emailBody);

                // Send Error Email
                mailSender.send(errorEmailSender, errorEmailRecipients,
                    serviceName.valueOf(strService).serviceNameMsg()  + " is Now Available in " + mcEnvironment + ".", emailBody.toString() );

            }
        }

        // Update the Service Status
	    serviceMap.put(strService, updateValue);
	}

	/*
	 * Method to send Email.
	 */
	public void sendErrorViaEmail(String service, String host, String method, String errorMessage) {
	    boolean sendEmail = Boolean.valueOf(sendErrorEmail);

	    if (sendEmail) {
    	    if (serviceMap.get(service)) {
                StringBuilder emailBody = new StringBuilder();
                emailBody.append("Madrid Console received the following Error. ");
                emailBody.append(System.lineSeparator());
                emailBody.append(System.lineSeparator());

                emailBody.append("Date/Time: \t" + new SimpleDateFormat("yyyy/MM/dd HH:mm").format(new Date()));
                emailBody.append(System.lineSeparator());
                emailBody.append(System.lineSeparator());

                emailBody.append("Environment: \t" +  mcEnvironment );
                emailBody.append(System.lineSeparator());
                emailBody.append(System.lineSeparator());

               emailBody.append("Service: \t" +  serviceName.valueOf(service).serviceNameMsg() );
               emailBody.append(System.lineSeparator());
               emailBody.append(System.lineSeparator());

               emailBody.append("Host: \t\t" +  host );
               emailBody.append(System.lineSeparator());
               emailBody.append(System.lineSeparator());

               emailBody.append("Method: \t" +  method );
               emailBody.append(System.lineSeparator());
               emailBody.append(System.lineSeparator());

               emailBody.append("Exception/Error: \t" +  errorMessage );
               emailBody.append(System.lineSeparator());
               emailBody.append(System.lineSeparator());

               logger.debug(emailBody);

               // Record that the Service, is down, and has been notified.
               updateServiceStatus(service, false);

                // Send Error Email
            	mailSender.send(errorEmailSender, errorEmailRecipients,
            	    serviceName.valueOf(service).serviceNameMsg()  + " Error  - " + mcEnvironment, emailBody.toString() );

    	    }
	    }
    }

}
