package ca.gc.ic.cipo.tm.madridconsole.web.bean;

public final class MadridServiceItemType {

	public static final Long GOODSERVICE_ACCEPT_WIPO = Long.valueOf(241);
	public static final Long GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT = Long.valueOf(242);
	public static final Long GOODSERVICE_RETURN_lIMIT_NO_EFFECT = Long.valueOf(243);

}
