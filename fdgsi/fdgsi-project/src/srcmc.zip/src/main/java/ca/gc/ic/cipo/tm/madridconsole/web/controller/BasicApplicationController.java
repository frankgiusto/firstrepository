package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

/**
 * The Class BasicApplicationController handles the Create Basic Application manual task.
 */
@Controller
@SessionAttributes("wipogs")
public class BasicApplicationController {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(BasicApplicationController.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    /** The message source. */
    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * Gets the bean used to transfer data from View and Controller.
     *
     * @param request the request
     * @return the wipo gs
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    /** The tm app service. */
    @Autowired
    protected TradMarkApplicationService tmAppService;

    /** The mwe client. */
    @Autowired
    protected WorkflowEngineServiceClient mweClient;

    /** The user profile service. */
    @Autowired
    protected UserProfileServiceClient userProfileService;

    /**
     * Inits the binder.
     *
     * @param binder the binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * The default handler (page=0).
     *
     * @param fileNumberStr the file number of the application associated to the selected task being processed.
     * @param transIds the trans ids associated to the selected task being processed.
     * @param taskId the task id associated to the selected task being processed.
     * @param actId the MWE activity task id associated to the selected task being processed.
     * @param type the type of the task being processed.
     * @param gsBean the gs bean used to send and receive data between the view and controller
     * @param modelMap the model map
     * @param request the request
     * @param session the session
     * @return the initial page
     */
    @RequestMapping(value = "/processtask/basicapplication", method = RequestMethod.POST)
    public String displayBasicApplicationPage(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                              @RequestParam(value = "transIds", required = false) List<String> transIds,
                                              @RequestParam(value = "irNum", required = false) String irNum,
                                              @RequestParam(value = "taskId", required = false) String taskId,
                                              @RequestParam(value = "aId", required = false) String actId,
                                              @RequestParam(value = "type", required = false) String type,
                                              @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                              final ModelMap modelMap, HttpServletRequest request,
                                              HttpServletResponse response, HttpSession session) {

        logger.debug(
            "Method: displayBasicApplicationPage: IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", IR# " + irNum + ", type " + type);

        // response.setContentType("application/json");
        // response.setCharacterEncoding("UTF-8");
        // response.setHeader("Cache-Control", "no-store");

        try {
            request.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e2) {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }

        response.setContentType("application/json; charset=utf-8");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Cache-Control", "no-store");

        if (fileNumberStr != null) {
            int fileNumber = Integer.parseInt(fileNumberStr);

            ArrayList<String> actIds = new ArrayList<String>();
            actIds.add(actId);

            try {

                // Acquire lock
                transactionServiceClient.acquireLock(gsBean, fileNumber, 0,
                    userProfileService.getLdapUsername(request));

                // assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (Exception e) {
                        logger.error("Exception: ", e);
                        // e.printStackTrace();
                    }
                }
            } catch (MCServerException e) {

                logger.error("Method: displayBasicApplicationPage: IR: " + gsBean.getInternationalRegistrationNumber()
                    + ", File: " + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", IR# " + irNum
                    + ", type " + type);
                logger.error("Method: displayBasicApplicationPage - Error assigning task to current user "
                    + userProfileService.getParentId(request) + " due to - " + e.getMessage(), e);
                // e.printStackTrace();

                try {
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                    transactionServiceClient.releaseLock(gsBean);
                    return "ptBasicApplication";
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }

            if (gsBean == null) {
                gsBean = new GoodServiceWipoBean();
            }
            gsBean.clearCache();

            gsBean.setTaskId(new BigDecimal(taskId));
            gsBean.setInternationalRegistrationNumber(irNum);

            if (transIds != null) { // take the first transId for now
                try {
                    tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                        new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.BASICAPPLICATION_FORM);
                } catch (MCServerException e) {

                    logger.error(
                        "Method: displayBasicApplicationPage - taskId " + taskId + ", transId  - " + transIds.get(0)
                            + ", act Id " + actId + ", IR# " + gsBean.getInternationalRegistrationNumber());
                    logger.error(
                        "Method: displayBasicApplicationPage - Error generating GoodsServicesBean - " + e.getMessage(),
                        e);
                    // e.printStackTrace();

                    try {
                        response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                        transactionServiceClient.releaseLock(gsBean);

                        // return "ptBasicApplication";
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
                // show the marks supporting the IR on the first page
                gsBean.setHideMarksSupportingIR(false);
            } else {
                logger.error("Method: displayBasicApplicationPage - Transaction ID is missing for task " + taskId
                    + " activity task - " + actId);
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        "Transaction ID is missing for task " + taskId + " activity task - " + actId);
                    transactionServiceClient.releaseLock(gsBean);

                } catch (Exception e) {
                    logger.error("Exception: ", e);
                    // e.printStackTrace();
                }
            }

        }

        return "ptBasicApplication";
    }

    /**
     * Displays the first screen to select the options when processing the G&S manual tasks.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/basicapplication", method = RequestMethod.GET)
    public String prepareSelectPage(final ModelMap modelMap, final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                    HttpServletRequest request) {

        logger.debug("Method: prepareSelectPage: IR: " + gsBean.getInternationalRegistrationNumber() + ", Task ID: "
            + gsBean.getActivityTaskId());

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptBasicApplication";
    }

    /**
     * Process any user selected input from the first screen when processing basic application manual task.
     *
     * @param gsBean the bean containing the data from the view
     * @param model the model
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/basicapplication/marks", method = RequestMethod.POST)
    public String handleSelectSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, ModelMap model,
                                         final HttpServletRequest request, final HttpServletResponse response,
                                         HttpSession session, final RedirectAttributes redirectAttributes) {

        logger.debug("Method: handleSelectSubmitForm: IR: " + gsBean.getInternationalRegistrationNumber()
            + ", Task ID: " + gsBean.getActivityTaskId());

        String action = gsBean.getAction();
        String viewName = "ptBasicApplication";

        viewName = "redirect:/processtask/basicapplication/wipomerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {
            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            viewName = "redirect:/processtask/basicapplication/wipomerge";

            /*
             * if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
             * viewName = "redirect:/processtask/basicapplication/wipomerge"; } else if
             * (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT)) { try {
             * tmAppService.processGoodServiceChange(request, gsBean);
             *
             * // call workflow engine to complete task try { mweClient.completeTask(gsBean.getActivityTaskId(),
             * userProfileService.getAuthorityId());
             *
             * redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
             * "mc.goodsandservices.label.noadjustmsg", null, LocaleContextHolder.getLocale()));
             *
             * } catch (MWEServiceFault | MCServerException e) { // TODO replace it with CIPOService Fault later // and
             * handle errors // // What happens if MWE cannot complete task but MTS has marked it Processed? // TODO:
             * The task will not appear on the console. MTS Needs to handle it. logger.error(
             * "Error completing Goods and Services Task by MWE - "); logger.error("IR: " +
             * gsBean.getInternationalRegistrationNumber() + ", File: " +
             * gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: " +
             * gsBean.getActivityTaskId()); logger.error("Exception: ", e);
             * redirectAttributes.addFlashAttribute("errorMsg",
             * messageSource.getMessage("mc.goodsandservices.label.noadjustmsgerr", null,
             * LocaleContextHolder.getLocale()) + e.getMessage()); }
             *
             * } catch (ca.gc.ic.cipo.tm.mts.CIPOServiceFault e) { // TODO handle errors logger.error(
             * "Error submitting goods and services request to MTS - "); logger.error("IR: " +
             * gsBean.getInternationalRegistrationNumber() + ", File: " +
             * gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: " +
             * gsBean.getActivityTaskId()); logger.error("Exception: ", e);
             * redirectAttributes.addFlashAttribute("errorMsg",
             * messageSource.getMessage("mc.goodsandservices.label.noadjustmsgerr", null,
             * LocaleContextHolder.getLocale()) + e.getMessage()); }
             *
             * // go back to the calling page viewName = "redirect:" + session.getAttribute("refererPage");
             *
             * session.setAttribute("wipogs", null);
             *
             * } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) { try {
             * gsBean.copyAllToFinalFromWipo(false); tmAppService.processGoodServiceChange(request, gsBean);
             *
             * // call workflow engine to complete task try { mweClient.completeTask(gsBean.getActivityTaskId(),
             * userProfileService.getAuthorityId());
             *
             * redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
             * "mc.goodsandservices.label.acceptwipomsg", null, LocaleContextHolder.getLocale()));
             *
             * } catch (MWEServiceFault | MCServerException e) { // TODO replace it with CIPOService Fault later // and
             * handle errors // // What happens if MWE cannot complete task but MTS has marked it Processed? // TODO:
             * The task will not appear on the console. MTS Needs to handle it. logger.error(
             * "Error completing Goods and Services Task by MWE - "); logger.error("IR: " +
             * gsBean.getInternationalRegistrationNumber() + ", File: " +
             * gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: " +
             * gsBean.getActivityTaskId()); logger.error("Exception: ", e);
             * redirectAttributes.addFlashAttribute("errorMsg",
             * messageSource.getMessage("mc.goodsandservices.label.acceptwipomsgerr", null,
             * LocaleContextHolder.getLocale()) + e.getMessage()); } } catch (ca.gc.ic.cipo.tm.mts.CIPOServiceFault e) {
             * // TODO handle errors logger.error("Error submitting goods and services request to MTS - ");
             * logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: " +
             * gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: " +
             * gsBean.getActivityTaskId()); logger.error("Exception: ", e);
             *
             * redirectAttributes.addFlashAttribute("errorMsg",
             * messageSource.getMessage("mc.goodsandservices.label.acceptwipomsgerr", null,
             * LocaleContextHolder.getLocale()) + e.getMessage()); }
             *
             * viewName = "redirect:" + session.getAttribute("refererPage");
             *
             * session.setAttribute("wipogs", null); }
             */
        } else if (action.startsWith(ActionDispatcher.ACTION_SAVE)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);
            if (tokens.length > 1) {
                gsBean.updateMarksForIR(tokens[1]);
                gsBean.setHideMarksSupportingIR(true);

                viewName = "redirect:" + session.getAttribute("refererPage");

                try {
                    // call MTS to save and go back
                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine to complete task
                    mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                    redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                        "mc.goodsandservices.label.createbasicappmsg", null, LocaleContextHolder.getLocale()));

                } catch (MCServerException e) {

                    // What happens if MWE cannot complete task but MTS has marked it Processed?
                    // TODO: The task will not appear on the console. MTS Needs to handle it.
                    logger.error(
                        "Method: handleSelectSubmitForm: Error completing Create Basic Application Task by MWE - ");
                    logger.error("Method: handleSelectSubmitForm: IR: " + gsBean.getInternationalRegistrationNumber()
                        + ", Task ID: " + gsBean.getActivityTaskId());
                    logger.error("Exception: ", e);
                    // e.printStackTrace();
                    redirectAttributes.addFlashAttribute("errorMsg",
                        messageSource.getMessage("mc.goodsandservices.label.createbasicappmsgerr", null,
                            LocaleContextHolder.getLocale()) + e.getMessage());
                } finally {

                    // Release the LOCK on the File Number/Extension
                    try {
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (MCServerException e) {
                        logger.error(
                            "/processtask/basicapplication/marks, Errors attempting to release Lock." + e.getMessage());
                    }
                }
            } else {

                // Total ceasing of effect. Show MF9
                viewName = "redirect:/processtask/MF9";
            }

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                if (gsBean.getApplication() != null) {
                    transactionServiceClient.releaseLock(gsBean);
                }
            } catch (Exception e) {
                logger.error(
                    "processtask/basicapplication/marks, (CANCEL) Errors attempting to release Lock." + e.getMessage());
            }
        }
        return viewName;
    }

    /**
     * Prepare the second page when processing G&S manual tasks where the statements from WIPO and INTREPID are merged
     * and adjusted.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/basicapplication/wipomerge", method = RequestMethod.GET)
    public String prepareMergePage(final ModelMap modelMap, final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                   HttpServletRequest request) {
        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptBasicApplicationGS";
    }

    /**
     * Process any actions on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/basicapplication/wipomerge", method = RequestMethod.POST)
    public String handleMergeSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                        final HttpServletRequest request, final HttpServletResponse response,
                                        HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = gsBean.getAction();
        String viewName = "ptBasicApplicationGS";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {
            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                viewName = "redirect:/processtask/basicapplication/review";
            }
        } else if (action.startsWith(ActionDispatcher.ACTION_MOVEWIPOTOMERGE)) { // .equalsIgnoreCase(action)) {
            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.copyWIPOStatementToFinalForNANR(new Integer(tokens[2]));

        } else if (action.startsWith(ActionDispatcher.ACTION_REMOVEFROMFINAL)) { // .equalsIgnoreCase(action)) {
            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);
            gsBean.removeWipoStatementFromFinalForNANR(new Integer(tokens[1]));

        } else if (action.startsWith(ActionDispatcher.ACTION_EDITFINAL)) {
            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.editFinalForNANR(new Integer(tokens[1]), request.getParameter("updatedText"));

        } else if (action.startsWith(ActionDispatcher.ACTION_REMOVEALLFROMFINAL)) {

            gsBean.removeAllFromFinalForNANR();

        } else if (action.startsWith(ActionDispatcher.ACTION_COPYALLFROMWIPO)) {

            gsBean.copyAllToFinalFromWipoForNANR();

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_PREVIOUS.equalsIgnoreCase(action)) {
            gsBean.setHideMarksSupportingIR(true);
            viewName = "redirect:/processtask/basicapplication";

        } else if (ActionDispatcher.ACTION_SAVE.equalsIgnoreCase(action)) {

            if (gsBean.isHideMarksSupportingIR()) {

                if (!gsBean.gsInFinal()) {

                    // Total Ceasing of Effect, go to MF9 screen
                    viewName = "redirect:/processtask/MF9";
                } else {
                    gsBean.setHideMarksSupportingIR(false);
                    viewName = "redirect:/processtask/basicapplication/wipomerge";
                }
            }
        } else if (action.startsWith(ActionDispatcher.ACTION_SAVE + "_")) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);
            gsBean.updateMarksForIR(tokens[1]);
            gsBean.setHideMarksSupportingIR(true);

            if (gsBean.getBasicMarksWithGS().size() > 0) {
                try {

                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine (MWE) to complete task
                    try {
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                        redirectAttributes.addFlashAttribute("wipogs", gsBean);
                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.acceptadjmsg", null, LocaleContextHolder.getLocale()));

                    } catch (MCServerException e) {

                        // What happens if MWE cannot complete task but MTS has marked it Processed?
                        // TODO: The task will not appear on the console. MTS Needs to handle it.
                        logger.error("Error completing Goods and Services Task by MWE - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId());
                        logger.error("Exception: ", e);
                        // e.printStackTrace();
                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.acceptadjmsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    } finally {

                        // Release the LOCK on the File Number/Extension
                        try {
                            transactionServiceClient.releaseLock(gsBean);
                        } catch (MCServerException e) {
                            logger.error(
                                "/processtask/basicapplication/wipomerge, (ACTION SAVE) Errors attempting to release Lock."
                                    + e.getMessage());
                        }
                    }
                    viewName = "redirect:" + session.getAttribute("refererPage");
                    session.setAttribute("wipogs", null);
                } catch (MCServerException e) {

                    logger.error("Error submitting goods and services request to MTS - ");
                    logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                        + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                        + gsBean.getActivityTaskId());
                    logger.error("Exception: ", e);
                    // e.printStackTrace();

                    redirectAttributes.addFlashAttribute("errorMsg",
                        messageSource.getMessage("mc.goodsandservices.label.acceptadjmsgerr", null,
                            LocaleContextHolder.getLocale()) + e.getMessage());
                    viewName = "redirect:" + session.getAttribute("refererPage");
                    session.setAttribute("wipogs", null);
                } finally {

                    // Release the LOCK on the File Number/Extension
                    try {
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (MCServerException e) {
                        logger.error(
                            "/processtask/basicapplication/wipomerge, (ACTION SAVE) Errors attempting to release Lock."
                                + e.getMessage());
                    }
                }
            } else {
                viewName = "redirect:/processtask/basicapplication/wipomerge";
            }
        }

        return viewName;
    }
}
