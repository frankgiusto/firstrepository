package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;

public class PackageBean implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -9124666294377438064L;

    private String packageId;

    private String type;

    private String transactionDate;

    private String intlPubId;

    private String intlPubDate;

    private int numberOfAttachments;
    
    private String status;

    private String actions;
    
    public String getPackageId() {
        return packageId;
    }

    
    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    
    public String getType() {
        return type;
    }

    
    public void setType(String type) {
        this.type = type;
    }

    
    public String getTransactionDate() {
        return transactionDate;
    }

    
    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    
    public String getIntlPubId() {
        return intlPubId;
    }

    
    public void setIntlPubId(String intlPubId) {
        this.intlPubId = intlPubId;
    }

    
    public String getIntlPubDate() {
        return intlPubDate;
    }

    
    public void setIntlPubDate(String intlPubDate) {
        this.intlPubDate = intlPubDate;
    }

    
    public int getNumberOfAttachments() {
        return numberOfAttachments;
    }

    
    public void setNumberOfAttachments(int numberOfAttachments) {
        this.numberOfAttachments = numberOfAttachments;
    }

    
    public String getStatus() {
        return status;
    }

    
    public void setStatus(String status) {
        this.status = status;
    }


    
    public String getActions() {
        return actions;
    }


    
    public void setActions(String actions) {
        this.actions = actions;
    }


}
