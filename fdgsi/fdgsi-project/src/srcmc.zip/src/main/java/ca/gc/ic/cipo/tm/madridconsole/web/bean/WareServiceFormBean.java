package ca.gc.ic.cipo.tm.madridconsole.web.bean;

public class WareServiceFormBean {

	/** Action performed. */
	private String action = "";

	private Integer niceClassNumber = null;

	private Integer niceClassEdition = null;

	private String statement = "";

	Integer mergeGSNumber = null;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Integer getNiceClassNumber() {
		return niceClassNumber;
	}

	public void setNiceClassNumber(Integer niceClassNumber) {
		this.niceClassNumber = niceClassNumber;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public Integer getMergeGSNumber() {
		return mergeGSNumber;
	}

	public void setMergeGSNumber(Integer mergeGSNumber) {
		this.mergeGSNumber = mergeGSNumber;
	}

	public Integer getNiceClassEdition() {
		return niceClassEdition;
	}

	public void setNiceClassEdition(Integer niceClassEdition) {
		this.niceClassEdition = niceClassEdition;
	}

}
