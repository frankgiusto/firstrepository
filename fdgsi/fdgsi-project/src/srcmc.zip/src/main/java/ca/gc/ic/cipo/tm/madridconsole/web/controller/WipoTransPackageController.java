package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.service.intl.IDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.schema.mps.PackageDetail;


/**
 * This is the main Controller for obtaining Package information.
 * 
 * @author tannerb
 *
 */
@Controller
@RequestMapping("/package")
public class WipoTransPackageController {

    private static Logger LOGGER = Logger.getLogger(WipoTransPackageController.class.getName());

    @Autowired
    private IDataTableService dataTableService;

    /**
     * This method is used to retrieve Financial Package Data (i.e., it is used to display/retrieve
     * a list or Packages (of type FINANCIAL)
     * 
     * @param typelist  Type Id
     * @param periodlist Period list (example:" -1 -3 etc.)
     * @param startdate Start Date 
     * @param enddate End Date
     * @param statuslist List of Statuses
     * @return PrinterWriter (response.getWriter())
     * 
     */
    @RequestMapping(value = "/financialpackagetabledata", method = RequestMethod.GET)
    public void  getFinancialPackages(HttpServletRequest request, HttpServletResponse response,
                               @RequestParam(value = "typelist", required = false) String typeid,
                               @RequestParam(value = "periodlist", required = false) String periodid,
                               @RequestParam(value = "startdate", required = false) String startdate,
                               @RequestParam(value = "enddate", required = false) String enddate,
                               @RequestParam(value = "statuslist", required = false) String status, Model model,
                               Locale loc, HttpSession session) 
        throws Exception {

        LOGGER.debug("financialpackagetabledata typeid: " + typeid + " statuslist: " + status +  "periodid: " 
            + periodid + "startdate: " + startdate + " enddate: " + enddate );

        String listFinancialPackages = null;
 
        // If the end date has been received, 1 day must be added to the date,
        // so that those packages for THAT END Date will be returned in the HPS getPackageList result. 
        if(enddate != null && !enddate.isEmpty()) {
            Date dt = DateFormats.getISOSDF().parse(enddate);
            Calendar c = Calendar.getInstance(); 
            c.setTime(dt); 
            c.add(Calendar.DATE, 1);
            dt = c.getTime();
            enddate = DateFormats.getISOSDF().format(dt);
        }
       
        // Given that a "Time Period" was selected (for example...1 month) determine the
        // Start and End Date.
        if (periodid != null && periodid.length() > 0 && !periodid.equalsIgnoreCase("0")) {
            
            // Because the service is using a dateTime for comparison, 1 day must be added to the date,
            // so that those packages for THAT END Date will be returned in the HPS getPackageList result. 
            Date dt = new Date();
            Calendar c = Calendar.getInstance(); 
            c.setTime(dt); 
            c.add(Calendar.DATE, 1);
            dt = c.getTime();
            
            startdate = WipoTransPackageController.convertdatebyMonths(periodid);
            enddate =  DateFormats.getISOSDF().format(dt);
        }
 
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;
        
        try {
            out = response.getWriter();
            listFinancialPackages = dataTableService.getPackageDataTableResponse(request, typeid, periodid, loc, status,
                startdate, enddate);
  
            if (listFinancialPackages != null) {
                out.print(listFinancialPackages);
            }
            
        } catch (Exception se) {
            LOGGER.error("Exception received while processing the input data of typeid: " 
                + typeid + " statuslist: " + status +  "periodid: " + periodid + "startdate: " + startdate + " enddate: " + enddate );
            LOGGER.warn("Madird Console runtime exception. check the data", se);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
            } catch (IOException e) {
                LOGGER.error("Exception: ", e);
            }
        }
        
    }

    /**
     * This method is used to retrieve Bulletin Package Data (i.e., it is used to display/retrieve
     * a list or Packages (of type BULLETIN, either 'IB to Office' or 'Office to IB')
     * 
     * @param typelist  Type Id
     * @param periodlist Period list (example:" -1 -3 etc.)
     * @param startdate Start Date 
     * @param enddate End Date
     * @param statuslist List of Statuses
     * @return VOID
     */
    @RequestMapping(value = "/bulletinpackagetabledata", method = RequestMethod.GET)
    public void getBulletinPackageInfo(HttpServletRequest request, HttpServletResponse response,
                               @RequestParam(value = "typelist", required = false) String typeid,
                               @RequestParam(value = "periodlist", required = false) String periodid,
                               @RequestParam(value = "startdate", required = false) String startdate,
                               @RequestParam(value = "enddate", required = false) String enddate,
                               @RequestParam(value = "statuslist", required = false) String status, Model model,
                               Locale loc, HttpSession session)
        throws Exception {

        LOGGER.debug("bulletinpackagetabledata typeid: " + typeid + " statuslist: " + status +  "periodid: " 
            + periodid + "startdate: " + startdate + " enddate: " + enddate );
        
        String listPackageBean = null;

        // If the end date has been received, 1 day must be added to the date,
        // so that those packages for THAT END Date will be returned in the HPS getPackageList Result. 
        if(enddate != null && !enddate.isEmpty()) {
            Date dt = DateFormats.getISOSDF().parse(enddate);
            Calendar c = Calendar.getInstance(); 
            c.setTime(dt); 
            c.add(Calendar.DATE, 1);
            dt = c.getTime();
            enddate = DateFormats.getISOSDF().format(dt);
        }
  
        
        // Given that a "Time Period" was selected (for example...1 month) determine the
        // Start and End Date.
        if (periodid != null && periodid.length() > 0 && !periodid.equalsIgnoreCase("0")) {
            // Because the service is using a dateTime for comparison, 1 day must be added to the date,
            // so that those packages for THAT END Date will be returned in the HPS getPackageList result. 
            Date dt = new Date();
            Calendar c = Calendar.getInstance(); 
            c.setTime(dt); 
            c.add(Calendar.DATE, 1);
            dt = c.getTime();
            
            startdate = WipoTransPackageController.convertdatebyMonths(periodid);
            enddate =  DateFormats.getISOSDF().format(dt);
        }

        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;
        
        try {
            out = response.getWriter();
            listPackageBean = dataTableService.getPackageDataTableResponse(request, typeid, periodid, loc, status,
                startdate, enddate);

            if (listPackageBean != null) {
                out.print(listPackageBean);
            }
            
        } catch (Exception se) {
            LOGGER.error("Exception received while processing the input data of typeid: " + typeid 
                + " statuslist: " + status +  "periodid: " + periodid + "startdate: " + startdate + " enddate: " + enddate );
            LOGGER.error("Madird Console runtime exception. " +  se);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
            } catch (IOException e) {
                LOGGER.error("Exception: ", e);
            }
        }
       
    }

    /**
     * This method is used to retrieve Package Detail information.
     * 
     * @param packageid Package Id
     * @return VOID
     * @exception Exception
     */
    @RequestMapping(value = "/getPackageDetail", method = RequestMethod.GET)
    public void getPackageDetail(HttpServletRequest request, HttpServletResponse response,
                               @RequestParam(value = "packageid", required = false) String packageid,
                                Model model,
                               Locale loc, HttpSession session)  {
        
        LOGGER.debug("getPackageDetail packageid: " + packageid );
        
        String packageDetail = null;
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;
        
        try {
            out = response.getWriter();
            
            packageDetail = dataTableService.getPackageDetail(Long.parseLong(packageid), loc);
            
            if (packageDetail != null) {
                out.print(packageDetail);
            }
            
        } catch (Exception e) {
            LOGGER.error("fail to output jason to gui for package display.", e);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        } 
       
    }    
 
    /**
     * This method is used to Download Package Detail information (XML).
     *
     * @param packageId  Package ID
     * @return String - XML Content being downloaded
     * @exception Exception
     * 
     */
    @RequestMapping(value = "/getPackageFile/{packageId}", method = RequestMethod.GET)
    public void getPackagefile(@PathVariable long packageId, HttpServletRequest request, HttpServletResponse response,
                               HttpSession session) {

        try {
            LOGGER.debug("getPackageFile packageid: " + packageId );
        
            PackageDetail packageDetail = dataTableService.getPackageFile(packageId);
            byte[] packagefile = packageDetail.getXmlContent();
        
            response.setHeader("Content-Disposition", "attachment; filename=" + packageId + ".xml");
            response.setHeader("Content-Type", "application/octet-stream");
            response.setHeader("Content-Length", String.valueOf(packagefile.length));

            OutputStream outputStream = null;
            try {
                outputStream = response.getOutputStream();

                outputStream.write(packagefile);
                outputStream.flush();

                } finally {
                    if (null != outputStream) {
                        outputStream.close();
                    }
                }
            }
            catch (Exception e) {
                try {
                    response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
                } catch (IOException e1) {
                    LOGGER.error("Exception: ", e1);
                }
            }
        return;
    }
    
    /**
     * This method is used to Download Package Notifications.
     *
     * @param packageId  Package ID
     * @return String - Notification Content being downloaded
     * @exception Exception
     * 
     */
    @RequestMapping(value = "/getPackageNotification/{packageId}", method = RequestMethod.GET)
    public void getPackageNotification(@PathVariable long packageId, HttpServletRequest request, HttpServletResponse response,
                               HttpSession session) {

        LOGGER.debug("getPackageNotification packageid: " + packageId );
        try {
            PackageDetail packageDetail = dataTableService.getPackageFile(packageId);
            byte[] packagefile = packageDetail.getNotifContent();
            
            response.setHeader("Content-Disposition", "attachment; filename=PkgId_" + packageDetail.getPackageId() + ".xref.txt" );
            response.setHeader("Content-Type", "application/octet-stream");
            response.setHeader("Content-Length", String.valueOf(packagefile.length));
    
            OutputStream outputStream = null;
                try {
                    outputStream = response.getOutputStream();
        
                    outputStream.write(packagefile);
                    outputStream.flush();
        
                } finally {
                    if (null != outputStream) {
                        outputStream.close();
                    }
                }
            }
            catch (Exception e) {
                try {
                    response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
                } catch (IOException e1) {
                    LOGGER.error("Exception: ", e1);
                }
            }
         return;
    }
 
    
    /**
     * This method is used to obtain Package Detail Event information (i.e., Event List data). 
     *
     * @param packageId  Package ID
     * @return void
     * @exception Exception
     * 
     */
    @RequestMapping(value = "/bulletinPackageEventsdetail", method = RequestMethod.GET)
    public void redirectBulletinDetailView(@RequestParam(value = "packageid", required = true) Long packageid,
                               HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
                               HttpSession session){
        
        LOGGER.debug("Method: bulletinPackageEventsdetail, packageid: " + packageid );

        String eventDetailList = null; 
        
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;

        try {
            
            out = response.getWriter();
            eventDetailList = dataTableService.getPackageEventsList( Long.toString(packageid), loc);
            if (eventDetailList != null) {
                out.print(eventDetailList);
            }
 
        } catch (Exception e) {
            LOGGER.error("Exception received while processing packageid: " + packageid  );
            LOGGER.error("Exception:", e);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }

    }
    /**
     * This method is used to obtain Package Attachment information (i.e., Attachment List data). 
     *
     * @param packageId  Package ID
     * @return void
     * @exception Exception
     * 
     */
    @RequestMapping(value = "/bulletinPackagetabledatpasspkgid", method = RequestMethod.GET)
    public void getTransactionattachetail(@RequestParam(value = "packageid", required = true) String packageid,
                               HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
                               HttpSession session) {
        
        LOGGER.debug("bulletinPackagetabledatpasspkgid packageid: " + packageid );
        
        model.addAttribute("packageid", packageid);
        String attachmentlList = null; 
        
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;

        try {
            
            out = response.getWriter();
            attachmentlList = dataTableService.getPackageAttachments(Long.parseLong(packageid), loc);
            if (attachmentlList != null) {
                out.print(attachmentlList);
            }
 
        } catch (Exception se) {
            LOGGER.error("Exception received while processing the input data of packageid: " + packageid  );
            LOGGER.warn("Madird Console runtime exception. check the data", se);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }
        }
    }
    
    /**
     * This method obtain the Addition Information (most likely Error Data) for a given Package Id and Event Id.
     * 
     * @param packageId Package Id
     * @param eventId Event Id
     */
    @RequestMapping(value = "/getPackageErrorEventData", method = RequestMethod.GET)
    public void getPackageErrorEventData(@RequestParam(value = "packageId", required = true) Long packageId,
                                   @RequestParam(value = "eventId", required = true) Long eventId,
        HttpServletRequest request, HttpServletResponse response, Model model, Locale loc,
        HttpSession session) {
        
        LOGGER.debug("Method: getPackageErrorEventData, packageId: " + packageId  + ", eventId: " + eventId);
        
        try {
        String errorEventlData = null;
        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");
        PrintWriter out;
        
        out = response.getWriter();
            errorEventlData = dataTableService.getPackageEventDetailData(packageId, eventId);
        
            if (errorEventlData != null) {
                out.print(errorEventlData);
            }
        } catch (Exception se) {
            LOGGER.error("Exception received while processing the input data of packageId: " + packageId + ", eventId: " + eventId  );
            LOGGER.warn("Madird Console runtime exception. check the data", se);
            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("wipotransmissions.error.package.service"));
            } catch (IOException e1) {
                LOGGER.error("Exception: ", e1);
            }

        }
    }
    
    public static String convertdatebyMonths(String amountMonth) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, Integer.parseInt(amountMonth));
        return DateFormats.getISOSDF().format(cal.getTime());
    }

    public static String convertStringToDate(Date indate) {
        String dateString = null;
        SimpleDateFormat sdfr = new SimpleDateFormat("dd/MMM/yyyy");
        try {
            dateString = sdfr.format(indate);
        } catch (Exception se) {
            LOGGER.error("Exception received in method convertStringToDate"  );

        }
        return dateString;
    }

}