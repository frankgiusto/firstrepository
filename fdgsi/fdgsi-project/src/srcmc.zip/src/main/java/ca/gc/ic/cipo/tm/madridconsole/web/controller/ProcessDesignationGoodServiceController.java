package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

/**
 * The Class ProcessDesignationGoodServiceController handles when a Madrid Designation (Category Registration or Subsequent Designation)
 *  is received and there is a Limitation with a Comment (com:CommentText is present within GoodsServicesLimitationBag).
 *
 */
@Controller
@SessionAttributes("wipogs")
public class ProcessDesignationGoodServiceController {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(ProcessDesignationGoodServiceController.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    /** The message source. */
    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * Gets the bean used to transfer data from View and Controller.
     *
     * @param request the request
     * @return the wipo gs
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    /** The TM App service to retrieve info from TIRS. */
    @Autowired
    protected TradMarkApplicationService tmAppService;

    /** The MWE client. */
    @Autowired
    protected WorkflowEngineServiceClient mweClient;

    /** The user profile service. */
    @Autowired
    protected UserProfileServiceClient userProfileService;

    /**
     * Inits the binder.
     *
     * @param binder the binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * This will get the necessary data and display the "Madrid Designation G&S Limitation" Screen.
     *
     * @param fileNumberStr the file number of the application associated to the selected task being processed.
     * @param transIds the trans ids associated to the selected task being processed.
     * @param taskId the task id associated to the selected task being processed.
     * @param actId the MWE activity task id associated to the selected task being processed.
     * @param type the type of the task being processed.
     * @param gsBean the gs bean used to send and receive data between the view and controller
     * @param modelMap the model map
     * @param request the request
     * @param session the session
     * @return the initial page
     */
    @RequestMapping(value = "/processtask/designationgoodservicelimitation", method = RequestMethod.POST)
    public String displayDesignationGsSelectOptionsPage(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                             @RequestParam(value = "transIds", required = false) List<String> transIds,
                                             @RequestParam(value = "taskId", required = false) String taskId,
                                             @RequestParam(value = "aId", required = false) String actId,
                                             @RequestParam(value = "type", required = false) String type,
                                             @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                             final ModelMap modelMap, HttpServletRequest request,
                                             HttpServletResponse response, HttpSession session,
                                             Map<String, String> errors) {

        logger.debug("Method: displayDesignationGsSelectOptionsPage: File: " + fileNumberStr + ", Task ID: " + taskId + ", actId "
            + actId + ", type " + type + ", transIds " + transIds);

        int fileNumber = Integer.parseInt(fileNumberStr);

        ArrayList<String> actIds = new ArrayList<String>();
        actIds.add(actId);

        try {

            // Acquire lock
            transactionServiceClient.acquireLock( gsBean, fileNumber, 0, userProfileService.getLdapUsername(request));

            // assign task to the user first, if its already been assigned we should not proceed
            // and let the user know that he should refresh page.
            if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                userProfileService.getParentId(request)) > 0) {
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                    transactionServiceClient.releaseLock( gsBean);

                } catch (IOException e) {
                    logger.error("Exception: ", e);
                }
            }

        } catch (MCServerException e) {
            logger.error("Method: displayDesignationGsSelectOptionsPage: File: " + fileNumberStr + ", Task ID: " + taskId
                + ", actId " + actId + ", type " + type + ", transIds " + transIds + "Error assigning task to current user "
                + userProfileService.getParentId(request)
                + " due to Exception - " + e.getMessage(), e);

            try {
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
                return "DesignationGoodandServiceLimitation";
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }  catch (Throwable e) {
            logger.error("Method: displayDesignationGsSelectOptionsPage: File: " + fileNumberStr + ", Task ID: " + taskId
                + ", actId " + actId + ", type " + type + ", transIds " + transIds + "Error assigning task to current user "
                + userProfileService.getParentId(request)
                + " due to Throwable - " + e.getMessage(), e);

            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("mc.error.mts.gettransaction"));
                transactionServiceClient.releaseLock(gsBean);
                return "DesignationGoodandServiceLimitation";
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        if (gsBean == null) {
            gsBean = new GoodServiceWipoBean();
        }
        gsBean.clearCache();

        try {
            tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.DESIGNATIONGOODSERVICESLIMITATION_FORM);

        } catch (MCServerException e) {

            try {
                logger.error("Method: displayDesignationGsSelectOptionsPage: Error generating GoodsServicesBean File: "
                    + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", type " + type
                    + ", transIds " + transIds + " due to error " + e.getMessage(), e);

                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                transactionServiceClient.releaseLock( gsBean);
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        return "DesignationGoodandServiceLimitation";
    }

    /**
     * Displays the first screen to select the options when processing the G&S manual tasks.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/designationgoodservicelimitation", method = RequestMethod.GET)
    public String prepareDesignationGsSelectPage(final ModelMap modelMap,
                                      final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                      HttpServletRequest request) {

        logger.debug("Method: prepareDesignationGsSelectPage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "DesignationGoodandServiceLimitation";
    }

    /**
     * Process any user selected input from the first screen when processing manual tasks.  Options are either:
     *      - Accept all Goods/Services in this limitation  (NOTE: This optinon will NOT be available for
     *            Designation with Limitations.
     *      - Accept Goods or Services with adjustments
     *      - Refuse the Limitation - Send Limitation with no effect
     *
     *
     * @param gsBean the bean containing the data from the view
     * @param model the model
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/designationgoodservicelimitation/merge", method = RequestMethod.POST)
    public String handleDesignationGsSelectSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, ModelMap model,
                                           final HttpServletRequest request, final HttpServletResponse response,
                                           HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = gsBean.getAction();
        String viewName = "redirect:/processtask/designationgoodservicelimitation/wipomerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        logger.debug("Method: handleDesignationGsSelectSubmitForm with action " + action);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {

            gsBean.setAction(ActionDispatcher.ACTION_NEXT);

            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {

                viewName = "redirect:/processtask/designationgoodservicelimitation/wipomerge";

            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT)) {

                    viewName = "redirect:/processtask/MF13";

            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) {
                //
                // NOTE: For a Designation (with Limitation), we should never have this Scenario
                //
            }
        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/designationgoodservicelimitation/merge, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }

        }
        return viewName;
    }

    /**
     * Prepare the second page when processing G&S manual tasks where the statements from WIPO and INTREPID are merged
     * and adjusted.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/designationgoodservicelimitation/wipomerge", method = RequestMethod.GET)
    public String prepareDesignationGsMergePage(final ModelMap modelMap,
                                     final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                     HttpServletRequest request) {

        logger.debug("Method: prepareDesignationGsMergePage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "DesignationGoodandServiceLimitationMerge";
    }

    /**
     * Process any actions on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/designationgoodservicelimitation/wipomerge", method = RequestMethod.POST)
    public String handleDesignationGsMergeSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                          @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                          @RequestParam(required = false, defaultValue = "false", value = "submitMF13") String submitMF13,
                                          final HttpServletRequest request, final HttpServletResponse response,
                                          HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = (actionVal == null || actionVal.isEmpty()) ? gsBean.getAction() : actionVal;

        logger.debug("Method: handleDesignationGsMergeSubmitForm with action " + action + ", submitMF13  " + submitMF13);

        String viewName = "DesignationGoodandServiceLimitationMerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {

            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                viewName = "redirect:/processtask/designationgoodservicelimitation/review";
            }

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/designationgoodservicelimitation/wipomerge, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }


        } else if (ActionDispatcher.ACTION_PREVIOUS.equalsIgnoreCase(action)) {

            viewName = "redirect:/processtask/designationgoodservicelimitation";

        } else if (ActionDispatcher.ACTION_SAVE.equalsIgnoreCase(action)) {

            try {

                // If there is G&S in final and this wish to send a MF13,
                // then we need to call the MF13 page to let user fill information and
                // only then mark the task complete (this will be done by the MF13 controller).
                //
                // If they do NOT wish to send a MF13, the just Process the Change.
                if (gsBean.gsInFinal()
                        && submitMF13.equals("false")) {

                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine (MWE) to complete task
                    try {
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                        redirectAttributes.addFlashAttribute("wipogs", gsBean);
                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.acceptadjmsg", null, LocaleContextHolder.getLocale()));

                    } catch (MCServerException e) {

                        // What happens if MWE cannot complete task but MTS has marked it Processed?
                        // TODO: The task will not appear on the console. MTS Needs to handle it.
                        logger.error("Error completing Goods and Services Task by MWE - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId() +"Exception: ", e);

                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.acceptadjmsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    } finally {
                        // Release the LOCK on the File Number/Extension
                        try {
                            transactionServiceClient.releaseLock(gsBean);
                        } catch (MCServerException e) {
                            logger.error("/processtask/goodservice/wipomerge, (ACTION SAVE) Errors attempting to release Lock." + e.getMessage() );
                        }
                    }

                    viewName = "redirect:" + session.getAttribute("refererPage");
                    session.setAttribute("wipogs", null);

                } else {
                    viewName = "redirect:/processtask/MF13";
                }

            } catch (MCServerException e) {

                logger.error("Error submitting goods and services request to MTS - ");
                logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                    + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                    + gsBean.getActivityTaskId()+ "Exception: ", e);

                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.goodsandservices.label.acceptadjmsgerr", null,
                        LocaleContextHolder.getLocale()) + e.getMessage());
                viewName = "redirect:" + session.getAttribute("refererPage");
                session.setAttribute("wipogs", null);

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock(gsBean);
                } catch (MCServerException e1) {
                    logger.error("/processtask/goodservice/wipomerge, (ACTION SAVE) Errors attempting to release Lock." + e1.getMessage() );
                }

            }
        }

        return viewName;
    }


}
