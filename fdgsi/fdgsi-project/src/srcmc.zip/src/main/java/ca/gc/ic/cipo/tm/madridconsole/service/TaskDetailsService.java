package ca.gc.ic.cipo.tm.madridconsole.service;

import java.math.BigDecimal;

import javax.activation.DataHandler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;

/**
 * The Class TaskDetailsService.
 */
@Service
public class TaskDetailsService {

    /** The MTS transaction service. */
    @Autowired
    private TransactionServiceClient transactionService;

    /**
     * Gets the pdf associated with the transaction based on the attachment id
     *
     * @param attachId the attachment Id
     * @return the pdf associated with the attachment id
     * @throws MCServerException the Madrid Console service fault
     */
    public DataHandler getTransactionAttachment(BigDecimal attachId) throws MCServerException {

        // Call MTS service to get PDF from database.
        AttachmentDetail detail = transactionService.getTransactionAttachment(attachId);
        return detail.getFileContent();
    }
}
