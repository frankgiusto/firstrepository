package ca.gc.ic.cipo.tm.madridconsole.service.web;

import javax.servlet.http.HttpServletRequest;

import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

public interface IDataTableService {

    enum processTaskURL {
        DESIGNATIONGOODSERVICELIMITATION("/processtask/designationgoodservicelimitation"),
        GOODSERVICE("/processtask/goodservice"),
        IRREGULARITY("/processtask/irregularity"),
        IRCORRECTION("/processtask/ircorrection"),
        EDITMAILINGLABEL("/processtask/editMailingLabel"),
        MF3A("/processtask/MF3A"),
        PARTIALOWNERSHIP("/processtask/partialownership"),
        PARTIALCEASING_OO("/processtask/partialceasingoo"),
        BASIC_APPLICATION("/processtask/basicapplication"),
        MF9("/processtask/MF9");

        String strProcessTaskURL;

        processTaskURL(String pT) {
            strProcessTaskURL = pT;
        }

        String getUrl() {
            return strProcessTaskURL;
        }
    }

    public String getDataTableResponse(HttpServletRequest request, int tableNum) throws MCServerException;

}
