package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;

public class TaskDetailInfoBean {

    String internationalRegistrationNumber;

    // Data From Intripid
    TrademarkApplicationType application;

    String taskDetailsMessage = "";

    String taskStatus = "";

    // String officeType="D/O";
    String dataTimeReceived = "";

    String bfDate = "";

}
