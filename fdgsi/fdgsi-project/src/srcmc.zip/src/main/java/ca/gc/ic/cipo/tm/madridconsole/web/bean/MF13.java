package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;

import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;


public class MF13 implements Serializable {

    private static final long serialVersionUID = 1L;
    
    ProcessManualReportRequest mf13Request = new ProcessManualReportRequest();

    
    public ProcessManualReportRequest getMf13Request() {
        return mf13Request;
    }

    
    public void setMf13Request(ProcessManualReportRequest mf13Request) {
        this.mf13Request = mf13Request;
    }

    

}
