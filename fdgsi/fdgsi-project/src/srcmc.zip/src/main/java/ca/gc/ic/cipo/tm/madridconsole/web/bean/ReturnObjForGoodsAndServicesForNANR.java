package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.util.List;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;

public class ReturnObjForGoodsAndServicesForNANR {

    private int niceClass;

    private ClassDescriptionType wipoGSType;

    private List<BasicMarksByNiceClass> intrepidGSType;

    private ClassDescriptionType finalGSType; // this will only be set when we do a copy over to final col from WIPO

    public ReturnObjForGoodsAndServicesForNANR(int niceClass, ClassDescriptionType wipoGS,
                                               List<BasicMarksByNiceClass> intrepidGS) {

        this.niceClass = niceClass;
        this.wipoGSType = wipoGS;
        this.intrepidGSType = intrepidGS;
    }

    public int getNiceClass() {
        return niceClass;
    }

    public void setNiceClass(int niceClass) {
        this.niceClass = niceClass;
    }

    public ClassDescriptionType getWipoGSType() {
        return wipoGSType;
    }

    public void setWipoGSType(ClassDescriptionType wipoGSType) {
        this.wipoGSType = wipoGSType;
    }

    public List<BasicMarksByNiceClass> getIntrepidGSType() {
        return intrepidGSType;
    }

    public void setIntrepidGSType(List<BasicMarksByNiceClass> intrepidClass) {
        this.intrepidGSType = intrepidClass;
    }

    public ClassDescriptionType getFinalGSType() {
        return finalGSType;
    }

    public void setFinalGSType(ClassDescriptionType finalGSType) {
        this.finalGSType = finalGSType;
    }
}
