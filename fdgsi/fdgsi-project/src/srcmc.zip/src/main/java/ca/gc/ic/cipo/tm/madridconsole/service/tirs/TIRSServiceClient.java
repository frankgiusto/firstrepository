package ca.gc.ic.cipo.tm.madridconsole.service.tirs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.schema.HeartbeatResponseType;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.util.ServiceUtil;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault;
import ca.gc.ic.cipo.tm.tirs.common.TMInfoRetrievalCommonServicePortType;
import ca.gc.ic.cipo.tm.tirs.common.TrademarkInfoRetrievalCommonServiceFactory;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.trademark.extended.ApplicationNumberBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.MadridApplicationEventBagType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.MadridApplicationEventType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsTypeMF3BagType;

/**
 * The Class TIRSServiceClient is a Trademark Information Retrieval Service web service client.
 *
 * @author kaurs
 */
@Service
public class TIRSServiceClient {

    /** The tirs host name from the intl database INTL_CNFGN_PARM table */
    @Value("${mc.tm.information.retrieval.services.host.name}")
    private String tmirServiceHost;

    @Autowired
    SendErrorEmail sendErrorEmail;

    /** The logger. */
    protected static Logger logger = Logger.getLogger(TIRSServiceClient.class);

    /**
     * Gets the TIRS client.
     *
     * @return the client
     * @throws MCServerException
     */
    private TMInfoRetrievalCommonServicePortType getClient() throws MCServerException {

        TMInfoRetrievalCommonServicePortType tirsClient = TrademarkInfoRetrievalCommonServiceFactory
            .createClient(tmirServiceHost);

        if (tirsClient == null) {
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.serviceunavailable"));
        }
        return tirsClient;
    }

    /**
     * Gets the application by file number.
     *
     * @param fileNumber the file number
     * @return the application by number
     * @throws MCServerException the MC server exception
     */
    public TrademarkApplicationType getApplicationByNumber(int fileNumber) throws MCServerException {

        logger.debug("Method: getApplicationByNumber: getting application by file number - " + fileNumber);

        ApplicationNumber app = new ApplicationNumber();
        app.setFileNumber(fileNumber);
        app.setExtensionCounter(Integer.valueOf(0));

        String[] params = new String[2];
        params[0] = "" + app.getFileNumber();
        params[1] = "" + app.getExtensionCounter();

        try {
            TrademarkApplicationType appType = getClient().getApplicationByNumber(app);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            if (appType == null || appType.getApplicationNumber() == null) {

                logger
                    .error("Method: getApplicationByNumber: Error getting application by file number - " + fileNumber);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appbynum", params));
            }
            return appType;
        } catch (CIPOServiceFault e) {

            logger.error("Method: getApplicationByNumber: Error getting application by file number - " + fileNumber);
            logger.error("Method: getApplicationByNumber: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appbynum", params), e);

        } catch (Throwable e) {

            logger
                .error("Method: getApplicationByNumber: Reveived Throwable. Error getting application by file number - "
                    + fileNumber);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost, "getApplicationByNumber()",
                e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appbynum", params), e);
        }
    }

    /**
     * Gets the application by application number which includes the file number and extension counter.
     *
     * @param app the ApplicationNumber
     * @return the application by number
     * @throws MCServerException the MC server exception
     */
    public TrademarkApplicationType getApplicationByNumber(ApplicationNumber app) throws MCServerException {

        logger.debug("Method: getApplicationByNumber: Error getting application by app number - " + app.getFileNumber()
            + "(" + app.getExtensionCounter() + ")");

        String[] params = new String[2];
        params[0] = "" + app.getFileNumber();
        params[1] = "" + app.getExtensionCounter();

        try {
            TrademarkApplicationType trademarkApplicationType = getClient().getApplicationByNumber(app);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            return trademarkApplicationType;

        } catch (CIPOServiceFault e) {

            logger.error("Method: getApplicationByNumber: Error getting application by app number - "
                + app.getFileNumber() + "(" + app.getExtensionCounter() + ")");
            logger.error("Method: getApplicationByNumber: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appbynum", params), e);

        } catch (Throwable e) {

            logger
                .error("Method: getApplicationByNumber: Received Throwable.  Error getting application by app number - "
                    + app.getFileNumber() + "(" + app.getExtensionCounter() + ")");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost, "getApplicationByNumber()",
                e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appbynum", params), e);
        }
    }

    /**
     * Gets the list of goods and services with claims.
     *
     * @param fileNumber the file number of the Application
     * @return the list of goods services with claims
     * @throws MCServerException the MC server exception
     */
    public List<GoodsServicesClaimsType> getClaimsByGoodsService(int fileNumber) throws MCServerException {

        logger.debug("Method: getClaimsByGoodsService: getting claims by goods and services - " + fileNumber);

        ApplicationNumber app = new ApplicationNumber();
        app.setFileNumber(fileNumber);
        app.setExtensionCounter(Integer.valueOf(0));

        List<GoodsServicesClaimsType> gsTypes = new ArrayList<GoodsServicesClaimsType>();
        GoodsServicesClaimsBagType gscBag;

        String[] params = new String[1];
        params[0] = "" + app.getFileNumber();

        try {
            gscBag = getClient().getClaimsByGoodsService(app);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);

        } catch (CIPOServiceFault e) {

            logger.error("Method: getClaimsByGoodsService: Error getting claims by goods and services - " + fileNumber);
            logger.error("Method: getClaimsByGoodsService: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.gsclaims", params), e);

        } catch (Throwable e) {

            logger.error(
                "Method: getClaimsByGoodsService: Revieved Throwable.  Error getting claims by goods and services - "
                    + fileNumber);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost,
                "getClaimsByGoodsService(int filenumber), filenumber=" + fileNumber, e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.gsclaims", params), e);
        }
        if (gscBag.isSetGoodsServicesClaims()) {
            gsTypes = gscBag.getGoodsServicesClaims();
        }
        return gsTypes;
    }

    /**
     * Gets the list of Applications based on international registration number.
     *
     * @param irNumber the international registration number
     * @return the list of ApplicationNumbers
     * @throws MCServerException the MC server exception
     */
    public List<ApplicationNumber> getApplications(String irNumber) throws MCServerException {

        logger.debug("Method: getApplications: getting list of basic applications by IR - " + irNumber);

        // Get the basic marks that make up the IR from INTREPID
        ApplicationNumberBagType appsBag = null;
        String[] params = new String[1];
        params[0] = irNumber;

        try {
            appsBag = getClient().getApplicationNumbersByInternationalRegistrationNumber(irNumber);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);

        } catch (CIPOServiceFault e) {

            logger.error("Method: getApplications: Error getting list of basic applications by IR - " + irNumber);
            logger.error("Method: getApplications: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyir", params), e);

        } catch (Throwable e) {

            logger
                .error("Method: getApplications: Received Throwable. Error getting list of basic applications by IR - "
                    + irNumber);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost,
                "getApplicationNumbersByInternationalRegistrationNumber(irNumber), irNumber=" + irNumber,
                e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyir", params), e);
        }

        List<ApplicationNumber> apps = Collections.emptyList();
        if (appsBag.isSetApplicationNumbers()) {
            apps = appsBag.getApplicationNumbers();
        }
        return apps;
    }

    /**
     * Gets the list of Madrid Application Action on international registration number.
     *
     * @param irNumber the international registration number
     * @return the list of MadridApplicationEventType
     * @throws MCServerException the MC server exception
     */
    public List<MadridApplicationEventType> getMadridApplicationEvents(String irNumber) throws MCServerException {

        logger.debug(
            "Method: getMadridApplicationEvents: getting list of madrid applications action by IR - " + irNumber);

        // Get the basic marks that make up the IR from INTREPID
        MadridApplicationEventBagType madridEventsBag = null;
        String[] params = new String[1];
        params[0] = irNumber;

        try {
            madridEventsBag = getClient().getMadridApplicationEventsByInternationalRegistrationNumber(irNumber);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);

        } catch (CIPOServiceFault e) {

            logger.error("Method: getApplications: Error getting list of basic applications by IR - " + irNumber);
            logger.error("Method: getApplications: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyir", params), e);

        } catch (Throwable e) {

            logger.error(
                "Method: getApplications: Received Throwable. Error getting list of madrid events(actions) by IR - "
                    + irNumber);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost,
                "getMadridApplicationEventsByInternationalRegistrationNumber(irNumber), irNumber=" + irNumber,
                e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyir", params), e);
        }

        List<MadridApplicationEventType> events = Collections.emptyList();
        if (madridEventsBag.isSetMadridApplicationEvents()) {
            events = madridEventsBag.getMadridApplicationEvents();
        }
        return events;
    }

    /**
     * Gets the list of goods and services by ApplicationNumber (file number and extension counter).
     *
     * @param app the ApplicationNumber
     * @return the list of goods services
     * @throws MCServerException the MC server exception
     */
    public List<GoodsServicesType> getGoodsServices(ApplicationNumber app) throws MCServerException {

        logger.debug("Method: getGoodsServices: getting list of goods and services by Application Number - "
            + app.getFileNumber() + "(" + app.getExtensionCounter() + ")");

        List<GoodsServicesType> gsTypes = new ArrayList<GoodsServicesType>();
        GoodsServicesBagType gscBag;
        String[] params = new String[1];
        params[0] = app.getFileNumber() + "(" + app.getExtensionCounter() + ")";

        try {
            gscBag = getClient().getGoodsServices(app);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);

        } catch (CIPOServiceFault e) {

            logger.error("Method: getGoodsServices: Error getting list of goods and services by Application Number - "
                + app.getFileNumber() + "(" + app.getExtensionCounter() + ")");
            logger.error("Method: getGoodsServices: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyfilenum", params), e);

        } catch (Throwable e) {

            logger.error(
                "Method: getGoodsServices: Received Throwable.  Error getting list of goods and services by Application Number - "
                    + app.getFileNumber() + "(" + app.getExtensionCounter() + ")");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost, "getGoodsServices(app)",
                e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyfilenum", params), e);
        }
        if (gscBag.isSetGoodsServices()) {
            gsTypes = gscBag.getGoodsServices();
        }
        return gsTypes;
    }

    /**
     * getHeartbeat() for TIRS.
     *
     * @return ca.gc.ic.cipo.schema.ws.common.HeartbeatResponseType
     */
    public HeartbeatResponseType getHeartbeat() {

        logger.debug("Method: getHeartbeat for MWE");

        HeartbeatResponseType getHeartbeatResponse = new HeartbeatResponseType();
        try {
            getHeartbeatResponse = getClient().getHeartbeat();
            getHeartbeatResponse.setIpAddress(getHeartbeatResponse.getIpAddress() + "   " + tmirServiceHost);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);

        } catch (Throwable tow) {
            tow.printStackTrace();
            getHeartbeatResponse.setIpAddress(tmirServiceHost);
            getHeartbeatResponse.setNodeName("");
            getHeartbeatResponse.setStatus("<b style='color:red;'>" + "OFF LINE" + "</b>");
            logger.error("Method: Throwable Exception: ", tow);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost, "getHeartbeat()", tow.getMessage());

        }

        return getHeartbeatResponse;
    }

    /**
     * Gets the application by file number, this method is used specifcally for the MF3A.
     *
     * @param fileNumber the file number
     * @return TrademarkDetailsTypeMF3BagType
     * @throws MCServerException the MC server exception
     */
    public TrademarkDetailsTypeMF3BagType getFillingNumberInformation(int fileNumber) throws MCServerException {

        logger.debug("Method: getFillingNumberInformation: getting Trademark by file number - " + fileNumber);

        String[] params = new String[1];
        params[0] = "" + fileNumber;

        try {
            TrademarkDetailsTypeMF3BagType trademarkDetailsTypeMF3BagType = getClient().getTrademarkDetailsForMF3(fileNumber, true);  // true (i.e., include the attachments)
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            if (trademarkDetailsTypeMF3BagType == null ) {

                logger.error(
                    "Method: getFillingNumberInformation: Error getting application by file number - " + fileNumber);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appbynum", params));
            }
            return trademarkDetailsTypeMF3BagType;
        } catch (CIPOServiceFault e) {

            logger
                .error("Method: getFillingNumberInformation: Error getting application by file number - " + fileNumber);
            logger.error("Method: getFillingNumberInformation: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.TIRS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyfilenum", params), e);

        } catch (Throwable e) {

            logger.error(
                "Method: getFillingNumberInformation: Reveived Throwable. Error getting application by file number - "
                    + fileNumber);
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.TIRS, tmirServiceHost,
                "getFillingNumberInformation(int fileNumber), fileNumber=" + fileNumber, e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.tirs.appsbyfilenum", params), e);
        }
    }
}
