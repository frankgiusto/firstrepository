package ca.gc.ic.cipo.tm.madridconsole.service.web;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.intl.enumerator.TaskStatusType;
import ca.gc.ic.cipo.tm.intl.enumerator.UserTaskType;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridGroup;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mts.AddtnlInfoMeta;
import ca.gc.ic.cipo.tm.mts.TaskTransactionMeta;
import ca.gc.ic.cipo.tm.mts.TransactionAttachmentMeta;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskMeta;

/**
 * Service for retrieving Madrid Console tasks.
 *
 * @author giustof, kaurs
 */
@Service
public class TaskDataTableService implements IDataTableService {

    /** The Constant log. */
    private final static Logger logger = Logger.getLogger(TaskDataTableService.class);

    /** The servlet context. */
    @Autowired
    private ServletContext servletContext;

    /** The message source. */
    @Resource(name = "messageSource")
    private MessageSource messageSource;

    /**
     * Config parameter indicating whether sequencing of tasks should be done from the intl database INTL_CNFGN_PARM
     * table.
     */
    @Value("${mc.seq.tasks}")
    private boolean seqTasks;

    /** The transaction service. */
    @Autowired
    private TransactionServiceClient transactionService;

    public static String REPRESENTATIVE_COURTESY_LETTER = "COURTESY_LETTER_PDF";

    @Override
    public String getDataTableResponse(HttpServletRequest request, int tableNum) throws MCServerException {

        // Response will be a String of JSONObject type
        JSONObject taskResults = new JSONObject();

        // JSON Array to store each row of the data table
        JSONArray taskList = new JSONArray();

        Locale locale = LocaleContextHolder.getLocale();

        // Get tasks from Madrid Transaction Service (MTS) to display in the data tables depending upon page (tableNum)
        WorkflowTaskListResponse taskBucketList = transactionService.getListOfWorkflowTasks(request, tableNum, true,
            false);

        for (WorkflowTaskMeta taskRow : taskBucketList.getWorkflowTaskMetaList().getTaskListBag()) {

            // link the task to the activity task id as that is what is required when acknowledging notifications
            StringBuilder idLink = new StringBuilder();
            idLink.append("<input type='checkbox' name=").append(taskRow.getActRuTaskId()).append(" id='selection")
                .append(taskRow.getIntlRegNo()).append("'/>");

            // set up column data
            JSONArray taskColumn = new JSONArray();
            taskColumn.put(idLink.toString());
            taskColumn.put(taskRow.getIntlRegNo());
            taskColumn.put((taskRow.getDmstcApltnFileNbr() != null ? taskRow.getDmstcApltnFileNbr().toString() : ""));

            // The Description
            String description = "";
            if (locale.getLanguage().equals("fr")) {
                description = taskRow.getTaskDescFr();
            } else {
                description = taskRow.getTaskDescEn();
            }
            description += appendAdditionalInfo(taskRow);

            taskColumn.put(description);

            TaskTransactionMeta meta = (taskRow.getTransactionListBag() != null
                && taskRow.getTransactionListBag().size() > 0) ? taskRow.getTransactionListBag().get(0) : null;

            if (null != meta) {
                taskColumn.put(DateFormats.getISOSDF().format(
                    meta.getIntlRecordEfctvDt() != null ? meta.getIntlRecordEfctvDt() : taskRow.getTaskUpdatedDate()));
            } else {
                taskColumn.put(DateFormats.getISOSDF().format(taskRow.getTaskUpdatedDate()));
            }

            // get the list of transactions and attachments pre-formatted for display
            taskColumn.put(this.getTransactionsAndAttachmentsLink(taskRow));

            // display User id of the user assigned the task for task bucket if page, group name for task bucket and
            // notifications page
            // If NOT Notifications Page....display the Creation Time Stamp.
            if (tableNum == TransactionServiceClient.TASK_BUCKET_TABLE) {
                taskColumn.put(taskRow.getAssignedUserId() != null
                    ? ((taskRow.getUserName() != null)
                        ? (new String(taskRow.getUserName().getBytes(StandardCharsets.UTF_8)) + " ("
                            + taskRow.getAssignedUserId() + ")")
                        : taskRow.getAssignedUserId())
                    : MadridGroup.getMadridGroupName(taskRow.getAssignedUserGroup()));
                taskColumn.put(DateFormats.getISOSDFDateTime().format(taskRow.getTaskCreateDate()));
            } else if (tableNum == TransactionServiceClient.MY_TASKS_TABLE) {
                taskColumn.put(DateFormats.getISOSDFDateTime().format(taskRow.getTaskCreateDate()));
            } else if (tableNum == TransactionServiceClient.NOTIFICATIONS_TABLE) {
                taskColumn.put(MadridGroup.getMadridGroupName(taskRow.getAssignedUserGroup()));
            }
            taskColumn.put(getStatusIcon(taskRow.getStatusTaskId())); // status icon

            if (tableNum != TransactionServiceClient.NOTIFICATIONS_TABLE) {
                taskColumn.put(getActionLink(taskRow, locale)); // action icon
            }
            taskList.put(taskColumn);
        }

        try {
            taskResults.put("iTotalRecords", taskBucketList.getTotalTasks().toString());
            taskResults.put("iTotalDisplayRecords", taskBucketList.getTotalTasksForDisplay().toString());
            taskResults.put("data", taskList);
        } catch (JSONException e) {
            logger.error("Method: getDataTableResponse: Error retrieving workflow tasks due to JSON processing error"
                + tableNum + ": " + e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.jsonerror"), e);
        }

        return taskResults.toString();
    }

    @SuppressWarnings("incomplete-switch")
    private String appendAdditionalInfo(WorkflowTaskMeta task) {

        String addnlInfo = "";

        for (AddtnlInfoMeta addtnlInfoMeta : task.getAddtnlInfoListBag()) {

            if (addtnlInfoMeta.getAddtnlInfo() != null) {
                switch (UserTaskType.getStatusTypeByValue(task.getStatusCategoryId())) {

                    case REVIEW_PARTIAL_OWNERSHIP_CHANGE:
                        addnlInfo = " (" + addtnlInfoMeta.getAddtnlInfo() + ")";
                        break;
                    case IR_REPLACEMENT_REQUEST:
                        addnlInfo = " ("
                            + messageSource.getMessage("mc.tasks.replacing", null, LocaleContextHolder.getLocale())
                            + addtnlInfoMeta.getAddtnlInfo() + ")";
                        break;
                    default:
                        if (addtnlInfoMeta.getAddtnlInfo().startsWith("mc.response.to.irregularity")) {
                            addnlInfo = " (" + messageSource.getMessage("mc.response.to.irregularity", null,
                                LocaleContextHolder.getLocale()) + ")";
                        }
                        break;
                }
            }

        }

        return addnlInfo;
    }

    private static Date parseDate(String date) {

        try {
            return DateFormats.getISOSDF().parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * Gets the status icon for the status column.
     *
     * @param statusId the status id
     * @return the status icon
     */
    private String getStatusIcon(BigDecimal statusId) {
        String result = "";
        if (statusId != null) {
            // adding an empty a link just for tool tip as title tag on span wasnt working for some reason
            if (statusId.intValue() == TaskStatusType.UNPROCESSED.getValue()) { // Unprocessed
                result = "<a title='"
                    + messageSource.getMessage("dashboard.label.unprocessed", null, LocaleContextHolder.getLocale())
                    + "'><span class='far fa-circle fa-lg text-success mrgn-right-sm'></span></a>";
            } else if (statusId.intValue() == TaskStatusType.CLOSED_UNPROCESSED.getValue()) { // Closed-Unprocessed
                result = "<a title='"
                    + messageSource.getMessage("dashboard.label.closedunprocessed", null,
                        LocaleContextHolder.getLocale())
                    + "'><span class='fas fa-circle fa-lg text-success mrgn-rght-sm'></span>";
            } else if (statusId.intValue() == TaskStatusType.PROCESSED.getValue()) { // Closed-Processed
                result = "<a title='"
                    + messageSource.getMessage("dashboard.label.closedprocessed", null, LocaleContextHolder.getLocale())
                    + "'><span class='fas fa-check-circle fa-lg text-success mrgn-rght-sm'></span>";
            } else if (statusId.intValue() == TaskStatusType.ON_HOLD.getValue()) { // On hold
                result = "<a title='"
                    + messageSource.getMessage("dashboard.label.hold", null, LocaleContextHolder.getLocale())
                    + "'><span class='as fa-pause-circle fa-lg mrgn-rght-sm' style='color:#666;'></span>";
            } /*
               * else if (statusId.intValue() == 4) { // Error-Processed result =
               * "<span class='fas fa-exclamation-circle fa-lg text-danger mrgn-rght-sm'>"; }
               */
        }

        return result;
    }

    /**
     * Gets the transactions and attachments pre-formatted for display for the transactions/attachments column.
     *
     * @param taskRow the task row
     * @return the transactions and attachments link
     */
    private String getTransactionsAndAttachmentsLink(WorkflowTaskMeta taskRow) {

        return createTransactionsAndAttachmentsSection(taskRow);

    }

    private String createTransactionsAndAttachmentsSection(WorkflowTaskMeta taskRow) {

        StringBuilder detailLink = new StringBuilder();

        List<TaskTransactionMeta> transBag = taskRow.getTransactionListBag();

        int numOfTrans = taskRow.getTransactionListBag().size();
        int numOfAttach = 0;

        // Get the total number of attachments from all the transactions
        for (int i = 0; i < numOfTrans; i++) {
            // get number of attachements ....excluding Courtesy Letters.
            numOfAttach += getNumberOfTransAttachments(transBag.get(i).getAttachmentListBag());
        }
        if (numOfTrans > 0) {
            detailLink.append("<details id=\"").append("detail_id").append("\">").append("<summary id=\"")
                .append(taskRow.getTaskId()).append("\" style=\"background-color:#F5F5F5; border:solid 1px #ccc\">")
                .append("<span title='")
                .append(messageSource.getMessage("dashboard.label.transattach", null, LocaleContextHolder.getLocale()))
                .append("' ID=\"noUnderline\">").append(numOfTrans)
                .append(" <i class=\"far fa-envelope text-warning mrgn-rght-lg\"></i>");
            if (numOfAttach > 0) {
                detailLink.append(numOfAttach).append(" <i class=\"far fa-file\"></i>");
            }
            detailLink.append("</span>").append("</summary>");

            detailLink.append("<ul id=\"attach\" class=\"list-unstyled\">");

            Locale locale = LocaleContextHolder.getLocale();

            TaskTransactionMeta taskmeta;

            for (int i = 0; i < numOfTrans; i++) {

                taskmeta = transBag.get(i);

                // display the transaction
                detailLink
                    .append(
                        "<li class=\"nowrap\" style=\"border:1px solid #999999 !important; padding:4px; margin-top:8px;\">")
                    .append("<i class=\"far fa-envelope text-warning\"></i> ").append("<a title='")
                    .append(
                        messageSource.getMessage("dashboard.label.transactions", null, LocaleContextHolder.getLocale()))
                    .append("' href='javascript:void(0);'").append(" onclick=\"launchMessagedetailDialog('")
                    .append(taskmeta.getIrTranId().toString()).append("');\">");

                if (locale.getLanguage().equals("fr")) {
                    detailLink.append(taskmeta.getTranCtgryDescFr()).append("</a>");
                } else {
                    detailLink.append(taskmeta.getTranCtgryDescEn()).append("</a>");
                }

                // get number of attachements ....excluding Courtesy Letters.
                numOfAttach = getNumberOfTransAttachments(taskmeta.getAttachmentListBag());

                if (numOfAttach > 0) {

                    detailLink.append("<ul style=\"margin-left:-22px\">");

                    // display the attachments
                    String filename = "";
                    TransactionAttachmentMeta transAttachMeta;

                    for (int j = 0; j < numOfAttach; j++) {
                        transAttachMeta = taskmeta.getAttachmentListBag().get(j);

                        // Exclude Courtesy Letters...
                        if (!transAttachMeta.getAtchmtCtgry().equals(REPRESENTATIVE_COURTESY_LETTER)) {
                            filename = transAttachMeta.getFileName();
                            detailLink.append("<li class=\"nowrap list-unstyled\">")
                                .append(getItagByFiletype(transAttachMeta.getFileFrmtCtgry())).append(" <a title='")
                                .append(messageSource.getMessage("dashboard.label.attachments", null,
                                    LocaleContextHolder.getLocale()))
                                .append("' href='").append(servletContext.getContextPath())
                                .append("/dashboard/getFile?attachId=").append(transAttachMeta.getAtchmtId())
                                .append("&filename=").append(filename).append("'>").append(filename);
                            detailLink.append("</a></li>");
                        }
                    }
                    detailLink.append("</ul>");
                }
                detailLink.append("</li>");
            }
            detailLink.append("</ul></details>");
        }
        return detailLink.toString();
    }

    /**
     * This method is used to determine (i.e., count) the number of attachments, for a Transaction. NOTE: This method
     * will EXCLUDE Courtesy Letters. (i.e., when Category NOT Equal REPRESENTATIVE_COURTESY_LETTER)
     *
     * @param List<TransactionAttachmentMeta>
     * @return int - number of attachments.
     */
    public int getNumberOfTransAttachments(List<TransactionAttachmentMeta> list) {

        logger.debug("Method:getNumberOfTransAttachments");

        int attachmentCnt = 0;
        int i = 0;
        while (i < list.size()) {
            TransactionAttachmentMeta transactionAttachmentMeta = list.get(i);
            if (!transactionAttachmentMeta.getAtchmtCtgry().equals(REPRESENTATIVE_COURTESY_LETTER)) {
                attachmentCnt++;
            }
            i++;
        }

        return attachmentCnt;
    }

    private String getItagByFiletype(String fileformat) {

        String itag = "";

        switch (fileformat.toLowerCase()) {
            case "png":
            case "tif":
            case "tiff":
            case "gif":
            case "bmp":
            case "jpg":
            case "jpeg":
                itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-image text-success\"></i>";
                break;
            case "pdf":
                itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-pdf text-danger\"></i>";
                break;
            case "doc":
            case "docx":
                itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-word text-primary\"></i>";
                break;
            case "xls":
                itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-excel text-success\"></i>";
                break;
            case "xml":
                itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-code text-success\"></i>";
                break;
            case "zip":
                itag = "<li class=\"nowrap list-unstyled\"><i class=\"far fa-file-zip\"></i>";
                break;
        }

        return itag;
    }

    /**
     * Gets the action link for the action column based on the task type.
     *
     * @param task the task
     * @param local the local
     * @return the action link
     */
    private String getActionLink(WorkflowTaskMeta task, Locale local) {

        StringBuilder actionLink = new StringBuilder();
        StringBuilder strTranIds = new StringBuilder();

        // we will probably only get one transaction but since we get a bag, we need to parse it as such
        List<TaskTransactionMeta> tranIdList = task.getTransactionListBag();

        for (TaskTransactionMeta tranId : tranIdList) {
            strTranIds.append("&transIds=" + tranId.getIrTranId());
        }
        String taskIdStr = "&taskId=" + task.getTaskId();
        String activtaskIdStr = "&aId=" + task.getActRuTaskId();

        // Determine the URL
        String strUrl = null;
        switch (UserTaskType.getStatusTypeByValue(task.getStatusCategoryId())) {
            case GOODSERVICE_LIMITATION:
            case PARTIAL_CEASING_OF_EFFECT_DO:
            case PARTIAL_CANCELLATION:
                strUrl = processTaskURL.GOODSERVICE.getUrl();
                break;
            case DESIGNATION_LIMITATION:
                strUrl = processTaskURL.DESIGNATIONGOODSERVICELIMITATION.getUrl();
                break;
            case PARTIAL_OWNERSHIP_CHANGE_DESIGNATION_RESTRICTION:
                strUrl = processTaskURL.PARTIALOWNERSHIP.getUrl();
                break;
            case PARTIAL_CEASING_OF_EFFECT_OO:
                strUrl = processTaskURL.PARTIALCEASING_OO.getUrl();
                break;
            case BASIC_APPLICATION_LIST:
                strUrl = processTaskURL.BASIC_APPLICATION.getUrl();
                break;
            case IRREGULARITY:
                strUrl = processTaskURL.IRREGULARITY.getUrl();
                break;
            case UPDATE_ADDRESS_CREATE_COURTESYLATTER:
                strUrl = processTaskURL.EDITMAILINGLABEL.getUrl();
                break;
            case CORRECTION:
                strUrl = processTaskURL.IRCORRECTION.getUrl();
                break;
            case MADRID_PROVISIONAL_REFUSAL_MF3A:
                strUrl = processTaskURL.MF3A.getUrl();
                break;
            case TOTAL_CEASING_OF_EFFECT_OO:
                strUrl = processTaskURL.MF9.getUrl();
                break;
            default:
                logger.info("Status Type: " + UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()));
        }

        if (UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.GOODSERVICE_LIMITATION
            || UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.DESIGNATION_LIMITATION
            || UserTaskType
                .getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.PARTIAL_CEASING_OF_EFFECT_DO
            || UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.IRREGULARITY
            || UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.CORRECTION
            || UserTaskType
                .getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.UPDATE_ADDRESS_CREATE_COURTESYLATTER
            || UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.PARTIAL_CANCELLATION
            || UserTaskType.getStatusTypeByValue(
                task.getStatusCategoryId()) == UserTaskType.PARTIAL_OWNERSHIP_CHANGE_DESIGNATION_RESTRICTION
            || UserTaskType
                .getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.MADRID_PROVISIONAL_REFUSAL_MF3A
            || UserTaskType
                .getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.PARTIAL_CEASING_OF_EFFECT_OO
            || UserTaskType.getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.BASIC_APPLICATION_LIST
            || UserTaskType
                .getStatusTypeByValue(task.getStatusCategoryId()) == UserTaskType.TOTAL_CEASING_OF_EFFECT_OO) {

            String fileNumber = task.getDmstcApltnFileNbr() == null ? StringUtils.EMPTY
                : task.getDmstcApltnFileNbr().toString();

            if (task.getStatusTaskId() != null
                && task.getStatusTaskId().intValue() == TaskStatusType.UNPROCESSED.getValue()
                && !strTranIds.toString().isEmpty()) {

                actionLink.append("<a title='")
                    .append(
                        messageSource.getMessage("dashboard.label.processtask", null, LocaleContextHolder.getLocale()))
                    .append("' id=\"proctask\" class=\"btn btn-primary btn-xs\" href=\"#")
                    .append(task.getTaskId() + "\"");
                actionLink.append(" onclick=\"processTask('").append(servletContext.getContextPath()).append(strUrl)
                    .append("','").append(fileNumber).append("','").append(task.getIntlRegNo()).append("','")
                    .append(tranIdList.get(0).getIrTranId()).append("','").append(task.getTaskId()).append("','")
                    .append(task.getActRuTaskId()).append("');\">");
                actionLink.append("<i class=\"\" aria-hidden=\"true\" ></i>"
                    + "<span class=\"fas fa-cogs mrgn-tp-sm\"></span>" + "</a>");

            } else {
                logger.warn("The task id: " + task.getTaskId() + " activity id: " + task.getActRuTaskId()
                    + " may have been processed or has no transaction associated with it. Disabling action link - ");
                actionLink.append("<a class=\"disabled btn btn-default btn-xs\" href='")
                    .append(servletContext.getContextPath())
                    .append(strUrl + "?filenumber=" + fileNumber + strTranIds.toString() + taskIdStr + activtaskIdStr
                        + "'><i class=\"\" aria-hidden=\"true\" ></i>"
                        + "<span class=\"fas fa-cogs mrgn-tp-sm\" style=\"color:#d1d1d1;\"></span>" + "</a>");

            }
        }

        logger.debug("action link = " + actionLink.toString());
        return actionLink.toString();
    }

    public String getUncompletedTasksForIR(HttpServletRequest request, int tableNum) throws MCServerException {

        // Response will be a String of JSONObject type
        JSONObject taskResults = new JSONObject();

        // JSON Array to store each row of the data table
        JSONArray taskList = new JSONArray();

        Locale locale = LocaleContextHolder.getLocale();

        // Get tasks (both Manual and Notificiations) from Madrid Transaction Service (MTS)
        WorkflowTaskListResponse taskBucketList = transactionService.getListOfWorkflowTasks(request, tableNum, false,
            true);

        String actId = request.getParameter("actId");

        long taskTime = 0L;
        boolean taskCanBeProcessed = false;

        if (seqTasks) {
            // first find the task that matches the one we are trying to process and if its a correction task, we will
            // display the warning of unprocessed tasks but allow them to continue processing the task
            for (WorkflowTaskMeta taskRow : taskBucketList.getWorkflowTaskMetaList().getTaskListBag()) {
                if (taskRow.getActRuTaskId().equalsIgnoreCase(actId)) {

                    TaskTransactionMeta meta = (taskRow.getTransactionListBag() != null
                        && taskRow.getTransactionListBag().size() > 0) ? taskRow.getTransactionListBag().get(0) : null;
                    if (null != meta && meta.getIntlRecordEfctvDt() != null) {
                        taskTime = meta.getIntlRecordEfctvDt().getTime();

                        if (UserTaskType
                            .getStatusTypeByValue(taskRow.getStatusCategoryId()) == UserTaskType.CORRECTION) {
                            taskCanBeProcessed = true;
                        }
                    }
                }
            }

            // Only return the tasks for same IR that have record effective date earlier than the one being processed.
            // Same dates are fine.
            for (WorkflowTaskMeta taskRow : taskBucketList.getWorkflowTaskMetaList().getTaskListBag()) {

                // skip the one that we are trying to process.
                if (taskRow.getActRuTaskId().equalsIgnoreCase(actId)) {
                    continue;
                }

                // make sure we have a valid unprocessed status and has a transaction
                if (taskRow.getStatusTaskId() != null
                    && taskRow.getStatusTaskId().intValue() == TaskStatusType.UNPROCESSED.getValue()
                    && (taskRow.getTransactionListBag() != null && taskRow.getTransactionListBag().size() > 0)) {

                    // set up column data
                    JSONArray taskColumn = new JSONArray();

                    taskColumn.put(taskRow.getIntlRegNo());
                    if (locale.getLanguage().equals("fr")) {
                        taskColumn.put(taskRow.getTaskDescFr());
                    } else {
                        taskColumn.put(taskRow.getTaskDescEn());
                    }

                    TaskTransactionMeta meta = taskRow.getTransactionListBag().get(0);

                    if (null != meta && meta.getIntlRecordEfctvDt() != null) {
                        if (meta.getIntlRecordEfctvDt().getTime() >= taskTime) {
                            // skip this task as it has the same or later record effective date than the task being
                            // processed
                            continue;
                        }
                        taskColumn.put(DateFormats.getISOSDF().format(meta.getIntlRecordEfctvDt()));
                    } else {
                        taskColumn.put(DateFormats.getISOSDF().format(parseDate("1970-01-01")));
                    }

                    // display user id of the user assigned the task for task bucket if page, group name for task bucket
                    // and notifications page
                    taskColumn.put(taskRow.getAssignedUserId() != null
                        ? ((taskRow.getUserName() != null)
                            ? (new String(taskRow.getUserName().getBytes(StandardCharsets.UTF_8)) + " ("
                                + taskRow.getAssignedUserId() + ")")
                            : taskRow.getAssignedUserId())
                        : MadridGroup.getMadridGroupName(taskRow.getAssignedUserGroup()));

                    taskList.put(taskColumn);
                }
            }
            // if taskCanBeProcessed is already true, that means we have a Corrections tasks and can go ahead. Otherwise
            // check if we have don't have any task that needs to be processed before this, than set it to true.
            if (!taskCanBeProcessed && taskList.length() == 0) {
                taskCanBeProcessed = true;
            }
        } else {
            taskCanBeProcessed = true;
        }
        try {
            taskResults.put("count", taskList.length());
            taskResults.put("data", taskList);
            taskResults.put("taskcanbeprocessed", taskCanBeProcessed);
        } catch (JSONException e) {
            logger
                .error("Method: getUncompletedTasksForIR: Error retrieving workflow tasks due to JSON processing error"
                    + tableNum + ": " + e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.jsonerror"), e);
        }

        return taskResults.toString();
    }
}
