package ca.gc.ic.cipo.tm.madridconsole.service.impl;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.madridconsole.service.intl.IDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.service.intl.WipoTransPackageService;
import ca.gc.ic.cipo.tm.madridconsole.service.intl.WipoTransTransactionService;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransPackageWSClient;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransTransactionWSClient;
import ca.gc.ic.cipo.tm.madridconsole.util.WipoTransUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.PackageBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForPkg;
import ca.gc.ic.cipo.tm.mps.GetAttachmentResponse;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.ReferenceCode;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.schema.mps.EventDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageDetail;

/**
 *
 * Service for retrieving data for Wipo Transmissions datatable
 *
 */
@Service
public class WipoTransDataTableService implements IDataTableService {

    private final static Logger LOGGER = Logger.getLogger(WipoTransDataTableService.class);

    @Autowired
    private ServletContext servletContext;

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    @Autowired
    private WipoTransPackageService wipoTransPackageService;

    @Autowired
    private WipoTransTransactionService wipoTransTransactionService;

    @Autowired
    private WipoTransPackageWSClient wipoTransPackageWSClient;

    @Autowired
    private WipoTransTransactionWSClient wipoTransTransactionWSClient;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static String REPRESENTATIVE_COURTESY_LETTER ="COURTESY_LETTER_PDF";

    @Override
    public String getPackageDataTableResponse(HttpServletRequest request, String type, String period, Locale loc,
                                              String status, String startDate, String endDate)
        throws Exception {

        LOGGER.debug("Mehtod: getPackageDataTableResponse");

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        Integer periodId = null;
        if (period != null && period.length() > 0) {
            periodId = Integer.valueOf(period);
        }
        ReturnObjForPkg packageCombine = wipoTransPackageService.getPackageList(type, periodId, loc, status, startDate,
            endDate);
        @SuppressWarnings("unchecked")
        List<PackageBean> packageList = packageCombine.getData2display();

        for (PackageBean taskRow : packageList) {
            JSONArray taskColumn = new JSONArray();

            taskColumn.put(taskRow.getPackageId());
            taskColumn.put(
                messageSource.getMessage(WipoTransUtils.packageType.valueOf(taskRow.getType()).typeMsg(), null, loc));
            taskColumn.put(taskRow.getTransactionDate());
            if (WipoTransUtils.packageType.MADRID_OFFICE_TO_IB.toString().equals(taskRow.getType())) {
                taskColumn.put(taskRow.getNumberOfAttachments());
            } else if ((WipoTransUtils.packageType.MADRID_IRREGULARITY_XML.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.MADRID_IRREGULARITY_PDF.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.MADRID_FINANCE_PACKAGE.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.MADRID_NOTIFICATION_IMG.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.MADRID_NOTIFICATION_PDF.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.MADRID_ACKNOWLEDGE_RECEIPT_XML.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.MADRID_NOTIFICATION_XML.toString().equals(taskRow.getType()))) {
                taskColumn.put(taskRow.getIntlPubId());
                taskColumn.put(taskRow.getIntlPubDate());
            } else if ((WipoTransUtils.packageType.IFMS_FINANCIAL_FEEDBACK.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.ACCOUNTS_RECEIVABLE.toString().equals(taskRow.getType()))
                || (WipoTransUtils.packageType.REVENUE_RECOGNITION.toString().equals(taskRow.getType()))) {
                taskColumn.put(taskRow.getIntlPubId());
                taskColumn.put(taskRow.getIntlPubDate());
            }

            try {
                taskColumn.put(messageSource
                    .getMessage(WipoTransUtils.packageStatus.valueOf(taskRow.getStatus()).statusMsg(), null, loc));
            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Package Status: " + taskRow.getStatus() + ", Package Id: "
                    + taskRow.getPackageId());
                taskColumn.put(taskRow.getStatus());
            }
            taskColumn.put(taskRow.getActions());
            taskList.put(taskColumn);
        }
        try {

            taskResults.put("data", taskList);
        } catch (Exception se) {
            LOGGER.error("Exception Recevied getPackageDataTableResponse(), type: " + type + ", period: " + period
                + ", loc: " + loc + ", status: " + status + ", startDate: " + startDate + ", endDate: " + endDate);
            throw se;
        }

        return taskResults.toString();
    }

    @Override
    public String getBulletinDataTableResponse(String packageId, Locale loc) throws Exception {

        LOGGER.debug("Method: getBulletinDataTableResponse, packageId: " + packageId + ", loc: " + loc);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        List<TransactionDetail> transactionDetailList = wipoTransTransactionService.getTransactionsInfo(packageId);

        LOGGER.debug("Method: getBulletinDataTableResponse, Numb of Transactions: " + transactionDetailList.size());

        for (TransactionDetail transactionDetail : transactionDetailList) {
            JSONArray taskColumn = new JSONArray();

            taskColumn.put(transactionDetail.getTransactionId());

            try {
                ReferenceCode transType = transactionDetail.getTransactionType();

                if (transType == null || transType.getCategory() == null) {
                    LOGGER.error("Recevied an potentially invalid Transation Type for Transaction Id: "
                        + transactionDetail.getTransactionId());
                    taskColumn.put(""); // Show Empty TransactionType for this one, avoiding Exception, which will
                                        // prevent displaying all Valid Transaction as well.
                } else {
                    String transactionCtgry = transType.getCategory();
                    WipoTransUtils.transactionTypeEnum tranCtgryType = WipoTransUtils.transactionTypeEnum
                        .valueOf(transactionCtgry);

                    if (tranCtgryType == null) {
                        LOGGER.error("Recevied an potentially invalid Transation Type: " + transactionCtgry
                            + ", Transaction Id: " + transactionDetail.getTransactionId()
                            + ". TrnasactionType is not know to Console"); // This might happen if Entry not found in
                                                                           // WipoTransUtils.transactionTypeEnum.
                        taskColumn.put(transactionCtgry);
                    } else {
                        String messageKey = tranCtgryType.typeMsg();
                        taskColumn.put(messageSource.getMessage(messageKey, null, loc));
                    }
                }

            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Transation Type: "
                    + transactionDetail.getTransactionType().getCategory() + ", Transaction Id: "
                    + transactionDetail.getTransactionId());
                taskColumn.put(transactionDetail.getTransactionType().getCategory());
            } catch (NoSuchMessageException nsme) {
                LOGGER.error("Unable to find the value for the TransactionType in properties file: "
                    + transactionDetail.getTransactionType().getCategory() + ", Transaction Id: "
                    + transactionDetail.getTransactionId());
                taskColumn.put(transactionDetail.getTransactionType().getCategory());
            }

            taskColumn.put(transactionDetail.getIntlRegistrationNumber());
            if (transactionDetail.getRecordId() != null
                && !transactionDetail.getRecordId().isEmpty()) {
                taskColumn.put(transactionDetail.getRecordId());
            } else {
                taskColumn.put(transactionDetail.getDomesticApplicationNumber());
            }
            try {
                taskColumn.put(messageSource.getMessage(WipoTransUtils.transactionStatusEnum
                    .valueOf(transactionDetail.getCurrentStatus().getCategory()).statusMsg(), null, loc));
            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Transation Status: "
                    + transactionDetail.getCurrentStatus().getCategory() + ", Transaction Id: "
                    + transactionDetail.getTransactionId());
                taskColumn.put(transactionDetail.getCurrentStatus().getCategory());
            }

            taskColumn.put(getNumberOfTransAttachments(transactionDetail.getAttachments()));
            taskColumn.put(dateFormat.format(transactionDetail.getCreatedTimestamp()));

            StringBuilder urlofTransactionXml = new StringBuilder();

            // Add the link to Download the Transaction.
            urlofTransactionXml
                .append("<a class=\"btn btn-xs\" title=\""
                    + messageSource.getMessage("wipotransmissions.icon.download.title", null, loc) + "\"  href='")
                .append(servletContext.getContextPath())
                .append("/transaction/getTransactionContent/" + transactionDetail.getTransactionId()
                    + "'><i class=\" fas fa-download fa-lg\" aria-hidden=\"true\" ></i>" + "</a>");

            // Add the link to the Transaction Detail (i.e., list of Events).
            // urlofTransactionXml.append("<button class=\"btn btn-xs\" style=\"background-color: transparent;\"
            // title=\"" + messageSource.getMessage("wipotransmissions.icon.view.events.title", null, loc) + "\"
            // onclick=getTransactionDetailData(" + transactionDetail.getTransactionId()
            // + ")><i class=\" fa fa-calendar-o fa-lg\" aria-hidden=\"true\" ></i>" + "</button>");

            // Add the link to the Transaction Detail (i.e., list of Attachments).
            if (transactionDetail.getAttachments().size() > 0) {
                urlofTransactionXml
                    .append("<button class=\"btn btn-xs\" style=\"background-color: transparent;\" title=\""
                        + messageSource.getMessage("wipotransmissions.icon.view.attachments.title", null, loc)
                        + "\"  onclick=getTransactionDetailAttachmentData(" + transactionDetail.getTransactionId()
                        + ")><i class=\" fas fa-paperclip fa-lg\" aria-hidden=\"true\" ></i>" + "</button>");
            }

            taskColumn.put(urlofTransactionXml.toString());

            taskList.put(taskColumn);
        }

        taskResults.put("data", taskList);
        return taskResults.toString();
    }

    /**
     * This method is used to obtain Package Detail Event information (i.e., Event List data). A call is made to
     * hagueConsoleSrvice (i.e. Madrid Package Service) to obtain the Package Events. There result is a String
     * (containing a JSON array) of Package Events data, to be display in a datatable.
     *
     * @param packageId - Package Id
     * @param loc - Locale
     * @return String - JSON Array of Package Events in the form of a String
     */
    @Override
    public String getPackageEventsList(String packageId, Locale loc) throws Exception {

        LOGGER.debug("Method: getPackageEventsList packageId: " + packageId + ", loc: " + loc.getLanguage());

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        List<ca.gc.ic.cipo.tm.schema.mps.EventDetail> eventDetailList = wipoTransPackageService
            .getEventsInfo(packageId);

        LOGGER.debug(
            "Method: getPackageEventsList packageId: " + packageId + ", No. of events: " + eventDetailList.size());

        for (EventDetail eventDetail : eventDetailList) {

            JSONArray taskColumn = new JSONArray();

            taskColumn.put(eventDetail.getEventId());
            try {
                taskColumn.put(messageSource.getMessage(
                    WipoTransUtils.eventTypeEnum.valueOf(eventDetail.getEventType().getCategory()).typeMsg(), null,
                    loc));
            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Event Type: " + eventDetail.getEventType().getCategory()
                    + ", Event Id: " + eventDetail.getTransactionId());
                taskColumn.put(eventDetail.getEventType().getCategory());
            }

            if (loc.getLanguage().contains("en")) {
                taskColumn.put(eventDetail.getDescriptionEn());
            } else {
                taskColumn.put(eventDetail.getDescriptionFr());
            }
            taskColumn.put(eventDetail.getComponent());
            taskColumn.put(eventDetail.getProcessedByNode());
            taskColumn.put(dateFormat.format(eventDetail.getCreatedOn()));

            String downloadError = new String();

            // Add the link to the Error Detail.
            if (eventDetail.getEventType().getCategory().equalsIgnoreCase("ERROR")) {
                downloadError = "<button class=\"btn btn-xs\" style=\"background-color: transparent;\"  title=\""
                    + messageSource.getMessage("wipotransmissions.icon.view.error.title", null, loc)
                    + "\"  href=\"#\" onclick=\"getPackageErrorEventData(" + packageId + "," + eventDetail.getEventId()
                    + ")\"><i class=\"fas fa-info-circle fa-lg\" aria-hidden=\"true\" ></i>" + "</button>";
            }
            taskColumn.put(downloadError);

            taskList.put(taskColumn);
        }
        taskResults.put("data", taskList);

        return taskResults.toString();
    }

    /**
     * This method is used to obtain Transaction Detail Event information (i.e., Event List data). A call is made to
     * hagueTransactionService (i.e. Madrid Transaction Service) to obtain the Transaction Events.
     *
     * @param packageId - Package Id
     * @param loc - Locale
     * @return String - JSON Array of Package Events in the form of a String
     */
    // public String getTransactionEventsList(String transId,Locale loc)
    // throws Exception{
    //
    // LOGGER.debug("Method: getTransactionEventsList transid: " + transId + ", loc: " + loc.getLanguage());
    //
    // /* Response will be a String of JSONObject type */
    // JSONObject taskResults = new JSONObject();
    //
    // /* JSON Array to store each row of the data table */
    // JSONArray taskList = new JSONArray();
    //
    // List<EventDetail> eventDetailList = wipoTransTransactionService.getEventsInfo(transId);
    //
    // for (EventDetail eventDetail : eventDetailList) {
    //
    // JSONArray taskColumn = new JSONArray();
    //
    // taskColumn.put(eventDetail.getEventId());
    // try {
    // taskColumn.put(messageSource.getMessage(WipoTransUtils.eventTypeEnum.valueOf(eventDetail.getEventType().getCategory()).typeMsg(),
    // null, loc));
    // } catch (IllegalArgumentException iae) {
    // LOGGER.error("Recevied an potentially invalid Event Type: " + eventDetail.getEventType().getCategory()
    // + ", Event Id: " + eventDetail.getTransactionId());
    // taskColumn.put(eventDetail.getEventType().getCategory());
    // }
    //
    // if (loc.getLanguage().contains("en")) {
    // taskColumn.put(eventDetail.getDescriptionEn());
    // } else {
    // taskColumn.put(eventDetail.getDescriptionFr());
    // }
    // taskColumn.put(eventDetail.getComponent());
    // taskColumn.put(eventDetail.getProcessedByNode());
    // taskColumn.put(dateFormat.format(eventDetail.getCreatedOn()));
    //
    // String downloadError = new String();
    //
    // // Add the link to the Error Detail.
    // if (eventDetail.getEventType().getCategory().equalsIgnoreCase("ERROR")) {
    // downloadError = "<button class=\"btn btn-xs\" style=\"background-color: transparent;\" title=\"" +
    // messageSource.getMessage("wipotransmissions.icon.view.error.title", null, loc) + "\" href=\"#\"
    // onclick=\"getErrorEventlData(" + transId + "," + eventDetail.getEventId() + ")\"><i class=\"fas fa-info-circle
    // fa-lg\" aria-hidden=\"true\" ></i>" + "</button>";
    // }
    // taskColumn.put(downloadError);
    //
    // taskList.put(taskColumn);
    // }
    // taskResults.put("data", taskList);
    //
    // return taskResults.toString();
    // }

    @Override
    public String getFinancialTransactionDetail(long packageId, Locale loc) throws Exception {

        LOGGER.debug("Method: getFinancialTransactionDetail, packageId: " + packageId + ", loc: " + loc);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        try {
            PackageDetail packageDetail = wipoTransPackageWSClient.getPackageBasicInfo(packageId);

            taskResults.put("pkgId", packageDetail.getPackageId());
            taskResults.put("pkgfilename", packageDetail.getIntlPblctnId());
            if (loc.getLanguage().contains("en")) {
                taskResults.put("pkgType", packageDetail.getPackageType().getDescriptionEn());
            } else {
                taskResults.put("pkgType", packageDetail.getPackageType().getDescriptionFr());

            }
            if (packageDetail.getIntlPblctnDt() == null) {
                taskResults.put("pkgPbltnDate", "");

            } else {
                taskResults.put("pkgPbltnDate", dateFormat.format(packageDetail.getIntlPblctnDt()));
            }
            if (packageDetail.getCreatedOn() == null) {
                taskResults.put("pkgTransDate", "");

            } else {
                taskResults.put("pkgTransDate", dateFormat.format(packageDetail.getCreatedOn()));
            }

            try {
                taskResults.put("pkgTransStatus", messageSource.getMessage(
                    WipoTransUtils.packageStatus.valueOf(packageDetail.getCurrentStatus().getCategory()).statusMsg(),
                    null, loc));
            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Package Status: "
                    + packageDetail.getCurrentStatus().getCategory() + ", Package Id: " + packageDetail.getPackageId());
                taskResults.put("pkgTransStatus", packageDetail.getCurrentStatus().getCategory());
            }

            // MADRID_FEE_PKG_GEN_RENCONCILED_OUTPUT
            if (packageDetail.getCurrentStatus().getCategory().equals("MADRID_FEE_PKG_GEN_RENCONCILED_OUTPUT")) {

                String urlofimport = null;
                urlofimport = servletContext.getContextPath() + "/package/getPackageFile/" + packageId;
                taskResults.put("urlofimport", urlofimport.toString());

            }
            // MADRID_FEE_PKG_GAP_PDF_REPORT or
            // MADRID_FEE_PKG_GAP_XSL_REPORT
            List<ca.gc.ic.cipo.tm.schema.mps.AttachmentDetail> attachmentDetaillList = packageDetail.getAttachments();

            for (ca.gc.ic.cipo.tm.schema.mps.AttachmentDetail attachmentDetail : attachmentDetaillList) {
                if (attachmentDetail.getAttachmentType().getCategory().equals("MADRID_FEE_PKG_GAP_PDF_REPORT")) {
                    String urlofgappdf = null;
                    urlofgappdf = servletContext.getContextPath() + "/transaction/getReport/"
                        + attachmentDetail.getId();
                    taskResults.put("urlofgappdf", urlofgappdf.toString());

                }
                if (attachmentDetail.getAttachmentType().getCategory().equals("MADRID_FEE_PKG_GAP_XSL_REPORT")) {
                    String urlofgapxsl = null;
                    urlofgapxsl = servletContext.getContextPath() + "/transaction/getReport/"
                        + attachmentDetail.getId();
                    taskResults.put("urlofgapxsl", urlofgapxsl.toString());
                }
            }

        } catch (Exception se) {
            LOGGER
                .error("Exception Recevied getFinancialTransactionDetail(), packageId: " + packageId + ", loc: " + loc);
            throw se;
        }

        return taskResults.toString();
    }

    @Override
    public PackageDetail getPackageFile(Long packageId) throws Exception {
        return wipoTransPackageWSClient.getPackageFile(packageId);
    }

    @Override
    public String getPackageDetail(Long packageId, Locale loc) throws Exception {

        LOGGER.debug("Method: getPackageDetail, packageId: " + packageId + ", loc: " + loc);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        PackageDetail packageDetail = wipoTransPackageWSClient.getPackageBasicInfo(packageId);

        try {

            taskResults.put("pkgId", packageDetail.getPackageId());
            taskResults.put("pkgfilename", packageDetail.getIntlPblctnId());
            taskResults.put("pkgType", messageSource.getMessage(
                WipoTransUtils.packageType.valueOf(packageDetail.getPackageType().getCategory()).typeMsg(), null, loc));
            if (packageDetail.getIntlPblctnDt() == null) {
                taskResults.put("pkgPbltnDate", "");
            } else {
                taskResults.put("pkgPbltnDate", dateFormat.format(packageDetail.getIntlPblctnDt()));
            }
            if (packageDetail.getCreatedOn() == null) {
                taskResults.put("pkgTransDate", "");
            } else {
                taskResults.put("pkgTransDate", dateFormat.format(packageDetail.getCreatedOn()));
            }
            taskResults.put("pkgTransStatus",
                messageSource.getMessage(
                    WipoTransUtils.packageStatus.valueOf(packageDetail.getCurrentStatus().getCategory()).statusMsg(),
                    null, loc));

        } catch (JSONException e) {
            LOGGER.error("Exception Recevied getPackageDetail(), packageId: " + packageId + ", loc: " + loc);
            throw e;
        }

        return taskResults.toString();
    }

    @Override
    public String getTransactionDetail(Long transid, Locale loc) throws Exception {

        LOGGER.debug("Method: getTransactionDetail, transid: " + transid + ", loc: " + loc);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        TransactionDetail transactionDetail = wipoTransTransactionWSClient.getTransactionDetail(transid);

        taskResults.put("transid", transactionDetail.getTransactionId());
        try {
            try {
                taskResults.put("transType", messageSource.getMessage(WipoTransUtils.transactionTypeEnum
                    .valueOf(transactionDetail.getTransactionType().getCategory()).typeMsg(), null, loc));
            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Transation Type: "
                    + transactionDetail.getTransactionType().getCategory() + ", Transaction Id: "
                    + transactionDetail.getTransactionId());
                taskResults.put("transType", transactionDetail.getTransactionType().getCategory());
            }

            if (transactionDetail.getCreatedTimestamp() == null) {
                taskResults.put("transCreateDate", "");
            } else {
                taskResults.put("transCreateDate", dateFormat.format(transactionDetail.getCreatedTimestamp()));
            }
            if (transactionDetail.getUpdatedTimestamp() == null) {
                taskResults.put("transUpdatedDate", "");
            } else {
                taskResults.put("transUpdatedDate", dateFormat.format(transactionDetail.getUpdatedTimestamp()));
            }
            taskResults.put("transrnumber", transactionDetail.getIntlRegistrationNumber());
            if (transactionDetail.getRecordId() != null
                && !transactionDetail.getRecordId().isEmpty()) {
                taskResults.put("transrecordid", transactionDetail.getRecordId());
            } else {
                taskResults.put("transDomesticApplNumb", transactionDetail.getDomesticApplicationNumber());
            }
            try {
                taskResults.put("transstatus", messageSource.getMessage(WipoTransUtils.transactionStatusEnum
                    .valueOf(transactionDetail.getCurrentStatus().getCategory()).statusMsg(), null, loc));
            } catch (IllegalArgumentException iae) {
                LOGGER.error("Recevied an potentially invalid Transation Status: "
                    + transactionDetail.getCurrentStatus().getCategory() + ", Transaction Id: "
                    + transactionDetail.getTransactionId());
                taskResults.put("transstatus", transactionDetail.getCurrentStatus().getCategory());
            }
        } catch (Exception se) {
            LOGGER.error("Exception Recevied getTransactionDetail(), transid: " + transid + ", loc: " + loc);
            throw se;
        }

        return taskResults.toString();

    }

    @Override
    public String getTransactionAttachments(Long transid, Locale loc) throws Exception {

        LOGGER.debug("Method: getTransactionAttachments, transid: " + transid + ", loc: " + loc);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        TransactionDetail transactionDetail = wipoTransTransactionWSClient.getTransactionDetail(transid);

        LOGGER.debug(
            "Method: getTransactionAttachments, Numb of attachements: " + transactionDetail.getAttachments().size());

        try {
            for (AttachmentDetail attachmentDetail : transactionDetail.getAttachments()) {

                // EXCLUDE Courtesy Letters.
                if (!attachmentDetail.getAttachmentType().getCategory().equals(REPRESENTATIVE_COURTESY_LETTER)) {
                    JSONArray taskColumn = new JSONArray();

                    taskColumn.put(attachmentDetail.getId());
                    if (loc.getLanguage().contains("en")) {
                        taskColumn.put(attachmentDetail.getAttachmentType().getDescriptionEn());
                    } else {
                        taskColumn.put(attachmentDetail.getAttachmentType().getDescriptionFr());
                    }
                    taskColumn.put(attachmentDetail.getFileFormatType().getCategory());
                    taskColumn.put(attachmentDetail.getFileName());
                    if (attachmentDetail.getCreatedOn() == null) {
                        taskColumn.put("");
                    } else {
                        taskColumn.put(dateFormat.format(attachmentDetail.getCreatedOn()));
                    }
                    StringBuffer downloadAttachment = new StringBuffer();
                    downloadAttachment
                        .append("<a class=\"btn btn-xs\" title=\""
                            + messageSource.getMessage("wipotransmissions.icon.download.title", null, loc) + "\"  href='")
                        .append(servletContext.getContextPath())
                        .append("/transaction/getTransactionAttachmentContent/" + attachmentDetail.getId()
                            + "'><i class=\" fas fa-download fa-lg\" aria-hidden=\"true\" ></i>" + "</a>");
                    taskColumn.put(downloadAttachment);

                    taskList.put(taskColumn);
                }
            }
            taskResults.put("data", taskList);
        } catch (Exception ex) {
            LOGGER.error("Exception Recevied getTransactionAttachments(), transid: " + transid + ", loc: " + loc);
            throw ex;
        }
        return taskResults.toString();

    }

    @Override
    public String getPackageAttachments(Long packageid, Locale loc) throws Exception {

        LOGGER.debug("Method: getPackageAttachments, packageid: " + packageid + ", loc: " + loc);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        /* JSON Array to store each row of the data table */
        JSONArray taskList = new JSONArray();

        PackageDetail packageDetail = wipoTransPackageWSClient.getPackageInfo(packageid);

        try {
            for (ca.gc.ic.cipo.tm.schema.mps.AttachmentDetail attachmentDetail : packageDetail.getAttachments()) {
                JSONArray taskColumn = new JSONArray();
                taskColumn.put(attachmentDetail.getId());
                if (loc.getLanguage().contains("en")) {
                    taskColumn.put(attachmentDetail.getAttachmentType().getDescriptionEn());
                } else {
                    taskColumn.put(attachmentDetail.getAttachmentType().getDescriptionFr());
                }
                taskColumn.put(attachmentDetail.getFileFormatType().getCategory());
                taskColumn.put(attachmentDetail.getFileName());
                if (attachmentDetail.getCreatedOn() == null) {
                    taskColumn.put("");
                } else {
                    taskColumn.put(dateFormat.format(attachmentDetail.getCreatedOn()));
                }
                StringBuffer downloadAttachment = new StringBuffer();
                downloadAttachment
                    .append("<a class=\"btn btn-xs\" title=\""
                        + messageSource.getMessage("wipotransmissions.icon.download.title", null, loc) + "\"  href='")
                    .append(servletContext.getContextPath()).append("/transaction/getReport/" + attachmentDetail.getId()
                        + "'><i class=\" fas fa-download fa-lg\" aria-hidden=\"true\" ></i>" + "</a>");
                taskColumn.put(downloadAttachment);

                taskList.put(taskColumn);

            }
            taskResults.put("data", taskList);
        } catch (Exception ex) {
            LOGGER.error("Exception Recevied getPackageDetail(), packageid: " + packageid + ", loc: " + loc);
            throw ex;
        }
        return taskResults.toString();

    }

    @Override
    public TransactionDetail getXML(Long transactionid) throws Exception {

        return wipoTransTransactionWSClient.getXML(transactionid);
    }

    @Override
    public AttachmentDetail getAttachment(Long attachmentid) throws Exception {

        LOGGER.debug("Method: getAttachment, attachmentid: " + attachmentid);

        return wipoTransTransactionWSClient.getAttachment(attachmentid);
    }

    /**
     * This method is to obtain, Package Event Additional Information, that will be displayed in a Modal Pop-up. A call
     * is made to WipoTransTransactionWSClient to call the Service (MPS), to obtain a list of Events for the Package Id.
     * Given the list of Events, loop through the list, to find the event Id that as passed in. Return the Additional
     * information for that Package Event.
     *
     * @param packageId Package Id
     * @param eventId Event Id
     * @return String Additional Information for the Package Event
     * @exception Exception
     */
    @Override
    public String getPackageEventDetailData(Long packageId, Long eventId) throws Exception {

        LOGGER.debug("Method: getPackageEventDetailData, packageId: " + packageId + ", eventId: " + eventId);

        /* Response will be a String of JSONObject type */
        JSONObject taskResults = new JSONObject();

        List<ca.gc.ic.cipo.tm.schema.mps.EventDetail> eventDetailList = wipoTransPackageService
            .getEventsInfo(Long.toString(packageId));

        for (ca.gc.ic.cipo.tm.schema.mps.EventDetail eventDetail : eventDetailList) {

            if (eventDetail.getEventId().longValue() == eventId) {
                taskResults.put("additionalInfo", eventDetail.getAdditionalInfo());
            }
        }
        return taskResults.toString();
    }
    // public String getEventErrorData(Long transId, Long eventId) throws Exception {
    //
    // /* Response will be a String of JSONObject type */
    // JSONObject taskResults = new JSONObject();
    //
    // List<EventDetail> eventDetailList = wipoTransTransactionService.getEventsInfo(Long.toString(transId));
    //
    // for (EventDetail eventDetail : eventDetailList) {
    //
    // if (eventDetail.getEventId().longValue() == eventId) {
    // taskResults.put("additionalInfo", eventDetail.getAdditionalInfo());
    // }
    // }
    // return taskResults.toString();
    // }

    /**
     * This method is used to obtain and download a PACKAGE attachment (based on an Attachment ID).
     *
     * @param attachmentId Attachment ID
     * @return GetAttachmentResponse The Attachment Response
     */
    @Override
    public GetAttachmentResponse getPackageAttachment(Long attachmentid) throws Exception {

        LOGGER.debug("Method: getPackageAttachment, attachmentid: " + attachmentid);

        return wipoTransPackageWSClient.getAttachment(attachmentid);
    }


    /**
     * This method is used to determine (i.e., count) the number of attachments, for a Transaction.
     * NOTE: This method will EXCLUDE Courtesy Letters.  (i.e., when Category NOT Equal REPRESENTATIVE_COURTESY_LETTER)
     *
     * @param List<AttachmentDetail>
     * @return int - number of attachments.
     */
    public int getNumberOfTransAttachments(List<AttachmentDetail> attachmentDetailList) throws Exception {

        LOGGER.debug("Method:getNumberOfTransAttachments" );

        int attachmentCnt = 0;
        int i = 0;
        while (i < attachmentDetailList.size()) {
             AttachmentDetail attachmentDetail = attachmentDetailList.get(i);
            if (!attachmentDetail.getAttachmentType().getCategory().equals(REPRESENTATIVE_COURTESY_LETTER)) {
                attachmentCnt++;
            }
            i++;
        }

        return attachmentCnt;
    }
}
