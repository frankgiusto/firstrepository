package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.TaskDetailInfoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.madridconsole.web.validator.ProcessIRTransformationValidator;
import ca.gc.ic.cipo.tm.tirs.common.CIPOServiceFault;
import ca.gc.ised.cipo.tm.mwe.ForwardTaskStatusType;

@Controller
@SessionAttributes("wipogs")
public class ProcessIRTransformationController {

    private static Logger logger = Logger.getLogger(ProcessIRTransformationController.class.getName());

    @Autowired
    private TradMarkApplicationService tmAppService;

    @Autowired
    private WorkflowEngineServiceClient mweClient;

    @Autowired
    private UserProfileServiceClient userProfileService;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    // IRRegularity Action Types
    public static final String IRREGULARITY_RESPONSE = "irregualrityResponse";

    public static final String IRREGULARITY_ACKNOWLEDGE = "irregualrityAcknowledge";

    public static final String IRREGULARITY_CORRECT = "irregualrityCorrect";

    // Workflow Engine IRRegularity ForwardTaskStatusType
    public static final String IRREG_NO_RESPONSE = "IRREG_NO_RESPONSE";

    public static final String IRREG_CORRECT_AND_RESPOND = "IRREG_CORRECT_AND_RESPOND";

    /**
     * @param request
     * @return
     */
    @ModelAttribute("taskdetail")
    public TaskDetailInfoBean getTaskDetail(HttpServletRequest request) {
        return new TaskDetailInfoBean();
    }

    /**
     * An irregularity transaction is WIPO’s indication of an error in a transaction originating from CIPO. This screen
     * will allow a user to respond or acknowledge the error. This is the POST, used to setup/obtain information for the
     * IRRegularity Screen
     *
     * @param filenumber - Filenumber (String)
     * @param irNum - International Registration Number
     * @param transIds - List<String>
     * @param GoodServiceWipoBean - ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
     * @param locale
     * @param model
     * @param request - HttpServletRequest
     * @return JSP - (String) JSP
     * @throws ca.gc.ic.cipo.tm.mts.CIPOServiceFault
     * @throws CIPOServiceFault
     */
    @RequestMapping(value = "/processtask/irregularity", method = RequestMethod.POST)
    public String irregularity(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                               @RequestParam(value = "irNum", required = false) String irNum,
                               @RequestParam(value = "transIds", required = false) List<String> transIds,
                               @RequestParam(value = "taskId", required = false) String taskId,
                               @RequestParam(value = "aId", required = false) String actId,
                               @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, Locale locale, Model model,
                               HttpServletRequest request, HttpServletResponse response) {

        logger.debug("/processtask/irregularity  method = RequestMethod.POST,  filenumber: " + fileNumberStr
            + ", transIds.get(0): " + transIds.get(0) + ",irNum: " + irNum);

        int fileNumber = 0;
        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        try {
            ArrayList<String> actIds = new ArrayList<String>();
            actIds.add(actId);

            // DO: File number is not blank
            if (StringUtils.isNotBlank(fileNumberStr)) {
                fileNumber = Integer.parseInt(fileNumberStr);

                // Acquire lock
                transactionServiceClient.acquireLock(gsBean, fileNumber, 0,
                    userProfileService.getLdapUsername(request));

                // assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (Exception e) {
                        logger.error("Exception: ", e);
                    }
                }

                if (gsBean == null) {
                    gsBean = new GoodServiceWipoBean();
                }
                gsBean.clearCache();
                tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                    new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.IRREGULARITY_FORM);

            } else {// OO: File number is blank
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                    } catch (Exception e) {
                        logger.error("Exception: ", e);

                    }
                }
                if (gsBean == null) {
                    gsBean = new GoodServiceWipoBean();
                }
                gsBean.clearCache();

                tmAppService.getGoodServiceFromTransaction(request, gsBean, new BigDecimal(transIds.get(0)),
                    new BigDecimal(taskId), actId, TradMarkApplicationService.IRREGULARITY_FORM);
            }
        } catch (MCServerException e) {
            logger.error("Error Obtaing IRRegularity IR: filenumber: " + fileNumberStr + ", transIds.get(0): "
                + transIds.get(0) + ",irNum: " + irNum);
            logger.error(
                messageSource.getMessage("mc.irregularity.infomsg.error", null, locale) + " - " + e.getMessage());

            // Display "Error" information Message.
            try {
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.irregularity.infomsg.error", null, locale) + " - " + e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        } catch (Throwable e) {
            logger.error("Error Obtaing IRRegularity IR: filenumber: " + fileNumberStr + ", transIds.get(0): "
                + transIds.get(0) + ",irNum: " + irNum);
            logger.error(
                messageSource.getMessage("mc.irregularity.infomsg.error", null, locale) + " - " + e.getMessage());

            // Display "Error" information Message.
            try {
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.irregularity.infomsg.error", null, locale) + " - " + e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        gsBean.setTransactionId(new BigDecimal(transIds.get(0)));
        gsBean.setInternationalRegistrationNumber(irNum);
        return "ptIrregularity";

    }

    /**
     *
     * @param modelMap - ModelMap
     * @param gsBean - GoodServiceWipoBean
     * @param request -HttpServletRequest
     * @return string - "ptIrregularity"
     */
    @RequestMapping(value = "/processtask/irregularity", method = RequestMethod.GET)
    public String prepareSelectPage(final ModelMap modelMap, final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                    HttpServletRequest request) {
        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);
        // populate the model Map as needed
        return "ptIrregularity";
    }

    /**
     * This is the GET, used to submit the IRRegularity information to WIPO. This will be executed when the user changes
     * or switches Language  (i.e., English to French and visa-versa)
     *
     * @param gsBean - GoodServiceWipoBean
     * @param errors - BindingResult
     * @param locale - Locale
     * @param session - HttpSession
     * @param request -HttpServletRequest
     * @param redirectAttributes - RedirectAttributes
     * @return String - JSP
     */
    @RequestMapping(value = "/processtask/irregularity/submit", method = RequestMethod.GET)
    public String irregularitySubmitGet(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     Locale locale, final ModelMap modelMap,Model model, HttpSession session, HttpServletRequest request,
                                     RedirectAttributes redirectAttributes) {
        modelMap.addAttribute("wipogs", gsBean);
        // populate the model Map as needed
        return "ptIrregularity";
    }

    /**
     * This is the POST, used to submit the IRRegularity information to WIPO. First it will validate the Information
     * (i.e., check if the comments have been provided. THe Submit the information to WIPO, and then Call Workflow
     * Engine to Complete Task.
     *
     * @param gsBean - GoodServiceWipoBean
     * @param errors - BindingResult
     * @param locale - Locale
     * @param session - HttpSession
     * @param request -HttpServletRequest
     * @param redirectAttributes - RedirectAttributes
     * @return String - JSP
     */
    @RequestMapping(value = "/processtask/irregularity/submit", method = RequestMethod.POST)
    public String irregularitySubmit(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     Locale locale, Model model, HttpSession session, HttpServletRequest request,
                                     RedirectAttributes redirectAttributes) {

        logger.debug("/processtask/irregularity/submit " + gsBean.getIrregularityDetail().toString());

        String viewName = "ptIrregularity";
        MessageSource messageSource = null;

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(actionVal)) {
            try {
                WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
                messageSource = (MessageSource) webAppContext.getBean("messageSource");

                // Perform validation
                ProcessIRTransformationValidator validator = new ProcessIRTransformationValidator();
                validator.validateIRRegularity(gsBean, errors, gsBean.getIrregularityDetail().getIrregularityAction());
                if (errors.hasErrors()) {
                    model.addAttribute("errors", errors);
                    return "ptIrregularity";
                }

                // Process (i.e., submit) the IRRegularity Response to MTS. However, only submit if the IRRegularity
                // action type is RREGULARITY_RESPONSE (i.e., Send irregularity response ), do NOT submit to MTS if the
                // IRRegularity Action Type is irregualrityAcknowledge or correctIrregularity.
                if (gsBean.getIrregularityDetail().getIrregularityAction().equalsIgnoreCase(IRREGULARITY_RESPONSE)) {
                    tmAppService.submitIRRegularity(gsBean, userProfileService.getAuthorityId(request));
                } else if (gsBean != null && gsBean.getApplication() != null
                    && gsBean.getApplication().getApplicationNumber() != null) { // call MTS to update mail flag prior
                                                                                 // to closing Irregularities manual
                                                                                 // task
                    tmAppService.submitUpdateMailProcStatusIRRegularity(gsBean,
                        userProfileService.getAuthorityId(request));
                }

                // Call workflow to complete task - Passing to the workflow the ForwardTaskStatusType (a indicator
                // indicating if Workflow should resend the message to WIPO.
                ForwardTaskStatusType strForwardTaskStatusType = null;
                if (gsBean.getIrregularityDetail().getIrregularityAction().equalsIgnoreCase(IRREGULARITY_CORRECT)) {
                    strForwardTaskStatusType = ForwardTaskStatusType.IRREG_CORRECT_AND_RESPOND; // Correct Irregularity
                                                                                                // and resend
                } else {
                    strForwardTaskStatusType = ForwardTaskStatusType.IRREG_NO_RESPONSE; // Acknowledge - No response to
                                                                                        // send
                }
                mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request),
                    strForwardTaskStatusType, userProfileService.getAuthorityId(request));

                // Assuming no Exception was thrown...Display "SUCCESS" information Message.
                redirectAttributes.addFlashAttribute("infoMsg",
                    messageSource.getMessage("mc.irregularity.infomsg.success", null, locale));

            } catch (MCServerException e) {
                logger.error("Error Submtting IRRegularity IR: " + gsBean.getInternationalRegistrationNumber()
                    + ", File: " + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                    + gsBean.getActivityTaskId());

                // Display "Error" information Message.
                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.irregularity.infomsg.error", null, locale) + " - " + e.getMessage());

            } finally {

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock(gsBean);
                } catch (MCServerException e) {
                    logger.error("/processtask/irregularity/submit, (ACTION NEXT) Errors attempting to release Lock."
                        + e.getMessage());
                }
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(actionVal)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error(
                    "/processtask/irregularity/submit, (CANCEL) Errors attempting to release Lock." + e.getMessage());
            }

        }

        // Assuming everything has been successful, so far, clear out the GoodServiceWipoBean Data.
        session.setAttribute("wipogs", null);

        return viewName;

    }

    /**
     * Corrections are where WIPO has put some information on the International Register (or sent us information
     * incorrectly) and later determined that the information is incorrect and needs to send the corrected information.
     * This is the POST, use to setup information for the IR Correction Screen
     *
     * @param filenumber - Filenumber (String)
     * @param transIds - List<String>
     * @param GoodServiceWipoBean - ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
     * @param locale - Locale
     * @param model
     * @param request - HttpServletRequest
     * @return JSP - (String) JSP
     */
    @RequestMapping(value = "/processtask/ircorrection", method = RequestMethod.POST)
    public String ircorrection(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                               @RequestParam(value = "irNum", required = false) String irNum,
                               @RequestParam(value = "transIds", required = false) List<String> transIds,
                               @RequestParam(value = "taskId", required = false) String taskId,
                               @RequestParam(value = "aId", required = false) String actId,
                               @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, Locale locale, Model model,
                               HttpSession session, HttpServletRequest request, HttpServletResponse response) {

        logger.debug("/processtask/ircorrection  method = RequestMethod.POST ");
        int fileNumber = 0;
        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        try {
            if (fileNumberStr != null) {
                fileNumber = Integer.parseInt(fileNumberStr);

                ArrayList<String> actIds = new ArrayList<String>();
                actIds.add(actId);

                // assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                    } catch (Exception e) {
                        logger.error("Exception: ", e);
                    }
                }

                if (gsBean == null) {
                    gsBean = new GoodServiceWipoBean();
                }
                gsBean.clearCache();
                tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                    new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.IRCORRECTION_FORM);
            }
        } catch (MCServerException e) {
            logger.error("Error Obtaining Correction...filenumber: " + fileNumberStr + ", transIds.get(0): "
                + transIds.get(0) + ", irNum: " + irNum);
            logger.error(
                messageSource.getMessage("mc.ircorrection.infomsg.error", null, locale) + " - " + e.getMessage());

            // Display "Error" information Message.
            try {
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.ircorrection.infomsg.error", null, locale) + " - " + e.getMessage());
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        // Update the Goods and Services Bean
        gsBean.setTransactionId(new BigDecimal(transIds.get(0)));
        gsBean.setInternationalRegistrationNumber(irNum);

        return "ircorrection";

    }

    /**
     *
     * @param modelMap -ModelMap
     * @param gsBean
     * @param request
     * @return JSP - String to ircorrection JSP
     */
    @RequestMapping(value = "/processtask/ircorrection", method = RequestMethod.GET)
    public String prepareIRCorrectionSelectPage(final ModelMap modelMap,
                                                final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                                HttpServletRequest request) {
        // populate the model Map as needed
        modelMap.addAttribute("wipogs", gsBean);

        return "ircorrection";
    }

    /**
     * This is the POST, used to submit the IRCorrection information to WIPO. The information will be submitted to WIPO,
     * and then Call Workflow Engine to Complete Task. Assuming everything works OK, a Success message will be
     * displayed.
     *
     * @param gsBean - ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
     * @param locale -Locale
     * @param model - Model
     * @param session -HttpSession
     * @param request -HttpServletRequest
     * @return String - JSP (string)
     * @throws MCServerException
     */
    @RequestMapping(value = "/processtask/ircorrection/submit", method = RequestMethod.POST)
    public String ircorrectionSubmit(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, Locale locale, Model model,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     HttpSession session, HttpServletRequest request,
                                     RedirectAttributes redirectAttributes)
        throws MCServerException {

        logger.debug("/processtask/ircorrection/submit  method = RequestMethod.POST ");

        String viewName = "";

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(actionVal)) {

            // Parameter resetQuestionResult..... Do you wish to reset the 18 month period?
            // false = NO, true = YES
            String resetQuestionResult = request.getParameter("resetQuestionResult");

            // Submit the Correction Response to WIPO
            tmAppService.submitIRCorrection(gsBean, resetQuestionResult, userProfileService.getAuthorityId(request));

            // Call Workflow Engine to Complete Task
            try {
                mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                // Display "SUCCESS" information Message.
                WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
                MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
                redirectAttributes.addFlashAttribute("infoMsg",
                    messageSource.getMessage("mc.ircorrection.infomsg.success", null, locale));

            } catch (MCServerException e) {
                logger.error("Error from Workflow for IRCorrection. IR: " + gsBean.getInternationalRegistrationNumber()
                    + ", File: " + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                    + gsBean.getActivityTaskId());
                redirectAttributes.addFlashAttribute("errorMsg", "Error completing task " + " - " + e.getMessage());
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(actionVal)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

        }

        // Assuming everything has been successful, clear out the GoodServiceWipoBean Data.
        session.setAttribute("wipogs", null);

        return viewName;

    }

    /**
     * @param request -HttpServletRequest
     * @return GoodServiceWipoBean
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

}
