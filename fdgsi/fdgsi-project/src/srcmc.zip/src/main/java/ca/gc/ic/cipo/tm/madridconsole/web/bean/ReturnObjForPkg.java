package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.util.List;

public class ReturnObjForPkg {

	private List data2display;

	public ReturnObjForPkg( List data2display) {

		this.data2display = data2display;
	}

	public List getData2display() {
		return data2display;
	}

	public void setData2display(List data2display) {
		this.data2display = data2display;
	}

}
