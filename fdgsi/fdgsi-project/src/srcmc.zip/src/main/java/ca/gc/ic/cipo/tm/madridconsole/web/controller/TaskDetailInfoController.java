package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.web.bean.TaskDetailInfoBean;

@Controller
public class TaskDetailInfoController {

    @ModelAttribute("taskdetail")
    public TaskDetailInfoBean getTaskDetail(HttpServletRequest request) {
        return new TaskDetailInfoBean();
    }

    @RequestMapping(value = "/taskdetailinfo", method = RequestMethod.GET)
    public String taskBucket(@RequestParam(value = "taskid", required = false) Integer taskId,
                             @RequestParam(value = "type", required = false) Integer type,
                             @ModelAttribute("taskdetail") TaskDetailInfoBean tdBean, final ModelMap modelMap,
                             Locale locale, Model model, HttpSession session) {
        model.addAttribute("taskdetail", tdBean);
        if (type!=null) {
            if (type.intValue()==1) {
                return "taskdetailManualInfo";
            } else {
                return "taskdetailNotificationInfo";
            }
        } else {
            return "taskdetailManualInfo";
        }
    }

}
