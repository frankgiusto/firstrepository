package ca.gc.ic.cipo.tm.madridconsole.web.validator;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;

public class ProcessIRTransformationValidator  {
    // Log4J logger.
    private final Logger logger = Logger.getLogger(getClass());
    
    public static final String IRREGULARITY_RESPONSE = "irregualrityResponse";
    public static final String ACKNOWLEDGE = "acknowledge";
    
    public void validateIRRegularity (GoodServiceWipoBean goodServiceWipoBean, Errors errors, String irregularityAction) {

        logger.debug("Validate IRRegularity " );      

        // Check if "Release/Note/Comment " has been entered (i.e., it is required!)
        if (irregularityAction.equalsIgnoreCase(IRREGULARITY_RESPONSE) ) {
            if (goodServiceWipoBean.getIrregularityDetail().getIrregularityCommentsInput() == null || goodServiceWipoBean.getIrregularityDetail().getIrregularityCommentsInput().isEmpty()) {
                logger.debug("Validate IRRegularity ERROR, Empty Comment: " + goodServiceWipoBean.getIrregularityDetail().getIrregularityCommentsInput() );      
                errors.rejectValue("irregularityDetail.irregularityCommentsInput", null, "mc.irregularity.error.comments.required");
            }
        }
    }
}
