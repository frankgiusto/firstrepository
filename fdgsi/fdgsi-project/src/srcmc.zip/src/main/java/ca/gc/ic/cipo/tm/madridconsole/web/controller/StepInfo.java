package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class StepInfo implements Serializable {
	protected static final long serialVersionUID = 1L;

	private int numberOfSteps;
	private int currentStep;

	private Map<Integer, String> formNames = new HashMap<Integer, String>();

	/**
	 * @return the currentStep
	 */
	public int getCurrentStep() {
		return currentStep;
	}

	/**
	 * @param currentStep
	 *            the currentStep to set
	 */
	public void setCurrentStep(int currentStep) {
		this.currentStep = currentStep;
	}

	/**
	 * @return the numberOfSteps
	 */
	public int getNumberOfSteps() {
		return numberOfSteps;
	}

	/**
	 * @param numberOfSteps
	 *            the numberOfSteps to set
	 */
	public void setNumberOfSteps(int numberOfSteps) {
		this.numberOfSteps = numberOfSteps;
	}

	/**
	 * @return the formNames
	 */
	public Map<Integer, String> getFormNames() {
		return formNames;
	}

	/**
	 * @param formNames
	 *            the formNames to set
	 */
	public void setFormNames(Map<Integer, String> formNames) {
		this.formNames = formNames;
	}

	/**
	 *
	 * @param stepNo
	 *            the step no to add
	 * @param formName
	 *            the form name to add
	 */
	public void addFormName(Integer stepNo, String formName) {
		formNames.put(stepNo, formName);
	}

}
