package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.service.UserGroupSelectDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

@Controller
@RequestMapping("/taskassign")
public class TaskAssignController {

    /** The logger. */
    private static Logger logger = Logger.getLogger(TaskAssignController.class.getName());

    @Autowired
    private UserGroupSelectDataTableService dataTableService;

    @Value("${mc.ws.common.services.host.name}")
    private String commonServiceHost;

    @RequestMapping(value = "/assign", method = RequestMethod.GET)
    public String taskBucket(Locale locale, Model model, HttpSession session) {

        return "taskUserGroupAssignment";
    }

    @RequestMapping(value = "/userlist", method = {RequestMethod.GET, RequestMethod.POST})
    public void getUsersList(@RequestParam(required = false, defaultValue = "", value = "searchName") String searchName,
                             @RequestParam(required = false, defaultValue = "", value = "group") String group,
                             HttpServletRequest request, HttpServletResponse response) {

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        try {
            PrintWriter out = response.getWriter();
            out.print(dataTableService.getUserDataTableResponse(request, searchName, group));
        } catch (MCServerException | IOException e) {
            try {
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }

    @RequestMapping(value = "/grouplist", method = {RequestMethod.GET, RequestMethod.POST})
    public void getGroupsList(@RequestParam(value = "ids", required = true) List<String> tasklist,
                              HttpServletRequest request, HttpServletResponse response) {

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        try {
            PrintWriter out = response.getWriter();
            out.print(dataTableService.getGroupDataTableResponse(request, tasklist));
        } catch (MCServerException | IOException e) {
            try {
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }
}
