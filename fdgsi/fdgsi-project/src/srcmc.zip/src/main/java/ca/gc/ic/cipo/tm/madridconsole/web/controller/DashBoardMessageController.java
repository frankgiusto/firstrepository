package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.TaskDetailInfoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;

@Controller
public class DashBoardMessageController {

    /** The transaction service. */
    @Autowired
    private TransactionServiceClient transactionService;

    /** The logger. */
    private static Logger logger = Logger.getLogger(DashBoardMessageController.class.getName());

    /**
     * @param request
     * @return
     */
    @ModelAttribute("taskdetail")
    public TaskDetailInfoBean getTaskDetail(HttpServletRequest request) {
        return new TaskDetailInfoBean();
    }

    /**
     * Get the XML message content of the transaction specified with task id (will change to trans id).
     *
     * @param transId the id of the transaction
     * @param tdBean the td bean
     * @param modelMap the model map
     * @param locale the locale
     * @param model the model
     * @param session the session
     * @return the string
     * @throws CIPOServiceFault the CIPO service fault
     */
    @RequestMapping(value = "/messagedetail", method = RequestMethod.GET)
    public String messageDetail(@RequestParam(value = "transid", required = false) BigDecimal transId,
                                @ModelAttribute("taskdetail") TaskDetailInfoBean tdBean, final ModelMap modelMap,
                                Locale locale, Model model, HttpSession session, HttpServletResponse response) {

        logger.debug("Method: messageDetail: transId " + transId);

        String message = "";
        try {
            message = transactionService.getXmlContent(transId, false);

        } catch (MCServerException e) {
            try {
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
        model.addAttribute("message", message);

        return "taskMessageDetail";
    }
    
    /**
     * Get the XML message content of the Original Correction Transaction (based on Record Identifier and IR Number).
     *
     * @param recordIdentifier - Record Identifier
     * @param irNumber - IR Number
     * @param tdBean the td bean
     * @param modelMap the model map
     * @param locale the locale
     * @param model the model
     * @param session the session
     * @return the string
     * @throws CIPOServiceFault the CIPO service fault
     */
    @RequestMapping(value = "messagedetailcorrection", method = RequestMethod.GET)
    public String messageDetailCorrection(@RequestParam(value = "recordIdentifier", required = false) String recordIdentifier,
                                          @RequestParam(value = "irNumber", required = false) String irNumber,
                                @ModelAttribute("taskdetail") TaskDetailInfoBean tdBean, final ModelMap modelMap,
                                Locale locale, Model model, HttpSession session, HttpServletResponse response) {

        logger.debug("Method: messageDetailCorrection: recordIdentifier " + recordIdentifier + ", irNumber " + irNumber);

        String message = "";
        try {
            message = transactionService.getXmlContentOrigCorrection(recordIdentifier, irNumber);

        } catch (MCServerException e) {
            try {
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
        model.addAttribute("message", message);

        return "taskMessageDetail";
    }
    
}
