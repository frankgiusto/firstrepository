package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;

public class LoginFormBean implements Serializable {

    // Serial Version id.
    private static final long serialVersionUID = -2017826429588605660L;

    // User name
    private String username;

    // Password
    private String password;

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

}
