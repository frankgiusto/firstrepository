package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType;

public class BasicMarksByNiceClass {

    private int fileNumber;

    private int extensionCounter;

    private String markStatus;

    private String modifiedDate;

    private GoodsServicesType intrepidGSType;

    public BasicMarksByNiceClass(int fileNumber, int extCounter, GoodsServicesType gsType, String markStatus,
                                 String modifiedDate) {

        this.setFileNumber(fileNumber);
        this.setExtensionCounter(extCounter);
        this.setIntrepidGSType(gsType);
        this.setMarkStatus(markStatus);
        this.setModifiedDate(modifiedDate);
    }

    public int getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(int fileNumber) {
        this.fileNumber = fileNumber;
    }

    public int getExtensionCounter() {
        return extensionCounter;
    }

    public void setExtensionCounter(int extensionCounter) {
        this.extensionCounter = extensionCounter;
    }

    public GoodsServicesType getIntrepidGSType() {
        return intrepidGSType;
    }

    public void setIntrepidGSType(GoodsServicesType intrepidGSType) {
        this.intrepidGSType = intrepidGSType;
    }

    public String getMarkStatus() {
        return markStatus;
    }

    public void setMarkStatus(String markStatus) {
        this.markStatus = markStatus;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}
