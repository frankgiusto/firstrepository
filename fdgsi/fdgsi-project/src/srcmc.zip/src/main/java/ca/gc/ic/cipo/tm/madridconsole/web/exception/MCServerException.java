package ca.gc.ic.cipo.tm.madridconsole.web.exception;

public class MCServerException extends Exception {

    private static final long serialVersionUID = 1L;

    private int errorCode = 0;

    public MCServerException(String errorMessage) {
        super(errorMessage);
    }

    public MCServerException(String errorMessage, int errorCode) {
        super(errorMessage);
        this.errorCode = errorCode;
    }

    public MCServerException(String errorMessage, Exception e) {
        super(errorMessage, e);
    }

    public MCServerException(String errorMessage, Throwable e) {
        super(errorMessage, e);
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }
}
