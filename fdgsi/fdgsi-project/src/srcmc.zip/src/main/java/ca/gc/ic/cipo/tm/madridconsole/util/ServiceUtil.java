package ca.gc.ic.cipo.tm.madridconsole.util;

import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.security.crypto.codec.Base64;

public class ServiceUtil {

    /**
     * @param src
     * @param target
     */
    public static void copyNonNullProperties(Object src, Object target) {
        BeanUtils.copyProperties(src, target, getNullPropertyNames(src));
    }

    public static void copyProperties(Object src, Object target, String[] ignoreProperties) {
        BeanUtils.copyProperties(src, target, ignoreProperties);
    }

    /**
     * @param source
     * @return
     */
    public static Set<String> getNotNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<String>();
        for (java.beans.PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());
            if (srcValue != null) {
                emptyNames.add(pd.getName());
            }
        }
        return emptyNames;
    }

    public static String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<String>();
        for (java.beans.PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());
            if (srcValue == null) {
                emptyNames.add(pd.getName());
            }
        }
        String[] result = new String[emptyNames.size()];
        return emptyNames.toArray(result);
    }

    /**
     * @param myObject
     * @param ignoreProperty
     * @param propertyClass
     */
    public static void setAnyNullOrEmptyToDefault(Object myObject, String ignoreProperty, Class propertyClass) {
        String mystring = " ";
        Long mylong = 0L;
        Integer myNum = 0;

        java.beans.PropertyDescriptor[] descriptors = PropertyUtils.getPropertyDescriptors(myObject);

        for (java.beans.PropertyDescriptor pd : descriptors) {
            if (pd.getPropertyType() == mystring.getClass()) {
                String name = pd.getName();
                String value;

                if (name.equalsIgnoreCase(ignoreProperty) && propertyClass == mystring.getClass()) {
                    continue;
                }
                try {
                    value = (String) PropertyUtils.getProperty(myObject, name);
                    if ((value == null) || (value.isEmpty())) {
                        PropertyUtils.setProperty(myObject, name, mystring);

                    }
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else if (pd.getPropertyType() == mylong.getClass()) {
                String name = pd.getName();

                if (name.equalsIgnoreCase(ignoreProperty) && propertyClass == mylong.getClass()) {
                    continue;
                }

                try {
                    Long value = (Long) PropertyUtils.getProperty(myObject, name);
                    if (value == null) {
                        PropertyUtils.setProperty(myObject, name, mylong);

                    }
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else if (pd.getPropertyType() == myNum.getClass()) {
                String name = pd.getName();

                if (name.equalsIgnoreCase(ignoreProperty) && propertyClass == myNum.getClass()) {
                    continue;
                }
                try {
                    Integer value = (Integer) PropertyUtils.getProperty(myObject, name);
                    if (value == null) {
                        PropertyUtils.setProperty(myObject, name, myNum);

                    }
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }

    }

    /**
     * @param token
     * @return
     */
    public static String base64Encode(String token) {
        byte[] encodedBytes = Base64.encode(token.getBytes());
        return new String(encodedBytes, Charset.forName("UTF-8"));
    }

    /**
     * @param token
     * @return
     */
    public static String base64Decode(String token) {
        byte[] decodedBytes = Base64.decode(token.getBytes());
        return new String(decodedBytes, Charset.forName("UTF-8"));
    }

    /**
     * @param object
     */
    public static void objectToXML(Object object) {
        try {
            JAXBContext jc = JAXBContext.newInstance(String.class, object.getClass());
            JAXBIntrospector introspector = jc.createJAXBIntrospector();
            Marshaller marshaller = jc.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            StringWriter sw = new StringWriter();
            if (null == introspector.getElementName(object)) {
                JAXBElement jaxbElement = new JAXBElement(new QName("ROOT"), Object.class, object);
                marshaller.marshal(jaxbElement, sw);
            } else {
                marshaller.marshal(object, sw);
            }
            String xmlString = sw.toString();
            xmlString = xmlString.replace("\n", "\r\n");
            System.out.println(xmlString);

        } catch (Exception e) {
            System.out.println("Error occurs marshalling the object to XML, message = " + e.getMessage());
        }
    }

    /**
     * @param s
     * @return
     */
    public static String stripCDATA(String s) {
        s = s.trim();
        if (s.startsWith("<![CDATA[")) {
            s = s.substring(9);
            // int i = s.indexOf("]]&gt;");
            int i = s.indexOf("]]>");
            if (i == -1) {
                throw new IllegalStateException("argument starts with <![CDATA[ but cannot find pairing ]]&gt;");
            }
            s = s.substring(0, i);
        }
        return s;
    }

    /**
     * @param statusCategoryId
     * @return 1 if manual task return 2 if notification return 0 others
     */
    public static int checkTaskType(BigDecimal statusCategoryId) {
        int i = statusCategoryId.intValue();

        if (i >= 200 && i < 232) {
            return 1;
        } else if (i > 13 && i < 18) {
            return 2;
        } else {
            return 0;
        }
    }

}
