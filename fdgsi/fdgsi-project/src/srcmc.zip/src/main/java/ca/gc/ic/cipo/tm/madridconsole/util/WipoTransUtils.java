package ca.gc.ic.cipo.tm.madridconsole.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class WipoTransUtils {

    protected static final Logger LOG = LoggerFactory.getLogger(WipoTransUtils.class);

    public enum packageType {
     // @formatter:off
        MADRID_FINANCE_PACKAGE("wipotransmissions.package.type.madrid.finance.package"),
        ACCOUNTS_RECEIVABLE("wipotransmissions.package.type.option.accts.receivable"),
        IFMS_FINANCIAL_FEEDBACK("wipotransmissions.package.type.ifms.financial.feedback"),
        REVENUE_RECOGNITION("wipotransmissions.package.type.revenue.recognition"),
        MADRID_NOTIFICATION_XML("wipotransmissions.package.type.madrid.nofitication"),
        MADRID_NOTIFICATION_IMG("wipotransmissions.package.type.madrid.nofitication"),
        MADRID_NOTIFICATION_PDF("wipotransmissions.package.type.madrid.nofitication"),
        MADRID_IRREGULARITY_XML("wipotransmissions.package.type.madrid.irregularity"),
        MADRID_IRREGULARITY_PDF("wipotransmissions.package.type.madrid.nofitication.pdf"),
        MADRID_ACKNOWLEDGE_RECEIPT_XML("wipotransmissions.package.type.madrid.ack"),
        MADRID_OFFICE_TO_IB("wipotransmissions.package.type.madrid.office.to.id");
     // @formatter:on
        private String typeMsg;

        packageType(String typeMsg) {
            this.typeMsg = typeMsg;
        }

        public String typeMsg() {
            return typeMsg;
        }
    }

    public enum packageStatus {
     // @formatter:off
        MPS_IMPORT_INITIATED("wipotransmissions.package.status.mps.import.initiated"),
        MPS_IMPORT_VALIDATING("wipotransmissions.package.status.mps.import.validating"),
        MPS_IMPORT_VALIDATED("wipotransmissions.package.status.mps.import.validated"),
        MPS_IMPORT_SPLIT_TRANSACTIONS("wipotransmissions.package.status.mps.import.split.transations"),
        MPS_IMPORT_VALIDATION_ERROR("wipotransmissions.package.status.mps.import.validation.error"),
        MPS_IMPORT_COMPLETE("wipotransmissions.package.status.mps.import.complete"),
        MPS_IMPORT_ERROR("wipotransmissions.package.status.mps.import.error"),
        MPS_IMPORT_IMAGES("wipotransmissions.package.status.mps.import.images"),
        ACCOUNTS_RECEIVABLE_VOID("wipotransmissions.package.status.accounts.receivable.void"),
        ACCOUNTS_RECEIVABLE_READY("wipotransmissions.package.status.accounts.receivable.ready"),
        ACCOUNTS_RECEIVABLE_IN_PROGRESS("wipotransmissions.package.status.accounts.receivable.in.progress"),
        ACCOUNTS_RECEIVABLE_SENT("wipotransmissions.package.status.accounts.receivable.sent"),
        ACCOUNTS_RECEIVABLE_FAILED("wipotransmissions.package.status.accounts.receivable.failed"),
        MPS_IMPORT_FEE("wipotransmissions.package.status.mps.import.fee"),
        MPS_EXPORT_COMPLETE("wipotransmissions.package.status.mps.export.complete"),
        MPS_READY_FOR_EXPORT("wipotransmissions.package.status.mps.ready.for.export"),
        MPS_EXPORT_ERROR("wipotransmissions.package.status.mps.export.error"),
        MPS_EXPORT_BUILD_PACKAGE("wipotransmissions.package.status.mps.export.build.package"),
        MPS_EXPORT_VALIDATE_PACKAGE("wipotransmissions.package.status.mps.export.validate.package"),
        MPS_EXPORT_VALIDATION_ERROR("wipotransmissions.package.status.mps.export.validation.error"),
        MPS_EXPORT_PACKAGE_EMPTY("wipotransmissions.package.status.mps.export.empty"),
        REVENUE_RECOGNITION_READY("wipotransmissions.package.status.revenue.recognition.ready"),
        REVENUE_RECOGNITION_IN_PROGRESS("wipotransmissions.package.status.revenue.recognition.in.progress"),
        REVENUE_RECOGNITION_SENT("wipotransmissions.package.status.revenue.recognition.sent"),
        REVENUE_RECOGNITION_FAILED("wipotransmissions.package.status.revenue.recognition.failed"),
        REVENUE_RECOGNITION_VOID("wipotransmissions.package.status.revenue.recognition.void"),
        IB_TO_OFFICE_UNPROCESSED("wipotransmissions.package.status.ib.to.office.unprocessed"),
        IB_TO_OFFICE_PROCESSED("wipotransmissions.package.status.ib.to.office.processed"),
        IB_TO_OFFICE_INPROGRESS("wipotransmissions.package.status.ib.to.office.in.progress"),
        IB_TO_OFFICE_FAILED("wipotransmissions.package.status.ib.to.office.failed"),
        IB_TO_OFFICE_READY_REP_GEN("wipotransmissions.package.status.ib.to.office.ready.rep.gen"),
        MADRID_FEE_PKG_RECONCILED("wipotransmissions.package.status.madrid.fee.pkg.reconciled"),
        MADRID_FEE_PKG_GEN_RENCONCILED_OUTPUT("wipotransmissions.package.status.madrid.fee.pkg.gen.reconciled.output"),
        MADRID_FEE_PKG_RECONCILED_SENT("wipotransmissions.package.status.madrid.fee.pkg.reconciled.sent"),
        MADRID_FEE_PKG_FIN_STATUS_UPDATED("wipotransmissions.package.status.madrid.fee.pkg.status.updated");
     // @formatter:on
        private String statusMsg;

        packageStatus(String statusMsg) {
            this.statusMsg = statusMsg;
        }

        public String statusMsg() {
            return statusMsg;
        }
    }

    public enum transactionStatusEnum {
     // @formatter:off
        PROCESSING("wipotransmissions.transaction.status.processing"),
        PROCESSED("wipotransmissions.transaction.status.processed"),
        PARTIALLY_PROCESSED("wipotransmissions.transaction.status.partially.processed"),
        ON_HOLD("wipotransmissions.transaction.status.on.hold"),
        PROCESSED_WITH_ERROR("wipotransmissions.transaction.status.processed.with.error"),
        ACCOUNTS_RECEIVABLE_READY("wipotransmissions.transaction.status.accounts.receivable.ready"),
        ACCOUNTS_RECEIVABLE_IN_PROGRESS("wipotransmissions.transaction.status.accounts.receivable.in.progress"),
        ACCOUNTS_RECEIVABLE_SENT("wipotransmissions.transaction.status.accounts.receivable.sent"),
        ACCOUNTS_RECEIVABLE_FAILED("wipotransmissions.transaction.status.accounts.receivable.failed"),
        ACCOUNTS_RECEIVABLE_VOID("wipotransmissions.transaction.status.accounts.receivable.void"),
        REVENUE_RECOGNITION_READY("wipotransmissions.transaction.status.revenue.recognition.ready"),
        REVENUE_RECOGNITION_IN_PROGRESS("wipotransmissions.transaction.status.revenue.recognition.in.progress"),
        REVENUE_RECOGNITION_SENT("wipotransmissions.transaction.status.revenue.recognition.sent"),
        REVENUE_RECOGNITION_FAILED("wipotransmissions.transaction.status.revenue.recognition.failed"),
        REVENUE_RECOGNITION_VOID("wipotransmissions.transaction.status.revenue.recognition.void"),
        MADRID_FEE_TRANS_GAP("wipotransmissions.transaction.status.fee.transaction.gap"),
        MADRID_FEE_TRANS_IMPORTED("wipotransmissions.transaction.status.fee.transaction.imported"),
        MADRID_FEE_TRANS_RECONCILED("wipotransmissions.transaction.status.fee.transaction.reconciled"),
        MADRID_FEE_TRANS_IN_PROGRESS("wipotransmissions.transaction.status.fee.transaction.in.progress"),
        MADRID_FEE_TRANS_PAY_CONFIRM_UPDATED("wipotransmissions.transaction.status.fee.transaction.pay.confirm.updated"),
        MADRID_FEE_TRANS_FINANCIAL_UPDATED("wipotransmissions.transaction.status.fee.transaction.financial.updated"),
        MADRID_FEE_TRANS_FAILED("wipotransmissions.transaction.status.fee.transaction.failed"),
        MTS_VOID("wipotransmissions.transaction.status.mts.void"),
        MPS_IMPORT_INITIATED("wipotransmissions.transaction.status.mps.import.initiated"),
        MPS_IMPORT_VALIDATING("wipotransmissions.transaction.status.mps.import.validating"),
        MPS_IMPORT_VALIDATED("wipotransmissions.transaction.status.mps.import.validated"),
        MPS_IMPORT_VALIDATION_ERROR("wipotransmissions.transaction.status.mps.import.validation.error"),
        MPS_IMPORT_SPLIT_TRANSACTIONS("wipotransmissions.transaction.status.mps.import.split.transactions"),
        MPS_IMPORT_FEES("wipotransmissions.transaction.status.mps.import.fees"),
        MPS_IMPORT_IMAGES("wipotransmissions.transaction.status.mps.import.images"),
        MPS_IMPORT_ERROR("wipotransmissions.transaction.status.mps.import.error"),
        MPS_IMPORT_COMPLETE("wipotransmissions.transaction.status.mps.import.complete"),
        MPS_READY_FOR_EXPORT("wipotransmissions.transaction.status.mps.ready.for.export"),
        MPS_EXPORT_BUILD_PACKAGE("wipotransmissions.transaction.status.mps.export.build.package"),
        MPS_EXPORT_VALIDATE_PACKAGE("wipotransmissions.transaction.status.mps.export.validate.package"),
        MPS_EXPORT_COMPLETE("wipotransmissions.transaction.status.mps.export.complete"),
        MPS_UNSUPPORTED_TRANSACTION_CATEGORY("wipotransmissions.transaction.status.mps.unsupport.transaction.category"),
        MPS_EXPORT_ERROR("wipotransmissions.transaction.status.mps.export.error");
     // @formatter:on
        private String statusMsg;

        transactionStatusEnum(String statusMsg) {
            this.statusMsg = statusMsg;
        }

        public String statusMsg() {
            return statusMsg;
        }

    }

    public enum transactionTypeEnum {
     // @formatter:off
        MBR_APPLICATION_CHANGE("wipotransmissions.transaction.type.mbr.application.change"),
        ACCOUNTS_RECEIVABLE("wipotransmissions.transaction.type.accounts.receivable"),
        IFMS_FINANCIAL_FEEDBACK("wipotransmissions.transaction.type.IFMS.financial.feedback"),
        REVENUE_RECOGNITION("wipotransmissions.transaction.type.revenue.recognition"),
        MD_REGISTRATION("wipotransmissions.transaction.type.md.registration"),
        MD_SUBSEQUENT_DESIGNATION("wipotransmissions.transaction.type.md.subsequent.designation"),
        MD_PARTIAL_CHANGE_OF_OWNERSHIP("wipotransmissions.transaction.type.md.partial.change.of.ownership"),
        MD_MERGER("wipotransmissions.transaction.type.md.merger"),
        MR_RENEWAL("wipotransmissions.transaction.type.mr.renewal"),
        MR_COMPLEMENTARY_RENEWAL("wipotransmissions.transaction.type.mr.complementary.renewal"),
        MC_CORRECTION("wipotransmissions.transaction.type.mc.correction"),
        MIR_REGISTRATION("wipotransmissions.transaction.type.mir.registration"),
        MDT_RENUNCIATION("wipotransmissions.transaction.type.mdt.renunciation"),
        MDT_TOTAL_CEASING_OF_EFFECT("wipotransmissions.transaction.type.mdt.total.ceasing.of.effect"),
        MDT_TOTAL_CANCELLATION("wipotransmissions.transaction.type.mdt.total.cancellation"),
        MDT_NON_RENEWAL_OF_TRADEMARK("wipotransmissions.transaction.type.mdt.non.renewal.of.trademark"),
        MDT_NON_RENEWAL_TRADEMARK("wipotransmissions.transaction.type.mdt.non.renewal.of.trademark"),
        MDT_NON_RENEWAL_OF_CONTRACTING_PARTY("wipotransmissions.transaction.type.mdt.non.renewal.of.contracting.party"),
        MDT_PARTIAL_CHANGE_OF_OWNERSHIP("wipotransmissions.transaction.type.mdt.partial.change.of.ownership"),
        MDT_MERGER("wipotransmissions.transaction.type.mdt.merger"),
        MHR_CHANGE_OF_HOLDER_NAME_ADDRESS("wipotransmissions.transaction.type.mhr.change.of.holder.name.address"),
        MHR_CHANGE_OF_OWNER("wipotransmissions.transaction.type.mhr.change.of.owner"),
        MHR_CHANGE_OF_OWNERSHIP("wipotransmissions.transaction.type.mhr.change.of.owner"),
        MPR_PARTIAL_CEASING_OF_EFFECT("wipotransmissions.transaction.type.mpr.partial.ceasing.of.effect"),
        MPR_LIMITATION("wipotransmissions.transaction.type.mpr.limitation"),
        MPR_PARTIAL_CANCELLATION("wipotransmissions.transaction.type.mpr.partial.cancellation"),
        MPR_PARTIAL_CHANGE_OF_OWNERSHIP("wipotransmissions.transaction.type.mpr.partial.change.of.ownership"),
        MI_IRREGULARITY_NOTIFICATION("wipotransmissions.transaction.type.mi.irregularity.notificaiton"),
        MCP_NO_CATEGORY("wipotransmissions.transaction.type.mcp.no.category"),
        INVALID_TRANSACTION_TYPE("wipotransmissions.transaction.type.invalid.transaction.type"),
        MADRID_FEE("wipotransmissions.transaction.type.madrid.fee"),
        MADRID_ABANDONMENT_NOTIFICATION("wipotransmissions.transaction.abandonment"),
        MADRID_PROVISIONAL_REFUSAL_MF3("wipotransmissions.transaction.type.madrid.provisional.refusal.mf3"),
        MADRID_POTENTIAL_CEASING_EFFECT("wipotransmissions.transaction.type.madrid.potential.ceasing.effect"),
        DESIGNATION_TERMINATION("wipotransmissions.transaction.type.madrid.partial.change.ownership.termination"),
        DESIGNATION_PROTECTION_RESTRICTION("wipotransmissions.transaction.type.madrid.partial.change.ownership.prot.restriction"),
        MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF2("wipotransmissions.transaction.type.madrid.possible.opposition.notification.mf2"),
        MADRID_POSSIBLE_OPPOSITION_NOTIFICATION_MF1("wipotransmissions.transaction.type.madrid.possible.opposition.notification.mf1"),
        MADRID_NEW_BASIC_APPLICATION_MERGER_EXT("wipotransmissions.transaction.type.madrid.new.basic.application.merger.ext"),
        MADRID_NEW_BASIC_APPLICATION_MERGER("wipotransmissions.transaction.type.madrid.new.basic.application.merger"),
        MADRID_NEW_BASIC_APPLICATION_DIVISION("wipotransmissions.transaction.type.madrid.new.basic.application.division"),
        MADRID_NATIONAL_REGISTRATION_REPLACEMENT_TOTAL("wipotransmissions.transaction.type.madrid.national.registration.replacement.total"),
        MADRID_NATIONAL_REGISTRATION_REPLACEMENT_PARTIAL("wipotransmissions.transaction.type.madrid.national.registration.replacement.partial"),
        MADRID_INVALIDATION_PARTIAL_MF10("wipotransmissions.transaction.type.madrid.invalidation.partial.mf10"),
        MADRID_INVALIDATION_FULL_MF10("wipotransmissions.transaction.type.madrid.invalidation.full.mf10"),
        MADRID_GRANT_PROTECTION_MF4("wipotransmissions.transaction.type.madrid.grant.protection.mf4"),
        MADRID_FURTHER_DECISION_MF7("wipotransmissions.transaction.type.madrid.further.devision.mf7"),
        MADRID_FINAL_DECISION_MF6("wipotransmissions.transaction.type.madrid.final.decision.mf6"),
        MADRID_FINAL_DECISION_MF5("wipotransmissions.transaction.type.madrid.final.decision.mf5"),
        MADRID_CANCELLATION("wipotransmissions.transaction.type.madrid.cancellation"),
        MADRID_IRREGULARITY_RESPONSE("wipotransmissions.transaction.type.madrid.irregularity.response"),
        MADRID_CORRECTION_REQUEST("wipotransmissions.transaction.type.madrid.correction.request"),
        MADRID_CEASING_EFFECT_TOTAL_MF9("wipotransmissions.transaction.type.madrid.ceasing.effect.total.mf9"),
        MADRID_OO_CEASING_EFFECT_PARTIAL_MANUAL("wipotransmissions.transaction.type.madrid.ceasing.effect.partial.mf9"),
        MADRID_LIMITATION_NO_EFFECT("wipotransmissions.transaction.type.madrid.limitation.no.effect"),
        MADRID_GOODS_SERVICES_LIMITATION_REQUEST("wipotransmissions.transaction.type.madrid.goods.services.limitation.request"),
        MADRID_ACKNOWLEDGE_RECEIPT("wipotransmissions.transaction.type.madrid.ack"),
        MHR_CHANGE_OF_REPRESENTATIVE("wipotransmissions.transaction.type.mhr.change.of.representative"),
        MHR_LIMITATION("wipotransmissions.transaction.type.mhr.limitation"),
        MHR_PARTIAL_CANCELLATION("wipotransmissions.transaction.type.mhr.partial.cancellation"),
        MI_CEASING_OF_EFFECT("wipotransmissions.transaction.type.mi.ceasing.of.effect"),
        MI_DISCLAIMER("wipotransmissions.transaction.type.mi.disclaimer"),
        MI_FINAL_DECISION("wipotransmissions.transaction.type.mi.final.decision"),
        MI_GRANT_OF_PROTECTION("wipotransmissions.transaction.type.mi.grant.of.protection"),
        MI_NOTIFICATION_OF_POSSIBLE_OPPOSITION("wipotransmissions.transaction.type.mi.notification.of.possible.oppostion"),
        MI_PARTIAL_CANCELLATION("wipotransmissions.transaction.type.mi.partial.cancelation"),
        MI_REFUSAL("wipotransmissions.transaction.type.mi.refusal"),
        MI_TOTAL_CANCELLATION("wipotransmissions.transaction.type.mi.total.cancellation"),
        MPR_RESTRICTION_HOLDERS_RIGHT_OF_DISPOSAL("wipotransmissions.transaction.type.mpr.restriction.holders.right.of.disposal");
     // @formatter:on
        private String typeMsg;

        transactionTypeEnum(String typeMsg) {
            this.typeMsg = typeMsg;
        }

        public String typeMsg() {
            return typeMsg;
        }
    }

    public enum eventTypeEnum {
     // @formatter:off
        INFORMATION("wipotransmissions.event.type.information"),
        ERROR("wipotransmissions.event.type.error"),
        WARNING("wipotransmissions.event.type.warning"),
        DEBUG("wipotransmissions.event.type.debug"),
        TRACE("wipotransmissions.event.type.trace");
     // @formatter:on
        private String typeMsg;

        eventTypeEnum(String typeMsg) {
            this.typeMsg = typeMsg;
        }

        public String typeMsg() {
            return typeMsg;
        }
    }
}