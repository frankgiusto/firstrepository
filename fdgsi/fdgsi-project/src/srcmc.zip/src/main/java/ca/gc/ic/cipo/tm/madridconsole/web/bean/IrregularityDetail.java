package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class IrregularityDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    private String irregularityAction;

    private String irregularityCommentsInput;

    private String responseDueDate;

    public String getIrregularityAction() {
        return irregularityAction;
    }

    public void setIrregularityAction(String irregularityAction) {
        this.irregularityAction = irregularityAction;
    }

    public String getIrregularityCommentsInput() {
        return irregularityCommentsInput;
    }

    public void setIrregularityCommentsInput(String irregularityCommentsInput) {
        this.irregularityCommentsInput = irregularityCommentsInput;
    }

    public String getResponseDueDate() {
        return responseDueDate;
    }

    public void setResponseDueDate(String responseDueDate) {
        this.responseDueDate = responseDueDate;
    }

    /**
     * Clear all Irregularity Data. (i.e., set all values to "")
     */
    public void clearData() {
        setIrregularityAction(StringUtils.EMPTY);
        setIrregularityCommentsInput(StringUtils.EMPTY);
        setResponseDueDate(StringUtils.EMPTY);

    }

    @Override
    public String toString() {
        return "IrregularityDetail [irregularityAction=" + irregularityAction + ", irregularityCommentsInput="
            + irregularityCommentsInput + ", responseDueDate=" + responseDueDate + "]";
    }

}
