package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.impl.CitedMarksDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.CitedMarksSearchResponse;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.StatusResponse;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.CustomGenericException;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.madridconsole.web.validator.MF3AValidator;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;
import ca.gc.ic.cipo.tm.mts.TrademarkInfo;

@Controller
@SessionAttributes("wipogs")
public class MF3AContoller {

    private static Logger logger = Logger.getLogger(MF3AContoller.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    /**
     * @param request
     * @return
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    @Autowired
    private TradMarkApplicationService tmAppService;

    @Autowired
    private WorkflowEngineServiceClient mweClient;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    @Autowired
    private UserProfileServiceClient userProfileService;

    @Autowired
    private CitedMarksDataTableService citedMarksDataTableService;

    private static final String FILE_NUMB_EXT_REGEX = "[0-9]+\\([0-9]+\\)";

    private static final Pattern FILE_NUMB_EXT_PATTERN = Pattern.compile(FILE_NUMB_EXT_REGEX);

    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * POST (i.e. Get) Request - for MF3A. Obtain the values for the pre-populated fields on the form.
     *
     * @param filenumber - File Number
     * @param transIds - Transaction Id,
     * @param taskId - Task Id,
     * @param aId -
     * @param Type
     * @param wipogs - GoodServiceWipoBean
     * @return string - JSP
     * @throws IOException
     * @throws MCServerException
     *
     */
    @SuppressWarnings("unused")
    @RequestMapping(value = "/processtask/MF3A", method = RequestMethod.POST)
    public String obtainMF3A(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                             @RequestParam(value = "transIds", required = false) List<String> transIds,
                             @RequestParam(value = "irNum", required = false) String irNum,
                             @RequestParam(value = "taskId", required = false) String taskId,
                             @RequestParam(value = "aId", required = false) String actId,
                             @RequestParam(value = "type", required = false) String type,
                             @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                             final ModelMap modelMap, HttpServletRequest request, Locale locale, HttpSession session,
                             HttpServletResponse response)
        throws IOException {

        logger.debug("/processtask/MF3A  method = RequestMethod.POST, filenumber: " + fileNumberStr + ", transIds: "
            + transIds.get(0) + ", task: " + taskId + ", transIds: " + transIds);

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        int fileNumber = Integer.parseInt(fileNumberStr);
        ArrayList<String> actIds = new ArrayList<String>();
        actIds.add(actId);

        try {
            // Acquire lock
            transactionServiceClient.acquireLock( gsBean, fileNumber, 0, userProfileService.getLdapUsername(request));

            // assign task to the user first, if its already been assigned we should not proceed
            // and let the user know that he should refresh page.
            if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                userProfileService.getParentId(request)) > 0) {
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));

                    // Release the LOCK on the File Number/Extension
                    try {
                        transactionServiceClient.releaseLock( gsBean);
                    } catch (MCServerException e) {
                        logger.error("/processtask/MF3A, Errors attempting to release Lock." + e.getMessage() );
                    }

                } catch (IOException e) {
                    logger.error("Exception: ", e);
                }
            }

        } catch (MCServerException e) {
            logger.error("obtainMF3A(), Received Exception", e);

            try {
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.mf3a.infomsg.error", null, locale) + " - " + e.getMessage());

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock(gsBean);
                } catch (MCServerException ex) {
                    logger.error("/processtask/MF3A, Errors attempting to release Lock." + ex.getMessage() );
                }
                return "MF3A";
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }  catch (Throwable e) {
            logger.error("Method: obtainMF3A: File: " + fileNumberStr + ", Task ID: " + taskId
                + ", actId " + actId + ", type " + type + ", transIds " + transIds + "Error assigning task to current user "
                + userProfileService.getParentId(request)
                + " due to Throwable - " + e.getMessage(), e);

            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("mc.error.mts.gettransaction"));
                transactionServiceClient.releaseLock(gsBean);
                return "MF3A";
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        if (gsBean == null) {
            gsBean = new GoodServiceWipoBean();
        }
        gsBean.clearCache();

        try {
            tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.MF3A_FORM);

        } catch (MCServerException e) {

            try {
                logger.error("/processtask/MF3A  method = RequestMethod.POST,  "
                     + taskId + " activity task - " + actId
                     + " Exception: " + e.getMessage());

                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.mf3a.infomsg.error", null, locale) + " - " + e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
                return "redirect:" + session.getAttribute("refererPage");
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
                }

            }

        // Obtain the MF3A data, to be displayed.
        try {
            tmAppService.obtainMF3A(request, gsBean, taskId, transIds.get(0));
        } catch (MCServerException e) {

            try {
                logger.error("/processtask/MF3A RequestMethod.POST, task: " + taskId + " activity task: " + actId
                    + " error: " + e.getMessage());
                response.sendError(HttpServletResponse.SC_OK,
                    messageSource.getMessage("mc.mf3a.infomsg.error", null, locale) + " - " + e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
                return "redirect:" + session.getAttribute("refererPage");
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        // Make sure there is at least 1 cited mark.
        if (gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
            .getGroundsOfOppositionList().getGroundsOfOppositionListBag().size() == 0) {
            GroundsOfOpposition groundsOfOppostion = new GroundsOfOpposition();
            gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                .getGroundsOfOppositionList().getGroundsOfOppositionListBag().add(groundsOfOppostion);
        }

        gsBean.setTaskId(new BigDecimal(taskId));
        gsBean.setInternationalRegistrationNumber(irNum);

        return "MF3A";
    }

    /**
     * @param modelMap
     * @param gsBean
     * @param request
     * @return
     */
    @RequestMapping(value = "/processtask/MF3A", method = RequestMethod.GET)
    public String prepareMF3ASubmitPage(final ModelMap modelMap,
                                        final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                        HttpServletRequest request, final RedirectAttributes redirectAttributes,
                                        HttpSession session) {
        // put your initial command
        modelMap.addAttribute("wipogs", gsBean); // populate the model Map as needed

        if (redirectAttributes.getFlashAttributes().containsKey("errorMsg")) {
            return "redirect:" + session.getAttribute("refererPage");
        }
        // populate the model Map as needed
        return "MF3A";
    }

    /**
     * Post Request - for MF3A. Validate (and assuming it passes validation) submit it to WIPO via the MTS.
     *
     * @param wipogs - GoodServiceWipoBean
     * @param errors - BindingResult
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/MF3A/submit", method = RequestMethod.POST)
    public String gsSelectsubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                     @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                     Locale locale, ModelMap model, final HttpServletRequest request,
                                     final HttpServletResponse response, HttpSession session,
                                     final RedirectAttributes redirectAttributes)
        throws IllegalStateException, IOException, CIPOServiceFault {

        logger.debug("/processtask/MF3A/submit RequestMethod.POST");

        String viewName = "ptDOGoodandService";

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(actionVal)) {
            // Perform validation
            MF3AValidator validator = new MF3AValidator();
            validator.validate(gsBean, errors);
            if (errors.hasErrors()) {
                model.addAttribute("errors", errors);
                return "MF3A";
            }

            try {

                // Remove any "EMPTY" Cited Marks
                Iterator<GroundsOfOpposition> i = gsBean.getMf3a().getMf3aRequest().getManualReportForm()
                    .getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag()
                    .iterator();
                while (i.hasNext()) {
                    GroundsOfOpposition groundsOfOppostion = i.next();
                    if (checkIfGroundsOfOppositionEmpty(groundsOfOppostion)) {
                        i.remove();
                    }
                }

                // Make sure there is at least 1 cited mark.
                if (gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                    .getGroundsOfOppositionList().getGroundsOfOppositionListBag().size() == 0) {
                    GroundsOfOpposition groundsOfOppostion = new GroundsOfOpposition();
                    gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                        .getGroundsOfOppositionList().getGroundsOfOppositionListBag().add(groundsOfOppostion);
                }

                // Process the MF3A (i.e., submit it to WIPO)
                tmAppService.processMF3A(request, gsBean);

                // Call Workflow Engine to Complete Task
                try {
                    mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));
                } catch (MCServerException e) {

                    redirectAttributes.addFlashAttribute("errorMsg", e.getMessage());
                }

                // Send Success Message to the User
                redirectAttributes.addFlashAttribute("infoMsg",
                    messageSource.getMessage("mc.mf3a.infomsg.success", null, locale));

            } catch (MCServerException e) {
                logger.error("/processtask/MF3A/submit RequestMethod.POST, MCServerException recevied.");
                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.mf3a.infomsg.error", null, locale) + " - " + e.getMessage());
            } finally {

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock( gsBean);
                } catch (MCServerException e) {
                    logger.error("/processtask/MF3A/submit, (ACTION NEXT) Errors attempting to release Lock." + e.getMessage() );                }
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(actionVal)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/MF3A/submit, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }

        }

        // Assuming everything has been successful, so far, clear out the GoodServiceWipoBean Data.
        session.setAttribute("wipogs", null);

        return viewName;

    }

    @RequestMapping(value = "/obtainCitedMarks", method = RequestMethod.GET)
    public void loadCitedMarks(@RequestParam(value = "addAnotherMark", required = false) Boolean addAnotherMark,
                               @RequestParam(value = "removeCitedMark", required = false) String removeCitedMark,
                               HttpServletRequest request, HttpServletResponse response, final ModelMap modelMap) {

        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");

        GoodServiceWipoBean gsBean = (GoodServiceWipoBean) modelMap.get("wipogs");

        // Add Another Cited Mark
        if (addAnotherMark) {
            GroundsOfOpposition groundsOfOppostion = new GroundsOfOpposition();

            gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                .getGroundsOfOppositionList().getGroundsOfOppositionListBag().add(groundsOfOppostion);
        }

        // Remove a Cited Mark
        if ((removeCitedMark != null) && (Integer.parseInt(removeCitedMark) != 0)) {

            // Remove the item (Cited Mark)
            gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                .getGroundsOfOppositionList().getGroundsOfOppositionListBag()
                .remove(Integer.parseInt(removeCitedMark) - 1);

            // Make sure there is at least 1 cited mark.
            if (gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                .getGroundsOfOppositionList().getGroundsOfOppositionListBag().size() == 0) {
                GroundsOfOpposition groundsOfOppostion = new GroundsOfOpposition();
                gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                    .getGroundsOfOppositionList().getGroundsOfOppositionListBag().add(groundsOfOppostion);
            }

        }

        // Reload the Cited Mark Table.
        PrintWriter out;
        String citedMarksdata = null;
        try {
            out = response.getWriter();
            citedMarksdata = citedMarksDataTableService.generateCitedMarks(gsBean);

            if (citedMarksdata != null) {
                out.print(citedMarksdata);
            }
        } catch (Exception se) {
            logger.warn("Madird Console runtime exception. check the data", se);
            throw new CustomGenericException("code1", "serviceerror");
        }

        modelMap.addAttribute("wipogs", gsBean);

    }

    /**
     * Update a Cited Marks.  In previous version of the code, the user was able to update all of the fields.
     *  However, currently the users can only update the field "listofGoodsAndServices'.  That is why the is a
     *  case statement for just a single field.
     *
     * @param strField - The field name to be update
     * @param strIncr - THe Cited Mark Number (increment) being updated
     * @param strValue - THe New value for strField
     *
     */
    @RequestMapping(value = "/updateCitedMarks", method = RequestMethod.POST)
    public void updateCitedMarks(@RequestParam(value = "strField", required = false) String strField,
                                 @RequestParam(value = "strIncr", required = false) String strIncr,
                                 @RequestParam(value = "strValue", required = false) String strValue,
                                 HttpServletRequest request, HttpServletResponse response, final ModelMap modelMap)
        throws ParseException, IOException {

        GoodServiceWipoBean gsBean = (GoodServiceWipoBean) modelMap.get("wipogs");
        GroundsOfOpposition groundsOfOppostion = new GroundsOfOpposition();

        groundsOfOppostion = gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
            .getGroundsOfOppositionList().getGroundsOfOppositionListBag().get(Integer.parseInt(strIncr) - 1);

        TrademarkInfo trademarkInfo = new TrademarkInfo();
        if (groundsOfOppostion.getTrademarkInfo() != null) {
            trademarkInfo = groundsOfOppostion.getTrademarkInfo();
        }

        switch (strField) {
            case "listofGoodsAndServices":
                groundsOfOppostion.setNiceClassCode(strValue);
                break;
            default:
                System.out.println("ERROR");
        }

        gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
            .getGroundsOfOppositionList().getGroundsOfOppositionListBag()
            .set(Integer.parseInt(strIncr) - 1, groundsOfOppostion);

        modelMap.addAttribute("wipogs", gsBean);

    }

    /**
     * Search for a Cited Mark.  Prior to performing a Search Validation will be done
     * to ensure that it is a INTEGER.  Then a call will be made to TIRS, to perform the Search.
     * It is possible that TIRS may return MULTIPLE Cited Marks, for the single FIle Number, in
     * which case....all will be returned and displayed to the User.  THe result of either
     * ERROR, SUCCESS or MULTIPLE (CitedMarksSearchResponse) will be returned to the client.
     *
     * @param strfilingNumber - Filing Number (String)
     * @param intCitedMarksCnt - Cited Mark Number (int)
     * @return  CitedMarksSearchResponse
     */
    @RequestMapping(value = "/searchFilingNumber", method = RequestMethod.POST)
    public @ResponseBody CitedMarksSearchResponse searchFilingNumber(@RequestParam(value = "strFilingNumber", required = false) String strfilingNumber,
                                                           @RequestParam(value = "intCitedMarksCnt", required = false) int intCitedMarksCnt,
                                                           Locale locale, ModelMap modelMap, Model model, final HttpServletRequest request,
                                                           final HttpServletResponse response, HttpSession session,
                                                           final RedirectAttributes redirectAttributes)
        throws ParseException, IOException {

        logger.debug("/searchFilingNumber RequestMethod.POST FilingNumber : " + strfilingNumber);

        CitedMarksSearchResponse resp = new CitedMarksSearchResponse();
        List<GroundsOfOpposition> groundsOfOppositionList = new ArrayList<GroundsOfOpposition>();

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");
        GoodServiceWipoBean gsBean = (GoodServiceWipoBean) modelMap.get("wipogs");

        // Language to be displayed on Screen.  Needed to dispaly error messages in the corect language
        Locale mf3alocale = new Locale(gsBean.getMf3a().getMf3aRequest().getLanguageCode());

        // Verify if Filing Number..is actually a number (Integer).
        int filingNumber = 0;
        try {
            filingNumber = Integer.valueOf(strfilingNumber);
        } catch (Exception e) {
            resp.setStatus(StatusResponse.ERROR);
            resp.setMessage(messageSource.getMessage("mc.mf3a.validation.error.filing.number.not.valid", null, mf3alocale));
            return resp;
        }

        try {
            groundsOfOppositionList= tmAppService.getGroundsOfOppostion(filingNumber);
        } catch (MCServerException e) {
            resp.setStatus(StatusResponse.ERROR);
            resp.setMessage(messageSource.getMessage("mc.mf3a.validation.error.filing.number.not.found", null, mf3alocale));
            return resp;
        }

        // Only 1 Grounds of Opposition is available
        if (groundsOfOppositionList.size() == 1 ) {
            // Verify if the Filing number is already present on the Screen.
            if (isCitedMarkPresent(gsBean, groundsOfOppositionList.get(0).getFilingNumber())) {
                String[] params = new String[1];
                params[0] = groundsOfOppositionList.get(0).getFilingNumber();
                resp.setStatus(StatusResponse.ERROR);
                resp.setMessage(messageSource.getMessage("mc.mf3a.validation.error.filing.number.already.present", params, mf3alocale));
            } else {
                gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                    .getGroundsOfOppositionList().getGroundsOfOppositionListBag().set(intCitedMarksCnt - 1, groundsOfOppositionList.get(0));
                resp.setStatus(CitedMarksSearchResponse.SUCCESS);
            }
        }

        // Multiple Grounds of Opposition exist - user is going to have to select
        if (groundsOfOppositionList.size() > 1 ) {

            // Remove the element(s) from the list, if they have already been selected
            for (int i = 0; i <  gsBean.getMf3a().getMf3aRequest().getManualReportForm()
                .getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag().size(); i++) {
                GroundsOfOpposition groundsOfOppostionGSBean = gsBean.getMf3a().getMf3aRequest().getManualReportForm()
                    .getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag().get(i);

                for (int y = 0; y <  groundsOfOppositionList.size(); y++) {
                    GroundsOfOpposition groundsOfOppostionTIRS = groundsOfOppositionList.get(y);

                    if (groundsOfOppostionTIRS.getFilingNumber().equals(groundsOfOppostionGSBean.getFilingNumber())) {
                        groundsOfOppositionList.remove(y);
                    }
                }
            }

            // If 0 Grounds of Opposition left present error message,
            // If only 1 Grounds of Opposition is available, automatically add it to he the list
            // If more then 1....(MULTIPLE) display list of Cited Marks
            if (groundsOfOppositionList.size() == 0 ) {
                String[] params = new String[1];
                params[0] = strfilingNumber;
                resp.setStatus(StatusResponse.ERROR);
                resp.setMessage(messageSource.getMessage("mc.mf3a.validation.error.filing.number.already.present", params, mf3alocale));
            } else if (groundsOfOppositionList.size() == 1 ) {
                gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
                .getGroundsOfOppositionList().getGroundsOfOppositionListBag().set(intCitedMarksCnt - 1, groundsOfOppositionList.get(0));
                resp.setStatus(CitedMarksSearchResponse.SUCCESS);
            } else {   // Mulitple
                gsBean.setGroundsOfOppositionList(groundsOfOppositionList);
                resp.setGroundsOfOppositionList(groundsOfOppositionList);
                resp.setStatus(CitedMarksSearchResponse.MULTIPLE);
            }
        }

        modelMap.addAttribute("wipogs", gsBean);

        return resp;
    }

    /**
     * This method is used to determine if the GroundsOfOpposition is empty or not, or has not been searched
     * and retrieved from TIRS. by checking if the GroundsOfOppostion contains any data.
     * If there is any data in the the GroundsOfOppostion, then it is not empty. A Boolean is returned indicating the results.
     *
     * @param groundsOfOppostion - GroundsOfOpposition
     * @return Boolean - Boolean indicating if the GroundsOfOpposition is empty or not.
     */
    public Boolean checkIfGroundsOfOppositionEmpty(GroundsOfOpposition groundsOfOppostion) {
        if (groundsOfOppostion == null
            || (groundsOfOppostion.getFilingNumber() == null || groundsOfOppostion.getFilingNumber().isEmpty())
            || (groundsOfOppostion.getFilingNumber() != null &&
                 groundsOfOppostion.getFilingDate() == null &&
                 groundsOfOppostion.getPriorityDate() == null &&
                 groundsOfOppostion.getRegistrationDate() == null &&
                 groundsOfOppostion.getRegistrationNumber() == null)
            ) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * This method is used to determine if a Cited Mark (filing Number) is currently present in the GoodServiceWipoBean
     * (MF3A Request - getMf3aRequest). A Boolean is returned indicating the results.
     *
     * @param gsBean - GoodServiceWipoBean
     * @param filingNumber - (String) Filing Number
     * @return Boolean - Boolean indicating if the Cited Mark (filing Number) is present in the GoodServiceWipoBean
     *         (MF3A Request)
     */
    public Boolean isCitedMarkPresent(GoodServiceWipoBean gsBean, String filingNumber) {

        Iterator<GroundsOfOpposition> i = gsBean.getMf3a().getMf3aRequest().getManualReportForm()
            .getProvisionalRefusalMF3AType().getGroundsOfOppositionList().getGroundsOfOppositionListBag().iterator();
        while (i.hasNext()) {
            GroundsOfOpposition groundsOfOppostion = i.next();
            if ((groundsOfOppostion.getFilingNumber() != null) && (!groundsOfOppostion.getFilingNumber().isEmpty())
                && groundsOfOppostion.getFilingNumber().equals(filingNumber)){
                return true;
            }
        }
        return false;
    }

    /**
     * This method is used when the user has selected a Cited Mark, when there were multiple (File Number / Extension Counter) available.
     *
     * The Citered Mark selected by the User (i.e., the parameter selectedCitedMark) will be copied from gsBean.getGroundsOfOppositionList()
     * and stored in the sBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
     *    .getGroundsOfOppositionList().getGroundsOfOppositionListBag()
     *
     * The Updated list of Cited Markes (which includes the just selected Cited Mark) is return, so the complete
     * list of Cited Marks may be displayed to the user.
     *
     * @param gsBean - GoodServiceWipoBean
     * @param citedMarkSelected - int representing the Cited Mark selected (Starting from the number 0)
     */
    @RequestMapping(value = "/citedMarkSelected", method = RequestMethod.GET)
    public void citedMarkSelected(@RequestParam(value = "selectedCitedMark", required = true) int selectedCitedMark,
                               HttpServletRequest request, HttpServletResponse response, final ModelMap modelMap) {

        logger.debug("/citedMarkSelected RequestMethod.GET selectedCitedMark : " + selectedCitedMark);

        response.setContentType("application/json;charset=ISO-8859-15");
        response.setHeader("Cache-Control", "no-store");

        GoodServiceWipoBean gsBean = (GoodServiceWipoBean) modelMap.get("wipogs");

        // Update the Grounds of Opposition List (gsbean/MF3A) with the item selected by the user
        int listsize = gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
        .getGroundsOfOppositionList().getGroundsOfOppositionListBag().size();
        gsBean.getMf3a().getMf3aRequest().getManualReportForm().getProvisionalRefusalMF3AType()
        .getGroundsOfOppositionList().getGroundsOfOppositionListBag().set(listsize - 1,gsBean.getGroundsOfOppositionList().get(selectedCitedMark));

        // Reload the Cited Mark Table.
        PrintWriter out;
        String citedMarksdata = null;
        try {
            out = response.getWriter();
            citedMarksdata = citedMarksDataTableService.generateCitedMarks(gsBean);

            if (citedMarksdata != null) {
                out.print(citedMarksdata);
            }
        } catch (Exception se) {
            logger.warn("Madird Console runtime exception. check the data", se);
            throw new CustomGenericException("code1", "serviceerror");
        }

        modelMap.addAttribute("wipogs", gsBean);

    }

}
