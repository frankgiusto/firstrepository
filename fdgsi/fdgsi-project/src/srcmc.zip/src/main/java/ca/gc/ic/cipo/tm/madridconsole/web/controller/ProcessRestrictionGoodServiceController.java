package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForGoodsAndServices;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.xmlschema.trademark.ClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.PriorityClaimType;
import ca.gc.ised.cipo.tm.mwe.ForwardTaskStatusType;

/**
 * The Class ProcessRestrictionGoodServiceController used to handle the G&S for Partial Ownership for New and Previous
 * Owner.
 */
@Controller
@SessionAttributes("wipogs")
public class ProcessRestrictionGoodServiceController {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(ProcessGoodServiceController.class.getName());

    /** The tm app service. */
    @Autowired
    protected TradMarkApplicationService tmAppService;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /** The message source. */
    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    /** The mwe client. */
    @Autowired
    protected WorkflowEngineServiceClient mweClient;

    /** The user profile service. */
    @Autowired
    protected UserProfileServiceClient userProfileService;

    /**
     * Gets the wipo gs.
     *
     * @param request the request
     * @return the wipo gs
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {
        GoodServiceWipoBean gsBean = new GoodServiceWipoBean();

        return gsBean;
    }

    /**
     * Inits the binder.
     *
     * @param binder the binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * Gets the initial page for partial ownership manual task.
     *
     * @param fileNumberStr the file number str
     * @param transIds the trans ids
     * @param taskId the task id
     * @param actId the act id
     * @param type the type
     * @param gsBean the gs bean
     * @param modelMap the model map
     * @param request the request
     * @param session the session
     * @return the initial page
     */
    @RequestMapping(value = "/processtask/partialownership", method = RequestMethod.POST)
    public String displayPartialOwnershipPage(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                              @RequestParam(value = "transIds", required = false) List<String> transIds,
                                              @RequestParam(value = "taskId", required = false) String taskId,
                                              @RequestParam(value = "aId", required = false) String actId,
                                              @RequestParam(value = "type", required = false) String type,
                                              @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                              final ModelMap modelMap, HttpServletRequest request,
                                              HttpServletResponse response, HttpSession session) {

        logger.debug("Method: displayPartialOwnershipPage: File: " + fileNumberStr + ", Task ID: " + taskId + ", actId "
            + actId + ", type " + type + ", transIds " + transIds);

        if (fileNumberStr != null) {
            int fileNumber = Integer.parseInt(fileNumberStr);

            ArrayList<String> actIds = new ArrayList<String>();
            actIds.add(actId);

            try {

                // Acquire lock
                transactionServiceClient.acquireLock(gsBean, fileNumber, 0,
                    userProfileService.getLdapUsername(request));

                // assign task to the user first, if its already been assigned we should not proceed
                // and let the user know that he should refresh page.
                if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                    userProfileService.getParentId(request)) > 0) {
                    try {
                        response.sendError(HttpServletResponse.SC_OK,
                            MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                    } catch (IOException e) {
                        logger.error("Exception: ", e);
                        // e.printStackTrace();
                    }
                }
            } catch (MCServerException e) {
                // TODO handle this error gracefully
                logger.error("Error assigning task to current user " + userProfileService.getParentId(request)
                    + " due to - " + e.getMessage(), e);
                try {
                    logger.error("Exception: ", e);
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                    transactionServiceClient.releaseLock(gsBean);
                    return "ptDOPartialOwnershipDesignation";
                } catch (Exception e1) {
                    logger.error("Exception: ", e1);
                }
            }

            if (gsBean == null) {
                gsBean = new GoodServiceWipoBean();
            }
            gsBean.clearCache();
            logger.debug("URL = " + request.getRequestURL());
            logger.debug("Referer = " + request.getHeader("Referer"));

            // save the calling page for now so that we can go back when the task is processed
            // now being set in the jsp page
            // session.setAttribute("refererPage", request.getHeader("Referer"));

            if (transIds != null) { // take the first transId for now
                try {
                    tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                        new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.PARTIALOWNERSHIP_FORM);
                } catch (MCServerException e) {
                    try {
                        logger.debug("Method: displayPartialOwnershipPage: Error generating GoodsServicesBean File: "
                            + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", type " + type
                            + ", transIds " + transIds);
                        logger.error("Exception: ", e);
                        response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (Exception e1) {
                        logger.error("Exception: ", e1);
                    }
                }
            } else {
                logger.error("Transaction ID is missing for task " + taskId + " activity task - " + actId);
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        "Transaction ID is missing for task " + taskId + " activity task - " + actId);
                    transactionServiceClient.releaseLock(gsBean);
                } catch (Exception e) {
                    logger.error("Exception: ", e);
                }
            }
        }

        return "ptDOPartialOwnershipDesignation";
    }

    /**
     * Prepare designation page for new owner.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership", method = RequestMethod.GET)
    public String prepareDesignationPage(final ModelMap modelMap,
                                         final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                         HttpServletRequest request) {

        logger.debug("Method: prepareDesignationPage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptDOPartialOwnershipDesignation";
    }

    /**
     * Handles actions on designation submit form.
     *
     * @param gsBean the gs bean
     * @param model the model
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/designation", method = RequestMethod.POST)
    public String handlePartialOwnershipDesignation(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                                    ModelMap model, final HttpServletRequest request,
                                                    final HttpServletResponse response, HttpSession session,
                                                    final RedirectAttributes redirectAttributes) {
        String action = gsBean.getAction();

        logger.debug("Method: handlePartialOwnershipDesignation with action " + action);

        String viewName = "ptDOPartialOwnershipDesignation";

        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {
            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            viewName = "redirect:/processtask/partialownership/restriction";

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/partialownership/designation, (CANCEL) Errors attempting to release Lock."
                    + e.getMessage());
            }

        }
        return viewName;
    }

    /**
     * Prepare restriction page for previous owner.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/restriction", method = RequestMethod.GET)
    public String prepareRestrictionPage(final ModelMap modelMap,
                                         final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                         HttpServletRequest request) {

        logger.debug("Method: prepareRestrictionPage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptDOPartialOwnershipRestriction";
    }

    /**
     * Handle actions on partial ownership for previous owner submit form.
     *
     * @param gsBean the gs bean
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/restriction", method = RequestMethod.POST)
    public String handlePartialOwnershipRestriction(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                                    final HttpServletRequest request,
                                                    final HttpServletResponse response, HttpSession session,
                                                    final RedirectAttributes redirectAttributes) {

        String action = gsBean.getAction();

        logger.debug("Method: handlePartialOwnershipRestriction with action " + action);

        String viewName = "ptDOPartialOwnershipRestriction";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {
            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                viewName = "redirect:/processtask/partialownership/review";
            }
        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/MF3A/submit, (CANCEL) Errors attempting to release Lock." + e.getMessage());
            }

        } else if (ActionDispatcher.ACTION_PREVIOUS.equalsIgnoreCase(action)) {
            viewName = "redirect:/processtask/partialownership";

        } else if (ActionDispatcher.ACTION_SAVE.equalsIgnoreCase(action)) {

            try {
                tmAppService.processPartialOwnershipChange(request, gsBean);

                // call workflow engine to complete task
                try {
                    // check if any of them have no goods and services. If so, we need to send
                    // notifications to the supervisor to review
                    ForwardTaskStatusType strForwardTaskStatusType = null;
                    if (!gsBean.gsInFinal()) {
                        if (!gsBean.gsInFinalForPreviousOwner()) {
                            strForwardTaskStatusType = ForwardTaskStatusType.PART_OWNERSHIP_BOTH;
                        } else {
                            strForwardTaskStatusType = ForwardTaskStatusType.PART_OWNERSHIP_DESIGNATION;
                        }
                    } else if (!gsBean.gsInFinalForPreviousOwner()) {
                        strForwardTaskStatusType = ForwardTaskStatusType.PART_OWNERSHIP_RESTRICTION;
                    }
                    if (strForwardTaskStatusType != null) {
                        // send notifications
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request),
                            strForwardTaskStatusType, userProfileService.getAuthorityId(request));
                    } else {
                        // no notifications
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));
                    }

                    // TODO: Need to update this once MTS is ready with how to pass the info
                    if (gsBean.gsInFinal() && gsBean.gsInFinalForPreviousOwner()) { // means we had some goods and
                                                                                    // services to merge for both
                                                                                    // owners
                        redirectAttributes.addFlashAttribute("wipogs", gsBean);
                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.completetaskmsg", null, LocaleContextHolder.getLocale()));
                    } else {
                        redirectAttributes.addFlashAttribute("wipogs", gsBean);

                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.notificationsentmsg", null, LocaleContextHolder.getLocale()));
                    }

                } catch (MCServerException e) {

                    // What happens if MWE cannot complete task but MTS has marked it Processed?
                    // TODO: The task will not appear on the console. MTS Needs to handle it.
                    logger.error("Error completing Goods and Services Task by MWE - ");
                    logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                        + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                        + gsBean.getActivityTaskId());
                    logger.error("Exception: ", e);
                    redirectAttributes.addFlashAttribute("errorMsg",
                        messageSource.getMessage("mc.goodsandservices.label.completetaskmsgerr", null,
                            LocaleContextHolder.getLocale()) + e.getMessage());
                }

            } catch (MCServerException e) {

                logger.error("Error submitting goods and services request to MTS - ");
                logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                    + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                    + gsBean.getActivityTaskId());
                logger.error("Exception: ", e);

                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.goodsandservices.label.completetaskmsgerr", null,
                        LocaleContextHolder.getLocale()) + e.getMessage());
            } finally {

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock(gsBean);
                } catch (MCServerException e) {
                    logger.error(
                        "/processtask/partialownership/restriction, (ACTION SAVE) Errors attempting to release Lock."
                            + e.getMessage());
                }
            }

            viewName = "redirect:" + session.getAttribute("refererPage");

            session.setAttribute("wipogs", null);
        }

        return viewName;
    }

    /**
     * Process the associate to WIPO action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/assoctowipo", method = RequestMethod.POST)
    public void handleAssocToWipo(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                  @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                  @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                  final HttpServletRequest request, final HttpServletResponse response,
                                  HttpSession session) {

        logger.debug("Method: handleAssocToWipo with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_ASSOCTOWIPO)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            int niceClass = new Integer(tokens[1]);
            int rowNum = new Integer(tokens[2]);
            int inrepidIndex = new Integer(tokens[3]);

            gsBean.associateInterpidToWipo(niceClass, rowNum, inrepidIndex, previousOwner,
                GoodServiceWipoBean.ASSOCIATE_TO_WIPO);

            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }

    /**
     * Process the edit final action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/editfinal", method = RequestMethod.POST)
    public void handleEditFinal(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                @RequestParam(required = true, defaultValue = "", value = "updatedText") String updatedText,
                                @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                final HttpServletRequest request, final HttpServletResponse response,
                                HttpSession session) {

        logger.debug("Method: handleEditFinal with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_EDITFINAL)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            String finalStatement = gsBean.editFinal(new Integer(tokens[2]), new Integer(tokens[3]), updatedText,
                previousOwner);

            try {
                PrintWriter out = response.getWriter();
                JSONObject result = new JSONObject();
                result.put("finalStatement", finalStatement);
                out.print(result);
            } catch (IOException | JSONException e) {
                try {
                    logger.error("Exception: ", e);
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                } catch (IOException e1) {
                    logger.error("Exception: ", e1);
                }
            }
        }
    }

    /**
     * Process the remove the data in the final table cell action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/removecelldata", method = RequestMethod.POST)
    public void handleRemoveFinalCellData(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                          @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                          @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                          final HttpServletRequest request, final HttpServletResponse response,
                                          HttpSession session) {

        logger.debug("Method: handleRemoveFinalCellData with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_REMOVEFROMFINAL)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.removeStatementFromFinal(new Integer(tokens[2]), new Integer(tokens[3]), previousOwner);

            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }

    /**
     * Process removing all final statements action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/removeallfromfinal", method = RequestMethod.POST)
    public void handleRemoveAllFromFinal(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                         @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                         @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                         final HttpServletRequest request, final HttpServletResponse response,
                                         HttpSession session) {

        logger.debug("Method: handleRemoveAllFinalCellData with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_REMOVEALLFROMFINAL)) {

            gsBean.removeAllFromFinal(previousOwner);

            // return a response that really does not matter
            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }

    private void outputAllFinalStatements(GoodServiceWipoBean gsBean, final HttpServletResponse response,
                                          boolean previousOwner) {
        // JSON Array to store the row of the same nice class that are affected
        JSONArray gsList = new JSONArray();

        List<ReturnObjForGoodsAndServices> retObjs = (previousOwner) ? gsBean.getGoodsAndServicesForPreviousOwner()
            : gsBean.getGoodsAndServices();

        try {
            PrintWriter out = response.getWriter();
            JSONObject result = new JSONObject();
            boolean finalStmtIsEmpty = true;

            int index = 0;
            for (ReturnObjForGoodsAndServices retGS : retObjs) {

                JSONArray finalStatements = new JSONArray();
                JSONArray claims = new JSONArray();
                List<GoodsServicesClaimsType> goodsAndServices = retObjs.get(index).getFinalGSType();

                if (goodsAndServices != null) {
                    for (GoodsServicesClaimsType gscType : goodsAndServices) {
                        if (gscType != null) {
                            finalStatements.put(gscType.getStatement().getStatementDescription().getValue());
                            finalStmtIsEmpty = false;
                            if (gscType.isSetClaims()) {
                                List<ClaimType> gscClaims = gscType.getClaims();
                                for (int i = 0; i < gscClaims.size(); i++) {
                                    JSONObject claim = new JSONObject();
                                    try {
                                        claim.put("type", gscClaims.get(i).getClaimCategoryType());
                                        if (gscClaims.get(i).getClaimTypeDescription() != null) {
                                            claim.put("desc", gscClaims.get(i).getClaimTypeDescription().getValue());
                                        }
                                        if (gscClaims.get(i).getClaimAdditionalInfo() != null) {
                                            claim.put("addinfo", gscClaims.get(i).getClaimAdditionalInfo());
                                        }
                                        if (gscClaims.get(i).getClaimCategoryType() == 12) {
                                            claim.put("fileddate",
                                                ((PriorityClaimType) gscClaims.get(i)).getFiledDate());
                                            claim.put("appnum",
                                                ((PriorityClaimType) gscClaims.get(i)).getApplicationNumber());
                                            claim.put("country",
                                                ((PriorityClaimType) gscClaims.get(i)).getCountryOfficeFiledCode());
                                        }
                                    } catch (JSONException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    claims.put(claim);
                                }
                            } else {
                                claims.put("");
                            }
                        } else {
                            finalStatements.put("");
                            claims.put("");
                        }
                    }
                } else {
                    finalStatements.put("");
                    claims.put("");
                }

                JSONObject gsRow = new JSONObject();
                gsRow.put("row", retGS.getNiceClass() + "_" + index);
                gsRow.put("nice", retGS.getNiceClass());
                gsRow.put("countstmt", finalStatements.length());
                gsRow.put("finalStatements", finalStatements);
                gsRow.put("finalStmtIsEmpty", finalStmtIsEmpty);
                gsRow.put("claims", claims);
                gsList.put(gsRow);

                finalStmtIsEmpty = true;
                index++;
            }
            result.put("count", gsList.length());
            result.put("gsList", gsList);
            result.put("removeAll",
                (previousOwner ? gsBean.isRemoveAllOptionForPreviousOwner() : gsBean.isRemoveAllOption()));
            result.put("checkedlist", gsBean.getAssociateInterpidToWipoList(false));
            out.print(result);

        } catch (IOException | JSONException e) {
            try {
                logger.error("Exception: ", e);
                // e.printStackTrace();
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
                // e1.printStackTrace();
            }
        }
    }

    /**
     * Process the copy the WIPO statement into the final table cell action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/copyfromwipo", method = RequestMethod.POST)
    public void handleCopyWIPOStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                        @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                        @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                        final HttpServletRequest request, final HttpServletResponse response,
                                        HttpSession session) {

        logger.debug("Method: handleCopyAllWIPOStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_MOVEWIPOTOMERGE)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.copyWIPOStatementToFinal(new Integer(tokens[2]), new Integer(tokens[3]), previousOwner);

            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }

    /**
     * Process the copy all WIPO statements into the final table action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/copyallfromwipo", method = RequestMethod.POST)
    public void handleCopyAllWIPOStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                           @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                           @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                           final HttpServletRequest request, final HttpServletResponse response,
                                           HttpSession session) {

        logger.debug("Method: handleCopyAllWIPOStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_COPYALLFROMWIPO)) {

            gsBean.copyAllToFinalFromWipo(previousOwner);

            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }

    /**
     * Process the copy the INTREPID statement into the final table cell action on the G&S adjustments/merge submit
     * form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/copyfromintrepid", method = RequestMethod.POST)
    public void handleCopyIntrepidStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                            @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                            @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                            final HttpServletRequest request, final HttpServletResponse response,
                                            HttpSession session) {

        logger.debug("Method: handleCopyIntrepidStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_MOVEINTREPIDTOMERGE)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.copyIntrepidStatementToFinal(new Integer(tokens[2]), new Integer(tokens[3]), previousOwner);

            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }

    /**
     * Process the copy all INTREPID statements into the final table action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/partialownership/copyallfromintrepid", method = RequestMethod.POST)
    public void handleCopyAllIntrepidStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                               @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                               @RequestParam(required = true, defaultValue = "false", value = "previousowner") boolean previousOwner,
                                               final HttpServletRequest request, final HttpServletResponse response,
                                               HttpSession session) {

        logger.debug("Method: handleCopyAllIntrepidStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_COPYALLFROMINTREPID)) {

            gsBean.copyAllToFinalFromIntrepid(previousOwner);

            outputAllFinalStatements(gsBean, response, previousOwner);
        }
    }
}
