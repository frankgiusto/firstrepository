package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import ca.gc.ic.cipo.tm.schema.mps.PackageStatusEnum;
import ca.gc.ic.cipo.tm.schema.mps.PackageTypeEnum;


public class PackageCriteria extends ca.gc.ic.cipo.tm.schema.mps.PackageCriteria implements Serializable {

    
    public List<BigDecimal> getPackageId() {
        return packageId;
    }
    
    public void setPackageId(List<BigDecimal> packageId) {
        this.packageId = packageId;
    }
    
    public List<PackageTypeEnum> getPackageTypeCode() {
        return packageTypeCode;
    }
    
    public void setPackageTypeCode(List<PackageTypeEnum> packageTypeCode) {
        this.packageTypeCode = packageTypeCode;
    }
    
    public List<PackageStatusEnum> getStatusCode() {
        return statusCode;
    }
    
    public void setStatusCode(List<PackageStatusEnum> statusCode) {
        this.statusCode = statusCode;
    }
    
    public List<String> getIntlPblctnId() {
        return intlPblctnId;
    }
    
    public void setIntlPblctnId(List<String> intlPblctnId) {
        this.intlPblctnId = intlPblctnId;
    }
    
    public String getIntlPblctnDt() {
        return intlPblctnDt;
    }
    
    public void setIntlPblctnDt(String intlPblctnDt) {
        this.intlPblctnDt = intlPblctnDt;
    }
}
