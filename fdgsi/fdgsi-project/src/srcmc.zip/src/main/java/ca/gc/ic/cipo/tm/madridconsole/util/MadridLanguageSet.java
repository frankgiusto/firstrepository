package ca.gc.ic.cipo.tm.madridconsole.util;

import org.springframework.util.StringUtils;

public enum MadridLanguageSet {
    EN("en"),

    FR("fr");

    private String value;

    private MadridLanguageSet(String value) {
        this.value = value;
    }

    public static MadridLanguageSet valueOfLabel(String value) {
        for (MadridLanguageSet e : values()) {
            if (e.value.equals(value)) {
                return e;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

    public static boolean contains(String value) {
        if (StringUtils.isEmpty(value)) {
            return false;
        }

        for (MadridLanguageSet e : MadridLanguageSet.values()) {
            if (e.toString().equalsIgnoreCase(value)) {
                return true;
            }
        }

        return false;
    }

}
