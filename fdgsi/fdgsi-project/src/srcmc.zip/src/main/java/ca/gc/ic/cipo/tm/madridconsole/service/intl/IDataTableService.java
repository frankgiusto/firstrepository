package ca.gc.ic.cipo.tm.madridconsole.service.intl;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import ca.gc.ic.cipo.tm.mps.GetAttachmentResponse;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.schema.mps.PackageDetail;

public interface IDataTableService {

    public String getPackageDataTableResponse(HttpServletRequest request, String typeid, String periodid, Locale loc,
                                              String status, String startate, String endDate)
        throws Exception;

    public String getFinancialTransactionDetail(long packageId, Locale loc)
        throws Exception;

    public PackageDetail getPackageFile(Long packageId) throws  Exception;

    public String getTransactionAttachments(Long transid, Locale loc) throws Exception;

    TransactionDetail getXML(Long transactionid)
        throws Exception;
   
    String getBulletinDataTableResponse(String packageId, Locale loc) 
        throws Exception;

//    String getTransactionEventsList(String transid, Locale loc) 
//        throws Exception;

    String getPackageEventsList(String packageId, Locale loc) 
        throws Exception;
    
    String getPackageDetail(Long packageId, Locale loc) throws Exception;

    String getTransactionDetail(Long transid, Locale loc) throws Exception;
    
    GetAttachmentResponse getPackageAttachment(Long attachmentid)
        throws Exception;
////
//    public String getEventErrorData(Long transId, Long eventId) throws  Exception;

    String getPackageAttachments(Long packageid, Locale loc) throws Exception;

    AttachmentDetail getAttachment(Long attachmentid) throws  Exception;

    String getPackageEventDetailData(Long packageId, Long eventId) throws Exception;
    
}