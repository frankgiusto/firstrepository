package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionCategoryType;
import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForGoodsAndServices;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.xmlschema.trademark.ClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.PriorityClaimType;
import ca.gc.ised.cipo.tm.mwe.ForwardTaskStatusType;

/**
 * The Class ProcessGoodServiceController handles any manual tasks where processing of G&S is required such as
 * Limitation, Partial Ceasing of Effect and Cancellation.
 */
@Controller
@SessionAttributes("wipogs")
public class ProcessGoodServiceController {

    /** The logger. */
    protected static Logger logger = Logger.getLogger(ProcessGoodServiceController.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    /** The message source. */
    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * Gets the bean used to transfer data from View and Controller.
     *
     * @param request the request
     * @return the wipo gs
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    /** The TM App service to retrieve info from TIRS. */
    @Autowired
    protected TradMarkApplicationService tmAppService;

    /** The MWE client. */
    @Autowired
    protected WorkflowEngineServiceClient mweClient;

    /** The user profile service. */
    @Autowired
    protected UserProfileServiceClient userProfileService;

    /**
     * Inits the binder.
     *
     * @param binder the binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * The default handler (page=0).
     *
     * @param fileNumberStr the file number of the application associated to the selected task being processed.
     * @param transIds the trans ids associated to the selected task being processed.
     * @param taskId the task id associated to the selected task being processed.
     * @param actId the MWE activity task id associated to the selected task being processed.
     * @param type the type of the task being processed.
     * @param gsBean the gs bean used to send and receive data between the view and controller
     * @param modelMap the model map
     * @param request the request
     * @param session the session
     * @return the initial page
     */
    @RequestMapping(value = "/processtask/goodservice", method = RequestMethod.POST)
    public String displayGsSelectOptionsPage(@RequestParam(value = "filenumber", required = false) String fileNumberStr,
                                             @RequestParam(value = "transIds", required = false) List<String> transIds,
                                             @RequestParam(value = "taskId", required = false) String taskId,
                                             @RequestParam(value = "aId", required = false) String actId,
                                             @RequestParam(value = "type", required = false) String type,
                                             @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                             final ModelMap modelMap, HttpServletRequest request,
                                             HttpServletResponse response, HttpSession session,
                                             Map<String, String> errors) {

        logger.debug("Method: displayGsSelectOptionsPage: File: " + fileNumberStr + ", Task ID: " + taskId + ", actId "
            + actId + ", type " + type + ", transIds " + transIds);


        int fileNumber = Integer.parseInt(fileNumberStr);

        ArrayList<String> actIds = new ArrayList<String>();
        actIds.add(actId);

        try {

            // Acquire lock
            transactionServiceClient.acquireLock( gsBean, fileNumber, 0, userProfileService.getLdapUsername(request));

            // assign task to the user first, if its already been assigned we should not proceed
            // and let the user know that he should refresh page.
            if (mweClient.assignUserTask(actIds, userProfileService.getParentId(request),
                userProfileService.getParentId(request)) > 0) {
                try {
                    response.sendError(HttpServletResponse.SC_OK,
                        MadridConsoleUtils.getMessage("mc.tasks.failedtoprocess"));
                    transactionServiceClient.releaseLock( gsBean);

                } catch (IOException e) {
                    logger.error("Exception: ", e);
                    // e.printStackTrace();
                }
            }

        } catch (MCServerException e) {

            logger.error("Method: displayGsSelectOptionsPage: File: " + fileNumberStr + ", Task ID: " + taskId
                + ", actId " + actId + ", type " + type + ", transIds " + transIds);
            logger.error("Error assigning task to current user " + userProfileService.getParentId(request)
                + " due to - " + e.getMessage(), e);
            try {
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                transactionServiceClient.releaseLock(gsBean);
                return "ptDOGoodandService";
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }  catch (Throwable e) {
            logger.error("Method: displayGsSelectOptionsPage: File: " + fileNumberStr + ", Task ID: " + taskId
                + ", actId " + actId + ", type " + type + ", transIds " + transIds + "Error assigning task to current user "
                + userProfileService.getParentId(request)
                + " due to Throwable - " + e.getMessage(), e);

            try {
                response.sendError(HttpServletResponse.SC_OK, MadridConsoleUtils.getMessage("mc.error.mts.gettransaction"));
                transactionServiceClient.releaseLock(gsBean);
                return "ptDOGoodandService";
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
            }
        }

        if (gsBean == null) {
            gsBean = new GoodServiceWipoBean();
        }
        gsBean.clearCache();

        logger.debug("URL = " + request.getRequestURL());
        logger.debug("Referer = " + request.getHeader("Referer"));


        try {
            tmAppService.generateGoodServiceBean(request, fileNumber, new BigDecimal(transIds.get(0)),
                new BigDecimal(taskId), actId, gsBean, TradMarkApplicationService.GOODSERVICES_FORM);

        } catch (MCServerException e) {

            try {
                logger.error("Method: displayGsSelectOptionsPage: Error generating GoodsServicesBean File: "
                    + fileNumberStr + ", Task ID: " + taskId + ", actId " + actId + ", type " + type
                    + ", transIds " + transIds + " due to error " + e.getMessage(), e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                transactionServiceClient.releaseLock( gsBean);
            } catch (Exception e1) {
                logger.error("Exception: ", e1);
                e1.printStackTrace();
            }
        }

        return "ptDOGoodandService";
    }

    /**
     * Displays the first screen to select the options when processing the G&S manual tasks.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice", method = RequestMethod.GET)
    public String prepareGsSelectPage(final ModelMap modelMap,
                                      final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                      HttpServletRequest request) {

        logger.debug("Method: prepareGsSelectPage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptDOGoodandService";
    }

    /**
     * Process any user selected input from the first screen when processing manual tasks.
     *
     * @param gsBean the bean containing the data from the view
     * @param model the model
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/merge", method = RequestMethod.POST)
    public String handleGsSelectSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, ModelMap model,
                                           final HttpServletRequest request, final HttpServletResponse response,
                                           HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = gsBean.getAction();
        String viewName = "ptDOGoodandService";

        logger.debug("Method: handleGsSelectSubmitForm with action " + action);

        viewName = "redirect:/processtask/goodservice/wipomerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {

            gsBean.setAction(ActionDispatcher.ACTION_NEXT);

            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {

                viewName = "redirect:/processtask/goodservice/wipomerge";

            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT)) {

                // if its Limitation, we need to call the MF13 page to let user fill information and
                // only then mark the task complete. Will be done by the MF13 controller.
                if (gsBean.getRestCategoryType() != MadridProtectionRestrictionCategoryType.LIMITATION) {
                    try {

                        tmAppService.processGoodServiceChange(request, gsBean);

                        // call workflow engine to complete task
                        try {
                            mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                            redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                                "mc.goodsandservices.label.noadjustmsg", null, LocaleContextHolder.getLocale()));

                        } catch (MCServerException e) {

                            // What happens if MWE cannot complete task but MTS has marked it Processed?
                            // TODO: The task will not appear on the console. MTS Needs to handle it.
                            logger.error("Error completing Goods and Services Task by MWE - ");
                            logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                                + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                                + gsBean.getActivityTaskId());
                            logger.error("Exception: ", e);
                            redirectAttributes.addFlashAttribute("errorMsg",
                                messageSource.getMessage("mc.goodsandservices.label.noadjustmsgerr", null,
                                    LocaleContextHolder.getLocale()) + e.getMessage());
                        }

                    } catch (MCServerException e) {

                        logger.error("Error submitting goods and services request to MTS - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId());
                        logger.error("Exception: ", e);

                        // e.printStackTrace();
                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.noadjustmsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    } finally {

                        // Release the LOCK on the File Number/Extension
                        try {
                            transactionServiceClient.releaseLock(gsBean);
                        } catch (MCServerException e) {
                            logger.error("/processtask/goodservice/merge, (ACTION NEXT) Errors attempting to release Lock." + e.getMessage() );                }
                    }

                    // go back to the calling page
                    viewName = "redirect:" + session.getAttribute("refererPage");

                    session.setAttribute("wipogs", null);
                } else {
                    // go back to the calling page
                    viewName = "redirect:/processtask/MF13";
                }

            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) {
                try {
                    gsBean.copyAllToFinalFromWipo(false);
                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine to complete task
                    try {
                        mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                        redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                            "mc.goodsandservices.label.acceptwipomsg", null, LocaleContextHolder.getLocale()));

                    } catch (MCServerException e) { // TODO replace it with CIPOService Fault later
                        // and handle errors
                        //
                        // What happens if MWE cannot complete task but MTS has marked it Processed?
                        // TODO: The task will not appear on the console. MTS Needs to handle it.
                        logger.error("Error completing Goods and Services Task by MWE - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId());
                        logger.error("Exception: ", e);
                        // e.printStackTrace();
                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.acceptwipomsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    }
                } catch (MCServerException e) {
                    // TODO handle errors
                    logger.error("Error submitting goods and services request to MTS - ");
                    logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                        + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                        + gsBean.getActivityTaskId());
                    logger.error("Exception: ", e);
                    // e.printStackTrace();

                    redirectAttributes.addFlashAttribute("errorMsg",
                        messageSource.getMessage("mc.goodsandservices.label.acceptwipomsgerr", null,
                            LocaleContextHolder.getLocale()) + e.getMessage());
                } finally {

                    // Release the LOCK on the File Number/Extension
                    try {
                        transactionServiceClient.releaseLock(gsBean);
                    } catch (MCServerException e) {
                        logger.error("/processtask/goodservice/merge, (ACTION NEXT) Errors attempting to release Lock." + e.getMessage() );                }
                }

                viewName = "redirect:" + session.getAttribute("refererPage");

                session.setAttribute("wipogs", null);
            }
        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {
            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/goodservice/merge, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }

        }
        return viewName;
    }

    /**
     * Prepare the second page when processing G&S manual tasks where the statements from WIPO and INTREPID are merged
     * and adjusted.
     *
     * @param modelMap the model map
     * @param gsBean the gs bean
     * @param request the request
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/wipomerge", method = RequestMethod.GET)
    public String prepareGsMergePage(final ModelMap modelMap,
                                     final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                     HttpServletRequest request) {

        logger.debug("Method: prepareGsMergePage");

        // put your initial command
        modelMap.addAttribute("wipogs", gsBean);

        // populate the model Map as needed
        return "ptDOGoodandServiceMerge";
    }

    /**
     * Process any actions on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param request the request
     * @param response the response
     * @param session the session
     * @param redirectAttributes the redirect attributes
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/wipomerge", method = RequestMethod.POST)
    public String handleGsMergeSubmitForm(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                          @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                          @RequestParam(required = false, defaultValue = "false", value = "submitMF13") String submitMF13,
                                          final HttpServletRequest request, final HttpServletResponse response,
                                          HttpSession session, final RedirectAttributes redirectAttributes) {

        String action = (actionVal == null || actionVal.isEmpty()) ? gsBean.getAction() : actionVal;

        logger.debug("Method: handleGsMergeSubmitForm with action " + action + ", submitMF13  " + submitMF13);

        String viewName = "ptDOGoodandServiceMerge";
        redirectAttributes.addFlashAttribute("wipogs", gsBean);

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(action)) {

            gsBean.setAction(ActionDispatcher.ACTION_NEXT);
            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                viewName = "redirect:/processtask/goodservice/review";
            }

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(action)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/goodservice/wipomerge, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }



        } else if (ActionDispatcher.ACTION_PREVIOUS.equalsIgnoreCase(action)) {

            viewName = "redirect:/processtask/goodservice";

        } else if (ActionDispatcher.ACTION_SAVE.equalsIgnoreCase(action)) {

            // Accept with adjustments option
            try {

                // if its Limitation with G&S in final, we need to call the MF13 page to let user fill information and
                // only then mark the task complete. Will be done by the MF13 controller. If its limitation and total
                // ceasing of effect, then we proceed to MTS similar to Cancellation and Partial ceasing of effect
                //
                //
                if (gsBean.getRestCategoryType() != MadridProtectionRestrictionCategoryType.LIMITATION
                    || (gsBean.getRestCategoryType() == MadridProtectionRestrictionCategoryType.LIMITATION
                        && !gsBean.gsInFinal())
                    || (gsBean.getRestCategoryType() == MadridProtectionRestrictionCategoryType.LIMITATION
                        && gsBean.gsInFinal()
                        && submitMF13.equals("false"))) {

                    tmAppService.processGoodServiceChange(request, gsBean);

                    // call workflow engine (MWE) to complete task
                    try {

                        if (gsBean.gsInFinal()) { // means we had some goods and services to merge

                            mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                            redirectAttributes.addFlashAttribute("wipogs", gsBean);
                            redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                                "mc.goodsandservices.label.acceptadjmsg", null, LocaleContextHolder.getLocale()));
                        } else {

                            mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request),
                                ForwardTaskStatusType.TOTAL_AND_NOTIFICATION,
                                userProfileService.getAuthorityId(request));

                            redirectAttributes.addFlashAttribute("wipogs", gsBean);
                            if (gsBean
                                .getRestCategoryType() == MadridProtectionRestrictionCategoryType.PARTIAL_CEASING_OF_EFFECT) {
                                redirectAttributes.addFlashAttribute("infoMsg",
                                    messageSource.getMessage("mc.goodsandservices.label.totalceasingmsg", null,
                                        LocaleContextHolder.getLocale()));
                            } else {
                                redirectAttributes.addFlashAttribute("infoMsg", messageSource.getMessage(
                                    "mc.goodsandservices.label.totalcancelmsg", null, LocaleContextHolder.getLocale()));
                            }
                        }

                    } catch (MCServerException e) {

                        // What happens if MWE cannot complete task but MTS has marked it Processed?
                        // TODO: The task will not appear on the console. MTS Needs to handle it.
                        logger.error("Error completing Goods and Services Task by MWE - ");
                        logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                            + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                            + gsBean.getActivityTaskId());
                        logger.error("Exception: ", e);
                        // e.printStackTrace();
                        redirectAttributes.addFlashAttribute("errorMsg",
                            messageSource.getMessage("mc.goodsandservices.label.acceptadjmsgerr", null,
                                LocaleContextHolder.getLocale()) + e.getMessage());
                    } finally {
                        // Release the LOCK on the File Number/Extension
                        try {
                            transactionServiceClient.releaseLock(gsBean);
                        } catch (MCServerException e) {
                            logger.error("/processtask/goodservice/wipomerge, (ACTION SAVE) Errors attempting to release Lock." + e.getMessage() );                }
                    }

                    viewName = "redirect:" + session.getAttribute("refererPage");
                    session.setAttribute("wipogs", null);

                } else {
                    viewName = "redirect:/processtask/MF13";
                }

            } catch (MCServerException e) {

                logger.error("Error submitting goods and services request to MTS - ");
                logger.error("IR: " + gsBean.getInternationalRegistrationNumber() + ", File: "
                    + gsBean.getApplication().getApplicationNumber().getFileNumber() + ", Task ID: "
                    + gsBean.getActivityTaskId());
                logger.error("Exception: ", e);
                // e.printStackTrace();

                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.goodsandservices.label.acceptadjmsgerr", null,
                        LocaleContextHolder.getLocale()) + e.getMessage());
                viewName = "redirect:" + session.getAttribute("refererPage");
                session.setAttribute("wipogs", null);
            }
        }

        return viewName;
    }

    /**
     * Process the associate to WIPO action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/assoctowipo", method = RequestMethod.POST)
    public void handleAssocToWipo(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                  @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                  final HttpServletRequest request, final HttpServletResponse response,
                                  HttpSession session) {

        logger.debug("Method: handleAssocToWipo with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_ASSOCTOWIPO)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            int niceClass = new Integer(tokens[1]);
            int rowNum = new Integer(tokens[2]);
            int inrepidIndex = new Integer(tokens[3]);

            gsBean.associateInterpidToWipo(niceClass, rowNum, inrepidIndex, false,
                GoodServiceWipoBean.ASSOCIATE_TO_WIPO);

            outputAllFinalStatements(gsBean, response);
        }
    }

    /**
     * Process the edit final action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/editfinal", method = RequestMethod.POST)
    public void handleEditFinal(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                @RequestParam(required = true, defaultValue = "", value = "updatedText") String updatedText,
                                final HttpServletRequest request, final HttpServletResponse response,
                                HttpSession session) {

        logger.debug("Method: handleEditFinal with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_EDITFINAL)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            String finalStatement = gsBean.editFinal(new Integer(tokens[2]), new Integer(tokens[3]), updatedText,
                false);

            try {
                PrintWriter out = response.getWriter();
                JSONObject result = new JSONObject();
                result.put("finalStatement", finalStatement);
                out.print(result);
            } catch (IOException | JSONException e) {
                try {
                    logger.error("Exception: ", e);
                    // e.printStackTrace();
                    response.sendError(HttpServletResponse.SC_OK, e.getMessage());
                } catch (IOException e1) {
                    logger.error("Exception: ", e1);
                    // e1.printStackTrace();
                }
            }
        }
    }

    /**
     * Process the remove the data in the final table cell action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/removecelldata", method = RequestMethod.POST)
    public void handleRemoveFinalCellData(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                          @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                          final HttpServletRequest request, final HttpServletResponse response,
                                          HttpSession session) {

        logger.debug("Method: handleRemoveFinalCellData with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_REMOVEFROMFINAL)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.removeStatementFromFinal(new Integer(tokens[2]), new Integer(tokens[3]), false);

            outputAllFinalStatements(gsBean, response);
        }
    }

    /**
     * Process removing all final statements action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/removeallfromfinal", method = RequestMethod.POST)
    public void handleRemoveAllFromFinal(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                         @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                         final HttpServletRequest request, final HttpServletResponse response,
                                         HttpSession session) {

        logger.debug("Method: handleRemoveAllFromFinal with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_REMOVEALLFROMFINAL)) {

            gsBean.removeAllFromFinal(false);

            // return a response that really does not matter
            outputAllFinalStatements(gsBean, response);
        }
    }

    private void outputAllFinalStatements(GoodServiceWipoBean gsBean, final HttpServletResponse response) {
        // JSON Array to store the row of the same nice class that are affected
        JSONArray gsList = new JSONArray();

        List<ReturnObjForGoodsAndServices> retObjs = gsBean.getGoodsAndServices();

        try {
            PrintWriter out = response.getWriter();
            JSONObject result = new JSONObject();
            boolean finalStmtIsEmpty = true;

            int index = 0;
            for (ReturnObjForGoodsAndServices retGS : retObjs) {

                JSONArray finalStatements = new JSONArray();
                JSONArray claims = new JSONArray();
                List<GoodsServicesClaimsType> goodsAndServices = retObjs.get(index).getFinalGSType();

                if (goodsAndServices != null) {
                    for (GoodsServicesClaimsType gscType : goodsAndServices) {
                        if (gscType != null) {
                            finalStatements.put(gscType.getStatement().getStatementDescription().getValue());
                            finalStmtIsEmpty = false;
                            if (gscType.isSetClaims()) {
                                List<ClaimType> gscClaims = gscType.getClaims();
                                for (int i = 0; i < gscClaims.size(); i++) {
                                    JSONObject claim = new JSONObject();
                                    try {
                                        claim.put("type", gscClaims.get(i).getClaimCategoryType());
                                        if (gscClaims.get(i).getClaimTypeDescription() != null) {
                                            claim.put("desc", gscClaims.get(i).getClaimTypeDescription().getValue());
                                        }
                                        if (gscClaims.get(i).getClaimAdditionalInfo() != null) {
                                            claim.put("addinfo", gscClaims.get(i).getClaimAdditionalInfo());
                                        }
                                        if (gscClaims.get(i).getClaimCategoryType() == 12) {
                                            claim.put("fileddate",
                                                ((PriorityClaimType) gscClaims.get(i)).getFiledDate());
                                            claim.put("appnum",
                                                ((PriorityClaimType) gscClaims.get(i)).getApplicationNumber());
                                            claim.put("country",
                                                ((PriorityClaimType) gscClaims.get(i)).getCountryOfficeFiledCode());
                                        }
                                    } catch (JSONException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    claims.put(claim);
                                }
                            } else {
                                claims.put("");
                            }
                        } else {
                            finalStatements.put("");
                            claims.put("");
                        }
                    }
                } else {
                    finalStatements.put("");
                    claims.put("");
                }

                JSONObject gsRow = new JSONObject();
                gsRow.put("row", retGS.getNiceClass() + "_" + index);
                gsRow.put("nice", retGS.getNiceClass());
                gsRow.put("countstmt", finalStatements.length());
                gsRow.put("finalStatements", finalStatements);
                gsRow.put("finalStmtIsEmpty", finalStmtIsEmpty);
                gsRow.put("claims", claims);
                gsList.put(gsRow);

                finalStmtIsEmpty = true;
                index++;
            }
            result.put("count", gsList.length());
            result.put("gsList", gsList);
            result.put("removeAll", gsBean.isRemoveAllOption());
            result.put("checkedlist", gsBean.getAssociateInterpidToWipoList(false));
            out.print(result);

        } catch (IOException | JSONException e) {
            try {
                logger.error("Exception: ", e);
                // e.printStackTrace();
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
                // e1.printStackTrace();
            }
        }
    }

    /**
     * Process the copy the WIPO statement into the final table cell action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/copyfromwipo", method = RequestMethod.POST)
    public void handleCopyWIPOStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                        @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                        final HttpServletRequest request, final HttpServletResponse response,
                                        HttpSession session) {

        logger.debug("Method: handleCopyWIPOStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_MOVEWIPOTOMERGE)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.copyWIPOStatementToFinal(new Integer(tokens[2]), new Integer(tokens[3]), false);

            outputAllFinalStatements(gsBean, response);
        }
    }

    /**
     * Process the copy all WIPO statements into the final table action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/copyallfromwipo", method = RequestMethod.POST)
    public void handleCopyAllWIPOStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                           @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                           final HttpServletRequest request, final HttpServletResponse response,
                                           HttpSession session) {

        logger.debug("Method: handleCopyAllWIPOStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_COPYALLFROMWIPO)) {

            gsBean.copyAllToFinalFromWipo(false);

            outputAllFinalStatements(gsBean, response);
        }
    }

    /**
     * Process the copy the INTREPID statement into the final table cell action on the G&S adjustments/merge submit
     * form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/copyfromintrepid", method = RequestMethod.POST)
    public void handleCopyIntrepidStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                            @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                            final HttpServletRequest request, final HttpServletResponse response,
                                            HttpSession session) {

        logger.debug("Method: handleCopyIntrepidStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_MOVEINTREPIDTOMERGE)) {

            String[] tokens = action.split("_");
            gsBean.setAction(tokens[0]);

            gsBean.copyIntrepidStatementToFinal(new Integer(tokens[2]), new Integer(tokens[3]), false);

            outputAllFinalStatements(gsBean, response);
        }
    }

    /**
     * Process the copy all INTREPID statements into the final table action on the G&S adjustments/merge submit form.
     *
     * @param gsBean the gs bean
     * @param action the action
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the string
     */
    @RequestMapping(value = "/processtask/goodservice/copyallfromintrepid", method = RequestMethod.POST)
    public void handleCopyAllIntrepidStatement(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean,
                                               @RequestParam(required = true, defaultValue = "", value = "action") String action,
                                               final HttpServletRequest request, final HttpServletResponse response,
                                               HttpSession session) {

        logger.debug("Method: handleCopyAllIntrepidStatement with action " + action);

        response.setContentType("application/json; charset=utf-8");
        response.setHeader("Cache-Control", "no-store");

        if (action.startsWith(ActionDispatcher.ACTION_COPYALLFROMINTREPID)) {

            gsBean.copyAllToFinalFromIntrepid(false);

            outputAllFinalStatements(gsBean, response);
        }
    }
}
