package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import ca.gc.ic.cipo.tm.madridconsole.web.bean.LoginFormBean;

@Controller
public class LoginController {

    @Value("${mc.wet4.theme.url}")
    private String mcWet4ThemeUrl;

    /** The logger. */
    private static Logger logger = Logger.getLogger(LoginController.class.getName());

    /**
     * Login page.
     *
     * @param session the session
     * @param model the model
     * @return the tiles definition for login page
     *
     * @author giustof
     */
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public final String loginPage(HttpSession session, Model model) {

        logger.debug("Method: loginPage");

        session.setAttribute("wetToolkitThemeUrl", mcWet4ThemeUrl);

        LoginFormBean loginFormBean = new LoginFormBean();
        model.addAttribute("loginForm", loginFormBean);

        Object authenticationAttribute = session.getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
        if (authenticationAttribute != null) {
            model.addAttribute("badCredentialsException", true);
        }

        // by default show the form view
        return "loginForm";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        // redirect to show login screen again
        return "redirect:/login?logout";
    }

}
