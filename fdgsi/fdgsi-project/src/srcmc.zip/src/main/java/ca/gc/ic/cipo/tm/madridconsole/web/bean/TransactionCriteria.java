package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import ca.gc.ic.cipo.tm.mts.TransactionStatusType;
import ca.gc.ic.cipo.tm.mts.TransactionType;


public class TransactionCriteria extends ca.gc.ic.cipo.tm.mts.TransactionCriteria implements Serializable {
   
    public List<BigDecimal> getTransactionIdList() {
        return transactionIdList;
    }
    
    public void setTransactionIdList(List<BigDecimal> transactionIdList) {
        this.transactionIdList = transactionIdList;
    }
    
    public List<BigDecimal> getPackageIdList() {
        return packageIdList;
    }
    
    public void setPackageIdList(List<BigDecimal> packageIdList) {
        this.packageIdList = packageIdList;
    }
    
    public List<TransactionStatusType> getStatusCodeList() {
        return statusCodeList;
    }
    
    public void setStatusCodeList(List<TransactionStatusType> statusCodeList) {
        this.statusCodeList = statusCodeList;
    }
    
    public List<TransactionType> getTransactionTypeCodeList() {
        return transactionTypeCodeList;
    }
    
    public void setTransactionTypeCodeList(List<TransactionType> transactionTypeCodeList) {
        this.transactionTypeCodeList = transactionTypeCodeList;
    }
    
    public List<String> getIntlRegistrationNumberList() {
        return intlRegistrationNumberList;
    }
    
    public void setIntlRegistrationNumberList(List<String> intlRegistrationNumberList) {
        this.intlRegistrationNumberList = intlRegistrationNumberList;
    }
    
    public List<String> getDomesticAppNumberList() {
        return domesticAppNumberList;
    }
    
    public void setDomesticAppNumberList(List<String> domesticAppNumberList) {
        this.domesticAppNumberList = domesticAppNumberList;
    }
    
    
}
