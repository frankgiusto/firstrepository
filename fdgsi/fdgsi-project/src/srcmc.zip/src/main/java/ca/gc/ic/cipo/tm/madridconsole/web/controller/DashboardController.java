package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import ca.gc.ic.cipo.tm.madridconsole.service.TaskDetailsService;
import ca.gc.ic.cipo.tm.madridconsole.service.mef.MEFServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.web.TaskDataTableService;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridGroup;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionList;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionType;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;

/**
 * The Class DashboardController handles the requests that are common to all task (notifications, my tasks and task
 * bucket) views and returns the response.
 */
@Controller
@RequestMapping("/dashboard")
public class DashboardController {

    /** The logger. */
    private static Logger logger = Logger.getLogger(DashboardController.class.getName());

    /** The task details service. */
    @Autowired
    private TaskDetailsService taskDetailsService;

    /** The user profile service. */
    @Autowired
    private UserProfileServiceClient userProfileService;

    /** The MEF service. */
    @Autowired
    private MEFServiceClient mefService;

    /** The data table service. */
    @Autowired
    private TaskDataTableService dataTableService;

    /** The transaction service. */
    @Autowired
    private TransactionServiceClient transactionService;

    /**
     * Handles the request to get the my tasks page.
     *
     * @param locale the locale
     * @param model the model
     * @return the string the jsp page to go to
     */
    @RequestMapping("")
    public String dashboard(Locale locale, Model model, HttpSession session) {

        // Remove the lock on the FileNumber/Extension (if there is one)
        removeLock(session);

        return "dashboard";
    }

    /**
     * Handles the request to get the Task bucket page.
     *
     * @param locale the locale
     * @param model the model
     * @return the string the jsp page to go to
     */
    @RequestMapping(value = "/taskBucket", method = RequestMethod.GET)
    public String taskBucket(Locale locale, Model model, HttpSession session) {

        // Remove the lock on the FileNumber/Extension (if there is one)
        removeLock(session);

        return "taskBucket";
    }

    /**
     * Handles the request to get the Notifications page if the logged in user is a supervisor, else redirects to My
     * Tasks page.
     *
     * @param locale the locale
     * @param model the model
     * @return the string the jsp page to go to
     */
    @RequestMapping(value = "/notifications", method = RequestMethod.GET)
    public String notifications(@RequestParam(required = false, defaultValue = "false", value = "init") boolean init,
                                HttpSession session, HttpServletRequest request, Locale locale, Model model) {

        // Remove the lock on the FileNumber/Extension (if there is one)
        removeLock(session);

        if (locale == null) {
            request.setAttribute("displayLanguage", "en");
        } else {
            request.setAttribute("displayLanguage", locale.getLanguage());

        }

        // if its the first time the user is logging in, then redirect to the page based on their role
        if (init) {
            if (MadridGroup.isSupervisor(userProfileService.getCurrentSelectedRole(request))) {
                return "redirect:/dashboard/notifications?lang=" + locale.getLanguage();
            } else {
                return "redirect:/dashboard?lang=" + locale.getLanguage();
            }
        } else {
            return "notifications";
        }
    }

    /**
     * Handles the request to get the Wipo transmissions page.
     *
     * @param locale the locale
     * @param model the model
     * @return the string the jsp page to go to
     */
    @RequestMapping(value = "/wipotransmissions", method = RequestMethod.GET)
    public String wipotransmissions(Locale locale, Model model, HttpSession session, HttpServletRequest request,
                                    HttpServletResponse response) {

        logger.debug("Method: wipotransmissions");

        // Remove the lock on the FileNumber/Extension (if there is one)
        removeLock(session);

        if (locale == null) {
            request.setAttribute("displayLanguage", "en");
        } else {
            request.setAttribute("displayLanguage", locale.getLanguage());

        }

        // Maximum date for the calendar.
        Calendar cal = Calendar.getInstance();
        String today = String.format("%4d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH));
        request.setAttribute("today", today);
        cal.add(Calendar.YEAR, -1);
        String minDate = String.format("%4d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH));
        request.setAttribute("minDate", minDate);

        return "wipotransmissions";
    }

    /**
     * Handles the request to get the help page.
     *
     * @param locale the locale
     * @param model the model
     * @return the string the jsp page to go to
     */
    @RequestMapping(value = "/help", method = RequestMethod.GET)
    public String help(Locale locale, Model model) {

        return "help";
    }

    /**
     * Handles the request to get the page defined in panel - 1 for notifications, 2 for my tasks and 3 for task bucket.
     *
     * @param panel the panel
     * @param request the request
     * @param response the response
     * @param session the session
     * @throws Exception the exception
     */
    @RequestMapping(value = "/init", method = RequestMethod.POST)
    public void init(@RequestParam(value = "panel", required = true) Integer panel, HttpServletRequest request,
                     HttpServletResponse response, HttpSession session)
        throws Exception {

        session.setAttribute("initDashboard", false);
        session.setAttribute("tableNum", panel);
    }

    /**
     * Stream file to save or open as attachment when a PDF attachment link is clicked under the Transactions/Attachment
     * column in the datatable on my tasks, notifications and task bucket pages.
     *
     * @param attachmentId the attachment id
     * @param filename the filename
     * @param request the http request
     * @param response the response being send back
     * @param session the http session
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws CIPOServiceFault the CIPO service fault
     */
    @RequestMapping(value = "/getFile", method = RequestMethod.GET)
    public void streamFile(@RequestParam(value = "attachId", required = true) Integer attachmentId,
                           @RequestParam(value = "filename", required = true) String filename,
                           HttpServletRequest request, HttpServletResponse response, HttpSession session) {

        logger.debug("Method: streamFile: Streaming file " + filename + ", with attachment id " + attachmentId);

        byte[] attachment = null;
        OutputStream outputStream = null;

        try {
            attachment = IOUtils.toByteArray(
                taskDetailsService.getTransactionAttachment(BigDecimal.valueOf(attachmentId)).getInputStream());

            response.setHeader("Content-Disposition", "attachment; filename=" + filename);
            response.setHeader("Content-Type", "application/octet-stream");
            response.setHeader("Content-Length", String.valueOf(attachment.length));

            outputStream = response.getOutputStream();

            outputStream.write(attachment);
            outputStream.flush();
            outputStream.close();
        } catch (IOException | MCServerException e) {
            try {
                logger.error(
                    "Method: streamFile: Error streaming file " + filename + ", with attachment id " + attachmentId);
                logger.error("Exception: ", e);
                if (null != outputStream) {
                    outputStream.close();
                }
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }

    /**
     * Handles the request to change role when the user switches the role from the drop down list on the top-right
     * corner of all pages. Calls the Trademarks User Profile service (TUPS) client to set the current selected role to
     * the new role
     *
     * @param role the role to switch to
     * @param request the http request sent when the user switches the role
     * @param response the response sent back once the role has been changed
     * @param session the http session when the request is made
     * @throws Exception the exception
     */
    @RequestMapping(value = "/changerole", method = RequestMethod.POST)
    public void changerole(@RequestParam(value = "role", required = true) String role, HttpServletRequest request,
                           HttpServletResponse response, HttpSession session) {

        logger.debug("Method: changerole: role " + role);

        String authId = "";
        String roleWithoutAuthID = "";

        if (!role.isEmpty()) {
            int index = role.lastIndexOf("-");
            if (index != -1) {
                roleWithoutAuthID = role.substring(0, index);
                authId = role.substring(index + 1);
            } else {
                roleWithoutAuthID = role;
            }
        }
        userProfileService.setCurrentSelectedRole(request, MadridGroup.getTupsAuthority(roleWithoutAuthID));

        userProfileService.setAuthorityId(request, authId);
    }

    /**
     * Handles the request to get the last selected role, so that when the page is refreshed/switched, it can reset the
     * role back to the last selected role in the drop down list on the top-right corner of all pages. Calls the
     * Trademarks User Profile service (TUPS) client to get the current selected role
     *
     * @param request the http request sent when the user switches the role
     * @param response the response sent back once the role has been changed
     * @param session the http session when the request is made
     * @return the role the currently selected role to return back
     * @throws Exception the exception
     */
    @RequestMapping(value = "/getrole", method = RequestMethod.GET)
    public void getrole(HttpServletRequest request, HttpServletResponse response, HttpSession session)
        throws Exception {

        logger.debug("Method: getrole");

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");

        PrintWriter out = response.getWriter();

        JSONObject result = new JSONObject();
        result.put("role", MadridGroup.getMadridGroupName(userProfileService.getCurrentSelectedRole(request)));
        out.print(result);
    }

    /**
     * Handles the request to check if the current user is a supervisor or not. Calls the Trademarks User Profile
     * service (TUPS) client to get the current selected role
     *
     * @param request the http request sent when the user switches the role
     * @param response the response sent back once the role has been changed
     * @param session the http session when the request is made
     * @throws Exception the exception
     */
    @RequestMapping(value = "/issuper", method = RequestMethod.GET)
    public void issuper(HttpServletRequest request, HttpServletResponse response, HttpSession session)
        throws Exception {

        logger.debug("Method: issuper");

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");

        PrintWriter out = response.getWriter();

        JSONObject result = new JSONObject();
        result.put("issuper", MadridGroup.isSupervisor(userProfileService.getCurrentSelectedRole(request)));
        out.print(result);
    }

    /**
     * Launch MEF.
     *
     * @param request the request sent when the user wants to launch MEF from the console
     * @param response the response to send back with the url to open MEF on another page
     * @param session the http session when the request is made
     * @return the string containing the MEF url to be redirected to
     * @throws MCServerException
     * @throws Exception the exception
     */
    @RequestMapping(value = "/launchMEF", method = RequestMethod.GET)
    public String launchMEF(HttpServletRequest request, HttpServletResponse response, HttpSession session)
        throws MCServerException {

        logger.debug("Method: launchMEF");

        String irpiUrl = "";
        try {
            irpiUrl = mefService.getIRPIURLSessionForOfficeUser(userProfileService.getLdapUsername(request));
        } catch (MCServerException e) {

            try {
                response.sendError(503, e.getMessage());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        logger.debug("Method: launchMEF with irpiURL = " + irpiUrl);

        return "redirect:" + irpiUrl;
    }

    /**
     * Handles the request to get all the roles in case the language changed.
     *
     * @param request the http request sent when the user switches the role
     * @param response the response sent back once the role has been changed
     * @param session the http session when the request is made
     * @return the role the currently selected role to return back
     * @throws Exception the exception
     */
    @RequestMapping(value = "/getallroles", method = RequestMethod.GET)
    public void getallroles(HttpServletRequest request, HttpServletResponse response, HttpSession session)
        throws Exception {

        logger.debug("Method: getallroles");

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");

        PrintWriter out = response.getWriter();

        JSONObject result = new JSONObject();
        JSONArray taskList = new JSONArray();

        // get the valid user authorities
        for (UserAuthority tupAuth : userProfileService.getUserAuthorities(request)) {
            taskList
                .put(MadridGroup.getMadridGroupName(tupAuth.getIntlAuthorityRole()) + "-" + tupAuth.getAuthorityId());
        }
        // set the current authority role for the drop down on the top right corner
        result.put("role", MadridGroup.getMadridGroupName(userProfileService.getCurrentSelectedRole(request)) + "-"
            + userProfileService.getAuthorityId(request));
        result.put("roles", taskList);
        out.print(result);
    }

    /**
     * Handles request from my tasks page.
     *
     * @param tableNum the table num of the datatable being displayed on my tasks page
     * @param request the request
     * @param response the response
     */
    @RequestMapping(value = "/getuncompletedtasks", method = RequestMethod.GET)
    public void getuncompletedtasks(HttpServletRequest request, HttpServletResponse response) {

        logger.debug("Method: getUncompletedTasksForIR for IR " + request.getParameter("id_filter_iair"));

        response.setContentType("application/json");
        response.setHeader("Cache-Control", "no-store");

        try {
            String message = dataTableService.getUncompletedTasksForIR(request,
                TransactionServiceClient.TASK_BUCKET_TABLE);

            PrintWriter out = response.getWriter();
            out.print(message);

        } catch (MCServerException | IOException e) {
            try {
                logger.error("Exception: ", e);
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
            }
        }
    }

    public JSONArray sortJSONArrayAlphabetically(JSONArray jArray) throws JSONException {

        ArrayList<String> sortedArray = new ArrayList<String>();

        if (jArray != null) {
            for (int i = 0; i < jArray.length(); i++) {
                sortedArray.add(jArray.get(i).toString());
            }
            Collections.sort(sortedArray);
            jArray = new JSONArray(sortedArray);
        }

        return jArray;
    }

    /**
     * Handles the request to get the list of description for a panel - 1 for notifications, 2 for my tasks and 3 for
     * task bucket.
     *
     * @param panel the panel
     * @param request the request
     * @param response the response
     * @param session the session
     * @throws Exception the exception
     */
    @RequestMapping(value = "/desclist", method = RequestMethod.GET)
    public void getDescriptions(@RequestParam(value = "panel", required = true) Integer panel, Locale locale,
                                HttpServletRequest request, HttpServletResponse response, HttpSession session)
        throws Exception {

        response.setContentType("application/json");
        response.setCharacterEncoding("ISO-8859-1");
        response.setHeader("Cache-Control", "no-store");

        JSONArray descriptions = new JSONArray();
        TaskDescriptionListResponse resp = this.transactionService.getDescriptions(panel);

        TaskDescriptionList desclist = resp.getTaskDescriptionList();
        if (desclist != null) {
            for (TaskDescriptionType desc : desclist.getTaskListBag()) {
                if (locale == null || locale.getLanguage().equals("en")) {
                    descriptions.put(desc.getTaskCtgryDescEn());
                } else {
                    descriptions.put(desc.getTaskCtgryDescFr());
                }
            }
        }
        try {
            PrintWriter out = response.getWriter();
            JSONObject result = new JSONObject();

            result.put("count", descriptions.length());
            result.put("descriptions", sortJSONArrayAlphabetically(descriptions));
            out.print(result);
        } catch (IOException | JSONException e) {
            try {
                logger.error("Exception: ", e);
                // e.printStackTrace();
                response.sendError(HttpServletResponse.SC_OK, e.getMessage());
            } catch (IOException e1) {
                logger.error("Exception: ", e1);
                // e1.printStackTrace();
            }
        }
    }

    /**
     * Handles the request to clear all the filters in the session.
     *
     * @param panel the panel
     * @param locale the locale
     * @param request the request
     * @param response the response
     * @param session the session
     * @return the descriptions
     * @throws Exception the exception
     */
    @RequestMapping(value = "/clearfilteroptions", method = RequestMethod.GET)
    public void clearFilterOptionsInSession(HttpServletRequest request, HttpServletResponse response) throws Exception {

        request.getSession().removeAttribute("iair");
        request.getSession().removeAttribute("fileid");
        request.getSession().removeAttribute("startdate");
        request.getSession().removeAttribute("enddate");
        request.getSession().removeAttribute("mdesc");
        request.getSession().removeAttribute("ndesc");
        request.getSession().removeAttribute("mgroup");
        request.getSession().removeAttribute("ngroup");
    }

    public void removeLock(HttpSession session) {
        logger.debug("Session destroyed ");

        GoodServiceWipoBean gsBean = (GoodServiceWipoBean) session.getAttribute("wipogs");

        // Release the LOCK on the File Number/Extension
        try {

            if (gsBean != null && gsBean.getApplication() != null  && gsBean.getApplication().getApplicationNumber() != null)
            {
                transactionService.releaseLock( gsBean);
            }
        } catch (MCServerException e) {
            logger.error("sessionDestroyed, Errors attempting to release Lock." + e.getMessage() );
        }

    }

}
