package ca.gc.ic.cipo.tm.madridconsole.web.validator;

import org.apache.log4j.Logger;
import org.springframework.validation.Errors;

import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;

public class EditMailingLabelValidator  {
    
    // Log4J logger.
    private final Logger logger = Logger.getLogger(getClass());
      
    // The Maximum number of Lines allowed, in the Mailing Label
    private static final int maxNumberLines = 8;
    
    // The Maximum number of Characters per line allowed, in the Mailing Label
    private static final int maxNumberCharacters = 40;

    //
    // Items to Validate
    //      1.  There has to be something present in the Mailing Label. (i.e., it cannot be empty)
    //      2.  The number of lines cannot be greater than 8
    //      3.  Each line cannot be greater than 40 characters
    //
    public void validate (GoodServiceWipoBean goodServiceWipoBean, Errors errors) {

        logger.debug("Validate Mailing Label, Mailing Label: " + goodServiceWipoBean.getMailingLabel() );          

        // Check that there has to be something present in the Mailing Label. (i.e., it cannot be empty)  
        if (goodServiceWipoBean.getMailingLabel() == null 
            || goodServiceWipoBean.getMailingLabel().trim().isEmpty()) {
            errors.rejectValue("mailingLabel", null, "mc.edit.mailing.address.error.line.rqd");
            return;
        }
        
        // Check the number of lines, the number of lines cannot be greater than 8
        String[] lines = goodServiceWipoBean.getMailingLabel().split("\r\n|\r|\n");
        if (lines.length > maxNumberLines){ 
            
            String[] params = new String[1];
            params[0] = Integer.toString(lines.length);
            errors.rejectValue("mailingLabel", null, MadridConsoleUtils.getMessage("mc.edit.mailing.address.error.line.cnt", params));
            return;
        }
        
        // Check that each line cannot be greater than 40 characters
        for (int x=0; x< lines.length; x++) {
            if (lines[x].length() > maxNumberCharacters) {
                String[] params = new String[2];
                params[0] = Integer.toString(x + 1);
                params[1] = Integer.toString(lines[x].length());
                errors.rejectValue("mailingLabel", null, MadridConsoleUtils.getMessage("mc.edit.mailing.address.error.word.cnt", params));
                return;
            }
        }
        
        
        
    }
}
