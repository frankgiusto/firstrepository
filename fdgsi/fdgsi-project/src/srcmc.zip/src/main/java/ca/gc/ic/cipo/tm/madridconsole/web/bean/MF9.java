package ca.gc.ic.cipo.tm.madridconsole.web.bean;

import java.io.Serializable;

import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;


public class MF9 implements Serializable {

    private static final long serialVersionUID = 1L;
    
    ProcessManualReportRequest mf9Request = new ProcessManualReportRequest();

    
    public ProcessManualReportRequest getMf9Request() {
        return mf9Request;
    }

    
    public void setMf9Request(ProcessManualReportRequest mf9Request) {
        this.mf9Request = mf9Request;
    }

}
