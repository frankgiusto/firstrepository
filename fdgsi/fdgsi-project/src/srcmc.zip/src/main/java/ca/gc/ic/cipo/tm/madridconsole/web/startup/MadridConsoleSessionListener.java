package ca.gc.ic.cipo.tm.madridconsole.web.startup;

import java.math.BigInteger;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;

public class MadridConsoleSessionListener implements HttpSessionListener {
	private static final Logger logger = Logger.getLogger(MadridConsoleSessionListener.class);
	
    @Autowired
    TransactionServiceClient transactionServiceClient;


	@Override
	public void sessionDestroyed(HttpSessionEvent sessionEvent) {
		logger.debug("Session destroyed ");
		
		GoodServiceWipoBean gsBean = (GoodServiceWipoBean) sessionEvent.getSession().getAttribute("wipogs");
		
        // Release the LOCK on the File Number/Extension
        try {
            
                if (gsBean != null) {
                    logger.debug("Session destroyed - GSBean Release Lock on file number:  " + gsBean.getFileNumberLocked());

                    getTransactionServiceClient(sessionEvent).releaseLock( gsBean);
                }
        } catch (MCServerException e) {
            logger.error("sessionDestroyed, Errors attempting to release Lock." + e.getMessage() );
        }

		
	} // End of the sessionDestroyed method.


	 private TransactionServiceClient getTransactionServiceClient(HttpSessionEvent se) {
	     WebApplicationContext context = 
	       WebApplicationContextUtils.getWebApplicationContext(
	         se.getSession().getServletContext());
	     return (TransactionServiceClient) context.getBean("transactionServiceClient");
	   } 
	
    @Override
    public void sessionCreated(HttpSessionEvent arg0) {
        // TODO Auto-generated method stub
        
    }
} // End of the MadridConsoleSessionListener class.
