package ca.gc.ic.cipo.tm.madridconsole.service.mts;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import ca.gc.ic.cipo.tm.intl.enumerator.SortColumn;
import ca.gc.ic.cipo.tm.intl.enumerator.SortOrder;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridGroup;
import ca.gc.ic.cipo.tm.madridconsole.util.SendErrorEmail;
import ca.gc.ic.cipo.tm.madridconsole.util.ServiceUtil;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mts.AcquireTrademarkLockRequest;
import ca.gc.ic.cipo.tm.mts.AttachmentDetail;
import ca.gc.ic.cipo.tm.mts.CIPOServiceFault;
import ca.gc.ic.cipo.tm.mts.ConsoleTaskStatusType;
import ca.gc.ic.cipo.tm.mts.GetManualReportRequest;
import ca.gc.ic.cipo.tm.mts.GetTransactionByIntlRecordIdRequest;
import ca.gc.ic.cipo.tm.mts.GetTransactionByIntlRecordIdResponse;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.LanguageType;
import ca.gc.ic.cipo.tm.mts.MadridTransactionServicePortType;
import ca.gc.ic.cipo.tm.mts.MailTransactionType;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessIrregularitySubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ProcessModifiedRepAddressSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ReleaseTrademarkLockRequest;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListResponse;
import ca.gc.ic.cipo.tm.mts.TaskDescriptionListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.TaskRequestType;
import ca.gc.ic.cipo.tm.mts.TaskSubjectCategory;
import ca.gc.ic.cipo.tm.mts.TransactionDetail;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListResponse;
import ca.gc.ic.cipo.tm.mts.WorkflowTaskListSearchCriteria;
import ca.gc.ic.cipo.tm.mts.client.common.MadridTransactionServiceFactory;
import ca.gc.ic.cipo.tm.userprofile.schema.UserAuthority;

/**
 * The Class TransactionServiceClient is a Madrid Transaction Service (MTS) web service client.
 *
 * @author kaurs
 */
@Service
public class TransactionServiceClient {

    /** The madrid transaction endpoint from the intl database INTL_CNFGN_PARM table. */
    @Value("${mc.madrid.transaction.endpoint}")
    private String madridTransactionEndpoint;

    private static Logger logger = Logger.getLogger(TransactionServiceClient.class.getName());

    /** The user profile service. */
    @Autowired
    private UserProfileServiceClient userProfileService;

    /* Email Error Notifications */
    @Autowired
    SendErrorEmail sendErrorEmail;

    /** The Constant NUM_OF_SORTABLE_COLS. */
    public static final int NUM_OF_SORTABLE_COLS = 4;

    /** The Constant IR_NUM_COL. */
    public static final String IR_NUM_COL = "1";

    /** The Constant FILE_NUM_COL. */
    public static final String FILE_NUM_COL = "2";

    /** The Constant TASK_DATE_COL. */
    public static final String DESCRIPTION_COL = "3";

    /** The Constant TASK_DATE_COL. */
    public static final String TASK_DATE_COL = "4";

    /** The Constant ASSIGNED_TO_COL. */
    public static final String ASSIGNED_TO_COL = "6";

    /** The Constant CREATION_DATE - my Tasks. */
    public static final String CREATION_DATE_MY_TASK = "6";

    /** The Constant CREATION_DATE - my Tasks. */
    public static final String CREATION_DATE_ALL_TASK = "7";

    /** The Constant NOTIFICATIONS_TABLE. */
    public static final Integer NOTIFICATIONS_TABLE = 1;

    /** The Constant MY_TASKS_TABLE. */
    public static final Integer MY_TASKS_TABLE = 2;

    /** The Constant TASK_BUCKET_TABLE. */
    public static final Integer TASK_BUCKET_TABLE = 3;

    public String filterIAIR = "";

    /**
     * Gets the Madrid Transaction Service client.
     *
     * @return the client
     * @throws MCServerException
     */
    private MadridTransactionServicePortType getClient() throws MCServerException {

        MadridTransactionServicePortType madridTransactionClient = MadridTransactionServiceFactory
            .createMadridTransactionClient(madridTransactionEndpoint);

        if (madridTransactionClient == null) {
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.serviceunavailable"));
        }

        return madridTransactionClient;
    }

    /**
     * Gets the list of work flow tasks depending upon the view specified by the table number.
     *
     * @param request the request to display the tasks
     * @param tableNum the table number indicates which view is being updated to display tasks
     * @param saveFilterCriteria (boolean) indicating if Filter Criteria is to be saved.
     * @return the list of work flow tasks
     * @throws CIPOServiceFault the CIPO service fault indicating any error from MTS
     * @throws MCServerException
     */
    public WorkflowTaskListResponse getListOfWorkflowTasks(HttpServletRequest request, int tableNum,
                                                           boolean saveFilterCriteria, boolean obtainAllTaskSubjectCategory)
        throws MCServerException {

        logger.debug("Method: getListOfWorkflowTasks - tableNum " + tableNum);

        Map<String, String[]> reqMap = request.getParameterMap();

        // apply the sort order and direction
        WorkflowTaskListSearchCriteria criteria = new WorkflowTaskListSearchCriteria();

        // If obtainAllTaskSubjectCategory is true, get both MANUAL tasks and NOTIFICATION Tasks,
        // else get either MANUAL or NOTIFICATION tasks (based on the Table Number)
        if (obtainAllTaskSubjectCategory ) {
            criteria.setTaskSubjectCategory(TaskSubjectCategory.ALL);
        } else {
            criteria.setTaskSubjectCategory((tableNum == NOTIFICATIONS_TABLE ? TaskSubjectCategory.NOTIFICATION
                : (tableNum == MY_TASKS_TABLE || tableNum == TASK_BUCKET_TABLE) ? TaskSubjectCategory.MANUAL : null));
        }

        applySortingCriteria(request, criteria, tableNum );

        // set the starting row and number of rows to display for the page
        applyPagingCriteria(request, criteria);

        // apply filter criteria's
        applyFilterCriteriaIRAndFileNum(request, criteria, saveFilterCriteria);
        applyFilterCriteriaStartAndEndDates(request, criteria, saveFilterCriteria);
        applyFilterCriteriaStatus(request, criteria);
        applyFilterCriteriaGroup(request, criteria, saveFilterCriteria, tableNum);
        applyFilterCriteriaAssignedTo(request, criteria, tableNum);
        applyFilterCriteriaUser(request, criteria, tableNum);
        applyFilterCriteriaDescription(request, criteria, saveFilterCriteria, tableNum);

        // Call the MTS web service to get list of tasks
        try {
            WorkflowTaskListResponse WorkflowTaskListResponse = getClient().getWorkflowTaskList(criteria);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return WorkflowTaskListResponse;

        } catch (CIPOServiceFault e) {

            logger.error("Method: getListOfWorkflowTasks - tableNum " + tableNum);

            for (String reqparam : reqMap.keySet()) {
                logger.error(
                    "Method: getListOfWorkflowTasks - req filter param " + reqparam + " : " + reqMap.get(reqparam));
            }
            ServiceUtil.objectToXML(e.getFaultInfo());
            logger.error("Method: getListOfWorkflowTasks - Error retrieving workflow tasks from MTS " + tableNum + ": "
                + e.getMessage());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.workflowtasks"), e);

        } catch (Exception e) {

            logger.error("Method: getListOfWorkflowTasks - tableNum " + tableNum);

            /*
             * for (String reqparam : reqMap.keySet()) { logger.error(
             * "Method: getListOfWorkflowTasks - req filter param " + reqparam + " : " + reqMap.get(reqparam)); }
             */
            logger.error("Method: getListOfWorkflowTasks - Error retrieving workflow tasks from MTS " + tableNum + ": "
                + e.getMessage());
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "updateServiceStatus()",
                e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.workflowtasks"), e);

        } catch (Throwable e) {

            logger.error("Method: getListOfWorkflowTasks - Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "updateServiceStatus()",
                e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.workflowtasks"), e);
        }
    }

    private void applyFilterCriteriaDescription(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria,
                                                boolean saveFilterCriteria, int tableNum) {

        String filterDesc = request.getParameter("id_filter_desc");

        if (!filterDesc.equalsIgnoreCase("All")) {
            Locale locale = LocaleContextHolder.getLocale();
            if (locale.getLanguage().equals("fr")) {
                criteria.setTaskCategoryDescriptionFrench(filterDesc);
            } else {
                criteria.setTaskCategoryDescriptionEnglish(filterDesc);
            }
            logger.debug("Method: applyFilterCriteriaDesc: description - " + filterDesc);
        }
        if (saveFilterCriteria) {
            if (tableNum == NOTIFICATIONS_TABLE) {
                request.getSession().setAttribute("ndesc", filterDesc);
            } else {
                request.getSession().setAttribute("mdesc", filterDesc);
            }
        }
    }

    private void applySortingCriteria(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria, int tableNum) {

        // Get request parameters and set the sort order and direction
        List<String> sortColumn = new ArrayList<>();
        List<String> sortDirection = new ArrayList<>();

        String param;
        String paramDir;
        String paramValue;

        // only four columns can be sorted upon - task date, IR#, File# and Assigned To columns
        for (int i = 0; i < NUM_OF_SORTABLE_COLS; i++) {
            param = "order[" + i + "][column]";
            paramDir = "order[" + i + "][dir]";
            paramValue = request.getParameter(param);
            if (paramValue != null) {
                switch (paramValue) {
                    case DESCRIPTION_COL:
                        Locale locale = LocaleContextHolder.getLocale();
                        if (locale.getLanguage().equals("fr")) {
                            sortColumn.add(SortColumn.TASK_DESC_EN.name());
                        } else {
                            sortColumn.add(SortColumn.TASK_DESC_FR.name());
                        }
                        break;
                    case TASK_DATE_COL:
                        sortColumn.add(SortColumn.INTL_RECORD_EFCTV_DT.name());
                        break;
                    case IR_NUM_COL:
                        sortColumn.add(SortColumn.INTL_REG_NO.name());
                        break;
                    case FILE_NUM_COL:
                        sortColumn.add(SortColumn.DMSTC_APLTN_FILE_NBR.name());
                        break;
                    case ASSIGNED_TO_COL:    // NOTE:  COLUMN 6 is different for either MY_TASKS_TABLE and TASK_BUCKET_TABLE
                        if (tableNum == MY_TASKS_TABLE) {
                            sortColumn.add(SortColumn.CREATED_TMSTMP.name());
                        }
                        if (tableNum == TASK_BUCKET_TABLE) {
                            sortColumn.add(SortColumn.GROUP_ID_.name());
                      }
                        break;
                    case CREATION_DATE_ALL_TASK:
                        sortColumn.add(SortColumn.CREATED_TMSTMP.name());
                        break;

                }
                // set the sort direction for each of the sorted columns
                if (request.getParameter(paramDir).equalsIgnoreCase("desc")) {
                    sortDirection.add(SortOrder.DESC.name());
                } else {
                    sortDirection.add(SortOrder.ASC.name());
                }

            } else {
                break;
            }
        }
        if (sortColumn.isEmpty()) {
            sortColumn.add(SortColumn.INTL_RECORD_EFCTV_DT.name());
            sortColumn.add(SortColumn.INTL_REG_NO.name());
            sortColumn.add(SortColumn.DMSTC_APLTN_FILE_NBR.name());
            Locale locale = LocaleContextHolder.getLocale();
            if (locale.getLanguage().equals("fr")) {
                sortColumn.add(SortColumn.TASK_DESC_EN.name());
            } else {
                sortColumn.add(SortColumn.TASK_DESC_FR.name());
            }

            sortDirection.add(SortOrder.ASC.name());
            sortDirection.add(SortOrder.ASC.name());
            sortDirection.add(SortOrder.ASC.name());
            sortDirection.add(SortOrder.ASC.name());
        } else {
            logger.debug("Method: applySortingCriteria: sort column - " + sortColumn);
            logger.debug("Method: applySortingCriteria: sort direction - " + sortDirection);
        }
        criteria.getSortColumn().addAll(sortColumn);
        criteria.getSortDirection().addAll(sortDirection);
    }

    private void applyPagingCriteria(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria) {

        int startRow = 0;
        int rowsPerPage = 10;

        if (StringUtils.isNotBlank(request.getParameter("start"))) {
            startRow = Integer.valueOf(request.getParameter("start"));
            rowsPerPage = Integer.valueOf(request.getParameter("length"));
        }
        criteria.setRowsPerPage(BigInteger.valueOf(rowsPerPage));
        criteria.setStartRow(BigInteger.valueOf(startRow));

        // logger.debug("Method: applyPagingCriteria: rowsPerPage - " + criteria.getRowsPerPage());
        // logger.debug("Method: applyPagingCriteria: startRow - " + criteria.getStartRow());
    }

    private void applyFilterCriteriaIRAndFileNum(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria,
                                                 boolean saveFilterCriteria) {

        filterIAIR = request.getParameter("id_filter_iair");
        String filterReferFileId = request.getParameter("id_filter_referfileid");

        if (saveFilterCriteria) {
            request.getSession().setAttribute("iair", filterIAIR);
            request.getSession().setAttribute("fileid", filterReferFileId);
        }

        // set international registration number if available
        if (StringUtils.isNotBlank(filterIAIR)) {
            criteria.setIntlRegNo(filterIAIR);
            logger.debug("Method: applyFilterCriteriaIRAndFileNum: IAIR - " + criteria.getIntlRegNo());
        }
        // set reference file number if available
        if (StringUtils.isNotBlank(filterReferFileId)) {
            criteria.setDmstcApltnFileNbr(new BigDecimal(filterReferFileId));
            logger.debug("Method: applyFilterCriteriaIRAndFileNum: ReferFileId - " + criteria.getDmstcApltnFileNbr());
        }
    }

    private void applyFilterCriteriaStartAndEndDates(HttpServletRequest request,
                                                     WorkflowTaskListSearchCriteria criteria,
                                                     boolean saveFilterCriteria)
        throws MCServerException {

        String filterStartDate = request.getParameter("startdate");
        String filterEndDate = request.getParameter("enddate");

        if (saveFilterCriteria) {
            request.getSession().setAttribute("startdate", filterStartDate);
            request.getSession().setAttribute("enddate", filterEndDate);
        }
        // set start date if available
        if (StringUtils.isNotBlank(filterStartDate)) {
            Date startdate;
            try {
                startdate = DateFormats.getISOSDF().parse(filterStartDate);
                criteria.setRecordEffectiveStartDate(startdate);
                logger.debug("Method: applyFilterCriteriaStartAndEndDates: start date - "
                    + criteria.getRecordEffectiveStartDate());
            } catch (ParseException e) {
                logger
                    .error("Method: applyFilterCriteriaStartAndEndDates - Error parsing start date " + filterStartDate);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.parsingdateerror"), e);
            }
        }
        // set end date if available
        if (StringUtils.isNotBlank(filterEndDate)) {
            Date enddate;
            try {
                enddate = DateFormats.getISOSDF().parse(filterEndDate);
                criteria.setRecordEffectiveEndDate(enddate);
                logger.debug(
                    "Method: applyFilterCriteriaStartAndEndDates: end date - " + criteria.getRecordEffectiveEndDate());
            } catch (ParseException e) {
                logger.error("Method: applyFilterCriteriaStartAndEndDates - Error parsing end date " + filterEndDate);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.parsingdateerror"), e);
            }
        }
    }

    private void applyFilterCriteriaStatus(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria) {

        String filterStatus = request.getParameter("id_filter_status");

        if (StringUtils.isNotBlank(filterStatus)) {
            switch (filterStatus) {
                case "U":
                    criteria.setTaskStatus(ConsoleTaskStatusType.UNPROCESSED);
                    break;
                case "CP":
                    criteria.setTaskStatus(ConsoleTaskStatusType.PROCESSED);
                    break;
                case "CU":
                    criteria.setTaskStatus(ConsoleTaskStatusType.CLOSED_UNPROCESSED);
                    break;
                case "H":
                    criteria.setTaskStatus(ConsoleTaskStatusType.ON_HOLD);
                    break;
                case "E":
                    criteria.setTaskStatus(ConsoleTaskStatusType.ERROR);
                    break;
                case "A": // don't set the status
                    break;
            }
            logger.debug("Method: applyFilterCriteriaStatus: start date - " + criteria.getTaskStatus());
        } else {
            // this is the default if nothing is set
            criteria.setTaskStatus(ConsoleTaskStatusType.UNPROCESSED);
        }
    }

    private void applyFilterCriteriaGroup(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria,
                                          boolean saveFilterCriteria, int tableNum)
        throws MCServerException {

        String filterGroup = request.getParameter("id_filter_group");

        if (StringUtils.isNotBlank(filterGroup)) {

            if (saveFilterCriteria) {
                if (tableNum == NOTIFICATIONS_TABLE) {
                    request.getSession().setAttribute("ngroup", filterGroup);
                } else {
                    request.getSession().setAttribute("mgroup", filterGroup);
                }
            }
            if (filterGroup.startsWith("All")) {

                // get the valid user authority groups associated with the logged in user
                for (UserAuthority tupAuth : userProfileService.getCurrentUserProfile(request).getUserAuthorities()) {
                    criteria.getGroupId().add(tupAuth.getIntlAuthorityRole());
                }
            } else {
                // This is set in the case of a supervisor. Convert the filter group to enum
                // groupIds.add(MadridGroup.getTupsAuthority(filterGroup));
                criteria.getGroupId().add(MadridGroup.getTupsAuthority(filterGroup));
            }
            logger.debug("Method: applyFilterCriteriaGroup: group - " + criteria.getGroupId());
        } else {
            // if group is not set as in my tasks page for supervisor, we need to show all tasks
            // from all groups, so no need to set group in that case
            if (!MadridGroup.isSupervisor(userProfileService.getCurrentSelectedRole(request))) {
                // this is the default if nothing is set
                criteria.getGroupId().add(userProfileService.getCurrentSelectedRole(request)); // Always required
            }
        }

    }

    private void applyFilterCriteriaAssignedTo(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria,
                                               int tableNum) {

        String filterClaimed = request.getParameter("id_filter_claimed");

        if (StringUtils.isNotBlank(filterClaimed)) {
            // This is set in the case of a supervisor in the task bucket page
            switch (filterClaimed) {
                case "U":
                    criteria.setTaskRequestType(TaskRequestType.UNCLAIMED);
                    break;
                case "C":
                    criteria.setTaskRequestType(TaskRequestType.CLAIMED_BY_ANY);
                    break;
                case "A":
                    criteria.setTaskRequestType(TaskRequestType.CLAIMED_AND_UNCLAIMED);
                    break;
            }
            logger.debug("Method: applyFilterCriteriaAssignedTo: task request type - "
                + criteria.getTaskRequestType().name() + ", " + criteria.getTaskRequestType().value());
        } else {
            // this is the default if nothing is set
            if (criteria.getTaskSubjectCategory().equals(TaskSubjectCategory.MANUAL)) {
                if (tableNum == MY_TASKS_TABLE) { // my tasks
                    criteria.setTaskRequestType(TaskRequestType.CLAIMED_BY_USER);
                } else { // task bucket
                    criteria.setTaskRequestType(TaskRequestType.UNCLAIMED);
                }
            } else if (criteria.getTaskSubjectCategory().equals(TaskSubjectCategory.NOTIFICATION)) {
                criteria.setTaskRequestType(TaskRequestType.CLAIMED_AND_UNCLAIMED);
            } else {
                criteria.setTaskRequestType(TaskRequestType.UNCLAIMED);
            }
        }
    }

    private void applyFilterCriteriaUser(HttpServletRequest request, WorkflowTaskListSearchCriteria criteria,
                                         int tableNum) {

        // this is is the format name-username
        String filterUser = request.getParameter("id_filter_users");

        if (tableNum == MY_TASKS_TABLE) { // in the case of my tasks, set it to the logged in user
            criteria.setUserId(userProfileService.getParentId(request));

        } else if (tableNum == TASK_BUCKET_TABLE) {

            if (StringUtils.isNotBlank(filterUser) && !filterUser.equalsIgnoreCase("All")) {

                // get the user name only, it should the last token in case the filter user has another "-"
                String[] user = filterUser.split("-");
                if (user.length >= 2) {
                    criteria.setUserId(user[user.length - 1]);
                    criteria.setTaskRequestType(TaskRequestType.CLAIMED_BY_USER);
                }
            }
        }
        logger.debug("Method: applyFilterCriteriaUser: user id - " + criteria.getUserId());
    }

    /**
     * Gets the transaction.
     *
     * @param transactionId the transaction id
     * @param includeXMLContent the include XML content
     * @param includeAttachmentContent the include attachment content
     * @return the transaction
     * @throws CIPOServiceFault the CIPO service fault
     */
    public TransactionDetail getTransaction(BigDecimal transactionId, boolean includeXMLContent,
                                            boolean includeAttachmentContent)
        throws MCServerException {

        logger.debug("Method: getTransaction: trans id - " + transactionId + ", includeXML - " + includeXMLContent
            + ", includeAttach - " + includeAttachmentContent);

        try {
            TransactionDetail transactionDetail = getClient().getTransaction(transactionId, includeXMLContent,
                includeAttachmentContent);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return transactionDetail;

        } catch (CIPOServiceFault e) {

            logger.error("Method: getTransaction, transactionId: " + transactionId + " includeXMLContent: "
                + includeXMLContent + " includeAttachmentContent: " + includeAttachmentContent);
            logger.error("Method: getTransaction, CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.gettransaction"), e);

        } catch (Throwable e) {

            logger.error("Method: getTransaction, transactionId: " + transactionId + " includeXMLContent: "
                + includeXMLContent + " includeAttachmentContent: " + includeAttachmentContent);
            logger.error("Method: getTransaction, Received Throwable ");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "getTransaction()",
                e.getMessage());

            // If MTS is DOWN, return message to the User.
            TransactionDetail transactionDetail = new TransactionDetail();
            transactionDetail
                .setXmlContent(MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service").getBytes());
            return transactionDetail;
        }
    }

    /**
     * Gets the transaction, by Record Identifier and IR Number
     *
     * @param recordIdentifier - Record Identifier
     * @param irNumber - IR Number
     * @return TransactionDetail - Original Transaction that the Correction is based on.
     * @throws CIPOServiceFault the CIPO service fault
     */
    public TransactionDetail getTransactionByIntlRecordId(String recordIdentifier, String irNumber)
        throws MCServerException {

        logger.debug("Method: getTransactionByIntlRecordId: recordIdentifier - " + recordIdentifier + ", irNumber - "
            + irNumber);

        GetTransactionByIntlRecordIdRequest transactionByIntlRecordIdRequest = new GetTransactionByIntlRecordIdRequest();

        transactionByIntlRecordIdRequest.setRecordIdentifier(recordIdentifier);
        transactionByIntlRecordIdRequest.setIrNumber(irNumber);
        transactionByIntlRecordIdRequest.setCorrectionTypeTransactionOnly(true);
        transactionByIntlRecordIdRequest.setIncludeXmlContent(true);
        transactionByIntlRecordIdRequest.setIncludeAttachmentContent(false);

        try {
            GetTransactionByIntlRecordIdResponse getTransactionByIntlRecordIdResponse = getClient()
                .getTransactionByIntlRecordId(transactionByIntlRecordIdRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return getTransactionByIntlRecordIdResponse.getTransactionDetail();

        } catch (CIPOServiceFault e) {

            logger.error("Method:  getTransactionByIntlRecordId: recordIdentifier - " + recordIdentifier
                + ", irNumber - " + irNumber);
            logger.error("Method: getTransactionByIntlRecordId, CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.gettransaction"), e);

        } catch (Throwable e) {

            logger.error("Method:  getTransactionByIntlRecordId: recordIdentifier - " + recordIdentifier
                + ", irNumber - " + irNumber);
            logger.error("Method: getTransactionByIntlRecordId, Received Throwable ");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint,
                "getTransactionByIntlRecordId()", e.getMessage());

            // If MTS is DOWN, return message to the User.
            TransactionDetail transactionDetail = new TransactionDetail();
            transactionDetail
                .setXmlContent(MadridConsoleUtils.getMessage("wipotransmissions.error.transaction.service").getBytes());
            return transactionDetail;
        }
    }

    /**
     * Process Manual Report (i.e., MF3A, MF13 or MF9).
     *
     * @param ProcessManualReportRequest - Request containing the MF data.
     * @return void
     * @throws CIPOServiceFault the CIPO service fault
     * @throws MCServerException
     */
    public void processManualReport(ProcessManualReportRequest processManualReportRequest) throws MCServerException {

        logger.debug("Method: processManualReport: ");

        try {
            getClient().processManualReport(processManualReportRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        } catch (CIPOServiceFault e) {

            logger.error("Method: processManualReport: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processmanualreport"), e);

        } catch (Throwable e) {

            logger.error("Method: processManualReport, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "processManualReport()",
                e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processmanualreport"), e);
        }
        return;
    }

    /**
     * Process Mailing Label  (i.e., send the Mailing Label to MTS for processing)
     *
     * @param GoodServiceWipoBean - The Goods and Services bean currently in the Session
     * @param AuthorityId  (String)
     * @return void
     * @throws MCServerException
     */
    public void processMailigLabel(GoodServiceWipoBean gsBean, String authorityId) throws MCServerException {

        logger.debug("Method: processMailigLabel ");

        ProcessModifiedRepAddressSubmissionRequest request = new ProcessModifiedRepAddressSubmissionRequest();
        request.setRepresentativeAddress(gsBean.getMailingLabel());
        request.setFileNumber(new BigDecimal(gsBean.getApplication().getApplicationNumber().getFileNumber()));
        request.setExtensioncounter(Integer.toString(gsBean.getApplication().getApplicationNumber().getExtensionCounter()));
        request.setAuthorityId(authorityId);
        request.setTaskId(gsBean.getTaskId());

        try {
            getClient().processModifiedRepAddressSubmission(request);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        } catch (CIPOServiceFault e) {

            logger.error("Method: processMailigLabel: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processmailinglabel"), e);

        } catch (Throwable e) {

            logger.error("Method: processMailigLabel, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "processMailigLabel()",
                e.getMessage());

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processmailinglabel"), e);
        }
        return;
    }


    /**
     * Gets the XML content.
     *
     * @param transactionId the transaction id
     * @return the XML content
     * @throws CIPOServiceFault the CIPO service fault
     */
    public String getXmlContent(BigDecimal transactionId, boolean includeAttachment) throws MCServerException {

        logger.debug("Method: getXmlContent: trans id - " + transactionId + ", includeXML - true" + ", includeAttach - "
            + includeAttachment);

        TransactionDetail response = getTransaction(transactionId, true, includeAttachment);

        String xmlcontent;
        try {
            xmlcontent = new String(response.getXmlContent(), "UTF-8");

        } catch (UnsupportedEncodingException e) {

            logger.error("Method: getXmlContent: unsupported UTF-8 encoding error for trans id - " + transactionId
                + ", includeXML - true" + ", includeAttach - " + includeAttachment);
            e.printStackTrace(); // Ignore encoding for now.
            xmlcontent = new String(response.getXmlContent());
        }

        // If empty XML response returned from MTS, set xmlcontent to an Error Message.
        if (xmlcontent.isEmpty()) {
            logger.error("Method: getXmlContentOrigCorrection, Unable to Retireve Transaction for Transaction Id: "
                + transactionId);
            xmlcontent = MadridConsoleUtils.getMessage("mc.transdetails.modal.trans.not.found");
        }

        return xmlcontent;
    }

    /**
     * Gets the XML content of the original Correction Transaction (based on Record Identifier and IR Number).
     *
     * @param recordIdentifier - The Record Identifier
     * @param irNumber - IR Number
     * @return the XML content
     * @throws MCServerException the CIPO service fault
     */
    public String getXmlContentOrigCorrection(String recordIdentifier, String irNumber) throws MCServerException {

        logger.debug(
            "Method: getXmlContentOrigCorrection  recordIdentifier: " + recordIdentifier + ", irNumber: " + irNumber);

        TransactionDetail response = getTransactionByIntlRecordId(recordIdentifier, irNumber);

        String xmlcontent = new String();
        try {
            if (response != null) {
                xmlcontent = new String(response.getXmlContent(), "UTF-8");
            }
        } catch (UnsupportedEncodingException e) {

            logger.error("Method: getXmlContentOrigCorrection  recordIdentifier: " + recordIdentifier + ", irNumber: "
                + irNumber);
            e.printStackTrace(); // Ignore encoding for now.
            xmlcontent = new String(response.getXmlContent());
        }

        // If empty XML response returned from MTS, set xmlcontent to an Error Message.
        if (xmlcontent.isEmpty()) {
            logger.error(
                "Method: getXmlContentOrigCorrection, Unable to Retireve Origianal Transaction for recordIdentifier: "
                    + recordIdentifier + ", irNumber: " + irNumber);
            xmlcontent = MadridConsoleUtils.getMessage("mc.ircorrection.error.correction.notfound");
        }

        return xmlcontent;
    }

    /**
     * Process goods and services changes.
     *
     * @param gsData the gs data
     * @return the goods and services changes response
     * @throws MCServerException the Madrid Console service fault
     */
    public GoodsAndServicesChangesResponse processGoodsAndServicesChanges(GoodsAndServiceMeta gsData)
        throws MCServerException {

        logger.debug("Method: processGoodsAndServicesChanges: goodandservicemeta size - "
            + gsData.getMergedGoodServices().getTaskListBag().size() + ", IR# - "
            + gsData.getInternationalRegistrationNumber() + ", taskId - " + gsData.getTaskId() + " task type - "
            + gsData.getTaskType());

        try {
            GoodsAndServicesChangesResponse GoodsAndServicesChangesResponse = getClient()
                .processGoodsAndServicesChanges(gsData);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return GoodsAndServicesChangesResponse;

        } catch (CIPOServiceFault e) {

            logger.error("Method: processGoodsAndServicesChanges: goodandservicemeta size - "
                + gsData.getMergedGoodServices().getTaskListBag().size() + ", IR# - "
                + gsData.getInternationalRegistrationNumber() + ", taskId - " + gsData.getTaskId() + " task type - "
                + gsData.getTaskType());
            logger.error("Method: processGoodsAndServicesChanges: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processgs"), e);

        } catch (Throwable e) {

            logger.error("Method: processGoodsAndServicesChanges, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint,
                "processGoodsAndServicesChanges()", e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processgs"), e);
        }
    }

    /**
     * Process goods and services changes for partial ownership.
     *
     * @param gsData the gs data
     * @return the goods and services changes response
     * @throws MCServerException the Madrid Console service fault
     */
    public GoodsAndServicesChangesResponse processPartialOwnership(BigDecimal taskId, String notificationLang,
                                                                   PartialOwnershipMeta designation,
                                                                   PartialOwnershipMeta restriction)
        throws MCServerException {

        logger.debug("Method: processPartialOwnership: designation gsMeta size - "
            + designation.getMergedGoodServices().getTaskListBag().size() + ", IR# - "
            + designation.getInternationalRegistrationNumber() + ", taskId - " + taskId);
        logger.debug("Method: processPartialOwnership: restriction gsMeta size - "
            + restriction.getMergedGoodServices().getTaskListBag().size() + ", IR# - "
            + restriction.getInternationalRegistrationNumber());

        try {
            GoodsAndServicesChangesResponse GoodsAndServicesChangesResponse = getClient()
                .processPartialOwnership(taskId, notificationLang, designation, restriction);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return GoodsAndServicesChangesResponse;

        } catch (CIPOServiceFault e) {

            logger.error("Method: processPartialOwnership: Task Id - " + taskId + ", designation gsMeta size - "
                + designation.getMergedGoodServices().getTaskListBag().size() + ", IR# - "
                + designation.getInternationalRegistrationNumber() + ", restriction gsMeta size - "
                + restriction.getMergedGoodServices().getTaskListBag().size());
            logger.error("Method: processPartialOwnership: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processgs"), e);

        } catch (Throwable e) {

            logger.error("Method: processPartialOwnership, Received Throwable");
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "processPartialOwnership()",
                e.getMessage());
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processgs"), e);
        }
    }

    /**
     * Gets the transaction attachment.
     *
     * @param attachId the attach id
     * @return the transaction attachment
     * @throws MCServerException the Madrid Console service fault
     */
    public AttachmentDetail getTransactionAttachment(BigDecimal attachId) throws MCServerException {

        logger.debug("Method: getTransactionAttachment: attach id - " + attachId);

        try {
            AttachmentDetail attachmentDetail = getClient().getTransactionAttachment(attachId);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return attachmentDetail;

        } catch (CIPOServiceFault e) {

            logger.error("Method: getTransactionAttachment: attach id - " + attachId);
            logger.error("Method: getTransactionAttachment: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.attachment"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint,
                "getTransactionAttachment()", e.getMessage());
            logger.error("Method: getTransactionAttachment, Received Throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.attachment"), e);
        }
    }

    /**
     * Process Irregularity
     *
     * @param param the param
     * @throws MCServerException the Madrid Console service fault
     */
    public void processIRRegularity(ProcessIrregularitySubmissionRequest param) throws MCServerException {

        logger.debug(
            "processIRRegularity: task id - " + param.getTaskId() + " response text - " + param.getResponseText());

        try {
            getClient().processIrregularitySubmission(param);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        } catch (CIPOServiceFault e) {

            logger.error(
                "processIRRegularity: task id - " + param.getTaskId() + " response text - " + param.getResponseText());
            logger.error("Method: processIRRegularity: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processirreg"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint,
                "processIrregularitySubmission()", e.getMessage());
            logger.error("Method: processIRRegularity, received throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processirreg"), e);
        }
    }

    /**
     * Process Mail Status flag (Processed) for irregularity.
     *
     * @param strFileNumber the File Number
     * @param strAuthorityId the Authority Id
     *
     * @throws MCServerException the Madrid Console service fault
     */
    public void processMailProcStatusIRRegularity(int fileNumber, String strAuthorityId) throws MCServerException {

        logger.debug(
            "processMailProcStatusIRRegularity: File Number - " + fileNumber + " strAuthorityId - " + strAuthorityId);

        try {
            getClient().updateMailProcessedStatus(new BigDecimal(fileNumber), strAuthorityId, MailTransactionType.MADRID_IRREGULARITY_NOTIFICATION  );
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        } catch (CIPOServiceFault e) {

            logger.error(
                "processMailProcStatusIRRegularity: File Number - " + fileNumber+ " strAuthorityId - " + strAuthorityId);
            logger.error("Method: processMailProcStatusIRRegularity: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processirreg"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint,
                "processMailProcStatusIRRegularity()", e.getMessage());
            logger.error("Method: processMailProcStatusIRRegularity, received throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processirreg"), e);
        }
    }

    /**
     * Obtain MF3A
     *
     * @param getManualReportRequest - The Manual Report Request data
     * @return ProcessManualReportRequest
     * @throws MCServerException the Madrid Console service fault
     */
    public ProcessManualReportRequest obtainMF3A(GetManualReportRequest getManualReportRequest)
        throws MCServerException {

        logger.debug("Method: obtainMF3A: task id - " + getManualReportRequest.getTaskId());

        try {

            ProcessManualReportRequest processManualReportRequest = getClient().getManualReport(getManualReportRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return processManualReportRequest;

        } catch (CIPOServiceFault e) {

            logger.error("Method: obtainMF3A: task id - " + getManualReportRequest.getTaskId());
            logger.error("Method: obtainMF3A: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf3a"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "getManualReport()",
                e.getMessage());
            logger.error("Method: obtainMF3A, recieved Throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf3a"), e);
        }
    }

    /**
     * Obtain MF13
     *
     * @param getManualReportRequest - The Manual Report Request data
     * @return ProcessManualReportRequest
     * @throws CIPOServiceFault the CIPO service fault
     */
    public ProcessManualReportRequest obtainMF13(GetManualReportRequest getManualReportRequest)
        throws MCServerException {

        logger.debug("Method: obtainMF13: task id - " + getManualReportRequest.getTaskId());

        try {
            ProcessManualReportRequest processManualReportRequest = getClient().getManualReport(getManualReportRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return processManualReportRequest;

        } catch (CIPOServiceFault e) {

            logger.error("Method: obtainMF13: task id - " + getManualReportRequest.getTaskId());
            logger.error("Method: obtainMF13: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf13"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "getManualReport()",
                e.getMessage());
            logger.error("Method: obtainMF13, receivled Throwable ");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf13"), e);
        }
    }

    /**
     * Obtain MF9
     *
     * @param getManualReportRequest - The Manual Report Request data
     * @return ProcessManualReportRequest
     * @throws MCServerException the Madrid Console service fault
     */
    public ProcessManualReportRequest obtainMF9(GetManualReportRequest getManualReportRequest)
        throws MCServerException {

        logger.debug("Method: obtainMF9: task id - " + getManualReportRequest.getTaskId());

        try {
            ProcessManualReportRequest processManualReportRequest = getClient().getManualReport(getManualReportRequest);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return processManualReportRequest;

        } catch (CIPOServiceFault e) {

            logger.error("Method: obtainMF9: task id - " + getManualReportRequest.getTaskId());
            logger.error("Method: obtainMF9: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf9"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "getManualReport()",
                e.getMessage());
            logger.error("Method: obtainMF9, received Throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf9"), e);
        }
    }

    public TaskDescriptionListResponse getDescriptions(Integer panel) throws MCServerException {

        TaskDescriptionListSearchCriteria criteria = new TaskDescriptionListSearchCriteria();
        if (panel == NOTIFICATIONS_TABLE) {
            criteria.setTaskSubjectCategory(TaskSubjectCategory.NOTIFICATION);
        } else {
            criteria.setTaskSubjectCategory(TaskSubjectCategory.MANUAL);
        }

        try {
            TaskDescriptionListResponse taskDescriptionListResponse = getClient().getTaskDescriptionList(criteria);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            return taskDescriptionListResponse;

        } catch (CIPOServiceFault e) {
            logger.error("Method: getDescriptions: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.workflowtasks"), e);
        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint,
                "getTaskDescriptionList(), panel=" + panel, e.getMessage());
            logger.error("Method: getDescriptions, received Throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.workflowtasks"), e);
        }
    }

    /**
     * Process IRCorrection
     *
     * @param param the ProcessIrCorrectionSubmissionRequest
     * @throws MCServerException the Madrid Console service fault
     */
    public void processIRCorrection(ProcessIRCorrectionSubmissionRequest param) throws MCServerException {

        logger.debug("processIRCorrection: task id - " + param.getTaskId());

        try {
            getClient().processIRCorrectionSubmission(param);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        } catch (CIPOServiceFault e) {

            logger.error("processIRCorrection: task id - " + param.getTaskId());
            logger.error("Method: processIRCorrection: CIPO service fault message: " + e.getMessage());
            ServiceUtil.objectToXML(e.getFaultInfo());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processircor"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "processIRCorrection()",
                e.getMessage());
            logger.error("Method: processIRRegularity, received throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processircor"), e);
        }
    }

    /**
     * Obtain the Country Dscription from
     *
     * @param countryCode - String
     * @param language - LanguageType
     * @return String - containing the country description
     * @throws MCServerException the Madrid Console service fault
     */
    public String obtainCountryDescription(String countryCode, LanguageType Language) throws MCServerException {

        logger.debug("obtainCountryDescription Country Cd: " + countryCode
            + ", Language: " + Language);

        String getCountryProvinceResponse = null;
        try {
            getCountryProvinceResponse = getClient().getCountryProvince(countryCode, Language);
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

        } catch (CIPOServiceFault e) {

            logger.error("obtainCountryDescription: Country Cd: " + countryCode
                + ", Language: " + Language);
            logger.error("Method: obtainCountryDescription: CIPO service fault message: " + e.getMessage());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processircor"), e);

        } catch (Throwable e) {
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "processIRCorrection()",
                e.getMessage());
            logger.error("Method: processIRRegularity, received throwable");
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.processircor"), e);
        }

        return getCountryProvinceResponse;
    }


    /**
     * Process acquireLock - Used to Acquire Lock on a File Number for a User Name
     *
     * @param GoodServiceWipoBean - Goods and Services Bean (stored in Session)
     * @param fileNumber - File Number
     * @param extensionCounter - Extension Counter
     * @param username - User Name
     * @throws MCServerException - Exception if Unable to Acquire the Lock
     */
    public void acquireLock(GoodServiceWipoBean gsBean, int fileNumber, int extensionCounter, String username)
        throws MCServerException {

        logger.debug("acquireLock: fileNumber - " + fileNumber + ", extensionCounter - " + extensionCounter + ", username - " + username);

        AcquireTrademarkLockRequest lockReq = new AcquireTrademarkLockRequest();

        // Update the AcquireTrademarkLockRequest
        lockReq.setFileNumber(BigInteger.valueOf(fileNumber));
        lockReq.setExtensionCounter(BigInteger.valueOf(extensionCounter));
        lockReq.setUserName(username);

        try {
            getClient().acquireTrademarkLock(lockReq);

            // Store the Locked File Number and Extension, in the Session - gsBean
            gsBean.setFileNumberLocked(fileNumber);
            gsBean.setFileExtensionLocked(extensionCounter);

            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
        } catch (CIPOServiceFault e) {
            logger.error("Method: acquireLock, received CIPOServiceFault " + e.getMessage());
            sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);

            String[] params = new String[2];
            params[0] = fileNumber + " (" + extensionCounter + ")";
            try {
                params[1] = e.getMessage().substring(e.getMessage().indexOf("[") + 1, e.getMessage().indexOf("]"));
            }
            catch (Exception ex) {
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.acquirelock", params) );
            }
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.acquirelock.userid", params) );

         } catch (Throwable e) {
            e.printStackTrace();
            sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "acquireLock()",
                e.getMessage());
            logger.error("Method: acquireLock, received Throwable");

            String[] params = new String[1];
            params[0] = fileNumber + " (" + extensionCounter + ")";

            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.acquirelock", params) + " "
                + MadridConsoleUtils.getMessage("mc.error.mts.serviceunavailable", params), e);
        }
    }

    /**
     * Process releaseLock - Used to Release Lock on a File Number (and Extension).  Both of these items
     * File Number are Extension, are contained in the Goods and Services Bean (stored in Session)
     *
     * @param GoodServiceWipoBean - Goods and Services Bean (stored in Session)
     * @throws MCServerException - Exception if Unable to Release the Lock
     */
    public void releaseLock(GoodServiceWipoBean gsBean)
        throws MCServerException {

        logger.debug("releaseLock: fileNumber - " + gsBean.getFileNumberLocked() + ", extensionCounter - " + gsBean.getFileExtensionLocked());


        // If the session has a File Locked....the release the Lock
        if (gsBean.getFileNumberLocked() != 0) {

            ReleaseTrademarkLockRequest relReq = new ReleaseTrademarkLockRequest();

            // Update the ReleaseTrademarkLockRequest
            relReq.setFileNumber(BigInteger.valueOf(gsBean.getFileNumberLocked()));
            relReq.setExtensionCounter(BigInteger.valueOf(gsBean.getFileExtensionLocked()));

            try {
                getClient().releaseTrademarkLock(relReq); // Will return success, even if lock was not acquired?
                sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
            } catch (CIPOServiceFault e) {
                sendErrorEmail.updateServiceStatus(sendErrorEmail.MTS, true);
                // Check if this exception only happens if the lock cannot be released?
                e.printStackTrace();
            } catch (Throwable e) {
                e.printStackTrace();
                sendErrorEmail.sendErrorViaEmail(sendErrorEmail.MTS, madridTransactionEndpoint, "acquireLock()",
                    e.getMessage());
                logger.error("Method: acquireLock, received Throwable");

                String[] params = new String[1];
                params[0] = gsBean.getFileNumberLocked() + "(" + gsBean.getFileExtensionLocked() + ")";

                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.releaselock", params) + " "
                    + MadridConsoleUtils.getMessage("mc.error.mts.serviceunavailable", params), e);
            } finally {
                gsBean.setFileNumberLocked(0);
                gsBean.setFileExtensionLocked(0);

            }

        }
    }

}
