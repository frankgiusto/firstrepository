package ca.gc.ic.cipo.tm.madridconsole.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.activation.DataHandler;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import _int.wipo.standards.xmlschema.st96.common.madrid.AddressLineTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ContactType;
import _int.wipo.standards.xmlschema.st96.common.madrid.ISOLanguageCodeType;
import _int.wipo.standards.xmlschema.st96.common.madrid.LocalizedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType;
import _int.wipo.standards.xmlschema.st96.common.madrid.OrganizationNameType;
import _int.wipo.standards.xmlschema.st96.common.madrid.RepresentativeType;
import _int.wipo.standards.xmlschema.st96.mops.trademark.MadridRegistrationCurrentStatusType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionBagType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ClassDescriptionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesLimitationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.GoodsServicesType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.IrregularityType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridCorrectionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridDesignationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridHolderRepresentativeChangeType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIBToOfficeTransactionType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridIrregularityNotificationType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridPartialChangeOwnershipType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionCategoryType;
import _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.MadridProtectionRestrictionType;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.MadridApplicationActionStatus;
import ca.gc.ic.cipo.tm.madridconsole.service.mops.MOPSServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tirs.TIRSServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.util.DateFormats;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridConsoleUtils;
import ca.gc.ic.cipo.tm.madridconsole.util.MadridLanguageSet;
import ca.gc.ic.cipo.tm.madridconsole.util.ServiceUtil;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.FinalGoodsServicesWrapper;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MF13;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MF3A;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MF9;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.MadridServiceItemType;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForBasicMarks;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForGoodsAndServices;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.ReturnObjForGoodsAndServicesForNANR;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.mops.MOPSServiceResponse;
import ca.gc.ic.cipo.tm.mts.Attachment;
import ca.gc.ic.cipo.tm.mts.AttachmentList;
import ca.gc.ic.cipo.tm.mts.GetManualReport;
import ca.gc.ic.cipo.tm.mts.GetManualReportRequest;
import ca.gc.ic.cipo.tm.mts.GoodServiceSelectionType;
import ca.gc.ic.cipo.tm.mts.GoodServiceTaskType;
import ca.gc.ic.cipo.tm.mts.GoodsAndServiceMeta;
import ca.gc.ic.cipo.tm.mts.GoodsAndServicesChangesResponse;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationList;
import ca.gc.ic.cipo.tm.mts.GoodsServicesClassificationType;
import ca.gc.ic.cipo.tm.mts.GroundsOfOpposition;
import ca.gc.ic.cipo.tm.mts.PartialOwnershipMeta;
import ca.gc.ic.cipo.tm.mts.ProcessIRCorrectionSubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessIrregularitySubmissionRequest;
import ca.gc.ic.cipo.tm.mts.ProcessManualReportRequest;
import ca.gc.ic.cipo.tm.mts.ReferenceCode;
import ca.gc.ic.cipo.tm.mts.TrademarkInfo;
import ca.gc.ic.cipo.xmlschema.common.ApplicationNumber;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressBagType;
import ca.gc.ic.cipo.xmlschema.common.PostalAddressType;
import ca.gc.ic.cipo.xmlschema.common.RoleCategoryType;
import ca.gc.ic.cipo.xmlschema.common.UnstructuredPostalAddressType;
import ca.gc.ic.cipo.xmlschema.trademark.ClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.ActionType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesClaimsType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.MadridApplicationEventType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.PriorityClaimType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkApplicationType;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsTypeMF3;
import ca.gc.ic.cipo.xmlschema.trademark.extended.TrademarkDetailsTypeMF3BagType;

/**
 * Service for retrieving trademark application information from TMIR Service.
 *
 * @author timyu
 */
@Service
public class TradMarkApplicationService {

    @Resource(name = "messageSource")
    private MessageSource messageSource;

    /** The Constant GOODSERVICES_FORM. */
    public static final String GOODSERVICES_FORM = "GoodServices";

    /** The Constant DESIGNATIONGOODSERVICESLIMITATION_FORM. */
    public static final String DESIGNATIONGOODSERVICESLIMITATION_FORM = "DesignationGoodServicesLimitation";

    /** The Constant MF3A_FORM. */
    public static final String MF3A_FORM = "MF3A";

    /** The Constant MF13_FORM. */
    public static final String MF13_FORM = "MF13";

    /** The Constant IRREGULARITY_FORM. */
    public static final String IRREGULARITY_FORM = "Irregularity";

    /** The Constant IRCORRECTION_FORM. */
    public static final String IRCORRECTION_FORM = "IRCorrection";

    /** The Constant IRCORRECTION_FORM. */
    public static final String EDIT_MAILING_LABEL_FORM = "EditMailingLabel";

    /** The Constant PARTIALOWNERSHIP_FORM. */
    public static final String PARTIALOWNERSHIP_FORM = "PartialOwnership";

    /** The Constant OOPARTIALCEASING_FORM. */
    public static final String OOPARTIALCEASING_FORM = "OOPartialCeasing";

    /** The Constant BASICAPPLICATION_FORM. */
    public static final String BASICAPPLICATION_FORM = "BasicApplication";

    /** The Constant TOTALCEASINGOO_FORM. */
    public static final String TOTALCEASINGOO_FORM = "TotalCeasingOO";

    public static final String COMMA_SPACE = ", ";

    public static final String SPACE = " ";

    public static final String DOUBLE_LINE_CHANGE = "\n\n";

    public static final String LINE_CHANGE = "\n";

    public static final String WHITE_SPACE = " ";

    public static final int MAILING_LABEL_LINE_SIZE = 40;

    public static final String STR_HOME = "Home";

    public static final String ENGLISH = "ENGLISH";

    public static final String FRENCH = "FRENCH";

    /** The MTS service. */
    @Autowired
    private TransactionServiceClient transactionService;

    /** The TIRS service. */
    @Autowired
    private TIRSServiceClient tirsService;

    /** The MOPS service. */
    @Autowired
    private MOPSServiceClient mopsService;

    @Autowired
    private UserProfileServiceClient userProfileService;

    private static Logger logger = Logger.getLogger(TradMarkApplicationService.class.getName());

    private static JAXBContext initMadridContextIbToOffice() throws JAXBException {

        return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid",
            _int.wipo.standards.xmlschema.st96.trademark.ibtooffice.madrid.ObjectFactory.class.getClassLoader());

    }

    private static JAXBContext initMadridContextOfficeToIb() throws JAXBException {

        return JAXBContext.newInstance("_int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid",
            _int.wipo.standards.xmlschema.st96.trademark.officetoib.madrid.ObjectFactory.class.getClassLoader());
    }

    @SuppressWarnings("unused")
    private <T> ByteArrayOutputStream marshalIt(Marshaller marshaller, JAXBElement<T> madridObject)
        throws JAXBException {

        ByteArrayOutputStream os = new ByteArrayOutputStream();

        @SuppressWarnings({"unchecked", "rawtypes"})
        JAXBElement jaxbElement = new JAXBElement(madridObject.getName(), madridObject.getClass(),
            madridObject.getValue());
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.marshal(jaxbElement, os);

        return os;
    }

    /**
     * Gets the good service from WIPO for irregularity.
     *
     * @param gsBean the gs bean
     * @param wipoXML the wipo XML
     * @return the good service from WIPO for irregularity
     * @throws MCServerException the MC server exception
     */
    public boolean getGoodServiceFromWIPOForIrregularity(GoodServiceWipoBean gsBean, String wipoXML)
        throws MCServerException {

        logger.debug("Method: getGoodServiceFromWIPOForIrregularity ");

        MadridIrregularityNotificationType restriction = null;

        try {
            JAXBContext jaxbMadridContext = initMadridContextIbToOffice();
            Unmarshaller unmarshallerRoot = jaxbMadridContext.createUnmarshaller();

            ByteArrayInputStream input = null;
            try {
                input = new ByteArrayInputStream(wipoXML.getBytes("UTF-8"));

            } catch (UnsupportedEncodingException e) {
                logger.error("getGoodServiceFromWIPOForIrregularity: Error encoding wipoXML in UTF8 - " + wipoXML);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
            }
            @SuppressWarnings("unchecked")
            JAXBElement<MadridIrregularityNotificationType> transactionType = (JAXBElement<MadridIrregularityNotificationType>) unmarshallerRoot
                .unmarshal(input);

            restriction = transactionType.getValue();

        } catch (JAXBException e) {
            logger.error(
                "getGoodServiceFromWIPOForIrregularity: Error creating unmarshaller when parsing wipoXML - " + wipoXML);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
        }

        List<IrregularityType> irregularityTypes = restriction.getIrregularityBag().getIrregularity();
        gsBean.getIrregularityDetail().setResponseDueDate(restriction.getResponseDueDate());
        gsBean.setIrregularityTypes(irregularityTypes);

        // Get the Original Transaction.
        gsBean.setOrigTransactionDetail(transactionService
            .getTransaction(new BigDecimal(restriction.getOfficeReferenceIdentifier().getValue()), true, true));

        gsBean.setInternationalRegistrationNumber(restriction.getInternationalRegistrationNumber());

        return true;
    }

    /**
     * Gets the good service from WIPO for Edit Mailing Label.
     *
     * @param gsBean the gs bean
     * @param transId the transaction ID
     * @return boolean (true)
     * @throws MCServerException the MC server exception
     */
    public boolean getGoodServiceFromWIPOForEditMailingLabel(GoodServiceWipoBean gsBean, BigDecimal transId)
        throws MCServerException {

        logger.debug("Method: getGoodServiceFromWIPOForEditMailingLabel ");

        String wipoXML = ServiceUtil.stripCDATA(transactionService.getXmlContent(transId, true));
        String transType = gsBean.getTransactionDetail().getTransactionType().getCategory();

        RepresentativeType representativeType = null;
        ISOLanguageCodeType notificationLanguage = null;
        String irNumb = null;

        try {
            JAXBContext jaxbMadridContext = initMadridContextIbToOffice();
            Unmarshaller unmarshallerRoot = jaxbMadridContext.createUnmarshaller();

            ByteArrayInputStream input = null;
            try {
                input = new ByteArrayInputStream(wipoXML.getBytes("UTF-8"));

            } catch (UnsupportedEncodingException e) {
                logger.error("getGoodServiceFromWIPOForIrregularity: Error encoding wipoXML in UTF8 - " + wipoXML);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
            }

            // MadridDesignationType (Madrid Designation)
            switch (transType) {
                case "MD_REGISTRATION":
                case "MD_SUBSEQUENT_DESIGNATION":
                case "MD_PARTIAL_CHANGE_OF_OWNERSHIP":
                case "MD_MERGER":
                    @SuppressWarnings("unchecked")
                    JAXBElement<MadridDesignationType> madridDesignationType = (JAXBElement<MadridDesignationType>) unmarshallerRoot
                        .unmarshal(input);

                    notificationLanguage = madridDesignationType.getValue().getNotificationLanguage();
                    representativeType = madridDesignationType.getValue().getRepresentative();
                    irNumb = madridDesignationType.getValue().getInternationalRegistrationNumber();
                    break;

                // MadridPartialChangeOwnershipType
                case "DESIGNATION_PROTECTION_RESTRICTION":
                case "DESIGNATION_TERMINATION":
                case "MDT_PARTIAL_CHANGE_OF_OWNERSHIP":
                case "MPR_PARTIAL_CHANGE_OF_OWNERSHIP":
                    @SuppressWarnings("unchecked")
                    JAXBElement<MadridPartialChangeOwnershipType> madridPartialChangeOwnershipType = (JAXBElement<MadridPartialChangeOwnershipType>) unmarshallerRoot
                        .unmarshal(input);

                    notificationLanguage = madridPartialChangeOwnershipType.getValue().getMadridDesignation()
                        .getNotificationLanguage();
                    representativeType = madridPartialChangeOwnershipType.getValue().getMadridDesignation()
                        .getRepresentative();
                    irNumb = madridPartialChangeOwnershipType.getValue().getMadridDesignation()
                        .getInternationalRegistrationNumber();
                    break;

                // MadridHolderRepresentativeChangeType
                case "MHR_CHANGE_OF_HOLDER_NAME_ADDRESS":
                case "MHR_CHANGE_OF_OWNER":
                case "MHR_CHANGE_OF_OWNERSHIP":
                case "MHR_CHANGE_OF_REPRESENTATIVE":
                    @SuppressWarnings("unchecked")
                    JAXBElement<MadridHolderRepresentativeChangeType> madridHolderRepresentativeChangeType = (JAXBElement<MadridHolderRepresentativeChangeType>) unmarshallerRoot
                        .unmarshal(input);

                    notificationLanguage = ISOLanguageCodeType.EN; // TEMPORARY HAck, since the notificatgion language
                                                                   // does not appear to be in XML for
                                                                   // MadridHolderRepresentativeChangeType
                    representativeType = madridHolderRepresentativeChangeType.getValue().getRepresentative();
                    irNumb = madridHolderRepresentativeChangeType.getValue().getInternationalRegistrationNumber();
                    break;

                default:
                    logger
                        .error("Method: getGoodServiceFromWIPOForEditMailingLabel Unexpected Trans Type: " + transType);
                    throw new MCServerException("Unexpected Trans Type: " + transType);
            }

        } catch (JAXBException e) {
            logger
                .error("getGoodServiceFromWIPOForEditMailingLabel: Error creating unmarshaller when parsing wipoXML - "
                    + wipoXML);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
        }

        gsBean.setMailingLabel(generateEditMailingLabel(representativeType, notificationLanguage));
        gsBean.setInternationalRegistrationNumber(irNumb);

        return true;
    }

    /**
     * Generate the Mailing Label (in the form of a String) to be displayedl.
     *
     * @param RepresentativeType - Used to derive the Mailing Label from.
     * @return String (Name, Address, City etc.) with newLines to from a Mailing Label for display
     * @throws MCServerException the MC server exception
     */
    @SuppressWarnings("unchecked")
    private String generateEditMailingLabel(RepresentativeType representativeType,
                                            ISOLanguageCodeType notificationLanguage)
        throws MCServerException {

        StringBuilder mailingLabel = new StringBuilder();
        String notifLanguage = null;

        // Determine the Notification Language (required for determining the Country Code/Description)
        if (notificationLanguage.equals(ISOLanguageCodeType.FR.value())) {
            notifLanguage = FRENCH;
        } else {
            notifLanguage = ENGLISH;
        }

        for (Object legalEntityNameOrPartyIdentifierOrContact : representativeType
            .getLegalEntityNameOrPartyIdentifierOrContact()) {

            // Only want CONTACT name.
            if (legalEntityNameOrPartyIdentifierOrContact instanceof ContactType) {

                ContactType contact = (ContactType) legalEntityNameOrPartyIdentifierOrContact;

                if (contact.getName() != null) {

                    for (Object personNameOrOrganizationNameOrEntityName : contact.getName()
                        .getPersonNameOrOrganizationNameOrEntityName()) {

                        if (personNameOrOrganizationNameOrEntityName instanceof OrganizationNameType) {
                            OrganizationNameType organizationName = (OrganizationNameType) personNameOrOrganizationNameOrEntityName;
                            mailingLabel.append(splitString(
                                organizationName.getOrganizationStandardName().getContent().get(0).toString(),
                                MAILING_LABEL_LINE_SIZE));
                        }
                    }
                }

                for (_int.wipo.standards.xmlschema.st96.common.madrid.PostalAddressType postalAddressType : contact
                    .getPostalAddressBag().getPostalAddress()) {
                    for (AddressLineTextType addressLineText : postalAddressType.getPostalStructuredAddress()
                        .getAddressLineText()) {
                        mailingLabel.append(splitString(addressLineText.getValue(), MAILING_LABEL_LINE_SIZE));

                    }

                    // City Name - if there is one.
                    if (postalAddressType.getPostalStructuredAddress().getCityName() != null) {
                        mailingLabel.append(postalAddressType.getPostalStructuredAddress().getCityName());
                        mailingLabel.append(LINE_CHANGE);
                    }

                    // Postal code - if there is one.
                    if (postalAddressType.getPostalStructuredAddress().getPostalCode() != null) {
                        mailingLabel.append(postalAddressType.getPostalStructuredAddress().getPostalCode());
                        mailingLabel.append(LINE_CHANGE);
                    }

                    // Country Code - if there is one.
                    if (postalAddressType.getPostalStructuredAddress().getCountryCode() != null) {
                        mailingLabel.append(obtainCountryDescripton(
                            postalAddressType.getPostalStructuredAddress().getCountryCode(), notifLanguage));
                        mailingLabel.append(LINE_CHANGE);
                    }
                }
            }
        }

        // Remove the last LINE_CHANGE, that will be at the end of the string
        return mailingLabel.toString().substring(0, mailingLabel.toString().lastIndexOf("\n"));
    }

    /**
     * Gets the good service from WIPO for correction.
     *
     * @param gsBean the gs bean
     * @param wipoXML the wipo XML
     * @return the good service from WIPO for ir correction
     * @throws MCServerException
     */
    public boolean getGoodServiceFromWIPOForIrCorrection(GoodServiceWipoBean gsBean, String wipoXML)
        throws MCServerException {

        logger.debug("Method: getGoodServiceFromWIPOForIrCorrection ");

        MadridCorrectionType resultCorrectionType = null;
        List<String> wipoComments = new ArrayList<String>();

        try {
            ByteArrayInputStream input = new ByteArrayInputStream(wipoXML.getBytes("UTF-8"));

            @SuppressWarnings("unchecked")
            JAXBElement<MadridCorrectionType> transactionType = (JAXBElement<MadridCorrectionType>) getUnmarshaller()
                .unmarshal(input);

            resultCorrectionType = transactionType.getValue();

        } catch (UnsupportedEncodingException e) {

            logger.error("getGoodServiceFromWIPOForIrCorrection: Error encoding wipoXML in UTF8 - " + wipoXML);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.encodingerror"), e);

        } catch (JAXBException e) {

            logger.error(
                "getGoodServiceFromWIPOForIrCorrection: Error creating unmarshaller when parsing wipoXML - " + wipoXML);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
        }

        // Get the WIPO comments if the list contains only OrderedTextTypes, otherwise check to get the
        // class descriptions that maybe limited to or being removed from the list if its a category type
        if (resultCorrectionType.getCorrectionDescriptionTextBag() != null
            && resultCorrectionType.getCorrectionDescriptionTextBag().getCorrectionDescriptionText() != null) {

            for (LocalizedTextType text : resultCorrectionType.getCorrectionDescriptionTextBag()
                .getCorrectionDescriptionText()) {
                if (text.getLanguageCode().equalsIgnoreCase(MadridConsoleUtils.getLocaleContext().getLanguage())) {
                    wipoComments.add(text.getValue());
                }
            }
        }

        // Set the Correction Record Identifier and the IR Number
        setCorrectionRecordIdentiferIRNumber(gsBean, resultCorrectionType);
        gsBean.setInternationalRegistrationNumber(gsBean.getCorrectionIRNumber());

        // Set the Correction Data
        gsBean.setCorrectionType(resultCorrectionType);

        return true;
    }

    /**
     * Gets the Record Identifier and the IR Number for the Original Correction Transaction. The Record Identifier and
     * the IR for the Original Correction Transaction, are updated in the GoodServiceWipoBean (i.e.,
     * correctionRecordIdentifier and correctionIRNumber)
     *
     * @param gsBean the GoodServiceWipoBean
     * @param resultCorrectionType the MadridCorrectionType
     * @return void
     * @throws MCServerException
     * @throws UnsupportedEncodingException
     */
    private void setCorrectionRecordIdentiferIRNumber(GoodServiceWipoBean gsBean,
                                                      MadridCorrectionType resultCorrectionType)
        throws MCServerException {

        String tmpRecordIdentifier = null;
        String tmpIRNumber = null;
        String strCorrection = transactionService.getXmlContent(gsBean.getTransactionId(), false);
        String strEncodeCorrection = null;
        Boolean correctContent = false;

        try {
            byte ptext[] = strCorrection.getBytes();
            strEncodeCorrection = new String(ptext, "ISO-8859-1");
        } catch (Exception e) {

        }

        if (resultCorrectionType.getMadridIncorrectContent().getMadridDesignation() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridDesignation()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridDesignation()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridBasicRegistrationApplicationChange() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent()
                .getMadridBasicRegistrationApplicationChange().getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridBasicRegistrationApplicationChange()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridDesignationTermination() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridDesignationTermination()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridDesignationTermination()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridHolderRepresentativeChange() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridHolderRepresentativeChange()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridHolderRepresentativeChange()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridInternationalRegistrationCreation() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent()
                .getMadridInternationalRegistrationCreation().getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridInternationalRegistrationCreation()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridLicenseeRecordChange() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridLicenseeRecordChange()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridLicenseeRecordChange()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridProtectionRestriction() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridProtectionRestriction()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridProtectionRestriction()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridRenewal() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridRenewal()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridRenewal()
                .getInternationalRegistrationNumber();
        }
        if (resultCorrectionType.getMadridIncorrectContent().getMadridSecondPartPayment() != null) {
            tmpRecordIdentifier = resultCorrectionType.getMadridIncorrectContent().getMadridSecondPartPayment()
                .getRecordIdentifier().getValue();
            tmpIRNumber = resultCorrectionType.getMadridIncorrectContent().getMadridSecondPartPayment()
                .getInternationalRegistrationNumber();
        }

        // Correct Content and INCorect Content to be used for comparison
        if ((resultCorrectionType.getMadridCorrectContent().getMadridDesignation() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridBasicRegistrationApplicationChange() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridDesignationTermination() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridHolderRepresentativeChange() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridInternationalRegistrationCreation() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridLicenseeRecordChange() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridProtectionRestriction() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridRenewal() != null)
            || (resultCorrectionType.getMadridCorrectContent().getMadridSecondPartPayment() != null)) {
            correctContent = true;
        }
        gsBean.setCorrectionOrigTrans(
            getBetweenStrings(strEncodeCorrection, "<ns2:MadridIncorrectContent>", "</ns2:MadridIncorrectContent>"));
        gsBean.setCorrectionCorrTrans(
            getBetweenStrings(strEncodeCorrection, "<ns2:MadridCorrectContent>", "</ns2:MadridCorrectContent>"));
        gsBean.setCorrectionContent(correctContent);

        // Original RE and IR number, to be used to retrieve the Original Transaction
        gsBean.setCorrectionRecordIdentifier(tmpRecordIdentifier);
        gsBean.setCorrectionIRNumber(tmpIRNumber);
    }

    private Unmarshaller getUnmarshaller() throws JAXBException {

        JAXBContext jaxbMadridContext = initMadridContextIbToOffice();

        return jaxbMadridContext.createUnmarshaller();
    }

    private static String getLocalizedOrderedMessage(List<OrderedTextType> list, String lang) {
        for (OrderedTextType type : list) {
            if (type.getLanguageCode().equals(lang)) {
                return type.getValue();
            }
        }
        return "";
    }

    /**
     * Gets the good service from WIPO for partial ownership.
     *
     * @param gsBean the gs bean
     * @param wipoXML the wipo XML
     * @return the good service from WIPO for partial ownership
     * @throws MCServerException
     */
    public boolean getGoodServiceFromWIPOForPartialOwnership(GoodServiceWipoBean gsBean, String wipoXML)
        throws MCServerException {

        logger.debug("getGoodServiceFromWIPOForPartialOwnership: transId - " + gsBean.getTransactionId() + ", taskId - "
            + gsBean.getTaskId());

        MadridPartialChangeOwnershipType ownership = null;

        try {
            ByteArrayInputStream input = new ByteArrayInputStream(wipoXML.getBytes("UTF-8"));

            @SuppressWarnings("unchecked")
            JAXBElement<MadridPartialChangeOwnershipType> transactionType = (JAXBElement<MadridPartialChangeOwnershipType>) getUnmarshaller()
                .unmarshal(input);

            ownership = transactionType.getValue();

        } catch (UnsupportedEncodingException e) {

            logger.error("getGoodServiceFromWIPOForPartialOwnership: Error encoding wipoXML in UTF8 - " + wipoXML);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.encodingerror"), e);

        } catch (JAXBException e) {

            logger
                .error("getGoodServiceFromWIPOForPartialOwnership: Error creating unmarshaller when parsing wipoXML - "
                    + wipoXML);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
        }

        // Read Good and Services for New Owner
        MadridDesignationType designation = ownership.getMadridDesignation();

        gsBean.setInternationalRegistrationNumber(designation.getInternationalRegistrationNumber());

        List<GoodsServicesType> gsTypes = Collections.emptyList();
        if (designation.getGoodsServicesBag() != null) {
            gsTypes = designation.getGoodsServicesBag().getGoodsServices();
        }
        List<ClassDescriptionType> wipoGsTypes = new ArrayList<ClassDescriptionType>();
        List<ClassDescriptionType> wipoGsLimitTypes = new ArrayList<ClassDescriptionType>();
        List<ClassDescriptionType> wipoGsRemoveTypes = new ArrayList<ClassDescriptionType>();

        // parse GoodsAndServicesBag only if GoodsServicesLimitationBag does not exist (optional bag)
        if (designation.getGoodsServicesLimitationBag() == null) {
            for (GoodsServicesType gsType : gsTypes) {
                if (gsType.getCommentTextBag() != null && gsType.getCommentTextBag().getCommentText() != null) {
                    gsBean.getWipoComments().add(getLocalizedOrderedMessage(gsType.getCommentTextBag().getCommentText(),
                        gsBean.getLangCode().value()));
                }
                ClassDescriptionBagType descripType = gsType.getClassDescriptionBag();
                List<ClassDescriptionType> classTypes = descripType.getClassDescription();
                for (ClassDescriptionType classType : classTypes) {
                    wipoGsTypes.add(classType);
                }
            }
        }
        // check if GoodsAndServicesLimitationBag exists
        List<GoodsServicesLimitationType> wipsGSLTypes = Collections.emptyList();

        if (designation.getGoodsServicesLimitationBag() != null) {
            wipsGSLTypes = designation.getGoodsServicesLimitationBag().getGoodsServicesLimitation();
        }

        for (GoodsServicesLimitationType gslType : wipsGSLTypes) {
            List<Object> commentsOrGSCategoryAndDescList = gslType
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag();

            boolean limitedTo = false;
            boolean removeFrom = false;

            for (Object commOrGSCatAndDesc : commentsOrGSCategoryAndDescList) {

                // Get the wipo comments if the list contains only OrderedTextTypes, otherwise check to get the
                // class descriptions that maybe limited to or being removed from the list if its a category type
                if (commOrGSCatAndDesc instanceof OrderedTextType) {
                    if (((OrderedTextType) commOrGSCatAndDesc).getLanguageCode()
                        .equalsIgnoreCase(gsBean.getLangCode().value())) {
                        gsBean.getWipoComments().add(((OrderedTextType) commOrGSCatAndDesc).getValue());
                    }
                } else if (commOrGSCatAndDesc instanceof GoodsServicesLimitationCategoryType) {
                    if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.LIST_LIMITED_TO) {
                        limitedTo = true;
                    } else if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                        removeFrom = true;
                    }
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && limitedTo) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsLimitTypes.add(classType);
                    }
                    limitedTo = false;
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && removeFrom) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsRemoveTypes.add(classType);
                    }
                    removeFrom = false;
                }
            }
        }

        gsBean.updateGoodsAndServices(wipoGsTypes, wipoGsLimitTypes, wipoGsRemoveTypes, false);

        // Read Good and Services for Previous Owner
        MadridProtectionRestrictionType restriction = ownership.getMadridProtectionRestriction();

        // This is the same for new and previous owner so can be read from either
        gsBean.setRestCategoryType(restriction.getMadridProtectionRestrictionCategory());

        wipsGSLTypes.clear();
        wipoGsTypes.clear();
        wipoGsLimitTypes.clear();
        wipoGsRemoveTypes.clear();

        if (restriction.getGoodsServicesLimitationBag() != null) {
            wipsGSLTypes = restriction.getGoodsServicesLimitationBag().getGoodsServicesLimitation();
        }

        for (GoodsServicesLimitationType gslType : wipsGSLTypes) {
            List<Object> commentsOrGSCategoryAndDescList = gslType
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag();

            boolean limitedTo = false;
            boolean removeFrom = false;

            for (Object commOrGSCatAndDesc : commentsOrGSCategoryAndDescList) {
                // logger.debug("comments list " + commOrGSCatAndDesc);

                // Get the wipo comments if the list contains only OrderedTextTypes, otherwise check to get the
                // class descriptions that maybe limited to or being removed from the list if its a category type
                if (commOrGSCatAndDesc instanceof OrderedTextType) {
                    if (((OrderedTextType) commOrGSCatAndDesc).getLanguageCode()
                        .equalsIgnoreCase(gsBean.getLangCode().value())) {
                        gsBean.getWipoCommentsForPreviousOwner().add(((OrderedTextType) commOrGSCatAndDesc).getValue());
                    }
                } else if (commOrGSCatAndDesc instanceof GoodsServicesLimitationCategoryType) {
                    if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.LIST_LIMITED_TO) {
                        limitedTo = true;
                    } else if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                        removeFrom = true;
                    }
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && limitedTo) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsLimitTypes.add(classType);
                    }
                    limitedTo = false;
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && removeFrom) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsRemoveTypes.add(classType);
                    }
                    removeFrom = false;
                }
            }
        }
        gsBean.setInternationalRegistrationNumberForPreviousOwner(restriction.getInternationalRegistrationNumber());
        gsBean.updateGoodsAndServices(new ArrayList<ClassDescriptionType>(), wipoGsLimitTypes, wipoGsRemoveTypes, true);

        return true;
    }

    private ClassDescriptionType transformClassDescriptionType(_int.wipo.standards.xmlschema.st96.mops.trademark.ClassDescriptionType classType) {

        logger.debug("transformClassDescriptionType: class number - " + classType.getClassNumber());

        ClassDescriptionType madClType = new ClassDescriptionType();
        madClType.setClassNumber(classType.getClassNumber());
        madClType.setClassificationVersion(classType.getClassificationVersion());
        List<_int.wipo.standards.xmlschema.st96.mops.common.OrderedTextType> ordTypes = classType
            .getGoodsServicesDescriptionText();

        for (_int.wipo.standards.xmlschema.st96.mops.common.OrderedTextType ordType : ordTypes) {
            _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType madOrdType = new _int.wipo.standards.xmlschema.st96.common.madrid.OrderedTextType();
            madOrdType.setLanguageCode(ordType.getLanguageCode());
            madOrdType.setSequenceNumber(ordType.getSequenceNumber());
            madOrdType.setValue(ordType.getValue());
            madClType.getGoodsServicesDescriptionText().add(madOrdType);

            // logger.debug("MC-WIPO: ordType - " + ordType.getValue());
            // logger.debug("MC-WIPO: madOrdType - " + madOrdType.getValue());
        }
        return madClType;
    }

    private boolean getFromMOPSPartialCeasingOO(GoodServiceWipoBean gsBean, BigDecimal transId)
        throws MCServerException {

        logger.debug("getFromMOPSPartialCeasingOO: transId - " + transId + ", taskId - " + gsBean.getTaskId());

        // Parse the MadridRegistrationCurrentStatus GoodsServicesBag as this is the current state of the entire IR
        // registration. The GoodsServicesLimitationBag is if the owner has limited to goods/services to/for certain
        // designated parties which doesn’t apply to us when we are working as the Office of Origin.
        String irNumber = gsBean.getInternationalRegistrationNumber();

        try {
            // Call MOPS using IR number
            MOPSServiceResponse resp = mopsService.getMadridRegistrationByIRNumber(irNumber);

            MadridRegistrationCurrentStatusType statusType = resp.getMadridRegistration()
                .getMadridRegistrationCurrentStatus();

            List<_int.wipo.standards.xmlschema.st96.mops.trademark.GoodsServicesType> gsTypes = Collections.emptyList();
            List<ClassDescriptionType> wipoGsTypes = new ArrayList<ClassDescriptionType>();

            if (statusType.getGoodsServicesBag() != null) {
                gsTypes = statusType.getGoodsServicesBag().getGoodsServices();

                // check for GoodsAndServicesBag
                for (_int.wipo.standards.xmlschema.st96.mops.trademark.GoodsServicesType gsType : gsTypes) {

                    if (gsType.getCommentText() != null
                        && gsType.getCommentText().getLanguageCode().equalsIgnoreCase(gsBean.getLangCode().value())) {
                        gsBean.getWipoComments().add(gsType.getCommentText().getValue());
                    }
                    _int.wipo.standards.xmlschema.st96.mops.trademark.ClassDescriptionBagType descripType = gsType
                        .getClassDescriptionBag();

                    if (descripType != null) {

                        for (_int.wipo.standards.xmlschema.st96.mops.trademark.ClassDescriptionType classType : descripType
                            .getClassDescription()) {

                            wipoGsTypes.add(transformClassDescriptionType(classType));
                        }
                    }
                }
            }

            gsBean.updateGoodsAndServicesForNANR(wipoGsTypes);

        } catch (MCServerException e) {

            logger.error("getFromMOPSPartialCeasingOO: Error parsing G&S from MOPS for transId - " + transId + " IR# - "
                + irNumber);
            throw e;
        }

        return true;
    }

    /**
     * Gets the Designation Good Service Limitation from WIPO.
     *
     * @param gsBean the gs bean
     * @param wipoXML the wipo XML
     * @return the good service from WIPO
     * @throws MCServerException
     */
    public boolean getDesignationGSLimitationFromWIPO(GoodServiceWipoBean gsBean, String wipoXML) throws MCServerException {

        logger.debug(
            "getDesignationGSLimitationFromWIPO: transId - " + gsBean.getTransactionId() + ", taskId - " + gsBean.getTaskId());

        MadridDesignationType restriction = null;

        try {
            JAXBContext jaxbMadridContext = initMadridContextIbToOffice();
            Unmarshaller unmarshallerRoot = jaxbMadridContext.createUnmarshaller();

            ByteArrayInputStream input = null;
            try {
                input = new ByteArrayInputStream(wipoXML.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {

                logger.error("getDesignationGSLimitationFromWIPO: Error encoding wipoXML in UTF8 - " + wipoXML);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.encodingerror"), e);
            }
            @SuppressWarnings("unchecked")
            JAXBElement<MadridDesignationType> transactionType = (JAXBElement<MadridDesignationType>) unmarshallerRoot
                .unmarshal(input);

            restriction = transactionType.getValue();

        } catch (JAXBException e) {

            logger.error("getDesignationGSLimitationFromWIPO: Error creating unmarshaller when parsing wipoXML - " + wipoXML);
            MCServerException mce = new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
            mce.setStackTrace(e.getStackTrace());
            throw mce;
        }

        List<ClassDescriptionType> wipoGsLimitTypes = new ArrayList<ClassDescriptionType>();
        List<ClassDescriptionType> wipoGsRemoveTypes = new ArrayList<ClassDescriptionType>();

        gsBean.setRestCategoryType(null);  // This is set to NULL.

        List<GoodsServicesLimitationType> wipsGSLTypes = Collections.emptyList();

        if (restriction.getGoodsServicesLimitationBag() != null) {
            wipsGSLTypes = restriction.getGoodsServicesLimitationBag().getGoodsServicesLimitation();
        }

        for (GoodsServicesLimitationType gslType : wipsGSLTypes) {
            List<Object> commentsOrGSCategoryAndDescList = gslType
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag();

            boolean limitedTo = false;
            boolean removeFrom = false;

            for (Object commOrGSCatAndDesc : commentsOrGSCategoryAndDescList) {

                // Get the WIPO comments if the list contains only OrderedTextTypes, otherwise check to get the
                // class descriptions that maybe limited to or being removed from the list if its a category type
                if (commOrGSCatAndDesc instanceof OrderedTextType) {
                    if (((OrderedTextType) commOrGSCatAndDesc).getLanguageCode()
                        .equalsIgnoreCase(gsBean.getLangCode().value())) {
                        gsBean.getWipoComments().add(((OrderedTextType) commOrGSCatAndDesc).getValue());
                    }
                } else if (commOrGSCatAndDesc instanceof GoodsServicesLimitationCategoryType) {
                    if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.LIST_LIMITED_TO) {
                        limitedTo = true;
                    } else if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                        removeFrom = true;
                    }
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && limitedTo) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsLimitTypes.add(classType);
                    }
                    limitedTo = false;
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && removeFrom) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsRemoveTypes.add(classType);
                    }
                    removeFrom = false;
                }
            }
        }
        gsBean.setInternationalRegistrationNumber(restriction.getInternationalRegistrationNumber());
        gsBean.updateGoodsAndServices(new ArrayList<ClassDescriptionType>(), wipoGsLimitTypes, wipoGsRemoveTypes,
            false);

        return true;
    }

    /**
     * Gets the Good Service Limitation from WIPO.
     *
     * @param gsBean the gs bean
     * @param wipoXML the wipo XML
     * @return the good service from WIPO
     * @throws MCServerException
     */
    public boolean getGoodServiceFromWIPO(GoodServiceWipoBean gsBean, String wipoXML) throws MCServerException {

        logger.debug(
            "getGoodServiceFromWIPO: transId - " + gsBean.getTransactionId() + ", taskId - " + gsBean.getTaskId());

        MadridProtectionRestrictionType restriction = null;

        try {
            JAXBContext jaxbMadridContext = initMadridContextIbToOffice();
            Unmarshaller unmarshallerRoot = jaxbMadridContext.createUnmarshaller();

            ByteArrayInputStream input = null;
            try {
                input = new ByteArrayInputStream(wipoXML.getBytes("UTF-8"));
            } catch (UnsupportedEncodingException e) {

                logger.error("getGoodServiceFromWIPO: Error encoding wipoXML in UTF8 - " + wipoXML);
                throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.encodingerror"), e);
            }
            @SuppressWarnings("unchecked")
            JAXBElement<MadridProtectionRestrictionType> transactionType = (JAXBElement<MadridProtectionRestrictionType>) unmarshallerRoot
                .unmarshal(input);

            restriction = transactionType.getValue();

        } catch (JAXBException e) {

            logger.error("getGoodServiceFromWIPO: Error creating unmarshaller when parsing wipoXML - " + wipoXML);
            MCServerException mce = new MCServerException(MadridConsoleUtils.getMessage("mc.error.unmarshallerror"), e);
            mce.setStackTrace(e.getStackTrace());
            throw mce;
        }

        List<ClassDescriptionType> wipoGsLimitTypes = new ArrayList<ClassDescriptionType>();
        List<ClassDescriptionType> wipoGsRemoveTypes = new ArrayList<ClassDescriptionType>();

        gsBean.setRestCategoryType(restriction.getMadridProtectionRestrictionCategory());

        // ignore the notification language and check the language from INTREPID statements. This should have
        // been set when retrieving INTREPID data
        // ISOLanguageCodeType noteLanguage = restriction.getNotificationLanguage();
        // gsBean.setLangCode(noteLanguage);
        // String lang = "EN";
        // if (noteLanguage.equals(ISOLanguageCodeType.EN) || noteLanguage.equals(ISOLanguageCodeType.FR)) {
        // lang = noteLanguage.toString();
        // }

        List<GoodsServicesLimitationType> wipsGSLTypes = Collections.emptyList();

        if (restriction.getGoodsServicesLimitationBag() != null) {
            wipsGSLTypes = restriction.getGoodsServicesLimitationBag().getGoodsServicesLimitation();
        }

        for (GoodsServicesLimitationType gslType : wipsGSLTypes) {
            List<Object> commentsOrGSCategoryAndDescList = gslType
                .getCommentTextOrGoodsServicesLimitationCategoryAndLimitationClassDescriptionBag();

            boolean limitedTo = false;
            boolean removeFrom = false;

            for (Object commOrGSCatAndDesc : commentsOrGSCategoryAndDescList) {
                // logger.debug("comments list " + commOrGSCatAndDesc);

                // Get the WIPO comments if the list contains only OrderedTextTypes, otherwise check to get the
                // class descriptions that maybe limited to or being removed from the list if its a category type
                if (commOrGSCatAndDesc instanceof OrderedTextType) {
                    if (((OrderedTextType) commOrGSCatAndDesc).getLanguageCode()
                        .equalsIgnoreCase(gsBean.getLangCode().value())) {
                        gsBean.getWipoComments().add(((OrderedTextType) commOrGSCatAndDesc).getValue());
                    }
                } else if (commOrGSCatAndDesc instanceof GoodsServicesLimitationCategoryType) {
                    if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.LIST_LIMITED_TO) {
                        limitedTo = true;
                    } else if (((GoodsServicesLimitationCategoryType) commOrGSCatAndDesc) == GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                        removeFrom = true;
                    }
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && limitedTo) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsLimitTypes.add(classType);
                    }
                    limitedTo = false;
                } else if ((commOrGSCatAndDesc instanceof ClassDescriptionBagType) && removeFrom) {
                    List<ClassDescriptionType> classTypes = ((ClassDescriptionBagType) commOrGSCatAndDesc)
                        .getClassDescription();
                    for (ClassDescriptionType classType : classTypes) {
                        wipoGsRemoveTypes.add(classType);
                    }
                    removeFrom = false;
                }
            }
        }
        gsBean.setInternationalRegistrationNumber(restriction.getInternationalRegistrationNumber());
        gsBean.updateGoodsAndServices(new ArrayList<ClassDescriptionType>(), wipoGsLimitTypes, wipoGsRemoveTypes,
            false);

        return true;
    }

    /**
     * Gets the good service from INTREPID.
     *
     * @param gsBean the gs bean
     * @param fileNumber the file number
     * @return the good service from INTREPID
     * @throws MCServerException
     */
    public void getGoodServiceFromIntrepid(GoodServiceWipoBean gsBean, int fileNumber) throws MCServerException {

        logger.debug("getGoodServiceFromIntrepid: transId - " + gsBean.getTransactionId() + ", taskId - "
            + gsBean.getTaskId() + ", file number - " + fileNumber);

        TrademarkApplicationType trademarkApplicationType = tirsService.getApplicationByNumber(fileNumber);

        gsBean.setApplication(trademarkApplicationType);

        if (trademarkApplicationType != null) {

            List<GoodsServicesClaimsType> gsTypes = tirsService.getClaimsByGoodsService(fileNumber);

            // FIXME: There is an issue of the TIRS.getClaimsByGoodsService and it does not include translations. The
            // following
            // code is for mocking purpose only.

            // for (GoodsServicesClaimsType goodsServicesClaimsType : gsTypes) {
            // _int.wipo.standards.xmlschema.st96.common.LocalizedTextType translatedText = new
            // _int.wipo.standards.xmlschema.st96.common.LocalizedTextType();
            // translatedText.setLanguageCode("fr");
            // translatedText.setValue("Translated french. blah blah blah...");
            //
            // goodsServicesClaimsType.getStatement().setStatementDescriptionTranslated(translatedText);
            //
            // }
            ///////////////////////////////////////

            gsBean.setIntrepidGsTypes(gsTypes);

            // TODO: can we assume that the language of the first statement will be same for all statements
            // and just take the language from the first. Doing a for loop doesn't help if it's different for
            // each statement anyway.
            for (GoodsServicesClaimsType gsType : gsTypes) {
                if (gsType.getStatement().getStatementDescription().getLanguageCode()
                    .equalsIgnoreCase(ISOLanguageCodeType.EN.value())) {
                    gsBean.setLangCode(ISOLanguageCodeType.EN);
                } else {
                    gsBean.setLangCode(ISOLanguageCodeType.FR);
                }
                // logger.debug(gsType.getStatement().getStatementDescription().getValue());
            }
        }
    }

    /**
     * Gets the good service from INTREPID for OO partial ceasing.
     *
     * @param gsBean the gs bean
     * @return the good service from INTREPID for OO partial ceasing
     * @throws MCServerException
     */
    public void getGoodServiceFromIntrepidForOOPartialCeasing(GoodServiceWipoBean gsBean, int fileNumber)
        throws MCServerException {

        logger.debug("getGoodServiceFromIntrepidForOOPartialCeasing: transId - " + gsBean.getTransactionId()
            + ", taskId - " + gsBean.getTaskId());

        // Get the file number of the IR from the Application table
        TrademarkApplicationType irtrademarkApplicationType = tirsService.getApplicationByNumber(fileNumber);
        gsBean.setApplication(irtrademarkApplicationType);

        // Get the domestic basic marks that make up the IR from INTREPID. Each of these will have their own file
        // numbers
        List<ApplicationNumber> apps = tirsService.getApplications(gsBean.getInternationalRegistrationNumber());

        List<MadridApplicationEventType> madridActions = tirsService
            .getMadridApplicationEvents(gsBean.getInternationalRegistrationNumber());

        Date createdDate = null;
        if (CollectionUtils.isNotEmpty(madridActions)) {
            for (MadridApplicationEventType madridAction : madridActions) {
                if (madridAction.getActionCode() == MadridApplicationActionStatus.CREATED.getValue()) {
                    createdDate = madridAction.getActionDate().toGregorianCalendar().getTime();

                }
            }
        }

        for (ApplicationNumber app : apps) {
            TrademarkApplicationType trademarkApplicationType = tirsService.getApplicationByNumber(app);

            if (trademarkApplicationType != null) {

                List<ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType> gsTypes = tirsService
                    .getGoodsServices(app);

                String markStatus = null;
                String modifiedDateString = null;
                if (trademarkApplicationType.getApplicationStatus() != null && CollectionUtils
                    .isNotEmpty(trademarkApplicationType.getApplicationStatus().getApplicationStatusText())) {
                    for (_int.wipo.standards.xmlschema.st96.common.LocalizedTextType localizedTextType : trademarkApplicationType
                        .getApplicationStatus().getApplicationStatusText()) {
                        if (StringUtils.equals(localizedTextType.getLanguageCode(), ISOLanguageCodeType.EN.value())) {
                            markStatus = localizedTextType.getValue();
                            break;
                        }

                    }
                }

                gsBean.addBasicMarks(app.getFileNumber(), app.getExtensionCounter(), gsTypes, markStatus,
                    modifiedDateString);

                // TODO: can we assume that the language of the first statement will be same for all statements
                // and just take the language from the first. Doing a for loop doesn't help if it's different
                // for each statement anyway.
                for (ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType gsType : gsTypes) {
                    if (gsType.getStatement().getStatementDescription().getLanguageCode()
                        .equalsIgnoreCase(ISOLanguageCodeType.EN.value())) {
                        gsBean.setLangCode(ISOLanguageCodeType.EN);
                    } else {
                        gsBean.setLangCode(ISOLanguageCodeType.FR);
                    }
                    // logger.debug(gsType.getStatement().getStatementDescription().getValue());
                }
                // Also organize the basic marks by nice class to display beside the WIPO information
                for (ca.gc.ic.cipo.xmlschema.trademark.extended.GoodsServicesType gsType : gsTypes) {

                    // Also for each basic marks goods/services statement we need to flag (put “(modified)” beside the
                    // File Number and Status when the Modified_Timestamp of the Goods/Services is > the Created Date
                    // for the AIR.
                    modifiedDateString = null;
                    if (gsType.getModifiedDate() != null && createdDate != null) {
                        Date modifiedDate = gsType.getModifiedDate().toGregorianCalendar().getTime();
                        if (modifiedDate.after(createdDate)) {
                            modifiedDateString = DateFormats.getISOSDF().format(modifiedDate);

                        }

                    }

                    if (gsType.getClassification().getClassNumber() != null) {
                        int intNiceClass = Integer.parseInt(gsType.getClassification().getClassNumber());
                        gsBean.addIntrepidGsTypesForBasicMarks(intNiceClass, app.getFileNumber(),
                            app.getExtensionCounter(), gsType, markStatus, modifiedDateString);
                    }
                }
            }
        }
    }

    /**
     * Generate good service bean.
     *
     * @param request the request
     * @param fileNumber the file number
     * @param transId the trans id
     * @param taskId the task id
     * @param actId the act id
     * @param gsBean the gs bean
     * @param formName the form name
     * @throws MCServerException the MC server exception
     */
    public void generateGoodServiceBean(HttpServletRequest request, int fileNumber, BigDecimal transId,
                                        BigDecimal taskId, String actId, GoodServiceWipoBean gsBean, String formName)
        throws MCServerException {

        logger.debug("generateGoodServiceBean: transId - " + gsBean.getTransactionId() + ", taskId - "
            + gsBean.getTaskId() + ", fileNumber - " + fileNumber + ", actId - " + actId + ", forName - " + formName);

        if (formName.equals(TradMarkApplicationService.OOPARTIALCEASING_FORM)
            || formName.equals(TradMarkApplicationService.BASICAPPLICATION_FORM)
            || formName.equals(TradMarkApplicationService.TOTALCEASINGOO_FORM)) {
            getGoodServiceFromIntrepidForOOPartialCeasing(gsBean, fileNumber);
        } /*
           * else if (formName.equals(TradMarkApplicationService.TOTALCEASINGOO_FORM)) { TrademarkApplicationType
           * trademarkApplicationType = tirsService.getApplicationByNumber(fileNumber);
           * gsBean.setApplication(trademarkApplicationType); }
           */
        else {
            getGoodServiceFromIntrepid(gsBean, fileNumber);
        }
        getGoodServiceFromTransaction(request, gsBean, transId, taskId, actId, formName);
    }

    /**
     * Gets the good service from transaction, based on the FORM (for example: irregularity, correction, etc)
     *
     * @param request the request
     * @param gsBean the gs bean
     * @param transId the trans id
     * @param taskId the task id
     * @param actId the act id
     * @param formName the form name
     * @return boolean indicating if Goods and Services were able to be generated
     * @throws MCServerException the MC server exception
     */
    public boolean getGoodServiceFromTransaction(HttpServletRequest request, GoodServiceWipoBean gsBean,
                                                 BigDecimal transId, BigDecimal taskId, String actId, String formName)
        throws MCServerException {

        logger.debug("getGoodServiceFromTransaction: transId - " + transId + ", FormName - " + formName);

        gsBean.setTransactionId(transId);
        gsBean.setTransactionDetail(transactionService.getTransaction(transId, true, true));

        gsBean.setTaskId(taskId);
        gsBean.setActivityTaskId(actId);
        gsBean.setFormType(formName);

        // The value in the XMLContent, will depend on the Transaction Type (or form)
        if (formName.equals(TradMarkApplicationService.IRREGULARITY_FORM)) {
            return getGoodServiceFromWIPOForIrregularity(gsBean,
                ServiceUtil.stripCDATA(transactionService.getXmlContent(transId, true)));
        } else if (formName.equals(TradMarkApplicationService.IRCORRECTION_FORM)) {
            return getGoodServiceFromWIPOForIrCorrection(gsBean,
                ServiceUtil.stripCDATA(transactionService.getXmlContent(transId, true)));
        } else if (formName.equals(TradMarkApplicationService.EDIT_MAILING_LABEL_FORM)) {
            return getGoodServiceFromWIPOForEditMailingLabel(gsBean, transId);
        } else if (formName.equals(TradMarkApplicationService.PARTIALOWNERSHIP_FORM)) {
            return getGoodServiceFromWIPOForPartialOwnership(gsBean,
                ServiceUtil.stripCDATA(transactionService.getXmlContent(transId, true)));
        } else if (formName.equals(TradMarkApplicationService.MF3A_FORM)) {
            return true; // For the MF3A, there should be not Information From WIPO.
        } else if (formName.equals(TradMarkApplicationService.OOPARTIALCEASING_FORM)) {
            return getFromMOPSPartialCeasingOO(gsBean, transId); // get the WIPO info from MOPS
        } else if (formName.equals(TradMarkApplicationService.BASICAPPLICATION_FORM)) {
            return getFromMOPSPartialCeasingOO(gsBean, transId); // get the WIPO info from MOPS
        } else if (formName.equals(TradMarkApplicationService.DESIGNATIONGOODSERVICESLIMITATION_FORM)) {
            return getDesignationGSLimitationFromWIPO(gsBean,
                ServiceUtil.stripCDATA(transactionService.getXmlContent(transId, true)));
        } else if (formName.equals(TradMarkApplicationService.TOTALCEASINGOO_FORM)) {
            return true;
        } else {
            return getGoodServiceFromWIPO(gsBean,
                ServiceUtil.stripCDATA(transactionService.getXmlContent(transId, true)));
        }
    }

    private static JAXBContext initContext() {
        try {
            return JAXBContext.newInstance(MadridIBToOfficeTransactionType.class,
                MadridIBToOfficeTransactionType.class);
        } catch (JAXBException e) {
            logger.error("initContext: An error occurred while getting JAXBContext instance", e);
        }
        return null;
    }

    /**
     * Process the good service change.
     *
     * @param request the request
     * @param gsBean the gs bean
     * @return the int
     * @throws MCServerException the MC server exception
     */
    public int processGoodServiceChange(HttpServletRequest request, GoodServiceWipoBean gsBean)
        throws MCServerException {

        logger.debug(
            "processGoodServiceChange: transId - " + gsBean.getTransactionId() + ", taskId - " + gsBean.getTaskId());

        GoodsAndServiceMeta gsData = createGoodServiceMeta(request, gsBean);

        GoodsAndServicesChangesResponse response = transactionService.processGoodsAndServicesChanges(gsData);

        return response.getStatus();
    }

    /**
     * Set the Create a Goods and Service Meta Data, based on data in the Goods and Services Bean.
     *
     * @param gsBean the gs bean
     * @return GoodsAndServiceMeta
     */
    public GoodsAndServiceMeta createGoodServiceMeta(HttpServletRequest request, GoodServiceWipoBean gsBean) {

        logger.debug(
            "createGoodServiceMeta: transId - " + gsBean.getTransactionId() + ", taskId - " + gsBean.getTaskId());

        GoodsAndServiceMeta gsData = new GoodsAndServiceMeta();

        if (gsBean.getApplication() != null && gsBean.getApplication().getApplicationNumber() != null) {
            gsData.setFileNumber(BigDecimal.valueOf(gsBean.getApplication().getApplicationNumber().getFileNumber()));
            gsData.setExtensioncounter(
                String.valueOf(gsBean.getApplication().getApplicationNumber().getExtensionCounter()));
        }
        if (gsBean.getServiceItemType() != null) { // can be null in case of partial ownership
            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_RETURN_lIMIT_NO_EFFECT)) {
                gsData.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_NO_EFFECT);
            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) {
                gsData.setUserSelectType(GoodServiceSelectionType.ACCEPT_ALL);
            } else if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO_ADJUSTMENT)) {
                gsData.setUserSelectType(GoodServiceSelectionType.ACCEPT_WITH_ADJUSTMENT);
            }
        }

        if (gsBean.getRestCategoryType() == MadridProtectionRestrictionCategoryType.PARTIAL_CANCELLATION) {
            gsData.setTaskType(GoodServiceTaskType.PARTIAL_CANCELLATION);
        } else if (gsBean.getRestCategoryType() == MadridProtectionRestrictionCategoryType.LIMITATION) {
            gsData.setTaskType(GoodServiceTaskType.GOOD_SERVICE_LIMITATION);
        } else if (gsBean.getRestCategoryType() == MadridProtectionRestrictionCategoryType.PARTIAL_CEASING_OF_EFFECT) {
            gsData.setTaskType(GoodServiceTaskType.PARTIAL_CEASING_EFFECT);
        } else if (gsBean
            .getRestCategoryType() == MadridProtectionRestrictionCategoryType.PARTIAL_CHANGE_OF_OWNERSHIP) {
            // gsData.setTaskType(GoodServiceTaskType.);
        } else {
            if (gsBean.getFormType().equals(TradMarkApplicationService.OOPARTIALCEASING_FORM)) {
                gsData.setTaskType(GoodServiceTaskType.NANR_PARTIAL_CEASING_EFFECT);
            } else if (gsBean.getFormType().equals(TradMarkApplicationService.BASICAPPLICATION_FORM)) {
                gsData.setTaskType(GoodServiceTaskType.MADRID_NEW_BASIC_APPLICATION);
            } else if (gsBean.getFormType().equals(TradMarkApplicationService.TOTALCEASINGOO_FORM)) {
                gsData.setTaskType(GoodServiceTaskType.TOTAL_CEASING_EFFECT);
            } else if(gsBean.getFormType().equals(TradMarkApplicationService.DESIGNATIONGOODSERVICESLIMITATION_FORM)) {
                gsData.setTaskType(GoodServiceTaskType.DESIGNATION_LIMITATION);
            }
        }
        gsData.setTaskId(gsBean.getTaskId());

        gsData.setInternationalRegistrationNumber(gsBean.getInternationalRegistrationNumber());

        // Copy good&service information
        GoodsServicesClassificationList goodServiceList = new GoodsServicesClassificationList();

        // Create Basic Application
        if (gsData.getTaskType() == GoodServiceTaskType.MADRID_NEW_BASIC_APPLICATION) {
            List<ReturnObjForBasicMarks> marks = gsBean.getBasicMarksWithGS();

            for (ReturnObjForBasicMarks mark : marks) {
                if (mark.isSelected()) {
                    ca.gc.ic.cipo.tm.mts.ApplicationNumber mtsAppNum = new ca.gc.ic.cipo.tm.mts.ApplicationNumber();
                    mtsAppNum.setFileNumber(new BigDecimal(mark.getFileNumber()));
                    mtsAppNum.setExtensionCounter(mark.getExtensionCounter() + "");
                    gsData.getBasicMarkList().add(mtsAppNum);
                }
            }
        } else if (gsData.getTaskType() != GoodServiceTaskType.NANR_PARTIAL_CEASING_EFFECT) { // Any other G&S tasks

            List<ReturnObjForGoodsAndServices> gsList = gsBean.getGoodsAndServices();

            for (ReturnObjForGoodsAndServices gs : gsList) {
                if (CollectionUtils.isNotEmpty(gs.getFinalGSType())) {
                    for (GoodsServicesClaimsType cipoType : gs.getFinalGSType()) {

                        if (cipoType != null) {
                            GoodsServicesClassificationType gsType = new GoodsServicesClassificationType();
                            if (cipoType.isSetClassification()) {
                                gsType
                                    .setClassificationVersion(cipoType.getClassification().getClassificationVersion());
                                gsType.setClassNumber((cipoType.getClassification().getClassNumber()));

                                // gsType.setClassTitleText(cipoType.getClassification().getClassTitleText());
                            }
                            // if we are accepting all from wipo, make sure we pass all the statements for all languages
                            if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) {
                                for (OrderedTextType ot : gs.getWipoGSType().getGoodsServicesDescriptionText()) {
                                    ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                                    orderedTextType.setLanguageCode(ot.getLanguageCode());
                                    orderedTextType.setValue(ot.getValue());
                                    gsType.getClassTitleText().add(orderedTextType);
                                }
                            } else if (cipoType.isSetStatement()) { // pass the statement for the notification language
                                ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                                orderedTextType.setLanguageCode(gsBean.getLangCode().value());
                                orderedTextType.setValue(cipoType.getStatement().getStatementDescription().getValue());
                                gsType.getClassTitleText().add(orderedTextType);
                            }
                            if (cipoType.isSetGoodsServiceNumber()) {
                                gsType.setWsNumber(cipoType.getGoodsServiceNumber());
                            }
                            if (cipoType.isSetGoodsServiceType()) {
                                gsType.setWsType(cipoType.getGoodsServiceType());
                            }

                            for (FinalGoodsServicesWrapper finalGsWrapper : gs.getFinalGSWrapper()) {
                                if (Integer.parseInt(cipoType.getClassification().getClassNumber()) == finalGsWrapper
                                    .getClassNum() && finalGsWrapper.isFromWipo()) {

                                    // Remove From List instruction to remove the GS from backend Intrepid.
                                    if (finalGsWrapper.getGoodsServicesLimitationCategoryType() != null
                                        && finalGsWrapper
                                            .getGoodsServicesLimitationCategoryType() == GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                                        gsType = null;
                                    } else {
                                        // WIPO statement to replace Intrepid statement and needs to be identified as
                                        // modified with a timestamp.
                                        gsType.setModified(true);

                                        gsType.setClassificationVersion(gs.getWipoGSType().getClassificationVersion());

                                        if (!finalGsWrapper.isEdited()) {
                                            gsType.getClassTitleText().clear();

                                            for (OrderedTextType ot : gs.getWipoGSType()
                                                .getGoodsServicesDescriptionText()) {
                                                if (MadridLanguageSet.contains(ot.getLanguageCode())) {
                                                    ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                                                    orderedTextType.setLanguageCode(ot.getLanguageCode());
                                                    orderedTextType.setValue(ot.getValue());
                                                    gsType.getClassTitleText().add(orderedTextType);
                                                }
                                            }

                                        }
                                    }

                                } else if (Integer.parseInt(
                                    cipoType.getClassification().getClassNumber()) == finalGsWrapper.getClassNum()
                                    && !finalGsWrapper.isFromWipo()) {

                                    gsType.setClassificationVersion(
                                        cipoType.getClassification().getClassificationVersion());

                                    gsType.setModified(true);
                                    if (!finalGsWrapper.isEdited()
                                        && CollectionUtils.isNotEmpty(gs.getIntrepidGSType())) {

                                        gsType.setModified(false);

                                        gsType.getClassTitleText().clear();

                                        for (GoodsServicesClaimsType gsClaim : gs.getIntrepidGSType()) {
                                            if (gsClaim.getStatement() != null
                                                && gsClaim.getStatement().getStatementDescription() != null
                                                && StringUtils.isNotBlank(
                                                    gsClaim.getStatement().getStatementDescription().getValue())) {
                                                ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                                                orderedTextType.setLanguageCode(
                                                    gsClaim.getStatement().getStatementDescription().getLanguageCode());
                                                orderedTextType.setValue(
                                                    gsClaim.getStatement().getStatementDescription().getValue());

                                                gsType.getClassTitleText().add(orderedTextType);

                                            }

                                            if (gsClaim.getStatement() != null
                                                && gsClaim.getStatement().getStatementDescriptionTranslated() != null
                                                && StringUtils.isNotBlank(gsClaim.getStatement()
                                                    .getStatementDescriptionTranslated().getValue())) {
                                                ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextTranslatedType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                                                orderedTextTranslatedType.setLanguageCode(gsClaim.getStatement()
                                                    .getStatementDescriptionTranslated().getLanguageCode());
                                                orderedTextTranslatedType.setValue(gsClaim.getStatement()
                                                    .getStatementDescriptionTranslated().getValue());
                                                gsType.getClassTitleText().add(orderedTextTranslatedType);

                                            }

                                        }

                                    }

                                }
                            }

                            if (gsType != null) {
                                goodServiceList.getTaskListBag().add(gsType);
                            }

                        }
                    }
                }
            }

        } else { // NA NR Partial Ceasing

            List<ReturnObjForGoodsAndServicesForNANR> gsList = gsBean.getGoodsAndServicesNANR();

            for (ReturnObjForGoodsAndServicesForNANR gs : gsList) {
                ClassDescriptionType cipoType = gs.getFinalGSType();

                if (cipoType != null) {
                    GoodsServicesClassificationType gsType = new GoodsServicesClassificationType();

                    gsType.setClassificationVersion(cipoType.getClassificationVersion());
                    gsType.setClassNumber((cipoType.getClassNumber()));

                    // if we are accepting all from WIPO, make sure we pass all the statements for all languages
                    // but the preferred language will be what's already set in INTREPID
                    if (gsBean.getServiceItemType().equals(MadridServiceItemType.GOODSERVICE_ACCEPT_WIPO)) {
                        for (OrderedTextType ot : gs.getWipoGSType().getGoodsServicesDescriptionText()) {
                            ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                            orderedTextType.setLanguageCode(ot.getLanguageCode());
                            orderedTextType.setValue(ot.getValue());
                            gsType.getClassTitleText().add(orderedTextType);
                            gsType.setModified(true);
                        }
                    } else {

                        for (OrderedTextType ot : cipoType.getGoodsServicesDescriptionText()) {

                            // pass only the statement for the preferred language in INTREPID language as the user may
                            // have modified it and there is no point in saving the text for other languages.
                            if (ot.getLanguageCode().equalsIgnoreCase(gsBean.getLangCode().value())) {
                                ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                                orderedTextType.setLanguageCode(ot.getLanguageCode());
                                orderedTextType.setValue(ot.getValue());
                                gsType.getClassTitleText().add(orderedTextType);
                                break;
                            }
                        }
                    }

                    if (gsType != null) {
                        goodServiceList.getTaskListBag().add(gsType);
                    }

                }
            }
            // pass the basic marks as well for updating the MADRID_APPLICATIONS and MARDID_APPLICATION_XREF tables
            // in the case of partial.In case there are no goods and services in final, send all the marks
            List<ReturnObjForBasicMarks> marks = gsBean.getBasicMarksWithGS();

            for (ReturnObjForBasicMarks mark : marks) {
                if (mark.isSelected() || goodServiceList.getTaskListBag().isEmpty()) {
                    ca.gc.ic.cipo.tm.mts.ApplicationNumber mtsAppNum = new ca.gc.ic.cipo.tm.mts.ApplicationNumber();
                    mtsAppNum.setFileNumber(new BigDecimal(mark.getFileNumber()));
                    mtsAppNum.setExtensionCounter(mark.getExtensionCounter() + "");
                    gsData.getBasicMarkList().add(mtsAppNum);
                }
            }
        }
        if (gsData.getBasicMarkList().size() == 0) {
            // total Ceasing
            if (gsBean.getFormType().equals(TradMarkApplicationService.BASICAPPLICATION_FORM)
                || gsBean.getFormType().equals(TradMarkApplicationService.TOTALCEASINGOO_FORM)) {
                gsData.setTaskType(GoodServiceTaskType.TOTAL_CEASING_EFFECT);
            }
        }

        gsData.setNotificationLanguage(gsBean.getLangCode().value()); // not needed probably
        gsData.setMergedGoodServices(goodServiceList);
        gsData.setAuthorityId(userProfileService.getAuthorityId(request));
        return gsData;
    }

    /**
     * Process good service change.
     *
     * @param request the request
     * @param gsBean the gs bean
     * @return the int
     * @throws MCServerException the MC server exception
     */
    public int processPartialOwnershipChange(HttpServletRequest request, GoodServiceWipoBean gsBean)
        throws MCServerException {

        logger.debug("processPartialOwnershipChange: transId - " + gsBean.getTransactionId() + ", taskId - "
            + gsBean.getTaskId());

        // Current owner
        PartialOwnershipMeta restriction = createPartialOwnershipMeta(request, gsBean,
            gsBean.getInternationalRegistrationNumberForPreviousOwner(), gsBean.getGoodsAndServicesForPreviousOwner());

        // New owner
        PartialOwnershipMeta designation = createPartialOwnershipMeta(request, gsBean,
            gsBean.getInternationalRegistrationNumber(), gsBean.getGoodsAndServices());

        GoodsAndServicesChangesResponse response = transactionService.processPartialOwnership(gsBean.getTaskId(),
            gsBean.getLangCode().value(), designation, restriction);

        return response.getStatus();
    }

    /**
     * Set the Create a PartialOwnership Meta Data, based on data in the Goods and Services Bean for new owner
     *
     * @param gsBean the gs bean
     * @return PartialOwnershipMeta
     */
    public PartialOwnershipMeta createPartialOwnershipMeta(HttpServletRequest request, GoodServiceWipoBean gsBean,
                                                           String irNumber, List<ReturnObjForGoodsAndServices> gsList) {

        logger.debug(
            "createPartialOwnershipMeta: transId - " + gsBean.getTransactionId() + ", taskId - " + gsBean.getTaskId());

        PartialOwnershipMeta gsData = new PartialOwnershipMeta();

        if (gsBean.getApplication() != null && gsBean.getApplication().getApplicationNumber() != null) {
            gsData.setFileNumber(BigDecimal.valueOf(gsBean.getApplication().getApplicationNumber().getFileNumber()));
            gsData.setExtensioncounter(
                String.valueOf(gsBean.getApplication().getApplicationNumber().getExtensionCounter()));
        }

        gsData.setInternationalRegistrationNumber(irNumber);

        // Copy good&service information
        GoodsServicesClassificationList goodServiceList = new GoodsServicesClassificationList();

        for (ReturnObjForGoodsAndServices gs : gsList) {
            if (gs.getFinalGSType() != null) {
                for (GoodsServicesClaimsType cipoType : gs.getFinalGSType()) {

                    if (cipoType != null) {

                        // Compare if the final statement is edited from WIPO's content or not.
                        GoodsServicesClassificationType gsType = new GoodsServicesClassificationType();
                        if (cipoType.isSetClassification()) {
                            gsType.setClassificationVersion(cipoType.getClassification().getClassificationVersion());
                            gsType.setClassNumber((cipoType.getClassification().getClassNumber()));

                            // gsType.setClassTitleText(cipoType.getClassification().getClassTitleText());
                        }
                        if (cipoType.isSetStatement()) { // pass the statement for the notification language
                            ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();
                            orderedTextType.setLanguageCode(gsBean.getLangCode().value());
                            orderedTextType.setValue(cipoType.getStatement().getStatementDescription().getValue());
                            gsType.getClassTitleText().add(orderedTextType);
                        }
                        if (cipoType.isSetGoodsServiceNumber()) {
                            gsType.setWsNumber(cipoType.getGoodsServiceNumber());
                        }
                        if (cipoType.isSetGoodsServiceType()) {
                            gsType.setWsType(cipoType.getGoodsServiceType());
                        }

                        // Set Translation for GS copied from Intrepid transaction
                        for (FinalGoodsServicesWrapper gsWrapper : gs.getFinalGSWrapper()) {
                            if (!gsWrapper.isFromWipo() && !gsWrapper.isEdited()) {
                                for (GoodsServicesClaimsType intrepidGsType : gs.getIntrepidGSType()) {
                                    if (gsWrapper.getClassNum() == Integer
                                        .parseInt(intrepidGsType.getClassification().getClassNumber())) {

                                        ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();

                                        orderedTextType.setLanguageCode(intrepidGsType.getStatement()
                                            .getStatementDescriptionTranslated().getLanguageCode());

                                        orderedTextType.setValue(intrepidGsType.getStatement()
                                            .getStatementDescriptionTranslated().getValue());

                                        gsType.getClassTitleText().add(orderedTextType);

                                    }

                                }

                                gsType.setModified(false);
                            } else if (!gsWrapper.isFromWipo() && gsWrapper.isEdited()) {
                                gsType.setModified(true);
                            }

                        }

                        // Set Translation for GS copied from WIPO transaction.
                        for (FinalGoodsServicesWrapper gsWrapper : gs.getFinalGSWrapper()) {
                            if (gsWrapper.isFromWipo()) {
                                gsType.setModified(true);
                            }

                            if (gsWrapper.isFromWipo() && !gsWrapper.isEdited()) {

                                if (gsWrapper.getClassNum() == Integer.parseInt(gs.getWipoGSType().getClassNumber())) {

                                    gsType.getClassTitleText().clear();

                                    for (OrderedTextType wipoGsText : gs.getWipoGSType()
                                        .getGoodsServicesDescriptionText()) {

                                        if (MadridLanguageSet.contains(wipoGsText.getLanguageCode().trim())) {
                                            ca.gc.ic.cipo.tm.mts.OrderedTextType orderedTextType = new ca.gc.ic.cipo.tm.mts.OrderedTextType();

                                            orderedTextType.setLanguageCode(wipoGsText.getLanguageCode());
                                            orderedTextType.setValue(wipoGsText.getValue());
                                            gsType.getClassTitleText().add(orderedTextType);
                                        }

                                    }

                                }
                            }
                            // Remove From List will remove it from backend Intrepid.
                            if (gsWrapper.isFromWipo() && gsWrapper.getGoodsServicesLimitationCategoryType() != null
                                && gsWrapper
                                    .getGoodsServicesLimitationCategoryType() == GoodsServicesLimitationCategoryType.REMOVE_FROM_LIST) {
                                gsType = null;
                            }

                        }

                        if (gsType != null) {
                            goodServiceList.getTaskListBag().add(gsType);
                        }

                    }
                }
            }
        }

        gsData.setMergedGoodServices(goodServiceList);
        gsData.setAuthorityId(userProfileService.getAuthorityId(request));
        return gsData;
    }

    /**
     * Obtain the MF3A data.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @param taskId the task id
     * @param transactionId the transaction id
     * @throws MCServerException the MC server exception
     */
    public void obtainMF3A(HttpServletRequest request, GoodServiceWipoBean gsBean, String taskId, String transactionId)
        throws MCServerException {

        logger.debug("obtainMF3A  transId: " + transactionId + ", taskId:" + taskId);

        // Populate the MF3A Request.
        GetManualReport getManualReport = new GetManualReport();
        GetManualReportRequest getManualReportRequest = new GetManualReportRequest();

        getManualReportRequest.setTaskId(new BigDecimal(taskId));
        getManualReportRequest.setTransactionId(new BigDecimal(transactionId));

        getManualReport.setManualReport(getManualReportRequest);

        // Call the Service to get the MF3A data.
        ProcessManualReportRequest processManualReportRequest = transactionService.obtainMF3A(getManualReportRequest);

        processManualReportRequest.setTaskId(new BigDecimal(taskId));
        processManualReportRequest.setTransactionId(new BigDecimal(transactionId));

        MF3A mf3a = new MF3A();
        mf3a.setMf3aData(processManualReportRequest);
        gsBean.setMf3a(mf3a);

        return;
    }

    /**
     * Submit the MF3A form to WIPO.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @throws MCServerException the MC server exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void processMF3A(HttpServletRequest request, GoodServiceWipoBean gsBean)
        throws MCServerException, IOException {

        logger.debug("processMF3A  transId: " + gsBean.getTransactionId() + ", taskId: "
            + gsBean.getMf3a().getMf3aRequest().getTaskId());

        // Add/Attach the Files to the gsBean.
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Iterator<String> iterator = multipartRequest.getFileNames();
        AttachmentList attachmentList = new AttachmentList();
        Attachment attachment = new Attachment();
        while (iterator.hasNext()) {
            String uploadedFileName = iterator.next();
            if (!uploadedFileName.equals("attachmentInfo.file")
                && (!uploadedFileName.contains("citedMarkAttachmentInfo"))) {
                MultipartFile inputFiles = multipartRequest.getFile(uploadedFileName);
                attachment.setFileName(inputFiles.getOriginalFilename());
                DataHandler handler = new DataHandler(inputFiles.getBytes(), "application/octet-stream");
                attachment.setFileContent(handler);
                attachmentList.getAttachmentListBag().add(attachment);
            }
        }
        gsBean.getMf3a().getMf3aRequest().setAttachmentList(attachmentList);
        logger.debug("/processtask/MF3A Number of MF3A Files: "
            + gsBean.getMf3a().getMf3aRequest().getAttachmentList().getAttachmentListBag().size());

        // Send to Madrid Transaction Service (MTS)
        transactionService.processManualReport(gsBean.getMf3a().getMf3aRequest());

        return;
    }

    /**
     * Submit the IRRegularity (actually it is just 1 field...Comments) to MTS (Madrid Transaction Service).
     *
     * @param gsBean - GoodServiceWipoBean
     * @param authorityId - Authority Id
     * @throws MCServerException the MC server exception
     *
     */
    public void submitIRRegularity(GoodServiceWipoBean gsBean, String authorityId) throws MCServerException {

        logger.debug(
            "submitIRRegularity  transId: " + gsBean.getTransactionId() + ", Task: " + gsBean.getActivityTaskId());

        // Populate the Irregularity Submission Request.
        ProcessIrregularitySubmissionRequest processIrregularitySubmissionRequest = new ProcessIrregularitySubmissionRequest();
        processIrregularitySubmissionRequest
            .setResponseText(gsBean.getIrregularityDetail().getIrregularityCommentsInput());
        processIrregularitySubmissionRequest.setTaskId(gsBean.getTaskId());
        processIrregularitySubmissionRequest.setAuthorityId(authorityId);

        // Send to Madrid Transaction Service (MTS)
        transactionService.processIRRegularity(processIrregularitySubmissionRequest);

        return;
    }

    /**
     * Update the Mail Processed Status Flas for the Irregularity
     *
     * @param gsBean - GoodServiceWipoBean
     * @param authorityId - Authority Id
     * @throws MCServerException the MC server exception
     *
     */
    public void submitUpdateMailProcStatusIRRegularity(GoodServiceWipoBean gsBean, String authorityId)
        throws MCServerException {

        logger.debug("submitUpdateMailProcStatusIRRegularity  transId: " + gsBean.getTransactionId() + ", Task: "
            + gsBean.getActivityTaskId());

        // Send to Madrid Transaction Service (MTS)
        transactionService.processMailProcStatusIRRegularity(
            gsBean.getApplication().getApplicationNumber().getFileNumber(), authorityId);

        return;
    }

    /**
     * Obtain the MF13, to be displayed to the user for update.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @param taskId the task id
     * @param transactionId the transaction id
     * @throws MCServerException the MC server exception
     */
    public void obtainMF13(HttpServletRequest request, GoodServiceWipoBean gsBean, String taskId, String transactionId)
        throws MCServerException {

        logger.debug("obtainMF13  transId: " + transactionId + ", taskId:" + taskId);

        // Populate the MF13 Request.
        GetManualReport getManualReport = new GetManualReport();
        GetManualReportRequest getManualReportRequest = new GetManualReportRequest();
        getManualReportRequest.setTaskId(new BigDecimal(taskId));
        getManualReportRequest.setTransactionId(new BigDecimal(transactionId));

        // Set the Goods and Services Meta.
        GoodsAndServiceMeta gsData = createGoodServiceMeta(request, gsBean);
        getManualReportRequest.setGoodsAndServices(gsData);

        getManualReport.setManualReport(getManualReportRequest);

        // Call the Service to get the MF13 data.
        ProcessManualReportRequest processManualReportRequest = transactionService.obtainMF13(getManualReportRequest);

        if (processManualReportRequest == null) {
            logger.error(
                "Unable to obtain MF13 data from the Service for transId: " + transactionId + ", taskId:" + taskId);
            throw new MCServerException(MadridConsoleUtils.getMessage("mc.error.mts.obtainmf13"));

        } else {
            processManualReportRequest.setTaskId(new BigDecimal(taskId));
            processManualReportRequest.setTransactionId(new BigDecimal(transactionId));

            MF13 mf13 = new MF13();
            mf13.setMf13Request(processManualReportRequest);
            gsBean.setMf13(mf13);
        }
        return;
    }

    /**
     * Submit the MF13 form to WIPO. A Call is made to createGoodServiceMeta to set the Goods and Services data.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @throws MCServerException the MC server exception
     */
    public void processMF13(HttpServletRequest request, GoodServiceWipoBean gsBean) throws MCServerException {

        logger.debug("processMF13  transId: " + gsBean.getTransactionId() + ", taskId: " + gsBean.getTaskId());

        // Set the Goods and Services data
        GoodsAndServiceMeta gsData = createGoodServiceMeta(request, gsBean);
        gsBean.getMf13().getMf13Request().getManualReportForm().getLimitationNoEffectMF13Type()
            .setGoodsAndServices(gsData);

        // Send to Madrid Transaction Service (MTS)
        transactionService.processManualReport(gsBean.getMf13().getMf13Request());

        return;
    }

    /**
     * Submit the Mailing Label to MTS.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @throws MCServerException the MC server exception
     */
    public void processEditMailingLabel(HttpServletRequest request, GoodServiceWipoBean gsBean)
        throws MCServerException {

        logger.debug(
            "processEditMailingLabel  transId: " + gsBean.getTransactionId() + ", taskId: " + gsBean.getTaskId());

        // Send Mailing Label to MTS
        transactionService.processMailigLabel(gsBean, userProfileService.getAuthorityId(request));

        return;
    }

    /**
     * Obtain the MF9, to be displayed to the user for update.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @param taskId the task id
     * @param transactionId the transaction id
     * @throws MCServerException the MC server exception
     */
    public void obtainMF9(HttpServletRequest request, GoodServiceWipoBean gsBean, String taskId, String transactionId)
        throws MCServerException {

        logger.debug("obtainMF9  transId: " + transactionId + ", taskId:" + taskId);

        // Populate the MF9 Request.
        GetManualReport getManualReport = new GetManualReport();
        GetManualReportRequest getManualReportRequest = new GetManualReportRequest();
        getManualReportRequest.setTaskId(new BigDecimal(taskId));
        getManualReportRequest.setTransactionId(new BigDecimal(transactionId));

        // Set the Goods and Services Meta.
        GoodsAndServiceMeta gsData = createGoodServiceMeta(request, gsBean);
        getManualReportRequest.setGoodsAndServices(gsData);

        getManualReport.setManualReport(getManualReportRequest);

        // Call the Service to get the MF9 data.
        ProcessManualReportRequest processManualReportRequest = transactionService.obtainMF9(getManualReportRequest);

        processManualReportRequest.setTaskId(new BigDecimal(taskId));
        processManualReportRequest.setTransactionId(new BigDecimal(transactionId));

        MF9 mf9 = new MF9();
        mf9.setMf9Request(processManualReportRequest);
        gsBean.setMf9(mf9);

        return;
    }

    /**
     * Submit the MF9 form to WIPO.
     *
     * @param request the request
     * @param gsBean - GoodServiceWipoBean
     * @throws MCServerException the MC server exception
     */
    public void processMF9(HttpServletRequest request, GoodServiceWipoBean gsBean) throws MCServerException {

        logger.debug("processMF9  transId: " + gsBean.getTransactionId() + ", taskId: " + gsBean.getTaskId());

        // Send to Madrid Transaction Service (MTS)
        transactionService.processManualReport(gsBean.getMf9().getMf9Request());

        return;
    }

    /**
     * MF3A - Cited Marks - Retrieve (fetch/search) for a Cited Mark, based on the filing number/ extensionCounter
     * provided.
     *
     * @param filingNumber - Filing Number
     * @return List<GroundsOfOpposition>
     * @throws MCServerException the MC server exception
     */
    public List<GroundsOfOpposition> getGroundsOfOppostion(int filingNumber) throws MCServerException {

        logger.debug("getGroundsOfOppostion filingNumber: " + filingNumber);

        GroundsOfOpposition groundsOfOpposition = new GroundsOfOpposition();
        List<GroundsOfOpposition> groundsOfOppositionList = new ArrayList<GroundsOfOpposition>();

        TrademarkDetailsTypeMF3BagType trademarkDetailsTypeMF3BagType = tirsService
            .getFillingNumberInformation(filingNumber);

        if (trademarkDetailsTypeMF3BagType.getTrademarkDetailsTypeMF3().isEmpty()) {
            throw new MCServerException("Filing Number not found!!");
        }

        for (TrademarkDetailsTypeMF3 trademarkDetailsTypeMF3 : trademarkDetailsTypeMF3BagType
            .getTrademarkDetailsTypeMF3()) {

            groundsOfOpposition = new GroundsOfOpposition();

            groundsOfOpposition.setFilingDate(getCitedLinkFilingDate(trademarkDetailsTypeMF3));
            if (trademarkDetailsTypeMF3.getTradmarkDetails().getApplicationNumber().getExtensionCounter() == 0) {
                groundsOfOpposition.setFilingNumber(Integer.toString(filingNumber));

            } else {
                groundsOfOpposition.setFilingNumber(Integer.toString(filingNumber) + "("
                    + trademarkDetailsTypeMF3.getTradmarkDetails().getApplicationNumber().getExtensionCounter() + ")");
            }
            groundsOfOpposition.setPriorityDate(
                getPriorityDate(trademarkDetailsTypeMF3.getGoodsServicesClaimsBag().getGoodsServicesClaims(), logger));
            groundsOfOpposition.setRegistrationDate(getCitedLinkRegistrationDate(trademarkDetailsTypeMF3));

            // Set the Registration Number - if there is a Registration Number
            if ((trademarkDetailsTypeMF3.getCitedLinksBag() != null)
                && (trademarkDetailsTypeMF3.getCitedLinksBag().getCitedLinks() != null)
                && (!trademarkDetailsTypeMF3.getCitedLinksBag().getCitedLinks().isEmpty())) {
                groundsOfOpposition.setRegistrationNumber(
                    trademarkDetailsTypeMF3.getCitedLinksBag().getCitedLinks().get(0).getCitedRegistrationNumber());

            } else {
                groundsOfOpposition.setRegistrationNumber("");
            }
            groundsOfOpposition.setTrademarkInfo(getTrademarkInfo(trademarkDetailsTypeMF3));
            groundsOfOpposition.setNameAndAddress(getCitedLinkNameAndAddress(trademarkDetailsTypeMF3));
            groundsOfOpposition.setNiceClassCode(getCitedNiceClasses(trademarkDetailsTypeMF3));

            groundsOfOppositionList.add(groundsOfOpposition);
        }

        return groundsOfOppositionList;

    }

    /**
     * MF3A - Field VII(i) - Filling Date
     *
     * Retrive the Filling Date.
     *
     * @param TrademarkDetailsTypeMF3
     * @return Date - Filling Date
     */
    public static Date getCitedLinkFilingDate(TrademarkDetailsTypeMF3 tmDetail) {
        Date filingDate = null;

        for (ActionType action : tmDetail.getActionsBag().getActions()) {
            if (action.getActionCode().equals(ActionCode.APPLICATION_FILED.getValue())) {
                if (action.getActionDate() != null) {
                    filingDate = action.getActionDate().toGregorianCalendar().getTime();
                }
            }
        }
        return filingDate;
    }

    /**
     * MF3A - Field VII(i) - Priority Date
     *
     * Claim Date from CLAIMS table if Claim Type is equal to ‘Priority’ (12). Loop the whole GS bag and find the
     * earliest priority filed date.
     *
     * @param goodsServicesClaims
     * @param logger
     * @return Date - Priority Date
     */
    public static Date getPriorityDate(List<GoodsServicesClaimsType> goodsServicesClaims, Logger logger) {
        Date earliestPriorityDate = null;
        if (goodsServicesClaims == null || goodsServicesClaims.isEmpty()) {
            return earliestPriorityDate;
        }
        for (GoodsServicesClaimsType gsClaim : goodsServicesClaims) {
            if (gsClaim.getClaims() != null && !gsClaim.getClaims().isEmpty()) {
                for (ClaimType claim : gsClaim.getClaims()) {
                    if (claim.getClaimCategoryType() == ca.gc.ic.cipo.tm.enumerator.ClaimType.PRIORITY_FILING.getValue()
                        .intValue()) {
                        String dateString = ((PriorityClaimType) claim).getFiledDate();
                        try {
                            Date priorityDate = DateFormats.getISOSDF().parse(dateString);

                            if (earliestPriorityDate == null) {
                                earliestPriorityDate = priorityDate;
                            } else if (earliestPriorityDate.compareTo(priorityDate) >= 0) {
                                earliestPriorityDate = priorityDate;
                            }
                        } catch (ParseException e) {
                            logger.error("Unable to parse this string <" + dateString + "> to a java.util.Date object");
                        }

                    }
                }
            }
        }

        return earliestPriorityDate;
    }

    /**
     * MF3A -Field VII(ii) Registration date
     *
     * Action Date from ACTIONS table where Action Code is ‘Registered’ (55),
     *
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @param string registrationNumber
     * @return
     */
    public static Date getCitedLinkRegistrationDate(TrademarkDetailsTypeMF3 tmDetail) {
        Date registrationDate = null;
        for (ActionType action : tmDetail.getActionsBag().getActions()) {
            if (action.getActionCode().equals(ActionCode.REGISTRATION.getValue())) {
                if (action.getActionDate() != null) {
                    registrationDate = action.getActionDate().toGregorianCalendar().getTime();
                }
            }
        }
        return registrationDate;
    }

    /**
     * MF3A - Field VII(iii) - Name and address of the owner
     *
     * Name, Address, description of Country/Province, Postal Code (if present) from INTERESTED_PARTIES table where
     * Relationship Type is ‘Owner’ (1)
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return String - containing the Name and Address
     */
    public static String getCitedLinkNameAndAddress(TrademarkDetailsTypeMF3 tmDetail) {
        String citedMarkNameAndAddress = "";
        for (ca.gc.ic.cipo.xmlschema.trademark.extended.ApplicantType applicant : tmDetail.getApplicantsBag()
            .getApplicants()) {
            if (applicant.getRoleCategory().equals(RoleCategoryType.OWNER)
                || applicant.getRoleCategory().equals(RoleCategoryType.APPLICANT)) {
                if ((applicant.getContact().getName() != null)
                    && (applicant.getContact().getName().getEntityName() != null)) {
                    citedMarkNameAndAddress = applicant.getContact().getName().getEntityName() + LINE_CHANGE;
                }
                citedMarkNameAndAddress = citedMarkNameAndAddress
                    + getPostalAddress(applicant.getContact().getPostalAddressBag());
            }
        }
        return citedMarkNameAndAddress;
    }

    /**
     * MF3A - Field VII(iv) - Reproduction of the Mark
     *
     * Reproduction of the mark  Text from TRADEMARK table if the Trademark Type from APPLICATIONS table is ‘Word’ or
     * ‘Standard Characters’, or any other type of mark where a Design file does not exist
     *
     * Design if the Trademark Type is ‘Design’, or any other type of mark where a Design file exists
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return TrademarkInfo - the trademark info.
     */
    public static TrademarkInfo getTrademarkInfo(TrademarkDetailsTypeMF3 tmDetail) {
        TrademarkInfo tm = new TrademarkInfo();

        tm.setTrademarkDescription(tmDetail.getTradmarkDetails().getMarkDescReference());

        // Attachment trademark
        Attachment attachment = new Attachment();
        for (ca.gc.ic.cipo.xmlschema.common.DocumentType doc : tmDetail.getTradmarkDetails().getMarkRepresentations()) {
            attachment.setAttachmentType(new ReferenceCode());
            attachment.getAttachmentType().setCategory(doc.getMediaType().value());
            attachment.setFileName(doc.getName());
            attachment.setFileContent(doc.getContent());
        }
        tm.setTrademarkAttachment(attachment);

        return tm;
    }

    /**
     * MF3A = Field VII(v) - CitedNiceClasses
     *
     * List of relevant goods and/or services
     *
     * List of all Nice Class Codes, WS Numbers and Text from WARES_SERVICES and WARES_SERVICES_TEXTS
     *
     * Order by Nice Class Code and WS Number
     *
     * @param tmDetail TrademarkDetailsTypeMF3
     * @return String List of Cited Nice Classes
     */
    public static String getCitedNiceClasses(TrademarkDetailsTypeMF3 tmDetail) {
        StringBuffer sb = new StringBuffer();
        for (GoodsServicesClaimsType gs : tmDetail.getGoodsServicesClaimsBag().getGoodsServicesClaims()) {
            if (gs.getClassification().getClassNumber() != null) {
                sb.append(gs.getClassification().getClassNumber());
                sb.append(SPACE);
            }
            sb.append(gs.getStatement().getStatementDescription().getValue());
            sb.append(DOUBLE_LINE_CHANGE);
        }
        return sb.toString();
    }

    public static String getPostalAddress(PostalAddressBagType addressBag) {
        StringBuffer sb = new StringBuffer();
        if (addressBag.getUnstructuredPostalAddress().size() > 0) {
            for (UnstructuredPostalAddressType address : addressBag.getUnstructuredPostalAddress()) {
                if (address.getCipoPostalAddressCategory().endsWith(STR_HOME)) {
                    sb.append(address.getUnstructuredAddress());
                    sb.append(LINE_CHANGE);
                    sb.append(address.getCountryDesc());
                }
            }
        } else {
            for (PostalAddressType address : addressBag.getPostalAddress()) {
                sb.append(address.getAddressLineText().toString() + COMMA_SPACE);
                sb.append(address.getCountryNumber() + COMMA_SPACE);
                sb.append(address.getPostalCode().toString());
            }
        }
        return sb.toString();
    }

    /**
     * Submit the IRCorrection to MTS (Madrid Transaction Service).
     *
     * @param gsBean - GoodServiceWipoBean
     * @param strResetQuestionResult - Indicator if the 18 Month Set. ('true' or 'false')
     * @param authorityId - Authority Id (String)
     * @throws MCServerException the MC server exception
     */
    public void submitIRCorrection(GoodServiceWipoBean gsBean, String strResetQuestionResult, String authorityId)
        throws MCServerException {

        logger.debug(
            "submitICorrection  transId: " + gsBean.getTransactionId() + ", Task: " + gsBean.getActivityTaskId());

        // Populate the IRCorrection Submission Request.
        ProcessIRCorrectionSubmissionRequest processIrcorrectionSubmissionRequest = new ProcessIRCorrectionSubmissionRequest();
        processIrcorrectionSubmissionRequest.setTaskId(gsBean.getTaskId());
        processIrcorrectionSubmissionRequest.setAuthorityId(authorityId);
        processIrcorrectionSubmissionRequest
            .setFileNumber(BigDecimal.valueOf(gsBean.getApplication().getApplicationNumber().getFileNumber()));
        processIrcorrectionSubmissionRequest
            .setExtensioncounter(gsBean.getApplication().getApplicationNumber().getExtensionNumber());
        processIrcorrectionSubmissionRequest.setIsResetMonthPeriod(Boolean.valueOf(strResetQuestionResult));

        // Send to Madrid Transaction Service (MTS)
        transactionService.processIRCorrection(processIrcorrectionSubmissionRequest);

        return;
    }

    /**
     * Obtain Country Description
     *
     * @throws MCServerException the MC server exception
     */
    public String obtainCountryDescripton(String countryCode, String language) throws MCServerException {

        logger.debug("obtainCountryDescripton  countryCode: " + countryCode + ", language: " + language);

        ca.gc.ic.cipo.tm.mts.LanguageType languageType = ca.gc.ic.cipo.tm.mts.LanguageType.valueOf(language);

        // return the Country Description from MTS
        String countryDescription = transactionService.obtainCountryDescription(countryCode, languageType);

        return countryDescription;
    }

    /**
     * Get text between two strings. Passed limiting strings are not included into result.
     *
     * @param text Text to search in.
     * @param textFrom Text to start cutting from (exclusive).
     * @param textTo Text to stop cuutting at (exclusive).
     */
    public static String getBetweenStrings(String text, String textFrom, String textTo) {

        String result = "";

        // Cut the beginning of the text to not occasionally meet a
        // 'textTo' value in it:
        result = text.substring(text.indexOf(textFrom) + textFrom.length(), text.length());

        // Cut the excessive ending of the text:
        result = result.substring(0, result.indexOf(textTo));

        return result;
    }

    /**
     * This method will take a long string and split it in several lines of fixed length that will be displayed. We must
     * therefore divide this input string into multiple strings of a pre-defined maximum length but keeping the words
     * entire without breaking them when the end of the line has been reached. In addition we also have to take care of
     * punctuation and avoid to start a new line if the n + 1 character is a period, comma, question mark, etc..
     *
     * If the inputString contains a "word" that is greater then the lineSize, then the whole string is returned as is
     *
     * @param inputString -= String to be split.
     * @param lineSize
     * @return String - String with / containing new lines
     */

    private String splitString(String inputString, int lineSize) {

        StringBuilder strBuilder = new StringBuilder();

        // Check if there are any words greater than "lineSize" characters, if so..
        // return the String as is, since it cannot be split.
        String[] words = StringUtils.split(inputString, WHITE_SPACE);
        for (String aWord : words) {
            if (aWord.length() > lineSize) {
                return inputString + LINE_CHANGE;
            }
        }

        // Split the String into multiple lines
        Pattern p = Pattern.compile("\\b.{1," + (lineSize - 1) + "}\\b\\W?");
        Matcher m = p.matcher(inputString);
        while (m.find()) {
            strBuilder.append(m.group());
            strBuilder.append(LINE_CHANGE);
        }
        return strBuilder.toString();

    }

}
