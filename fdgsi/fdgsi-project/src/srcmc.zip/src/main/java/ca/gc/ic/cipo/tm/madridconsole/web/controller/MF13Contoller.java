package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import ca.gc.ic.cipo.tm.madridconsole.service.TradMarkApplicationService;
import ca.gc.ic.cipo.tm.madridconsole.service.mts.TransactionServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.mwe.WorkflowEngineServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.service.tups.UserProfileServiceClient;
import ca.gc.ic.cipo.tm.madridconsole.web.bean.GoodServiceWipoBean;
import ca.gc.ic.cipo.tm.madridconsole.web.exception.MCServerException;
import ca.gc.ic.cipo.tm.madridconsole.web.validator.MF13Validator;

@Controller
@SessionAttributes("wipogs")
public class MF13Contoller {

    private static Logger logger = Logger.getLogger(MF13Contoller.class.getName());

    /** Controller dispatcher. */
    @Autowired
    protected ActionDispatcher dispatcher;

    @Autowired
    TransactionServiceClient transactionServiceClient;

    /**
     * @param request
     * @return
     */
    @ModelAttribute("wipogs")
    public GoodServiceWipoBean getWipoGs(HttpServletRequest request) {

        return new GoodServiceWipoBean();
    }

    @Autowired
    private TradMarkApplicationService tmAppService;

    @Autowired
    private WorkflowEngineServiceClient mweClient;

    @Autowired
    private UserProfileServiceClient userProfileService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
    }

    /**
     * POST (i.e. Get) Request - for MF13. Obtain the values for the pre-populated fields on the form.
     *
     * @param wipogs - GoodServiceWipoBean
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/MF13", method = RequestMethod.GET)
    public String obtainMF13data(@ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                 Locale locale, final ModelMap modelMap, HttpServletRequest request,
                                 HttpSession session, final RedirectAttributes redirectAttributes) {

        String viewName = "MF13";
        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        String taskId = gsBean.getTaskId().toString();
        String transId = gsBean.getTransactionId().toString();

        logger.debug("/processtask/MF13  method = RequestMethod.GET, transIds: " + transId + ", task: " + taskId);

        // Obtain the MF13 Data to be displayed
        try {
            tmAppService.obtainMF13(request, gsBean, taskId, transId);
        } catch (MCServerException e) {
            logger.error("obtainMF13data(), Received Exception ", e);
            redirectAttributes.addFlashAttribute("errorMsg",
                messageSource.getMessage("mc.mf13.infomsg.error", null, locale) + " - " + e.getMessage());

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock(gsBean);
            } catch (MCServerException e1) {
                logger.error("/processtask/MF13/submit, Errors attempting to release Lock." + e1.getMessage() );
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");
        }

        return viewName;
    }

    /**
     * Post Request - for MF13. Validate (and assuming it passes validation) submit it to WIPO via the MTS.
     *
     * @param wipogs - GoodServiceWipoBean
     * @param errors - BindingResult
     * @return string - JSP
     *
     */
    @RequestMapping(value = "/processtask/MF13/submit", method = RequestMethod.POST)
    public String submitMF13Form(final @ModelAttribute("wipogs") GoodServiceWipoBean gsBean, BindingResult errors,
                                 @RequestParam(required = false, defaultValue = "", value = "action") String actionVal,
                                 Locale locale, ModelMap model, final HttpServletRequest request,
                                 final HttpServletResponse response, HttpSession session,
                                 final RedirectAttributes redirectAttributes) {

        logger.debug("/processtask/MF13 RequestMethod.POST, " + gsBean.getMf13().toString());

        WebApplicationContext webAppContext = ContextLoader.getCurrentWebApplicationContext();
        MessageSource messageSource = (MessageSource) webAppContext.getBean("messageSource");

        String viewName = "";

        if (ActionDispatcher.ACTION_NEXT.equalsIgnoreCase(actionVal)) {

            // Perform validation
            MF13Validator validator = new MF13Validator();
            validator.validate(gsBean, errors);
            // if (errors.hasErrors()) {
            // model.addAttribute("errors", errors);
            // return "MF13";
            // }

            try {

                logger.debug("/processtask/MF13 About to process MF13 ");

                // Process the MF13 (i.e., submit MF13 to WIPO)
                tmAppService.processMF13(request, gsBean);

                // Call Workflow Engine to Complete Task
                mweClient.completeTask(gsBean.getActivityTaskId(), userProfileService.getParentId(request));

                // Format the Success Message.
                redirectAttributes.addFlashAttribute("infoMsg",
                    messageSource.getMessage("mc.mf13.infomsg.success", null, locale));

            } catch (Exception e) {
                logger.error("submitMF13Form(), Received Exception", e);

                redirectAttributes.addFlashAttribute("errorMsg",
                    messageSource.getMessage("mc.mf13.infomsg.error", null, locale) + " - " + e.getMessage());
            } finally {

                // Release the LOCK on the File Number/Extension
                try {
                    transactionServiceClient.releaseLock(gsBean);
                } catch (MCServerException e) {
                    logger.error("/processtask/MF13/submit, Errors attempting to release Lock." + e.getMessage() );
                }
            }

            // go back to the calling page
            viewName = "redirect:" + session.getAttribute("refererPage");

        } else if (ActionDispatcher.ACTION_CANCEL.equalsIgnoreCase(actionVal)) {

            viewName = "redirect:" + session.getAttribute("refererPage");

            // Release the LOCK on the File Number/Extension
            try {
                transactionServiceClient.releaseLock( gsBean);
            } catch (MCServerException e) {
                logger.error("/processtask/MF13/submit, (CANCEL) Errors attempting to release Lock." + e.getMessage() );
            }

        }

        // Assuming everything has been successful, so far, clear out the GoodServiceWipoBean Data.
        session.setAttribute("wipogs", null);

        return viewName;

    }
}
