package ca.gc.ic.cipo.tm.madridconsole.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import ca.gc.ic.cipo.tm.madridconsole.web.exception.CustomGenericException;

/**
 * The Class GlobalExceptionController handle all web exceptions in the application.
 *
 * @author giustof
 */
@ControllerAdvice
public class GlobalExceptionController {

    private static Logger logger = Logger.getLogger(GlobalExceptionController.class.getName());

    /**
     * @param session
     * @param model
     * @param ex
     * @return
     */
    @ExceptionHandler(CustomGenericException.class)
    public String handleCustomException(HttpSession session, Model model, CustomGenericException ex) {

        logger.error("Unexpected error: ", ex);
        model.addAttribute("errCode", ex.getErrCode());
        model.addAttribute("errMsg", ex.getErrMsg());

        return "webException";
    }

    /**
     * @param request
     * @param response
     * @param session
     * @param model
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public String handleAllException(HttpServletRequest request, HttpServletResponse response, HttpSession session,
                                     Model model, Exception ex) {

        logger.error("Unexpected error: ", ex);
        String xrequestedWith = request.getHeader("x-requested-with");
        if (xrequestedWith != null && xrequestedWith.equals("XMLHttpRequest")) {

        }

        return "webException";
    }

    /**
     * @param response
     * @throws IOException
     */
    private void prepareError(HttpServletResponse response) throws IOException {
        // TODO check various error codes
        response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }
}