package ca.gc.ic.cipo.tm.madridconsole.util;

/**
 * The Class StatusResponse that send the status back on an AJAX call.
 */
public class StatusResponse {

    /** The state of the AJAX response message to be displayed to the user - success, error, warning or info. */
    private String status;

    /** The message to be displayed to the user. */
    private String message;

    /** The Constant ERROR. */
    public static final String ERROR = "E";

    /** The Constant WARNING. */
    public static final String WARNING = "W";

    /** The Constant SUCCESS. */
    public static final String SUCCESS = "S";

    /** The Constant INFO. */
    public static final String INFO = "I";

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets the message.
     *
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the message.
     *
     * @param message the new message
     */
    public void setMessage(String message) {
        this.message = message;
    }

}
