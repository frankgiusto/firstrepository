package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.GoodServiceClassificationsDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodServiceClassification;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = false)
@Rollback(true)
public class GoodsServicesClassificationDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private GoodServiceClassificationsDao goodServiceClassificationsDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void TestSetGoodServiceClassification() {

        // Create an application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application newApplication = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(newApplication);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(newApplication);

        Application savedApplication = applicationDao.getApplication(nextApplicationNumber, 0);
        // Adding ServiceClassification

        GoodServiceClassification goodServiceClassification = new GoodServiceClassification();
        goodServiceClassification.setApplication(savedApplication);
        goodServiceClassification.setNiceClassCode(1);
        goodServiceClassification.setSequenceNumber(1);
        goodServiceClassification.setExtensionCounter(0);
        goodServiceClassification.setFileNumber(nextApplicationNumber);
        goodServiceClassificationsDao.setGoodServiceClassification(goodServiceClassification);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(newApplication);

        // Getting back the application
        Set<GoodServiceClassification> classification = goodServiceClassificationsDao
            .getGoodServiceClassifications(savedApplication);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(newApplication);

        assertNotNull(classification);
        GoodServiceClassification result = classification.iterator().next();
        assertNotNull(result);
        assertNotNull(result.getSequenceNumber());
        assertNotNull(result.getNiceClassCode());
        assertTrue(result.getSequenceNumber() == 1);
        assertTrue(result.getNiceClassCode() == 1);

    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void TestSetGoodServiceClassifications() {
        int numberOfGoodServices = 5;

        // Create an application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application newApplication = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(newApplication);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(newApplication);

        Application savedApplication = applicationDao.getApplication(nextApplicationNumber, 0);
        // Adding ServiceClassification
        for (int value = 1; value <= numberOfGoodServices; value++) {

            GoodServiceClassification goodServiceClassification = new GoodServiceClassification();
            goodServiceClassification.setApplication(savedApplication);
            goodServiceClassification.setNiceClassCode(value);
            goodServiceClassification.setSequenceNumber(value);
            goodServiceClassification.setExtensionCounter(0);
            goodServiceClassification.setFileNumber(nextApplicationNumber);
            goodServiceClassificationsDao.setGoodServiceClassification(goodServiceClassification);
            // Forces Hibernate to save/refresh from DB
            transactionManager.getSessionFactory().getCurrentSession().flush();
            transactionManager.getSessionFactory().getCurrentSession().refresh(newApplication);
        }

        // Getting back the application
        Set<GoodServiceClassification> classification = goodServiceClassificationsDao
            .getGoodServiceClassifications(savedApplication);

        int count = 0;
        for (GoodServiceClassification current : classification) {
            Assert.assertNotNull(current.getSequenceNumber());
            Assert.assertNotNull(current.getNiceClassCode());
            Assert.assertEquals(current.getSequenceNumber(), current.getNiceClassCode());
            count += current.getSequenceNumber();
        }

        int goodsCount = 0;
        for (int i = 1; i <= numberOfGoodServices; i++) {
            goodsCount += i;
        }
        assertTrue(count == goodsCount);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void TestDeleteGoodServiceClassification() {
        // Create an application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application newApplication = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(newApplication);
        Application savedApplication = applicationDao.getApplication(nextApplicationNumber, 0);

        GoodServiceClassification goodServiceClassification = new GoodServiceClassification();
        goodServiceClassification.setApplication(savedApplication);
        goodServiceClassification.setNiceClassCode(1);
        goodServiceClassification.setSequenceNumber(1);
        goodServiceClassification.setExtensionCounter(0);
        goodServiceClassification.setFileNumber(nextApplicationNumber);
        goodServiceClassificationsDao.setGoodServiceClassification(goodServiceClassification);

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(savedApplication.getFileNumber());
        applicationNumber.setExtensionCounter(savedApplication.getExtensionCounter());
        System.out.println("TestSetGoodServiceClassification current:" + savedApplication.getFileNumber());
        goodServiceClassificationsDao.deleteGoodServiceClassifications(applicationNumber);
        Set<GoodServiceClassification> classification = goodServiceClassificationsDao
            .getGoodServiceClassifications(savedApplication);
        assertTrue(classification.isEmpty());
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setMadridDesignationCategory(2);
        application.setRegistrabilityRecognizedInd(1);
        return application;
    }
}
