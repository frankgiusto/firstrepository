/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AssignmentAmendmentTransactionDao;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransactionIp;
import junit.framework.TestCase;

/**
 * This class test the AssignmentAmendmentTransactionDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AssignmentAmendmentTransactionDaoTest extends TestCase {

    @Autowired
    private AssignmentAmendmentTransactionDao assignmentAmendmentTransactionDao;

    @Test
    @Transactional(readOnly = true)
    public void getAssignmentamendmentTransactions() {

        if (assignmentAmendmentTransactionDao == null) {
            System.out.println("assignmentAmendmentTransactionDao is NULL!!!");
        }
        List<AssignmentAmendmentTransaction> assignmentAmendmentTransactions = assignmentAmendmentTransactionDao
            .list(536334, 0);

        // assert (assignmentAmendmentTransactions.size() > 0);
        this.printAssignmentAmendmentTransactions(assignmentAmendmentTransactions);

        // Retrieve the AssignmentAmendmentTrasanctionIps related to the
        // interested party
        Set<AssignmentAmendmentTransactionIp> assignmentAmendmentTrasanctionIps = assignmentAmendmentTransactionDao
            .getAssignmentAmendmentTransactionIps(869520, 0, 1000819);

        // assert (assignmentAmendmentTrasanctionIps.size() > 0);

        printAssignmentAmendmentTransactionIps(assignmentAmendmentTrasanctionIps);

    }

    /**
     * Printing method
     *
     * @param Collection of assignmentAmendmentTransactions
     */
    private void printAssignmentAmendmentTransactions(List<AssignmentAmendmentTransaction> aaTransactions) {

        System.out.println("Assignment Amendment Transactions Data: ");
        System.out.println("=============================");
        for (AssignmentAmendmentTransaction aaTransaction : aaTransactions) {
            // This will get the specific authorities aa transactions
            // information
            System.out.println(" Transactions AAT Number " + aaTransaction.getAatNumber());
            System.out.println("Assignment Amendment Transactions AAT Label: " + aaTransaction.getAatLabel());
            System.out.println("Assignment Amendment Transactions AAT Type: " + aaTransaction.getAatType());
            System.out.println("Assignment Amendment Transactions Authority Id " + aaTransaction.getAuthorityId());
            System.out.println(
                "Assignment Amendment Transactions AAT Work Sheet Number: " + aaTransaction.getWorkSheetNumber());
            System.out.println(
                "Assignment Amendment Transactions AAT Master File Number: " + aaTransaction.getMasterFileNumber());
            System.out.println("Assignment Amendment Transactions Master Extension Counter "
                + aaTransaction.getMasterExtensionCounter());
            System.out.println("Assignment Amendment Transactions Status Code: " + aaTransaction.getStatusCode());
            System.out.println("Assignment Amendment Transactions Start Date: " + aaTransaction.getStartDate());
            System.out.println("Assignment Amendment Transactions Receive Date " + aaTransaction.getReceiveDate());
            System.out
                .println("Assignment Amendment Transactions Correctrion Ind: " + aaTransaction.getCorrectionInd());
            System.out
                .println("Assignment Amendment Transactions Court Order Ind: " + aaTransaction.getCourtOrderInd());
            System.out.println("Assignment Amendment Transactions Footnote Type: " + aaTransaction.getFootnoteType());
            System.out.println("Assignment Amendment Transactions Footnote Date Of Change: "
                + aaTransaction.getFootnoteDateOfChange());
            System.out.println("Assignment Amendment Transactions Footnote Text " + aaTransaction.getFootnoteText());
            System.out
                .println("Assignment Amendment Transactions Agent Change Ind: " + aaTransaction.getAgentChangeInd());
            System.out.println("Assignment Amendment Transactions Rep Change Ind: " + aaTransaction.getRepChangeInd());
            System.out.println(
                "Assignment Amendment Transactions Correspondence Date: " + aaTransaction.getCorrespondenceDate());
            System.out.println("Assignment Amendment Transactions Reponse Date: " + aaTransaction.getResponseDate());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Assignment Amendment Trasanction Ips
     */

    private void printAssignmentAmendmentTransactionIps(Set<AssignmentAmendmentTransactionIp> assignmentAmendmentTransactionIps) {
        System.out.println("=============================");
        System.out.println("=============================");
        System.out.println("Assignment Amendment Trasanction Assignment Amendment Trasanction Ips: ");
        System.out.println("=============================");
        for (AssignmentAmendmentTransactionIp assignmentAmendmentTransactionIp : assignmentAmendmentTransactionIps) {
            // This will get the specific interested party Assignment Amendment
            // Trasanctions
            // information

            System.out.println("Assignment Amendment Trasanction  Assignment Amendment Trasanction Ip File Number: "
                + assignmentAmendmentTransactionIp.getFileNumber());
            System.out.println("Assignment Amendment Trasanction  Assignment Amendment Trasanction Extension Counter: "
                + assignmentAmendmentTransactionIp.getExtensionCounter());
            System.out.println("Assignment Amendment Trasanction  Assignment Amendment Trasanction Ip Ip Number : "
                + assignmentAmendmentTransactionIp.getIpNumber());
            System.out.println("Assignment Amendment Trasanction  Assignment Amendment Trasanction Ip AAT Number : "
                + assignmentAmendmentTransactionIp.getAatNumber());
            System.out
                .println("Assignment Amendment Trasanction  Assignment Amendment Trasanction Ip New File Number : "
                    + assignmentAmendmentTransactionIp.getNewFileNumber());
            System.out.println("Assignment Amendment Trasanction  Assignment Amendment Trasanction Extension Counter: "
                + assignmentAmendmentTransactionIp.getNewExtensionCounter());

        }
    }
}
