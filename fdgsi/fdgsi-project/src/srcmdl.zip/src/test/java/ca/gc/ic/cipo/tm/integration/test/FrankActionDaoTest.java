/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import junit.framework.TestCase;

/**
 * This class tests ActionDao
 *
 * @see ActionDao
 * @author martinr3
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class FrankActionDaoTest extends TestCase {

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    // @Autowired
    // private HibernateTransactionManager transactionManager;

    /**
     * Checks that updating an Action works as expected
     */
    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void saveActionUpdateTest() {

        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        Action action = buildAction(2, application);
        actionDao.saveAction(action);
        application.getActions().add(action);
        applicationDao.saveApplication(application);

        action = buildAction(2, application);
        action.setAdditionalInfo("Action2");
        actionDao.saveAction(action);
        application.getActions().add(action);
        applicationDao.saveApplication(application);

        transactionManager.getSessionFactory().getCurrentSession().flush();

        Application application2 = applicationDao.getApplication(application.getFileNumber(), 0);
        List<Action> actionList = application2.getActions();

        for (Action actionrec : actionList) {
            System.out.println(actionrec.toString());
        }
    }

    /**
     * @return
     */
    private Action buildAction(Integer actionCode, Application application) {
        Action newAction = new Action();
        newAction.setActionCode(actionCode);
        newAction.setActionDate(new Date());
        newAction.setAdditionalInfo("testInsert");
        newAction.setAuthorityId("ECTEST1");
        newAction.setExtensionCounter(0);
        newAction.setFileNumber(application.getFileNumber());
        newAction.setPerformedByAuthorityId("ECTEST1");
        newAction.setResponseDate(new Date());
        newAction.setApplication(application);
        return newAction;
    }

    /**
     * Create an application which is required as foreign key.
     *
     * @param nextApplicationNumber
     * @return
     */
    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);

        return application;
    } // End of the createApplication method.
}
