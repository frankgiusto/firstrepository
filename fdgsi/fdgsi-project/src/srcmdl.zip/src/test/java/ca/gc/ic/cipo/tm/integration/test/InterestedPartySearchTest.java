package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionFactory;
import ca.gc.ic.cipo.tm.dao.search.InterestedPartySearch;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.SearchItemType;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.type.CountryCanadaProvinceEnum;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class InterestedPartySearchTest {

    @Autowired
    @Qualifier("interestedPartySearch")
    private InterestedPartySearch interestedPartySearch;

    @Test
    @Transactional(readOnly = true)
    public void searchApplicantsUsingNameAndCountryProvince() {
        List<Expression> expressions = createSearchExpressions();
        List<InterestedParty> results = interestedPartySearch.searchApplicants(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        printInterestedPartyData(results);
        checkUniqueFilenumbers(results);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicantsUsingCountryProvince() {
        List<Expression> expressions = createSearchExpressions(CountryCanadaProvinceEnum.CA.getValue());
        List<InterestedParty> results = interestedPartySearch.searchApplicants(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        Assert.assertTrue(results.size() > 0);
        printInterestedPartyData(results);
        checkUniqueFilenumbers(results);
    }

    private List<Expression> createSearchExpressions(String countryProvince) {
        List<Expression> expressions = new ArrayList<>();
        Expression expression = makeExpression(SearchItemType.COUNTRY_PROVINCE_SEARCH.dbColName("IPA"),
            SearchItemType.COUNTRY_PROVINCE_SEARCH.namedParamName(), HibernateOperatorEnum.IN,
            CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList());
        expressions.add(expression);

        expression = makeExpression(SearchItemType.ADDRESS_TYPE.dbColName("IPA"),
            SearchItemType.ADDRESS_TYPE.namedParamName(), HibernateOperatorEnum.EQUAL, AddressType.PRIMARY.getValue());
        expressions.add(expression);
        return expressions;
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicantsUsingPhone() {
        List<Expression> expressions = createSearchExpressionsNameAndPhone();
        List<InterestedParty> results = interestedPartySearch.searchApplicants(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        printInterestedPartyData(results);
        checkUniqueFilenumbers(results);
    }

    @Test(expected = IllegalArgumentException.class)
    public void searchApplicantsUnSupportedSearchMethod() {
        List<Expression> expressions = new ArrayList<>();
        Expression expression = makeExpression(SearchItemType.NAME_SEARCH.dbColName("IP"),
            SearchItemType.NAME_SEARCH.namedParamName(), HibernateOperatorEnum.BETWEEN, "guillaume");
        expressions.add(expression);

        List<InterestedParty> results = interestedPartySearch.searchApplicants(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        printInterestedPartyData(results);
        checkUniqueFilenumbers(results);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchInterestedParties() {
        List<Expression> expressions = new ArrayList<>();
        Expression expression = makeExpression(SearchItemType.NAME_SEARCH.dbColName("IP"),
            SearchItemType.NAME_SEARCH.namedParamName(), HibernateOperatorEnum.LIKE, "guillaume");
        expressions.add(expression);

        expression = makeExpression(SearchItemType.COUNTRY_PROVINCE_SEARCH.dbColName("IPA"),
            SearchItemType.COUNTRY_PROVINCE_SEARCH.namedParamName(), HibernateOperatorEnum.IN,
            CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList());
        expressions.add(expression);

        expression = makeExpression(SearchItemType.RELATIONSHIP_TYPE.dbColName("IP"),
            SearchItemType.RELATIONSHIP_TYPE.namedParamName(), HibernateOperatorEnum.EQUAL,
            RelationshipType.OPPONENT.getValue());
        expressions.add(expression);

        List<InterestedParty> results = interestedPartySearch.searchInterestedParties(expressions,
            HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);

        printInterestedPartyData(results);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchInterestedPartiesWithRelationshipType() {
        List<Expression> expressions = new ArrayList<>();
        Expression expression = makeExpression(SearchItemType.NAME_SEARCH.dbColName("IP"),
            SearchItemType.NAME_SEARCH.namedParamName(), HibernateOperatorEnum.LIKE, "joe");
        expressions.add(expression);

        expression = makeExpression(SearchItemType.RELATIONSHIP_TYPE.dbColName("IP"),
            SearchItemType.RELATIONSHIP_TYPE.namedParamName(), HibernateOperatorEnum.EQUAL,
            RelationshipType.OPPONENT.getValue());
        expressions.add(expression);

        List<InterestedParty> results = interestedPartySearch.searchInterestedParties(expressions,
            HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        printInterestedPartyData(results);
    }

    private List<Expression> createSearchExpressions() {

        List<Expression> expressions = new ArrayList<>();

        // Name
        String value = "Joe Smith";
        Expression expression = makeExpression(SearchItemType.NAME_SEARCH.dbColName("IP"),
            SearchItemType.NAME_SEARCH.namedParamName(), HibernateOperatorEnum.LIKE, value);
        expressions.add(expression);

        // Country
        expression = makeExpression(SearchItemType.COUNTRY_PROVINCE_SEARCH.dbColName("IPA"),
            SearchItemType.COUNTRY_PROVINCE_SEARCH.namedParamName(), HibernateOperatorEnum.IN,
            CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList());
        expressions.add(expression);

        // always on address type = 1 (PRIMARY)
        expression = makeExpression(SearchItemType.ADDRESS_TYPE.dbColName("IPA"),
            SearchItemType.ADDRESS_TYPE.namedParamName(), HibernateOperatorEnum.EQUAL, AddressType.PRIMARY.getValue());
        expressions.add(expression);

        return expressions;
    }

    private List<Expression> createSearchExpressionsNameAndPhone() {
        List<Expression> expressions = new ArrayList<>();

        // Name
        String value = "joe";
        Expression expression = makeExpression(SearchItemType.NAME_SEARCH.dbColName("IP"),
            SearchItemType.NAME_SEARCH.namedParamName(), HibernateOperatorEnum.LIKE, value);
        expressions.add(expression);

        // Telephone
        value = "6472628699";
        expression = makeExpression(SearchItemType.PHONE_SEARCH.dbColName("IP"),
            SearchItemType.PHONE_SEARCH.namedParamName(), HibernateOperatorEnum.EQUAL, value);
        expressions.add(expression);

        // always on address type = 1 (PRIMARY)
        expression = makeExpression(SearchItemType.ADDRESS_TYPE.dbColName("IPA"),
            SearchItemType.ADDRESS_TYPE.namedParamName(), HibernateOperatorEnum.EQUAL, AddressType.PRIMARY.getValue());
        expressions.add(expression);
        return expressions;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      Object value) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            value);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      List<Object> values) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            values);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

    private void printInterestedPartyData(List<InterestedParty> interestedParties) {
        printInterestedPartyData(interestedParties, false);
    }

    private void printInterestedPartyData(List<InterestedParty> interestedParties, boolean assertAddressType) {
        if (!CollectionUtils.isEmpty(interestedParties)) {
            System.out.println("--------- Total count of InterestedParty Data: " + interestedParties.size());
            for (InterestedParty interestedParty : interestedParties) {
                System.out.println("--------- InterestedParty Data ---------");
                System.out.println("-------------- File Number: " + interestedParty.getFileNumber());
                System.out.println("-------------- Extension counter: " + interestedParty.getExtensionCounter());
                System.out.println("-------------- Relation Type code: " + interestedParty.getRelationshipType());
                System.out.println("-------------- Name: " + interestedParty.getContact().getName());

                Set<InterestedPartiesAddresses> interestedPartiesAddresses = interestedParty.getContact()
                    .getInterestedPartiesAddresses();

                System.out.println("--------- InterestedPartyAddresses Data ---------");
                if (!CollectionUtils.isEmpty(interestedPartiesAddresses)) {
                    for (InterestedPartiesAddresses address : interestedPartiesAddresses) {
                        System.out.println("-------------- Country/Province: " + address.getCountryProvince());
                        System.out.println("-------------- Postal Code: " + address.getPostalCode());
                        System.out.println("-------------- Address Type: " + address.getAddressType());

                    }
                }
                System.out.println();
                System.out.println("-------------- Agent number: "
                    + ((interestedParty.getAgent() != null && interestedParty.getAgent().getArNumber() != null)
                        ? interestedParty.getAgent().getArNumber() : ""));
            }
        }
    }

    private void checkUniqueFilenumbers(List<InterestedParty> results) {
        if (!CollectionUtils.isEmpty(results)) {
            Collections.sort(results, new Comparator<InterestedParty>() {

                @Override
                public int compare(InterestedParty o1, InterestedParty o2) {
                    int result = o1.getFileNumber() - o2.getFileNumber();
                    if (result == 0) {
                        result = o1.getExtensionCounter() - o1.getExtensionCounter();
                    }

                    if (result == 0) {
                        result = o1.getIpNumber() - o1.getIpNumber();
                    }

                    return result;
                }
            });

            for (int i = 0; i < (results.size() - 1); i++) {
                Assert.assertNotEquals(results.get(i), results.get(i + 1));
            }
        }
    }

}
