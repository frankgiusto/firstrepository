package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.TransactionTypeFilePrefixDao;
import ca.gc.ic.cipo.tm.model.TransactionTypeFilePrefix;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class TransactionTypePrefixDaoTest {

    @Autowired
    @Qualifier("transactionTypeFilePrefixDao")
    private TransactionTypeFilePrefixDao transactionTypePrefixDao;

    @Test
    public void testPrefix() {
        Integer transactionType = 301;
        TransactionTypeFilePrefix transactionTypeFilePrefix = transactionTypePrefixDao
            .getTransactionTypeFilePrefix(transactionType);
        Assert.assertNotNull("Check for not null", transactionTypeFilePrefix);
        Assert.assertEquals("Check for transaction type", transactionTypeFilePrefix.getTransactionType(),
            transactionType);
        Assert.assertNotNull("Check for not null", transactionTypeFilePrefix.getFilePrefix());

    }

    @Test
    public void testForNonExisitngPrefix() {
        Integer transactionType = 1000;
        TransactionTypeFilePrefix transactionTypeFilePrefix = transactionTypePrefixDao
            .getTransactionTypeFilePrefix(transactionType);
        Assert.assertNull("Check for null", transactionTypeFilePrefix);
    }
}
