package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.OppositionGroundsSubsectionDao;
import ca.gc.ic.cipo.tm.model.OppositionGroundsSubsection;

@Transactional(readOnly = true)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionGroundsSubsectionDaoTest {

    @Autowired
    private OppositionGroundsSubsectionDao subsectionDao;

    @Test
    public void getOppositionGroundsSubsections() {
        final Integer opsGroundCode = 1;
        final Integer subSectionCode = 1;

        List<OppositionGroundsSubsection> results = this.subsectionDao.getOppositionGroundsSubsections(opsGroundCode,
            subSectionCode);
        Assert.assertNotNull("Check for not null", results);
        Assert.assertTrue("Check for size null", results.size() > 0);
    }

}
