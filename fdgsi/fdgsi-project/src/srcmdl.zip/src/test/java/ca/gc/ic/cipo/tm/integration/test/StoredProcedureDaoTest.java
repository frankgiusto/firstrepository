package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.StoredProcedureDao;
import ca.gc.ic.cipo.tm.dao.TransactionInboxAttachmentDao;
import ca.gc.ic.cipo.tm.model.StoreFileStoredProcedureParameters;
import ca.gc.ic.cipo.tm.model.TransactionInboxAttachment;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class StoredProcedureDaoTest {

    @Autowired
    @Qualifier("storedProcedureDao")
    private StoredProcedureDao storedProcedureDao;

    @Autowired
    @Qualifier("transactionInboxAttachmentDao")
    private TransactionInboxAttachmentDao transactionInbooxAttachmentDao;

    /**
     * sSQLQUERY string parameter for stored procedure call (STORE_FILE) - used for Adjustment renewal fee transaction
     */
    private static final String sSQL_QUERY_FORMAT = "select ATTACHMENT_FILE from EC_TRANSACTION_INBOX_ATTCH where INBOX_ATTACHMENT_SEQ_NO = %d";

    @Test
    @Rollback(true)
    @Transactional(readOnly = true)
    @Ignore
    public void callStorefile() {
        // 578655
        // 23184
        // StoreFileStoredProcedureParameters storedProcedureParameters =
        // StoreFileStoredProcedureParameters.makeStoreFileParameters(sqlQuery, fileNumber, extensionCounter, fileType,
        // fileName)
        Integer fileNumber = 576533;
        Integer extensionCounter = 0;
        Integer transactionInboxSeqNumber = 22903;
        String attachmentFileName = "AdjRenFee_20190117095442.pdf";
        List<TransactionInboxAttachment> attachments = this.transactionInbooxAttachmentDao
            .getTransactionAttachmentMinimumInfoList(transactionInboxSeqNumber);

        String sSQLQueryParam = null;
        String fileName = attachmentFileName;
        if (!CollectionUtils.isEmpty(attachments)) {
            for (TransactionInboxAttachment eachAtt : attachments) {
                sSQLQueryParam = String.format(sSQL_QUERY_FORMAT, eachAtt.getAttachmentSeqNum());
                StoreFileStoredProcedureParameters params = StoreFileStoredProcedureParameters.makeStoreFileParameters(
                    sSQLQueryParam, fileNumber, extensionCounter, eachAtt.getAttachmentType(), fileName);
                boolean result = this.storedProcedureDao.callStoreFile("STORE_FILE", params);
                Assert.assertTrue(result);
            }
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = true)
    @Ignore
    public void moveFileRegistrationRenewalTransaction() {
        Integer fileNumber = 576533;
        Integer extensionCounter = 0;
        final String sqlQuery = "select ECRCPT_BLOB from WEB_TRANSACTIONS where FILE_NUMBER = 576533 and EXTENSION_COUNTER = 0 AND STATUS_CODE = 4";
        final String mailAttachmentFilename = "REN_20190315074934_rcpt.pdf";
        List<String> expectedFilenames = new ArrayList<>();
        expectedFilenames.add("REN_20190315074934_rcpt.pdf");

        StoreFileStoredProcedureParameters params = StoreFileStoredProcedureParameters.makeStoreFileParameters(sqlQuery,
            fileNumber, extensionCounter, 2, mailAttachmentFilename);

        boolean result = this.storedProcedureDao.callStoreFile("STORE_FILE", params);
        Assert.assertTrue(result);

    }
}
