package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionFactory;
import ca.gc.ic.cipo.tm.dao.search.GenericSearch;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.dao.search.SearchExpressionConstructor;
import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.enumerator.InterestedPartyRelationshipType;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.Contact;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class GenericSearchTest extends TestCase {

    @Autowired
    private GenericSearch genericSearch;

    @Test
    @Transactional(readOnly = true)
    public void testBasicSearchByAppNumber() {
        String fileNumber = "148256";
        List<Expression> seList = new ArrayList<Expression>();
        // construct SearchExpression by property, operator, value and
        // search entity
        SearchExpression searchExpression = new SearchExpression(
            ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), HibernateOperatorEnum.EQUAL,
            Integer.valueOf(fileNumber), Application.class);

        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        List<Application> applications = genericSearch.basicSearchOnApplication(seList, HibernateOperatorEnum.AND);
        printApplicationData(applications);
    }

    @Test
    @Transactional(readOnly = true)
    public void testAdvancedSearchByAppCriterion() {
        List<Expression> seList = new ArrayList<Expression>();

        // construct search expression for primary applicant
        SearchExpression searchExpression = new SearchExpression(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE,
            HibernateOperatorEnum.EQUAL, InterestedPartyRelationshipType.OWNER.getValue(), InterestedParty.class);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // construct search expression for legal name of primary
        // applicant
        searchExpression = new SearchExpression(
            ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue() + "." + ModelPropertyType.CONTACT_NAME.getValue(),
            HibernateOperatorEnum.LIKE, "Les Creations Tiffany (1982) Inc.,", InterestedParty.class);
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        searchExpression = new SearchExpression(
            ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue() + "."
                + ModelPropertyType.INTERESTED_PARTIES_ADDRESSES.getValue() + "."
                + ModelPropertyType.ADDRESS_COUNTRY_PROVINCE.getValue(),
            HibernateOperatorEnum.EQUAL, "Q1", Contact.class);
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        List<Application> applications = genericSearch.advancedSearchOnApplication(seList, HibernateOperatorEnum.AND);
        printApplicationData(applications);

    }

    @Test
    @Transactional(readOnly = true)
    public void testBasicSearchByName() {

        List<Expression> seList = new ArrayList<Expression>();
        // construct search expression for primary applicant
        SearchExpression searchExpression = new SearchExpression(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE,
            HibernateOperatorEnum.EQUAL, InterestedPartyRelationshipType.OWNER.getValue(), InterestedParty.class);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // construct search expression for legal name of primary
        // applicant
        searchExpression = new SearchExpression(
            ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue() + "." + ModelPropertyType.CONTACT_NAME.getValue(),
            HibernateOperatorEnum.EQUAL, "S.C. JOHNSON AND SON, LIMITED", InterestedParty.class);
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        List<InterestedParty> interestedParties = genericSearch.basicSearchOnInterestedParty(seList,
            HibernateOperatorEnum.AND);
        printInterestedPartyData(interestedParties);
    }

    @Test
    @Transactional
    public void testAdvancedSearchByInterestedPartyCriterion() {
        List<Expression> seList = new ArrayList<Expression>();
        SearchExpressionConstructor searchExpressionConstructor = new SearchExpressionConstructor();

        // Entity name
        List<Expression> exps = searchExpressionConstructor.generateSearchExpressionOnLegalEntityName("cadbury limited",
            HibernateOperatorEnum.LIKE);
        seList.addAll(exps);

        // country
        Expression exp = searchExpressionConstructor.generateSearchExpressionOnInterestedPartyCountryProvince("US",
            HibernateOperatorEnum.IN);
        seList.add(exp);

        // address type
        exp = searchExpressionConstructor.generateSearchExpressionForAddressType(AddressType.PRIMARY,
            HibernateOperatorEnum.EQUAL);
        seList.add(exp);

        List<InterestedParty> interestedParties = genericSearch.advancedSearchOnInterestedParty(seList,
            HibernateOperatorEnum.AND);
        printInterestedPartyData(interestedParties, true);
    }

    private void printApplicationData(List<Application> applications) {
        if (applications != null) {
            System.out.println("--------- Total count of APPLICATION Data: " + applications.size());
            for (Application application : applications) {
                System.out.println("--------- APPLICATION Data ---------");
                System.out.println("-------------- File Number: " + application.getFileNumber());
                System.out.println("-------------- Extension counter: " + application.getExtensionCounter());
                System.out.println("-------------- Application status code: " + application.getStatusCode());
            }
        }
    }

    private void printInterestedPartyData(List<InterestedParty> interestedParties) {
        printInterestedPartyData(interestedParties, false);
    }

    private void printInterestedPartyData(List<InterestedParty> interestedParties, boolean assertAddressType) {
        if (!CollectionUtils.isEmpty(interestedParties)) {
            System.out.println("--------- Total count of InterestedParty Data: " + interestedParties.size());
            for (InterestedParty interestedParty : interestedParties) {
                System.out.println("--------- InterestedParty Data ---------");
                System.out.println("-------------- File Number: " + interestedParty.getFileNumber());
                System.out.println("-------------- Extension counter: " + interestedParty.getExtensionCounter());
                System.out.println("-------------- Relation Type code: " + interestedParty.getRelationshipType());
                System.out.println("-------------- Name: " + interestedParty.getContact().getName());

                Set<InterestedPartiesAddresses> interestedPartiesAddresses = interestedParty.getContact()
                    .getInterestedPartiesAddresses();

                System.out.println("--------- InterestedPartyAddresses Data ---------");
                if (!CollectionUtils.isEmpty(interestedPartiesAddresses)) {
                    for (InterestedPartiesAddresses address : interestedPartiesAddresses) {
                        System.out.println("-------------- Country/Province: " + address.getCountryProvince());
                        System.out.println("-------------- Postal Code: " + address.getPostalCode());
                        System.out.println("-------------- Address Type: " + address.getAddressType());

                    }
                }
                System.out.println();
                System.out.println("-------------- Agent number: "
                    + ((interestedParty.getAgent() != null && interestedParty.getAgent().getArNumber() != null)
                        ? interestedParty.getAgent().getArNumber() : ""));
            }
        }
    }
}
