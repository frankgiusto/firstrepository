/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import junit.framework.TestCase;

/**
 * This class tests ActionDao
 *
 * @see ActionDao
 * @author martinr3
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class ActionDaoTest extends TestCase {

    @Autowired
    private ActionDao actionDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    /**
     * Checks that updating an Action works as expected
     */
    // @Test
    // @Transactional(readOnly = false)
    // @Ignore
    // Update not allowed on the table - this test is ignored
    public void saveActionUpdateTest() {
        Action action = null;

        for (Action foundAction : actionDao.getActions(111, 0)) {
            if (foundAction.getActionCode() == 1 && foundAction.getApplication().getFileNumber() == 111
                && foundAction.getExtensionCounter() == 0) {
                action = foundAction;
                break;
            }
        }
        if (action != null) {
            action.setAdditionalInfo("test");
            action.setPerformedByAuthorityId("ECTEST1");
            action.setResponseDate(new Date());
            if (actionDao == null) {
                System.out.println("actionDao is NULL!!!");
            }
            if (applicationDao == null) {
                System.out.println("applicationDao is NULL!!!");
            }
            action.setApplication(applicationDao.getApplication(action.getFileNumber(), action.getExtensionCounter()));
            actionDao.saveAction(action);
        }
        Action detachedAction = new Action();
        // Need to do a copy since Hibernate sets newAction and retrieved action to the same instance...
        BeanUtils.copyProperties(action, detachedAction);
        // Forces Hibernate to refresh from DB

        List<Action> actions = actionDao.getActions(action.getFileNumber(), action.getExtensionCounter());
        for (Action actionUpdated : actions) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(actionUpdated);

            if (actionUpdated.getActionCode() == 1) {
                Assert.assertEquals(action.getAdditionalInfo(), actionUpdated.getAdditionalInfo());
                // TODO remove line below when DAO is fixed, action date is not saved/retrieved the same way (is
                // retrieved truncated)
                actionUpdated.setResponseDate(detachedAction.getResponseDate());
                Assert.assertEquals(detachedAction, actionUpdated);
            }
        }
    }

    /**
     * Checks that inserting an Action works as expected
     */
    @Test
    @Transactional(readOnly = false)
    public void saveActionInsertTest() {
        final Integer actionCode = 2;
        Action newAction = buildAction(actionCode);
        actionDao.saveAction(newAction);

        // Forces Hibernate to refresh from DB
        List<Action> actions = actionDao.getActions(newAction.getFileNumber(), newAction.getExtensionCounter());
        for (Action retrievedAction : actions) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedAction);
            assertNotNull("Check for not null", retrievedAction);

            if (retrievedAction.getActionCode().equals(actionCode)
                && retrievedAction.getAdditionalInfo().equals(newAction.getAdditionalInfo())) {
                Assert.assertEquals(newAction.getFileNumber(), retrievedAction.getFileNumber());
                Assert.assertEquals(retrievedAction.getActionCode(), retrievedAction.getActionCode());
                Assert.assertTrue(checkifTimePresent(retrievedAction.getActionDate()));
                Assert.assertTrue(checkifTimePresent(retrievedAction.getResponseDate()));
            }
        }
    }

    private boolean checkifTimePresent(Date date) {
        if (date == null) {
            return false;
        }
        Calendar cal = GregorianCalendar.getInstance();

        cal.setTime(date);
        if (cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) > 0) {
            return true;
        }
        return false;
    }

    private Action buildAction(Integer actionCode) {
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);
        return buildAction(application, actionCode);
    }

    private Action buildAction(Application application, Integer actionCode) {
        Action newAction = new Action();
        newAction.setActionCode(actionCode);
        newAction.setActionDate(new Date());
        newAction.setAdditionalInfo("testInsert");
        newAction.setAuthorityId("ECTEST1");
        newAction.setFileNumber(application.getFileNumber());
        newAction.setExtensionCounter(0);
        newAction.setPerformedByAuthorityId("ECTEST1");
        newAction.setResponseDate(new Date());
        newAction.setApplication(application);
        return newAction;
    }

    /**
     * Checks that ActionDao actions retrieval matches actions retrieval through Application, specifically for a
     * duplicated record
     */
    @Test
    @Transactional(readOnly = true)
    public void getActionsWithDuplicatesTest() {
        // Result should be 12, but test that DAO results matches to be more robust instead
        Assert.assertEquals(applicationDao.getApplication(new ApplicationNumber(599685, 0)).getActions().size(),
            actionDao.getActions(new ApplicationNumber(599685, 0)).size());
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void getActionsApplicationNumber() {
        Action newAction = buildAction(2);
        int i = actionDao.getActions(newAction.getApplication()).size();

        actionDao.saveAction(newAction);
        Assert.assertEquals(i + 1, actionDao.getActions(newAction.getApplication()).size());
    }

    /**
     * This test should find a list of actions on or after allowed.
     */
    @SuppressWarnings("deprecation")
    @Rollback(true)
    @Test
    @Transactional(readOnly = false)
    @Ignore
    public void testGetResultsForActionsOnOrAfterAllowed() {
        buildTestDataForActionsOnOrAfterAllowedWithResults();
        List<Action> actionList = actionDao.getActionsOnOrAfterAllowed(1876176, 0);
        Assert.assertEquals(3, actionList.size());
        System.out.println("ActionCode list size:" + actionList.size());
        for (int i = 0; i < actionList.size(); i++) {
            Action tempAction = actionList.get(i);
            System.out.println("ActionCode: " + tempAction.getActionCode() + ", ActionDate: "
                + tempAction.getActionDate().toGMTString());
        } // End for.
    } // End of the testGetResults method.

    /**
     * This test should not find any results from a search for actions on or after allowed.
     */
    @Rollback(true)
    @Test
    @Transactional(readOnly = false)
    public void testGetNoResultsForActionsOnOrAfterAllowed() {
        buildTestDataForActionsOnOrAfterAllowedWithNoResults();
        List<Action> actionList = actionDao.getActionsOnOrAfterAllowed(1794641, 0);
        Assert.assertEquals(0, actionList.size());
    } // End of the testGetNoResults method.

    @Test
    @Transactional(readOnly = false)
    @Rollback
    @Ignore
    public void testDoesActionCodeExistForApplication() {
        ApplicationNumber applicationNumber = new ApplicationNumber(1680125, 0);
        boolean result = this.actionDao.isOpposedActionRecordNotFound(applicationNumber, ActionCode.OPPOSED);
        Assert.assertFalse("Check if exists ", result);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback
    public void testDoesActionCodeExistForNOnExistingApplication() {
        ApplicationNumber applicationNumber = new ApplicationNumber(617832112, 0);
        boolean result = this.actionDao.isOpposedActionRecordNotFound(applicationNumber, ActionCode.OPPOSED);
        Assert.assertTrue("Check should not exists ", result);
    }

    @Test
    @Transactional(readOnly = true)
    public void testgetEndOfAdvertisedDate() {
        ApplicationNumber applicationNumber = new ApplicationNumber(617832, 0);
        Date result = this.actionDao.getEndOfAdvertisedDate(applicationNumber);
        Assert.assertNotNull(result);
    }

    private void buildTestDataForActionsOnOrAfterAllowedWithResults() {
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 1, new Date(), "CHURCHN1", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 30, new Date(), "CHURCHN1", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 31, new Date(), "CHURCHN1", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 27, new Date(), "IBRAHIFI1", null, new Date(),
            null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 22, new Date(), "IBRAHIFI1", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 26, new Date(), "EXAMINATION", null, null,
            "APPROVED BY PROGRAM EX200M1");
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 40, new Date(), "JOURNAL", "OPERATOR",
            new Date(), null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 42, new Date(), "JOURNAL", "JOURNAL", null,
            "Vol.64 Issue 3256");
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 41, new Date(), "JOURNAL", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 49, new Date(), "JOURNAL", "JOURNAL", null,
            "Vol.64 Issue 3256 2017/03/22");
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 50, new Date(), "WIGNED5", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 51, new Date(), "WIGNED5", null, new Date(),
            null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 55, new Date(), "WIGNED5", null, new Date(),
            null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 34, new Date(), "HOBBSR1", null, null,
            "Partial Assignment / Voir Preuve au dossier/See evidence on File No. 8888888");
    } // End of the buildTestDataForActionsOnOrAfterAllowedWithResults method.

    private void buildTestDataForActionsOnOrAfterAllowedWithNoResults() {
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 1, new Date(), "ANKENBC2", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 15, new Date(), "WANGY1", null, new Date(),
            null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 22, new Date(), "WANGY1", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 49, new Date(), "JOURNAL", "JOURNAL", null,
            "Vol.64 Issue 3262 2017/05/03");
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 50, new Date(), "LEMIEUJ2", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 51, new Date(), "LEMIEUJ2", null, new Date(),
            null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 52, new Date(), "ROYA5", null, null, null);
        buildActionForActionsOnOrAfterAllowed(nextApplicationNumber, 0, 130, new Date(), "ROYA1", null, null,
            "The publication is hereby declared a nullity/ La publication est déclarée être une nullité.");
    } // End of the buildTestDataForActionsOnOrAfterAllowedWithNoResults method.

    /**
     * Create an Action.
     *
     * @param fileNumber
     * @param extensionCounter
     * @param actionCode
     * @param actionDate
     * @param authorityId
     * @param performedByAuthorityId
     * @param responseDate
     * @param additionalInfo
     */
    private void buildActionForActionsOnOrAfterAllowed(Integer fileNumber, Integer extensionCounter, Integer actionCode,
                                                       Date actionDate, String authorityId,
                                                       String performedByAuthorityId, Date responseDate,
                                                       String additionalInfo) {
        Action newAction = new Action();

        newAction.setFileNumber(fileNumber);
        newAction.setExtensionCounter(extensionCounter);
        newAction.setActionCode(actionCode);
        newAction.setActionDate(actionDate);
        newAction.setAuthorityId(authorityId);
        newAction.setPerformedByAuthorityId(performedByAuthorityId);
        newAction.setResponseDate(responseDate);
        newAction.setAdditionalInfo(additionalInfo);
        actionDao.saveAction(newAction);
    } // End of the buildActionForActionsOnOrAfterAllowed method.

    /**
     * Create an application which is required as foreign key.
     *
     * @param nextApplicationNumber
     * @return
     */
    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);

        return application;
    } // End of the createApplication method.

    @Test
    @Transactional(readOnly = true)
    public void testForIsAdjustedRenewalFeeReceived() {
        Boolean result = this.actionDao.isAdjustedRenewalFeeReceived(new ApplicationNumber(1062102, 0));
        Assert.assertNotNull(result);
        Assert.assertFalse(result);
    }

    /**
     * Test saving/retrieving the same action twice
     */
    @Test
    @Transactional(readOnly = false)
    @Rollback(value = true)
    public void testSaveDuplicateActions() {
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        Action action1 = buildAction(application, ActionCode.ADJUSTED_RENEWAL_FEE_RECEIVED.getValue());
        Action action2 = buildAction(application, ActionCode.ADJUSTED_RENEWAL_FEE_RECEIVED.getValue());
        action2.setAdditionalInfo("Action2");
        actionDao.saveAction(action1);
        actionDao.saveAction(action2);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        List<Action> retrievedActions = actionDao.getActions(action1.getApplication());
        List<Action> newActions = new ArrayList<>();
        for (Action action : retrievedActions) {
            if (ActionCode.ADJUSTED_RENEWAL_FEE_RECEIVED.isEqualTo(action.getActionCode())) {
                newActions.add(action);
            }
            Action detachedAction1 = new Action();
            // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
            BeanUtils.copyProperties(action1, detachedAction1);
            // Forces Hibernate to save/refresh from DB
            Action retAction1 = action;
            transactionManager.getSessionFactory().getCurrentSession().refresh(retAction1);
        }
        Assert.assertEquals(2, newActions.size());
        Assert.assertTrue(newActions.get(0).getAdditionalInfo() != newActions.get(1).getAdditionalInfo());

    }

    /**
     * Before using rowid in Hibernate Mapping, non PK columns were set to the same value when PK values were the same,
     * even if it is not the case in DB TMDXML-47
     */
    @Test
    @Transactional(readOnly = true)
    public void testSimilarActions() {
        List<Action> retrievedActions = actionDao.getActions(499853, 0);
        List<Action> actionsSimilar = new ArrayList<Action>();
        for (Action action : retrievedActions) {
            if (action.getActionCode() == 90) {
                actionsSimilar.add(action);
            }
        }
        Assert.assertEquals(2, actionsSimilar.size());
        Assert.assertFalse(actionsSimilar.get(0).getAdditionalInfo().equals(actionsSimilar.get(1).getAdditionalInfo()));
    }
}
