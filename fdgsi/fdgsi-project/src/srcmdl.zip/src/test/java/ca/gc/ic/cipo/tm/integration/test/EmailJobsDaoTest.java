/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.EmailJobsDao;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.PdfFiles;
import junit.framework.TestCase;

/**
 * This class test the EmailJobsDao
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class EmailJobsDaoTest extends TestCase {

    @Autowired
    private EmailJobsDao emailJobsDao;

    @Test
    @Transactional(readOnly = true)
    public void getEmailJobsTest() {

        /*
         * ApplicationNumber applicationNumber = new ApplicationNumber();
         * applicationNumber.setFileNumber(Integer.valueOf(821828));
         * applicationNumber.setExtensionCounter(Integer.valueOf(0));
         *
         * if (emailJobsDao == null) { System.out.println( "emailJobsDao is NULL!!!"); } Set<EmailJobs> emailJobsList =
         * emailJobsDao.getEmailJobs(applicationNumber); assert (emailJobsList.size() > 0);
         * this.printData(emailJobsList);
         *
         * // get the list of Agent Represenatives Set<AgentRepresentative> agentRepresentatives =
         * emailJobsDao.getAgentRepresentatives(Integer.valueOf(9073)); assert (agentRepresentatives.size() > 0);
         * this.printAgentRepresentatives(agentRepresentatives);
         */

        // get the list of PDF Files
        printPDFFilesData(1046116, 0, 6356);
    }

    /**
     * Printing method
     *
     * @param Collection of Email Jobs
     */
    private void printData(Set<EmailJobs> emailJobsList) {

        System.out.println("Email Jobs Data: ");
        System.out.println("================================");

        for (EmailJobs emailJobs : emailJobsList) {
            // This will get the specific email jobs information
            System.out.println("Doubtful Case Details: " + emailJobs.getApplication());
            System.out.println("Email Jobs File Number: " + emailJobs.getFileNumber());
            System.out.println("Email Jobs Extension Counter: " + emailJobs.getExtensionCounter());
            System.out.println("Email Jobs Email Job Number: " + emailJobs.getEmailJobNumber());
            System.out.println("Email Jobs AR Number " + emailJobs.getArNumber());
            System.out.println("Email Jobs Authority ID: " + emailJobs.getAuthorityId());
            System.out.println("Email Jobs Email Status Code: " + emailJobs.getEmailStatusCode());
            System.out.println("Email Jobs Email Job Type: " + emailJobs.getEmailJobType());
            System.out.println("Email Jobs Email Sent TimeStamp: " + emailJobs.getSentTimeStamp());
            System.out.println("Email Jobs Email Created TimeStamp: " + emailJobs.getCreatedTimeStamp());
            System.out.println("Email Jobs Email Modified TimeStamp: " + emailJobs.getModifiedTimeStamp());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Agent representatives
     */
    private void printAgentRepresentatives(Set<AgentRepresentative> agentRepresentatives) {

        System.out.println("Email Jobs Agent Representatives Data: ");
        System.out.println("================================");

        for (AgentRepresentative agentRepresentative : agentRepresentatives) {
            // This will get the specific email jobs agent representatives
            // information

            System.out.println("Email Jobs Agent Representatives AR Number: " + agentRepresentative.getArNumber());
            System.out.println("Email Jobs Agent Representatives AR Type: " + agentRepresentative.getArType());
            System.out.println("Email Jobs Agent Representatives Language: " + agentRepresentative.getLanguage());
            System.out.println("Email Jobs Agent Representatives Status Code: " + agentRepresentative.getStatusCode());
            System.out
                .println("Email Jobs Agent Representatives Major Centre: " + agentRepresentative.getMajorCentre());
            System.out.println("Email Jobs Agent Representatives Statement Receiver Ind: "
                + agentRepresentative.getStatementReceivedInd());
            System.out
                .println("Email Jobs Agent Representatives Renewal Date: " + agentRepresentative.getRenewalDate());
            System.out
                .println("Email Jobs Agent Representatives Effective Year: " + agentRepresentative.getREffectiveYear());
            System.out.println(
                "Email Jobs Agent Representatives Reinstatement Date: " + agentRepresentative.getReinstatementDate());
            System.out.println("Email Jobs Agent Representatives Original Registration Date: "
                + agentRepresentative.getOriginalRegistrationDate());
            System.out
                .println("Email Jobs Agent Representatives Contact Name: " + agentRepresentative.getContactName());
            System.out.println("Email Jobs Agent Representatives Contact: " + agentRepresentative.getContact());
            System.out
                .println("Email Jobs Agent Representatives Account Number: " + agentRepresentative.getAccountNumber());
            System.out.println(
                "Email Jobs Agent Representatives Electronic Corr Ind: " + agentRepresentative.getElectronicCorrInd());
            System.out
                .println("Email Jobs Agent Representatives IP for Agent: " + agentRepresentative.getIpForAgentNumber());
            System.out.println(
                "Email Jobs Agent Representatives IP for Rep Number: " + agentRepresentative.getIpForRepNumber());
            System.out.println("================================");
            System.out.println("================================");

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Pdf Files
     */
    private void printPDFFilesData(Integer fileNumber, Integer extensionCounter, Integer emailJobNumber) {

        System.out.println("PDF Files Data: ");
        System.out.println("================================");

        Set<PdfFiles> pdfFilesList = emailJobsDao.getPdfFiles(fileNumber, extensionCounter, emailJobNumber);

        for (PdfFiles pdfFiles : pdfFilesList) {
            // This will get the specific pdf files information
            System.out.println("Email Jobs Details: " + pdfFiles.getEmailJobs());
            System.out.println("PDF Files Email Job Number: " + pdfFiles.getEmailJobNumber());
            System.out.println("PDF Files Output Code: " + pdfFiles.getOutputCode());
            System.out.println("PDF Files File Name: " + pdfFiles.getFileName());
            System.out.println("PDF Files PDF Job Status Code " + pdfFiles.getPdfJobStatusCode());
            System.out.println("PDF Files Created TimeStamp: " + pdfFiles.getCreatedTimeStamp());
            System.out.println("PDF Files Modified TimeStamp: " + pdfFiles.getModifiedTimeStamp());
            System.out.println("PDF Files Job Error: " + pdfFiles.getPdfJobError());
            System.out.println("PDF Files File Error: " + pdfFiles.getFileBlob());

        }
    }

}
