/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.HistoricalFileActionsDao;
import ca.gc.ic.cipo.tm.model.HistoricalFileActions;
import junit.framework.TestCase;

/**
 * This class tests the HistoricalFileActionsDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class HistoricalFileActionsDaoTest extends TestCase {

    @Autowired
    private HistoricalFileActionsDao historicalFileActionsDao;

    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getHistoricalFileActions() {

        String receiverAuthorityId = "PUBLIC";
        String senderAuthorityId = "DAGENAR1";

        if (historicalFileActionsDao == null) {
            System.out.println("historicalFileActionsDao is NULL!!!");
        }

        Set<HistoricalFileActions> historicalFileActions = historicalFileActionsDao
            .getHistoricalFileActions(receiverAuthorityId, senderAuthorityId);

        assert (historicalFileActions.size() > 0);

        this.printData(historicalFileActions);

    }

    /**
     * Printing method
     *
     * @param Collection of Current File Actions
     */
    private void printData(Set<HistoricalFileActions> currentFileActionsSet) {

        System.out.println("Historical File Actions Data: ");
        System.out.println("=============================");
        for (HistoricalFileActions historicalFileActions : currentFileActionsSet) {
            // This will get the specific historical file action information

            System.out.println("Historical Current File Actions File Number: " + historicalFileActions.getFileNumber());
            System.out.println("Historical Current File Actions File Type: " + historicalFileActions.getFileType());
            System.out.println(
                "Historical Current File Actions Request Time Stamp: " + historicalFileActions.getReceiveTimeStamp());
            System.out.println(
                "Historical Current File Actions Reserve Time Stamp: " + historicalFileActions.getSendTimeStamp());
            System.out
                .println("Historical Current File Actions Receiver Name: " + historicalFileActions.getReceiverName());
            System.out.println("Historical Current File Actions AR Number: " + historicalFileActions.getArNumber());

        }
    }

}
