package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class MadridApplicationDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionDao;

    private static Integer MADRID_APPLICATION_PENDING = 1;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void createMadridApplicationsTest() {

        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber("99999FG");
        madridApplication.setWipoReferenceNumber("FG-77777");
        madridApplication.setStatusCode(MADRID_APPLICATION_PENDING);
        madridApplicationDao.saveMadridApplication(madridApplication);

        MadridApplicationAction madridApplicationActions = new MadridApplicationAction();
        madridApplicationActions.setActionCode(1);
        madridApplicationActions.setActionDate(new Date());
        madridApplicationActions.setAdditionalInfo("Test");
        madridApplicationActions.setAuthorityId("GIUSTOF1");
        madridApplicationActions.setWipoReferenceNumber("FG-77777");
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationActions.setMadridApplicationActionsSeqNumber(madridApplicationActionId);

        // madridApplicationActions.setMadridApplication(madridApplication);
        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationActions);
        // madridApplication.getMadridApplicationActions().add(madridApplicationActions);

        // Create Madrid Application Xref
        MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
        madridApplicationXref.setMadridApplication(madridApplication);
        madridApplicationXref.setExtensionCounter(0);
        madridApplicationXref.setFileNumber(application.getFileNumber());
        madridApplicationXref.setWipoReferenceNumber("FG-77777");

        madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);
        madridApplicationDao.saveMadridApplication(madridApplication);

        MadridApplication madridApplication2 = madridApplicationDao.getMadridApplicationByReferenceNumber("FG-77777");
        assertTrue(madridApplication2.getIrNumber().equals("99999FG"));

        List<MadridApplication> application2 = madridApplicationDao.getMadridApplicationByIrNumber("99999FG");

        assertTrue(application2.get(0).getIrNumber().equals("99999FG"));
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void createMadridApplicationsTest2() {

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber("99999FG");
        madridApplication.setWipoReferenceNumber("FG-77777");
        madridApplication.setStatusCode(MADRID_APPLICATION_PENDING);

        // Create Application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Madrid Application Xref
        MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
        madridApplicationXref.setMadridApplication(madridApplication);
        madridApplicationXref.setExtensionCounter(0);
        madridApplicationXref.setFileNumber(application.getFileNumber());
        madridApplicationXref.setWipoReferenceNumber("FG-77777");

        madridApplicationDao.saveMadridApplication(madridApplication);
        madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);

        // nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        // application = createApplication(nextApplicationNumber);
        // applicationDao.saveApplication(application);
        //
        // madridApplicationXref = new MadridApplicationXref();
        // madridApplicationXref.setMadridApplication(madridApplication);
        // madridApplicationXref.setExtensionCounter(0);
        // madridApplicationXref.setFileNumber(application.getFileNumber());
        // madridApplicationXref.setWipoReferenceNumber("FG-77777");
        //
        // madridApplicationDao.saveMadridApplication(madridApplication);
        // madridApplication.getMadridApplicationXrefs().add(madridApplicationXref);
        //
        // MadridApplication madridApplication2 =
        // madridApplicationDao.getMadridApplicationByReferenceNumber("FG-77777");
        // assertTrue(madridApplication2.getIrNumber().equals("99999FG"));
        //
        List<MadridApplication> results = madridApplicationDao.getMadridApplicationByIrNumber("99999FG");

        Assert.assertNotNull(results);
        // should be 1
        Assert.assertEquals(1, results.size());
        for (MadridApplication eachApplication : results) {
            Assert.assertNotNull(eachApplication.getMadridApplicationXrefs());
            // should be 1
            Assert.assertEquals(1, eachApplication.getMadridApplicationXrefs().size());
        }
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);

        return application;
    }

}
