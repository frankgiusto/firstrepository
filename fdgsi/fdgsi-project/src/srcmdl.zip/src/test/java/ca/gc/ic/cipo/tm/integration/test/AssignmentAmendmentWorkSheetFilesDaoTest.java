/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AssignmentAmendmentWorkSheetFilesDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import junit.framework.TestCase;

/**
 * This class test the AssignmentAmendmentAWorkSheetFilesDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AssignmentAmendmentWorkSheetFilesDaoTest extends TestCase {

    @Autowired
    private AssignmentAmendmentWorkSheetFilesDao aAWorkSheetFilesDao;

    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getAAWorkSheetFiles() {

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(32696));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        if (aAWorkSheetFilesDao == null) {
            System.out.println("aAWorkSheetFilesDao is NULL!!!");
        }
        Set<AssignmentAmendmentWorkSheetFiles> aaWorkSheetFiles = aAWorkSheetFilesDao
            .getAssignmentAmendmentWorkSheetFiles(applicationNumber);
        assert (aaWorkSheetFiles.size() > 0);
        this.printData(aaWorkSheetFiles);

    }

    /**
     * Printing method
     *
     * @param Collection of aa work sheet files
     */
    private void printData(Set<AssignmentAmendmentWorkSheetFiles> aaWorkSheetFilesSet) {

        System.out.println("AA Work Sheet Files Data: ");
        System.out.println("=============================");
        for (AssignmentAmendmentWorkSheetFiles aaWorkSheetFiles : aaWorkSheetFilesSet) {
            // This will get the specific aa work sheet files information
            System.out.println("Application Details: " + aaWorkSheetFiles.getApplication());
            System.out.println("AA Work Sheet Files User Input Index: " + aaWorkSheetFiles.getUserInputIndex());
            System.out.println("AA Work Sheet Files Iteration Counter " + aaWorkSheetFiles.getIterationCounter());
            System.out.println("AA Work Sheet Files Work Sheet Number: " + aaWorkSheetFiles.getWorkSheetNumber());

        }
    }

}
