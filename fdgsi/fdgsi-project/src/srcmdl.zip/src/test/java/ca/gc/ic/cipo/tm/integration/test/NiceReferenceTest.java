package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.NiceReferenceDao;
import ca.gc.ic.cipo.tm.model.NiceReference;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class NiceReferenceTest extends TestCase {

    @Autowired
    private NiceReferenceDao niceReferenceDao;

    @Test
    @Transactional(readOnly = true)
    public void readNiceReference() {
        NiceReference nf = niceReferenceDao.getNiceReference(Integer.valueOf(11), Integer.valueOf(2));
        assertNotNull(nf);
        System.out.println("Nice Reference En Heading: \n" + nf.getEnClassHeadingDesc());
    }

    @Test
    @Transactional(readOnly = true)
    public void readNiceReferences() {
        List<NiceReference> niceReferences = new ArrayList<NiceReference>();
        niceReferences = niceReferenceDao.getNiceReferences(Integer.valueOf(11));
        assertNotNull(niceReferences);
        for (NiceReference niceReference : niceReferences) {
            System.out.println(
                "Nice: " + niceReference.getId().getNiceClassCode() + " - " + niceReference.getEnClassHeadingDesc());
        }
    }
}
