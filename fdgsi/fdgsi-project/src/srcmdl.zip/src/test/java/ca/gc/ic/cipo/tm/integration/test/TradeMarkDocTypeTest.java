package ca.gc.ic.cipo.tm.integration.test;

import java.io.InputStream;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;
import ca.gc.ic.cipo.tm.type.TradeMarkDocTypeFactory;
import ca.gc.ic.cipo.util.cipher.PropertiesFileCipherUtility;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class TradeMarkDocTypeTest extends TestCase {

    private static final String CONFIG_FILE = "configuration.properties";

    private Properties property;

    @Override
    @Before
    public void setUp() {
        InputStream input = TradeMarkDocTypeTest.class.getClassLoader().getResourceAsStream(CONFIG_FILE);
        property = PropertiesFileCipherUtility.getProperties(input);
    }

    @Test
    public void testTrademarkDesign() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.DESIGN.getValue()).path(property);
        assertEquals("Design path not equal to trademark type design", path, "designs/");
    }

    @Test
    public void testTrademarkSound() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.SOUND.getValue()).path(property);
        assertEquals("Sound path not equal to trademark type sound", path, "sounds/");
    }
    
    @Test
    public void testTrademarkMultiType() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.MULTI_TYPE.getValue()).path(property);
        assertEquals("Multi Type path not equal to trademark type multi-type", path, "multi/");
    }
    @Test
    public void testTrademarkColor() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.COLOR.getValue()).path(property);
        assertEquals("Color path not equal to trademark type color", path, "color/");
    }

    @Test
    public void testTrademarkHologram() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.HOLOGRAM.getValue()).path(property);
        assertEquals("Hologram path not equal to trademark type hologram", path, "hologram/");
    }

    @Test
    public void testTrademarkMotion() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.MOTION.getValue()).path(property);
        assertEquals("Motion path not equal to trademark type motion", path, "motion/");
    }

    @Test
    public void testTrademarkPackagingGood() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.PACKAGING_GOOD.getValue()).path(property);
        assertEquals("Packaging goods path not equal to trademark type packaging goods", path, "packaging/");
    }

    @Test
    public void testTrademarkPositional() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.POSITIONAL.getValue()).path(property);
        assertEquals("Positional path not equal to trademark type positional", path, "positional/");
    }

    @Test
    public void testTrademarkScent() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.SCENT.getValue()).path(property);
        assertEquals("Scent path not equal to trademark type scent", path, "scent/");
    }

    @Test
    public void testTrademarkStandardCharacters() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.STANDARD_CHARACTERS.getValue()).path(property);
        assertEquals("Standard charaters path not equal to trademark type standard character", path, "standard/");
    }

    @Test
    public void testTrademarkTaste() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.TASTE.getValue()).path(property);
        assertEquals("Taste path not equal to trademark type taste", path, "taste/");
    }

    @Test
    public void testTrademarkTexture() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.TEXTURE.getValue()).path(property);
        assertEquals("Texture path not equal to trademark type texture", path, "texture/");
    }

    @Test
    public void testTrademarkThreeDimensional() {
        String path = TradeMarkDocTypeFactory.getInstance(TradeMarkType.THREE_DIMENSIONAL.getValue()).path(property);
        assertEquals("Three dimensional path not equal to trademark type three dimentional", path, "threedim/");
    }

}
