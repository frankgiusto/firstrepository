/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AssignmentAmendmentWorkSheetsDao;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFilesId;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheets;
import junit.framework.TestCase;

/**
 * This class test the AssignmentAmendmentAWorkSheetsDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AssignmentAmendmentWorkSheetsDaoTest extends TestCase {

    @Autowired
    private AssignmentAmendmentWorkSheetsDao aAWorkSheetsDao;

    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getAAWorkSheets() {

        AssignmentAmendmentWorkSheetFilesId aaWorkSheetFilesId = new AssignmentAmendmentWorkSheetFilesId();
        aaWorkSheetFilesId.setFileNumber(Integer.valueOf(32696));
        aaWorkSheetFilesId.setExtensionCounter(Integer.valueOf(0));
        aaWorkSheetFilesId.setWorkSheetNumber(Integer.valueOf(1007244));

        if (aAWorkSheetsDao == null) {
            System.out.println("aAWorkSheetsDao is NULL!!!");
        }

        Set<AssignmentAmendmentWorkSheets> aaWorkSheets = aAWorkSheetsDao
            .getAssignmentAmendmentWorkSheets(aaWorkSheetFilesId);

        // assert (aaWorkSheets.size() > 0);

        this.printData(aaWorkSheets);

        Set<AssignmentAmendmentTransaction> aaTransactions = aAWorkSheetsDao
            .getAssignmentAmendmentTransactions("AMCMILLL1", 984210, 1002594);

        // assert (aaTransactions.size() > 0);

        this.printAATransactions(aaTransactions);

        printAssignmentAmendmentWorkSheetFilesData(32696, 0, 1007244);

    }

    /**
     * Printing method
     *
     * @param Collection of aa work sheets
     */
    private void printData(Set<AssignmentAmendmentWorkSheets> aaWorkSheetsSet) {

        System.out.println("AA Work Sheets Data: ");
        System.out.println("=============================");
        for (AssignmentAmendmentWorkSheets aaWorkSheets : aaWorkSheetsSet) {
            // This will get the specific aa work sheets information
            // System.out.println("AAWorkSheetFiles Details: " +
            // aaWorkSheets.getaAWorkSheetFiles());
            System.out.println("AA Work Sheets Work Sheet Label: " + aaWorkSheets.getWorkSheetLabel());
            System.out.println("AA Work Sheets Authority Id: " + aaWorkSheets.getAuthorityId());
            System.out.println("AA Work Sheets Edit Date: " + aaWorkSheets.getEditDate());
            System.out.println("AA Work Sheets Assemble Date: " + aaWorkSheets.getAssembleDate());
            System.out.println("AA Work Sheets Changes Made Ind: " + aaWorkSheets.getChangesMadeInd());
            System.out.println("AA Work Sheets Do Not Assemble Ind: " + aaWorkSheets.getDoNotAssembleInd());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of AA Transactions
     */
    private void printAATransactions(Set<AssignmentAmendmentTransaction> aaTransactions) {

        System.out.println("AA Work Sheets Transactions Data: ");
        System.out.println("=============================");
        for (AssignmentAmendmentTransaction aaTransaction : aaTransactions) {
            // This will get the specific aa work sheets transactions
            // information
            System.out.println("AA Work Sheets Transactions AAT Number " + aaTransaction.getAatNumber());
            System.out.println("AA Work Sheets Transactions AAT Label: " + aaTransaction.getAatLabel());
            System.out.println("AA Work Sheets Transactions AAT Type: " + aaTransaction.getAatType());
            System.out.println("AA Work Sheets Transactions Authority Id " + aaTransaction.getAuthorityId());
            System.out
                .println("AA Work Sheets Transactions AAT Work Sheet Number: " + aaTransaction.getWorkSheetNumber());
            System.out
                .println("AA Work Sheets Transactions AAT Master File Number: " + aaTransaction.getMasterFileNumber());
            System.out.println(
                "AA Work Sheets Transactions Master Extension Counter " + aaTransaction.getMasterExtensionCounter());
            System.out.println("AA Work Sheets Transactions Status Code: " + aaTransaction.getStatusCode());
            System.out.println("AA Work Sheets Transactions Start Date: " + aaTransaction.getStartDate());
            System.out.println("AA Work Sheets Transactions Receive Date " + aaTransaction.getReceiveDate());
            System.out.println("AA Work Sheets Transactions Correctrion Ind: " + aaTransaction.getCorrectionInd());
            System.out.println("AA Work Sheets Transactions Court Order Ind: " + aaTransaction.getCourtOrderInd());
            System.out.println("AA Work Sheets Transactions Footnote Type: " + aaTransaction.getFootnoteType());
            System.out.println(
                "AA Work Sheets Transactions Footnote Date Of Change: " + aaTransaction.getFootnoteDateOfChange());
            System.out.println("AA Work Sheets Transactions Footnote Text " + aaTransaction.getFootnoteText());
            System.out.println("AA Work Sheets Transactions Agent Change Ind: " + aaTransaction.getAgentChangeInd());
            System.out.println("AA Work Sheets Transactions Rep Change Ind: " + aaTransaction.getRepChangeInd());
            System.out
                .println("AA Work Sheets Transactions Correspondence Date: " + aaTransaction.getCorrespondenceDate());
            System.out.println("AA Work Sheets Transactions Reponse Date: " + aaTransaction.getResponseDate());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of aa work sheet files
     */
    private void printAssignmentAmendmentWorkSheetFilesData(Integer fileNumber, Integer extensionCounter,
                                                            Integer workSheetNumber) {

        System.out.println("AA Work Sheet Files Data: ");
        System.out.println("=============================");

        Set<AssignmentAmendmentWorkSheetFiles> aaWorkSheetFilesSet = aAWorkSheetsDao
            .getAssignmentAmendmentWorkSheetFiles(fileNumber, extensionCounter, workSheetNumber);
        for (AssignmentAmendmentWorkSheetFiles aaWorkSheetFiles : aaWorkSheetFilesSet) {
            // This will get the specific aa work sheet files information
            System.out.println("Application Details: " + aaWorkSheetFiles.getApplication());
            System.out.println("AA Work Sheet Files User Input Index: " + aaWorkSheetFiles.getUserInputIndex());
            System.out.println("AA Work Sheet Files Iteration Counter " + aaWorkSheetFiles.getIterationCounter());
            System.out.println("AA Work Sheet Files Work Sheet Number: " + aaWorkSheetFiles.getWorkSheetNumber());

        }
    }
}
