package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.CitedLinksDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.CitedLinks;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class CitedLinksDaoTest {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private CitedLinksDao citedLinksDao;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void createCitedLinksTest() {
        Integer applicationNumber = applicationDao.getNextApplicationNumber().intValue();
        CitedLinks citedLinks = createCitedLinks(applicationNumber);
        citedLinksDao.saveCitedLinks(citedLinks);

        List<CitedLinks> savedCitedLinks = citedLinksDao
            .getCitedLinksForFileNumber(new ApplicationNumber(applicationNumber, 0));

        Assert.assertNotNull(savedCitedLinks);
        Assert.assertEquals(savedCitedLinks.size(), 1);
    }

    private CitedLinks createCitedLinks(Integer nextApplicationNumber) {
        CitedLinks citedLinks = new CitedLinks();
        citedLinks.setFileNumber(nextApplicationNumber);
        citedLinks.setExtensionCounter(0);
        citedLinks.setCitedSectionNumber(1);
        citedLinks.setCitedFileNumber(1);
        citedLinks.setCitedExtensionCounter(1);
        citedLinks.setCitedRegistrationNumber("UCA40055");
        return citedLinks;
    }

}
