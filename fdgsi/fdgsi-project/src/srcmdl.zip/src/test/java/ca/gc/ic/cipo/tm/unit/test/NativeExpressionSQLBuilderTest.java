package ca.gc.ic.cipo.tm.unit.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionFactory;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.dao.search.builders.NativeExpressionSQLBuilder;
import ca.gc.ic.cipo.tm.type.CountryCanadaProvinceEnum;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class NativeExpressionSQLBuilderTest {

    @Test
    public void andExpression() {
        List<Expression> seList = new ArrayList<>();

        // Entity name
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IP.NAME", "name",
            HibernateOperatorEnum.LIKE, "jane");

        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // country
        searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE", "countryProvince",
            HibernateOperatorEnum.IN, "CA");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // city
        searchExpression = SearchExpression.makeSearchExpression("IPA.ADDRESS", "city", HibernateOperatorEnum.IN,
            "NYC");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // phone number
        searchExpression = SearchExpression.makeSearchExpression("IP.TELEPHONE_NUMBER", "telephoneNumber",
            HibernateOperatorEnum.EQUAL, "565-565-5859");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // address type
        searchExpression = SearchExpression.makeSearchExpression("IPA.ADDRESS_TYPE", "addressType",
            HibernateOperatorEnum.EQUAL, "1");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.AND)
            .buildQuery();
        String result = builder.toFinalSQL();
        Map<String, Object> params = builder.toParametersMap();
        // System.out.println("SQL (AND)" + result);
        // System.out.println("Parameters " + params);
        Assert.assertNotNull(result);
        Assert.assertNotNull(params);
        Assert.assertTrue(params.size() > 0);

    }

    @Test
    public void orExpression() {
        List<Expression> seList = new ArrayList<>();

        // Entity name
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IP.NAME", "name",
            HibernateOperatorEnum.LIKE, "joe");

        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // country
        searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE", "countryProvince",
            HibernateOperatorEnum.EQUAL, "CA");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // city
        searchExpression = SearchExpression.makeSearchExpression("IPA.ADDRESS", "city",
            HibernateOperatorEnum.START_WITH, "Ottawa");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // phone number
        searchExpression = SearchExpression.makeSearchExpression("IP.TELEPHONE_NUMBER", "telephoneNumber",
            HibernateOperatorEnum.EQUAL, "555-555-5555");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        // address type
        searchExpression = SearchExpression.makeSearchExpression("IPA.ADDRESS_TYPE", "addressType",
            HibernateOperatorEnum.EQUAL, "1");
        expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);

        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.OR)
            .buildQuery();
        String result = builder.toFinalSQL();
        Map<String, Object> params = builder.toParametersMap();
        Assert.assertNotNull(result);
        Assert.assertNotNull(params);
        Assert.assertTrue(params.size() > 0);
    }

    @Test
    public void checkExpressions() {
        checkEquals();
        checkLike();
        checkStartsWith();
        checkEndsWith();
        checkIn();
    }

    private void checkEquals() {
        List<Expression> seList = new ArrayList<>();
        // country
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE",
            "countryProvince", HibernateOperatorEnum.EQUAL, "CA");
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);
        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.OR)
            .buildQuery();
        String result = builder.toFinalSQL();
        // System.out.println("SQL " + result);
        // IPA.COUNTRY_PROVINCE = :countryProvince
        Assert.assertNotNull(result);
        Assert.assertEquals("IPA.COUNTRY_PROVINCE = :countryProvince ", result);
    }

    private void checkLike() {
        List<Expression> seList = new ArrayList<>();
        // country
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE",
            "countryProvince", HibernateOperatorEnum.LIKE, "CA");
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);
        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.OR)
            .buildQuery();
        String result = builder.toFinalSQL();
        // System.out.println("SQL " + result);
        // upper(IPA.COUNTRY_PROVINCE) like upper(:countryProvince)
        Assert.assertNotNull(result);
        Assert.assertEquals(" upper(IPA.COUNTRY_PROVINCE) like upper(:countryProvince) ", result);
    }

    private void checkStartsWith() {
        List<Expression> seList = new ArrayList<>();
        // country
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE",
            "countryProvince", HibernateOperatorEnum.START_WITH, "CA");
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);
        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.OR)
            .buildQuery();
        String result = builder.toFinalSQL();
        // System.out.println("SQL " + result);
        // upper(IPA.COUNTRY_PROVINCE) like upper(:countryProvince)
        Assert.assertNotNull(result);
        Assert.assertEquals(" upper(IPA.COUNTRY_PROVINCE) like upper(:countryProvince) ", result);
    }

    private void checkEndsWith() {
        List<Expression> seList = new ArrayList<>();
        // country
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE",
            "countryProvince", HibernateOperatorEnum.START_WITH, "CA");
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);
        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.OR)
            .buildQuery();
        String result = builder.toFinalSQL();
        // System.out.println("SQL " + result);
        // upper(IPA.COUNTRY_PROVINCE) like upper(:countryProvince)
        Assert.assertNotNull(result);
        Assert.assertEquals(" upper(IPA.COUNTRY_PROVINCE) like upper(:countryProvince) ", result);
    }

    private void checkIn() {
        List<Expression> seList = new ArrayList<>();
        // country
        SearchExpression searchExpression = SearchExpression.makeSearchExpression("IPA.COUNTRY_PROVINCE",
            "countryProvince", HibernateOperatorEnum.IN, CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList());
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        seList.add(expression);
        NativeExpressionSQLBuilder builder = new NativeExpressionSQLBuilder.Builder(seList, HibernateOperatorEnum.OR)
            .buildQuery();
        String result = builder.toFinalSQL();
        // System.out.println("SQL " + result);
        // IPA.COUNTRY_PROVINCE IN ( :countryProvince )
        Assert.assertNotNull(result);
        Assert.assertEquals("IPA.COUNTRY_PROVINCE IN ( :countryProvince )", result);
    }

}
