package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationXrefDao;
import ca.gc.ic.cipo.tm.dao.repository.HibernateBaseDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;
import junit.framework.TestCase;

/**
 *
 * @author rahmana1 TODO: Please move the tests to MTS unit tests Use the following below to for save/refresh from DB
 *         within the transaction:
 *
 *         Forces Hibernate to save/refresh from DB transactionManager.getSessionFactory().getCurrentSession().flush();
 *         transactionManager.getSessionFactory().getCurrentSession().refresh(savedApplication);
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Ignore("TODO: Please move the tests to MTS unit tests")
public class MadridApplicationXrefDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    MadridApplicationXrefDao madridApplicationXrefDao;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void saveMadridApplicationXrefTest() {
        String wipoReferenceNumber = "YZ-88888";
        String irNumber = "YZ88888";
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        Application application = createApplication(nextApplicationNumber, 0, irNumber);
        applicationDao.saveApplication(application);

        MadridApplication madridApplication = createMadridApplication(irNumber, wipoReferenceNumber);
        madridApplicationDao.saveMadridApplication(madridApplication);
        ((HibernateBaseDao) applicationDao).flush();

        // Number prior to save Xref
        long numXref = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);

        int xrefFileNumber = applicationDao.getNextApplicationNumber().intValue();
        int xrefExtCounter = 0;
        Application domesticApplication = createApplication(xrefFileNumber, xrefExtCounter, null);
        applicationDao.saveApplication(domesticApplication);
        ((HibernateBaseDao) applicationDao).flush();

        MadridApplicationXref xref = createMadridApplicationXref(wipoReferenceNumber, xrefFileNumber, xrefExtCounter);
        madridApplicationXrefDao.saveMadridApplicationXref(xref);
        ((HibernateBaseDao) madridApplicationXrefDao).flush();

        // Number after saving the new xref
        long numXrefNew = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);

        List<MadridApplication> applications = this.madridApplicationDao.getMadridApplicationByIrNumber("YZ88888");

        // Assert that the xref is saved
        Assert.assertEquals("Failed to save MadridApplicationXref", numXrefNew, numXref + 1);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void deleteMadridApplicationXrefTest() {

        String wipoReferenceNumber = "YZ-88888";
        String irNumber = "YZ88888";
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        Application application = createApplication(nextApplicationNumber, 0, irNumber);
        applicationDao.saveApplication(application);

        MadridApplication madridApplication = createMadridApplication(irNumber, wipoReferenceNumber);
        madridApplicationDao.saveMadridApplication(madridApplication);
        List<MadridApplication> madridApplications = madridApplicationDao.getMadridApplicationByIrNumber(irNumber);
        madridApplication = madridApplications.get(0);

        int xrefFileNumber = applicationDao.getNextApplicationNumber().intValue();
        int xrefExtCounter = 0;
        Application domesticApplication = createApplication(xrefFileNumber, xrefExtCounter, null);
        applicationDao.saveApplication(domesticApplication);
        ((HibernateBaseDao) applicationDao).flush();

        // create xref
        MadridApplicationXref xref = createMadridApplicationXref(wipoReferenceNumber, xrefFileNumber, xrefExtCounter);
        xref.setMadridApplication(madridApplication);
        madridApplication.getMadridApplicationXrefs().add(xref);
        madridApplicationDao.saveMadridApplication(madridApplication);
        ((HibernateBaseDao) madridApplicationDao).flush();

        // Number prior to delete xref
        long numXref = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);

        // Delete the xref
        madridApplicationXrefDao.deleteMadridApplicationXref(xrefFileNumber, xrefExtCounter, wipoReferenceNumber);

        // Number after deleting the xref
        long numXrefNew = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);

        // Assert the xref is delted
        Assert.assertEquals("Failed to Delete MadridApplicationXref", numXrefNew, numXref - 1);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void countMadridApplicationXrefTest() {
        String wipoReferenceNumber = "YZ-88888";
        String irNumber = "YZ88888";
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        Application application = createApplication(nextApplicationNumber, 0, irNumber);
        applicationDao.saveApplication(application);

        MadridApplication madridApplication = createMadridApplication(irNumber, wipoReferenceNumber);
        madridApplicationDao.saveMadridApplication(madridApplication);
        List<MadridApplication> madridApplications = madridApplicationDao.getMadridApplicationByIrNumber(irNumber);
        madridApplication = madridApplications.get(0);

        int xrefFileNumber = applicationDao.getNextApplicationNumber().intValue();
        int xrefExtCounter = 0;
        Application domesticApplication = createApplication(xrefFileNumber, xrefExtCounter, null);
        applicationDao.saveApplication(domesticApplication);
        ((HibernateBaseDao) applicationDao).flush();

        long initialXrefNum = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);

        // create xref
        MadridApplicationXref xref = createMadridApplicationXref(wipoReferenceNumber, xrefFileNumber, xrefExtCounter);
        xref.setMadridApplication(madridApplication);
        madridApplication.getMadridApplicationXrefs().add(xref);
        madridApplicationDao.saveMadridApplication(madridApplication);
        ((HibernateBaseDao) madridApplicationDao).flush();

        long numXref = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);

        // Assert Number is higher now after saving the xref
        Assert.assertTrue("Number for MadridApplicationXref does not match", numXref > initialXrefNum);

        madridApplicationXrefDao.deleteMadridApplicationXref(xrefFileNumber, xrefExtCounter, wipoReferenceNumber);

        long actual = madridApplicationXrefDao.countMadridApplicationXref(wipoReferenceNumber);
        long expected = numXref - 1;

        // Assert the number matches with expected number.
        Assert.assertEquals("Number for MadridApplicationXref does not match", actual, expected);

    }

    private MadridApplicationXref createMadridApplicationXref(String wipoReferenceNumber, int fileNumber,
                                                              int extensionCounter) {
        MadridApplicationXref madridApplicationXref = new MadridApplicationXref();
        madridApplicationXref.setExtensionCounter(extensionCounter);
        madridApplicationXref.setFileNumber(fileNumber);
        madridApplicationXref.setWipoReferenceNumber(wipoReferenceNumber);

        return madridApplicationXref;
    }

    private MadridApplication createMadridApplication(String irNumber, String wipoReferenceNumber) {
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber(irNumber);
        madridApplication.setWipoReferenceNumber(wipoReferenceNumber);
        madridApplication.setStatusCode(1);
        return madridApplication;
    }

    private Application createApplication(Integer nextApplicationNumber, int extensionCounter, String irNumber) {
        Application application = new Application();
        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(extensionCounter);
        application.setIrNumber(irNumber);
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        return application;
    }

}
