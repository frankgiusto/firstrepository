package ca.gc.ic.cipo.tm.integration.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import junit.framework.TestSuite;

@RunWith(Suite.class)
@SuiteClasses({ActionDaoTest.class, AgentRepresentativeActionsDaoTest.class, AgentRepresentativeDaoTest.class,
    AgentUserXrefDaoTest.class, ApplicationDaoTest.class, ApplicationEmailsDaoTest.class,
    AssignmentAmendmentTransactionDaoTest.class, AssignmentAmendmentWorkSheetFilesDaoTest.class,
    AssignmentAmendmentWorkSheetsDaoTest.class, AssociatedMarkDaoTest.class, AuthoritiesDaoTest.class,
    CountryProvincesDaoTest.class, CurrentFileActionsDaoTest.class, DataCorrectionActionsLogDaoTest.class,
    DocumentStoredDaoTest.class, EmailJobsDaoTest.class, FinancialTransactionsDaoTest.class,
    FittIdentifiersAgentsRepresentativesDaoTest.class, FittIdentifiersDaoTest.class, FootNotesDaoTest.class,
    GenericSearchTest.class, GoodsServicesDaoTest.class, HistoricalFileActionsDaoTest.class, IndexHeadingsDaoTest.class,
    InterestedPartiesAddressesDaoTest.class, InterestedPartyDaoTest.class, NiceReferenceTest.class,
    OppositionCaseActionDaoTest.class, OralHearingAttendeesDaoTest.class, OralHearingDetailsDaoTest.class,
    PdfFilesDaoTest.class, PhysicalFilesDaoTest.class, ProcessActionsDaoTest.class, PullingListsDaoTest.class,
    ReferenceCodeDaoTest.class, SelectedParagraphsDaoTest.class, TrademarkDaoTest.class, TradeMarkDocTypeTest.class,
    TransactionDaoTest.class, TransactionInboxDaoTest.class, RegistrationDaoTest.class,
    RegistrationRenewalDaoTest.class, SearchAdjustedRenewalFeeDaoTest.class,
    SearchRegRenTransactionHistoryDaoTest.class, SearchRegRenApplicationsForRegistrationDaoTest.class})
public class AllTests {

    public static TestSuite suite() {
        TestSuite suite = new TestSuite();
        return suite;
    }
}
