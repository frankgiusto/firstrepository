package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.enumerator.ClaimType;
import ca.gc.ic.cipo.tm.model.Claim;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = false)
@Rollback(true)
public class ClaimDaoTest extends TestCase {

    @Autowired
    ApplicationDao applicationDao;

    @Autowired
    ClaimDao claimDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    public void testGetClaimIntegerInteger() {
        Claim claim = buildClaim();
        int i = claimDao.getClaim(claim.getFileNumber(), claim.getExtensionCounter()).size();

        claimDao.saveClaim(claim);

        assertEquals(i + 1, claimDao.getClaim(claim.getFileNumber(), claim.getExtensionCounter()).size());
    }

    @Test
    public void testGetClaimIntegerIntegerIntegerInteger() {
        Claim claim = buildClaim();

        claimDao.saveClaim(claim);
        Claim retrievedClaim = claimDao.getClaim(claim.getFileNumber(), claim.getExtensionCounter(),
            claim.getClaimType(), claim.getClaimNumber());
        Claim detachedClaim = new Claim();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(claim, detachedClaim);
        assertNotNull(retrievedClaim);

        Claim retClaim = retrievedClaim;
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(retClaim);
        assertEquals(detachedClaim, retClaim);
    }

    @Test
    public void testGetClaimApplicationNumber() {
        Claim claim = buildClaim();
        int i = claimDao.getClaim(claim.getApplication()).size();

        claimDao.saveClaim(claim);

        assertEquals(i + 1, claimDao.getClaim(claim.getApplication()).size());
    }

    @Test
    public void testGetClaimApplicationNumberIntegerInteger() {
        Claim claim = buildClaim();

        claimDao.saveClaim(claim);
        Claim retrievedClaim = claimDao.getClaim(claim.getApplication(), claim.getClaimType(), claim.getClaimNumber());
        Claim detachedClaim = new Claim();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(claim, detachedClaim);
        assertNotNull(retrievedClaim);

        Claim retClaim = retrievedClaim;
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(retClaim);
        assertEquals(detachedClaim, retClaim);
    }

    @Test
    public void testGetClaimApplicationNumberClaimId() {
        Claim claim = buildClaim();

        claimDao.saveClaim(claim);
        Claim retrievedClaim = claimDao.getClaim(claim.getApplication(), claim);
        Claim detachedClaim = new Claim();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(claim, detachedClaim);
        assertNotNull(retrievedClaim);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedClaim);
        assertEquals(detachedClaim, retrievedClaim);
    }

    @Transactional(readOnly = false)
    @Test
    public void testSaveClaim() {
        Claim claim = buildClaim();
        claimDao.saveClaim(claim);
        Claim retrievedClaim = claimDao.getClaim(claim.getApplication(), claim);
        Claim detachedClaim = new Claim();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(claim, detachedClaim);
        // Forces Hibernate to save/refresh from DB
        Claim retClaim = retrievedClaim;
        transactionManager.getSessionFactory().getCurrentSession().refresh(retClaim);

        assertEquals(detachedClaim, retClaim);

    }

    /**
     * @return
     */
    private Claim buildClaim() {
        Claim claim = new Claim();
        claim.setApplication(applicationDao.getApplication(111, 0));
        claim.setFileNumber(claim.getApplication().getFileNumber());
        claim.setExtensionCounter(claim.getApplication().getExtensionCounter());
        claim.setClaimType(ClaimType.DECLARATION_OF_USE.getValue());
        claim.setClaimNumber(999);
        claim.setLanguage(1);
        claim.setClaimCode(99);

        claim.setForeignRegistrationNumber("1234567891012345678");

        claim.setClaimDate("12345678");
        claim.setClaimCountry("AA");
        claim.setCertifiedCopyInd(1);
        claim.setEvidenceFiledInd(1);
        return claim;
    }

}
