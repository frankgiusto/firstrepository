/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.OralHearingAttendeesDao;
import ca.gc.ic.cipo.tm.model.OppositionCaseId;
import ca.gc.ic.cipo.tm.model.OralHearingAttendees;
import junit.framework.TestCase;

/**
 * This class test the OralHearingAttendeesDaoTest
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OralHearingAttendeesDaoTest extends TestCase {

    @Autowired
    private OralHearingAttendeesDao oralHearingAttendeesDao;

    @Test
    @Transactional(readOnly = true)
    public void getOralHearingAttendeesTest() {

        OppositionCaseId oppositionCaseId = new OppositionCaseId();
        oppositionCaseId.setFileNumber(Integer.valueOf(1123342));
        oppositionCaseId.setExtensionCounter(Integer.valueOf(0));
        oppositionCaseId.setOppCaseNumber(Integer.valueOf(1));

        if (oralHearingAttendeesDao == null) {
            System.out.println("oralHearingAttendeesDao is NULL!!!");
        }
        Set<OralHearingAttendees> oralHearingAttendees = oralHearingAttendeesDao
            .getOralHearingAttendees(oppositionCaseId);
        assert (oralHearingAttendees.size() > 0);
        this.printData(oralHearingAttendees);

    }

    /**
     * Printing method
     *
     * @param Collection of Oral Hearing Attendees
     */
    private void printData(Set<OralHearingAttendees> oralHearingAttendeesSet) {

        System.out.println("Oral Hearing Attendees Data: ");
        System.out.println("================================");
        for (OralHearingAttendees oralHearingAttendees : oralHearingAttendeesSet) {

            // This will get the specific oral hearing attendees information
            System.out.println("Application Details: " + oralHearingAttendees.getApplication());
            System.out.println("Oral Hearing Attendees Name: " + oralHearingAttendees.getName());
            System.out.println("Oral Hearing Attendees Telephone Number: " + oralHearingAttendees.getTelephoneNumber());
            System.out.println("Oral Hearing Attendees Fax Number: " + oralHearingAttendees.getFaxNumber());
            System.out.println(
                "Oral Hearing Attendees Language of Preference: " + oralHearingAttendees.getLanguageOfPreference());
            System.out.println("Oral Hearing Attendees Simulataneous Trans Reqd Ind: "
                + oralHearingAttendees.getSimultaneousTransReqdInd());
            System.out
                .println("Oral Hearing Attendees Not Attending Ind: " + oralHearingAttendees.getNotAttendingInd());
            System.out.println("Oral Hearing Attendees Attendance Type: " + oralHearingAttendees.getAttendanceType());
            System.out.println(
                "Oral Hearing Attendees Juris Prudence Status: " + oralHearingAttendees.getJurisPrudenceStatus());
            System.out.println(
                "Oral Hearing Attendees Juris Prudence Sent Date : " + oralHearingAttendees.getJurisPrudenceSentDate());
            System.out.println("Oral Hearing Attendees Attendee Type: " + oralHearingAttendees.getAttendeeType());
            System.out.println("Oral Hearing Attendees IP Address: " + oralHearingAttendees.getIpAddress());

        }
    }

}
