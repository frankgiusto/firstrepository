package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.InterestedPartyRelationshipType;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationEmails;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ApplicationText;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.Authorities;
import ca.gc.ic.cipo.tm.model.Contact;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.FinancialTransactions;
import ca.gc.ic.cipo.tm.model.FittIdentifiers;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class ApplicationDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional(readOnly = true)
    public void getNextApplicationNumberTest() {

        Long applicationNumber = applicationDao.getNextApplicationNumber();

        assertTrue(applicationNumber != null);

    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void createApplicationTest() {

        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);

        applicationDao.saveApplication(application);

        Application savedApplication = applicationDao.getApplication(nextApplicationNumber, 0);
        Application detachedApplication = new Application();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(application, detachedApplication);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(savedApplication);

        assertTrue(savedApplication.getIrNumber().equals("1093502"));
        assertTrue(savedApplication.getIntlFilingRecordId().equals("1043968801"));
        assertEquals(detachedApplication, savedApplication);
    }

    // @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void copyMarkTest() {

        ApplicationNumber newApplicationNumber = applicationDao.copyMark(1912816, 0);

        Application savedApplication = applicationDao.getApplication(newApplicationNumber.getFileNumber(),
            newApplicationNumber.getExtensionCounter());

        assertTrue(savedApplication != null);

    }

    /**
     * @param savedApplication
     */
    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testDuplicateActions() {
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        List<Action> actions = buildDuplicatedActions(application);

        application.setActions(actions);
        Set<OppositionCase> oppositionCases = buildOppositionCasesWithDuplicates(application);
        application.setOppositionCases(oppositionCases);
        applicationDao.saveApplication(application);

        Application savedApplication = applicationDao.getApplication(nextApplicationNumber, 0);
        // TODO uncomment when code is fixed
        // Duplicate Action and Opposition Case Actions should be retrieved accurately

        assertEquals(2, savedApplication.getActions().size());

        for (OppositionCase oppositionCase : savedApplication.getOppositionCases()) {
            assertEquals(2, oppositionCase.getOppositionCaseActions().size());
        }
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getApplicationByIrNumberTest() {

        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);
        Application savedApplication = applicationDao.getApplication(nextApplicationNumber, 0);

        List<Application> applications = applicationDao.getApplicationByIrNumber(savedApplication.getIrNumber());

        assertTrue(!CollectionUtils.isEmpty(applications));

    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testGetApplicationsByClassificationRequiredIndRange() {

        final int numberOfApplication = 6;
        final int numberRangeApplication = 3;
        List<Application> savedApplications = createApplications(numberOfApplication);

        Collections.sort(savedApplications, new Comparator<Application>() {

            @Override
            public int compare(Application lhs, Application rhs) {
                // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                return lhs.getFileNumber() > rhs.getFileNumber() ? 1
                    : (lhs.getFileNumber() < rhs.getFileNumber()) ? -1 : 0;
            }
        });

        Application savedApplicationFirst = savedApplications.get(0);
        Application savedApplicationLast = savedApplications.get(savedApplications.size() - 1);

        Integer lowest = savedApplicationFirst.getFileNumber();
        Integer highest = savedApplicationLast.getFileNumber();

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        for (Application savedApplication : savedApplications) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(savedApplication);
        }
        try {
            List<Application> applications = applicationDao.getApplicationsByClassificationRequiredIndRange(
                savedApplicationFirst.getClassificationRequiredInd(), lowest, highest, null);

            assertTrue(!CollectionUtils.isEmpty(applications) && (applications.size() == numberOfApplication));

            applications = applicationDao.getApplicationsByClassificationRequiredIndRange(
                savedApplicationFirst.getClassificationRequiredInd(), lowest, null, null);
            assertTrue(!CollectionUtils.isEmpty(applications) && (applications.size() == numberOfApplication));

            applications = applicationDao.getApplicationsByClassificationRequiredIndRange(
                savedApplicationFirst.getClassificationRequiredInd(), lowest, null, 1);
            assertTrue(!CollectionUtils.isEmpty(applications) && (applications.size() == 1));

        } catch (Exception e) {
            System.out.println("-----Exception--testGetApplicationsByClassificationRequiredIndRange:" + e);
            assertTrue(false);
        }
    }

    private List<Application> createApplications(int numberOfApplicationTobeCreated) {
        List<Application> apps = new ArrayList<Application>();

        for (int number = 0; number < numberOfApplicationTobeCreated; number++) {
            Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
            Application savedApplication = createApplication(nextApplicationNumber);
            applicationDao.saveApplication(savedApplication);
            apps.add(savedApplication);
        }
        return apps;
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setMadridDesignationCategory(2);
        application.setRegistrabilityRecognizedInd(1);

        return application;
    }

    /**
     * @param application
     * @return
     */
    private Set<OppositionCase> buildOppositionCasesWithDuplicates(Application application) {
        Set<OppositionCase> oppositionCases = new HashSet<OppositionCase>();
        OppositionCase opposition = new OppositionCase();
        opposition.setFileNumber(application.getFileNumber());
        opposition.setExtensionCounter(application.getExtensionCounter());
        opposition.setOppCaseNumber(1);
        List<OppositionCaseAction> oppositionCaseActions = new ArrayList<>();
        OppositionCaseAction oppositionCaseAction1 = new OppositionCaseAction();
        OppositionCaseAction oppositionCaseAction2 = new OppositionCaseAction();
        oppositionCaseAction1.setFileNumber(application.getFileNumber());
        oppositionCaseAction1.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseAction2.setFileNumber(application.getFileNumber());
        oppositionCaseAction2.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseActions.add(oppositionCaseAction2);
        oppositionCaseActions.add(oppositionCaseAction1);
        opposition.setOppositionCaseActions(oppositionCaseActions);
        oppositionCases.add(opposition);
        return oppositionCases;
    }

    /**
     * @param application
     * @return
     */
    private List<Action> buildDuplicatedActions(Application application) {
        // Test that inserting 2 duplicated actions works correctly
        List<Action> actions = new ArrayList<Action>();
        Action action = new Action();
        action.setActionCode(1);
        action.setFileNumber(application.getFileNumber());
        action.setExtensionCounter(application.getExtensionCounter());
        action.setApplication(application);
        Date actionDate = new Date();
        action.setActionDate(actionDate);
        action.setAuthorityId("AAR");

        Action action2 = new Action();
        action2.setActionCode(1);
        action2.setFileNumber(application.getFileNumber());
        action2.setExtensionCounter(application.getExtensionCounter());
        action2.setApplication(application);
        action2.setActionDate(actionDate);
        action2.setAuthorityId("AAR");
        actions.add(action);
        actions.add(action2);
        return actions;
    }

    @Test
    @Transactional(readOnly = true)
    public void ApplicationTest() {
        // Get an application by application number

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(148256));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        Application application = applicationDao.getApplication(applicationNumber);

        // writeApplication();

        System.out.println("-------------- Application status code " + application.getStatusCode());
        assertTrue(application != null);

        // Get the application texts
        ApplicationNumber applicationTextNumber = new ApplicationNumber();
        applicationTextNumber.setFileNumber(Integer.valueOf(32696));
        applicationTextNumber.setExtensionCounter(Integer.valueOf(0));
        Set<ApplicationText> applicationTexts = application.getApplicationTexts();
        System.out.println("-------------- Application Texts: " + applicationTexts.size());
        for (ApplicationText applicationText : applicationTexts) {
            System.out.println("Application Text Type: " + applicationText.getTextType());
            System.out.println("Application Text Translation Status: " + applicationText.getTranslationStatus());

        }

        // Get the Interested Parties
        Set<InterestedParty> interestedParties = application.getInterestedParties();
        System.out.println("-------------- Interested Party count: " + interestedParties.size());
        for (InterestedParty interestedParty : interestedParties) {
            try {
                // Get Contact
                Contact contact = interestedParty.getContact();
                // Lookup for Primary Applicant (Owner)
                Boolean owner = interestedParty.getRelationshipType() == InterestedPartyRelationshipType.OWNER
                    .getValue();
                System.out.println("Contact Type: " + interestedParty.getCorrespondenceType() + " - Primary Applicant?("
                    + owner + ")" + " - Contact Name: " + contact.getName() + " - Organization?("
                    + interestedParty.getApplicantInd() + ")");

                AgentRepresentative ar = interestedParty.getRepresentative();
                System.out.println(ar.getContactName());

                // Get Contact -> Address
                // Address address = contact.getAddress();
                // System.out.println("---> Contact Address: ");
                // System.out.println(address.getAddress());
                // System.out.println("---> Contact Mailing Name Address: ");
                // System.out.println(address.getMailingNameAddress());
                // System.out.println("---> Contact address one line: ");
                // System.out.println(address.getOneLineAddress());
                // System.out.println("Country/Province & Postal Code");
                // System.out.println(address.getCountryProvince() + ", " +
                // address.getPostalCode());

                // // Phone Number
                System.out.println("Phone Number: " + contact.getPhoneNumber());
                // Fax Number
                System.out.println("Fax Number: " + contact.getFaxNumber());
                // Email Address
                System.out.println("Email Address: " + contact.getEmailAddress());
                // Reference Number
                System.out.println("Reference Number: " + interestedParty.getReference());
                // Attention To
                System.out.println("Attention To: " + interestedParty.getAttention());

                // // Representative
                //
                System.out.println(
                    "Interested Party Representative: " + interestedParty.getRepresentative().getContactName());
                System.out.println("Agent: " + interestedParty.getAgent().getContactName());
            } catch (Exception he) {
                System.out.println("--------------- Error: " + he.getMessage());
                continue;
            }
        }

        // // Get the Actions for this application
        // // List<Action> actions = actionDao.getActions(applicationNumber);
        // Collection<Action> actions = application.getActions();
        // for (Action action : actions) {
        // System.out.println("-------------- Action Code: "
        // + action.getActionCode() + " Date: "
        // + action.getActionDate());
        // }
        // List<ApplicationText> applicationTexts = application
        // .getApplicationTexts();
        // if (applicationTexts.isEmpty())
        // System.out.println("-------------- No Application Text for "
        // + application.getFileNumber());
        // for (ApplicationText entry : applicationTexts) {
        // System.out.println("-------------- Application Text: "
        // + entry.getText() + " - type: " + entry.getTextType());
        // }

    }

    /**
     * This test demonstrates the
     */
    @Test
    @Transactional
    public void testGetAllApplicationData() {
        ApplicationNumber applicationNumber = new ApplicationNumber(Integer.valueOf(148256), Integer.valueOf(0));
        Application application = applicationDao.getApplication(applicationNumber);

        this.printActions(application);
        this.printApplicationText(application);
        this.printFootNote(application);
        this.printGoodService(application);

        // print Authorities
        printAuthorities(109651, 0, "LACOMBES3");

        // print financial transactions data
        printFinancialTransactionsData(5205, 0);

        // print data correction actions logs
        printDataCorrectionActionsLogs(105430, 0);

        // print process actions data
        printProcessActionsData(162535, 0);

        // print FITT Identifiers data
        printFittIdentifiersData(1631750, 0);

        // print Assignment Amendment WorkSheet Files Data
        printAssignmentAmendmentWorkSheetFilesData(32696, 0);

        // print Email Jobs Data
        printEmailJobsData(1046116, 0);

        // print Application emails data
        printApplicationEmailsData(124661, 0);
    }

    /**
     * Printing methods
     *
     * @param application
     */
    private void printActions(Application application) {
        System.out.println("--------- ACTIONS");
        for (Action action : application.getActions()) {
            System.out.println("---> " + action.getActionCode());
        }
    }

    private void printApplicationText(Application application) {
        System.out.println("--------- APPLICATION TEXT");
        for (ApplicationText applicationText : application.getApplicationTexts()) {
            System.out.println("---> " + applicationText.getText());
        }
    }

    private void printFootNote(Application application) {
        System.out.println("--------- FOOT NOTES");
        for (Footnote footnote : application.getFootnotes()) {
            System.out.println("---> " + footnote.getText());
        }
    }

    private void printGoodService(Application application) {
        System.out.println("--------- GOODS AND SERVICES");
        for (GoodService goodService : application.getGoodsServices()) {
            System.out.println("---> " + goodService.getType());
            Set<GoodServiceText> gsts = goodService.getGoodServiceTexts();
            for (GoodServiceText gst : gsts) {
                System.out.println("GS Text: " + gst.getText());
            }
            assertTrue(gsts.size() > 0);
        }
    }

    private void printAuthorities(Integer fileNumber, Integer extensionCounter, String authorityId) {
        System.out.println("---------Application Authorities");
        List<Authorities> authorities = applicationDao.getAuthorities(fileNumber, extensionCounter, authorityId);

        System.out.println("Application Authorities Data: ");
        System.out.println("=============================");
        for (Authorities authority : authorities) {
            // This will get the specific aa work sheets information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            System.out.println("Authorities Authority Type: " + authority.getAuthorityType());

            System.out.println("Authorities Name: " + authority.getName());

            System.out.println("Authorities Username: " + authority.getUserName());

            System.out.println("Authorities Security Level Code: " + authority.getSecurityLevelCode());

            System.out.println("Authorities Language Of Preference: " + authority.getLanguageOfPreference());

            System.out.println("Authorities Section Authority ID: " + authority.getSectionAuthorityId());

            System.out.println("Authorities F Section Authority ID: " + authority.getfSectionAuthorityId());

            System.out.println("Authorities Default User Name: " + authority.getDefaultUserName());

            System.out.println("Authorities Parent User Name: " + authority.getParentUserName());

            System.out.println("Authorities VPN User: " + authority.getVpnUser());

            System.out.println("Authorities Electronic Signtaure: " + authority.getElectronicSignature());

            System.out.println("Authorities Printer Output Bin: " + authority.getPrinterOutputBin());

            System.out.println("Authorities Email Address: " + authority.getEmailAddress());

        }

    }

    /**
     * Printing method
     *
     * @param Collection of financial transactions
     */
    private void printFinancialTransactionsData(Integer fileNumber, Integer extensionCounter) {

        System.out.println("Financial Transactions Data: ");
        List<FinancialTransactions> financialTransactions = applicationDao.getFinancialTransactions(fileNumber,
            extensionCounter);
        for (FinancialTransactions transaction : financialTransactions) {
            // This will get the specific financial transaction information
            System.out.println("Application Details: " + transaction.getApplication());
            System.out.println("Financial Transactions Account Number: " + transaction.getAccountNumber());
            System.out.println("Financial Transactions Amount: " + transaction.getAmount());
            System.out.println("Financial Transactions Confirmation Number: " + transaction.getConfirmationNumber());
            System.out.println("Financial Transactions Extension Counter: " + transaction.getExtensionCounter());
            System.out.println("Financial Transactions Fee Type: " + transaction.getFeeType());
            System.out.println("Financial Transactions File Number: " + transaction.getFileNumber());
            System.out.println("Financial Transactions Payment Method: " + transaction.getPaymentMethod());
            System.out.println("Financial Transactions Payment Reference: " + transaction.getPaymentReference());
            System.out.println("Financial Transactions Print Date: " + transaction.getPrintDate());
            System.out.println("Financial Transactions Receive Date: " + transaction.getReceiveDate());
            System.out.println(
                "Financial Transactions Financial Transaction Number: " + transaction.getFinancialTransactionNumber());
            System.out.println("Financial Transactions AR Number: " + transaction.getArNumber());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Data Correction Action Logs
     */
    private void printDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter) {

        System.out.println("Data Correction Action Logs Data: ");
        System.out.println("================================");
        List<DataCorrectionActionsLog> dataCorrectionsActionsLogs = applicationDao
            .getDataCorrectionActionsLogs(fileNumber, extensionCounter);
        for (DataCorrectionActionsLog dataCorrectionsActionsLog : dataCorrectionsActionsLogs) {
            // This will get the specific financial transaction information
            System.out.println("Application Details: " + dataCorrectionsActionsLog.getApplication());
            System.out.println("Data Correction Actions Log Action Code: " + dataCorrectionsActionsLog.getActionCode());
            System.out.println("Data Correction Actions Log Action Date: " + dataCorrectionsActionsLog.getActionDate());
            System.out
                .println("Data Correction Actions Log Authority ID: " + dataCorrectionsActionsLog.getAuthorityId());
            System.out.println("Data Correction Actions Log Performed By Authority ID: "
                + dataCorrectionsActionsLog.getPerformedByAuthorityId());
            System.out
                .println("Data Correction Actions Log Response Date: " + dataCorrectionsActionsLog.getResponseDate());
            System.out.println(
                "Data Correction Actions Log Additional Information: " + dataCorrectionsActionsLog.getAdditionalInfo());
            System.out
                .println("Data Correction Actions Log Justification: " + dataCorrectionsActionsLog.getJustification());
            System.out.println("Data Correction Actions Log Data Correction Action Performed: "
                + dataCorrectionsActionsLog.getDataCorrectionActionPerformed());
            System.out.println("Data Correction Actions Log Data Correction Authority ID: "
                + dataCorrectionsActionsLog.getAuthorityId());
            System.out.println("Data Correction Actions Log Data Correction Date Performed: "
                + dataCorrectionsActionsLog.getDataCorrectionDatePerformed());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Process Actions
     */
    private void printProcessActionsData(Integer fileNumber, Integer extensionCounter) {

        System.out.println("Process Actions Data: ");
        System.out.println("================================");

        List<ProcessAction> processActionsList = applicationDao.getProcessActions(fileNumber, extensionCounter);
        for (ProcessAction processActions : processActionsList) {
            // This will get the specific process actions information
            System.out.println("Application Details: " + processActions.getApplication());
            System.out.println("Process Actions Process Type: " + processActions.getProcessType());
            System.out.println("Process Actions Process Code: " + processActions.getProcessCode());
            System.out.println("Process Actions Additional Info: " + processActions.getAdditionalInfo());
            System.out.println("Process Actions Alternate Mail To: " + processActions.getAlternateMailTo());
            System.out.println("Process Actions Authority ID: " + processActions.getAuthorityId());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of fittIdentifiers
     *
     */
    private void printFittIdentifiersData(Integer fileNumber, Integer extensionCounter) {

        System.out.println("FITT Identifiers Data: ");
        System.out.println("================================");

        List<FittIdentifiers> fittIdentifiersList = applicationDao.getFittIdentifiers(fileNumber, extensionCounter);

        for (FittIdentifiers fittIdentifiers : fittIdentifiersList) {
            // This will get the specific fitt Identifiers information
            System.out.println("Application Details: " + fittIdentifiers.getApplication());
            System.out.println("Fitt Identifiers File Type: " + fittIdentifiers.getFileType());
            System.out.println("Fitt Identifiers Mail Room Date: " + fittIdentifiers.getMailRoomDate());
            System.out.println("Fitt Identifiers Mail Room Date Days: " + fittIdentifiers.getMailRoomDateDays());
            System.out.println("Fitt Identifiers First Received Date: " + fittIdentifiers.getFirstReceivedDate());
            System.out.println("Fitt Identifiers MURID: " + fittIdentifiers.getMrUID());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of aa work sheet files
     */
    private void printAssignmentAmendmentWorkSheetFilesData(Integer fileNumber, Integer extensionCounter) {

        System.out.println("AA Work Sheet Files Data: ");
        System.out.println("=============================");

        List<AssignmentAmendmentWorkSheetFiles> aaWorkSheetFilesSet = applicationDao
            .getAssignmentAmendmentWorkSheetFiles(fileNumber, extensionCounter);

        for (AssignmentAmendmentWorkSheetFiles aaWorkSheetFiles : aaWorkSheetFilesSet) {
            // This will get the specific aa work sheet files information
            System.out.println("Application Details: " + aaWorkSheetFiles.getApplication());
            System.out.println("AA Work Sheet Files User Input Index: " + aaWorkSheetFiles.getUserInputIndex());
            System.out.println("AA Work Sheet Files Iteration Counter " + aaWorkSheetFiles.getIterationCounter());
            System.out.println("AA Work Sheet Files Work Sheet Number: " + aaWorkSheetFiles.getWorkSheetNumber());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Email Jobs
     */
    private void printEmailJobsData(Integer fileNumber, Integer extensionCounter) {

        System.out.println("Email Jobs Data: ");
        System.out.println("================================");

        List<EmailJobs> emailJobsList = applicationDao.getEmailJobs(fileNumber, extensionCounter);

        for (EmailJobs emailJobs : emailJobsList) {
            // This will get the specific email jobs information
            System.out.println("Doubtful Case Details: " + emailJobs.getApplication());
            System.out.println("Email Jobs File Number: " + emailJobs.getFileNumber());
            System.out.println("Email Jobs Extension Counter: " + emailJobs.getExtensionCounter());
            System.out.println("Email Jobs Email Job Number: " + emailJobs.getEmailJobNumber());
            System.out.println("Email Jobs AR Number " + emailJobs.getArNumber());
            System.out.println("Email Jobs Authority ID: " + emailJobs.getAuthorityId());
            System.out.println("Email Jobs Email Status Code: " + emailJobs.getEmailStatusCode());
            System.out.println("Email Jobs Email Job Type: " + emailJobs.getEmailJobType());
            System.out.println("Email Jobs Email Sent TimeStamp: " + emailJobs.getSentTimeStamp());
            System.out.println("Email Jobs Email Created TimeStamp: " + emailJobs.getCreatedTimeStamp());
            System.out.println("Email Jobs Email Modified TimeStamp: " + emailJobs.getModifiedTimeStamp());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Application Emails
     */
    private void printApplicationEmailsData(Integer fileNumber, Integer extensionCounter) {

        System.out.println("Application Emails Data: ");
        System.out.println("================================");

        List<ApplicationEmails> applicationEmailsList = applicationDao.getApplicationEmails(fileNumber,
            extensionCounter);

        for (ApplicationEmails applicationEmails : applicationEmailsList) {
            // This will get the specific application emails information
            System.out.println("Application Details: " + applicationEmails.getApplication());
            System.out.println("Aplication Emails File Number: " + applicationEmails.getFileNumber());
            System.out.println("Application Emails Extension Counter: " + applicationEmails.getExtensionCounter());
            System.out.println("Application Emails Email Sequence: " + applicationEmails.getEmailSeq());
            System.out.println("Application Emails Email Address " + applicationEmails.getEmailAddress());

        }
    }

    @Test
    @Transactional(readOnly = true)
    public void testForGetTrademarkApplicationByAgentNumber() {
        final Integer agentNumber = 6489;
        List<Application> applications = this.applicationDao.getTrademarkApplicationsByAgentNumber(agentNumber);
        Assert.assertNotNull("Check for not null", applications);
        Assert.assertTrue("Check for size", applications.size() > 0);
    }

}
