package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AgentUserXrefDao;
import ca.gc.ic.cipo.tm.model.AgentUserXref;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AgentUserXrefDaoTest extends TestCase {

    @Autowired
    private AgentUserXrefDao agentUserXrefDao;

    @Test
    @Transactional(readOnly = true)
    public void test() {
        // fail("Not yet implemented");

        AgentUserXref agentUserXref = new AgentUserXref();
        agentUserXref.setUserId("NicolasOuellet1");
        agentUserXref.setArNumber(10935);

        /*
         * List<AgentUserXref> agentUserXrefs = agentUserXrefDao.getAgentUserXrefs(agentUserXref.getUserId(),
         * agentUserXref.getArNumber());
         *
         * for (AgentUserXref agUserXref : agentUserXrefs) { System.out.println(agUserXref.getEmailAddress()); }
         */

    }

}
