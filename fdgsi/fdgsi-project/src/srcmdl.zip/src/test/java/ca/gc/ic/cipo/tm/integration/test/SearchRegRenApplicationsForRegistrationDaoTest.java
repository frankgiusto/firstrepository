package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.SearchRegRenApplicationsForRegistrationDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.RegfeedecuseAllowed;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
// @Ignore
public class SearchRegRenApplicationsForRegistrationDaoTest {

    @Autowired
    @Qualifier("searchRegRenApplicationsForRegistrationDao")
    private SearchRegRenApplicationsForRegistrationDao searchRegRenApplicationsForRegistrationDao;

    @Test
    public void testForSearchApplicatonWithApplicationNumberOnly() {
        final Integer fileNumber = 1569248;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber);
        // .addStartDate(createDate(2018, 3, 21)).addEndDate(createDate(2028, 3, 21));
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 1);

    }

    @Test
    public void testForSearchApplicationsWithNonExistingApplicationNumber() {
        // does not exist in DB
        final Integer fileNumber = 1720387123;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber);
        // .addStartDate(createDate(2018, 3, 21)).addEndDate(createDate(2028, 3, 21));
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 0);
    }

    @Test
    public void testForSearchApplcationsWithAllSearchCriteriaProvided() {
        final Integer fileNumber = 1720387;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addStartDate(createDate(2018, 3, 21))
            .addEndDate(createDate(2028, 3, 21)).addRequestorUserId("TSmartYYY").addApplicantName("toy")
            .addTrademarkName("canada");
        builder.addAgentNumbers(createAgentNumbersList());
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 0);
    }

    @Test
    public void testForSearchApplicationsUsingApplicant() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 3, 21)).addEndDate(createDate(2028, 3, 21))
            .addRequestorUserId("TSmartYYY").addApplicantName("Harvest");
        builder.addAgentNumbers(createAgentNumbersList());

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test
    public void testForSearchApplicationsUsingTrademark() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 3, 21)).addEndDate(createDate(2028, 3, 21))
            .addRequestorUserId("TSmartYYY").addTrademarkName("bread");
        builder.addAgentNumbers(createAgentNumbersList());

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test
    public void testForSearchApplicationsUsingDateFilter() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 3, 21)).addEndDate(createDate(2028, 3, 21))
            .addRequestorUserId("TSmartYYY");
        builder.addAgentNumbers(createAgentNumbersList());

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test(expected = RuntimeException.class)
    public void testForNoSearchCriteria() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<RegfeedecuseAllowed> results = searchRegRenApplicationsForRegistrationDao
            .searchApplicationsForRegistration(searchCriteria);
        Assert.assertTrue("Test for results size", results.size() == 0);
    }

    // Dates used to be mandatory, they are not anymore, not sure if this test is useful
    @Test(expected = RuntimeException.class)
    public void testForSearchWithNoDatesProvided() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        final Integer fileNumber = 562866;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        builder.addRequestorUserId("TSmartYYY").addApplicantName("bread").addApplicationNumber(applicationNumber);
        searchRegRenApplicationsForRegistrationDao.searchApplicationsForRegistration(builder.build());
    }

    private List<Integer> createAgentNumbersList() {
        List<Integer> agentNumbers = new ArrayList<>();
        agentNumbers.add(9681); /* TSmartYYY */
        return agentNumbers;
    }

    private Date createDate(int year, int month, int day) {
        Calendar gc = Calendar.getInstance();
        gc.set(year, month - 1, day, 0, 0);
        return gc.getTime();
    }
}
