/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Collection;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ApplicationEmailsDao;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationEmails;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import junit.framework.TestCase;

/**
 * This class tests the ApplicationEmailsDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class ApplicationEmailsDaoTest extends TestCase {

    @Autowired
    private ApplicationEmailsDao applicationEmailsDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void saveApplicationEmailsTest() {
        Application application = applicationDao.getApplication(111, 0);

        ApplicationEmails applicationEmails = buildValidApplicationEmail(application);
        Set<ApplicationEmails> retrievedApplicationEmailsSet;
        applicationEmailsDao.saveApplicationEmails(applicationEmails);
        retrievedApplicationEmailsSet = applicationEmailsDao.getApplicationEmails(application);
        assertNotNull(retrievedApplicationEmailsSet);
        assertEquals(1, retrievedApplicationEmailsSet.size());
        for (ApplicationEmails retrievedEmail : retrievedApplicationEmailsSet) {
            assertEquals(applicationEmails, retrievedEmail);
            // Should have a sequence set from database
            assertNotNull(retrievedEmail.getEmailSeq());
        }
    }

    private ApplicationEmails buildValidApplicationEmail(Application application) {
        ApplicationEmails applicationEmail = new ApplicationEmails();
        applicationEmail.setEmailAddress("test");
        applicationEmail.setExtensionCounter(application.getExtensionCounter());

        applicationEmail.setFileNumber(application.getFileNumber());
        return applicationEmail;
    }

    @Test
    @Transactional(readOnly = true)
    public void getApplicationEmailsTest() {

        /*
         * ApplicationNumber applicationNumber = new ApplicationNumber();
         * applicationNumber.setFileNumber(Integer.valueOf(148329));
         * applicationNumber.setExtensionCounter(Integer.valueOf(0));
         *
         * if (applicationEmailsDao == null) { System.out.println( "applicationEmailsDao is NULL!!!"); }
         * Set<ApplicationEmails> applicationEmailsList = applicationEmailsDao.getApplicationEmails(applicationNumber,
         * 2183100); assert (applicationEmailsList.size() > 0); this.printData(applicationEmailsList);
         */

    }

    /**
     * Printing method
     *
     * @param Collection of Application Emails
     */
    private void printData(Set<ApplicationEmails> applicationEmailsList) {

        System.out.println("Application Emails Data: ");
        System.out.println("================================");

        for (ApplicationEmails applicationEmails : applicationEmailsList) {
            // This will get the specific application emails information
            System.out.println("Application Details: " + applicationEmails.getApplication());
            System.out.println("Aplication Emails File Number: " + applicationEmails.getFileNumber());
            System.out.println("Application Emails Extension Counter: " + applicationEmails.getExtensionCounter());
            System.out.println("Application Emails Email Sequence: " + applicationEmails.getEmailSeq());
            System.out.println("Application Emails Email Address " + applicationEmails.getEmailAddress());

        }
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetApplicationEmailsIntegerInteger() {
        ApplicationEmails applicationEmail = buildApplicationEmail();
        Collection<ApplicationEmails> retrievedEmails = applicationEmailsDao
            .getApplicationEmails(applicationEmail.getFileNumber(), applicationEmail.getExtensionCounter());
        int i = retrievedEmails.size();

        applicationEmailsDao.saveApplicationEmails(applicationEmail);
        retrievedEmails = applicationEmailsDao.getApplicationEmails(applicationEmail.getFileNumber(),
            applicationEmail.getExtensionCounter());

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        ApplicationEmails retrievedEmail = retrievedEmails.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedEmail);
        assertEquals(i + 1, retrievedEmails.size());
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetApplicationEmailsApplicationNumber() {
        ApplicationEmails applicationEmail = buildApplicationEmail();
        Collection<ApplicationEmails> retrievedEmails = applicationEmailsDao.getApplicationEmails(
            new ApplicationNumber(applicationEmail.getFileNumber(), applicationEmail.getExtensionCounter()));
        int i = retrievedEmails.size();

        applicationEmailsDao.saveApplicationEmails(applicationEmail);
        retrievedEmails = applicationEmailsDao.getApplicationEmails(
            new ApplicationNumber(applicationEmail.getFileNumber(), applicationEmail.getExtensionCounter()));

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        ApplicationEmails retrievedEmail = retrievedEmails.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedEmail);
        assertEquals(i + 1, retrievedEmails.size());
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetApplicationEmailsApplicationNumberInteger() {
        ApplicationEmails applicationEmail = buildApplicationEmail();
        applicationEmailsDao.saveApplicationEmails(applicationEmail);
        ApplicationEmails detachedApplicationEmail = new ApplicationEmails();
        ApplicationNumber applicationNumber = new ApplicationNumber(applicationEmail.getFileNumber(),
            applicationEmail.getExtensionCounter());
        Collection<ApplicationEmails> retrievedEmails = applicationEmailsDao.getApplicationEmails(applicationNumber,
            applicationEmail.getEmailSeq());
        // Need to do a copy since Hibernate sets applicationEmail and savedApplication to the same instance...
        BeanUtils.copyProperties(applicationEmail, detachedApplicationEmail);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedEmails.size());

        ApplicationEmails retrievedEmail = retrievedEmails.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedEmail);
        assertEquals(detachedApplicationEmail, retrievedEmail);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetApplicationEmailsApplicationNumberApplicationEmailsId() {
        ApplicationEmails applicationEmail = buildApplicationEmail();
        applicationEmailsDao.saveApplicationEmails(applicationEmail);
        ApplicationEmails detachedApplicationEmail = new ApplicationEmails();
        Collection<ApplicationEmails> retrievedEmails = applicationEmailsDao.getApplicationEmails(applicationEmail,
            applicationEmail);
        // Need to do a copy since Hibernate sets applicationEmail and savedApplication to the same instance...
        BeanUtils.copyProperties(applicationEmail, detachedApplicationEmail);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedEmails.size());

        ApplicationEmails retrievedEmail = retrievedEmails.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedEmail);
        assertEquals(detachedApplicationEmail, retrievedEmail);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testSaveApplicationEmails() {
        ApplicationEmails applicationEmail = buildApplicationEmail();
        applicationEmailsDao.saveApplicationEmails(applicationEmail);
        ApplicationEmails detachedApplicationEmail = new ApplicationEmails();
        Collection<ApplicationEmails> retrievedEmails = applicationEmailsDao.getApplicationEmails(applicationEmail,
            applicationEmail);
        // Need to do a copy since Hibernate sets applicationEmail and savedApplication to the same instance...
        BeanUtils.copyProperties(applicationEmail, detachedApplicationEmail);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedEmails.size());

        ApplicationEmails retrievedEmail = retrievedEmails.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedEmail);
        assertEquals(detachedApplicationEmail, retrievedEmail);
    }

    /**
     * @return
     */
    private ApplicationEmails buildApplicationEmail() {
        ApplicationEmails applicationEmail = new ApplicationEmails();
        applicationEmail.setFileNumber(111);
        applicationEmail.setExtensionCounter(0);
        applicationEmail.setEmailAddress(
            "mailemailemailemailemailemail@emailemailemailemailemailemailemailemailemailemailemailemailemail.comm");
        return applicationEmail;
    }

}
