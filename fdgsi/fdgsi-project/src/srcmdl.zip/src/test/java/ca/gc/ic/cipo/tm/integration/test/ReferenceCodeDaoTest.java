package ca.gc.ic.cipo.tm.integration.test;

import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ReferenceCodeDao;
import ca.gc.ic.cipo.tm.model.ReferenceCode;
import ca.gc.ic.cipo.tm.type.LanguageType;
import ca.gc.ic.cipo.tm.type.ReferenceCodeType;
import ca.gc.ic.cipo.tm.type.TradeMarkStatusType;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class ReferenceCodeDaoTest extends TestCase {

    @Autowired
    private ReferenceCodeDao referenceCodeDao;

    @Autowired
    @Qualifier("frenchReferenceCodeDao")
    private ReferenceCodeDao frenchReferenceCodeDao;

    @Autowired
    @Qualifier("englishReferenceCodeDao")
    private ReferenceCodeDao englishReferenceCodeDao;

    // This test will retrieve the application status English description for the status code expunged.
    @Test
    @Transactional(readOnly = true)
    public void test() {
        ReferenceCode referenceCode = referenceCodeDao.getCode(ReferenceCodeType.STATUS_TRADEMARK,
            TradeMarkStatusType.EXPUNGED, LanguageType.ENGLISH);
        System.out.println("Reference code: " + referenceCode.getDescription());
    }

    // This test will retrieve the application status description for all the language in the database for the status
    // code EXPUNGED.
    @Test
    @Transactional(readOnly = true)
    public void getCodesByCodeAndType() {
        List<ReferenceCode> referenceCodes = referenceCodeDao.listCodesByTypeAndCode(ReferenceCodeType.STATUS_TRADEMARK,
            TradeMarkStatusType.EXPUNGED);
        for (ReferenceCode referenceCode : referenceCodes) {
            System.out.println(
                "Reference Code Language: " + referenceCode.getLanguage() + " - " + referenceCode.getDescription());
        }
    }

    /**
     * This will test the convenience method to get a Set of Reference table for all languages
     */
    @Test
    @Transactional(readOnly = true)
    public void callConvenienceMethodsAllLanguages() {
        List<ReferenceCode> referenceCodes = referenceCodeDao.getActions();
        // System.out.println("----------- Action codes count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = referenceCodeDao.getClaimTypes();
        // System.out.println("----------- Claim type count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = referenceCodeDao.getGoodsAndServices();
        // System.out.println("----------- Goods and Services count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = referenceCodeDao.getTrademarkType();
        // System.out.println("----------- Trademark type count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);
    }

    /**
     * This will test the convenience method to get a Set of Reference table with French Only description
     */
    @Test
    @Transactional(readOnly = true)
    public void callConvenienceMethodsInFrench() {
        List<ReferenceCode> referenceCodes = frenchReferenceCodeDao.getActions();
        // System.out.println("----------- Action codes count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = frenchReferenceCodeDao.getClaimTypes();
        // System.out.println("----------- Claim type count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = frenchReferenceCodeDao.getGoodsAndServices();
        // System.out.println("----------- Goods and Services count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = frenchReferenceCodeDao.getTrademarkType();
        // System.out.println("----------- Trademark type count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);
    }

    /**
     * This will test the convenience method to get a Set of Reference table with English Only description
     */
    @Test
    @Transactional(readOnly = true)
    public void callConvenienceMethodsInEnglish() {
        List<ReferenceCode> referenceCodes = englishReferenceCodeDao.getActions();
        // System.out.println("----------- Action codes count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = englishReferenceCodeDao.getClaimTypes();
        // System.out.println("----------- Claim type count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = englishReferenceCodeDao.getGoodsAndServices();
        // System.out.println("----------- Goods and Services count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);

        referenceCodes = englishReferenceCodeDao.getTrademarkType();
        // System.out.println("----------- Trademark type count: " + referenceCodes.size());
        // this.printReferenceCodes(referenceCodes);
        assertTrue(referenceCodes.size() > 0);
    }

    @SuppressWarnings("unused")
    private void printReferenceCodes(List<ReferenceCode> referenceCodes) {
        for (ReferenceCode referenceCode : referenceCodes) {
            try {
                System.out.println(
                    "Code: " + referenceCode.getCode() + " - Type: " + referenceCode.getCodeType() + " - Language: "
                        + referenceCode.getLanguage() + " - Description: " + referenceCode.getDescription());
            } catch (Exception e) {
                continue;
            }
        }
    }

    // This test was used to create all the static constant for the Reference Code.
    // @Test
    @Transactional(readOnly = true)
    public void referenceByLanguage() {
        List<ReferenceCode> referenceCodes = referenceCodeDao.listCodesByType(Integer.valueOf(0), Integer.valueOf(1));
        Collections.sort(referenceCodes, new ReferenceCodeComparator());
        for (ReferenceCode rc : referenceCodes) {
            System.out.println("public static final Integer " + this.getConstantText(rc.getDescription()) + " = "
                + rc.getCode() + ";");
        }
    }

    private String getConstantText(String text) {
        text = text.replace("/", "");
        text = text.replace("(", "");
        text = text.replace(")", "");
        text = text.replace("-", "");
        text = text.replace(" ", "_");
        return text.toUpperCase();
    }

}
