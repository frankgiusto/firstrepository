package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class MadridApplicationActionDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private MadridApplicationActionDao madridApplicationActionDao;

    private static Integer MADRID_APPLICATION_PENDING = 1;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void saveMadridApplicationActionTest() {
        String testWipReferenceNumber = "FG-77777";

        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber("99999FG");
        madridApplication.setWipoReferenceNumber(testWipReferenceNumber);
        madridApplication.setStatusCode(MADRID_APPLICATION_PENDING);
        madridApplicationDao.saveMadridApplication(madridApplication);

        List<MadridApplicationAction> actionList = madridApplicationActionDao
            .getMadridApplicationActionByReferenceNumber(testWipReferenceNumber);
        int numberOfActionPriorToSave = actionList != null ? actionList.size() : 0;

        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setActionCode(1);
        madridApplicationAction.setActionDate(new Date());
        madridApplicationAction.setAdditionalInfo("Test1");
        madridApplicationAction.setAuthorityId("GIUSTOF1");
        madridApplicationAction.setWipoReferenceNumber(testWipReferenceNumber);
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationAction.setMadridApplicationActionsSeqNumber(madridApplicationActionId);
        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);

        actionList = madridApplicationActionDao.getMadridApplicationActionByReferenceNumber(testWipReferenceNumber);
        int numberOfActionAfterSave = actionList != null ? actionList.size() : 0;

        Assert.assertTrue(
            "Error: Number of MadridApplicationAction is not correct after save. MadridApplicationAction might have not saved.",
            numberOfActionAfterSave > numberOfActionPriorToSave);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getMadridApplicationActionByReferenceNumberTest() {
        String testWipReferenceNumber = "FG-77777";

        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Madrid Application
        MadridApplication madridApplication = new MadridApplication();
        madridApplication.setIrNumber("99999FG");
        madridApplication.setWipoReferenceNumber(testWipReferenceNumber);
        madridApplication.setStatusCode(MADRID_APPLICATION_PENDING);
        madridApplicationDao.saveMadridApplication(madridApplication);

        List<MadridApplicationAction> actionList = madridApplicationActionDao
            .getMadridApplicationActionByReferenceNumber(testWipReferenceNumber);
        int numberOfActionPriorToSave = actionList != null ? actionList.size() : 0;

        MadridApplicationAction madridApplicationAction = new MadridApplicationAction();
        madridApplicationAction.setActionCode(1);
        madridApplicationAction.setActionDate(new Date());
        madridApplicationAction.setAdditionalInfo("Test1");
        madridApplicationAction.setAuthorityId("GIUSTOF1");
        madridApplicationAction.setWipoReferenceNumber(testWipReferenceNumber);
        Long madridApplicationActionId = madridApplicationActionDao.getNextMadridApplicationActionNumber();
        madridApplicationAction.setMadridApplicationActionsSeqNumber(madridApplicationActionId);
        madridApplicationActionDao.saveMadridApplicationAction(madridApplicationAction);

        actionList = madridApplicationActionDao.getMadridApplicationActionByReferenceNumber(testWipReferenceNumber);
        int numberOfActionAfterSave = actionList != null ? actionList.size() : 0;

        Assert.assertTrue("Error: Number of MadridApplicationAction does not match with expected number",
            numberOfActionAfterSave > numberOfActionPriorToSave);
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(1);
        return application;
    }

}
