/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.DataCorrectionActionsLogDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import junit.framework.TestCase;

/**
 * This class test the DataCorrectionActionsLogDao
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class DataCorrectionActionsLogDaoTest extends TestCase {

    @Autowired
    private DataCorrectionActionsLogDao dataCorrectionActionsLogDao;

    @Test
    @Transactional(readOnly = true)
    public void getProcessActionsTest() {

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(105430));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        if (dataCorrectionActionsLogDao == null) {
            System.out.println("dataCorrectionActionsLogDao is NULL!!!");
        }
        Set<DataCorrectionActionsLog> dataCorrectionActionsLogs = dataCorrectionActionsLogDao
            .getDataCorrectionActionsLogs(applicationNumber);
        assert (dataCorrectionActionsLogs.size() > 0);
        this.printData(dataCorrectionActionsLogs);

    }

    /**
     * Printing method
     *
     * @param Collection of Data Correction Action Logs
     */
    private void printData(Set<DataCorrectionActionsLog> dataCorrectionsActionsLogs) {

        System.out.println("Data Correction Action Logs Data: ");
        System.out.println("================================");
        for (DataCorrectionActionsLog dataCorrectionsActionsLog : dataCorrectionsActionsLogs) {
            // This will get the specific financial transaction information
            System.out.println("Application Details: " + dataCorrectionsActionsLog.getApplication());
            System.out.println("Data Correction Actions Log Action Code: " + dataCorrectionsActionsLog.getActionCode());
            System.out.println("Data Correction Actions Log Action Date: " + dataCorrectionsActionsLog.getActionDate());
            System.out
                .println("Data Correction Actions Log Authority ID: " + dataCorrectionsActionsLog.getAuthorityId());
            System.out.println("Data Correction Actions Log Performed By Authority ID: "
                + dataCorrectionsActionsLog.getPerformedByAuthorityId());
            System.out
                .println("Data Correction Actions Log Response Date: " + dataCorrectionsActionsLog.getResponseDate());
            System.out.println(
                "Data Correction Actions Log Additional Information: " + dataCorrectionsActionsLog.getAdditionalInfo());
            System.out
                .println("Data Correction Actions Log Justification: " + dataCorrectionsActionsLog.getJustification());
            System.out.println("Data Correction Actions Log Data Correction Action Performed: "
                + dataCorrectionsActionsLog.getDataCorrectionActionPerformed());
            System.out.println("Data Correction Actions Log Data Correction Authority ID: "
                + dataCorrectionsActionsLog.getAuthorityId());
            System.out.println("Data Correction Actions Log Data Correction Date Performed: "
                + dataCorrectionsActionsLog.getDataCorrectionDatePerformed());

        }
    }
}
