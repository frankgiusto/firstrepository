package ca.gc.ic.cipo.tm.integration.test;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.TransactionInboxAttachmentDao;
import ca.gc.ic.cipo.tm.dao.TransactionInboxDao;
import ca.gc.ic.cipo.tm.model.TransactionInbox;
import ca.gc.ic.cipo.tm.model.TransactionInboxAttachment;
import junit.framework.TestCase;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional
public class TransactionDaoTest extends TestCase {
	
	@Autowired
	private TransactionInboxDao transactionInboxDao;
	
	@Autowired
	private TransactionInboxAttachmentDao transactionInboxAttachmentDao;
	

	//@Test
	@Transactional(readOnly = true)
	public void TransactionInboxFetchTest() {
	
	    int transactionSeqNumber= 100;
	    //todo: uncomment the code below to test TransactionInboxDao retrieval 
//	    TransactionInbox transactionItem = transactionInboxDao.getTransactionItem(transactionSeqNumber);
//		System.out.println("-------------- Application file number is: " + transactionItem.getFileNumber());
//		assertTrue(transactionItem != null);			
	}
	
	@Test
	@Transactional(readOnly = true)
	public void InboxAttachmentFetchTest() {
	    int inboxAttachmentSeqNumber= 1;
	    //todo: uncomment the code below to test TransactionInboxAttachmentDao retrieval 
//		TransactionInboxAttachment inboxAttachment = transactionInboxAttachmentDao.getTransactionAttachment(inboxAttachmentSeqNumber);
//		Blob attachmentBlob = inboxAttachment.getAttachmentFileBlob();
//		System.out.println("-------------- Inbox attachment file name is: " + inboxAttachment.getAttachmentFileName());
//		System.out.println("-------------- Inbox attachment file blob is: " + inboxAttachment.getAttachmentFileBlob());
//		byte[] content = null;
//        if (attachmentBlob != null) {
//            try {
//                content = attachmentBlob.getBytes(1, (int) attachmentBlob.length());
//            } catch (SQLException ex) { 
//            	ex.printStackTrace();
//            }
//        }
//        //assertTrue(transactionItem != null);	
//        BufferedOutputStream bos= null;
//        try{
//        FileOutputStream fos = new FileOutputStream(new File("C:\\test\\ws\\attachTest"));
//        bos = new BufferedOutputStream(fos);
//        bos.write(content);      
//        bos.flush();
//    	} catch (IOException e) {
//    		e.printStackTrace();
//    	}finally{
//    		if(bos!=null){
//    			try {
//            	bos.close();
//	            } catch (IOException e) {
//	                e.printStackTrace();}
//	         	}
//    	}
	}
}
