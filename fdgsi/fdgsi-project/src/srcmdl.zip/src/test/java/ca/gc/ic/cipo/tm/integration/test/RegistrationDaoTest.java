package ca.gc.ic.cipo.tm.integration.test;

import java.sql.Blob;
import java.sql.SQLException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.RegistrationDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class RegistrationDaoTest extends TestCase {

    @Autowired
    private RegistrationDao registrationDao;

    @Test
    public void dummyTestToMakeBuildPass() {
        Assert.assertNotNull("Please remove me after fixing");
    }

    // @Test
    // @Transactional(readOnly = true)
    public void getRegistrationDocuments() {
        // Get the registration document.
        Blob registrationDoc = registrationDao.getRegistrationPageForRegistration(1817631, 0, 6339786);
        try {
            assert (registrationDoc != null);
            try {
                assert (registrationDoc.length() >= 0);
                System.out.println("The Registration document was retrieved successfully. Size "
                    + registrationDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Registration document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Registration document is <null>. " + e.getMessage());
        } // End try, catch.

        // Get the registration certificate document.
        Blob registrationCertificateDoc = registrationDao.getRegistrationCertificate(1817631, 0, 6339786);
        try {
            assert (registrationCertificateDoc != null);
            try {
                assert (registrationCertificateDoc.length() > 0);
                System.out.println("The Registration certificate document was retrieved successfully. Size "
                    + registrationCertificateDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Registration Certificate document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Registration Certificate document is <null>. " + e.getMessage());
        } // End try, catch.

        // Get the declaration of use document.
        Blob declarationOfUseDoc = registrationDao.getDeclarationOfUse(1817631, 0, 6339786);
        try {
            assert (declarationOfUseDoc != null);
            try {
                assert (declarationOfUseDoc.length() > 0);
                System.out.println("The Declaration of Use document was retrieved successfully. Size "
                    + declarationOfUseDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Declaration of Use document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Declaration of Use document is <null>. " + e.getMessage());
        } // End try, catch.

        // Get the extension of time document.
        Blob extensionOfTimeDoc = registrationDao.getExtensionOfTime(1261510, 0, 2380023);
        try {
            assert (extensionOfTimeDoc != null);
            try {
                assert (extensionOfTimeDoc.length() > 0);
                System.out.println("The Extension of Time document was retrieved successfully. Size "
                    + extensionOfTimeDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Extension of Time document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Extension of Time document is <null>. " + e.getMessage());
        } // End try, catch.

        // Get the renewal certificate document.
        Blob renewalCertificateDoc = registrationDao.getRenewalCertificate(498810, 0, 4323600);
        try {
            assert (renewalCertificateDoc != null);
            try {
                assert (renewalCertificateDoc.length() > 0);
                System.out.println("The Renewal Certificate document was retrieved successfully. Size "
                    + renewalCertificateDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Renewal Certificate document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Renewal Certificate document is <null>. " + e.getMessage());
        } // End try, catch.

        // Get the registration page document.
        Blob registrationPageDoc = registrationDao.getRegistrationPageForRegistration(498810, 0, 4323600);
        try {
            assert (renewalCertificateDoc != null);
            try {
                assert (registrationPageDoc.length() > 0);
                System.out.println("Registration Page document was retrieved successfully. Size "
                    + registrationPageDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Registration Page document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Registration Page document is <null>. " + e.getMessage());
        } // End try, catch.

        // Get the acknowledgment notice document.
        Blob acknowledgementNoticeDoc = registrationDao.getAcknowledgementNotice(498810, 0, 4323600);
        try {
            assert (acknowledgementNoticeDoc != null);
            try {
                assert (acknowledgementNoticeDoc.length() > 0);
                System.out.println("The Acknowledgment Notice document was retrieved successfully. Size "
                    + acknowledgementNoticeDoc.length() + " bytes");
            } catch (SQLException e) {
                System.out.println("The Acknowledgment Notice document has 0 length data. " + e.getMessage());
            } // End try, catch.
        } catch (Exception e) {
            System.out.println("The Acknowledgment Notice document is <null>. " + e.getMessage());
        } // End try, catch.
    } // End of the getRegistrationDocuments method.

    @Test
    @Transactional(readOnly = true)
    // TODO revist this test
    public void isRegistrationExistsInTrademark() {
        ApplicationNumber applicationNumber = new ApplicationNumber(1840490, 0);
        boolean exists = registrationDao.isRegistrationExistsInTrademark(applicationNumber);
        Assert.assertFalse(exists);
    }

} // End of the RegistrationDaoTest class.
