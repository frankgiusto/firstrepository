package ca.gc.ic.cipo.tm.integration.test;

import java.io.InputStream;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import ca.gc.ic.cipo.util.cipher.PropertiesFileCipherUtility;

@Configuration
@EnableTransactionManagement
@ComponentScan("ca.gc.ic.cipo.tm.dao.*")
public class JunitConfig {

    @Bean
    public DataSource dataSource() {
        InputStream input = JunitConfig.class.getClassLoader().getResourceAsStream("database.properties");
        Properties properties = PropertiesFileCipherUtility.getProperties(input);
        // Decrypt the properties
        properties = PropertiesFileCipherUtility.decrypt(properties);

        DriverManagerDataSource dmds = new DriverManagerDataSource();

        dmds.setDriverClassName(properties.getProperty("jdbc.driverClassName"));
        dmds.setUrl(properties.getProperty("jdbc.url"));
        dmds.setUsername(properties.getProperty("jdbc.username"));
        dmds.setPassword(properties.getProperty("jdbc.password"));

        return dmds;
    }

    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setMappingResources(mappingResources());
        sessionFactory.setHibernateProperties(hibernateProperties());
        return sessionFactory;
    }

    @Bean
    public HibernateTransactionManager transactionManager(SessionFactory sessionFactory) {
        HibernateTransactionManager hibernateTransactionManager = new HibernateTransactionManager();
        hibernateTransactionManager.setSessionFactory(sessionFactory);
        return hibernateTransactionManager;
    }

    private Properties hibernateProperties() {
        Properties hibernateProperties = new Properties();
        hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
        hibernateProperties.setProperty("hibernate.show_sql", "false");
        hibernateProperties.setProperty("hibernate.format_sql", "false");
        hibernateProperties.setProperty("hibernate.default_schema", "TM");
        return hibernateProperties;
    }

    private String[] mappingResources() {
        String[] mappingResources = {"/mapping/AatIp.hbm.xml", "/mapping/AaTransaction.hbm.xml",
            "/mapping/Action.hbm.xml", "/mapping/AgentRepresentative.hbm.xml", "/mapping/Application.hbm.xml",
            "/mapping/ApplicationText.hbm.xml", "/mapping/AssociatedMark.hbm.xml", "/mapping/Claim.hbm.xml",
            "/mapping/ClaimText.hbm.xml", "/mapping/CountryProvince.hbm.xml", "/mapping/DoubtfulCase.hbm.xml",
            "/mapping/DocumentStored.hbm.xml", "/mapping/FigurativeElement.hbm.xml", "/mapping/Footnotes.hbm.xml",
            "/mapping/IndexHeading.hbm.xml", "/mapping/InterestedParty.hbm.xml", "/mapping/MadridApplications.hbm.xml",
            "/mapping/MadridApplicationActions.hbm.xml", "/mapping/MadridApplicationsXref.hbm.xml",
            "/mapping/Mail.hbm.xml", "/mapping/NiceReference.hbm.xml", "/mapping/OppositionCase.hbm.xml",
            "/mapping/OppositionCaseAction.hbm.xml", "/mapping/OppositionIp.hbm.xml",
            "/mapping/OppositionReportNote.hbm.xml", "/mapping/ReferenceCode.hbm.xml", "/mapping/ReferenceText.hbm.xml",
            "/mapping/TradeMark.hbm.xml", "/mapping/TrademarkType.hbm.xml", "/mapping/ViennaClassificationCode.hbm.xml",
            "/mapping/GoodService.hbm.xml", "/mapping/GoodServiceText.hbm.xml", "/mapping/GoodServiceClaim.hbm.xml",
            "/mapping/GoodServiceClassification.hbm.xml", "/mapping/TransactionInbox.hbm.xml",
            "/mapping/TransactionInboxAttachment.hbm.xml", "/mapping/FinancialTransactions.hbm.xml",
            "/mapping/DataCorrectionActionsLog.hbm.xml", "/mapping/ProcessActions.hbm.xml",
            "/mapping/FittIdentifiers.hbm.xml", "/mapping/AAWorkSheetFiles.hbm.xml",
            "/mapping/OralHearingAttendees.hbm.xml", "/mapping/OralHearingDetails.hbm.xml",
            "/mapping/AAWorkSheets.hbm.xml", "/mapping/Authorities.hbm.xml", "/mapping/PullingLists.hbm.xml",
            "/mapping/CurrentFileActions.hbm.xml", "/mapping/PhysicalFiles.hbm.xml", "/mapping/EmailJobs.hbm.xml",
            "/mapping/PdfFiles.hbm.xml", "/mapping/ApplicationEmails.hbm.xml", "/mapping/HistoricalFileActions.hbm.xml",
            "/mapping/AgentRepresentativeActions.hbm.xml", "/mapping/FittIdentifiersAgentsRepresentatives.hbm.xml",
            "/mapping/InterestedPartiesAddresses.hbm.xml", "/mapping/AgentUserXref.hbm.xml",
            "/mapping/GiTranslation.hbm.xml", "/mapping/TransactionTypeFilePrefix.hbm.xml",
            "/mapping/EcRegistration.hbm.xml", "/mapping/RegfeedecuseHistory.hbm.xml", "/mapping/EcExtoftime.hbm.xml",
            "/mapping/WebTransactions.hbm.xml", "/mapping/OppositionGrounds.hbm.xml",
            "/mapping/RegistrationRenewalWeb.hbm.xml", "/mapping/CitedLinks.hbm.xml",
            "/mapping/OppositionCitedMarks.hbm.xml", "/mapping/OppositionGroundsSubsection.hbm.xml",
            "/mapping/RegfeedecuseAllowed.hbm.xml", "/mapping/TradeMarkLock.hbm.xml"

        };
        return mappingResources;
    }

}
