package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.dao.ClaimTextDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesDao;
import ca.gc.ic.cipo.tm.enumerator.ClaimType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.ClaimText;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class GoodsServicesDaoTest extends TestCase {

    @Autowired
    ApplicationDao applicationDao;

    @Autowired
    private GoodsServicesDao goodsServicesDao;

    @Autowired
    private GoodsServicesClaimDao goodsServicesClaimDao;

    @Autowired
    private ClaimDao claimDao;

    @Autowired
    private ClaimTextDao claimTextDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional
    public void GoodsServicesTest() {
        Integer fileNumber = Integer.valueOf(11799);
        Integer extensionNumber = Integer.valueOf(0);
        ApplicationNumber applicationNumber = new ApplicationNumber(fileNumber, extensionNumber);

        List<GoodService> goodServices = goodsServicesDao.getGoodService(applicationNumber);
        for (GoodService goodService : goodServices) {
            System.out.println(
                "For Good Service: " + goodService.getFileNumber() + " - " + goodService.getExtensionCounter());
            printGoodServiceText(goodService.getGoodServiceTexts());
            printGoodServiceClaims(goodService.getGoodServiceClaims());
        }

    }

    private void printGoodServiceText(Set<GoodServiceText> goodServiceTexts) {
        for (GoodServiceText goodServiceText : goodServiceTexts) {
            System.out.println("---- > Good Service Text: " + goodServiceText.getText());
        }
    }

    private void printGoodServiceClaims(Set<GoodServiceClaim> goodServiceClaims) {
        for (GoodServiceClaim goodServiceClaim : goodServiceClaims) {
            System.out.println("---- > Good Service Claim: " + goodServiceClaim);
        }
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void saveLongTextSave() {
        List<GoodService> gs = goodsServicesDao.getGoodService(new ApplicationNumber(1418750, 0));
        GoodServiceText expectedGsText = null;
        for (GoodService goodService : gs) {
            if (goodService.getNumber() == 10) {
                for (GoodServiceText goodServiceText : goodService.getGoodServiceTexts()) {
                    expectedGsText = new GoodServiceText();
                    expectedGsText.setFileNumber(goodService.getFileNumber());
                    expectedGsText.setExtensionCounter(goodService.getExtensionCounter());
                    expectedGsText.setType(goodService.getType());
                    expectedGsText.setNumber(goodService.getNumber());
                    expectedGsText.setOriginalInd(2);
                    expectedGsText.setText(goodServiceText.getText() + "longer");
                    expectedGsText.setPickListInd(1);
                    expectedGsText.setModifiedTimestamp(new Date());
                    expectedGsText.setLanguage(1);
                    goodService.getGoodServiceTexts().add(expectedGsText);
                    goodsServicesDao.saveGoodsServices(goodService);
                    break;
                }

            }
        }
        List<GoodService> foundGS = goodsServicesDao.getGoodService(new ApplicationNumber(1418750, 0));
        GoodServiceText detachedExpectedText = new GoodServiceText();
        BeanUtils.copyProperties(expectedGsText, detachedExpectedText);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        for (GoodService goodService : foundGS) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(goodService);

            if (goodService.getNumber() == 10) {
                for (GoodServiceText goodServiceText : goodService.getGoodServiceTexts()) {
                    transactionManager.getSessionFactory().getCurrentSession().refresh(goodServiceText);

                    if (goodServiceText.getPickListInd() == 1) {
                        // TODO modifiedTimestamp is retrieved as truncated date instead of timestamp, uncomment below
                        // when fixed
                        goodServiceText.setModifiedTimestamp(detachedExpectedText.getModifiedTimestamp());
                        assertEquals(detachedExpectedText, goodServiceText);
                    }
                }

            }
        }

    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetGoodServiceApplicationNumber() {

        GoodService goodService = buildGoodService();
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(goodService.getApplication().getFileNumber());
        applicationNumber.setExtensionCounter(0);

        List<GoodService> retGoodServices = goodsServicesDao.getGoodService(applicationNumber);
        int i = retGoodServices.size();

        goodsServicesDao.saveGoodsServices(goodService);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        transactionManager.getSessionFactory().getCurrentSession().refresh(goodService.getApplication());

        for (GoodService goodService2 : retGoodServices) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(goodService2);
        }

        applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(goodService.getApplication().getFileNumber());
        applicationNumber.setExtensionCounter(0);
        retGoodServices = goodsServicesDao.getGoodService(applicationNumber);

        assertEquals(i + 1, retGoodServices.size());
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetGoodServiceApplicationNumberIntegerInteger() {
        GoodService goodService = buildGoodService();

        goodsServicesDao.saveGoodsServices(goodService);
        Object detachedGoodService = new GoodsServicesDaoTest();
        BeanUtils.copyProperties(goodService, detachedGoodService);
        List<GoodService> retGoodServices = goodsServicesDao.getGoodService(goodService, goodService.getType(),
            goodService.getNumber());
        assertEquals(1, retGoodServices.size());

        GoodService retGoodService = retGoodServices.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retGoodService);
        assertEquals(goodService, retGoodService);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetGoodServiceGoodServiceId() {
        GoodService goodService = buildGoodService();

        goodsServicesDao.saveGoodsServices(goodService);
        Object detachedGoodService = new GoodsServicesDaoTest();
        BeanUtils.copyProperties(goodService, detachedGoodService);
        List<GoodService> retGoodServices = goodsServicesDao.getGoodService(goodService);
        assertEquals(1, retGoodServices.size());

        GoodService retGoodService = retGoodServices.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retGoodService);
        assertEquals(goodService, retGoodService);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testSaveGoodsServices() {
        GoodService goodService = buildGoodService();

        goodsServicesDao.saveGoodsServices(goodService);
        Object detachedGoodService = new GoodsServicesDaoTest();
        BeanUtils.copyProperties(goodService, detachedGoodService);
        List<GoodService> retGoodServices = goodsServicesDao.getGoodService(goodService);
        assertEquals(1, retGoodServices.size());

        GoodService retGoodService = retGoodServices.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retGoodService);
        assertEquals(goodService, retGoodService);
    }

    /**
     * @return
     */
    private GoodService buildGoodService() {
        GoodService goodService = new GoodService();
        goodService.setFileNumber(111);
        goodService.setExtensionCounter(0);
        goodService.setNumber(999);
        goodService.setType(GoodServiceType.GOODS.getValue());
        goodService.setGiCategoryType(99);
        goodService.setNiceClassCode(98);
        goodService.setNiceEdition(97);
        goodService.setApplication(applicationDao.getApplication(111, 0));
        return goodService;
    }

    @Test
    @Transactional(readOnly = true)
    public void testGoodsServiceWithSortEnabled() {
        Integer fileNumber = Integer.valueOf(191538);
        Integer extensionNumber = Integer.valueOf(0);
        ApplicationNumber applicationNumber = new ApplicationNumber(fileNumber, extensionNumber);
        List<GoodService> results = goodsServicesDao.getGoodServiceWithSortEnabled(applicationNumber);
        Assert.assertNotNull(results);
        Assert.assertTrue(results.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void testUnclassifiedGoodServices() {
        Integer fileNumber = 1909306;
        Integer extensionNumber = 0;
        ApplicationNumber applicationNumber = new ApplicationNumber(fileNumber, extensionNumber);
        Integer count = goodsServicesDao.getUnclassifiedGoods(applicationNumber);
        Assert.assertNotNull(count);
        Assert.assertTrue(count > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void testUniqueClassifiedGoodServices() {
        Integer fileNumber = 1909306;
        Integer extensionNumber = 0;
        ApplicationNumber applicationNumber = new ApplicationNumber(fileNumber, extensionNumber);
        Integer count = goodsServicesDao.getUniqueClassifiedGoods(applicationNumber);
        Assert.assertNotNull(count);
        Assert.assertTrue(count == 1);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void deleteUpdateGoodsServices() {
        // Create Application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        Claim claim = buildClaim(application);
        claimDao.saveClaim(claim);

        GoodService goodsService = buildGoodService(application); // WARES_SERVICES
        goodsServicesDao.saveGoodsServices(goodsService);

        GoodServiceClaim gsClaim = buildGsClaim(claim, goodsService); // WS_CLAIMS
        goodsServicesClaimDao.saveGoodServiceClaim(gsClaim);

        claim.getGoodServiceClaims().add(gsClaim);
        claimDao.saveClaim(claim); // CLAIM

        //
        ClaimText claimText = new ClaimText();
        claimText.setClaimNumber(999);
        claimText.setClaims(claim);
        claimText.setClaimType(ClaimType.DECLARATION_OF_USE.getValue());
        claimText.setOriginalInd(1);
        claimText.setModifiedDate(new Date());
        claimText.setExtensionCounter(0);
        claimText.setFileNumber(application.getFileNumber());
        claimText.setText(
            "Clothing, namely, shirts, t-shirts, polo shirts, dress shirts, collared shirts, tops, tank tops, sweatshirts, hooded sweatshirts, hoodies, sweaters, cardigans, pants, sweatpants, jeans, trousers, shorts, bottoms, jackets, coats, overcoats, parkas, raincoats, wind-resistant jackets, vests, belts, suits, tuxedos, blazers, sport coats, ties, footwear, shoes, sandals, socks, underwear, beachwear, beach footwear, swim suits, swim trunks, pajamas, scarves, gloves, headwear, hats, and caps.");

        claimTextDao.saveClaimText(claimText);
        claim.getClaimTexts().add(claimText);
        claimDao.saveClaim(claim);

        application.getGoodsServices().add(goodsService);
        application.getClaims().add(claim);
        applicationDao.saveApplication(application);

        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application, goodsService);
        Assert.assertTrue(results.size() == 1);

        goodsServicesDao.deleteGoodsServices(goodsService);
        claimDao.deleteClaim(claim);

        results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application, goodsService);
        List<Claim> claimRecord = claimDao.getClaim(application.getFileNumber(), 0);
        Assert.assertTrue(results.size() == 0 && CollectionUtils.isEmpty(claimRecord));
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);
        return application;
    }

    private Claim buildClaim(Application application) {
        Claim claim = new Claim();
        claim.setApplication(application);
        claim.setClaimType(ClaimType.DECLARATION_OF_USE.getValue());
        claim.setClaimNumber(999);
        claim.setFileNumber(claim.getApplication().getFileNumber());
        claim.setExtensionCounter(claim.getApplication().getExtensionCounter());
        claim.setLanguage(1);
        return claim;
    }

    private GoodService buildGoodService(Application application) {
        GoodService goodService = new GoodService();
        goodService.setNumber(998);
        goodService.setType(GoodServiceType.GOODS.getValue());
        goodService.setApplication(application);
        goodService.setFileNumber(application.getFileNumber());
        goodService.setExtensionCounter(application.getExtensionCounter());
        return goodService;
    }

    private GoodServiceClaim buildGsClaim(Claim claim, GoodService goodService) {
        GoodServiceClaim gsClaim = new GoodServiceClaim();
        gsClaim.setClaim(claim);
        gsClaim.setGoodService(goodService);
        gsClaim.setFileNumber(gsClaim.getClaim().getApplication().getFileNumber());
        gsClaim.setExtensionCounter(gsClaim.getClaim().getApplication().getExtensionCounter());
        gsClaim.setClaimType(claim.getClaimType());
        gsClaim.setType(goodService.getType());
        gsClaim.setNumber(goodService.getNumber());
        gsClaim.setClaimNumber(claim.getClaimNumber());
        return gsClaim;
    }
}
