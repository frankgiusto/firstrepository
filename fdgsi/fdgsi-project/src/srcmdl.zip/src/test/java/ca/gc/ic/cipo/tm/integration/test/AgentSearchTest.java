package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.search.AgentSearch;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionFactory;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.enumerator.SearchItemType;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.type.CountryCanadaProvinceEnum;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AgentSearchTest {

    @Autowired
    @Qualifier("agentSearch")
    private AgentSearch agentSearch;

    @Test
    @Transactional(readOnly = true)
    public void searchAgentsByName() {
        List<Expression> expressions = createSearchExpressions();
        List<AgentRepresentative> results = agentSearch.searchAgents(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        Assert.assertTrue(results.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void getAgentEmailAddresses() {
        List<Expression> expressions = createSearchExpressionAgentUserName();
        List<String> results = agentSearch.getAgentEmailAddresses(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(results);
        Assert.assertTrue(results.size() > 0);
        for (String eachResult : results) {
            System.out.println(eachResult);
        }
    }

    private List<Expression> createSearchExpressions() {

        List<Expression> expressions = new ArrayList<>();

        // Name
        String value = "peter";
        Expression expression = makeExpression(SearchItemType.NAME_SEARCH.dbColName("AR"),
            SearchItemType.NAME_SEARCH.namedParamName(), HibernateOperatorEnum.LIKE, value);
        expressions.add(expression);

        // COUNTRY_PROVINCE
        value = "CA";
        expression = makeExpression(SearchItemType.COUNTRY_PROVINCE_SEARCH.dbColName("AR"),
            SearchItemType.COUNTRY_PROVINCE_SEARCH.namedParamName(), HibernateOperatorEnum.IN,
            CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList());
        expressions.add(expression);

        /*
         * // CITY value = "NEW YORK"; expression = makeExpression(SearchItemType.CITY_SEARCH.dbColName("AR"),
         * SearchItemType.CITY_SEARCH.namedParamName(), HibernateOperatorEnum.LIKE, value); expressions.add(expression);
         */
        return expressions;
    }

    private List<Expression> createSearchExpressionAgentUserName() {
        List<Expression> expressions = new ArrayList<>();
        // Name
        String value = "MaintFeeAgent1";
        Expression expression = makeExpression(SearchItemType.AGENT_USER_ID.dbColName("xref"),
            SearchItemType.AGENT_USER_ID.namedParamName(), HibernateOperatorEnum.LIKE, value);
        expressions.add(expression);

        return expressions;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      Object value) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            value);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      List<Object> values) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            values);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

}
