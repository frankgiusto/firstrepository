package ca.gc.ic.cipo.tm.integration.test;

import java.util.Date;

import org.hibernate.Hibernate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.enumerator.CorrespondenceType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Contact;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.type.CountryCanadaProvinceEnum;

@Transactional(readOnly = true)
@Rollback(true)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class InterestedPartyDaoTest {

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private ApplicationDao applicationDao;

    private ApplicationNumber applicationNumber;

    @Autowired
    private HibernateTransactionManager transactionManager;

    private static final Integer FILE_NUMBER = 148256;

    private static final Integer EXTENTION_NUMBER = 0;

    @Before
    public void initialize() {
        applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    }

    private InterestedParty buildIpNoExistingOwner() {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(1863146);
        interestedParty.setExtensionCounter(0);
        interestedParty.setApplication(applicationDao.getApplication(interestedParty));
        buildPartialIp(interestedParty);
        return interestedParty;
    }

    private InterestedParty buildIpExistingOwner() {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(111);
        interestedParty.setExtensionCounter(0);
        interestedParty.setApplication(applicationDao.getApplication(interestedParty));
        buildPartialIp(interestedParty);
        return interestedParty;
    }

    private void buildPartialIp(InterestedParty interestedParty) {
        IPContact contact = new IPContact();
        interestedParty.setContact(contact);

        interestedParty.setIpNumber(111);
        interestedParty.setModifiedTimestamp(new Date());
        interestedParty.setRelationshipType(RelationshipType.OWNER.getValue());
        interestedParty.setApplicantInd(1);
        interestedParty.setRegistrantInd(0);
        contact.setLanguage(1);
        InterestedPartiesAddresses address = new InterestedPartiesAddresses();
        address.setCountryProvince(CountryCanadaProvinceEnum.CA.getValue());
        address.setPostalCode("HOHOHO");
        contact.setPhoneNumber("999-999-9999999-999-");
        contact.setFaxNumber("999-999-9999999-999-");
        interestedParty.setReference("testtesttesttesttes");
        interestedParty.setAgentNumber(1);
        interestedParty.setAgentReference("test2test2test2test2");
        interestedParty.setAgentAttention("agentAttentionagentAttentionageagentAtt");
        contact.setName("addressaddres" + System.getProperty("line.separator")
            + "addressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddr");
        address.setAddress("addressaddres" + System.getProperty("line.separator")
            + "addressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddr");
        contact.setMailingNameAddress("addressaddres" + System.getProperty("line.separator")
            + "addressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddr");
        contact.setEmailAddress(
            "emailadressemailadressemailadressemailad@ailadressemailadressemailadressemailadressemailadresss.com");
        Contact businessContact = new Contact();
        InterestedPartiesAddresses busAddress = new InterestedPartiesAddresses();
        busAddress.setAddress("addressaddres" + System.getProperty("line.separator")
            + "addressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddr");
        busAddress.setCountryProvince(CountryCanadaProvinceEnum.N2.getValue());
        busAddress.setPostalCode("HOHOHO");
        businessContact.setMailingNameAddress("addressaddres" + System.getProperty("line.separator")
            + "addressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddressaddr");
        contact.getInterestedPartiesAddresses().add(busAddress);
        businessContact.setLanguage(1);
        interestedParty.setAgentCorrespondenceType(CorrespondenceType.ELECTRONIC.getValue());
        interestedParty.setCorrespondenceType(CorrespondenceType.ELECTRONIC.getValue());
        interestedParty.setRepCorrespondenceType(CorrespondenceType.ELECTRONIC.getValue());

        contact.getInterestedPartiesAddresses().add(address);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(value = false)
    @Ignore
    public void testUpdateIP() {
        // Les Creations Tiffany (1982) Inc.,
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(148256);
        interestedParty.setExtensionCounter(0);
        interestedParty.setIpNumber(76316);
        interestedParty.setRelationshipType(RelationshipType.OWNER.getValue());
        interestedParty.setApplicantInd(0);
        interestedParty.setRegistrantInd(0);
        IPContact contact = new IPContact();
        contact.setName("Les Creations Tiffany (1982) Inc.,");
        contact.setLanguage(1);
        contact.setInterestedParty(interestedParty);
        interestedParty.setContact(contact);

        this.interestedPartyDao.saveInterestedParty(interestedParty);

    }

    @Test
    public void testGetInterestedPartyByIpNumber() {
        InterestedParty interestedParty = buildIpExistingOwner();

        interestedPartyDao.saveInterestedParty(interestedParty);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty);
        // need to refresh application too, otherwise the query in the assert is not run against the database
        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty.getApplication());
        InterestedParty retrievedIp = interestedPartyDao.getInterestedPartyByIpNumber(interestedParty.getFileNumber(),
            interestedParty.getExtensionCounter(), interestedParty.getIpNumber());
        InterestedParty detachedIp = new InterestedParty();
        // Need to do a copy since Hibernate sets interestedParty and retrievedIp to the same instance...
        Hibernate.initialize(retrievedIp.getContact().getInterestedPartiesAddresses());
        BeanUtils.copyProperties(interestedParty, detachedIp);
        // Forces Hibernate to refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedIp);
        Assert.assertEquals(detachedIp, retrievedIp);
    }

    @Test
    public void testGetInterestedPartyByIpNumberApplicationNumberInteger() {
        InterestedParty interestedParty = buildIpExistingOwner();

        interestedPartyDao.saveInterestedParty(interestedParty);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty);
        // need to refresh application too, otherwise the query in the assert is not run against the database
        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty.getApplication());
        InterestedParty retrievedIp = interestedPartyDao.getInterestedPartyByIpNumber(interestedParty.getApplication(),
            interestedParty.getIpNumber());
        InterestedParty detachedIp = new InterestedParty();
        // Need to do a copy since Hibernate sets interestedParty and retrievedIp to the same instance...
        Hibernate.initialize(retrievedIp.getContact().getInterestedPartiesAddresses());
        BeanUtils.copyProperties(interestedParty, detachedIp);
        // Forces Hibernate to refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedIp);
        Assert.assertEquals(detachedIp, retrievedIp);
    }

    @Test
    @Ignore
    public void testGetInterestedPartyByFileNumberExtensionCounterRelationshipType() {
        InterestedParty interestedParty = buildIpExistingOwner();

        interestedPartyDao.saveInterestedParty(interestedParty);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty);
        // need to refresh application too, otherwise the query in the assert is not run against the database
        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty.getApplication());
        // TODO uncomment and review test when DAO is fixed, it should return a collection...
        /*
         * InterestedParty retrievedIp =
         * interestedPartyDao.getInterestedPartyByFileNumberExtensionCounterRelationshipType(
         * interestedParty.getFileNumber(), interestedParty.getExtensionCounter(),
         * interestedParty.getRelationshipType()); InterestedParty detachedIp = new InterestedParty(); // Need to do a
         * copy since Hibernate sets interestedParty and retrievedIp to the same instance...
         * Hibernate.initialize(retrievedIp.getContact().getInterestedPartiesAddresses());
         * BeanUtils.copyProperties(interestedParty, detachedIp); // Forces Hibernate to refresh from DB
         * transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedIp);
         * Assert.assertEquals(detachedIp, retrievedIp);
         */
    }

    @Test
    @Transactional(readOnly = true)
    public void testGetNextIpNumber() {
        Integer fileNumber = 74761;
        Integer extCounter = 0;
        Application app = new Application();
        app.setFileNumber(fileNumber);
        app.setExtensionCounter(extCounter);
        InterestedParty ip = new InterestedParty();
        ip.setApplication(app);

        if (interestedPartyDao == null) {
            System.out.println(" interestedPartyDao is null .......");
        }

        Integer nextIp = interestedPartyDao.getNextIpNumber(ip.getApplication().getFileNumber(),
            ip.getApplication().getExtensionCounter());
        System.out.println(
            "Next ip number for file number " + fileNumber + " and extCounter " + extCounter + " is = " + nextIp);
    }

    @Test
    @Transactional(readOnly = true)
    public void getInterestedPartyByFileNumberIPNumberAndRelationshipType() {
        ApplicationNumber applicationNumber = new ApplicationNumber(111, 0);
        InterestedParty interestedParty = buildIpExistingOwner();

        interestedPartyDao.saveInterestedParty(interestedParty);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        transactionManager.getSessionFactory().getCurrentSession().refresh(interestedParty);

        InterestedParty result = this.interestedPartyDao
            .getInterestedPartyByFileNumberIPNumberAndRelationshipType(applicationNumber, 111, 1);
        Assert.assertNotNull(result);

    }

    @Test()
    @Transactional(readOnly = true)
    public void getIPNumberByFileNumberExtensionCounterRelationshipType() {
        Integer result = this.interestedPartyDao.getIPNumberByFileNumberExtensionCounterRelationshipType(1797654, 0, 5);
        Assert.assertNotNull(result);
        System.out.println("IP Number " + result);
    }
}
