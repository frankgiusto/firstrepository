/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.ProcessActionsType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.MadridApplication;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import junit.framework.TestCase;

/**
 * This class test the ProcessActionsDao
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class ProcessActionsDaoTest extends TestCase {

    @Autowired
    private ProcessActionsDao processActionsDao;

    @Autowired
    private MadridApplicationDao madridApplicationDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Test
    @Transactional(readOnly = true)
    public void getProcessActionsTest() {

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(162535));
        applicationNumber.setExtensionCounter(Integer.valueOf(1));
        if (processActionsDao == null) {
            System.out.println("ProcessActionsDao is NULL!!!");
        }
        Set<ProcessAction> processActionsList = processActionsDao.getProcessActions(applicationNumber);
        assert (processActionsList.size() > 0);
        this.printData(processActionsList);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getProcessActionsByReferenceNumberTest() {

        Integer MADRID_APPLICATION_REGISTERED = 2;
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Madrid Application
        MadridApplication madridApplications = new MadridApplication("WIPO-9999", 9999l, application.getIrNumber(),
            MADRID_APPLICATION_REGISTERED, null, null);
        madridApplicationDao.saveMadridApplication(madridApplications);

        ProcessAction processActions = new ProcessAction();
        processActions.setAdditionalInfo("Frank");
        processActions.setApplication(application);
        processActions.setAuthorityId("GIUSTOF1");
        processActions.setExtensionCounter(0);
        processActions.setFileNumber(application.getFileNumber());
        processActions.setProcessCode(ProcessActionsType.CREATE_IR_REPLACEMENT_FULL.getValue());
        processActions.setProcessType(2);
        processActions.setWipoReferenceNumber("WIPO-9999");
        processActions.setIrNumber(application.getIrNumber());
        processActionsDao.saveProcessActions(processActions);

        List<ProcessAction> processActionsList = processActionsDao.getProcessActionsByReferenceNumber("WIPO-9999");

        assert (null != processActionsList);
        assert (processActionsList.size() > 0);

        for (ProcessAction pa : processActionsList) {
            assert (pa.getWipoReferenceNumber() != null && pa.getWipoReferenceNumber().equalsIgnoreCase("WIPO-9999"));
        }
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getProcessActionsByCodesTest() {

        List<Integer> officeToIbProcessActionCodes = new ArrayList<>();
        officeToIbProcessActionCodes.add(242);
        officeToIbProcessActionCodes.add(226);
        officeToIbProcessActionCodes.add(227);
        officeToIbProcessActionCodes.add(228);
        officeToIbProcessActionCodes.add(229);
        officeToIbProcessActionCodes.add(230);
        officeToIbProcessActionCodes.add(231);
        officeToIbProcessActionCodes.add(224);
        officeToIbProcessActionCodes.add(225);
        officeToIbProcessActionCodes.add(204);
        officeToIbProcessActionCodes.add(205);
        officeToIbProcessActionCodes.add(217);
        officeToIbProcessActionCodes.add(222);
        officeToIbProcessActionCodes.add(216);
        officeToIbProcessActionCodes.add(214);
        officeToIbProcessActionCodes.add(220);
        officeToIbProcessActionCodes.add(207);
        officeToIbProcessActionCodes.add(206);
        officeToIbProcessActionCodes.add(201);
        officeToIbProcessActionCodes.add(213);
        officeToIbProcessActionCodes.add(208);
        officeToIbProcessActionCodes.add(209);
        officeToIbProcessActionCodes.add(210);
        officeToIbProcessActionCodes.add(219);
        officeToIbProcessActionCodes.add(218);
        officeToIbProcessActionCodes.add(212);
        officeToIbProcessActionCodes.add(211);

        Integer MADRID_APPLICATION_REGISTERED = 2;
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Madrid Application
        MadridApplication madridApplications = new MadridApplication("WIPO-9999", 9999l, application.getIrNumber(),
            MADRID_APPLICATION_REGISTERED, null, null);
        madridApplicationDao.saveMadridApplication(madridApplications);

        ProcessAction processActions = new ProcessAction();
        processActions.setAdditionalInfo("Frank");
        processActions.setApplication(application);
        processActions.setAuthorityId("GIUSTOF1");
        processActions.setExtensionCounter(0);
        processActions.setFileNumber(application.getFileNumber());
        processActions.setProcessCode(ProcessActionsType.CREATE_IR_REPLACEMENT_FULL.getValue());
        processActions.setProcessType(2);
        processActions.setWipoReferenceNumber("WIPO-9999");
        processActions.setIrNumber(application.getIrNumber());
        processActionsDao.saveProcessActions(processActions);

        List<ProcessAction> processActionsList = processActionsDao
            .getProcessActionsByCodes(officeToIbProcessActionCodes);

        assert (null != processActionsList);

        List<Integer> one = new ArrayList<>();
        one.add(ProcessActionsType.CREATE_IR_REPLACEMENT_FULL.getValue());

        processActionsList = processActionsDao.getProcessActionsByCodes(one);

        Integer pk = processActionsList.get(0).getProcessActionId();

        ProcessAction pa = processActionsDao.getById(pk);

        processActionsDao.deleteProcessAction(pa);

        processActionsList = processActionsDao.getProcessActionsByCodes(one);

        if (null != processActionsList) {
            for (ProcessAction newProcessAction : processActionsList) {
                if (newProcessAction.getProcessActionId().intValue() == processActions.getProcessActionId()
                    .intValue()) {
                    // my process action should be deleted.
                    fail();
                }
            }
        }

    }

    /**
     * Printing method
     *
     * @param Collection of Process Actions
     */
    private void printData(Set<ProcessAction> processActionsList) {

        System.out.println("Process Actions Data: ");
        System.out.println("================================");

        for (ProcessAction processActions : processActionsList) {
            // This will get the specific process actions information
            System.out.println("Application Details: " + processActions.getApplication());
            System.out.println("Process Actions Process Type: " + processActions.getProcessType());
            System.out.println("Process Actions Process Code: " + processActions.getProcessCode());
            System.out.println("Process Actions Additional Info: " + processActions.getAdditionalInfo());
            System.out.println("Process Actions Alternate Mail To: " + processActions.getAlternateMailTo());
            System.out.println("Process Actions Authority ID: " + processActions.getAuthorityId());

        }
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);

        return application;
    }
}
