/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.OralHearingDetailsDao;
import ca.gc.ic.cipo.tm.model.OppositionCaseId;
import ca.gc.ic.cipo.tm.model.OralHearingDetails;
import junit.framework.TestCase;

/**
 * This class test the OralHearingDetailsDaoTest
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OralHearingDetailsDaoTest extends TestCase {

    @Autowired
    private OralHearingDetailsDao oralHearingDetailsDao;

    @Test
    @Transactional(readOnly = true)
    public void getOralHearingDetailsTest() {

        OppositionCaseId oppositionCaseId = new OppositionCaseId();
        oppositionCaseId.setFileNumber(Integer.valueOf(77270));
        oppositionCaseId.setExtensionCounter(Integer.valueOf(0));
        oppositionCaseId.setOppCaseNumber(Integer.valueOf(1));

        if (oralHearingDetailsDao == null) {
            System.out.println("oralHearingDetailsDao is NULL!!!");
        }
        Set<OralHearingDetails> oralHearingDetails = oralHearingDetailsDao.getOralHearingDetails(oppositionCaseId);
        assert (oralHearingDetails.size() > 0);
        this.printData(oralHearingDetails);

    }

    /**
     * Printing method
     *
     * @param Collection of Oral Hearing Details
     */
    private void printData(Set<OralHearingDetails> oralHearingDetailsSet) {

        System.out.println("Oral Hearing Details Data: ");
        System.out.println("================================");
        for (OralHearingDetails oralHearingDetails : oralHearingDetailsSet) {

            // This will get the specific oral hearing details information
            System.out.println("Application Details: " + oralHearingDetails.getApplication());
            System.out.println("Oral Hearing Details Timestamp: " + oralHearingDetails.getTimestamp());
            System.out.println("Oral Hearing Details Location: " + oralHearingDetails.getLocation());
            System.out.println("Oral Hearing Details Conference Call Confirm Number: "
                + oralHearingDetails.getConferenceCallConfirmNumber());
            System.out.println("Oral Hearing Details Language : " + oralHearingDetails.getLanguage());

        }
    }

}
