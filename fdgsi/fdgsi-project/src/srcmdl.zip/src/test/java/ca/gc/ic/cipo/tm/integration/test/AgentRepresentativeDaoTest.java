package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.ic.cipo.tm.dao.AgentRepresentativeDao;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AgentRepresentativeDaoTest {

    // DAO to test
    @Autowired
    private AgentRepresentativeDao agentRepresentativeDao;

    @Test
    public void testForGetActiveAgents() {
        final String userId = "MaintFeeAgent1";
        List<AgentRepresentative> results = agentRepresentativeDao.getActiveAgents(userId);
        Assert.assertNotNull(results);
    }

    @Test(expected = Exception.class)
    public void testForGetActiveAgentsWithInvalidUserId() {
        final String userId = "";
        List<AgentRepresentative> results = agentRepresentativeDao.getActiveAgents(userId);
        Assert.assertNotNull(results);

        results = agentRepresentativeDao.getActiveAgents(null);
        Assert.assertNotNull(results);
    }

    @Test()
    public void testForGetActiveAgentsWithWrongUserId() {
        final String userId = "XXXX";
        List<AgentRepresentative> results = agentRepresentativeDao.getActiveAgents(userId);
        Assert.assertNotNull(results);
        Assert.assertEquals(results.size(), 0);
    }

}
