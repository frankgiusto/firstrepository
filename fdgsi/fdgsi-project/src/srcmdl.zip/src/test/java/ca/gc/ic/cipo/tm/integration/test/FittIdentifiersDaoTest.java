/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Date;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.FittIdentifiersDao;
import ca.gc.ic.cipo.tm.enumerator.FileType;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FittIdentifiers;
import junit.framework.TestCase;

/**
 * This class test the FittIdentifiersDao
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class FittIdentifiersDaoTest extends TestCase {

    @Autowired
    private FittIdentifiersDao fittIdentifiersDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional(readOnly = true)
    public void getFittIdentifiersTest() {

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(1631750));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        if (fittIdentifiersDao == null) {
            System.out.println("fittIdentifiersDao is NULL!!!");
        }
        Set<FittIdentifiers> fittIdentifiersList = fittIdentifiersDao.getFittIdentifiers(applicationNumber);
        assert (fittIdentifiersList.size() > 0);
        this.printData(fittIdentifiersList);

    }

    /**
     * Printing method
     *
     * @param Collection of fittIdentifiers
     *
     */
    private void printData(Set<FittIdentifiers> fittIdentifiersList) {

        System.out.println("FITT Identifiers Data: ");
        System.out.println("================================");

        for (FittIdentifiers fittIdentifiers : fittIdentifiersList) {
            // This will get the specific fitt Identifiers information
            System.out.println("Application Details: " + fittIdentifiers.getApplication());
            System.out.println("Fitt Identifiers File Type: " + fittIdentifiers.getFileType());
            System.out.println("Fitt Identifiers Mail Room Date: " + fittIdentifiers.getMailRoomDate());
            System.out.println("Fitt Identifiers Mail Room Date Days: " + fittIdentifiers.getMailRoomDateDays());
            System.out.println("Fitt Identifiers First Received Date: " + fittIdentifiers.getFirstReceivedDate());
            System.out.println("Fitt Identifiers MURID: " + fittIdentifiers.getMrUID());

        }
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetFittIdentifiersIntegerInteger() {
        FittIdentifiers fittIdentifier = buildFittIdentifier();
        fittIdentifiersDao.saveFittIdentifiers(fittIdentifier);
        Set<FittIdentifiers> retrievedFittIdentifiers = fittIdentifiersDao
            .getFittIdentifiers(fittIdentifier.getFileNumber(), fittIdentifier.getExtensionCounter());
        FittIdentifiers detachedFittIdentifiers = new FittIdentifiers();
        // Need to do a copy since Hibernate sets fittIdentifier and retrievedFittIdentifier to the same instance...
        BeanUtils.copyProperties(fittIdentifier, detachedFittIdentifiers);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedFittIdentifiers.size());
        FittIdentifiers retrievedFittIdent = retrievedFittIdentifiers.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFittIdent);
        // TODO remove when date issue is fixed
        retrievedFittIdent.setFirstReceivedDate(detachedFittIdentifiers.getFirstReceivedDate());
        retrievedFittIdent.setMailRoomDate(detachedFittIdentifiers.getMailRoomDate());
        assertEquals(detachedFittIdentifiers, retrievedFittIdent);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetFittIdentifiersIntegerIntegerString() {
        FittIdentifiers fittIdentifier = buildFittIdentifier();
        fittIdentifiersDao.saveFittIdentifiers(fittIdentifier);
        Set<FittIdentifiers> retrievedFittIdentifiers = fittIdentifiersDao.getFittIdentifiers(
            fittIdentifier.getFileNumber(), fittIdentifier.getExtensionCounter(), fittIdentifier.getMrUID());
        FittIdentifiers detachedFittIdentifiers = new FittIdentifiers();
        // Need to do a copy since Hibernate sets fittIdentifier and retrievedFittIdentifier to the same instance...
        BeanUtils.copyProperties(fittIdentifier, detachedFittIdentifiers);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedFittIdentifiers.size());
        FittIdentifiers retrievedFittIdent = retrievedFittIdentifiers.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFittIdent);
        // TODO remove when date issue is fixed
        retrievedFittIdent.setFirstReceivedDate(detachedFittIdentifiers.getFirstReceivedDate());
        retrievedFittIdent.setMailRoomDate(detachedFittIdentifiers.getMailRoomDate());
        assertEquals(detachedFittIdentifiers, retrievedFittIdent);
    }

    @Transactional(readOnly = false)
    @Rollback(true)

    @Test
    public void testGetFittIdentifiersApplicationNumber() {
        FittIdentifiers fittIdentifier = buildFittIdentifier();
        fittIdentifiersDao.saveFittIdentifiers(fittIdentifier);

        Set<FittIdentifiers> retrievedFittIdentifiers = fittIdentifiersDao.getFittIdentifiers(
            new ApplicationNumber(fittIdentifier.getFileNumber(), fittIdentifier.getExtensionCounter()));
        FittIdentifiers detachedFittIdentifiers = new FittIdentifiers();
        // Need to do a copy since Hibernate sets fittIdentifier and retrievedFittIdentifier to the same instance...
        BeanUtils.copyProperties(fittIdentifier, detachedFittIdentifiers);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedFittIdentifiers.size());
        FittIdentifiers retrievedFittIdent = retrievedFittIdentifiers.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFittIdent);
        // TODO remove when date issue is fixed
        retrievedFittIdent.setFirstReceivedDate(detachedFittIdentifiers.getFirstReceivedDate());
        retrievedFittIdent.setMailRoomDate(detachedFittIdentifiers.getMailRoomDate());
        assertEquals(detachedFittIdentifiers, retrievedFittIdent);
    }

    @Transactional(readOnly = false)
    @Rollback(true)

    @Test
    public void testGetFittIdentifiersApplicationNumberString() {
        FittIdentifiers fittIdentifier = buildFittIdentifier();
        fittIdentifiersDao.saveFittIdentifiers(fittIdentifier);
        Set<FittIdentifiers> retrievedFittIdentifiers = fittIdentifiersDao.getFittIdentifiers(fittIdentifier,
            fittIdentifier.getMrUID());
        FittIdentifiers detachedFittIdentifiers = new FittIdentifiers();
        // Need to do a copy since Hibernate sets fittIdentifier and retrievedFittIdentifier to the same instance...
        BeanUtils.copyProperties(fittIdentifier, detachedFittIdentifiers);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedFittIdentifiers.size());
        FittIdentifiers retrievedFittIdent = retrievedFittIdentifiers.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFittIdent);
        // TODO remove when date issue is fixed
        retrievedFittIdent.setFirstReceivedDate(detachedFittIdentifiers.getFirstReceivedDate());
        retrievedFittIdent.setMailRoomDate(detachedFittIdentifiers.getMailRoomDate());
        assertEquals(detachedFittIdentifiers, retrievedFittIdent);
    }

    @Transactional(readOnly = false)
    @Rollback(true)

    @Test
    public void testGetFittIdentifiersApplicationNumberFittIdentifiersId() {
        FittIdentifiers fittIdentifier = buildFittIdentifier();
        fittIdentifiersDao.saveFittIdentifiers(fittIdentifier);
        Set<FittIdentifiers> retrievedFittIdentifiers = fittIdentifiersDao.getFittIdentifiers(fittIdentifier);
        FittIdentifiers detachedFittIdentifiers = new FittIdentifiers();
        // Need to do a copy since Hibernate sets fittIdentifier and retrievedFittIdentifier to the same instance...
        BeanUtils.copyProperties(fittIdentifier, detachedFittIdentifiers);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedFittIdentifiers.size());
        FittIdentifiers retrievedFittIdent = retrievedFittIdentifiers.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFittIdent);
        // TODO remove when date issue is fixed
        retrievedFittIdent.setFirstReceivedDate(detachedFittIdentifiers.getFirstReceivedDate());
        retrievedFittIdent.setMailRoomDate(detachedFittIdentifiers.getMailRoomDate());
        assertEquals(detachedFittIdentifiers, retrievedFittIdent);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testSaveFittIdentifiers() {
        FittIdentifiers fittIdentifier = buildFittIdentifier();
        fittIdentifiersDao.saveFittIdentifiers(fittIdentifier);
        Set<FittIdentifiers> retrievedFittIdentifiers = fittIdentifiersDao.getFittIdentifiers(fittIdentifier);
        FittIdentifiers detachedFittIdentifiers = new FittIdentifiers();
        // Need to do a copy since Hibernate sets fittIdentifier and retrievedFittIdentifier to the same instance...
        BeanUtils.copyProperties(fittIdentifier, detachedFittIdentifiers);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedFittIdentifiers.size());
        FittIdentifiers retrievedFittIdent = retrievedFittIdentifiers.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFittIdent);
        // TODO remove when date issue is fixed
        retrievedFittIdent.setFirstReceivedDate(detachedFittIdentifiers.getFirstReceivedDate());
        retrievedFittIdent.setMailRoomDate(detachedFittIdentifiers.getMailRoomDate());
        assertEquals(detachedFittIdentifiers, retrievedFittIdent);
    }

    /**
     * @return
     */
    private FittIdentifiers buildFittIdentifier() {
        FittIdentifiers fittIdentifier = new FittIdentifiers();
        fittIdentifier.setFileNumber(111);
        fittIdentifier.setExtensionCounter(0);
        fittIdentifier.setMrUID(
            "mrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUIDmrUID");
        fittIdentifier.setFileType(FileType.TRADE_MARK.getValue());
        fittIdentifier.setFirstReceivedDate(new Date());
        fittIdentifier.setMailRoomDate(new Date());
        fittIdentifier.setMailRoomDateDays("mailRo");
        return fittIdentifier;
    }

}
