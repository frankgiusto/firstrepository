package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.Mail;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class MailDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private MailDao mailDao;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getMailByFileNumber() {

        // 1. create application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Mail
        Calendar mailDate = Calendar.getInstance();

        Mail mail = new Mail();
        mail.setFileNumber(nextApplicationNumber);
        mail.setFileType(2);
        mail.setMailAttachedInd(1);
        mail.setAdditionalInfo("testing");
        mail.setAuthorityId("GIUSTOF1");
        mail.setEcMailText("some text");
        mail.setMailType(1);
        mail.setMailMode(2);
        mail.setMailTimestamp(mailDate.getTime());
        mail.setMailRoomDate(mailDate.getTime());
        mail.setProcessedByAuthorityID("MADRID1");
        mail.setProcessedDate(mailDate.getTime());

        mailDao.saveMail(mail);

        mailDate.add(Calendar.DAY_OF_WEEK, 1);

        // Create second mail for same file
        mail = new Mail();
        mail.setFileNumber(nextApplicationNumber);
        mail.setFileType(2);
        mail.setMailAttachedInd(1);
        mail.setAdditionalInfo("testing 2");
        mail.setAuthorityId("GIUSTOF1");
        mail.setEcMailText("some text 2");
        mail.setMailTimestamp(mailDate.getTime());
        mail.setMailRoomDate(mailDate.getTime());
        mail.setProcessedByAuthorityID("MADRID2");
        mail.setProcessedDate(mailDate.getTime());

        mailDao.saveMail(mail);

        List<Mail> results = mailDao.getMailByFileId(nextApplicationNumber);

        assertTrue(null != results);

    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testUpdateMailAttachedIndWithAuthority() {

        // 1. create application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Mail
        Calendar mailDate = Calendar.getInstance();

        Mail mail = new Mail();
        mail.setFileNumber(nextApplicationNumber);
        mail.setFileType(2);
        mail.setMailAttachedInd(0);
        mail.setAdditionalInfo("testing");
        mail.setAuthorityId("GIUSTOF1");
        mail.setEcMailText("some text");
        mail.setMailType(1);
        mail.setMailMode(2);
        mail.setMailTimestamp(mailDate.getTime());
        mail.setMailRoomDate(mailDate.getTime());
        mail.setProcessedDate(mailDate.getTime());

        mailDao.saveMail(mail);

        List<Mail> results = mailDao.getMailByFileId(nextApplicationNumber);
        assertTrue(null != results && results.size() == 1);

        mail = results.get(0);
        assertTrue(mail.getMailAttachedInd() == 0);

        mailDao.updateMailAttachedIndicatorWithAuthority(mail.getFileNumber(), "MADRID1", mail.getFileType());

        results = mailDao.getMailByFileId(nextApplicationNumber);
        assertTrue(null != results && results.size() == 1);

        mail = results.get(0);
        assertTrue(mail.getMailAttachedInd() == 1);
        assertTrue(mail.getProcessedByAuthorityID().equals("MADRID1"));
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testUpdateMailAttachedIndWithAuthorityForNoProcessByAuthority() {

        // 1. create application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Mail
        Calendar mailDate = Calendar.getInstance();

        Mail mail = new Mail();
        mail.setFileNumber(nextApplicationNumber);
        mail.setFileType(2);
        mail.setMailAttachedInd(0);
        mail.setAdditionalInfo("testing");
        mail.setAuthorityId("GIUSTOF1");
        mail.setEcMailText("some text");
        mail.setMailType(1);
        mail.setMailMode(2);
        mail.setMailTimestamp(mailDate.getTime());
        mail.setMailRoomDate(mailDate.getTime());
        mail.setProcessedDate(mailDate.getTime());

        mailDao.saveMail(mail);

        List<Mail> results = mailDao.getMailByFileId(nextApplicationNumber);
        assertTrue(null != results && results.size() == 1);

        mail = results.get(0);
        assertTrue(mail.getMailAttachedInd() == 0);

        mailDao.updateMailAttachedIndicatorWithAuthority(mail.getFileNumber(), null, mail.getFileType());

        results = mailDao.getMailByFileId(nextApplicationNumber);
        assertTrue(null != results && results.size() == 1);

        mail = results.get(0);
        assertTrue(mail.getMailAttachedInd() == 1);
        assertTrue(StringUtils.isBlank(mail.getProcessedByAuthorityID()));
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testUpdateMailAttachedIndWithAuthorityForMailType() {

        // 1. create application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        // Create Mail
        Calendar mailDate = Calendar.getInstance();

        Mail mail = new Mail();
        mail.setFileNumber(nextApplicationNumber);
        mail.setFileType(2);
        mail.setMailAttachedInd(0);
        mail.setAdditionalInfo("testing");
        mail.setAuthorityId("GIUSTOF1");
        mail.setEcMailText("some text");
        mail.setMailType(1);
        mail.setMailMode(2);
        mail.setMailTimestamp(mailDate.getTime());
        mail.setMailRoomDate(mailDate.getTime());
        mail.setProcessedDate(mailDate.getTime());

        mailDao.saveMail(mail);

        List<Mail> results = mailDao.getMailByFileId(nextApplicationNumber);
        assertTrue(null != results && results.size() == 1);

        mail = results.get(0);
        assertTrue(mail.getMailAttachedInd() == 0);

        mailDao.updateMailAttachedIndicatorWithAuthority(mail.getFileNumber(), "MADRID1", mail.getFileType(),
            mail.getMailType());

        results = mailDao.getMailByFileId(nextApplicationNumber);
        assertTrue(null != results && results.size() == 1);

        mail = results.get(0);
        assertTrue(mail.getMailAttachedInd() == 1);
        assertTrue(mail.getProcessedByAuthorityID().equals("MADRID1"));
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);

        return application;
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void updateMailRecord() {
        this.mailDao.updateMailAttachedIndicator(2, 1972133, "APP_20190201115915.pdf");
        Mail mail = this.mailDao.getMail(1972133, 2, 1, "APP_20190201115915.pdf");
        Assert.assertEquals(new Integer(1), mail.getMailAttachedInd());
    }
}
