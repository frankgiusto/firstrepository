/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import junit.framework.TestCase;

/**
 * This class test the PullingListsDao
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Ignore
public class PullingListsDaoTest extends TestCase {

}
