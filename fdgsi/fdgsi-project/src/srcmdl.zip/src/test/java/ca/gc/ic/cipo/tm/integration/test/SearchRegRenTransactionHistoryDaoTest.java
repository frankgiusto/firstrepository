package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.SearchRegRenTransactionHistoryDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.SearchRegRenTransactionHistory;
import ca.gc.ic.cipo.tm.model.SearchRegRenTransactionHistoryCriteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class SearchRegRenTransactionHistoryDaoTest {

    @Autowired
    private SearchRegRenTransactionHistoryDao searchRegRenTransactionHistoryDao;

    @Test
    public void testForSearchTransactionHistoryForRegistration() {
        final Integer fileNumber = 1373059;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);

        SearchRegRenTransactionHistoryCriteria.Builder builder = new SearchRegRenTransactionHistoryCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addConfirmationNumber("2065292").addTransactionType("1");
        SearchRegRenTransactionHistoryCriteria searchCriteria = builder.build();
        List<SearchRegRenTransactionHistory> results = searchRegRenTransactionHistoryDao
            .searchRegRenTransactionHistory(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 1);
    }

    @Test
    public void testForSearchTransactionHistoryForExtensionOfTime() {
        final Integer fileNumber = 1261502;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);

        SearchRegRenTransactionHistoryCriteria.Builder builder = new SearchRegRenTransactionHistoryCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addConfirmationNumber("2211465").addTransactionType("3");
        SearchRegRenTransactionHistoryCriteria searchCriteria = builder.build();
        List<SearchRegRenTransactionHistory> results = searchRegRenTransactionHistoryDao
            .searchRegRenTransactionHistory(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 1);
    }

    @Test
    public void testForSearchTransactionHistoryForRenewal() {
        final Integer fileNumber = 884972;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);

        SearchRegRenTransactionHistoryCriteria.Builder builder = new SearchRegRenTransactionHistoryCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addConfirmationNumber("5241863").addTransactionType("2");
        SearchRegRenTransactionHistoryCriteria searchCriteria = builder.build();
        List<SearchRegRenTransactionHistory> results = searchRegRenTransactionHistoryDao
            .searchRegRenTransactionHistory(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 1);
    }

    @Test
    public void testForSearchTransactionHistoryWithNonExistingApplicationNumber() {
        // does not exist in DB
        final Integer fileNumber = 1720387123;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);

        SearchRegRenTransactionHistoryCriteria.Builder builder = new SearchRegRenTransactionHistoryCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addConfirmationNumber("6339786").addTransactionType("1");
        SearchRegRenTransactionHistoryCriteria searchCriteria = builder.build();
        List<SearchRegRenTransactionHistory> results = searchRegRenTransactionHistoryDao
            .searchRegRenTransactionHistory(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 0);
    }

    @Test(expected = RuntimeException.class)
    public void testForNoSearchCriteria() {
        SearchRegRenTransactionHistoryCriteria.Builder builder = new SearchRegRenTransactionHistoryCriteria.Builder();
        SearchRegRenTransactionHistoryCriteria searchCriteria = builder.build();
        searchRegRenTransactionHistoryDao.searchRegRenTransactionHistory(searchCriteria);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSearchCriteria() {
        SearchRegRenTransactionHistoryCriteria.Builder builder = new SearchRegRenTransactionHistoryCriteria.Builder();
        builder.addApplicationNumber(new ApplicationNumber(884972, 0)).addConfirmationNumber("6339786")
            .addTransactionType("5");
        SearchRegRenTransactionHistoryCriteria searchCriteria = builder.build();
        searchRegRenTransactionHistoryDao.searchRegRenTransactionHistory(searchCriteria);
    }

}
