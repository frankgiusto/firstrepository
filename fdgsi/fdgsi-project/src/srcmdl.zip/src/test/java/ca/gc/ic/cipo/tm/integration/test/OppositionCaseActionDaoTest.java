/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.OppositionActionType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStage;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import junit.framework.TestCase;

/**
 * This class test the OppositionCaseActionDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionCaseActionDaoTest extends TestCase {

    @Autowired
    private OppositionCaseActionDao oppositionCaseActionDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Autowired
    private ApplicationDao applicationDao;

    @Test
    @Transactional(readOnly = true)
    public void getEmailJobs() {

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(236242));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));

    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void saveOppositionDuplicateCaseActions() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        applicationDao.saveApplication(application);
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setOppCaseNumber(1);
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        OppositionCaseAction oppositionCaseAction1 = createNewOppositionAction(application, oppositionCase);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction2 = createNewOppositionAction(application, oppositionCase);

        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction1);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction2);

        OppositionCase detachedOp = new OppositionCase();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(oppositionCase, detachedOp);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        OppositionCase retrievedOp = oppositionCaseDao.getOppositionCase(oppositionCase,
            oppositionCase.getOppCaseNumber());

        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedOp);
        OppositionCaseAction oppositionCaseAction1Ret = retrievedOp.getOppositionCaseActions().get(0);
        OppositionCaseAction oppositionCaseAction2Ret = retrievedOp.getOppositionCaseActions().get(1);

        assertNotNull(oppositionCaseAction1Ret.getOppositionCaseActionsSeq());

        assertEquals(detachedOp, retrievedOp);
        assertNotSame(oppositionCaseAction1Ret, oppositionCaseAction2Ret);
    }

    @Test
    @Transactional(readOnly = true)
    public void getPreviousDeadlineDateForOpposition() {
        OppositionCaseAction oppositionCaseAction = new OppositionCaseAction();
        oppositionCaseAction.setFileNumber(1862235);
        oppositionCaseAction.setExtensionCounter(0);
        oppositionCaseAction.setOppStageCode(101);
        oppositionCaseAction.setOppActionCode(301);
        oppositionCaseAction.setOppActionType(2);
        oppositionCaseAction.setOppCaseNumber(1);

        OppositionCaseAction result = this.oppositionCaseActionDao
            .getPreviousDeadlineDateForOpposition(oppositionCaseAction);
        Assert.assertNotNull("Check for not null", result);
        Assert.assertEquals("Check file number", result.getFileNumber(), new Integer(1862235));
        Assert.assertNotNull("Check deadline date", result.getActionDate());
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testGetOppositionCaseActions() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        applicationDao.saveApplication(application);

        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setOppCaseNumber(1);
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        OppositionCaseAction oppositionCaseAction1 = createNewOppositionAction(application, oppositionCase);
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        OppositionCaseAction oppositionCaseAction2 = createNewOppositionAction(application, oppositionCase);

        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction1);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction2);

        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        List<OppositionCaseAction> results = oppositionCaseActionDao.getOppositionCaseActions(applicationNumber,
            new Integer(1));
        Assert.assertNotNull(results);
        Assert.assertTrue(results.size() > 0);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testGetOppositionCaseAction() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        applicationDao.saveApplication(application);

        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setOppCaseNumber(1);
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppOwnerCorrInd(1);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        OppositionCaseAction oppositionCaseAction1 = createNewOppositionAction(application, oppositionCase);
        oppositionCaseActionDao.saveOrUpdateEntity(OppositionCaseAction.class, oppositionCaseAction1);

        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());

        Integer oppStageCode = OppositionCaseStage.GENERAL_ACTIONS_OPPOSITIONS.getValue();
        Integer oppActionCode = OppositionCaseActionCodeType.CASE_OPENED.getValue();

        OppositionCaseAction result = this.oppositionCaseActionDao.getOppositionCaseAction(applicationNumber, 1,
            oppStageCode, oppActionCode);
        Assert.assertNotNull(result);
    }

    private OppositionCaseAction createNewOppositionAction(Application application, OppositionCase oppositionCase) {
        OppositionCaseAction oppositionCaseAction1 = new OppositionCaseAction();
        oppositionCaseAction1.setFileNumber(application.getFileNumber());
        oppositionCaseAction1.setExtensionCounter(application.getExtensionCounter());
        oppositionCaseAction1.setActionDate(new Date());
        oppositionCaseAction1.setOppCaseNumber(oppositionCase.getOppCaseNumber());
        // oppositionCaseAction1.setOppositionCase(oppositionCase);
        oppositionCaseAction1.setOppStageCode(OppositionCaseStage.GENERAL_ACTIONS_OPPOSITIONS.getValue());
        oppositionCaseAction1.setOppActionCode(OppositionCaseActionCodeType.CASE_OPENED.getValue());
        oppositionCaseAction1.setOppActionType(OppositionActionType.SYSTEM_GENERATED.getValue());
        oppositionCaseAction1.setAuthorityId("JOURNAL");
        return oppositionCaseAction1;
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);

        return application;
    }

    @Test
    @Transactional(readOnly = true)
    @Ignore("Revist later")
    public void activeOppositionCaseActions() {
        ApplicationNumber applicationNumber = new ApplicationNumber(1737892, 0);
        Integer oppActionType = OppositionActionType.DEADLINE_BF.getValue();
        Integer caseNumber = 1;
        List<OppositionCaseAction> results = oppositionCaseActionDao.getActiveOppositionCaseActions(applicationNumber,
            caseNumber, oppActionType);
        Assert.assertNotNull(results);
        Assert.assertEquals(results.size(), 1);
    }

    @Test
    @Transactional(readOnly = true)
    @Ignore
    public void testGetOppositionCaseActionForEvidence() {
        ApplicationNumber applicationNumber = new ApplicationNumber(1800091, 0);
        Integer caseNumber = 1;
        Integer oppActionCode = OppositionCaseActionCodeType.DEADLINE_EVIDENCE_FROM_OWNER.getValue();
        Integer oppStageCode = OppositionCaseStage.SECTION45_REGISTRANT_EVIDENCE.getValue();

        OppositionCaseAction result = oppositionCaseActionDao.getOppositionCaseAction(applicationNumber, caseNumber,
            oppStageCode, oppActionCode);

        System.out.println("Case Number: " + result.getOppCaseNumber());
        System.out.println("Authority Id: " + result.getAuthorityId());
        System.out.println("oppStageCode: " + result.getOppStageCode());
        System.out.println("Action Date: " + result.getActionDate());
        System.out.println("Effective Date: " + result.getEffectiveDate());
        System.out.println("Response Date: " + result.getResponseDate());
        System.out.println("Delete Code: " + result.getDeleteCode());

        Assert.assertNotNull(result);
    }

    @Test
    @Transactional(readOnly = true)
    @Ignore
    public void testGetOppositionCaseActionForS45Evidence() {
        ApplicationNumber applicationNumber = new ApplicationNumber(1800091, 0);
        Integer caseNumber = 1;
        Integer oppActionCode = OppositionCaseActionCodeType.DEADLINE_EVIDENCE_FROM_OWNER.getValue();
        Integer oppStageCode = OppositionCaseStage.SECTION45_REGISTRANT_EVIDENCE.getValue();

        List<OppositionCaseAction> results = oppositionCaseActionDao.getOppositionCaseActions(applicationNumber,
            caseNumber);

        if (results != null && !results.isEmpty()) {
            for (OppositionCaseAction oca : results) {
                if (oppStageCode.equals(oca.getOppStageCode()) && oppActionCode.equals(oca.getOppActionCode())) {
                    System.out.println("Authority Id: " + oca.getAuthorityId());
                    System.out.println("oppStageCode: " + oca.getOppStageCode());
                    System.out.println("oppActionType: " + oca.getOppActionType());
                    System.out.println("oppActionCode: " + oca.getOppActionCode());
                    System.out.println("deleteCode: " + oca.getDeleteCode());
                }
            }
        }

        Assert.assertNotNull(results);
    }
}
