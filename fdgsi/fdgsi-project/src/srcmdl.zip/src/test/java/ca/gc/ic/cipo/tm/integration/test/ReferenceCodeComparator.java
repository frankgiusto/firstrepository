package ca.gc.ic.cipo.tm.integration.test;

import java.util.Comparator;

import ca.gc.ic.cipo.tm.model.ReferenceCode;

public class ReferenceCodeComparator implements Comparator<ReferenceCode> {

	public int compare(ReferenceCode o1, ReferenceCode o2) {
		return o1.getCode().compareTo(o2.getCode());
	}

	
}
