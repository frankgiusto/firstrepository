/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AgentRepresentativeActionsDao;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.AgentRepresentativeActions;
import ca.gc.ic.cipo.tm.model.AuthoritiesId;
import junit.framework.TestCase;

/**
 * Tis class tests AgentRepresentativeActionsDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AgentRepresentativeActionsDaoTest extends TestCase {

    @Autowired
    private AgentRepresentativeActionsDao agentRepresentativeActionsDao;

    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getAgentRepresentativeActionsTest() {

        AgentRepresentative agentRepresentative = new AgentRepresentative();
        AuthoritiesId authoritiesId = new AuthoritiesId();
        agentRepresentative.setArNumber(Integer.valueOf(13529));
        authoritiesId.setAuthorityId("LEPAGEL1");

        if (agentRepresentativeActionsDao == null) {
            System.out.println("agentRepresentativeActionsDao is NULL!!!");
        }

        // Retrieve Agent Representative Actions
        Set<AgentRepresentativeActions> agentRepresentativesActions = agentRepresentativeActionsDao
            .getAgentRepresentativeActions(agentRepresentative.getArNumber(), authoritiesId.getAuthorityId());
        assert (agentRepresentativesActions.size() > 0);
        this.printData(agentRepresentativesActions);
    }

    /**
     * Printing method
     *
     * @param Collection of agent representative actions
     */
    private void printData(Set<AgentRepresentativeActions> agentRepresentativesActions) {

        System.out.println("Agent Representative Actions Data: ");
        System.out.println("=============================");
        for (AgentRepresentativeActions agentRepresentativesAction : agentRepresentativesActions) {

            // This will get the Agent Representative Actions data

            System.out.println("Agent Representative Actions AR Number : " + agentRepresentativesAction.getArNumber());
            System.out
                .println("Agent Representative Actions Authority ID : " + agentRepresentativesAction.getAuthorityId());
            System.out
                .println("Agent Representative Actions Action Code : " + agentRepresentativesAction.getActionCode());
            System.out
                .println("Agent Representative Actions Action Date : " + agentRepresentativesAction.getActionDate());
            System.out.println(
                "Agent Representative Actions Additional Info: " + agentRepresentativesAction.getAdditionalInfo());
            System.out.println(
                "Agent Representative Actions electronic Ind : " + agentRepresentativesAction.getElectronicInd());
            System.out
                .println("Agent Representative Actions EC File Name: " + agentRepresentativesAction.getEcFileName());

        }
    }
}
