/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import junit.framework.TestCase;

/**
 * Tis class tests InterestedPartiesAddressesDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class InterestedPartiesAddressesDaoTest extends TestCase {

    @Autowired
    private InterestedPartiesAddressesDao interestedPartiesAddressesDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional(readOnly = true)
    public void getInterestedPartiesAddressesDaoTest() {

        InterestedPartiesAddresses interestedPartiesAddresses = new InterestedPartiesAddresses();
        Integer fileNumber = 67472;
        Integer extensionCounter = 0;
        Integer ipNumber = 1;

        if (interestedPartiesAddressesDao == null) {
            System.out.println("interestedPartiesAddressesDao is NULL!!!");
        }

        // Retrieve InterestedPartiesAddresses
        List<InterestedPartiesAddresses> interestedPartiesAddressesList = interestedPartiesAddressesDao
            .getInterestedPartiesAddresses(fileNumber, extensionCounter, ipNumber);

        assert (interestedPartiesAddressesList.size() > 0);
        this.printData(interestedPartiesAddressesList);
    }

    /**
     * Printing method
     *
     * @param Collection of InterestedPartiesAddresses
     */
    private void printData(List<InterestedPartiesAddresses> interestedPartiesAddressesList) {

        System.out.println("InterestedPartiesAddresses Data: ");
        System.out.println("=============================");
        for (InterestedPartiesAddresses interestedPartiesAddresses : interestedPartiesAddressesList) {

            // This will get the InterestedPartiesAddresses data

            System.out
                .println("InterestedPartiesAddresses File Number : " + interestedPartiesAddresses.getFileNumber());
            System.out.println(
                "InterestedPartiesAddresses Extension Counter: " + interestedPartiesAddresses.getExtensionCounter());

        }
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void saveInterestedPartiesAddressesMinimalTest() {
        InterestedPartiesAddresses address = new InterestedPartiesAddresses();
        Application application = applicationDao.getApplication(111, 0);
        assertNotNull("Sample application 111 null, review test", application);
        address.setFileNumber(application.getFileNumber());
        address.setExtensionCounter(application.getExtensionCounter());
        assertNotNull(application.getInterestedParties());
        assertTrue(application.getInterestedParties().size() > 0);
        // Just reuse first ip found
        InterestedParty ip = application.getInterestedParties().iterator().next();
        address.setIpNumber(ip.getIpNumber());
        address.setAddressType(AddressType.SERVICE.getValue());
        Integer originalTotal = ip.getContact().getInterestedPartiesAddresses().size();
        interestedPartiesAddressesDao.saveInterestedPartiesAddresses(address);

        List<InterestedPartiesAddresses> retrievedAddresses = interestedPartiesAddressesDao
            .getInterestedPartiesAddresses(address.getFileNumber(), address.getExtensionCounter(),
                address.getIpNumber());
        InterestedPartiesAddresses detachedAddress = new InterestedPartiesAddresses();
        // Need to do a copy since Hibernate sets address and retrievedAddresses to the same instance...
        BeanUtils.copyProperties(address, detachedAddress);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        assertNotNull(retrievedAddresses);
        assertEquals(originalTotal + 1, retrievedAddresses.size());
        for (InterestedPartiesAddresses interestedPartiesAddress : retrievedAddresses) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(interestedPartiesAddress);

            if (address.getAddressType().equals(interestedPartiesAddress.getAddressType())) {

                assertEquals(detachedAddress, interestedPartiesAddress);
            }
        }

    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void saveInterestedPartiesAddressesMaximalTest() {
        InterestedPartiesAddresses address = new InterestedPartiesAddresses();
        Application application = applicationDao.getApplication(111, 0);
        assertNotNull("Sample application 111 null, review test", application);
        address.setFileNumber(application.getFileNumber());
        address.setExtensionCounter(application.getExtensionCounter());
        assertNotNull(application.getInterestedParties());
        assertTrue(application.getInterestedParties().size() > 0);
        // Just reuse first ip found
        InterestedParty ip = application.getInterestedParties().iterator().next();
        address.setIpNumber(ip.getIpNumber());
        address.setAddressType(AddressType.SERVICE.getValue());
        address.setAddress(
            "Some long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long addressSome long address"
                + System.lineSeparator()
                + "Some long addressSome long addressSome long addressSome long addressSome long");
        address.setCountryProvince("AA");
        address.setPostalCode("AAAAAA");
        Integer originalTotal = ip.getContact().getInterestedPartiesAddresses().size();
        interestedPartiesAddressesDao.saveInterestedPartiesAddresses(address);

        List<InterestedPartiesAddresses> retrievedAddresses = interestedPartiesAddressesDao
            .getInterestedPartiesAddresses(address.getFileNumber(), address.getExtensionCounter(),
                address.getIpNumber());
        InterestedPartiesAddresses detachedAddress = new InterestedPartiesAddresses();
        // Need to do a copy since Hibernate sets address and retrievedAddresses to the same instance...
        BeanUtils.copyProperties(address, detachedAddress);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        assertNotNull(retrievedAddresses);
        assertEquals(originalTotal + 1, retrievedAddresses.size());
        for (InterestedPartiesAddresses interestedPartiesAddress : retrievedAddresses) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(interestedPartiesAddress);

            if (address.getAddressType().equals(interestedPartiesAddress.getAddressType())) {

                assertEquals(detachedAddress, interestedPartiesAddress);
            }
        }

    }
}
