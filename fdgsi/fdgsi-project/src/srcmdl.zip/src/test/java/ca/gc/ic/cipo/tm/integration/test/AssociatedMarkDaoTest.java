package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AssociatedMarkDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssociatedMark;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AssociatedMarkDaoTest extends TestCase {

    @Autowired
    private AssociatedMarkDao associatedMarkDao;

    @Test
    @Transactional(readOnly = true)
    @Ignore("TODO: Please revisit the test - was failing marking it as ignore to have the build done.")
    public void readAssociatedMarkTest() {
        // Get an application by application number

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(735119));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        List<AssociatedMark> associatedMarks = associatedMarkDao.listAssociatedMarksToPublish(applicationNumber);
        assertTrue(associatedMarks.size() > 0);
        this.printAssociatedMark(associatedMarks);
    }

    /**
     * Printing XML method
     *
     * @param Collection of AssociatedMark
     */
    private void printAssociatedMark(List<AssociatedMark> associatedMarks) {
        System.out.println("<?xml version='1.0' encoding='UTF-8' ?>");
        System.out.println("<root>");
        System.out.println("<rows>");
        for (AssociatedMark associatedMark : associatedMarks) {
            System.out.println("<row>");
            System.out.println(
                "<associatedFileNumber>" + associatedMark.getAssociatedFileNumber() + "</associatedFileNumber>");
            System.out.println("<associatedExtentionCounter>" + associatedMark.getAssociatedExtensionCounter()
                + "</associatedExtentionCounter>");
            System.out.println("<fileNumber>" + associatedMark.getFileNumber() + "</fileNumber>");
            System.out.println("<extentionCounter>" + associatedMark.getExtensionCounter() + "</extentionCounter>");
            System.out.println("</row>");
        }
        System.out.println("</rows>");
        System.out.println("</root>");
    }

}
