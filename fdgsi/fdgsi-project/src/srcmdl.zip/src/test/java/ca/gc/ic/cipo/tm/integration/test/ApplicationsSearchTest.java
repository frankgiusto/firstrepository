package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.search.ApplicationsSearch;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionFactory;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.enumerator.SearchItemType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class ApplicationsSearchTest {

    @Autowired
    @Qualifier("applicationsSearch")
    private ApplicationsSearch applicationsSearch;

    @Test
    @Transactional(readOnly = true)
    public void searchApplicationsByFileNumberUsingEquals() {
        List<Expression> expressions = createSearchExpressions(HibernateOperatorEnum.EQUAL, 2020665, 0, null, null);
        List<Application> applications = applicationsSearch.searchApplications(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicationsByFileNumberUsingLike() {
        List<Expression> expressions = createSearchExpressions(HibernateOperatorEnum.LIKE, 202, 0, null, null);
        List<Application> applications = applicationsSearch.searchApplications(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicationsByFileNumberUsingStartWith() {
        List<Expression> expressions = createSearchExpressions(HibernateOperatorEnum.START_WITH, 202, 0, null, null);
        List<Application> applications = applicationsSearch.searchApplications(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicationsByFileNumberUsingEndsWith() {
        List<Expression> expressions = createSearchExpressions(HibernateOperatorEnum.END_WITH, 202, 0, null, null);
        List<Application> applications = applicationsSearch.searchApplications(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicationsByFileNumberAndRegistrationNumber() {
        List<Expression> expressions = createSearchExpressions(HibernateOperatorEnum.EQUAL, 2017223, 0, 980904, null);
        List<Application> applications = applicationsSearch.searchApplications(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchApplicationsByFileNumberAndRegistrationNumberAndLegislation() {
        List<Expression> expressions = createSearchExpressions(HibernateOperatorEnum.EQUAL, 2017223, 0, 980904, 1);
        List<Application> applications = applicationsSearch.searchApplications(expressions, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
    }

    private List<Expression> createSearchExpressions(HibernateOperatorEnum operatorEnum, Integer fileNumber,
                                                     Integer extCounter, Integer registrationNumber,
                                                     Integer legislation) {

        List<Expression> expressions = new ArrayList<>();

        Integer value = null;
        Expression expression = null;
        // File number
        if (fileNumber != null) {
            value = fileNumber;
            expression = makeExpression(SearchItemType.APPLICATION_NUMBER.dbColName("AP"),
                SearchItemType.APPLICATION_NUMBER.namedParamName(), operatorEnum, value);
            expressions.add(expression);
        }

        // Extension counter
        if (extCounter != null) {
            value = extCounter;
            expression = makeExpression(SearchItemType.EXTENSION_COUNTER.dbColName("AP"),
                SearchItemType.EXTENSION_COUNTER.namedParamName(), operatorEnum, value);
            expressions.add(expression);
        }

        // registration number
        if (registrationNumber != null) {

            value = registrationNumber;
            expression = makeExpression(SearchItemType.REGISTRATION_NUMBER.dbColName("AP"),
                SearchItemType.REGISTRATION_NUMBER.namedParamName(), operatorEnum, value);
            expressions.add(expression);
        }

        // legislation
        if (legislation != null) {
            value = legislation;
            expression = makeExpression(SearchItemType.LEGISLATION.dbColName("AP"),
                SearchItemType.LEGISLATION.namedParamName(), operatorEnum, value);
            expressions.add(expression);
        }

        return expressions;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      Object value) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            value);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      List<Object> values) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            values);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

}
