package ca.gc.ic.cipo.tm.integration.test;

import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ClaimTextDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ClaimText;
import ca.gc.ic.cipo.tm.model.ClaimTextId;
import junit.framework.TestCase;

/**
 * I cannot save using the DAO, so integration test done using application #490986, will fail if modified
 *
 * @author martinr3
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = false)
@Rollback(true)
public class ClaimTextDaoTest extends TestCase {

    @Autowired
    ClaimTextDao claimTextDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    public void testGetClaimTextIntegerInteger() {
        Set<ClaimText> claimTexts = claimTextDao.getClaimText(490986, 0);
        assertEquals(1, claimTexts.size());
        ClaimText foundClaim = claimTexts.iterator().next();
        for (Field field : ClaimText.class.getDeclaredFields()) {

            try {
                if (field.isAccessible() && field.get(foundClaim) == null) {
                    fail("null field");
                }
            } catch (IllegalArgumentException | IllegalAccessException e) {
                fail("review test");
                e.printStackTrace();
            }
        }

    }

    @Test
    public void testGetClaimTextIntegerIntegerIntegerInteger() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao.getClaimText(490986, 0, 11, 1);
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

    @Test
    public void testGetClaimTextIntegerIntegerIntegerIntegerInteger() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao.getClaimText(490986, 0, 11, 1, 0);
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

    @Test
    public void testGetClaimTextApplicationNumber() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao.getClaimText(new ApplicationNumber(490986, 0));
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

    @Test
    public void testGetClaimTextApplication() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao
            .getClaimText(claimTextsBench.iterator().next().getClaims().getApplication());
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

    @Test
    public void testGetClaimTextApplicationNumberIntegerInteger() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao
            .getClaimText(claimTextsBench.iterator().next().getClaims().getApplication(), 11, 1);
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

    @Test
    public void testGetClaimTextApplicationNumberIntegerIntegerInteger() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao
            .getClaimText(claimTextsBench.iterator().next().getClaims().getApplication(), 11, 1, 0);
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

    @Test
    public void testGetClaimTextClaimTextId() {
        Set<ClaimText> claimTextsBench = claimTextDao.getClaimText(490986, 0);
        Set<ClaimText> claimTexts = claimTextDao.getClaimText(new ClaimTextId(490986, 0, 11, 1, 0));
        assertEquals(1, claimTexts.size());
        Set<ClaimText> detachedClaims = new HashSet<ClaimText>();
        // Need to do a copy since Hibernate sets claimTextsBench and claimTexts to the same instance...
        BeanUtils.copyProperties(claimTextsBench, detachedClaims);

        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(claimTexts.iterator().next());

        assertEquals(claimTextsBench, claimTexts);
    }

}
