package ca.gc.ic.cipo.tm.integration.test;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.SearchAdjustedRenewalFeeDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.SearchAdjustedRenewalFee;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/*
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class SearchAdjustedRenewalFeeDaoTest {

    @Autowired
    private SearchAdjustedRenewalFeeDao searchAdjustedRenewalFeeDao;

    @Test
    @Ignore
    public void testForSearchAdjustedRenewalFeeWithApplicationNumber() {
        System.out.println("testForSearchAdjustedRenewalFeeWithApplicationNumber");
        final Integer fileNumber = 1075730;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);

        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addStartDate(createDate(2018, 4, 25))
            .addEndDate(createDate(2018, 4, 25));
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 1);

        printListResults(results);
    }

    @Test
    public void testForSearchAdjustedRenewalFeeWithNonExistingApplicationNumber() {
        // does not exist in DB
        final Integer fileNumber = 1720387123;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber).addStartDate(createDate(2018, 4, 25))
            .addEndDate(createDate(2028, 4, 25));
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithNoApplicationNumberProvidedAlongWithNoDates() {
        // does not exist in DB
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(1);
        applicationNumber.setExtensionCounter(null);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber);
        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 0);
    }

    @Test
    @Ignore
    public void testForSearchAdjustedRenewalFeeUsingRegistrationNumber() {
        System.out.println("testForSearchAdjustedRenewalFeeUsingRegistrationNumber");
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 4, 25)).addEndDate(createDate(2018, 4, 25)).addRegistrationNumber(576086);

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test
    @Ignore
    public void testForSearchAdjustedRenewalFeeUsingApplicantName() {
        System.out.println("testForSearchAdjustedRenewalFeeUsingApplicantName");
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 4, 25)).addEndDate(createDate(2018, 4, 25))
            .addRequestorUserId("MaintFeeAgent1").addApplicantName("colman");

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);

        printListResults(results);
    }

    @Test
    @Ignore
    public void testForSearchAdjustedRenewalFeeUsingTrademarkText() {
        System.out.println("testForSearchAdjustedRenewalFeeUsingTrademarkText");
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 4, 25)).addEndDate(createDate(2018, 4, 25))
            .addRequestorUserId("MaintFeeAgent1").addTrademarkName("fini");

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);

        printListResults(results);
    }

    @Test
    @Ignore
    public void testForSearchAdjustedRenewalFeeUsingStartAndEndDate() {
        System.out.println("testForSearchAdjustedRenewalFeeUsingStartAndEndDate");
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(2018, 4, 1)).addEndDate(createDate(2018, 4, 30))
            .addRequestorUserId("MaintFeeAgent1");

        SearchRegistrationCriteria searchCriteria = builder.build();
        List<SearchAdjustedRenewalFee> results = searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);

        printListResults(results);
    }

    @Test(expected = RuntimeException.class)
    @Ignore
    // TODO: Please revisit this method - the code should three RuntimeException in order to be passed
    public void testForNoSearchCriteria() {
        System.out.println("testForNoSearchCriteria");
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        SearchRegistrationCriteria searchCriteria = builder.build();
        searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(searchCriteria);
    }

    @Test(expected = RuntimeException.class)
    @Ignore
    // TODO: Please revisit this method - the code should three RuntimeException in order to be passed
    public void testForSearchWithNoDatesProvided() {
        System.out.println("testForSearchWithNoDatesProvided");
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        final Integer fileNumber = 1075730;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        builder.addRequestorUserId("MaintFeeAgent1").addApplicationNumber(applicationNumber);
        // builder.addRequestorUserId("TSmartYYY").addApplicantName("bread").addApplicationNumber(applicationNumber);
        searchAdjustedRenewalFeeDao.searchAdjustedRenewalFee(builder.build());
    }

    private Date createDate(int year, int month, int day) {
        Calendar gc = Calendar.getInstance();
        gc.set(year, month - 1, day, 0, 0);
        return gc.getTime();
    }

    private void printListResults(List<SearchAdjustedRenewalFee> results) {
        // for (SearchAdjustedRenewalFee search : results) {
        // System.out.println(search.toString());
        // }
    }

}
