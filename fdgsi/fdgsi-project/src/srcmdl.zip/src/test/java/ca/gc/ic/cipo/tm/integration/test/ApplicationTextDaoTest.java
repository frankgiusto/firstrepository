package ca.gc.ic.cipo.tm.integration.test;

import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationTextDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ApplicationText;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class ApplicationTextDaoTest extends TestCase {

    @Autowired
    ApplicationTextDao applicationTextDao;

    @Test
    public void testGetApplicationTextApplicationNumber() {
        ApplicationNumber applicationNumber = new ApplicationNumber(48157, 0);
        List<ApplicationText> results = applicationTextDao.getApplicationText(applicationNumber);
        Assert.assertNotNull("Check for not null", results);
        Assert.assertTrue("Check for size", results.size() > 0);

    }

    @Test
    @Transactional(readOnly = false)
    public void testSaveApplicationText() {
        ApplicationText applicationText = buildSampleApplicationText();
        applicationTextDao.saveApplicationText(applicationText);
        ApplicationNumber applicationNumber = new ApplicationNumber(111, 0);
        ApplicationText result = applicationTextDao.getApplicationText(applicationNumber,
            ca.gc.ic.cipo.tm.enumerator.ApplicationText.DESCRIPTION_OF_MARK.getValue(), 1);
        assertNotNull("Check for not null", result);
        Assert.assertEquals("Check for text", result.getText(), applicationText.getText());
    }

    @Test(expected = RuntimeException.class)
    public void testGetApplicationTextInvalidApplicationNumber() {
        List<ApplicationText> results = applicationTextDao.getApplicationText(null);
        Assert.assertNotNull("Check for not null", results);
        Assert.assertTrue("Check for size", results.size() > 0);

    }

    /**
     * Test data
     */
    private ApplicationText buildSampleApplicationText() {
        ApplicationText applicationText = new ApplicationText();
        applicationText.setFileNumber(111);
        applicationText.setExtensionCounter(0);
        applicationText.setTextType(ca.gc.ic.cipo.tm.enumerator.ApplicationText.DESCRIPTION_OF_MARK.getValue());
        applicationText.setOriginalInd(1);
        applicationText.setModifiedTimestamp(new Date());
        applicationText.setText("text");
        applicationText.setLanguage(1);
        return applicationText;
    }

}
