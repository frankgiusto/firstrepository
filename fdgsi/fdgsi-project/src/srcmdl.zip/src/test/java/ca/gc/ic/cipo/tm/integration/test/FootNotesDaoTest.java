package ca.gc.ic.cipo.tm.integration.test;

import java.util.Collection;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.enumerator.FootnoteType;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import junit.framework.TestCase;

@Transactional(readOnly = false)
@Rollback(true)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class FootNotesDaoTest extends TestCase {

    @Autowired
    private FootNotesDao footNotesDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    public void testGetFootNotesApplicationNumber() {
        Footnote footnote = buildFootNote();
        Collection<Footnote> retrievedFootnotes = footNotesDao
            .getFootNotes(new ApplicationNumber(footnote.getFileNumber(), footnote.getExtensionCounter()));
        int i = retrievedFootnotes.size();

        footNotesDao.saveFootNote(footnote);
        retrievedFootnotes = footNotesDao
            .getFootNotes(new ApplicationNumber(footnote.getFileNumber(), footnote.getExtensionCounter()));

        assertEquals(i + 1, retrievedFootnotes.size());
    }

    @Test
    public void testGetFootNotesApplicationNumberInteger() {
        Footnote footnote = buildFootNote();
        footNotesDao.saveFootNote(footnote);
        Collection<Footnote> retrievedFootNotes = footNotesDao.getFootNotes(footnote, footnote.getSequenceNumber());
        Footnote detachedFootnote = new Footnote();
        // Need to do a copy since Hibernate sets footnote and retrieved footnote to the same instance...
        BeanUtils.copyProperties(footnote, detachedFootnote);
        // Forces Hibernate to refresh from DB
        assertEquals(1, retrievedFootNotes.size());
        Footnote retrievedFootnote = retrievedFootNotes.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFootnote);
        // TODO check dates and remove lines below
        retrievedFootnote.setDateOfChange(detachedFootnote.getDateOfChange());
        retrievedFootnote.setDateRegistered(detachedFootnote.getDateRegistered());
        assertEquals(detachedFootnote, retrievedFootnote);
    }

    @Test
    public void testGetFootNotesFootnoteId() {
        Footnote footnote = buildFootNote();
        footNotesDao.saveFootNote(footnote);
        Collection<Footnote> retrievedFootnotes = footNotesDao.getFootNotes(footnote);
        Footnote detachedFootnote = new Footnote();
        // Need to do a copy since Hibernate sets footnote and retrieved footnote to the same instance...
        BeanUtils.copyProperties(footnote, detachedFootnote);
        // Forces Hibernate to refresh from DB
        assertEquals(1, retrievedFootnotes.size());
        Footnote retrievedFootnote = retrievedFootnotes.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFootnote);
        // TODO check dates and remove lines below
        retrievedFootnote.setDateOfChange(detachedFootnote.getDateOfChange());
        retrievedFootnote.setDateRegistered(detachedFootnote.getDateRegistered());
        assertEquals(detachedFootnote, retrievedFootnote);
    }

    @Test
    public void testSaveFootNote() {
        Footnote footnote = buildFootNote();
        footNotesDao.saveFootNote(footnote);
        Collection<Footnote> retrievedFootnotes = footNotesDao.getFootNotes(footnote);
        Footnote detachedFootnote = new Footnote();
        // Need to do a copy since Hibernate sets footnote and retrieved footnote to the same instance...
        BeanUtils.copyProperties(footnote, detachedFootnote);
        // Forces Hibernate to refresh from DB
        assertEquals(1, retrievedFootnotes.size());
        Footnote retrievedFootnote = retrievedFootnotes.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFootnote);
        // TODO check dates and remove lines below
        retrievedFootnote.setDateOfChange(detachedFootnote.getDateOfChange());
        retrievedFootnote.setDateRegistered(detachedFootnote.getDateRegistered());
        assertEquals(detachedFootnote, retrievedFootnote);

    }

    /**
     * @return
     */
    private Footnote buildFootNote() {
        Footnote footnote = new Footnote();
        footnote.setFileNumber(111);
        footnote.setExtensionCounter(0);
        footnote.setSequenceNumber(999);
        footnote.setType(FootnoteType.ADDITIONAL_GOODS.getValue());
        footnote.setDateOfChange(new Date());
        footnote.setDateRegistered(new Date());
        footnote.setText(
            "To delete the following wares: \"Financial products, namely real estate investment funds, and investment products related hereto; Insurance products namely critical illness, medical and disability insurance and annuities\"; and the following services:  \"Financial services namely investment and retirement services namely investment and portfolio management services, investment counselling services, real estate investment advice and property management services, and tax registered plans; mutual fund services namely mutual fund brokerage; mutual fund investment and mutual fund distribution; services related to the management of pooled funds and pension funds; securities brokerage services; services related to administration of assets namely custody, securities administration, financial reporting, securities lending and other value added services related to the said administration of assets; trust and estate services; credit services namely credit cards, loans and mortgages; deposit services namely savings, chequing and guaranteed investment accounts; currency services namely foreign exchange; Disability Insurance, Critical Illness Insurance, Long Term Care Insurance, Living Benefit Insurance, Health Insurance, Dental Insurance, Prescription Medication Insurance, Accidental Death and Dismemberment Insurance, Travel Insurance; Investment Brokerage in the field of Mutual Funds, Segregated Funds, Term Deposits/GIC's, RRIF's, Annuities, Registered Retirement Savings Plans, Registered Education Savings Plans, Wealth Management Services; Disability Insurance, Critical Illness Insurance, Long Term Care Insurance, Living Benefit Insurance, Health Insurance, Dental Insurance, Prescription Medication Insurance, Accidental Death and Dismemberment Insurance, Travel Insurance; Online Investment Brokerage in the field of Mutual Funds, Segregated Funds, Term Deposits/GIC's, RRIF's, Annuities, Registered Retirement Saving Plans, Registered Education Savings Plans, Wealth Management......");
        return footnote;
    }

}
