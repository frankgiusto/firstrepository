package ca.gc.ic.cipo.tm.integration.test;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.serial.SerialBlob;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.TransactionInboxAttachmentDao;
import ca.gc.ic.cipo.tm.dao.TransactionInboxDao;
import ca.gc.ic.cipo.tm.enumerator.AttachmentFormatType;
import ca.gc.ic.cipo.tm.enumerator.AttachmentType;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FiledTransaction;
import ca.gc.ic.cipo.tm.model.TransactionInbox;
import ca.gc.ic.cipo.tm.model.TransactionInboxAttachment;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class TransactionInboxAttachmentDaoTest {

    @Autowired
    TransactionInboxAttachmentDao transactionInboxAttachmentDao;

    @Autowired
    TransactionInboxDao transactionInboxDao;

    /** PDF attachment type */
    private static final int PDF_ATTACHMENT_TYPE = 3;

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void getTransactionAttachmentsMap() {
        TransactionInboxAttachment attachment = createTransactionInboxAttachment(createTransactionInbox());
        List<TransactionInboxAttachment> retrievedInboxAttachments = transactionInboxAttachmentDao
            .getTransactionAttachmentList(attachment.getTransactionInboxSeqNum());

        Assert.assertNotNull(retrievedInboxAttachments);
        Assert.assertEquals(2, retrievedInboxAttachments.size());

        Map<Integer, List<TransactionInboxAttachment>> attachmentsMap = transactionInboxAttachmentDao
            .getTransactionAttachmentsMap(attachment.getTransactionInboxSeqNum());
        Assert.assertNotNull(attachmentsMap);
        Assert.assertEquals(2, attachmentsMap.size());
        Assert.assertNotNull(attachmentsMap.get(PDF_ATTACHMENT_TYPE));
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testSaveTransactionAttachement() {

        TransactionInboxAttachment attachment = createTransactionInboxAttachment(createTransactionInbox());

        TransactionInboxAttachment retrievedInboxAttachment = transactionInboxAttachmentDao
            .getTransactionAttachment(attachment.getAttachmentSeqNum());

        Assert.assertNotNull(retrievedInboxAttachment);
        Assert.assertEquals(attachment, retrievedInboxAttachment);

        List<TransactionInboxAttachment> retrievedInboxAttachments = transactionInboxAttachmentDao
            .getTransactionAttachmentList(attachment.getTransactionInboxSeqNum());
        Assert.assertNotNull(retrievedInboxAttachments);
        Assert.assertEquals(2, retrievedInboxAttachments.size());
        // Assert.assertEquals(attachment, retrievedInboxAttachments.get(0));
    }

    private TransactionInbox createTransactionInbox() {
        TransactionInbox inbox = new TransactionInbox();
        inbox.setServiceItemNum(1);
        inbox.setTransactionType(1);
        inbox.setFileNumber(111);
        inbox.setTransactionStatusCode(2);
        transactionInboxDao.saveTransactionItem(inbox);
        return inbox;
    }

    private TransactionInboxAttachment createTransactionInboxAttachment(TransactionInbox inbox) {

        TransactionInboxAttachment attachment = new TransactionInboxAttachment();
        attachment.setTransactionInboxSeqNum(inbox.getTransactionInboxSeqNum());
        // 3 is for PDF
        attachment.setAttachmentType(AttachmentType.PDF.attachmentType());

        attachment.setAttachmentFileName("ApplicationForm.pdf");
        attachment.setAttachmentDescription("Application form");
        attachment.setAtachmentFormat(AttachmentFormatType.PDF.attachmentFormatType());// PDF

        attachment.setAttachmentFileBlob(createBlob());
        attachment.setCreatedDate(new Date());
        attachment.setCreatedBy("Tester");
        attachment.setLastChangedDate(new Date());
        transactionInboxAttachmentDao.saveTransactionAttachment(attachment);

        attachment = new TransactionInboxAttachment();
        attachment.setTransactionInboxSeqNum(inbox.getTransactionInboxSeqNum());
        // 2 is for receipt
        attachment.setAttachmentType(AttachmentType.PAYMENT_RECEIPT.attachmentType());

        attachment.setAttachmentFileName("receipt_111.pdf");
        attachment.setAttachmentDescription("Sample payment receipt");
        attachment.setAtachmentFormat(AttachmentFormatType.PDF.attachmentFormatType());// PDF

        attachment.setAttachmentFileBlob(createBlob());
        attachment.setCreatedDate(new Date());
        attachment.setCreatedBy("Tester");
        attachment.setLastChangedDate(new Date());
        transactionInboxAttachmentDao.saveTransactionAttachment(attachment);
        return attachment;
    }

    /**
     * @return a newly created Blob object back to the caller
     */
    public Blob createBlob() {
        final String path = "src/test/resources/samples/test.pdf";
        try (InputStream is = new FileInputStream(path); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            IOUtils.copy(is, bos);
            Blob attachmentFileBlob = new SerialBlob(bos.toByteArray());
            return attachmentFileBlob;
        } catch (IOException | SQLException ex) {
            Assert.fail(ex.getMessage());
        }
        return null;
    }

    @Test
    @Transactional(readOnly = true)
    public void retrieveTransactionXmlBlob() {
        FiledTransaction filedTransaction = new FiledTransaction();
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(1946203);
        applicationNumber.setExtensionCounter(0);
        filedTransaction.setApplicationNumber(applicationNumber);
        filedTransaction.setTransactionType(301);
        filedTransaction.setEcReferenceNumber(20735972);
        filedTransaction.setMailRoomDate(toDate(2018, Calendar.DECEMBER, 19));
        TransactionInboxAttachment result = this.transactionInboxAttachmentDao
            .retrieveTransactionXmlBlob(filedTransaction);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.getAttachmentFileBlob() instanceof Blob);
    }

    @Test
    @Transactional(readOnly = true)
    public void retrieveTransactionPDFBlob() {
        FiledTransaction filedTransaction = new FiledTransaction();
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(1946203);
        applicationNumber.setExtensionCounter(0);
        filedTransaction.setApplicationNumber(applicationNumber);
        filedTransaction.setTransactionType(301);
        filedTransaction.setEcReferenceNumber(20735972);
        filedTransaction.setMailRoomDate(toDate(2018, Calendar.DECEMBER, 19));

        TransactionInboxAttachment result = this.transactionInboxAttachmentDao
            .retrieveApplicationFormBlob(filedTransaction);
        Assert.assertNotNull(result);
        Assert.assertTrue(result.getAttachmentFileBlob() instanceof Blob);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getTransactionAttachmentMinimumInfoList() {
        TransactionInbox inbox = createTransactionInbox();
        createTransactionInboxAttachment(inbox);
        List<TransactionInboxAttachment> results = this.transactionInboxAttachmentDao
            .getTransactionAttachmentMinimumInfoList(23478);
        Assert.assertNotNull(results);
        Assert.assertEquals(2, results.size());
        for (TransactionInboxAttachment eachAtt : results) {
            System.out.println(eachAtt.getAttachmentSeqNum() + " " + eachAtt.getAttachmentType() + " "
                + eachAtt.getAttachmentFileName());
        }
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void getAllTransactionAttachmentMinimumInfoList() {
        TransactionInbox inbox = createTransactionInbox();
        createTransactionInboxAttachment(inbox);
        List<TransactionInboxAttachment> results = this.transactionInboxAttachmentDao
            .getAllTransactionAttachmentMinimumInfoList(23478);
        Assert.assertNotNull(results);
        for (TransactionInboxAttachment eachAtt : results) {
            System.out.println(eachAtt.getAttachmentSeqNum() + " " + eachAtt.getAttachmentType() + " "
                + eachAtt.getAttachmentFileName());
        }
    }

    private Date toDate(int year, int month, int day) {
        GregorianCalendar cal = new GregorianCalendar(year, month, day);
        return cal.getTime();
    }
}
