package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesClaimDao;
import ca.gc.ic.cipo.tm.dao.GoodsServicesDao;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.Pair;
import ca.gc.ic.cipo.tm.enumerator.ClaimType;
import ca.gc.ic.cipo.tm.enumerator.GoodServiceType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = false)
@Rollback(true)
public class GoodsServicesClaimDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private GoodsServicesClaimDao goodsServicesClaimDao;

    @Autowired
    private GoodsServicesDao goodsServicesDao;

    @Autowired
    private ClaimDao claimDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    public void testGetGoodServiceClaimsApplicationNumber() {
        Application application = applicationDao.getApplication(111, 0);
        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaims(application);
        assertNotNull(results);
        int initialCount = results.size();
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao
            .getGoodServiceClaims(gsClaim.getClaim().getApplication());
        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetGoodServiceClaimsApplicationNumber2() {
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao
            .getGoodServiceClaims(new ApplicationNumber(1760085, 0));
        Assert.assertNotNull(retrievedGsClaims);
    }

    @Test
    public void testGetGoodServiceClaimsApplicationNumberOrderByClaimType() {
        Application application = applicationDao.getApplication(111, 0);
        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsOrderByClaimType(application);
        assertNotNull(results);
        int initialCount = results.size();
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao
            .getGoodServiceClaims(gsClaim.getClaim().getApplication());
        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetOrderedGoodServiceClaims() {
        Application application = applicationDao.getApplication(111, 0);
        MultiValueMap<Pair<Integer, Integer>, GoodServiceClaim> results = goodsServicesClaimDao
            .getOrderedGoodServiceClaims(application);
        assertNotNull(results);

        int initialCount = results.size();
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao
            .getGoodServiceClaims(gsClaim.getClaim().getApplication());
        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetGoodServiceClaimsByGSKeyApplicationNumberIntegerInteger() {
        Application application = applicationDao.getApplication(111, 0);
        GoodService goodService = buildGoodService(application);
        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application,
            goodService.getType(), goodService.getNumber());
        assertNotNull(results);
        int initialCount = results.size();

        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());

        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(
            gsClaim.getClaim().getApplication(), goodService.getType(), goodService.getNumber());

        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetGoodServiceClaimsByGSKeyApplicationNumberGoodServiceId() {
        Application application = applicationDao.getApplication(111, 0);
        GoodService goodService = buildGoodService(application);
        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByGSKey(application, goodService);
        Assert.assertNotNull(results);
        int initialCount = results.size();
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());

        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao
            .getGoodServiceClaimsByGSKey(gsClaim.getClaim().getApplication(), goodService);
        // TODO uncomment when fixed, dao does not work as expected (when passing parameters)
        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetGoodServiceClaimsByClaimKeyApplicationNumberIntegerInteger() {
        Application application = applicationDao.getApplication(111, 0);
        Claim claim = buildClaim(application, ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByClaimKey(application,
            claim.getClaimType(), claim.getClaimNumber());
        Assert.assertNotNull(results);
        int initialCount = results.size();
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao.getGoodServiceClaimsByClaimKey(application,
            gsClaim.getClaimType(), gsClaim.getClaimNumber());
        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetGoodServiceClaimsByClaimKeyApplicationNumberClaimId() {
        Application application = applicationDao.getApplication(111, 0);
        Claim claim = buildClaim(application, ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> results = goodsServicesClaimDao.getGoodServiceClaimsByClaimKey(application,
            claim.getClaimType(), claim.getClaimNumber());
        Assert.assertNotNull(results);
        int initialCount = results.size();
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao.getGoodServiceClaimsByClaimKey(application,
            gsClaim.getClaim());
        assertEquals(initialCount + 1, retrievedGsClaims.size());
    }

    @Test
    public void testGetGoodServiceClaimsByKeysApplicationNumberIntegerIntegerIntegerInteger() {
        Application application = applicationDao.getApplication(111, 0);
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        GoodServiceClaim result = goodsServicesClaimDao.getGoodServiceClaimsByKeys(application, gsClaim.getType(),
            gsClaim.getNumber(), gsClaim.getClaimType(), gsClaim.getClaimNumber());
        Assert.assertNotNull(result);
    }

    @Test
    public void testGetGoodServiceClaimsByKeysApplicationNumberClaimIdGoodServiceId() {
        Application application = applicationDao.getApplication(111, 0);
        Claim claim = buildClaim(application, ClaimType.DECLARATION_OF_USE.getValue());
        GoodService gs = buildGoodService(application);
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        GoodServiceClaim retrievedGsClaim = goodsServicesClaimDao.getGoodServiceClaimsByKeys(application, claim, gs);
        assertEquals(gsClaim, retrievedGsClaim);
    }

    @Transactional(readOnly = false)
    @Test
    public void testSaveGoodServiceClaim() {
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.DECLARATION_OF_USE.getValue());
        GoodServiceClaim retrievedGsClaim = goodsServicesClaimDao.getGoodServiceClaimsByKeys(
            gsClaim.getClaim().getApplication(), gsClaim.getGoodService().getType(),
            gsClaim.getGoodService().getNumber(), gsClaim.getClaimType(), gsClaim.getClaimNumber());

        GoodServiceClaim detachedGsClaim = getDetachedGsClaim(gsClaim);
        assertNotNull(detachedGsClaim);
        // Forces Hibernate to refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedGsClaim);
        assertEquals(detachedGsClaim, retrievedGsClaim);
    }

    @Transactional(readOnly = false)
    @Test
    public void getGoodServiceClaimsByClaimType() {
        GoodServiceClaim gsClaim = saveNewGoodServiceClaim(ClaimType.PRIORITY_FILING.getValue());
        List<GoodServiceClaim> retrievedGsClaims = goodsServicesClaimDao.getGoodServiceClaimsByGSKeyAndClaimType(
            gsClaim.getClaim().getApplication(), gsClaim.getGoodService().getType(),
            gsClaim.getGoodService().getNumber(), ClaimType.PRIORITY_FILING.getValue());

        Assert.assertNotNull(retrievedGsClaims);
        GoodServiceClaim detachedGsClaim = getDetachedGsClaim(gsClaim);
        for (GoodServiceClaim eachGoodServiceClaim : retrievedGsClaims) {
            transactionManager.getSessionFactory().getCurrentSession().refresh(eachGoodServiceClaim);
            assertEquals(detachedGsClaim, eachGoodServiceClaim);
            Assert.assertEquals(eachGoodServiceClaim.getClaimType(), ClaimType.PRIORITY_FILING.getValue());
        }
    }

    private GoodServiceClaim getDetachedGsClaim(GoodServiceClaim gsClaim) {
        GoodServiceClaim detachedGsClaim = new GoodServiceClaim();
        // Need to do a copy since Hibernate sets gsClaim and detachedGsClaim to the same instance...
        BeanUtils.copyProperties(gsClaim, detachedGsClaim);
        return detachedGsClaim;
    }

    private GoodServiceClaim saveNewGoodServiceClaim(Integer claimType) {
        Application application = applicationDao.getApplication(111, 0);
        Claim claim = buildClaim(application, claimType);
        GoodService goodService = buildGoodService(application);
        GoodServiceClaim gsClaim = buildGsClaim(claim, goodService);
        claimDao.saveClaim(claim);
        goodsServicesDao.saveGoodsServices(goodService);
        goodsServicesClaimDao.saveGoodServiceClaim(gsClaim);
        return gsClaim;
    }

    private GoodService buildGoodService(Application application) {
        GoodService goodService = new GoodService();
        goodService.setNumber(998);
        goodService.setType(GoodServiceType.GOODS.getValue());
        goodService.setApplication(application);
        goodService.setFileNumber(application.getFileNumber());
        goodService.setExtensionCounter(application.getExtensionCounter());
        return goodService;
    }

    private Claim buildClaim(Application application, Integer claimType) {
        Claim claim = new Claim();
        claim.setApplication(application);
        claim.setClaimType(claimType);
        claim.setClaimNumber(999);
        claim.setFileNumber(claim.getApplication().getFileNumber());
        claim.setExtensionCounter(claim.getApplication().getExtensionCounter());
        claim.setLanguage(1);
        return claim;
    }

    private GoodServiceClaim buildGsClaim(Claim claim, GoodService goodService) {
        GoodServiceClaim gsClaim = new GoodServiceClaim();
        gsClaim.setClaim(claim);
        gsClaim.setGoodService(goodService);
        gsClaim.setFileNumber(gsClaim.getClaim().getApplication().getFileNumber());
        gsClaim.setExtensionCounter(gsClaim.getClaim().getApplication().getExtensionCounter());
        gsClaim.setClaimType(claim.getClaimType());
        gsClaim.setType(goodService.getType());
        gsClaim.setNumber(goodService.getNumber());
        gsClaim.setClaimNumber(claim.getClaimNumber());
        return gsClaim;
    }
}
