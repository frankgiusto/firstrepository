package ca.gc.ic.cipo.tm.integration.test;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.DocumentStoredDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DocumentStored;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional
public class DocumentStoredDaoTest extends TestCase {

    @Autowired
    private DocumentStoredDao documentStoredDao;

    @Test
    public void readDocumentStoredTest() {
        // Get an application by application number

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(1195295));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        List<DocumentStored> documentsStored = documentStoredDao.getDocumentStored(applicationNumber);
        DocumentStored ds = documentsStored.get(0);
        java.sql.Blob blob = ds.getDocumentBlob();
        byte[] bytes = null;
        try {
            bytes = blob.getBytes(1, (int) blob.length());
            assertTrue(bytes.length > 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        assertTrue(documentsStored.size() > 0);
        this.printAssociatedMark(documentsStored);
    }

    /**
     * Printing XML method
     *
     * @param Collection
     */
    private void printAssociatedMark(List<DocumentStored> documentsStored) {
        System.out.println("<?xml version='1.0' encoding='UTF-8' ?>");
        System.out.println("<root table=DocumentStored>");
        System.out.println("<rows>");
        for (DocumentStored documentStored : documentsStored) {
            System.out.println("<row>");
            System.out.println("<autorityId>" + documentStored.getAuthorityId() + "</authorityId>");
            System.out.println("<documentType>" + documentStored.getDocumentType() + "</documentType>");
            System.out.println("<outputCode>" + documentStored.getOutputCode() + "</outputCode>");
            System.out.println("</row>");
        }
        System.out.println("</rows>");
        System.out.println("</root>");
    }

}
