/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AuthoritiesDao;
import ca.gc.ic.cipo.tm.dao.PhysicalFilesDao;
import ca.gc.ic.cipo.tm.enumerator.FileType;
import ca.gc.ic.cipo.tm.model.PhysicalFiles;
import junit.framework.TestCase;

/**
 * This class test the PhysicalFilesDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class PhysicalFilesDaoTest extends TestCase {

    @Autowired
    private PhysicalFilesDao physicalFilesDao;

    @Autowired
    private AuthoritiesDao authoritiesDao;

    /**
     * Printing method
     *
     * @param Collection of physical files.
     */
    private void printData(Set<PhysicalFiles> physicalFiles) {

        System.out.println("Physical Files Data: ");
        System.out.println("=============================");
        for (PhysicalFiles physicalFile : physicalFiles) {
            // This will get the specific physical files information

            System.out.println("Physical Files File Type: " + physicalFile.getFileType());

            System.out.println("Physical Files File Number: " + physicalFile.getFileNumber());

            System.out.println("Physical Files Location Authority ID: " + physicalFile.getLocationAuthorityId());

            System.out.println("Physical Files Transit Ind: " + physicalFile.getTransitInd());

            System.out.println("Physical File Archival Locator: " + physicalFile.getArchivalLocator());

            System.out.println("Physical Files Disposed Date: " + physicalFile.getDisposedDate());

            System.out.println("Physical File Ascession No: " + physicalFile.getAscessionNo());

        }
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testSavePhysicalFiles() {
        PhysicalFiles physicalFile = buildPhysicalFile();
        physicalFilesDao.savePhysicalFiles(physicalFile);
        Set<PhysicalFiles> retrievedPhysicalFiles = physicalFilesDao.getPhysicalFiles(physicalFile.getFileNumber(),
            physicalFile.getFileType(), physicalFile.getLocationAuthorityId());
        assertNotNull(retrievedPhysicalFiles);
    }

    /**
     * @return
     */
    private PhysicalFiles buildPhysicalFile() {
        PhysicalFiles physicalFile = new PhysicalFiles();
        physicalFile.setFileNumber(111);
        physicalFile.setFileType(FileType.TRADE_MARK.getValue());
        physicalFile.setTransitInd(0);
        physicalFile.setLocationAuthorityId("ECTEST1");
        physicalFile.setAuthorityId("ECTEST1");
        return physicalFile;
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetPhysicalFilesFileNumberFileType() {
        PhysicalFiles physicalFile = buildPhysicalFile();
        physicalFilesDao.savePhysicalFiles(physicalFile);
        Set<PhysicalFiles> retrievedPhysicalFiles = physicalFilesDao.getPhysicalFiles(physicalFile.getFileNumber(),
            physicalFile.getFileType());
        assertNotNull(retrievedPhysicalFiles);
        assertEquals(1, retrievedPhysicalFiles.size());
        assertEquals(physicalFile, retrievedPhysicalFiles.iterator().next());

    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetPhysicalFilesFileNumberFileTypeLocationAuthorityId() {
        PhysicalFiles physicalFile = buildPhysicalFile();
        physicalFilesDao.savePhysicalFiles(physicalFile);
        Set<PhysicalFiles> retrievedPhysicalFiles = physicalFilesDao.getPhysicalFiles(physicalFile.getFileNumber(),
            physicalFile.getFileType(), physicalFile.getLocationAuthorityId());
        assertNotNull(retrievedPhysicalFiles);
    }
}
