/*
 * Copyright (c) 2019 CIPO Created on Feb 12, 2019
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.TradeMarkLockDao;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.TradeMarkLock;
import junit.framework.TestCase;

/**
 * Test cases for the Intrepid locking mechanism.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = false)
@Rollback(true)
public class TradeMarkLockDaoTest extends TestCase {

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Autowired
    private TradeMarkLockDao lockDao;

    @Test
    public void testAcquireLockSuccess() {
        TradeMarkLock lock = lockDao.acquireLock(2059350, 0, "MADRID");
        assertNotNull(lock);
        assertEquals(new Integer(111), lock.getFileNumber());
        assertEquals(new Integer(0), lock.getExtensionCounter());
        assertEquals("testUser", lock.getUserName());
    }

    @Test
    public void testAcquireLockExistsSuccess() {
        // Test where the same user attempts to acquire his existing lock
        TradeMarkLock lock1 = lockDao.acquireLock(111, 0, "testUser1");
        assertNotNull(lock1);
        assertEquals(new Integer(111), lock1.getFileNumber());
        assertEquals(new Integer(0), lock1.getExtensionCounter());
        assertEquals("testUser1", lock1.getUserName());

        // For the purposes of this test, evict the first lock since two with the same ID can't be in the same Hibernate
        // session
        transactionManager.getSessionFactory().getCurrentSession().evict(lock1);

        TradeMarkLock lock2 = lockDao.acquireLock(111, 0, "testUser1");
        assertNotNull(lock2);
        assertEquals(new Integer(111), lock2.getFileNumber());
        assertEquals(new Integer(0), lock2.getExtensionCounter());
        assertEquals("testUser1", lock2.getUserName());
    }

    @Test(expected = DataAccessException.class)
    public void testAcquireLockExistFailure() {
        // Acquire the lock for a test user
        TradeMarkLock lock1 = lockDao.acquireLock(111, 0, "testUser1");
        assertNotNull(lock1);

        // Attempt to acquire the same lock for another user -- a DataAccessException is expected here
        lockDao.acquireLock(111, 0, "testUser2");
    }

    @Test
    public void testReleaseLockExists() {
        // Acquire the lock for a test user
        TradeMarkLock lock1 = lockDao.acquireLock(333, 0, "testUser1");
        assertNotNull(lock1);

        // Now release the lock
        TradeMarkLock lockReleased = lockDao.releaseLock(333, 0);
        assertNotNull(lockReleased);
        assertEquals(new Integer(333), lockReleased.getFileNumber());
        assertEquals(new Integer(0), lockReleased.getExtensionCounter());
    }

    @Test
    public void testReleaseLockNotExists() {
        // Release the lock that has not been acquired
        TradeMarkLock lockReleased = lockDao.releaseLock(1010, 0);
        assertNotNull(lockReleased);
        assertEquals(new Integer(1010), lockReleased.getFileNumber());
        assertEquals(new Integer(0), lockReleased.getExtensionCounter());
    }

    @Test
    public void testListLocksByFileNumber() {
        // Add some lock data for testing
        lockDao.acquireLock(5001, 0, "testUser1");
        lockDao.acquireLock(5001, 1, "testUser1");
        lockDao.acquireLock(5001, 2, "testUser2");
        lockDao.acquireLock(5001, 3, "testUser4");
        lockDao.acquireLock(5002, 0, "testUser1");
        lockDao.acquireLock(5003, 0, "testUser3");

        List<TradeMarkLock> lockList = lockDao.listLocks(new Integer(5001), null, null);

        assertNotNull(lockList);
        assertEquals(4, lockList.size());
    }

    @Test
    public void testListLocksByFileNumberAndExt() {
        // Add some lock data for testing
        lockDao.acquireLock(5001, 0, "testUser1");
        lockDao.acquireLock(5001, 1, "testUser1");
        lockDao.acquireLock(5001, 2, "testUser2");
        lockDao.acquireLock(5001, 3, "testUser4");
        lockDao.acquireLock(5002, 0, "testUser1");
        lockDao.acquireLock(5003, 0, "testUser3");

        List<TradeMarkLock> lockList = lockDao.listLocks(new Integer(5001), new Integer(0), null);

        assertNotNull(lockList);
        assertEquals(1, lockList.size());
    }

    @Test
    public void testListLocksByUserName() {
        // Add some lock data for testing
        lockDao.acquireLock(5001, 0, "testUser1");
        lockDao.acquireLock(5001, 1, "testUser1");
        lockDao.acquireLock(5001, 2, "testUser2");
        lockDao.acquireLock(5001, 3, "testUser4");
        lockDao.acquireLock(5002, 0, "testUser1");
        lockDao.acquireLock(5003, 0, "testUser3");

        List<TradeMarkLock> lockList = lockDao.listLocks(null, null, "testUser1");

        assertNotNull(lockList);
        assertEquals(3, lockList.size());
    }

    @Test
    public void testListLocksByUserNameAndFileNumber() {
        // Add some lock data for testing
        lockDao.acquireLock(5001, 0, "testUser1");
        lockDao.acquireLock(5001, 1, "testUser1");
        lockDao.acquireLock(5001, 2, "testUser2");
        lockDao.acquireLock(5001, 3, "testUser4");
        lockDao.acquireLock(5002, 0, "testUser1");
        lockDao.acquireLock(5003, 0, "testUser3");

        List<TradeMarkLock> lockList = lockDao.listLocks(new Integer(5001), null, "testUser1");

        assertNotNull(lockList);
        assertEquals(2, lockList.size());
    }
}
