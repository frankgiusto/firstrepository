package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCitedMarksDao;
import ca.gc.ic.cipo.tm.dao.OppositionGroundsDao;
import ca.gc.ic.cipo.tm.model.OppositionCitedMarks;
import ca.gc.ic.cipo.tm.model.OppositionGrounds;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionCitedMarksDaoTest {

    @Autowired
    @Qualifier("oppositionGroundsDao")
    private OppositionGroundsDao oppositionGroundsDao;

    @Autowired
    @Qualifier("oppositionCitedMarksDao")
    private OppositionCitedMarksDao oppositionCitedMarksDao;

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void oppositionCitedMarksInsert() {
        OppositionGrounds oppositionGrounds = new OppositionGrounds();
        oppositionGrounds.setFileNumber(111);
        oppositionGrounds.setExtensionCounter(0);
        oppositionGrounds.setOppCaseNumber(22);
        oppositionGrounds.setOppGroundsCode(2);

        oppositionGroundsDao.saveOppositionGrounds(oppositionGrounds);

        Assert.assertNotNull(oppositionGrounds.getOppositionGroundsSeqId());

        OppositionCitedMarks oppositionCitedMarks = new OppositionCitedMarks();
        oppositionCitedMarks.setCitedFileNumber(1441083);
        oppositionCitedMarks.setCitedExtensionCounter(0);

        oppositionGrounds.getOppositionCitedMarks().add(oppositionCitedMarks);
        oppositionCitedMarks.setOppositionGrounds(oppositionGrounds);

        oppositionCitedMarks.setOppositionGroundsSequence(oppositionGrounds.getOppositionGroundsSeqId());

        oppositionCitedMarksDao.saveOppositionCitedMarks(oppositionCitedMarks);

        transactionManager.getSessionFactory().getCurrentSession().flush();
        Assert.assertNotNull(oppositionCitedMarks);
        Assert.assertTrue("Chec if cited marks is populated with correct sequence ID",
            oppositionCitedMarks.getOppositionGroundsSequence() == oppositionGrounds.getOppositionGroundsSeqId());
    }

    @Test
    @Rollback(true)
    @Transactional(readOnly = false)
    public void oppositionCitedMarksInsertWithFlush() {
        OppositionGrounds oppositionGrounds = new OppositionGrounds();
        oppositionGrounds.setFileNumber(111);
        oppositionGrounds.setExtensionCounter(0);
        oppositionGrounds.setOppCaseNumber(22);
        oppositionGrounds.setOppGroundsCode(2);

        oppositionGroundsDao.saveOppositionGrounds(oppositionGrounds);

        Assert.assertNotNull(oppositionGrounds.getOppositionGroundsSeqId());

        OppositionCitedMarks oppositionCitedMarks = new OppositionCitedMarks();
        oppositionCitedMarks.setCitedFileNumber(1441083);
        oppositionCitedMarks.setCitedExtensionCounter(0);

        oppositionGrounds.getOppositionCitedMarks().add(oppositionCitedMarks);
        oppositionCitedMarks.setOppositionGrounds(oppositionGrounds);

        oppositionCitedMarks.setOppositionGroundsSequence(oppositionGrounds.getOppositionGroundsSeqId());

        oppositionCitedMarksDao.saveOppositionCitedMarks(oppositionCitedMarks);

        transactionManager.getSessionFactory().getCurrentSession().flush();
        Assert.assertNotNull(oppositionCitedMarks);
        Assert.assertTrue("Chec if cited marks is populated with correct sequence ID",
            oppositionCitedMarks.getOppositionGroundsSequence() == oppositionGrounds.getOppositionGroundsSeqId());

    }

}
