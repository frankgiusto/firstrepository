package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.CountryProvinceLookupDao;
import ca.gc.ic.cipo.tm.model.CountryProvince;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class CountryProvincesDaoTest extends TestCase {

    @Autowired
    private CountryProvinceLookupDao countryProvinceLookupDao;

    @Autowired
    @Qualifier("englishCountryProvinceLookupDao")
    private CountryProvinceLookupDao englishCountryProvinceLookupDao;

    @Autowired
    @Qualifier("frenchCountryProvinceLookupDao")
    private CountryProvinceLookupDao frenchCountryProvinceLookupDao;

    @Test
    @Transactional(readOnly = true)
    public void readCoutriesTest() {
        List<CountryProvince> cps = countryProvinceLookupDao.getCountries();
        assertTrue(cps.size() > 0);
        this.printData(cps);

        cps = frenchCountryProvinceLookupDao.getCountries();
        assertTrue(cps.size() > 0);
        this.printData(cps);
    }

    @Test
    @Transactional(readOnly = true)
    public void readCountryByCode() {
        CountryProvince country = countryProvinceLookupDao.getCountry("CA", 1);

        System.out.println("<english>");
        System.out.println("<code>" + country.getCode() + "</code>");
        System.out.println("<description>" + country.getDescription() + "</description>");
        System.out.println("<language>" + country.getLanguage() + "</language>");

        country = countryProvinceLookupDao.getCountry("CA", 2);

        System.out.println("<french>");
        System.out.println("<code>" + country.getCode() + "</code>");
        System.out.println("<description>" + country.getDescription() + "</description>");
        System.out.println("<language>" + country.getLanguage() + "</language>");

    }

    /**
     * Printing XML method
     *
     * @param Collection of Country Province
     */
    private void printData(List<CountryProvince> cps) {
        System.out.println("<?xml version='1.0' encoding='UTF-8' ?>");
        System.out.println("<root>");
        System.out.println("<rows>");
        for (CountryProvince cp : cps) {
            System.out.println("<row>");
            System.out.println("<code>" + cp.getCode() + "</code>");
            System.out.println("<description>" + cp.getDescription() + "</description>");
            System.out.println("<language>" + cp.getLanguage() + "</language>");
            System.out.println("</row>");
        }
        System.out.println("</rows>");
        System.out.println("</root>");
    }

}
