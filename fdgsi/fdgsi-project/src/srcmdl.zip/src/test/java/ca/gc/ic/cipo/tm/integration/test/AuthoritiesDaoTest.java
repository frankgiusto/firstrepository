/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.AuthoritiesDao;
import ca.gc.ic.cipo.tm.dao.CurrentFileActionsDao;
import ca.gc.ic.cipo.tm.enumerator.AuthorityType;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.AgentRepresentativeActions;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.Authorities;
import ca.gc.ic.cipo.tm.model.CurrentFileActions;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import ca.gc.ic.cipo.tm.model.HistoricalFileActions;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.PullingLists;
import junit.framework.TestCase;

/**
 * This class test the AuthoritiesDao Since we cannot save data, we are assuming authority ECTEST1 exists to run tests
 *
 * @author houreich
 *
 */
@Transactional(readOnly = true)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class AuthoritiesDaoTest extends TestCase {

    @Autowired
    private AuthoritiesDao authoritiesDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Autowired
    CurrentFileActionsDao currentFileActionsDao;

    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getAuthorities() {

        /*
         * AssignmentAmendmentWorkSheetsId aaWorkSheetsId = new AssignmentAmendmentWorkSheetsId(); //
         * aaWorkSheetsId.setFileNumber(Integer.valueOf(55287)); //
         * aaWorkSheetsId.setExtensionCounter(Integer.valueOf(0));
         * aaWorkSheetsId.setWorkSheetNumber(Integer.valueOf(975146)); aaWorkSheetsId.setAuthorityId("LACOMBES3");
         *
         * if (authoritiesDao == null) { System.out.println( "authoritiesDao is NULL!!!"); }
         *
         * // Retrieve Authorities Set<Authorities> authorities = authoritiesDao.getAuthorities(aaWorkSheetsId); assert
         * (authorities.size() > 0); this.printData(authorities);
         *
         * // Retrieve Authorities Current File Actions Set<CurrentFileActions> currentFileActions =
         * authoritiesDao.getCurrentFileActions("ARCHIVE", Integer.valueOf(1)); assert (currentFileActions.size() > 0);
         * printCurrentFileActions(currentFileActions);
         *
         * // Retrieve Authorities Historical File Actions Set<HistoricalFileActions> historicalFileActions =
         * authoritiesDao.getHistoricalFileActions("ARCHIVE", "ARCHIVE", Integer.valueOf(5)); assert
         * (historicalFileActions.size() > 0); printHistoricalFileActions(historicalFileActions);
         *
         * // Retrieve Authorities AA Transactions
         *
         * Set<AssignmentAmendmentTransaction> aaTransactions = authoritiesDao
         * .getAssignmentAmendmentTransactions("AMCMILLL1", Integer.valueOf(1013375)); assert (aaTransactions.size() >
         * 0); this.printAATransactions(aaTransactions);
         *
         * // Retrieve Authorities list of Actions Set<Action> actions =
         * authoritiesDao.getActions(Integer.valueOf(134412), Integer.valueOf(0), Integer.valueOf(1021333), "TREMBAN3");
         * assert (actions.size() > 0); this.printActions(actions);
         *
         * // Retrieve Authorities Data Correction Actions Log
         *
         * Set<DataCorrectionActionsLog> dataCorrectionActionsLogs = authoritiesDao.getDataCorrectionActionLogs(49561,
         * Integer.valueOf(0), "LAMARCJ6"); assert (dataCorrectionActionsLogs.size() > 0);
         * this.printDataCorrectionActionsLogs(dataCorrectionActionsLogs);
         *
         * // Retrieve Authorities Opposition Case Actions Set<OppositionCaseAction> oppositionCaseActions =
         * authoritiesDao.getOppositionCaseActions(Integer.valueOf(6008), Integer.valueOf(0), "MURRAYJ1"); assert
         * (oppositionCaseActions.size() > 0);
         *
         * this.printOppositionCaseActions(oppositionCaseActions);
         *
         * // Retrieve Authorities Pulling Lists Set<PullingLists> pullingLists =
         * authoritiesDao.getPullingLists("ARCHIVE");
         *
         * assert (pullingLists.size() > 0);
         *
         * this.printPullingLists(pullingLists);
         *
         * // Retrieve Authorities Pulling Lists Set<ProcessActions> processActions =
         * authoritiesDao.getProcessActions(Integer.valueOf(1812655), Integer.valueOf(0), Integer.valueOf(1022741),
         * "JOURNAL"); assert (processActions.size() > 0); this.printProcessActions(processActions);
         *
         * // Retrieve Authorities Agent Representative Actions Set<AgentRepresentativeActions>
         * agentRepresentativeActions = authoritiesDao .getAgentRepresentativeActions(Integer.valueOf(13529),
         * "LEPAGEL1"); assert (agentRepresentativeActions.size() > 0);
         * this.printAgentRepresentativeActions(agentRepresentativeActions);
         */

    }

    /**
     * Printing method
     *
     * @param Collection of authorities
     */
    private void printData(Set<Authorities> authorities) {

        System.out.println("Authorities Data: ");
        System.out.println("=============================");
        for (Authorities authority : authorities) {
            // This will get the specific aa work sheets information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            System.out.println("Authorities Authority Type: " + authority.getAuthorityType());

            System.out.println("Authorities Name: " + authority.getName());

            System.out.println("Authorities Username: " + authority.getUserName());

            System.out.println("Authorities Security Level Code: " + authority.getSecurityLevelCode());

            System.out.println("Authorities Language Of Preference: " + authority.getLanguageOfPreference());

            System.out.println("Authorities Section Authority ID: " + authority.getSectionAuthorityId());

            System.out.println("Authorities F Section Authority ID: " + authority.getfSectionAuthorityId());

            System.out.println("Authorities Default User Name: " + authority.getDefaultUserName());

            System.out.println("Authorities Parent User Name: " + authority.getParentUserName());

            System.out.println("Authorities VPN User: " + authority.getVpnUser());

            System.out.println("Authorities Electronic Signtaure: " + authority.getElectronicSignature());

            System.out.println("Authorities Printer Output Bin: " + authority.getPrinterOutputBin());

            System.out.println("Authorities Email Address: " + authority.getEmailAddress());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of current file actions
     */
    private void printCurrentFileActions(Set<CurrentFileActions> currentFileActions) {
        System.out.println("=============================");
        System.out.println("=============================");
        System.out.println("Authorities Current File Actions Data: ");
        System.out.println("=============================");
        for (CurrentFileActions currentFileAction : currentFileActions) {
            // This will get the specific authorities current file actions
            // information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            System.out
                .println("Authorities Current Receiver Authority ID: " + currentFileAction.getReceiverAuthorityId());
            System.out
                .println("Authorities Current File Pulling List Number: " + currentFileAction.getPullingListNumber());
            System.out.println(
                "Authorities Current File Actions Sender Authority ID: " + currentFileAction.getSenderAuthorityId());
            System.out.println("Authorities Current File Actions File Number: " + currentFileAction.getFileNumber());
            System.out.println("Authorities Current File Actions File Type: " + currentFileAction.getFileType());
            System.out.println(
                "Authorities Current File Actions Request Time Stamp: " + currentFileAction.getRequestTimeStamp());
            System.out.println(
                "Authorities Current File Actions Reserve Time Stamp: " + currentFileAction.getReserveTimeStamp());
            System.out
                .println("Authorities Current File Actions Send Time Stamp: " + currentFileAction.getSendTimeStamp());
            System.out
                .println("Authorities Current File Actions Receiver Name: " + currentFileAction.getReceiverName());
            System.out.println("Authorities Current File Actions AR Number: " + currentFileAction.getReceiverName());
            System.out.println("Authorities Current File Actions Evidence Requested Ind: "
                + currentFileAction.getEvidenceRequestedInd());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of historical file actions
     */
    private void printHistoricalFileActions(Set<HistoricalFileActions> historicalFileActions) {
        System.out.println("=============================");
        System.out.println("=============================");
        System.out.println("Authorities Historical File Actions Data: ");
        System.out.println("=============================");
        for (HistoricalFileActions historicalFileAction : historicalFileActions) {
            // This will get the specific authorities historical file actions
            // information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            System.out.println(
                "Authorities Historical Receiver Authority ID: " + historicalFileAction.getReceiverAuthorityId());
            System.out.println("Authorities Historical File Actions Sender Authority ID: "
                + historicalFileAction.getSenderAuthorityId());
            System.out
                .println("Authorities Historical File Actions File Number: " + historicalFileAction.getFileNumber());
            System.out.println("Authorities Historical File Actions File Type: " + historicalFileAction.getFileType());
            System.out.println("Authorities Historical File Actions Receive Time Stamp: "
                + historicalFileAction.getReceiveTimeStamp());
            System.out.println(
                "Authorities Historical File Actions Send Time Stamp: " + historicalFileAction.getSendTimeStamp());
            System.out.println(
                "Authorities Historical File Actions Receiver Name: " + historicalFileAction.getReceiverName());
            System.out.println("Authorities Historical File Actions AR Number: " + historicalFileAction.getArNumber());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of AA Transactions
     */
    private void printAATransactions(Set<AssignmentAmendmentTransaction> aaTransactions) {

        System.out.println("Authorities Transactions Data: ");
        System.out.println("=============================");
        for (AssignmentAmendmentTransaction aaTransaction : aaTransactions) {
            // This will get the specific authorities aa transactions
            // information
            System.out.println("Authorities Transactions AAT Number " + aaTransaction.getAatNumber());
            System.out.println("Authorities Transactions AAT Label: " + aaTransaction.getAatLabel());
            System.out.println("Authorities Transactions AAT Type: " + aaTransaction.getAatType());
            System.out.println("Authorities Transactions Authority Id " + aaTransaction.getAuthorityId());
            System.out.println("Authorities Transactions AAT Work Sheet Number: " + aaTransaction.getWorkSheetNumber());
            System.out
                .println("Authorities Transactions AAT Master File Number: " + aaTransaction.getMasterFileNumber());
            System.out.println(
                "Authorities Transactions Master Extension Counter " + aaTransaction.getMasterExtensionCounter());
            System.out.println("Authorities Transactions Status Code: " + aaTransaction.getStatusCode());
            System.out.println("Authorities Transactions Start Date: " + aaTransaction.getStartDate());
            System.out.println("Authorities Transactions Receive Date " + aaTransaction.getReceiveDate());
            System.out.println("Authorities Transactions Correctrion Ind: " + aaTransaction.getCorrectionInd());
            System.out.println("Authorities Transactions Court Order Ind: " + aaTransaction.getCourtOrderInd());
            System.out.println("Authorities Transactions Footnote Type: " + aaTransaction.getFootnoteType());
            System.out.println(
                "Authorities Transactions Footnote Date Of Change: " + aaTransaction.getFootnoteDateOfChange());
            System.out.println("Authorities Transactions Footnote Text " + aaTransaction.getFootnoteText());
            System.out.println("Authorities Transactions Agent Change Ind: " + aaTransaction.getAgentChangeInd());
            System.out.println("Authorities Transactions Rep Change Ind: " + aaTransaction.getRepChangeInd());
            System.out
                .println("Authorities Transactions Correspondence Date: " + aaTransaction.getCorrespondenceDate());
            System.out.println("Authorities Transactions Reponse Date: " + aaTransaction.getResponseDate());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Actions
     */

    private void printActions(Set<Action> actions) {
        System.out.println("=============================");
        System.out.println("=============================");
        System.out.println("Authorities Actions Data: ");
        System.out.println("=============================");
        for (Action action : actions) {
            // This will get the specific authorities actions
            // information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            System.out.println("Authorities Actions File Number: " + action.getFileNumber());
            System.out.println("Authorities Actions Extension Counter: " + action.getExtensionCounter());
            System.out.println("Authorities Action code : " + action.getActionCode());
            System.out.println("Authorities Action Date : " + action.getActionDate());
            System.out.println("Authorities Action Response Date : " + action.getResponseDate());
            System.out.println("Authorities Action Additional Info : " + action.getAdditionalInfo());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Data Correction Action Logs
     */

    private void printDataCorrectionActionsLogs(Set<DataCorrectionActionsLog> dataCorrecttionActionsLogs) {
        System.out.println("=============================");
        System.out.println("=============================");
        System.out.println("Authorities Data Corretion Actions Logs Data: ");
        System.out.println("=============================");
        for (DataCorrectionActionsLog dataCorrectionsActionsLog : dataCorrecttionActionsLogs) {
            // This will get the specific authorities data correction actions
            // logs
            // information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            System.out.println("Application Details: " + dataCorrectionsActionsLog.getApplication());
            System.out.println(
                "Authorities Data Correction Actions Log Action Code: " + dataCorrectionsActionsLog.getActionCode());
            System.out.println(
                "Authorities Data Correction Actions Log Action Date: " + dataCorrectionsActionsLog.getActionDate());
            System.out.println(
                "Authorities Data Correction Actions Log Authority ID: " + dataCorrectionsActionsLog.getAuthorityId());
            System.out.println("Authorities Data Correction Actions Log DC Authority ID: "
                + dataCorrectionsActionsLog.getDataCorrectionAuthorityId());
            System.out.println("Authorities Data Correction Actions Log Performed By Authority ID: "
                + dataCorrectionsActionsLog.getPerformedByAuthorityId());
            System.out.println("Authorities Data Correction Actions Log Response Date: "
                + dataCorrectionsActionsLog.getResponseDate());
            System.out.println("Authorities Data Correction Actions Log Additional Information: "
                + dataCorrectionsActionsLog.getAdditionalInfo());
            System.out.println("Authorities Data Correction Actions Log Justification: "
                + dataCorrectionsActionsLog.getJustification());
            System.out.println("Authorities Data Correction Actions Log Data Correction Action Performed: "
                + dataCorrectionsActionsLog.getDataCorrectionActionPerformed());
            System.out.println("Authorities Data Correction Actions Log Data Correction Authority ID: "
                + dataCorrectionsActionsLog.getAuthorityId());
            System.out.println("Authorities Data Correction Actions Log Data Correction Date Performed: "
                + dataCorrectionsActionsLog.getDataCorrectionDatePerformed());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Opposition Case Actions
     */

    private void printOppositionCaseActions(Set<OppositionCaseAction> oppositionCaseActions) {
        System.out.println("=============================");
        System.out.println("=============================");
        System.out.println("Authorities Opposition Case Actions Logs Data: ");
        System.out.println("=============================");
        for (OppositionCaseAction oppositionCaseAction : oppositionCaseActions) {
            // This will get the specific authorities opposition case actions
            // logs
            // information
            // System.out.println("AAWorkSheets Details: " +
            // authority.getaAWorkSheets());

            // System.out.println("Application Details: " + oppositionCaseAction.getOppositionCase());
            System.out.println(
                "Authorities Opposition Case Action Opp Case Number: " + oppositionCaseAction.getOppCaseNumber());
            System.out.println(
                "Authorities Opposition Case Action Opp Stage Code: " + oppositionCaseAction.getOppStageCode());
            System.out.println(
                "Authorities Opposition Case Action Opp Action Code: " + oppositionCaseAction.getOppActionCode());
            System.out.println(
                "Authorities Opposition Case Action Opp Action Type: " + oppositionCaseAction.getOppActionType());
            System.out
                .println("Authorities Opposition Case Action Opp Action Date: " + oppositionCaseAction.getActionDate());
            System.out.println(
                "Authorities Opposition Case Action Opp Effective Date: " + oppositionCaseAction.getEffectiveDate());
            System.out.println(
                "Authorities Opposition Case Action Additional Info: " + oppositionCaseAction.getAdditionalInfo());
            System.out
                .println("Authorities Opposition Case Action Response Date: " + oppositionCaseAction.getResponseDate());
            System.out
                .println("Authorities Opposition Case Action Delete Code: " + oppositionCaseAction.getDeleteCode());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Pulling Lists
     */

    private void printPullingLists(Set<PullingLists> pullingListsSet) {

        System.out.println("Authorities Pulling Lists Data: ");
        System.out.println("=============================");
        for (PullingLists pullingLists : pullingListsSet) {
            // This will get the specific pulling lists information

            System.out.println("Authorities Pulling Lists Authority ID: " + pullingLists.getAuthorityId());
            System.out.println("Authorities Pulling Lists Pulling List Number: " + pullingLists.getPullingListNumber());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Process Actions
     */
    private void printProcessActions(Set<ProcessAction> processActionsList) {

        System.out.println("Authorities Process Actions Data: ");
        System.out.println("================================");

        for (ProcessAction processActions : processActionsList) {
            // This will get the specific process actions information
            System.out.println("Application Details: " + processActions.getApplication());
            System.out.println("Authorities Process Actions Process Type: " + processActions.getProcessType());
            System.out.println("Authorities Process Actions Process Code: " + processActions.getProcessCode());
            System.out.println("Authorities Process Actions Additional Info: " + processActions.getAdditionalInfo());
            System.out.println("Authorities Process Actions Alternate Mail To: " + processActions.getAlternateMailTo());
            System.out.println("Authorities Process Actions Authority ID: " + processActions.getAuthorityId());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of agent representative actions
     */
    private void printAgentRepresentativeActions(Set<AgentRepresentativeActions> agentRepresentativesActions) {

        System.out.println("Authorities Agent Representative Actions Data: ");
        System.out.println("=============================");
        for (AgentRepresentativeActions agentRepresentativesAction : agentRepresentativesActions) {

            // This will get the Agent Representative Actions data

            System.out.println(
                "Authorities Agent Representative Actions AR Number : " + agentRepresentativesAction.getArNumber());
            System.out.println("Authorities Agent Representative Actions Authority ID : "
                + agentRepresentativesAction.getAuthorityId());
            System.out.println(
                "Authorities Agent Representative Actions Action Code : " + agentRepresentativesAction.getActionCode());
            System.out.println(
                "Authorities Agent Representative Actions Action Date : " + agentRepresentativesAction.getActionDate());
            System.out.println("Authorities Agent Representative Actions Additional Info: "
                + agentRepresentativesAction.getAdditionalInfo());
            System.out.println("Authorities Agent Representative Actions electronic Ind : "
                + agentRepresentativesAction.getElectronicInd());
            System.out.println(
                "Authorities Agent Representative Actions EC File Name: " + agentRepresentativesAction.getEcFileName());

        }
    }

    /**
     * @return
     */
    private Authorities buildAuthority() {
        Authorities authority = new Authorities();
        // There is a lot of assumptions here, but only way to make sure data is retrieved correctly...
        authority.setAuthorityId("ECTEST1");
        authority.setAuthorityType(AuthorityType.INDIVIDUAL_USER.getValue());
        authority.setName("EC Test Team");
        authority.setUserName("ECTEST");
        authority.setSecurityLevelCode(5);
        authority.setLanguageOfPreference(1);
        authority.setSectionAuthorityId("PUBLIC");
        authority.setTelephoneNumber("819-934-5147");
        authority.setParentUserName("ECTEST");
        authority.setVpnUser(0);
        return authority;
    }
}
