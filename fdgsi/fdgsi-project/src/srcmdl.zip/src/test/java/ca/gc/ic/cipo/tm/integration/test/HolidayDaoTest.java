package ca.gc.ic.cipo.tm.integration.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.HolidayDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class HolidayDaoTest {

    @Autowired
    @Qualifier("holidayDao")
    public HolidayDao holidayDao;

    @Test
    @Transactional(readOnly = true)
    public void testIsHoliday() {
        Boolean isHoliday = this.holidayDao.isHoliday(new Date());
        Assert.assertNotNull(isHoliday);
        // System.out.println("Is holiday " + isHoliday);
    }

    @Test
    @Transactional(readOnly = true)
    public void isValidHoliday() {
        GregorianCalendar cal = new GregorianCalendar(2019, Calendar.APRIL, 22);
        Boolean isHoliday = this.holidayDao.isHoliday(cal.getTime());
        Assert.assertTrue(isHoliday);
    }

    @Test
    @Transactional(readOnly = true)
    public void getOpenBusinessDate() {
        GregorianCalendar cal = new GregorianCalendar(2019, Calendar.APRIL, 22);
        Date date = this.holidayDao.getOpenBusinessDate(cal.getTime());
        // System.out.println(date);
        cal = new GregorianCalendar(2019, Calendar.APRIL, 23);
        Assert.assertEquals("Check if two dates equal", cal.getTime().getTime(), date.getTime());
    }
}
