package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.RegistrationRenewalDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.RegistrationRenewal;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class RegistrationRenewalDaoTest {

    @Autowired
    @Qualifier("registrationRenewalDao")
    private RegistrationRenewalDao registrationRenewalDao;

    @Test
    public void testForSearchRenewalsWithApplicationNumberOnly() {
        final Integer fileNumber = 158156;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber);
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size greater than 0", results.size() > 0);
        System.out.println("Total size " + results.size());

    }

    @Test
    public void testForSearchRenewalsWithNonExistingApplicationNumber() { // does not exist in DB final
        Integer fileNumber = 1720387123;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addApplicationNumber(applicationNumber);
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());

        Assert.assertNotNull("Test for not null", results);
        Assert.assertEquals("Test for results size", results.size(), 0);
    }

    @Test
    public void testForSearchRenewalsWithRegistrationNumberProvided() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addRegistrationNumber(55359);
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());
        Assert.assertNotNull("Test for not null", results);
    }

    @Test
    public void testForSearchRenewalsWithAgentNumbers() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(1992, 1, 1)).addEndDate(createDate(2018, 12, 31))
            .addAgentNumbers(createAgentNumbersList());
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());
        Assert.assertNotNull("Test for not null", results);
    }

    private List<Integer> createAgentNumbersList() {
        List<Integer> agentNumbers = new ArrayList<>();
        agentNumbers.add(12);
        return agentNumbers;
    }

    @Test
    public void testForSearchRenewalsUsingLegislation() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addLegislationCode(3);
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test
    public void testForSearchRenewalsUsingTrademark() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(1987, 9, 1)).addEndDate(createDate(2023, 3, 18)).addTrademarkName("OLD")
            .addAgentNumbers(createAgentNumbersList());
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());

        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test
    public void testForSearchRenewalsUsingApplicantName() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        builder.addStartDate(createDate(1987, 9, 1)).addEndDate(createDate(2023, 3, 18)).addApplicantName("CORP")
            .addAgentNumbers(createAgentNumbersList());
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());
        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() > 0);
    }

    @Test(expected = RuntimeException.class)
    public void testForNoSearchCriteria() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());
        Assert.assertTrue("Test for results size", results.size() == 0);
    }

    @Test(expected = RuntimeException.class)
    public void testForSearchWithNoDatesProvided() {
        SearchRegistrationCriteria.Builder builder = new SearchRegistrationCriteria.Builder();
        final Integer fileNumber = 562866;
        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(fileNumber);
        applicationNumber.setExtensionCounter(0);
        builder.addRequestorUserId("SmartMAP").addTrademarkName("bread").addApplicationNumber(applicationNumber);
        List<RegistrationRenewal> results = registrationRenewalDao.searchRegistrationsForRenewal(builder.build());
        Assert.assertNotNull("Test for not null", results);
        Assert.assertTrue("Test for results size", results.size() == 0);
    }

    private Date createDate(int year, int month, int day) {
        Calendar gc = Calendar.getInstance();
        gc.set(year, month - 1, day, 0, 0);
        return gc.getTime();
    }

}
