/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.SelectedParagraphsDao;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.SelectedParagraphs;
import junit.framework.TestCase;

/**
 * This class test the SelectedParagraphsDao
 */
// TODO remove class and hibernate mapping
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Deprecated
@Ignore
public class SelectedParagraphsDaoTest extends TestCase {

    @Autowired
    private SelectedParagraphsDao selectedParagraphsDao;

    @Test
    @Transactional(readOnly = true)
    public void getSelectedParagraphsTest() {

        ProcessAction processActions = new ProcessAction();
        processActions.setFileNumber(Integer.valueOf(859679));
        processActions.setExtensionCounter(Integer.valueOf(0));
        processActions.setProcessCode(60);
        processActions.setProcessType(2);
        processActions.setAuthorityId("test id");
        if (selectedParagraphsDao == null) {
            System.out.println("selectedParagraphsDao is NULL!!!");
        }
        Set<SelectedParagraphs> selectedParagraphsList = selectedParagraphsDao.getSelectedParagraphs(processActions);
        // assert (selectedParagraphsList.size() > 0);
        this.printData(selectedParagraphsList);

    }

    /**
     * Printing method
     *
     * @param Collection of Process Actions
     */
    private void printData(Set<SelectedParagraphs> selectedParagraphsList) {

        System.out.println("Selected Paragraphs Data: ");
        System.out.println("================================");

        for (SelectedParagraphs selectedParagraphs : selectedParagraphsList) {
            // This will get the specific financial transaction information
            System.out.println("Process Action Details: " + selectedParagraphs.getProcessActions());
            System.out.println("Selected Paragraphs File Number: " + selectedParagraphs.getFileNumber());
            System.out.println("Selected Paragraphs Extension Counter: " + selectedParagraphs.getExtensionCounter());
            System.out.println("Selected Paragraphs Process Type: " + selectedParagraphs.getProcessType());
            System.out.println("Selected Paragraphs Process Code: " + selectedParagraphs.getProcessCode());
            System.out.println("Process Actions Sequence Number: " + selectedParagraphs.getSequenceNumber());
            System.out.println("Process Actions Authority ID: " + selectedParagraphs.getAuthorityId());

        }
    }
}
