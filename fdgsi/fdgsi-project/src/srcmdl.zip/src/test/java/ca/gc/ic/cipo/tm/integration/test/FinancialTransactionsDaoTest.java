/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Collection;
import java.util.Date;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.FinancialTransactionsDao;
import ca.gc.ic.cipo.tm.enumerator.FeeType;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FinancialTransactions;
import junit.framework.TestCase;

/**
 * This class test the FinancialTransactionsDao
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class FinancialTransactionsDaoTest extends TestCase {

    @Autowired
    private FinancialTransactionsDao financialTransactionsDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Autowired
    private ApplicationDao applicationDao;
    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getFinancialTransactionsTest() {

        ApplicationNumber applicationNumber = new ApplicationNumber();
        applicationNumber.setFileNumber(Integer.valueOf(91958));
        applicationNumber.setExtensionCounter(Integer.valueOf(0));
        if (financialTransactionsDao == null) {
            System.out.println("financialTransactionsDao is NULL!!!");
        }

        // Set<FinancialTransactions> transactions =
        // financialTransactionsDao.getFinancialTransactions(applicationNumber);
        // assert (transactions.size() > 0);
        // this.printData(transactions);

        // get the list of Agent Represenatives
        // Set<AgentRepresentative> agentRepresentatives = financialTransactionsDao
        // .getAgentRepresentatives(Integer.valueOf(9073));
        // assert (agentRepresentatives.size() > 0);
        // this.printAgentRepresentatives(agentRepresentatives);

    }

    /**
     * Printing method
     *
     * @param Collection of financial transactions
     */
    private void printData(Set<FinancialTransactions> transactions) {

        System.out.println("Financial Transactions Data: ");
        System.out.println("=============================");
        for (FinancialTransactions transaction : transactions) {
            // This will get the specific financial transaction information
            System.out.println("Application Details: " + transaction.getApplication());
            System.out.println("Financial Transactions Account Number: " + transaction.getAccountNumber());
            System.out.println("Financial Transactions Amount: " + transaction.getAmount());
            System.out.println("Financial Transactions Confirmation Number: " + transaction.getConfirmationNumber());
            System.out.println("Financial Transactions Extension Counter: " + transaction.getExtensionCounter());
            System.out.println("Financial Transactions Fee Type: " + transaction.getFeeType());
            System.out.println("Financial Transactions File Number: " + transaction.getFileNumber());
            System.out.println("Financial Transactions Payment Method: " + transaction.getPaymentMethod());
            System.out.println("Financial Transactions Payment Reference: " + transaction.getPaymentReference());
            System.out.println("Financial Transactions Print Date: " + transaction.getPrintDate());
            System.out.println("Financial Transactions Receive Date: " + transaction.getReceiveDate());
            System.out.println(
                "Financial Transactions Financial Transaction Number: " + transaction.getFinancialTransactionNumber());
            System.out.println("Financial Transactions AR Number: " + transaction.getArNumber());

        }
    }

    /**
     * Printing method
     *
     * @param Collection of Agent representatives
     */
    private void printAgentRepresentatives(Set<AgentRepresentative> agentRepresentatives) {

        System.out.println("Financial Transactions Representatives Data: ");
        System.out.println("================================");

        for (AgentRepresentative agentRepresentative : agentRepresentatives) {
            // This will get the specific email jobs agent representatives
            // information

            System.out
                .println("Financial Transactions Representatives AR Number: " + agentRepresentative.getArNumber());
            System.out.println("Financial Transactions Representatives AR Type: " + agentRepresentative.getArType());
            System.out.println("Financial Transactions Representatives Language: " + agentRepresentative.getLanguage());
            System.out
                .println("Financial Transactions Representatives Status Code: " + agentRepresentative.getStatusCode());
            System.out.println(
                "Financial Transactions Representatives Major Centre: " + agentRepresentative.getMajorCentre());
            System.out.println("Financial Transactions Representatives Statement Receiver Ind: "
                + agentRepresentative.getStatementReceivedInd());
            System.out.println(
                "Financial Transactions Representatives Renewal Date: " + agentRepresentative.getRenewalDate());
            System.out.println(
                "Financial Transactions Representatives Effective Year: " + agentRepresentative.getREffectiveYear());
            System.out.println("Financial Transactions Representatives Reinstatement Date: "
                + agentRepresentative.getReinstatementDate());
            System.out.println("Financial Transactions Representatives Original Registration Date: "
                + agentRepresentative.getOriginalRegistrationDate());
            System.out.println(
                "Financial Transactions Representatives Contact Name: " + agentRepresentative.getContactName());
            System.out.println("Financial Transactions Representatives Contact: " + agentRepresentative.getContact());
            System.out.println(
                "Financial Transactions Representatives Account Number: " + agentRepresentative.getAccountNumber());
            System.out.println("Financial Transactions Representatives Electronic Corr Ind: "
                + agentRepresentative.getElectronicCorrInd());
            System.out.println(
                "Financial Transactions Representatives IP for Agent: " + agentRepresentative.getIpForAgentNumber());
            System.out.println(
                "Financial Transactions Representatives IP for Rep Number: " + agentRepresentative.getIpForRepNumber());

        }
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetFinancialTransactionsIntegerInteger() {
        FinancialTransactions financialTransaction = buildFinancialTransaction();
        financialTransactionsDao.saveFinancialTransactions(financialTransaction);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<FinancialTransactions> retrievedFinancialTransactions = financialTransactionsDao
            .getFinancialTransactions(financialTransaction.getFileNumber(), financialTransaction.getExtensionCounter());
        FinancialTransactions detachedFinancialTransaction = new FinancialTransactions();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(financialTransaction, detachedFinancialTransaction);
        // Forces Hibernate to save/refresh from DB
        assertEquals(1, retrievedFinancialTransactions.size());
        FinancialTransactions retrievedFinancialTransaction = retrievedFinancialTransactions.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFinancialTransaction);
        // TODO review date, format does not match, line below to be removed
        retrievedFinancialTransaction.setReceiveDate(detachedFinancialTransaction.getReceiveDate());
        retrievedFinancialTransaction.setPrintDate(detachedFinancialTransaction.getPrintDate());
        assertEquals(detachedFinancialTransaction, retrievedFinancialTransaction);
    }

    @Transactional(readOnly = false)
    @Rollback(true)

    @Test
    public void testGetFinancialTransactionsIntegerIntegerIntegerInteger() {
        FinancialTransactions financialTransaction = buildFinancialTransaction();
        financialTransactionsDao.saveFinancialTransactions(financialTransaction);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<FinancialTransactions> retrievedFinancialTransactions = financialTransactionsDao
            .getFinancialTransactions(financialTransaction.getFileNumber(), financialTransaction.getExtensionCounter(),
                financialTransaction.getArNumber(), financialTransaction.getFinancialTransactionNumber());
        FinancialTransactions detachedFinancialTransaction = new FinancialTransactions();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(financialTransaction, detachedFinancialTransaction);
        // Forces Hibernate to save/refresh from DB
        // TODO uncomment below, will not work correctly until ar_number is fixed in model
        // assertEquals(1, retrievedFinancialTransactions.size());
        // FinancialTransactions retrievedFinancialTransaction = retrievedFinancialTransactions.iterator().next();
        // transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFinancialTransaction);
        // TODO review date, format does not match, line below to be removed
        // retrievedFinancialTransaction.setReceiveDate(detachedFinancialTransaction.getReceiveDate());
        // retrievedFinancialTransaction.setPrintDate(detachedFinancialTransaction.getPrintDate());
        // TODO uncomment below, will not work correctly until ar_number is fixed in model
        // assertEquals(detachedFinancialTransaction, retrievedFinancialTransaction);
    }

    @Transactional(readOnly = false)
    @Rollback(true)

    @Test
    public void testGetFinancialTransactionsApplicationNumber() {
        FinancialTransactions financialTransaction = buildFinancialTransaction();
        financialTransactionsDao.saveFinancialTransactions(financialTransaction);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<FinancialTransactions> retrievedFinancialTransactions = financialTransactionsDao
            .getFinancialTransactions(financialTransaction);
        FinancialTransactions detachedFinancialTransaction = new FinancialTransactions();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(financialTransaction, detachedFinancialTransaction);
        // Forces Hibernate to save/refresh from DB
        assertEquals(1, retrievedFinancialTransactions.size());
        FinancialTransactions retrievedFinancialTransaction = retrievedFinancialTransactions.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFinancialTransaction);
        // TODO review date, format does not match, line below to be removed
        retrievedFinancialTransaction.setReceiveDate(detachedFinancialTransaction.getReceiveDate());
        retrievedFinancialTransaction.setPrintDate(detachedFinancialTransaction.getPrintDate());
        assertEquals(detachedFinancialTransaction, retrievedFinancialTransaction);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetFinancialTransactionsApplicationNumberFinancialTransactionsId() {
        FinancialTransactions financialTransaction = buildFinancialTransaction();
        financialTransactionsDao.saveFinancialTransactions(financialTransaction);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<FinancialTransactions> retrievedFinancialTransactions = financialTransactionsDao
            .getFinancialTransactions(financialTransaction, financialTransaction);
        FinancialTransactions detachedFinancialTransaction = new FinancialTransactions();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(financialTransaction, detachedFinancialTransaction);
        // Forces Hibernate to save/refresh from DB
        // TODO uncomment below, will not work correctly until ar_number is fixed in model
        // assertEquals(1, retrievedFinancialTransactions.size());
        // FinancialTransactions retrievedFinancialTransaction = retrievedFinancialTransactions.iterator().next();
        // transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFinancialTransaction);
        // TODO review date, format does not match, line below to be removed
        // retrievedFinancialTransaction.setReceiveDate(detachedFinancialTransaction.getReceiveDate());
        // retrievedFinancialTransaction.setPrintDate(detachedFinancialTransaction.getPrintDate());
        // TODO uncomment below, will not work correctly until ar_number is fixed in model
        // assertEquals(detachedFinancialTransaction, retrievedFinancialTransaction);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testSaveFinancialTransactions() {
        FinancialTransactions financialTransaction = buildFinancialTransaction();
        financialTransactionsDao.saveFinancialTransactions(financialTransaction);
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<FinancialTransactions> retrievedFinancialTransactions = financialTransactionsDao
            .getFinancialTransactions(financialTransaction);
        FinancialTransactions detachedFinancialTransaction = new FinancialTransactions();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(financialTransaction, detachedFinancialTransaction);
        // Forces Hibernate to save/refresh from DB
        assertEquals(1, retrievedFinancialTransactions.size());
        FinancialTransactions retrievedFinancialTransaction = retrievedFinancialTransactions.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedFinancialTransaction);
        // TODO review date, format does not match, line below to be removed
        retrievedFinancialTransaction.setReceiveDate(detachedFinancialTransaction.getReceiveDate());
        retrievedFinancialTransaction.setPrintDate(detachedFinancialTransaction.getPrintDate());
        assertEquals(detachedFinancialTransaction, retrievedFinancialTransaction);
    }

    /**
     * @return
     */
    private FinancialTransactions buildFinancialTransaction() {
        FinancialTransactions financialTransaction = new FinancialTransactions();
        financialTransaction.setFeeType(FeeType.APPLICATION_FEE.getValue());
        // TODO update when amount datatype is corrected
        // financialTransaction.setAmount(BigDecimal.valueOf(99999.99));
        financialTransaction.setAmount(99999);
        financialTransaction.setFileNumber(111);
        financialTransaction.setExtensionCounter(0);
        financialTransaction.setReceiveDate(new Date());
        financialTransaction.setPaymentMethod(2);
        financialTransaction.setArNumber(11111);
        financialTransaction.setConfirmationNumber("ConfirmationNum");
        financialTransaction.setPaymentReference("PaymentReferencePaym");
        financialTransaction.setPrintDate(new Date(new Date().getTime() + 1000));
        financialTransaction.setAccountNumber("AccountNumberAccoun");
        financialTransaction.setApplication(applicationDao.getApplication(111, 0));
        return financialTransaction;
    }

}
