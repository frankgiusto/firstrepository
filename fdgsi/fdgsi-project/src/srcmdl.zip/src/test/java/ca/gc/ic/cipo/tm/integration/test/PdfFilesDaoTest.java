/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.PdfFilesDao;
import ca.gc.ic.cipo.tm.model.PdfFiles;
import junit.framework.TestCase;

/**
 * This class tests the PdfFilesDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class PdfFilesDaoTest extends TestCase {

    @Autowired
    private PdfFilesDao pdfFilesDao;

    @Test
    @Transactional(readOnly = true)
    public void getPdfFilesTest() {

        /*
         * EmailJobsId emailJobsId = new EmailJobsId(); emailJobsId.setFileNumber(Integer.valueOf(1807793));
         * emailJobsId.setExtensionCounter(Integer.valueOf(0)); emailJobsId.setEmailJobNumber(2387110);
         * 
         * if (pdfFilesDao == null) { System.out.println( "pdfFilesDao is NULL!!!"); } Set<PdfFiles> pdfFilesList =
         * pdfFilesDao.getPdfFiles(emailJobsId); assert (pdfFilesList.size() > 0); this.printData(pdfFilesList);
         */

    }

    /**
     * Printing method
     *
     * @param Collection of Pdf Files
     */
    private void printData(Set<PdfFiles> pdfFilesList) {

        System.out.println("PDF Files Data: ");
        System.out.println("================================");

        for (PdfFiles pdfFiles : pdfFilesList) {
            // This will get the specific pdf files information
            System.out.println("Email Jobs Details: " + pdfFiles.getEmailJobs());
            System.out.println("PDF Files Email Job Number: " + pdfFiles.getEmailJobNumber());
            System.out.println("PDF Files Output Code: " + pdfFiles.getOutputCode());
            System.out.println("PDF Files File Name: " + pdfFiles.getFileName());
            System.out.println("PDF Files PDF Job Status Code " + pdfFiles.getPdfJobStatusCode());
            System.out.println("PDF Files Created TimeStamp: " + pdfFiles.getCreatedTimeStamp());
            System.out.println("PDF Files Modified TimeStamp: " + pdfFiles.getModifiedTimeStamp());
            System.out.println("PDF Files Job Error: " + pdfFiles.getPdfJobError());
            System.out.println("PDF Files File Error: " + pdfFiles.getFileBlob());

        }
    }

}
