/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.CurrentFileActionsDao;
import ca.gc.ic.cipo.tm.model.CurrentFileActions;
import ca.gc.ic.cipo.tm.model.PullingListsId;
import junit.framework.TestCase;

/**
 * This is the test class for CurrentFileActionsDao
 *
 * @author houreich
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Deprecated
public class CurrentFileActionsDaoTest extends TestCase {

    @Autowired
    private CurrentFileActionsDao currentFileActionsDao;

    // @Before
    // public void initialize() {
    // applicationNumber = new ApplicationNumber(FILE_NUMBER, EXTENTION_NUMBER);
    // }

    @Test
    @Transactional(readOnly = true)
    public void getCurrentFileActions() {

        PullingListsId pullingListsId = new PullingListsId();
        pullingListsId.setPullingListNumber(Integer.valueOf(1));

        if (currentFileActionsDao == null) {
            System.out.println("currentFileActionsDao is NULL!!!");
        }

        Set<CurrentFileActions> currentFileActions = currentFileActionsDao
            .getCurrentFileActions(pullingListsId.getPullingListNumber(), "ARCHIVE");

        assert (currentFileActions.size() > 0);

        this.printData(currentFileActions);

    }

    /**
     * Printing method
     *
     * @param Collection of Current File Actions
     */
    private void printData(Set<CurrentFileActions> currentFileActionsSet) {

        System.out.println("Current File Actions Data: ");
        System.out.println("=============================");
        for (CurrentFileActions currentFileActions : currentFileActionsSet) {
            // This will get the specificcurrent file action information

            System.out.println("Current File Actions File Number: " + currentFileActions.getFileNumber());
            System.out.println("Current File Actions File Type: " + currentFileActions.getFileType());
            System.out.println("Current File Actions Request Time Stamp: " + currentFileActions.getRequestTimeStamp());
            System.out.println("Current File Actions Reserve Time Stamp: " + currentFileActions.getReserveTimeStamp());
            System.out.println("Current File Actions Send Time Stamp: " + currentFileActions.getSendTimeStamp());
            System.out.println("Current File Actions Receiver Name: " + currentFileActions.getReceiverName());
            System.out.println("Current File Actions AR Number: " + currentFileActions.getArNumber());
            System.out.println(
                "Current File Actions Evidence Requested Ind: " + currentFileActions.getEvidenceRequestedInd());

        }
    }

}
