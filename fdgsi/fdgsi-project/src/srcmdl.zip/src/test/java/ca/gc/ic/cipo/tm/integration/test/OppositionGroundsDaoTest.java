package ca.gc.ic.cipo.tm.integration.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.OppositionGroundsDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionGrounds;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionGroundsDaoTest extends TestCase {

    @Autowired
    @Qualifier("oppositionGroundsDao")
    private OppositionGroundsDao oppositionGroundsDao;

    @Test
    @Transactional(readOnly = true)
    public void getOppositonGroundsByApplication() {
        ApplicationNumber applicationNumberModel = new ApplicationNumber(1282503, 0);
        List<OppositionGrounds> oppGrounds = this.oppositionGroundsDao
            .getOppositonGroundsByApplication(applicationNumberModel);
        Assert.assertNotNull(oppGrounds);
        Assert.assertTrue(oppGrounds.size() > 0);
    }

}
