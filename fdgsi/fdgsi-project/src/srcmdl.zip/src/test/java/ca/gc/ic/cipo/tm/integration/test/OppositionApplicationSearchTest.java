package ca.gc.ic.cipo.tm.integration.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionFactory;
import ca.gc.ic.cipo.tm.dao.search.OppositionApplicationSearch;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.enumerator.SearchItemType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionApplicationSearchTest {

    @Autowired
    @Qualifier("oppositionApplicationSearch")
    private OppositionApplicationSearch oppAppSearch;

    @Test
    @Transactional(readOnly = true)
    public void searchOppositionApplicationOpponent() {
        List<Expression> searchExpressions = createOpponentNameSearchExpressions();
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        searchItemTypesMap.put(SearchItemType.OPPONENT_NAME, Boolean.TRUE);

        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchOppositionApplicationApplicant() {
        List<Expression> searchExpressions = createApplicantNameSearchExpressions("CADBURY LIMITED");
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        searchItemTypesMap.put(SearchItemType.APPLICANT_NAME, Boolean.TRUE);

        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchOppositionApplicationApplicationNumber() {
        List<Expression> searchExpressions = createApplicationNumberSearchExpressions();
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        searchItemTypesMap.put(SearchItemType.APPLICATION_NUMBER, Boolean.TRUE);

        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchOppositionApplicationRegistrationNumber() {
        List<Expression> searchExpressions = createRegistrationNumberSearchExpressions(48117);
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        searchItemTypesMap.put(SearchItemType.REGISTRATION_NUMBER, Boolean.TRUE);

        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchOppositionApplicationRegistrationNumberAndApplicant() {
        List<Expression> searchExpressions = createRegistrationNumberAndApplicantNameSearchExpressions(34346, "joe");
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        searchItemTypesMap.put(SearchItemType.REGISTRATION_NUMBER, Boolean.TRUE);
        searchItemTypesMap.put(SearchItemType.APPLICANT_NAME, Boolean.TRUE);

        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    @Test
    @Transactional(readOnly = true)
    public void searchOppositionApplicationRegistrationNumberAndOpponent() {
        List<Expression> searchExpressions = createRegistrationNumberAndApplicantNameSearchExpressions(475579, "joe");
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        searchItemTypesMap.put(SearchItemType.REGISTRATION_NUMBER, Boolean.TRUE);
        searchItemTypesMap.put(SearchItemType.OPPONENT_NAME, Boolean.TRUE);

        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    @Test(expected = IllegalArgumentException.class)
    public void searchOppositionApplicationWithNoSearchCriteria() {
        List<Expression> searchExpressions = new ArrayList<>();
        Map<SearchItemType, Boolean> searchItemTypesMap = new HashMap<>();
        List<Application> applications = oppAppSearch.searchOppositionApplications(searchExpressions,
            searchItemTypesMap, HibernateOperatorEnum.AND);
        Assert.assertNotNull(applications);
        Assert.assertTrue(applications.size() > 0);
        printApplications(applications);
    }

    private void printApplications(List<Application> applications) {
        if (!CollectionUtils.isEmpty(applications)) {
            for (Application eachApp : applications) {
                System.out.println("APP " + eachApp);
            }
        }
    }

    private List<Expression> createRegistrationNumberAndApplicantNameSearchExpressions(Integer fileNumber,
                                                                                       String applicantName) {
        List<Expression> expressions = createRegistrationNumberSearchExpressions(fileNumber);
        List<Expression> nameExpressions = createApplicantNameSearchExpressions(applicantName);
        expressions.addAll(nameExpressions);
        return expressions;
    }

    private List<Expression> createApplicantNameSearchExpressions(String applicantName) {
        List<Expression> expressions = new ArrayList<>();
        // Name
        Expression expression = makeExpression(SearchItemType.APPLICANT_NAME.dbColName("IP"),
            SearchItemType.APPLICANT_NAME.namedParamName(), HibernateOperatorEnum.LIKE, applicantName);
        expressions.add(expression);

        return expressions;
    }

    private List<Expression> createOpponentNameSearchExpressions() {
        List<Expression> expressions = new ArrayList<>();
        // Name
        String opponentName = "Opp One Inc.";
        Expression expression = makeExpression(SearchItemType.OPPONENT_NAME.dbColName("IP"),
            SearchItemType.OPPONENT_NAME.namedParamName(), HibernateOperatorEnum.EQUAL, opponentName);
        expressions.add(expression);

        return expressions;
    }

    private List<Expression> createApplicationNumberSearchExpressions() {
        List<Expression> expressions = new ArrayList<>();
        // Name
        Integer applicationNumber = 148256;
        Expression expression = makeExpression(SearchItemType.APPLICATION_NUMBER.dbColName("app"),
            SearchItemType.APPLICATION_NUMBER.namedParamName(), HibernateOperatorEnum.EQUAL, applicationNumber);
        expressions.add(expression);

        return expressions;
    }

    private List<Expression> createRegistrationNumberSearchExpressions(Integer registrationNumber) {
        List<Expression> expressions = new ArrayList<>();
        // Name
        Expression expression = makeExpression(SearchItemType.REGISTRATION_NUMBER.dbColName("app"),
            SearchItemType.REGISTRATION_NUMBER.namedParamName(), HibernateOperatorEnum.EQUAL, registrationNumber);
        expressions.add(expression);

        return expressions;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      Object value) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            value);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

    private Expression makeExpression(String dbColName, String paramName, HibernateOperatorEnum operator,
                                      List<Object> values) {
        SearchExpression searchExpression = SearchExpression.makeSearchExpression(dbColName, paramName, operator,
            values);
        Expression expression = ExpressionFactory.getExpression(searchExpression);
        return expression;
    }

}
