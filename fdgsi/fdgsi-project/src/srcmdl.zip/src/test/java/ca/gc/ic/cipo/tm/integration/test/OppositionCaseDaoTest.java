/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.LegislationType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkClassType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkStatusType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import junit.framework.TestCase;

/**
 * This class test the OppositionCaseDao. Added this when I found an error in the mapping the hard way.
 *
 * @author fgiusto
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionCaseDaoTest extends TestCase {

    @Autowired
    private ApplicationDao applicationDao;

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    @Transactional(readOnly = false)
    @Rollback(true)
    public void testCreateOppositionCase() {

        // 1. create application
        Integer nextApplicationNumber = applicationDao.getNextApplicationNumber().intValue();

        // Create Application
        Application application = createApplication(nextApplicationNumber);
        applicationDao.saveApplication(application);

        OppositionCase oppositionCase = createPendingOppositionCase(application);
        application.getOppositionCases().add(oppositionCase);

        // TODO Need to create Opposition Action Code - Needs dao mapping and model.
        // Create Opposition Case
        oppositionCaseDao.saveOppositionCase(oppositionCase);
        applicationDao.saveApplication(application);

        Application application2 = applicationDao.getApplication(nextApplicationNumber, 0);

        Set<OppositionCase> cases = application2.getOppositionCases();

        assertTrue(cases.size() > 0);

    }

    private OppositionCase createPendingOppositionCase(Application application) {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(application.getFileNumber());
        oppositionCase.setExtensionCounter(application.getExtensionCounter());
        oppositionCase.setApplication(application);
        oppositionCase.setOppCaseNumber(10);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(1);

        return oppositionCase;
    }

    private Application createApplication(Integer nextApplicationNumber) {
        Application application = new Application();

        application.setFileNumber(nextApplicationNumber);
        application.setExtensionCounter(0);
        application.setIrNumber("1093502");
        application.setIntlFilingRecordId("1043968801");
        application.setStatusCode(TradeMarkStatusType.FORMALIZED.getValue());
        application.setFilingFeeInd(1);
        application.setClassificationRequiredInd(1);
        application.setRegisteredUserInd(0);
        application.setPreciousMetalsInd(0);
        application.setElectronicApplicationInd(1);
        application.setOnHoldInd(BigDecimal.valueOf(0));
        application.setLegislation(LegislationType.TMA.getValue());
        application.setTradeMarkClass(TradeMarkClassType.CERTIFICATION_MARK.getValue());
        application.setTradeMarkType(1);
        application.setRegistrabilityRecognizedInd(0);

        return application;
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetOppositionCasesApplicationNumber() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        applicationDao.saveApplication(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        Collection<OppositionCase> retrievedOps = oppositionCaseDao.getOppositionCases(oppositionCase);
        OppositionCase detachedOp = new OppositionCase();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(oppositionCase, detachedOp);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        assertEquals(1, retrievedOps.size());
        OppositionCase retrievedOp = retrievedOps.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedOp);
        assertEquals(detachedOp, retrievedOp);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testGetOppositionCase() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        applicationDao.saveApplication(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        OppositionCase retrievedOp = oppositionCaseDao.getOppositionCase(oppositionCase,
            oppositionCase.getOppCaseNumber());
        OppositionCase detachedOp = new OppositionCase();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(oppositionCase, detachedOp);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedOp);
        assertEquals(detachedOp, retrievedOp);
    }

    @Transactional(readOnly = false)
    @Rollback(true)
    @Test
    public void testSaveOppositionCase() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        applicationDao.saveApplication(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        OppositionCase retrievedOp = oppositionCaseDao.getOppositionCase(oppositionCase,
            oppositionCase.getOppCaseNumber());
        OppositionCase detachedOp = new OppositionCase();
        // Need to do a copy since Hibernate sets application and savedApplication to the same instance...
        BeanUtils.copyProperties(oppositionCase, detachedOp);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedOp);
        assertEquals(detachedOp, retrievedOp);
    }

    @Test
    @Transactional(readOnly = false)
    @Rollback
    public void testGetNextOppositionCaseNumberForApplication() {
        Application application = createApplication(applicationDao.getNextApplicationNumber().intValue());
        OppositionCase oppositionCase = createPendingOppositionCase(application);
        applicationDao.saveApplication(application);
        oppositionCaseDao.saveOppositionCase(oppositionCase);

        OppositionCase retrievedOp = oppositionCaseDao.getOppositionCase(oppositionCase,
            oppositionCase.getOppCaseNumber());

        Assert.assertNotNull("Check for retrieved", retrievedOp);
        Integer fileNumber = retrievedOp.getFileNumber();
        Integer extCounter = 0;
        Integer result = oppositionCaseDao.getNextOppositionCaseNumberForApplication(fileNumber, extCounter);
        Assert.assertNotNull("Test if next opposition case number", result);
    }

    @Test
    @Transactional(readOnly = true)
    public void testGetNextOppositionCaseNumberForNonExistingApplication() {
        Integer fileNumber = Integer.MAX_VALUE;
        Integer extCounter = 0;
        Integer result = oppositionCaseDao.getNextOppositionCaseNumberForApplication(fileNumber, extCounter);
        Assert.assertNotNull("Test if next opposition case number", result);
        Assert.assertEquals("Check if 1", new Integer(1), result);
    }

    @Test
    @Transactional(readOnly = true)
    public void getOppositionCasesByOppCaseType() {
        Integer fileNumber = 856278;
        Integer extCounter = 0;
        List<OppositionCase> results = oppositionCaseDao
            .getOppositionCasesByCaseType(new ApplicationNumber(fileNumber, extCounter), OppositionCaseType.OPPOSITION);
        Assert.assertNotNull(results);

        fileNumber = 85155;
        extCounter = 0;
        results = oppositionCaseDao.getOppositionCasesByCaseType(new ApplicationNumber(fileNumber, extCounter),
            OppositionCaseType.SECTION_45);
        Assert.assertNotNull(results);

        fileNumber = 85155;
        extCounter = 0;
        results = oppositionCaseDao.getOppositionCasesByCaseType(new ApplicationNumber(fileNumber, extCounter), null);
        Assert.assertNotNull(results);
    }

}
