package ca.gc.ic.cipo.tm.integration.test;

import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.dao.OppositionIpDao;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStatus;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.model.Contact;
import ca.gc.ic.cipo.tm.model.IPContact;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionIp;
import ca.gc.ic.cipo.tm.model.OppositionIpId;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = false)
@Rollback(true)
public class OppositionIpDaoTest extends TestCase {

    @Autowired
    private OppositionCaseDao oppositionCaseDao;

    @Autowired
    private InterestedPartyDao interestedPartyDao;

    @Autowired
    private OppositionIpDao oppositionIpDao;

    @Test
    @Transactional(readOnly = false)
    public void testSaveOppositionIP() {
        OppositionCase oppositionCase = buildOppositionCase();
        InterestedParty interestedParty = buildInterestedParty();
        this.oppositionCaseDao.saveOppositionCase(oppositionCase);
        this.interestedPartyDao.saveInterestedParty(interestedParty);

        // create OppoistionIP record
        OppositionIp oppositionIp = new OppositionIp();
        oppositionIp.setOppositionCase(oppositionCase);
        oppositionIp.setInterestedParty(interestedParty);
        oppositionIp.setFileNumber(111);
        oppositionIp.setExtensionCounter(0);
        oppositionIp.setIpNumber(1);
        oppositionIp.setOppCaseNumber(1);
        this.oppositionIpDao.saveOrUpdateEntity(OppositionIp.class, oppositionIp);
        OppositionIp result = this.oppositionIpDao
            .getOppositionIp(new OppositionIpId(111, 0, 1, oppositionCase.getOppCaseNumber()));
        Assert.assertNotNull("Check for not null", result);
    }

    @Test
    public void testExistingOppIp() {
        OppositionIp result = this.oppositionIpDao.getOppositionIp(new OppositionIpId(1862235, 0, 92317, 1));
        Assert.assertNotNull("Check for not null", result);
    }

    private OppositionCase buildOppositionCase() {
        OppositionCase oppositionCase = new OppositionCase();
        oppositionCase.setFileNumber(111);
        oppositionCase.setExtensionCounter(0);
        oppositionCase.setOppCaseNumber(1);
        oppositionCase.setOppCaseTypeCode(OppositionCaseType.OPPOSITION.getValue());
        oppositionCase.setOppStatusCode(OppositionCaseStatus.ACTIVE.getValue());
        oppositionCase.setOppOwnerCorrInd(0);
        return oppositionCase;
    }

    private InterestedParty buildInterestedParty() {
        InterestedParty interestedParty = new InterestedParty();
        interestedParty.setFileNumber(111);
        interestedParty.setExtensionCounter(0);
        interestedParty.setApplicantInd(0);
        interestedParty.setRegistrantInd(0);

        interestedParty.setRelationshipType(RelationshipType.OPPONENT.getValue());

        IPContact contact = new IPContact();
        interestedParty.setContact(contact);
        interestedParty.setLanguageOfPreference(1);
        interestedParty.setIpNumber(1);
        interestedParty.setModifiedTimestamp(new Date());
        InterestedPartiesAddresses address = new InterestedPartiesAddresses();
        contact.setName("addressaddres" + System.getProperty("line.separator"));
        address.setAddress("addressaddres" + System.getProperty("line.separator"));
        contact.setMailingNameAddress("addressaddres" + System.getProperty("line.separator"));
        Contact businessContact = new Contact();
        InterestedPartiesAddresses busAddress = new InterestedPartiesAddresses();
        busAddress.setAddress("addressaddres" + System.getProperty("line.separator"));
        businessContact.setMailingNameAddress("addressaddres" + System.getProperty("line.separator"));
        contact.getInterestedPartiesAddresses().add(busAddress);

        contact.getInterestedPartiesAddresses().add(address);
        return interestedParty;
    }
}
