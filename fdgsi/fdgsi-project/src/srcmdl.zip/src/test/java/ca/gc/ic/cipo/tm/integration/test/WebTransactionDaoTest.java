package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.WebTransactionDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class WebTransactionDaoTest extends TestCase {

    @Autowired
    private WebTransactionDao webTransactionDao;

    @Test
    @Transactional(readOnly = true)
    // TODO: Revisit the test case when proper query is obtained from Intrepid team
    public void isRenewalExistInTrademark() {
        ApplicationNumber applicationNumber = new ApplicationNumber(1840490, 0);
        boolean exists = this.webTransactionDao.isRenewalExistInTrademark(applicationNumber);
        Assert.assertFalse(exists);
    }
}
