/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.OppositionActionCodesDao;
import ca.gc.ic.cipo.tm.enumerator.OppositionActionType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseStage;
import ca.gc.ic.cipo.tm.model.OppositionActionCodes;
import junit.framework.TestCase;

/**
 * @author duanj
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class OppositionActionCodesDaoTest extends TestCase {

    @Autowired
    @Qualifier("oppositionActionCodesDao")
    private OppositionActionCodesDao oppositionActionCodesDao;

    @Test
    @Transactional(readOnly = true)
    @Ignore
    public void getOppositionActionCodesForS45Evidence() {

        Integer oppStageCode = OppositionCaseStage.SECTION45_REGISTRANT_EVIDENCE.getValue();
        Integer oppActionCode = OppositionCaseActionCodeType.DEADLINE_EVIDENCE_FROM_OWNER.getValue();
        Integer oppActionType = OppositionActionType.DEADLINE_BF.getValue();

        OppositionActionCodes result = oppositionActionCodesDao.getOppositionActionCodes(oppStageCode, oppActionCode,
            oppActionType);

        Assert.assertNotNull(result);
    }

    @Test
    @Transactional(readOnly = true)
    @Ignore
    public void getOppositionActionCodesForS45RequesterWrittenRep() {

        Integer oppStageCode = OppositionCaseStage.SECTION45_WRITTEN_REPRESENTATION_PARTY.getValue();
        Integer oppActionCode = OppositionCaseActionCodeType.DEADLINE_ARGUMENTS_FROM_REQUESTER.getValue();
        Integer oppActionType = OppositionActionType.DEADLINE_BF.getValue();

        OppositionActionCodes result = oppositionActionCodesDao.getOppositionActionCodes(oppStageCode, oppActionCode,
            oppActionType);

        Assert.assertNotNull(result);
    }
}
