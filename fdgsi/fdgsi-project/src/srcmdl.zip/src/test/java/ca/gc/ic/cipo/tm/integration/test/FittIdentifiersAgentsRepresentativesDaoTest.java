/**
 *
 */
package ca.gc.ic.cipo.tm.integration.test;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.FittIdentifiersAgentsRepresentativesDao;
import ca.gc.ic.cipo.tm.model.FittIdentifiersAgentsRepresentatives;
import junit.framework.TestCase;

/**
 * This class tests FittIdentifiersAgentsRepresentativesDao
 *
 * @author houreich
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
public class FittIdentifiersAgentsRepresentativesDaoTest extends TestCase {

    @Autowired
    private FittIdentifiersAgentsRepresentativesDao fittIdentifiersAgentsRepresentativesDao;

    @Test
    @Transactional(readOnly = true)
    public void getFittIdentifiersAgentsRepresentativesTest() {

        /*
         * AgentRepresentative agentRepresentative = new AgentRepresentative();
         * agentRepresentative.setArNumber(Integer.valueOf(12943)); String mrUID =
         * "1294320121204160420234_afr_3416133.html";
         *
         * if (fittIdentifiersAgentsRepresentativesDao == null) { System.out.println(
         * "fittIdentifiersAgentsRepresentativesDao is NULL!!!"); } Set<FittIdentifiersAgentsRepresentatives>
         * fittIdentifiersAgentsRepresentatives = fittIdentifiersAgentsRepresentativesDao
         * .getFittIdentifiersAgentsRepresentatives(agentRepresentative, mrUID); assert
         * (fittIdentifiersAgentsRepresentatives.size() > 0); this.printData(fittIdentifiersAgentsRepresentatives);
         */

    }

    /**
     * Printing method
     *
     * @param Collection of fittIdentifiersAgentRepresentatives
     *
     */
    private void printData(Set<FittIdentifiersAgentsRepresentatives> fittIdentifiersAgentsRepresentatives) {

        System.out.println("FITT Identifiers for Agent Representatives Data: ");
        System.out.println("==================================================");

        for (FittIdentifiersAgentsRepresentatives fittIdentifiersAgentsRepresentative : fittIdentifiersAgentsRepresentatives) {
            // This will get the specific fitt Identifiers information for Agent
            // Representatives.
            // System.out.println(
            // "Agent Representative Details: " +
            // fittIdentifiersAgentsRepresentative.getAgentRepresentative());

            System.out.println("Fitt Identifiers for Agent Representative Mail Room Date: "
                + fittIdentifiersAgentsRepresentative.getMailRoomDate());
            System.out.println("Fitt Identifiers for Agent Representative Mail Room Date Days: "
                + fittIdentifiersAgentsRepresentative.getMailRoomDateDays());
            System.out.println("Fitt Identifiers for Agent Representative First Received Date: "
                + fittIdentifiersAgentsRepresentative.getFirstReceivedDate());
            System.out.println(
                "Fitt Identifiers for Agent Representative MURID: " + fittIdentifiersAgentsRepresentative.getMrUID());
            // System.out.println("Fitt Identifiers for Agent Representative AR
            // Number: "
            // + fittIdentifiersAgentsRepresentative.getArNumber());

        }
    }

}
