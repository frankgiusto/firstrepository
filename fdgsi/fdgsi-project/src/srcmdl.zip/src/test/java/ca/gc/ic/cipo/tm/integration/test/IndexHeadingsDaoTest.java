package ca.gc.ic.cipo.tm.integration.test;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.IndexHeadingsDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.IndexHeading;
import junit.framework.TestCase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = JunitConfig.class)
@Transactional(readOnly = true)
public class IndexHeadingsDaoTest extends TestCase {

    @Autowired
    IndexHeadingsDao indexHeadingDao;

    @Autowired
    private HibernateTransactionManager transactionManager;

    @Test
    public void testGetIndexHeadingsApplicationNumber() {
        IndexHeading indexHeading = buildIndexHeading();
        IndexHeading detachedIndexHeading = new IndexHeading();
        // Need to do a copy since Hibernate sets indexHeading and retrievedIndexHeading to the same instance...
        BeanUtils.copyProperties(indexHeading, detachedIndexHeading);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<IndexHeading> retrievedIndexHeadings = indexHeadingDao
            .getIndexHeadings(new ApplicationNumber(indexHeading.getFileNumber(), indexHeading.getExtensionCounter()));
        assertEquals(1, retrievedIndexHeadings.size());
        IndexHeading retrievedIndexHeading = retrievedIndexHeadings.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedIndexHeading);

    }

    @Test
    public void testGetIndexHeadingsApplicationNumberInteger() {
        IndexHeading indexHeading = buildIndexHeading();
        IndexHeading detachedIndexHeading = new IndexHeading();
        // Need to do a copy since Hibernate sets indexHeading and retrievedIndexHeading to the same instance...
        BeanUtils.copyProperties(indexHeading, detachedIndexHeading);
        // Forces Hibernate to save/refresh from DB
        transactionManager.getSessionFactory().getCurrentSession().flush();

        Collection<IndexHeading> retrievedIndexHeadings = indexHeadingDao.getIndexHeadings(
            new ApplicationNumber(indexHeading.getFileNumber(), indexHeading.getExtensionCounter()),
            indexHeading.getSequenceNumber());
        assertEquals(1, retrievedIndexHeadings.size());
        IndexHeading retrievedIndexHeading = retrievedIndexHeadings.iterator().next();
        transactionManager.getSessionFactory().getCurrentSession().refresh(retrievedIndexHeading);

    }

    /**
     * @return
     */
    private IndexHeading buildIndexHeading() {
        IndexHeading indexHeading = new IndexHeading();
        indexHeading.setFileNumber(111);
        indexHeading.setExtensionCounter(0);
        indexHeading.setSequenceNumber(1);
        return indexHeading;
    }

}
