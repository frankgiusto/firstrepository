package ca.gc.ic.cipo.tm.dao.utils;

import java.sql.Blob;

import org.hibernate.Hibernate;

import ca.gc.ic.cipo.tm.dao.repository.HibernateBaseDao;

public final class DaoUtils extends HibernateBaseDao {

    private static final long serialVersionUID = 8277258368358530642L;

    public Blob createEmptyBlob() {
        Blob blob = Hibernate.getLobCreator(getSession()).createBlob(new byte[0]);
        return blob;
    }

}
