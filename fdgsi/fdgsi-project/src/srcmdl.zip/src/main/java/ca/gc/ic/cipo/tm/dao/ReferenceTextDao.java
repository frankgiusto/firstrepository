package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ReferenceText;

/**
 * ReferenceTextDAO is an interface used to find a reference text
 * based on a code type, a code level, and/or language.  
 * 
 * @author DenisJ1
 *
 */
public interface ReferenceTextDao {	
	
	/**
	 * Retrieve the reference text for the given code type, code value and language.
	 *  
	 * @param code The type of code to retrieve.
	 * @param codeLevel The code value to retrieve.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return The reference code information if found, otherwise null. 
	 */
	public ReferenceText get(Integer code, Integer codeLevel, Integer language);		
	
	/**
	 * Retrieve a reference text list for the given code type.
	 *  
	 * @param code The type of code to retrieve.
	 * 
	 * @return A list of reference code information if found, otherwise null. 
	 */
	public List<ReferenceText> list(Integer code);
	
	/**
	 * Retrieve a reference text list for the given code type and language.
	 *  
	 * @param code The type of code to retrieve.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return A list of reference code information if found, otherwise null. 
	 */	
	public List<ReferenceText> list(Integer code, Integer language);	
}
