package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Set;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.TradeMarkTypeDao;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.model.TrademarkType;

@Repository("tradeMarkTypeDao")
public class TradeMarkTypeDaoImpl extends HibernateBaseDao implements TradeMarkTypeDao {

    private static final long serialVersionUID = 1L;

    @Override
    public Set<TrademarkType> getTradeMarkTypes(TradeMark tradeMark) {
        Set<TrademarkType> trademarkTypes = tradeMark.getTrademarkTypes();
        return trademarkTypes;
    }

}
