package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.RegfeedecuseAllowed;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Contract interface for Searching Applications for Registration
 */
public interface SearchRegRenApplicationsForRegistrationDao {

    /**
     * Interface to retrieve applications based on the search criteria
     *
     * @param searchCriteria the SearchCriteria object encapsulating the search fields.
     * @return the list of RegfeedecuseAllowed type objects
     */
    public List<RegfeedecuseAllowed> searchApplicationsForRegistration(SearchRegistrationCriteria searchCriteria);

}
