package ca.gc.ic.cipo.tm.exception;

/**
 * TrademarkNotFoundException is a runtime exception implementation that 
 * is raise when a Trademarks Application or it's content is not found.  
 *  
 * @author DenisJ1
 */
public class TrademarkNotFoundException extends RuntimeException {

    /**
	 * Unique serial ID.
	 */
	private static final long serialVersionUID = 5516328513326849526L;

	/**
     * Constructor.
     */
    public TrademarkNotFoundException() {
        super();
    }

    /**
     * Constructor.
     * 
     * @param message the message.
     */
    public TrademarkNotFoundException(final String message) {
        super(message);
    }
    
    /**
     * Constructor.
     * 
     * @param message The message.
     * @param throwable The throwable if any.
     */
    public TrademarkNotFoundException(final String message, Throwable throwable) {
        super(message, throwable);
    }
}
