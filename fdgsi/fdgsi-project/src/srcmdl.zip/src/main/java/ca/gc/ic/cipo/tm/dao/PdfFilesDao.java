/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.EmailJobsId;
import ca.gc.ic.cipo.tm.model.PdfFiles;
import ca.gc.ic.cipo.tm.model.PdfFilesId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface PdfFilesDao {

    public Set<PdfFiles> getPdfFiles(Integer emailJobNumber);

    public Set<PdfFiles> getPdfFiles(Integer emailJobNumber, Integer outputCode);

    public Set<PdfFiles> getPdfFiles(EmailJobsId EmailJobsId);

    public Set<PdfFiles> getPdfFiles(EmailJobs emailJobs);

    public Set<PdfFiles> getPdfFiles(EmailJobsId emailJobsId, Integer outputCode);

    public Set<PdfFiles> getPdfFiles(EmailJobs emailJobs, Integer outputCode);

    public Set<PdfFiles> getPdfFiles(EmailJobsId emailJobsId, PdfFilesId pdfFilesId);
}
