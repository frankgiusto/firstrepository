package ca.gc.ic.cipo.tm.type;

public enum TradeMarkPropertyKey {

    CONTENT_PATH_WORD("tm.model.dao.repository.content.path.word"),
    CONTENT_PATH_DESIGNS("tm.model.dao.repository.content.path.designs"),
    CONTENT_PATH_SOUNDS("tm.model.dao.repository.content.path.sounds"),
    @Deprecated CONTENT_PATH_VIDEOS("tm.model.dao.repository.content.path.videos"),
    CONTENT_PATH_MOTION("tm.model.dao.repository.content.path.motion"),
    CONTENT_PATH_STANDARD_CHARACTER("tm.model.dao.repository.content.path.standard.character"),
    CONTENT_PATH_COLOR("tm.model.dao.repository.content.path.color"),
    CONTENT_PATH_THREE_DIMENSIONAL("tm.model.dao.repository.content.path.three.dimensional"),
    CONTENT_PATH_HOLOGRAM("tm.model.dao.repository.content.path.hologram"),
    CONTENT_PATH_PACKAGING_GOODS("tm.model.dao.repository.content.path.packaging.goods"),
    CONTENT_PATH_POSITIONAL("tm.model.dao.repository.content.path.positional"),
    CONTENT_PATH_TASTE("tm.model.dao.repository.content.path.taste"),
    CONTENT_PATH_SCENT("tm.model.dao.repository.content.path.scent"),
    CONTENT_PATH_TEXTURE("tm.model.dao.repository.content.path.texture"),
    CONTENT_PATH_MULTI_TYPE("tm.model.dao.repository.content.path.multi.type"),
    CONTENT_PATH_GI("tm.model.dao.repository.content.path.gi"),
    CONTENT_PATH_ROOT("tm.model.dao.repository.content.path.root"),
    CONTENT_NAME_FORMAT("tm.model.dao.repository.content.name.format"),
    NICE_CLASS_CURRENT_EDITION("tm.model.dao.repository.nice.class.current.edition"),
    CONTENT_DEFAULT_DESIGN("tm.model.dao.repository.content.default.design"),
    CONTENT_FILTER_EXTENSION("tm.model.dao.repository.content.filter.extension.");

    private String value;

    private TradeMarkPropertyKey(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public Boolean isEqualTo(String value) {
        return (this.value == value);
    }
}
