/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.MailDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Mail;

@Repository("mailDao")
public class MailDaoImpl extends HibernateBaseDao implements MailDao {

    private static final long serialVersionUID = -1351054033328764602L;

    /**
     * MAIL table does not have a primary key. Hence need to by pass Hibernate
     */
    private static final String UPDATE_MAIL_ATTACHED_IND_FOR_ATTACHED_FILE_NAME_SQL = " UPDATE MAIL set MAIL_ATTACHED_IND = 1 where FILE_NUMBER = :fileNumber AND "
        + " FILE_TYPE = :fileType AND MAIL_ATTACHED_IND = 0 AND ATTACHMENT_FILE_NAME =  :mailAttachmentFilename ";

    private static final String UPDATE_MAIL_ATTACHED_IND_SQL = " UPDATE MAIL set MAIL_ATTACHED_IND = 1, PROCESSED_BY_AUTHORITY_ID = :processByAuthorityID where FILE_NUMBER = :fileNumber AND "
        + " FILE_TYPE = :fileType AND MAIL_ATTACHED_IND = 0 ";

    private static final String UPDATE_MAIL_ATTACHED_IND_FOR_MAIL_TYPE_SQL = " UPDATE MAIL set MAIL_ATTACHED_IND = 1, PROCESSED_BY_AUTHORITY_ID = :processByAuthorityID where FILE_NUMBER = :fileNumber AND "
        + " FILE_TYPE = :fileType AND MAIL_ATTACHED_IND = 0 AND MAIL_TYPE =  :mailType ";

    private static final String DELETE_MAIL_RECORD_SQL = " DELETE FROM MAIL where FILE_NUMBER = :fileNumber AND "
        + " FILE_TYPE = :fileType AND ATTACHMENT_FILE_NAME = :attachmentFilename ";

    /** {@inheritDoc} */
    @Override
    public void saveMail(Mail mail) {
        Session session = getSession();
        session.saveOrUpdate(mail);
    }

    @Override
    public List<Mail> getMailByFileId(Integer fileNumber) {
        if (fileNumber == null) {
            throw new IllegalArgumentException("invalid parameters. fileNumber is required.");
        }
        List<Mail> mails = Collections.<Mail> emptyList();
        Criteria criteria = getSession().createCriteria(Mail.class);
        criteria.add(Restrictions.eq("fileNumber", fileNumber));
        criteria.addOrder(Order.desc("mailRoomDate"));
        try {
            mails = findByCriteria(criteria);
        } catch (Throwable ex) {
            String msg = "Problem in retrieving mails for specified file number";
            logger.error(msg, ex);
            throw new DataAccessException(msg, ex);
        }
        return mails;
    }

    @Override
    public Mail getMail(Integer fileNumber, Integer fileType, Integer mailAttachedInd, String attachmentFilename) {
        Mail mail = null;
        try {
            Criteria criteria = getSession().createCriteria(Mail.class);
            criteria.add(Restrictions.eq(ModelPropertyType.MAIL_ID_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.MAIL_ID_FILE_TYPE.getValue(), fileType));
            criteria.add(Restrictions.eq(ModelPropertyType.MAIL_ID_MAIL_ATTACHED_IND.getValue(), mailAttachedInd));
            criteria.add(Restrictions.eq(ModelPropertyType.MAIL_ATTACHMENT_FILE_NAME.getValue(), attachmentFilename));
            mail = super.findUniqueByCriteria(criteria);
        } catch (Exception ex) {
            String msg = "Problem in retrieving mail record for file number [" + fileNumber + " ] ";
            logger.error(msg);
            throw new DataAccessException(ex);
        }
        return mail;
    }

    @Override
    public void updateMailAttachedIndicator(Integer fileType, Integer fileNumber, String attachmentFilename) {
        // can be renamed to updateMailAttachedIndicatorForAttachedFileName??
        Objects.requireNonNull(fileType);
        Objects.requireNonNull(fileNumber);
        Objects.requireNonNull(attachmentFilename);

        getSession().flush();
        Query query = getSession().createSQLQuery(UPDATE_MAIL_ATTACHED_IND_FOR_ATTACHED_FILE_NAME_SQL);

        query.setParameter("fileType", fileType, IntegerType.INSTANCE);
        query.setParameter("fileNumber", fileNumber, IntegerType.INSTANCE);
        query.setParameter("mailAttachmentFilename", attachmentFilename);
        query.executeUpdate();
    }

    @Override
    public void updateMailAttachedIndicatorWithAuthority(Integer fileNumber, String processedByAuthorityID,
                                                         Integer fileType) {
        Objects.requireNonNull(fileType);
        Objects.requireNonNull(fileNumber);

        getSession().flush();
        Query query = getSession().createSQLQuery(UPDATE_MAIL_ATTACHED_IND_SQL);

        query.setParameter("fileType", fileType, IntegerType.INSTANCE);
        query.setParameter("fileNumber", fileNumber, IntegerType.INSTANCE);
        query.setParameter("processByAuthorityID", processedByAuthorityID, StringType.INSTANCE);
        query.executeUpdate();
    }

    @Override
    public void updateMailAttachedIndicatorWithAuthority(Integer fileNumber, String processedByAuthorityID,
                                                         Integer fileType, Integer mailType) {
        Objects.requireNonNull(fileType);
        Objects.requireNonNull(fileNumber);

        getSession().flush();
        Query query = getSession().createSQLQuery(UPDATE_MAIL_ATTACHED_IND_FOR_MAIL_TYPE_SQL);

        query.setParameter("fileType", fileType, IntegerType.INSTANCE);
        query.setParameter("fileNumber", fileNumber, IntegerType.INSTANCE);
        query.setParameter("mailType", mailType, IntegerType.INSTANCE);
        query.setParameter("processByAuthorityID", processedByAuthorityID, StringType.INSTANCE);
        query.executeUpdate();
    }

    @Override
    public void deleteMailRecord(Integer fileNumber, Integer fileType, String attachmentFilename) {
        Objects.requireNonNull(fileType);
        Objects.requireNonNull(fileNumber);

        getSession().flush();
        Query query = getSession().createSQLQuery(DELETE_MAIL_RECORD_SQL);

        query.setParameter("fileNumber", fileNumber, IntegerType.INSTANCE);
        query.setParameter("fileType", fileType, IntegerType.INSTANCE);
        query.setParameter("attachmentFilename", attachmentFilename, StringType.INSTANCE);
        query.executeUpdate();
    }

}
