package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ClaimTextDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ClaimText;
import ca.gc.ic.cipo.tm.model.ClaimTextId;

/**
 * The ClaimTextDaoImpl retrieves data from the Claim Text Table using Hibernate.
 *
 * @see ClaimTextDao
 * @see HibernateBaseDAO
 *
 * @author SeguinA3
 *
 */
@Repository("claimTextDao")
public class ClaimTextDaoImpl extends HibernateBaseDao implements ClaimTextDao {

    private static final long serialVersionUID = -6877797649452771965L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ClaimTextDaoImpl.class);

    @Override
    public Set<ClaimText> getClaimText(ApplicationNumber applicationNumber) {
        return this.getClaimText(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    @Override
    public Set<ClaimText> getClaimText(Integer fileNumber, Integer extensionCounter) {
        List<ClaimText> claimTexts = new ArrayList<ClaimText>();
        try {
            Criteria criteria = getSession().createCriteria(ClaimText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            claimTexts = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving claim text with parematers [" + fileNumber + ", " + extensionCounter + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<ClaimText>(claimTexts);
    }

    @Override
    public Set<ClaimText> getClaimText(Application application) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getClaimText(applicationNumber);
    }

    @Override
    public Set<ClaimText> getClaimText(ApplicationNumber applicationNumber, Integer claimType, Integer claimNumber) {
        return this.getClaimText(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(), claimType,
            claimNumber);
    }

    @Override
    public Set<ClaimText> getClaimText(Integer fileNumber, Integer extensionCounter, Integer claimType,
                                       Integer claimNumber) {
        List<ClaimText> claimTexts = new ArrayList<ClaimText>();
        try {
            Criteria criteria = getSession().createCriteria(ClaimText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_TEXT_ID_CLAIM_TYPE.getValue(), claimType));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_TEXT_ID_CLAIM_NUMBER.getValue(), claimNumber));
            claimTexts = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving claim text with parameters [" + fileNumber + ", " + extensionCounter + ", "
                + claimType + ", " + claimNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<ClaimText>(claimTexts);
    }

    @Override
    public Set<ClaimText> getClaimText(Application application, Integer claimType, Integer claimNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getClaimText(applicationNumber, claimType, claimNumber);
    }

    @Override
    public Set<ClaimText> getClaimText(ApplicationNumber applicationNumber, Integer claimType, Integer claimNumber,
                                       Integer originalInd) {
        return this.getClaimText(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(), claimType,
            claimNumber, originalInd);
    }

    @Override
    public Set<ClaimText> getClaimText(Integer fileNumber, Integer extensionCounter, Integer claimType,
                                       Integer claimNumber, Integer originalInd) {
        List<ClaimText> claimTexts = new ArrayList<ClaimText>();
        try {
            Criteria criteria = getSession().createCriteria(ClaimText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_TEXT_ID_CLAIM_TYPE.getValue(), claimType));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_TEXT_ID_CLAIM_NUMBER.getValue(), claimNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_TEXT_ID_ORIGINAL_IND.getValue(), originalInd));
            claimTexts = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving claim text with parameters [" + fileNumber + ", " + extensionCounter + ", "
                + claimType + ", " + claimNumber + ", " + originalInd + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<ClaimText>(claimTexts);
    }

    @Override
    public Set<ClaimText> getClaimText(Application application, Integer claimType, Integer claimNumber,
                                       Integer originalInd) {
        return this.getClaimText(application.getFileNumber(), application.getExtensionCounter(), claimType, claimNumber,
            originalInd);
    }

    @Override
    public Set<ClaimText> getClaimText(ClaimTextId claimTextId) {
        return this.getClaimText(claimTextId.getFileNumber(), claimTextId.getExtensionCounter(),
            claimTextId.getClaimType(), claimTextId.getClaimNumber(), claimTextId.getOriginalInd());
    }

    @Override
    public void saveClaimText(ClaimText claimText) {
        Session session = getSession();
        session.saveOrUpdate(claimText);
    }

}
