package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class SearchExpression implements Serializable {

    private static final long serialVersionUID = 4213259062293533761L;

    private HibernateOperatorEnum operator;

    private ModelPropertyType modelPropertyType;

    private String nestedModelPropertyType;

    private List<Object> values = new ArrayList<Object>();

    private Class<?> entityClass;

    private Object lowValue;

    private Object HighValue;

    /**
     * Used with Native SQL builder only
     */
    private String dbColumn;

    /**
     * Used for building parameterized SQL
     */
    private String paramName;

    public SearchExpression(ModelPropertyType type, HibernateOperatorEnum operator, Object value,
                            Class<?> entityClass) {
        this.modelPropertyType = type;
        this.operator = operator;
        this.values.add(value);
        this.entityClass = entityClass;
    }

    public SearchExpression(String type, HibernateOperatorEnum operator, Object value, Class<?> entityClass) {
        this.nestedModelPropertyType = type;
        this.operator = operator;
        this.values.add(value);
        this.entityClass = entityClass;
    }

    public SearchExpression(ModelPropertyType type, HibernateOperatorEnum operator, List<Object> values,
                            Class<?> entityClass) {
        this.modelPropertyType = type;
        this.operator = operator;
        this.values = values;
        this.entityClass = entityClass;
    }

    public SearchExpression(String type, HibernateOperatorEnum operator, List<Object> values, Class<?> entityClass) {
        this.nestedModelPropertyType = type;
        this.operator = operator;
        this.values = values;
        this.entityClass = entityClass;
    }

    private SearchExpression() {

    }

    /**
     * Makes search expression for Native SQL query only.
     *
     * @param dbColumn the database column name
     * @param paramName the parameter name
     * @param operator the operator (IN,EQUALS,LIKE,END_WITH,START_WITH) [Supports equivalent of SearchMethodType only)
     * @param values the parameter values
     * @return the newly constructed SearchExpression object
     */
    public static SearchExpression makeSearchExpression(String dbColumn, String paramName,
                                                        HibernateOperatorEnum operator, List<Object> values) {
        SearchExpression searchExpression = new SearchExpression();
        searchExpression.setDbColumn(Objects.requireNonNull(dbColumn));
        checkSupportedOperatorTypes(Objects.requireNonNull(operator));
        searchExpression.setOperator(operator);
        searchExpression.setValues(Objects.requireNonNull(values));
        searchExpression.setParamName(Objects.requireNonNull(paramName));
        return searchExpression;
    }

    /**
     * Makes search expression for Native SQL query only.
     *
     * @param dbColumn the database column name
     * @param paramName the parameter name
     * @param operator the operator (IN,EQUALS,LIKE,END_WITH,START_WITH) [Supports equivalent of SearchMethodType only)
     * @param values the parameter value
     * @return the newly constructed SearchExpression object
     */
    public static SearchExpression makeSearchExpression(String dbColumn, String paramName,
                                                        HibernateOperatorEnum operator, Object value) {
        SearchExpression searchExpression = new SearchExpression();
        searchExpression.setDbColumn(Objects.requireNonNull(dbColumn));
        checkSupportedOperatorTypes(Objects.requireNonNull(operator));
        searchExpression.setOperator(operator);
        searchExpression.getValues().add(Objects.requireNonNull(value));
        searchExpression.setParamName(Objects.requireNonNull(paramName));
        return searchExpression;
    }

    private static void checkSupportedOperatorTypes(HibernateOperatorEnum operator) {
        if (operator != HibernateOperatorEnum.EQUAL && operator != HibernateOperatorEnum.LIKE
            && operator != HibernateOperatorEnum.START_WITH && operator != HibernateOperatorEnum.END_WITH
            && operator != HibernateOperatorEnum.IN) {
            throw new IllegalArgumentException("Unsupported operator supplied. Expected operator: "
                + HibernateOperatorEnum.EQUAL.getValue() + ", " + HibernateOperatorEnum.LIKE.getValue() + ", "
                + HibernateOperatorEnum.START_WITH.getValue() + ", " + HibernateOperatorEnum.END_WITH.getValue());
        }
    }

    /**
     * @return the paramName
     */
    public String getParamName() {
        return paramName;
    }

    /**
     * @param paramName the paramName to set
     */
    public void setParamName(String paramName) {
        this.paramName = paramName;
    }

    public HibernateOperatorEnum getOperator() {
        return operator;
    }

    public void setOperator(HibernateOperatorEnum operator) {
        this.operator = operator;
    }

    public ModelPropertyType getModelPropertyType() {
        return modelPropertyType;
    }

    public void setModelPropertyType(ModelPropertyType modelPropertyType) {
        this.modelPropertyType = modelPropertyType;
    }

    public String getNestedModelPropertyType() {
        return nestedModelPropertyType;
    }

    public void setNestedModelPropertyType(String nestedModelPropertyType) {
        this.nestedModelPropertyType = nestedModelPropertyType;
    }

    public List<Object> getValues() {
        return values;
    }

    public void setValues(List<Object> values) {
        this.values = values;
    }

    public void addValue(Object value) {
        this.values.add(value);
    }

    public Class<?> getEntityClass() {
        return entityClass;
    }

    public void setEntityClass(Class<?> entityClass) {
        this.entityClass = entityClass;
    }

    public Object getLowValue() {
        return lowValue;
    }

    public void setLowValue(Object lowValue) {
        this.lowValue = lowValue;
    }

    public Object getHighValue() {
        return HighValue;
    }

    public void setHighValue(Object highValue) {
        HighValue = highValue;
    }

    public List<String> allValuesToString() {
        List<String> valueStrings = new ArrayList<>();
        List<Object> values = this.getValues();
        if (!CollectionUtils.isEmpty(values)) {
            for (Object value : values) {
                if (value != null) {
                    if (value instanceof String) {
                        valueStrings.add((String) value);
                    } else if (value instanceof Integer) {
                        valueStrings.add(String.valueOf(value));
                    } else {
                        valueStrings.add(value.toString());
                    }
                }
            }
        }
        return valueStrings;
    }

    public String firstValueToString() {
        String valueString = null;
        Object value = this.getValues().get(0);

        if (value != null) {

            if (value instanceof String) {
                valueString = (String) value;

            } else if (value instanceof Integer) {
                valueString = String.valueOf(value);

            } else {
                valueString = value.toString();
            }
        }
        return valueString;
    }

    public Boolean isValid() {
        Integer errorCount = 0;
        if (null == this.getOperator()) {
            errorCount++;
        }
        if (null == this.getModelPropertyType()) {
            errorCount++;
        }
        if (null == this.getNestedModelPropertyType() || this.getNestedModelPropertyType().isEmpty()) {
            errorCount++;
        }
        if (null == this.getValues() || this.getValues().isEmpty()) {
            errorCount++;
        }
        if (null == this.getEntityClass()) {
            errorCount++;
        }

        return (errorCount > 0);
    }

    public String getDbColumn() {
        return dbColumn;
    }

    public void setDbColumn(String dbColumn) {
        this.dbColumn = dbColumn;
    }

    public String getValueString() {
        if (!CollectionUtils.isEmpty(getValues())) {
            Object obj = getValues().get(0);

            if (obj instanceof Integer) {
                Integer val = (Integer) obj;
                return String.valueOf(val);
            }
            return String.valueOf(obj);
        }
        return null;
    }

}
