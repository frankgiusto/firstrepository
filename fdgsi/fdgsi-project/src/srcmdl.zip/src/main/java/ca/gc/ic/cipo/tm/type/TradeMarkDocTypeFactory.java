package ca.gc.ic.cipo.tm.type;

import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;

// TODO remove class
@Deprecated
public class TradeMarkDocTypeFactory {

    public static TradeMarkDocType getInstance(Integer trademarkType) {
        if (TradeMarkType.WORD.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeWord();
        }
        if (TradeMarkType.DESIGN.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeDesign();
        }
        if (TradeMarkType.SOUND.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeSound();
        }

        if (TradeMarkType.MULTI_TYPE.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeMultiType();
        }

        if (TradeMarkType.COLOR.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeColor();
        }
        if (TradeMarkType.HOLOGRAM.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeHologram();
        }
        if (TradeMarkType.MOTION.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeMotion();
        }
        if (TradeMarkType.PACKAGING_GOOD.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypePackagingGoods();
        }
        if (TradeMarkType.POSITIONAL.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypePositional();
        }
        if (TradeMarkType.SCENT.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeScent();
        }
        if (TradeMarkType.STANDARD_CHARACTERS.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeStandardCharacter();
        }
        if (TradeMarkType.TASTE.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeTaste();
        }
        if (TradeMarkType.TEXTURE.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeTexture();
        }
        if (TradeMarkType.THREE_DIMENSIONAL.isEqualTo(trademarkType)) {
            return new TradeMarkDocTypeThreeDimensional();
        }

        return null;
    }
}
