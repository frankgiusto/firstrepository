/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseId;
import ca.gc.ic.cipo.tm.model.OralHearingDetails;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface OralHearingDetailsDao {

    public Set<OralHearingDetails> getOralHearingDetails(Integer fileNumber, Integer extensionCounter,
                                                         Integer oppCaseNumber);

    public Set<OralHearingDetails> getOralHearingDetails(OppositionCaseId oppositionCaseId);

    public Set<OralHearingDetails> getOralHearingDetails(OppositionCase oppostionCase);

}
