package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DocumentLocation;
import ca.gc.ic.cipo.tm.model.DocumentLocationId;

public interface DocumentLocationDao {

    /**
     * @param documentLocationId
     * @param extensionCounter
     * @param oppCaseNumber
     * @return
     */
    public DocumentLocation getDocumentLocation(DocumentLocationId documentLocationId, Integer extensionCounter,
                                                Integer oppCaseNumber);

    /**
     * @param applicationNumber
     * @return
     */
    public List<DocumentLocation> getDocumentLocations(ApplicationNumber applicationNumber);

    /**
     * @param fileNumber
     * @return
     */
    public List<DocumentLocation> getDocumentLocations(Integer fileNumber);

    /**
     * @param fileNumber
     * @param extensionCounter
     * @return
     */
    public List<DocumentLocation> getDocumentLocations(Integer fileNumber, Integer extensionCounter);

    /**
     * Saves document location in table DOCUMENT_LOCATIONS
     *
     * @param documentLocation
     */
    public void saveDocumentLocation(DocumentLocation documentLocation);

}
