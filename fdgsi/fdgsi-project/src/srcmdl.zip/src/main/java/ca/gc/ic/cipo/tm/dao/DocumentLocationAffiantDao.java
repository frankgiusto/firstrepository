package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DocumentLocationAffiant;
import ca.gc.ic.cipo.tm.model.DocumentLocationAffiantId;

public interface DocumentLocationAffiantDao {

    /**
     * @param documentLocationAffiantId
     * @param extensionCounter
     * @param oppCaseNumber
     * @return
     */
    public DocumentLocationAffiant getDocumentLocationAffiant(DocumentLocationAffiantId documentLocationAffiantId,
                                                              Integer extensionCounter, Integer oppCaseNumber);

    /**
     * @param applicationNumber
     * @return
     */
    public List<DocumentLocationAffiant> getDocumentLocationsAffiant(ApplicationNumber applicationNumber);

    /**
     * @param fileNumber
     * @return
     */
    public List<DocumentLocationAffiant> getDocumentLocationsAffiant(Integer fileNumber);

    /**
     * @param fileNumber
     * @param extensionCounter
     * @return
     */
    public List<DocumentLocationAffiant> getDocumentLocationsAffiant(Integer fileNumber, Integer extensionCounter);

    /**
     * Saves the document location affiant in table DOCUMENT_LOCATIONS_AFFIANT
     *
     * @param documentLocationAffiant
     */
    public void saveDocumentLocationAffiant(DocumentLocationAffiant documentLocationAffiant);
}
