package ca.gc.ic.cipo.tm.dao.search;

import java.util.List;
import java.util.Map;

import ca.gc.ic.cipo.tm.enumerator.SearchItemType;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public interface OppositionApplicationSearch {

    public List<Application> searchOppositionApplications(List<Expression> expressions,
                                                          Map<SearchItemType, Boolean> searchItemTypesMap,
                                                          HibernateOperatorEnum searchOperator);

}
