package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.StoredProcedureDao;
import ca.gc.ic.cipo.tm.enumerator.StoreFileParameterType;
import ca.gc.ic.cipo.tm.model.StoreFileStoredProcedureParameters;
import ca.gc.ic.cipo.tm.model.StoredProcedureParameter;

@Repository("storedProcedureDao")
public class StoredProcedureDaoImpl extends HibernateBaseDao implements StoredProcedureDao {

    private static final long serialVersionUID = -7315792008499555458L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(StoredProcedureDaoImpl.class);

    @Autowired
    @Qualifier("dataSource")
    private DataSource dataSource;

    @Override
    /** @{inheritDoc} */
    public boolean callStoreFile(String storeProcedureName, StoreFileStoredProcedureParameters params) {
        LOG.debug("About to execute the stored procedure " + storeProcedureName);
        SimpleJdbcCall simpleJdbcCall = populateStoredProcedureParameters(StoreFileParameterType.class,
            storeProcedureName);
        Map<String, Object> paramsMap = populateParameterValuesAndReturn(params);
        Map<String, Object> out = simpleJdbcCall.execute(paramsMap);
        Object output = out.get(StoreFileParameterType.STORED_FILE.getParamName());
        boolean result = (output instanceof String);
        LOG.debug(storeProcedureName + " is successfully executed");
        return result;
    }

    /**
     * Build and returns the SimpleJdbcCall back to the caller.
     *
     * @param storedProcedureParameters Class<T> of type Enum implementing the StoredProcedureParameter
     * @param storeProcedureName the name of the stored procedure to call
     * @return the SimpleJdbcCall object
     */
    private <T extends Enum<T> & StoredProcedureParameter> SimpleJdbcCall populateStoredProcedureParameters(Class<T> storedProcedureParameters,
                                                                                                            String storeProcedureName) {
        Objects.requireNonNull(storedProcedureParameters);

        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(this.dataSource);
        simpleJdbcCall.withProcedureName(storeProcedureName);
        simpleJdbcCall.withoutProcedureColumnMetaDataAccess();

        for (StoredProcedureParameter eachParameter : storedProcedureParameters.getEnumConstants()) {
            // if output parameter only
            if (eachParameter.isOutputParameter()) {
                simpleJdbcCall
                    .declareParameters(new SqlOutParameter(eachParameter.getParamName(), eachParameter.getType()));
            } else {
                // input parameters
                simpleJdbcCall
                    .declareParameters(new SqlParameter(eachParameter.getParamName(), eachParameter.getType()));

            }
        }
        return simpleJdbcCall;
    }

    /**
     * Populates the value of the stored procedure parameter
     *
     * @param params the parameters object
     * @return the map of populated SP parameters
     */
    private Map<String, Object> populateParameterValuesAndReturn(StoreFileStoredProcedureParameters params) {
        Map<String, Object> paramsMap = new HashMap<>();
        paramsMap.put(StoreFileParameterType.SQL_QUERY.getParamName(), params.getSqlQuery());
        paramsMap.put(StoreFileParameterType.FILE_NUMBER.getParamName(), params.getFileNumber());
        paramsMap.put(StoreFileParameterType.EXTENSION_COUNTER.getParamName(), params.getExtensionCounter());
        paramsMap.put(StoreFileParameterType.FILE_TYPE.getParamName(), params.getFileType());
        paramsMap.put(StoreFileParameterType.FILE_NAME.getParamName(), params.getFileName());
        return paramsMap;
    }
}
