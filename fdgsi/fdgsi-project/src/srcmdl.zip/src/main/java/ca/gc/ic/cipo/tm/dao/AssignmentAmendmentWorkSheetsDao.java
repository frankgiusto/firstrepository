/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFilesId;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheets;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetsId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface AssignmentAmendmentWorkSheetsDao {

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(Integer workSheetNumber);

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(Integer workSheetNumber,
                                                                               String authorityId);

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFilesId aAWorkSheetFilesId);

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFiles aAWorkSheetFiles);

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFilesId aAWorkSheetFilesId,
                                                                               String authorityId);

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFiles aAWorkSheetFiles,
                                                                               String authorityId);

    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFilesId aAWorkSheetFilesId,
                                                                               AssignmentAmendmentWorkSheetsId aAWorkSheetsId);

    public Set<AssignmentAmendmentTransaction> getAssignmentAmendmentTransactions(String authorityId,
                                                                                  Integer workSheetNumber,
                                                                                  Integer aatNumber);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                       Integer extensionCounter,
                                                                                       Integer workSheetNumber);
}
