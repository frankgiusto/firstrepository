package ca.gc.ic.cipo.tm.dao.search;

public interface Expression {

    public Object compose();

    public void accept(ExpressionVisitor expressionVisitor);

}
