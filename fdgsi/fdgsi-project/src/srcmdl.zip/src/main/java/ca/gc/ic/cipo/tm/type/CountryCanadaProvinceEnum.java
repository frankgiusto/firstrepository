/**
 *
 */
package ca.gc.ic.cipo.tm.type;

import java.util.ArrayList;
import java.util.List;

public enum CountryCanadaProvinceEnum {
    /** Canada */
    CA("CA"),

    /** AB */
    A1("A1"),

    /** BC */
    B1("B1"),

    /** Manitoba */
    M1("M1"),

    /** Saskatchewan */
    S1("S1"),

    /** NL */
    N1("N1"),

    /** NS */
    N2("N2"),

    /** NB */
    N3("N3"),

    /** NT */
    N4("N4"),

    /** PE */
    P1("P1"),

    /** NU */
    N6("N6"),

    /** YT */
    Y1("Y1"),

    /** ON */
    O1("O1"),

    /** QE */
    Q1("Q1");

    static final List<Object> COUNTRY_PROVINCE_LIST = new ArrayList<>();

    static {
        for (CountryCanadaProvinceEnum eachEntry : CountryCanadaProvinceEnum.values()) {
            COUNTRY_PROVINCE_LIST.add(eachEntry.getValue());
        }
    }

    private final String value;

    private CountryCanadaProvinceEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public Boolean isEqualTo(CountryCanadaProvinceEnum operator) {
        return (this.value == operator.getValue());
    }

    public static List<Object> getCountryCanadaProvinceEnumList() {
        return COUNTRY_PROVINCE_LIST;
    }

}
