package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.OppositionGroundsSubsection;

public interface OppositionGroundsSubsectionDao {

    public List<OppositionGroundsSubsection> getOppositionGroundsSubsections(Integer oppCode, Integer subsectionCode);

}
