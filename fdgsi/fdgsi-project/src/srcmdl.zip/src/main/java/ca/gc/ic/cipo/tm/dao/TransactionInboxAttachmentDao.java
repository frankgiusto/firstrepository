package ca.gc.ic.cipo.tm.dao;

import java.util.List;
import java.util.Map;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.FiledTransaction;
import ca.gc.ic.cipo.tm.model.TransactionInboxAttachment;

/**
 * TransactionInboxAttachmentDao is an DAO interface that manages transaction inbox attachment in trademark database.
 * This is a CRUD DAO.
 *
 * @see TransactionInboxAttachmen
 * @author MengW
 */
public interface TransactionInboxAttachmentDao extends BaseDao {

    /**
     * Return a reference of Transaction Inbox Attachment based on the given transaction attachment sequence number.
     *
     * @param transactionAttachmentSeqNum The transaction inbox attachment sequence number.
     * @return A TransactionInboxAttachment reference.
     */
    public TransactionInboxAttachment getTransactionAttachment(Integer inboxAttachmentSeqNumber);

    /**
     * Retrieve and return a list of transaction inbox attachments for the specified Transaction Inbox sequence number.
     *
     * @param transactionSeqNumber Transaction inbox sequence number
     * @return the list of type TransactionInboxAttachment objects;
     */
    public List<TransactionInboxAttachment> getTransactionAttachmentList(Integer transactionSeqNumber);

    /**
     * Retrieve and return a map with key as attachment type and value as list of TransactionInboxAttachment for
     * specific transaction inbox sequence number. Delegates to {@code getTransactionAttachmentList} method and then
     * builds the map.
     *
     * @param transactionInboxSeqNumber the transaction inbox sequence number
     * @return the Map of Key -> Attachment type; Value -> TransactionInboxAttachment
     */
    public Map<Integer, List<TransactionInboxAttachment>> getTransactionAttachmentsMap(Integer transactionInboxSeqNumber);

    /**
     * Save the Transaction Inbox Attachment with the given information
     *
     * @param transaction inbox attachment information to save or update.
     */
    public void saveTransactionAttachment(TransactionInboxAttachment attachment);

    /**
     * Retrieve and return transaction XML attachment from EC_TRANSACTION_INBOX table
     *
     * @param filedTransaction the FiledTransaction
     * @return the TransactionInboxAttachment model as populated by ORM
     */
    public TransactionInboxAttachment retrieveTransactionXmlBlob(FiledTransaction filedTransaction);

    /**
     * Retrieve and return application form PDF attachment from EC_TRANSACTION_INBOX table
     *
     * @param filedTransaction
     * @return the TransactionInboxAttachment model as populated by ORM
     */
    public TransactionInboxAttachment retrieveApplicationFormBlob(FiledTransaction filedTransaction);

    /**
     * Retrieves and returns the minimum transaction attachment information for the specified transaction inbox sequence
     * number
     *
     * @param transactionInboxSeqNumber the transaction inbox sequence number
     * @return the list of type TransactionInboxAttachment object(s)
     */
    List<TransactionInboxAttachment> getTransactionAttachmentMinimumInfoList(Integer transactionInboxSeqNumber);

    /**
     * Retrieves and returns the minimum transaction attachment information for the specified transaction inbox sequence
     * number without filtering on specific attachment types.
     *
     * @param transactionInboxSeqNumber the transaction inbox sequence number
     * @return the list of type TransactionInboxAttachment object(s)
     */
    List<TransactionInboxAttachment> getAllTransactionAttachmentMinimumInfoList(Integer transactionInboxSeqNumber);

}
