package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.Pair;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ClaimId;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.GoodServiceId;

public interface GoodsServicesClaimDao {

    public List<GoodServiceClaim> getGoodServiceClaims(ApplicationNumber applicationNumber);

    public List<GoodServiceClaim> getGoodServiceClaimsByGSKey(ApplicationNumber applicationNumber,
                                                              Integer goodServiceType, Integer goodServiceNumber);

    public List<GoodServiceClaim> getGoodServiceClaimsByGSKey(Application application, Integer goodServiceType,
                                                              Integer goodServiceNumber);

    public List<GoodServiceClaim> getGoodServiceClaimsByGSKey(ApplicationNumber applicationNumber,
                                                              GoodServiceId goodServiceId);

    public List<GoodServiceClaim> getGoodServiceClaimsByClaimKey(ApplicationNumber applicationNumber, Integer claimType,
                                                                 Integer claimNumber);

    public List<GoodServiceClaim> getGoodServiceClaimsByClaimKey(Application application, Integer claimType,
                                                                 Integer claimNumber);

    public List<GoodServiceClaim> getGoodServiceClaimsByClaimKey(ApplicationNumber applicationNumber, ClaimId claimId);

    public GoodServiceClaim getGoodServiceClaimsByKeys(ApplicationNumber applicationNumber, Integer goodServiceType,
                                                       Integer goodServiceNumber, Integer claimType,
                                                       Integer claimNumber);

    public GoodServiceClaim getGoodServiceClaimsByKeys(ApplicationNumber applicationNumber, ClaimId claimId,
                                                       GoodServiceId goodServiceId);

    public void saveGoodServiceClaim(GoodServiceClaim goodServiceClaim);

    public List<GoodServiceClaim> getGoodServiceClaimsOrderByClaimType(ApplicationNumber applicationNumber);

    public List<GoodServiceClaim> getGoodServiceClaimsByGSKeyAndClaimType(ApplicationNumber applicationNumber,
                                                                          Integer gsType, Integer gsNumber,
                                                                          Integer claimType);

    public MultiValueMap<Pair<Integer, Integer>, GoodServiceClaim> getOrderedGoodServiceClaims(ApplicationNumber applicationNumber);
}
