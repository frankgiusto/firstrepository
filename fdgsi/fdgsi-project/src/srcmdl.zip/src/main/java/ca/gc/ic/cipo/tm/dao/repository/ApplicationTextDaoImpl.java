package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ApplicationTextDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ApplicationText;

/**
 * The ApplicationTextDaoImpl retrieves data from the ApplicationText Table using Hibernate
 *
 * @see ApplicationTextDao
 * @see HibernateBaseDAO
 *
 * @author SeguinA3
 *
 */
@Repository("applicationTextDao")
public class ApplicationTextDaoImpl extends HibernateBaseDao implements ApplicationTextDao {

    private static final long serialVersionUID = 440099858304731559L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ApplicationTextDaoImpl.class);

    @Override
    public List<ApplicationText> getApplicationText(ApplicationNumber applicationNumber) {
        List<ApplicationText> applicationTexts = null;
        Objects.requireNonNull(applicationNumber);
        try {

            Criteria criteria = getSession().createCriteria(ApplicationText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            applicationTexts = super.findByCriteria(criteria);

        } catch (Throwable ex) {
            logger.error("Error retrieving application text with parameters [" + applicationNumber.getFileNumber()
                + ", " + applicationNumber.getExtensionCounter() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return applicationTexts;
    }

    @Override
    public ApplicationText getApplicationText(ApplicationNumber applicationNumber, Integer textType,
                                              Integer originalInd) {

        Objects.requireNonNull(applicationNumber);
        Objects.requireNonNull(textType);
        Objects.requireNonNull(originalInd);
        ApplicationText applicationText = null;
        try {
            Criteria criteria = getSession().createCriteria(ApplicationText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_TEXT_ID_TEXT_TYPE.getValue(), textType));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_TEXT_ID_ORIGINAL_IND.getValue(), originalInd));
            applicationText = super.findUniqueByCriteria(criteria);

        } catch (Throwable ex) {
            logger.error("Error retrieving application text with parameters [" + applicationNumber.getFileNumber()
                + ", " + applicationNumber.getExtensionCounter() + ", " + textType + ", " + originalInd + "]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return applicationText;
    }

    @Override
    public void saveApplicationText(ApplicationText applicationText) {
        Objects.requireNonNull(applicationText);
        Session session = getSession();
        session.saveOrUpdate(applicationText);
    }
}
