/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.HistoricalFileActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.HistoricalFileActions;

/**
 * The CurrentFileActionsDaoImpl retrieves data from the HISTORICAL_FILE_ACTIONS Table using Hibernate.
 *
 * @see HistoricalFileActionsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("historicalFileActionsDaoImpl")
public class HistoricalFileActionsDaoImpl extends HibernateBaseDao implements HistoricalFileActionsDao {

    /**
     *
     */
    private static final long serialVersionUID = 8161778316542987181L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(HistoricalFileActionsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<HistoricalFileActions> getHistoricalFileActions(String receiverAuthorityId, String senderAuthorityId) {
        // TODO Auto-generated method stub

        // TODO Auto-generated method stub
        List<HistoricalFileActions> historicalFileActions = new ArrayList<HistoricalFileActions>();
        try {
            Criteria criteria = getSession().createCriteria(HistoricalFileActions.class);
            criteria.add(Restrictions.eq(ModelPropertyType.CURRENT_FILE_ACTIONS_ID_RECEIVER_AUTHORITY_ID.getValue(),
                receiverAuthorityId));
            criteria.add(Restrictions.eq(ModelPropertyType.CURRENT_FILE_ACTIONS_ID_SENDER_AUTHORITY_ID.getValue(),
                senderAuthorityId));
            historicalFileActions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving historical file actions  with parameters [" + historicalFileActions + ", "
                + senderAuthorityId + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<HistoricalFileActions>(historicalFileActions);
    }

}
