/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.SelectedParagraphsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.SelectedParagraphs;
import ca.gc.ic.cipo.tm.model.SelectedParagraphsId;

/**
 * The SelectedParagraphsDaoImpl retrieves data from the SELECTED_PARAGRAPHS Table using Hibernate.
 */
// TODO not used for now
@Deprecated
@Repository("selectedParagraphsDao")
public class SelectedParagraphsDaoImpl extends HibernateBaseDao implements SelectedParagraphsDao {

    private static final long serialVersionUID = -4534612255642744951L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(SelectedParagraphsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<SelectedParagraphs> getSelectedParagraphs(Integer fileNumber, Integer extensionCounter,
                                                         Integer processType, Integer processCode, String authorityId) {
        // TODO Auto-generated method stub
        List<SelectedParagraphs> selectedParagraphs = new ArrayList<SelectedParagraphs>();
        try {
            Criteria criteria = getSession().createCriteria(SelectedParagraphs.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_PROCESS_TYPE.getValue(), processType));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_PROCESS_CODE.getValue(), processCode));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_ID_AUTHORITY_ID.getValue(), authorityId));
            selectedParagraphs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving process actions with parameters [" + fileNumber + ", " + extensionCounter
                + ", " + processType + ", " + processCode + ", " + authorityId + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<SelectedParagraphs>(selectedParagraphs);
    }

    /** {@inheritDoc} */
    @Override
    public Set<SelectedParagraphs> getSelectedParagraphs(Integer fileNumber, Integer extensionCounter,
                                                         Integer processType, Integer processCode, String authorityId,
                                                         Integer sequenceNumber) {
        // TODO Auto-generated method stub
        List<SelectedParagraphs> selectedParagraphs = new ArrayList<SelectedParagraphs>();
        try {
            Criteria criteria = getSession().createCriteria(SelectedParagraphs.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_PROCESS_TYPE.getValue(), processType));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_PROCESS_CODE.getValue(), processCode));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_ID_AUTHORITY_ID.getValue(), authorityId));
            criteria.add(
                Restrictions.eq(ModelPropertyType.SELECTED_PARAGRAPHS_ID_SEQUENCE_NUMBER.getValue(), sequenceNumber));
            selectedParagraphs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving process actions with parameters [" + fileNumber + ", " + extensionCounter
                + ", " + processType + ", " + processCode + ", " + authorityId + ", " + sequenceNumber + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<SelectedParagraphs>(selectedParagraphs);
    }

    /** {@inheritDoc} */
    @Override
    public Set<SelectedParagraphs> getSelectedParagraphs(ProcessAction processActions) {
        // TODO Auto-generated method stub
        return this.getSelectedParagraphs(processActions.getFileNumber(), processActions.getExtensionCounter(),
            processActions.getProcessType(), processActions.getProcessCode(), processActions.getAuthorityId());

    }

    /** {@inheritDoc} */
    @Override
    public Set<SelectedParagraphs> getSelectedParagraphs(ProcessAction processActions, Integer sequenceNumber) {
        // TODO Auto-generated method stub
        return this.getSelectedParagraphs(processActions.getFileNumber(), processActions.getExtensionCounter(),
            processActions.getProcessType(), processActions.getProcessCode(), processActions.getAuthorityId(),
            sequenceNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<SelectedParagraphs> getSelectedParagraphs(ProcessAction processActions,
                                                         SelectedParagraphsId selectedParagraphsId) {
        // TODO Auto-generated method stub
        return this.getSelectedParagraphs(processActions, selectedParagraphsId.getSequenceNumber());
    }

}
