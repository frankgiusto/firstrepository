package ca.gc.ic.cipo.tm.dao;

import java.util.Date;
import java.util.List;

import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;

public interface ActionDao {

    /**
     * Interface to retrieve actions based on file number and extension counter
     *
     * @param fileNumber
     * @param extensionCounter
     * @return Collection of Action object
     */
    public List<Action> getActions(Integer fileNumber, Integer extensionCounter);

    /**
     * Interface to retrieve actions based on an Application Number object containing the file number and extension
     * counter
     *
     * @param applicationNumber
     * @return Collection of Action Object
     */
    public List<Action> getActions(ApplicationNumber applicationNumber);

    /**
     *
     * @param action
     */
    public void saveAction(Action action);

    /**
     *
     * @param fileNumber
     * @param extensionCounter
     * @return
     */
    public List<Action> getActionsOnOrAfterAllowed(Integer fileNumber, Integer extensionCounter);

    /**
     * Retrieves and return true if specified action code is found for a specified file number; false otherwise
     */
    public boolean isOpposedActionRecordNotFound(ApplicationNumber applicationNumber, ActionCode actionCode);

    /**
     * Calculates and retrieves the date for specified file number and action codes
     *
     * @param applicationNumber application number
     * @return the calculated end of opposition period daae
     */
    public Date getEndOfAdvertisedDate(ApplicationNumber applicationNumber);

    /**
     * Checks if adjusted renewal fee is received (action code 179)
     * 
     * @param applicationNumber the application file number
     * @return true if received; false otherwise
     */
    public boolean isAdjustedRenewalFeeReceived(ApplicationNumber applicationNumber);

}
