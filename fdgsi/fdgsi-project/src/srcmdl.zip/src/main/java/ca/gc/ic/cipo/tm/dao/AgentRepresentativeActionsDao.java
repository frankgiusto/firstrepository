/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.AgentRepresentativeActions;
import ca.gc.ic.cipo.tm.model.AuthoritiesId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface AgentRepresentativeActionsDao {

    public Set<AgentRepresentativeActions> getAgentRepresentativeActions(Integer arNumber, String authorityId);

    public Set<AgentRepresentativeActions> getAgentRepresentativeActions(AgentRepresentative agentRepresentative,
                                                                         AuthoritiesId authoritiesId);

}
