package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.GoodsServicesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceId;

@Repository("goodsServicesDao")
public class GoodsServicesDaoImpl extends HibernateBaseDao implements GoodsServicesDao {

    private static final long serialVersionUID = -6877797649452771965L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(GoodsServicesDaoImpl.class);

    private static final String SQL_QUERY_FILE_NUM_WITH_SORT = " select {gs.*} from WARES_SERVICES gs where (1=1) and gs.FILE_NUMBER = :fileNumber and gs.EXTENSION_COUNTER = :extensionCounter order by gs.WS_TYPE, gs.NICE_CLASS_CODE nulls last, gs.WS_NUMBER ";

    /**
     * Count of unique classified nice class codes
     */
    private static final String UNIQUE_CLASSIFIED_GOODS_SQL = " select count(distinct ws.nice_class_code) as uniqueCount from WARES_SERVICES ws where ws.FILE_NUMBER = :fileNumber and ws.EXTENSION_COUNTER = :extensionCounter ";

    /**
     * Count of unclassified nice class codes (counting nulls only)
     */
    private static final String UN_CLASSIFIED_GOODS_SQL = " select count(*) - count(ws.nice_class_code) as unclassifiedCount from WARES_SERVICES ws where  ws.FILE_NUMBER = :fileNumber and ws.EXTENSION_COUNTER = :extensionCounter ";

    @Override
    public List<GoodService> getGoodService(Application application) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodService(applicationNumber);
    }

    @Override
    public List<GoodService> getGoodService(ApplicationNumber applicationNumber) {
        return getGoodService(applicationNumber, null, null);
    }

    @Override
    public List<GoodService> getGoodService(Application application, Integer goodServiceType,
                                            Integer goodServiceNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodService(applicationNumber, goodServiceType, goodServiceNumber);
    }

    @Override
    public List<GoodService> getGoodService(GoodServiceId goodServiceId) {
        ApplicationNumber applicationNumber = new ApplicationNumber(goodServiceId.getFileNumber(),
            goodServiceId.getExtensionCounter());
        return this.getGoodService(applicationNumber, goodServiceId.getType(), goodServiceId.getNumber());
    }

    @Override
    public List<GoodService> getGoodService(ApplicationNumber applicationNumber, Integer goodServiceType,
                                            Integer goodServiceNumber) {
        List<GoodService> goodServices = Collections.<GoodService> emptyList();
        try {
            Criteria criteria = getSession().createCriteria(GoodService.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            if (goodServiceType != null && goodServiceNumber != null) {
                criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_ID_TYPE.getValue(), goodServiceType));
                criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_ID_NUMBER.getValue(), goodServiceNumber));
            }
            goodServices = super.findByCriteria(criteria);

        } catch (Exception ex) {

            String erroMsg = null;
            if (goodServiceType != null && goodServiceNumber != null) {
                erroMsg = String.format("There are no Good Service with parameters [ %d, %d, %d, %d ]\n",
                    applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(), goodServiceType,
                    goodServiceNumber);
            } else {
                if (goodServiceType != null && goodServiceNumber != null) {
                    erroMsg = String.format("There are no Good Service with parameters [ %d, %d ]\n",
                        applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
                }
            }

            logger.error(erroMsg, ex);
            throw new DataAccessException(ex);
        }
        return goodServices;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GoodService> getGoodServiceWithSortEnabled(ApplicationNumber applicationNumber) {
        List<GoodService> goodServices = Collections.<GoodService> emptyList();
        try {
            Objects.requireNonNull(applicationNumber);
            Objects.requireNonNull(applicationNumber.getFileNumber());
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("fileNumber", applicationNumber.getFileNumber());
            parameters.put("extensionCounter", applicationNumber.getExtensionCounter());
            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(SQL_QUERY_FILE_NUM_WITH_SORT, parameters);
            sqlQuery.addEntity("gs", GoodService.class);
            goodServices = sqlQuery.list();
        } catch (Throwable ex) {
            if (applicationNumber != null && applicationNumber.getFileNumber() != null) {
                String erroMsg = String.format("There are no Good Service with parameters [ %d, %d]\n",
                    applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
                logger.error(erroMsg, ex);
            }
            throw new DataAccessException(ex);
        }
        return goodServices;
    }

    public void getGoodServiceText(GoodService goodService) {
        Hibernate.initialize(goodService.getGoodServiceTexts());
    }

    @Override
    public void saveGoodsServices(GoodService goodsService) {
        Session session = getSession();
        session.saveOrUpdate(goodsService);
    }

    @Override
    public void deleteGoodsServices(GoodService goodsService) {
        try {
            delete(goodsService);
        } catch (Exception he) {
            String message = "Could not delete " + goodsService.toString() + " - message: " + he.getMessage();
            throw new DataAccessException(message, he);
        }
    }

    @Override
    public Integer getUniqueClassifiedGoods(ApplicationNumber applicationNumber) {
        Integer count = null;
        try {
            Objects.requireNonNull(applicationNumber);
            Objects.requireNonNull(applicationNumber.getFileNumber());
            Objects.requireNonNull(applicationNumber.getExtensionCounter());

            Map<String, Object> parameters = new HashMap<>();
            parameters.put("fileNumber", applicationNumber.getFileNumber());
            parameters.put("extensionCounter", applicationNumber.getExtensionCounter());

            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(UNIQUE_CLASSIFIED_GOODS_SQL, parameters);
            sqlQuery.addScalar("uniqueCount", IntegerType.INSTANCE);

            count = (Integer) sqlQuery.uniqueResult();
        } catch (Throwable ex) {
            if (applicationNumber != null && applicationNumber.getFileNumber() != null) {
                String errorMsg = String.format(
                    "There are no Unique Classified Goods and Services with parameters [ %d, %d]\n",
                    applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
                logger.error(errorMsg, ex);
            }
            throw new DataAccessException(ex);
        }
        return count;
    }

    @Override
    public Integer getUnclassifiedGoods(ApplicationNumber applicationNumber) {
        Integer count = null;
        try {
            Objects.requireNonNull(applicationNumber);
            Objects.requireNonNull(applicationNumber.getFileNumber());
            Objects.requireNonNull(applicationNumber.getExtensionCounter());

            Map<String, Object> parameters = new HashMap<>();
            parameters.put("fileNumber", applicationNumber.getFileNumber());
            parameters.put("extensionCounter", applicationNumber.getExtensionCounter());

            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(UN_CLASSIFIED_GOODS_SQL, parameters);
            sqlQuery.addScalar("unclassifiedCount", IntegerType.INSTANCE);

            count = (Integer) sqlQuery.uniqueResult();
        } catch (Throwable ex) {
            if (applicationNumber != null && applicationNumber.getFileNumber() != null) {
                String errorMsg = String.format(
                    "There are no UnClassified Goods and Services with parameters [ %d, %d]\n",
                    applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
                logger.error(errorMsg, ex);
            }
            throw new DataAccessException(ex);
        }

        return count;
    }

}
