package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.AgentRepresentativeDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;

@Repository("agentRepresentativeDao")
@Transactional
public class AgentRepresentativeDaoImpl extends HibernateBaseDao implements AgentRepresentativeDao {

    private static final long serialVersionUID = 1L;

    private static final String ACTIVE_AGENTS_SQL = " select {ar.*} from {h-schema}agents_reps ar inner join {h-schema}agent_user_xref userRef "
        + " on ar.ar_number = userRef.ar_number "
        + " where userRef.user_id = :userId and ar.status_code = 1 and ar.ar_type in (1,3) ";

    /**
     * Only used for Unit testing purposes. See integration test of TIRS web service
     */
    private static final String MAX_AR_NUMBER = " select max(AR_NUMBER) as maxArNumber  from {h-schema}agents_reps ar ";

    /** @{inheritDoc} */
    @Override
    public List<AgentRepresentative> getActiveAgents(String userId) {
        if (!StringUtils.hasText(userId)) {
            throw new IllegalArgumentException("Agent user Id must not be blank or null");
        }
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("userId", userId);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(ACTIVE_AGENTS_SQL, parameters);
        sqlQuery.addEntity("ar", AgentRepresentative.class);

        @SuppressWarnings("unchecked")
        List<AgentRepresentative> results = sqlQuery.list();
        return results;
    }

    /** {@inheritDoc} */
    @Override
    public AgentRepresentative getAgentRepresentative(Integer arNumber) {

        AgentRepresentative agentRepresentative = null;
        try {
            Criteria criteria = getSession().createCriteria(AgentRepresentative.class);
            criteria.add(Restrictions.eq(ModelPropertyType.AGENT_REPRESENTATIVE_AR_NUMBER.getValue(), arNumber));
            agentRepresentative = super.findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving agrent/representative with parameters [" + arNumber + "]", ex);
            throw new DataAccessException(ex);
        }

        return agentRepresentative;
    }

    @Override
    public Integer getNextAgentRepresentativeNumber() {
        Map<String, Object> params = new HashMap<>();
        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(MAX_AR_NUMBER, params);
        sqlQuery.addScalar("maxArNumber", IntegerType.INSTANCE);

        Integer maxArNumber = (Integer) sqlQuery.uniqueResult();
        if (maxArNumber != null) {
            return maxArNumber + 1;
        }
        return null;
    }

}
