package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ClaimText;
import ca.gc.ic.cipo.tm.model.ClaimTextId;

public interface ClaimTextDao {

    public Set<ClaimText> getClaimText(Integer fileNumber, Integer extensionNumber);

    public Set<ClaimText> getClaimText(Integer fileNumber, Integer extensionNumber, Integer claimType,
                                       Integer claimNumber);

    // TODO, should not return collection since it is PK
    public Set<ClaimText> getClaimText(Integer fileNumber, Integer extensionNumber, Integer claimType,
                                       Integer claimNumber, Integer originalInd);

    public Set<ClaimText> getClaimText(ApplicationNumber applicationNumber);

    // TODO, remove, duplicated ApplicationNumber parameter
    public Set<ClaimText> getClaimText(Application application);

    public Set<ClaimText> getClaimText(ApplicationNumber applicationNumber, Integer claimType, Integer claimNumber);

    // TODO, remove, duplicated ApplicationNumber parameter
    public Set<ClaimText> getClaimText(Application application, Integer claimType, Integer claimNumber);

    // TODO, should not return collection since it is PK
    public Set<ClaimText> getClaimText(ApplicationNumber applicationNumber, Integer claimType, Integer claimNumber,
                                       Integer originalInd);

    // TODO, remove, duplicated ApplicationNumber parameter
    public Set<ClaimText> getClaimText(Application application, Integer claimType, Integer claimNumber,
                                       Integer originalInd);

    // TODO, should not return collection since it is PK
    public Set<ClaimText> getClaimText(ClaimTextId claimTextId);

    /**
     * Save claim text.
     *
     * @param claimText the claim text
     */
    public void saveClaimText(ClaimText claimText);
}
