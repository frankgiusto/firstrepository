package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.GoodServiceClassificationsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodServiceClassification;
import ca.gc.ic.cipo.tm.model.GoodServiceClassificationId;

@Repository("goodServiceClassificationsDao")
public class GoodServiceClassificationsDaoImpl extends HibernateBaseDao implements GoodServiceClassificationsDao {

    private static final long serialVersionUID = -3440863729372289768L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(GoodServiceClassificationsDaoImpl.class);

    @Override
    public Set<GoodServiceClassification> getGoodServiceClassifications(ApplicationNumber applicationNumber) {
        List<GoodServiceClassification> goodServiceClassifications = new ArrayList<GoodServiceClassification>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClassification.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            goodServiceClassifications = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger
                .error("There are no Good Service Classification with parameters [" + applicationNumber.getFileNumber()
                    + ", " + applicationNumber.getExtensionCounter() + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<GoodServiceClassification>(goodServiceClassifications);
    }

    @Override
    public Set<GoodServiceClassification> getGoodServiceClassifications(Application application) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceClassifications(applicationNumber);
    }

    @Override
    public Set<GoodServiceClassification> getGoodServiceClassifications(ApplicationNumber applicationNumber,
                                                                        Integer niceClassCode) {
        List<GoodServiceClassification> goodServiceClassifications = new ArrayList<GoodServiceClassification>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClassification.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria
                .add(Restrictions.eq(ModelPropertyType.WS_CLASSIFICATION_ID_NICE_CLASS_CODE.getValue(), niceClassCode));
            goodServiceClassifications = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "There are no Good Service Classification with parameters [" + applicationNumber.getFileNumber() + ", "
                    + applicationNumber.getExtensionCounter() + ", " + niceClassCode + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<GoodServiceClassification>(goodServiceClassifications);
    }

    @Override
    public Set<GoodServiceClassification> getGoodServiceClassifications(Application application,
                                                                        Integer niceClassCode) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceClassifications(applicationNumber, niceClassCode);
    }

    @Override
    public Set<GoodServiceClassification> getGoodServiceClassifications(GoodServiceClassificationId goodServiceClassificationId) {
        ApplicationNumber applicationNumber = new ApplicationNumber(goodServiceClassificationId.getFileNumber(),
            goodServiceClassificationId.getExtensionCounter());
        return this.getGoodServiceClassifications(applicationNumber);
    }

    @Override
    public void deleteGoodServiceClassifications(ApplicationNumber applicationNumber) {
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClassification.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            List<GoodServiceClassification> goodServiceClassifications = new ArrayList<GoodServiceClassification>();
            goodServiceClassifications = super.findByCriteria(criteria);
            if (!goodServiceClassifications.isEmpty()) {
                for (GoodServiceClassification obj : goodServiceClassifications) {
                    getSession().delete(obj);
                }
            }
        } catch (Exception ex) {
            logger
                .error("There are no Good Service Classification with parameters [" + applicationNumber.getFileNumber()
                    + ", " + applicationNumber.getExtensionCounter() + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
    }

    @Override
    public void setGoodServiceClassification(GoodServiceClassification goodServiceClassification) {

        System.out.println("setGoodServiceClassification begin row:" + goodServiceClassification.getFileNumber() + ":"
            + goodServiceClassification.getExtensionCounter() + ":" + goodServiceClassification.getNiceClassCode() + ":"
            + goodServiceClassification.getSequenceNumber());
        saveGoodServiceClassification(goodServiceClassification);
    }

    @Override
    public void saveGoodServiceClassification(GoodServiceClassification goodServiceClassification) {
        Session session = getSession();

        // System.out.println("goodServiceClassificationsDao begin saveOrUpdate:");
        session.saveOrUpdate(goodServiceClassification);
        // System.out.println("goodServiceClassificationsDao end saveOrUpdate:");
    }

}
