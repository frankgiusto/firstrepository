package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class BetweenExpression extends OperatorExpression implements Expression, Serializable {

    private static final long serialVersionUID = 3941946098793064611L;

    public BetweenExpression(SearchExpression searchExpression) {
        super(searchExpression, HibernateOperatorEnum.BETWEEN);
    }

    @Override
    public Criterion compose() {
        if (searchExpression.getOperator() != null && searchExpression.getValues() != null) {
            String property = searchExpression.getNestedModelPropertyType() != null
                ? searchExpression.getNestedModelPropertyType() : searchExpression.getModelPropertyType().getValue();

            // TO DO Create the Between Test
            return Restrictions.between(property, searchExpression.getLowValue(), searchExpression.getHighValue());
        }
        return null;
    }

    @Override
    public void accept(ExpressionVisitor expressionVisitor) {
        // TODO Auto-generated method stub

    }

}
