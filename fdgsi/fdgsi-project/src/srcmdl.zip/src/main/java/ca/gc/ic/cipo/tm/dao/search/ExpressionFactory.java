package ca.gc.ic.cipo.tm.dao.search;

import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class ExpressionFactory {

    public static Expression getExpression(SearchExpression searchExpression) {
        if (HibernateOperatorEnum.EQUAL.isEqualTo(searchExpression.getOperator())) {
            return new EqualExpression(searchExpression);
        }
        if (HibernateOperatorEnum.LIKE.isEqualTo(searchExpression.getOperator())) {
            return new LikeExpression(searchExpression);
        }
        if (HibernateOperatorEnum.END_WITH.isEqualTo(searchExpression.getOperator())) {
            return new EndWithExpression(searchExpression);
        }
        if (HibernateOperatorEnum.START_WITH.isEqualTo(searchExpression.getOperator())) {
            return new StartWithExpression(searchExpression);
        }
        if (HibernateOperatorEnum.BETWEEN.isEqualTo(searchExpression.getOperator())) {
            return new BetweenExpression(searchExpression);
        }
        if (HibernateOperatorEnum.IN.isEqualTo(searchExpression.getOperator())) {
            return new InExpression(searchExpression);
        }

        return null;
    }
}
