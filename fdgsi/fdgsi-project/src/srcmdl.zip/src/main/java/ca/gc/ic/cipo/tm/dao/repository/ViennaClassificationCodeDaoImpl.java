package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ViennaClassificationCodeDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ViennaClassificationCode;

/**
 * This ViennaClassificationCodeDAO implementation is used to find Vienna Classification codes based on and descriptions
 * based on category, division, section and/or language.
 *
 * @see ViennaClassificationCode
 * @see ViennaClassificationCodeDao
 * @see HibernateBaseDAO
 *
 * @author Denisj1
 * @author SeguinA3 - Ported and re-factored from TDRS
 */
@Repository("viennaClassificationCodeDao")
public class ViennaClassificationCodeDaoImpl extends HibernateBaseDao implements ViennaClassificationCodeDao {

    private static final long serialVersionUID = 8726899462982145123L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ViennaClassificationCodeDaoImpl.class);

    @Override
    public ViennaClassificationCode getClassificationCode(Integer category, Integer division, Integer section,
                                                          Integer language) {
        logger.trace("getClassificationCode - Hibernate Session Id = " + getSession().hashCode() + " for [" + category
            + "," + category + "," + section + "]" + " - Object = " + this.hashCode());

        ViennaClassificationCode viennaClassificationCode = new ViennaClassificationCode();
        try {
            Criteria criteria = getSession().createCriteria(ViennaClassificationCode.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_CATEGORY_CODE.getValue(), category));
            criteria.add(
                Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_DIVISION_CODE.getValue(), division));
            criteria
                .add(Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_SECTION_CODE.getValue(), section));
            criteria
                .add(Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_LANGUAGE.getValue(), language));
            viennaClassificationCode = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("getClassificationCode - Hibernate Session Id = " + getSession().hashCode()
                + "There are no Classification Code with parameters for [" + category + "," + category + "," + section
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return viennaClassificationCode;
    }

    @Override
    public Collection<ViennaClassificationCode> listClassificationCodesByLanguage(Integer language) {
        logger.trace("getClassificationCodeByLanguage - Hibernate Session Id = " + getSession().hashCode() + " for ["
            + language + "]" + " - Object = " + this.hashCode());

        List<ViennaClassificationCode> viennaClassificationCodes = new ArrayList<ViennaClassificationCode>();
        try {
            Criteria criteria = getSession().createCriteria(ViennaClassificationCode.class);
            criteria
                .add(Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_LANGUAGE.getValue(), language));
            viennaClassificationCodes = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("getClassificationCodeByLanguage - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + language + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return viennaClassificationCodes;
    }

    @Override
    public Collection<ViennaClassificationCode> listClassificationCodes(Integer category, Integer division,
                                                                        Integer section) {
        logger.trace("getClassificationCodes - Hibernate Session Id = " + getSession().hashCode() + " for [" + category
            + "," + category + "," + section + "]" + " - Object = " + this.hashCode());
        List<ViennaClassificationCode> viennaClassificationCodes = new ArrayList<ViennaClassificationCode>();
        try {
            Criteria criteria = getSession().createCriteria(ViennaClassificationCode.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_CATEGORY_CODE.getValue(), category));
            criteria.add(
                Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_DIVISION_CODE.getValue(), division));
            criteria
                .add(Restrictions.eq(ModelPropertyType.VIENNA_CLASSIFICATION_CODE_ID_SECTION_CODE.getValue(), section));
            viennaClassificationCodes = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("getClassificationCodes - Hibernate Session Id = " + getSession().hashCode() + " for ["
                + category + "," + category + "," + section + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return viennaClassificationCodes;
    }
}
