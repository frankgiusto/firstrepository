/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.FittIdentifiersDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FittIdentifiers;
import ca.gc.ic.cipo.tm.model.FittIdentifiersId;

/**
 * The FittIdentifiersDaoImpl retrieves data from the FITT_IDENTIFIERS Table using Hibernate.
 *
 * @see FittIdentifiersDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
@Repository("fittIdentifiersDao")
public class FittIdentifiersDaoImpl extends HibernateBaseDao implements FittIdentifiersDao {

    /**
     *
     */
    private static final long serialVersionUID = -6167875463671506547L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(FittIdentifiersDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(Integer fileNumber, Integer extensionCounter) {
        // TODO Auto-generated method stub
        List<FittIdentifiers> fittIdentifiers = new ArrayList<FittIdentifiers>();
        try {
            Criteria criteria = getSession().createCriteria(FittIdentifiers.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            fittIdentifiers = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving fitt identifiers with parameters [" + fileNumber + ", " + extensionCounter
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<FittIdentifiers>(fittIdentifiers);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(Integer fileNumber, Integer extensionCounter, String mrUID) {
        // TODO Auto-generated method stub
        List<FittIdentifiers> fittIdentifiers = new ArrayList<FittIdentifiers>();
        try {
            Criteria criteria = getSession().createCriteria(FittIdentifiers.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.FITT_IDENTIFIERS_MRUID.getValue(), mrUID));

            fittIdentifiers = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving fitt identifiers with parameters [" + fileNumber + ", " + extensionCounter
                + ", " + ", " + mrUID + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<FittIdentifiers>(fittIdentifiers);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiers(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(Application application) {
        // TODO Auto-generated method stub
        return this
            .getFittIdentifiers(new ApplicationNumber(application.getFileNumber(), application.getExtensionCounter()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(ApplicationNumber applicationNumber, String mrUID) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiers(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(),
            mrUID);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(Application application, String mrUID) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiers(application.getFileNumber(), application.getExtensionCounter(), mrUID);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiers> getFittIdentifiers(ApplicationNumber applicationNumber,
                                                   FittIdentifiersId fittIdentifiersId) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiers(applicationNumber, fittIdentifiersId.getMrUID());
    }

    @Override
    public void saveFittIdentifiers(FittIdentifiers fittIdentifiers) {
        Session session = getSession();
        session.saveOrUpdate(fittIdentifiers);
    }
}
