package ca.gc.ic.cipo.tm.type;

import java.io.Serializable;

public class Property implements Serializable {

	private static final long serialVersionUID = 2833136990286704203L;

	public OrderByEnum orderByEnum;
	public String name;
	
	public OrderByEnum getOrderByEnum() {
		return orderByEnum;
	}
	public void setOrderByEnum(OrderByEnum orderByEnum) {
		this.orderByEnum = orderByEnum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
