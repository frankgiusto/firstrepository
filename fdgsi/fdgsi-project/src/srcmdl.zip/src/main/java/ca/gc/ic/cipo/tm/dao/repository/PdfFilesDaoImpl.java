/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.PdfFilesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.EmailJobsId;
import ca.gc.ic.cipo.tm.model.PdfFiles;
import ca.gc.ic.cipo.tm.model.PdfFilesId;

/**
 * The PdfFilesDaoImpl retrieves data from the PDF_FILES Table using Hibernate.
 *
 * @see pdfFilesDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */

// TODO not used for now I think, not reviewed
@Deprecated
@Repository("pdfFilesDao")
public class PdfFilesDaoImpl extends HibernateBaseDao implements PdfFilesDao {

    /**
     *
     */
    private static final long serialVersionUID = -2135597406251075938L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(PdfFilesDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<PdfFiles> getPdfFiles(Integer emailJobNumber) {
        // TODO Auto-generated method stub
        List<PdfFiles> pdfFiles = new ArrayList<PdfFiles>();
        try {
            Criteria criteria = getSession().createCriteria(PdfFiles.class);
            criteria.add(Restrictions.eq(ModelPropertyType.EMAIL_JOBS_ID_EMAIL_JOB_NUMBER.getValue(), emailJobNumber));
            pdfFiles = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving email jobs with parameters [" + emailJobNumber + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<PdfFiles>(pdfFiles);
    }

    /** {@inheritDoc} */
    @Override
    public Set<PdfFiles> getPdfFiles(Integer emailJobNumber, Integer outputCode) {
        // TODO Auto-generated method stub
        List<PdfFiles> pdfFiles = new ArrayList<PdfFiles>();
        try {
            Criteria criteria = getSession().createCriteria(PdfFiles.class);
            criteria.add(Restrictions.eq(ModelPropertyType.EMAIL_JOBS_ID_EMAIL_JOB_NUMBER.getValue(), emailJobNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.PDF_FILES_ID_OUTPUT_CODE.getValue(), outputCode));
            pdfFiles = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving email jobs with parameters [" + emailJobNumber + ", " + outputCode + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<PdfFiles>(pdfFiles);
    }

    /** {@inheritDoc} */
    @Override
    public Set<PdfFiles> getPdfFiles(EmailJobsId EmailJobsId) {
        // TODO Auto-generated method stub
        return this.getPdfFiles(EmailJobsId.getEmailJobNumber());
    }

    /** {@inheritDoc} */
    @Override
    // TODO not used for now I think, not reviewed
    @Deprecated
    public Set<PdfFiles> getPdfFiles(EmailJobs emailJobs) {
        // TODO Auto-generated method stub
        return this.getPdfFiles(new EmailJobsId(emailJobs.getFileNumber(), emailJobs.getExtensionCounter(),
            emailJobs.getEmailJobNumber(), emailJobs.getArNumber()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<PdfFiles> getPdfFiles(EmailJobsId emailJobsId, Integer outputCode) {
        // TODO Auto-generated method stub
        return this.getPdfFiles(emailJobsId.getEmailJobNumber(), outputCode);
    }

    /** {@inheritDoc} */
    @Override
    public Set<PdfFiles> getPdfFiles(EmailJobs emailJobs, Integer outputCode) {
        // TODO Auto-generated method stub
        return this.getPdfFiles(emailJobs.getEmailJobNumber(), outputCode);
    }

    /** {@inheritDoc} */
    @Override
    public Set<PdfFiles> getPdfFiles(EmailJobsId emailJobsId, PdfFilesId pdfFilesId) {
        // TODO Auto-generated method stub
        return this.getPdfFiles(emailJobsId, pdfFilesId.getOutputCode());
    }

}
