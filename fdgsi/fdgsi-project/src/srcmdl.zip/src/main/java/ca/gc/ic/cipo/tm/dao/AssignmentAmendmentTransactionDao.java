package ca.gc.ic.cipo.tm.dao;

import java.util.List;
import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransactionIp;

/**
 * The AssignmentAmendmentTransactionsDAO is the interface used to retrieve Assignment and Amendment Transactions
 * information related to a given Trademark application.
 *
 * @see AssignmentAmendmentTransaction
 * @see ApplicationNumber
 *
 * @author Denisj1
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface AssignmentAmendmentTransactionDao {

    public List<AssignmentAmendmentTransaction> list(Integer fileNumber, Integer extensionCounter);

    // TODO remove, Application is an ApplicationNumber
    @Deprecated
    public List<AssignmentAmendmentTransaction> list(Application application);

    public List<AssignmentAmendmentTransaction> list(ApplicationNumber applicationNumber);

    // TODO only keep aatNumber as a parameter, the rest is not required (PK), should return a single object
    public Set<AssignmentAmendmentTransactionIp> getAssignmentAmendmentTransactionIps(Integer fileNumber,
                                                                                      Integer extensionCounter,
                                                                                      Integer aatNumber);
}
