package ca.gc.ic.cipo.tm.type;

public enum OperatorEnum {
	EQUAL(" = "), 
	NOT_EQUAL(" <> "),
	LESS_THAN(" < "), 
	LESS_OR_EQ(" <= "),
	GREATER_THAN( " > "), 	 
	GREATER_OR_EQ(" >= "),
	LIKE(" LIKE "), 
	NOT_LIKE(" NOT LIKE "),
	AND(" AND "),
	OR(" OR "),
	NOT(" NOT ");	

	private final String value;

	private OperatorEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

}
