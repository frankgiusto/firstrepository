package ca.gc.ic.cipo.tm.dao.search;

import java.util.List;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Interface to searching the applications
 */
public interface ApplicationsSearch {

    /**
     * Retrieving and return the applications based on specified search expressions and operator (OR or AND)
     * 
     * @param expressions the list of search expressions
     * @param searchOperator the search operator
     * @return the list of type Application entity object
     */
    public List<Application> searchApplications(List<Expression> expressions, HibernateOperatorEnum searchOperator);

}
