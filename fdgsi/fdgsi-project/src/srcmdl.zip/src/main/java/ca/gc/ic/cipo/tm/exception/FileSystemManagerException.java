package ca.gc.ic.cipo.tm.exception;

/**
 * FileSystemManagerException is a runtime exception implementation that 
 * handles low level errors and exceptions related to the file system.
 *  
 * @author DenisJ1
 */
public class FileSystemManagerException extends RuntimeException {

    /**
	 * Unique serial ID.
	 */
	private static final long serialVersionUID = 5516328513326849526L;

	/**
     * Constructor.
     */
    public FileSystemManagerException() {
        super();
    }

    /**
     * Constructor.
     * 
     * @param message The message.
     */
    public FileSystemManagerException(final String message) {
        super(message);
    }
    
    /**
     * Constructor.
     * 
     * @param message The message.
     * @param throwable The throwable if any.
     */
    public FileSystemManagerException(final String message, Throwable throwable) {
        super(message, throwable);
    }
}

