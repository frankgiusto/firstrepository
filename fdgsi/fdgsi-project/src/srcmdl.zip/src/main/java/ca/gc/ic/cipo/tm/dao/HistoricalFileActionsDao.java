/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.HistoricalFileActions;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface HistoricalFileActionsDao {

    public Set<HistoricalFileActions> getHistoricalFileActions(String receiverAuthorityId, String senderAuthorityId);

}
