package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OppositionGroundsSubsectionDao;
import ca.gc.ic.cipo.tm.model.OppositionGroundsSubsection;

@Repository("oppositionGroundsSubsectionDao")
public class OppositionGroundsSubsectionDaoImpl extends HibernateBaseDao implements OppositionGroundsSubsectionDao {

    private static final long serialVersionUID = 2392433924136706850L;

    private static final String OPP_GROUNDS_SUB_SECTION_SQL = "select {ogs.*} from {h-schema}OPPOSITION_GROUNDS_SUBSECTIONS ogs where ogs.OPP_GROUNDS_CODE = :groundCode and ogs.SUBSECTION_CODE = :subSectionCode";

    @Override
    public List<OppositionGroundsSubsection> getOppositionGroundsSubsections(Integer oppCode, Integer subsectionCode) {
        Objects.requireNonNull(oppCode);
        Objects.requireNonNull(subsectionCode);

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("groundCode", oppCode);
        parameters.put("subSectionCode", subsectionCode);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(OPP_GROUNDS_SUB_SECTION_SQL, parameters);
        sqlQuery.addEntity("ogs", OppositionGroundsSubsection.class);

        @SuppressWarnings("unchecked")
        List<OppositionGroundsSubsection> results = sqlQuery.list();
        return results;
    }

}
