package ca.gc.ic.cipo.tm.dao.repository;

import java.io.File;
import java.io.Serializable;

import org.apache.commons.io.FilenameUtils;

/**
 * Utility class for defining a Generic file document and simplifying access
 * to it. A Generic File Document is built into four parts:
 * 
 * - Root:  	The root folder.
 * - Path:  	The path relative to the root folder.
 * - Name:  	The name of the document without the extension.
 * - Extension: The extension of the document.
 * 
 * @author denisj1
 */
@SuppressWarnings("serial")
public class GenericFileDocument implements Serializable {

	/** Represents the root part of the document. A root could be a letter drive,
	    an NFS mounted drive, a network path, etc. */
	private String root;
	
	/** Represents the path of a document.  It is the relative path without
	    the root and filename sections.  */
	private String path;
	
	/** Represents the filename of the document. */
	private String filename;
	
	public GenericFileDocument() {
		super();
	}
	
	public GenericFileDocument(String root, String path, String filename) {
		super();
		setRoot(root);
		setPath(path);
		setFilename(filename);
	}

	/**
	 * Return the root folder of this document.
	 * 
	 * @return The root folder.  May return a null value or an empty string.
	 */
	public String getRoot() {
		return root;
	}
	
	public void setRoot(String root) {
		this.root = FilenameUtils.separatorsToSystem(root);
	}
	
	/**
	 * Return the full path of this document excluding the filename (basename and extension).
	 * 
	 * @return The full path.  May return a null value or an empty string.
	 */
	public String getFullPath() {
		boolean fullPathExists = false;
		String fullPath = "";
		if (root != null) {
			fullPathExists = true;
			fullPath += root;
		}
		if (path != null) {
			fullPathExists = true;
			fullPath += path;
		}		
		
		return fullPathExists ? FilenameUtils.getFullPath(fullPath) : null;		
	}
	
	/**
	 * Return the path of this document excluding the root folder.
	 * 
	 * @return The path of this document.  May return a null value or an empty string.
	 */
	public String getPath() {
		return path;
	}
	
	public void setPath(String path) {
		this.path = FilenameUtils.separatorsToSystem(path);
	}
		
	
	/**
	 * Return the basename of this document if any.
	 * 
	 * @return The basename of this document.  May return a null value or an empty string.
	 */
	public String getBasename() {
		return FilenameUtils.getBaseName(filename);
	}
		
	/**
	 * Return the extension of this document if any.
	 * 
	 * @return The extension of this document.  May return a null value or an empty string.
	 */
	public String getExtension() {
		return FilenameUtils.getExtension(filename);
	}
		
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	/**
	 * Return the filename (basename and extension) of this document if any.
	 * 
	 * @return The filename of this document.  May return a null value or an empty string.
	 */
	public String getFilename() {
		return filename;
	}
	
	/**
	 * Return a File reference of this document.
	 * 
	 * @return The File reference of this document. May return a null value.
	 */
	public File getFile() {
		File file = null;
		String fullName = "";
		boolean nullPath = true;
		
		String fullPath = getFullPath();
		if (fullPath != null) {
			nullPath = false;
			fullName += fullPath;
		}
		if (filename != null) {
			nullPath = false;
			fullName += filename;
		}
		
		if (!nullPath) {
			file = new File(fullName);
		} 
		return file;
	}	
}
