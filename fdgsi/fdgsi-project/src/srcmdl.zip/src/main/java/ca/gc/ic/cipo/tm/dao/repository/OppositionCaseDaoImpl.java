package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OppositionCaseDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;

@Repository("oppositionCaseDao")
public class OppositionCaseDaoImpl extends HibernateBaseDao implements OppositionCaseDao {

    private static final long serialVersionUID = 4158315158162349316L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(OppositionCaseDaoImpl.class);

    private static final String NEXT_CASE_NUM_SQL = " select max(oc.OPP_CASE_NUMBER) as next_case_number from OPPOSITION_CASES oc where oc.FILE_NUMBER = :fileNumber and oc.EXTENSION_COUNTER = :extensionCounter ";

    private static final String OPP_CASE_SQL = "select {oc.*} from OPPOSITION_CASES oc where FILE_NUMBER = :fileNumber and EXTENSION_COUNTER = :extCounter ";

    @Override
    public List<OppositionCase> getOppositionCases(ApplicationNumber applicationNumber) {
        List<OppositionCase> oppositionCases = new ArrayList<OppositionCase>();
        try {
            Criteria criteria = getSession().createCriteria(OppositionCase.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            oppositionCases = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "There are no Opposition Cases of Application with parameters [" + applicationNumber.getFileNumber()
                    + ", " + applicationNumber.getExtensionCounter() + "]\n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return oppositionCases;
    }

    @Override
    public OppositionCase getOppositionCase(ApplicationNumber applicationNumber, Integer caseNumber) {
        OppositionCase oppositionCase = null;
        try {
            Criteria criteria = getSession().createCriteria(OppositionCase.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
            oppositionCase = super.findUniqueByCriteria(criteria);
        } catch (Exception ex) {
            logger
                .error(
                    "There are no Opposition Case of Application with parameters [" + applicationNumber.getFileNumber()
                        + ", " + applicationNumber.getExtensionCounter() + ", " + caseNumber + "]\n" + ex.getMessage(),
                    ex);
            throw new DataAccessException(ex);
        }
        return oppositionCase;

    }

    @Override
    public Integer getNextOppositionCaseNumberForApplication(Integer fileNumber, Integer extCounter) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", fileNumber);
        parameters.put("extensionCounter", extCounter);
        SQLQuery query = (SQLQuery) super.createSQLQuery(NEXT_CASE_NUM_SQL, parameters);
        query.addScalar("next_case_number", IntegerType.INSTANCE);
        Integer caseNumber = (Integer) query.uniqueResult();
        if (caseNumber != null) {
            return new Integer(caseNumber.intValue() + 1);
        }
        return new Integer(1);
    }

    @Override
    public List<OppositionCase> getOppositionCasesByCaseType(ApplicationNumber applicationNumber,
                                                             OppositionCaseType oppCaseType) {
        Objects.requireNonNull(applicationNumber);

        String finalSQL = OPP_CASE_SQL;
        if (oppCaseType != null) {
            if (OppositionCaseType.OPPOSITION == oppCaseType) {
                finalSQL += " AND OPP_CASE_TYPE_CODE = 1 ";
            }

            if (OppositionCaseType.SECTION_45 == oppCaseType) {
                finalSQL += " AND OPP_CASE_TYPE_CODE > 1 ";
            }
        }

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", applicationNumber.getFileNumber());
        parameters.put("extCounter", applicationNumber.getExtensionCounter());

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(finalSQL, parameters);
        sqlQuery.addEntity("oc", OppositionCase.class);

        @SuppressWarnings("unchecked")
        List<OppositionCase> results = sqlQuery.list();
        return results;
    }

    @Override
    public void saveOppositionCase(OppositionCase oppositionCase) {
        Session session = getSession();
        session.saveOrUpdate(oppositionCase);
    }

}
