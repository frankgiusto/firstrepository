package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AssignmentAmendmentTransactionDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransactionIp;

/**
 * The AssignmentAmendmentTransactionsDAOImpl is the Hibernate implementation used to retrieve Assignment and Amendment
 * Transactions information related to a given Trademark application.
 *
 * @see AssignmentAmendmentTransaction
 * @see AssignmentAmendmentTransactionDao
 * @see HibernateBaseDAO
 *
 * @author denisj1
 * @author SeguinA3 - Ported and re-factored from TDRS
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("AssignmentAmendmentTransactionDao")
public class AssignmentAmendmentTransactionDaoImpl extends HibernateBaseDao
    implements AssignmentAmendmentTransactionDao {

    private static final long serialVersionUID = 8223335361150686893L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(AssignmentAmendmentTransactionDaoImpl.class);

    @Override
    public List<AssignmentAmendmentTransaction> list(Integer fileNumber, Integer extensionCounter) {
        List<AssignmentAmendmentTransaction> assignmentAmendmentTransactions = new ArrayList<AssignmentAmendmentTransaction>();
        try {
            Criteria criteria = getSession().createCriteria(AssignmentAmendmentTransaction.class);
            criteria.add(Restrictions
                .eq(ModelPropertyType.ASSIGNMENT_AMENDMENT_TRANSACTION_MASTER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.ASSIGNMENT_AMENDMENT_TRANSACTION_MASTER_EXTENSION_COUNTER.getValue(),
                    extensionCounter));
            assignmentAmendmentTransactions = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving assignment amendment transactions with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + "]" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return assignmentAmendmentTransactions;
    }

    @Override
    public List<AssignmentAmendmentTransaction> list(Application application) {
        return this.list(application.getFileNumber(), application.getExtensionCounter());
    }

    @Override
    public List<AssignmentAmendmentTransaction> list(ApplicationNumber applicationNumber) {
        return this.list(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    @Override
    public Set<AssignmentAmendmentTransactionIp> getAssignmentAmendmentTransactionIps(Integer fileNumber,
                                                                                      Integer extensionCounter,
                                                                                      Integer aatNumber) {

        List<AssignmentAmendmentTransactionIp> assignmentAmendmentTransactionIps = new ArrayList<AssignmentAmendmentTransactionIp>();
        try {
            Criteria criteria = getSession().createCriteria(AssignmentAmendmentTransactionIp.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(
                Restrictions.eq(ModelPropertyType.ASSIGNMENT_AMENDMENT_TRANSACTION_AAT_NUMBER.getValue(), aatNumber));
            assignmentAmendmentTransactionIps = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving assignment amendment transactions Ips with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + extensionCounter + "]" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        return new HashSet<AssignmentAmendmentTransactionIp>(assignmentAmendmentTransactionIps);

    }
}
