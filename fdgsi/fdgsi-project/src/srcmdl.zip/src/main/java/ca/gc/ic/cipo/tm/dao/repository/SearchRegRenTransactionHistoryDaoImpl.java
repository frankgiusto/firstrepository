package ca.gc.ic.cipo.tm.dao.repository;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.SearchRegRenTransactionHistoryDao;
import ca.gc.ic.cipo.tm.dao.helpers.SearchConstants;
import ca.gc.ic.cipo.tm.dao.helpers.SearchRegRenTransactionHistoryQueryHelper;
import ca.gc.ic.cipo.tm.model.SearchRegRenTransactionHistory;
import ca.gc.ic.cipo.tm.model.SearchRegRenTransactionHistoryCriteria;

/**
 * The SearchRegRenTransactionHistoryDaoImpl retrieves data from the many Tables using Hibernate.
 *
 * @see SearchRegRenTransactionHistoryDao
 * @see HibernateBaseDAO
 * @author Peloquip
 */
@Repository("searchRegRenTransactionHistoryDao")
public class SearchRegRenTransactionHistoryDaoImpl extends HibernateBaseDao
    implements SearchRegRenTransactionHistoryDao {

    private static final long serialVersionUID = 749547634508733386L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(MethodHandles.lookup().lookupClass());

    @Override
    public List<SearchRegRenTransactionHistory> searchRegRenTransactionHistory(SearchRegRenTransactionHistoryCriteria searchCriteria) {
        List<SearchRegRenTransactionHistory> results = doSearchRegRenTransactionHistory(searchCriteria);
        return results;
    }

    @SuppressWarnings("unchecked")
    public List<SearchRegRenTransactionHistory> doSearchRegRenTransactionHistory(SearchRegRenTransactionHistoryCriteria searchCriteria) {

        LOG.debug("About to retrieve SearchRegRenTransactionHistory");
        // Setting the parameters
        Map<String, Object> parameters = new HashMap<>();
        Objects.requireNonNull(searchCriteria, "Expected valid search criteria but was: [ " + searchCriteria + " ]");

        // Search by application number - including extension counter (set to 0
        // by default in the sql)
        if (searchCriteria.getApplicationNumber() != null
            && searchCriteria.getApplicationNumber().getFileNumber() != null) {
            parameters.put(SearchConstants.SEARCH_FILE_NUMBER.getValue(),
                searchCriteria.getApplicationNumber().getFileNumber());
        } else {
            throw new IllegalArgumentException("Search criteria is not valid, mandatory file number is not provided");
        }

        // Search by confirmation number
        if (StringUtils.hasText(searchCriteria.getConfirmationNumber())) {
            parameters.put(SearchConstants.SEARCH_CONFIRMATION_NUMBER.getValue(),
                searchCriteria.getConfirmationNumber());
        } else {
            throw new IllegalArgumentException(
                "Search criteria is not valid, mandatory confirmation number is not provided");
        }

        // check if transaction type is valid
        SearchRegRenTransactionHistoryQueryHelper.checkTransactionType(searchCriteria.getTransactionType());

        // sql query string
        String sql = SearchRegRenTransactionHistoryQueryHelper
            .getRegRenTransactionHistoryQuery(searchCriteria.getTransactionType());

        // SQLQuery
        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(sql, parameters);

        // updates the query object with appropriate scalar values
        SearchRegRenTransactionHistoryQueryHelper.updateSQLQueryWithScalarInfo(sqlQuery,
            searchCriteria.getTransactionType());

        List<SearchRegRenTransactionHistory> result = sqlQuery
            .setResultTransformer(Transformers.aliasToBean(SearchRegRenTransactionHistory.class)).list();
        return result;
    }

}
