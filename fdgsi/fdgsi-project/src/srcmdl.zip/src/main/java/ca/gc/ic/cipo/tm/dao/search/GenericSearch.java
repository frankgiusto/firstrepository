package ca.gc.ic.cipo.tm.dao.search;

import java.util.List;

import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * This interface represents the search functionality for applicants, interested parties, agents and applications. It
 * uses the Hibernate Criteria API and provides support for AND/OR along with search method type.
 *
 * Note: The search methods might not return expected results in case when the collection needs to be filtered.
 *
 * An issue was fixed for advancedSearchOnInterestedParty method which required filtering of certain trypes of
 * InterestedPartiesAddresses records. Turns out Hibernate was loading all records for a given file number and extension
 * counter and IP number. * @author sagary
 */
public interface GenericSearch {

    /**
     * Performs a basic search on Trademark application
     *
     * @param seList the expression list
     * @param associationRelation the operator
     * @return the list of type Application object
     */
    public List<Application> basicSearchOnApplication(List<Expression> seList,
                                                      HibernateOperatorEnum associationRelation);

    /**
     * Performs an advanced search on the Trademark Application
     *
     * @param seList the expression list
     * @param associationRelation the operator
     * @return the list of type Application object
     */
    public List<Application> advancedSearchOnApplication(List<Expression> seList,
                                                         HibernateOperatorEnum associationRelation);

    /**
     * Performs a basic search on Trademark
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @return the list of type TradeMark object
     */
    public List<TradeMark> basicSearchOnTradeMark(List<Expression> seList, HibernateOperatorEnum associationRelation);

    /**
     * Performs a basic search on InterestedParty
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @return the list of type InterestedParty object
     */
    public List<InterestedParty> basicSearchOnInterestedParty(List<Expression> seList,
                                                              HibernateOperatorEnum associationRelation);

    /**
     * Performs a basic search on InterestedParty with pagination capabilities
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @param pageNumber the page number
     * @param pageSize the size of result set to obtain
     * @return the list of type InterestedParty objects
     */
    public List<InterestedParty> basicSearchOnInterestedPartyWithPagination(List<Expression> seList,
                                                                            HibernateOperatorEnum associationRelation,
                                                                            Integer pageNumber, Integer pageSize);

    /**
     * Performs an advanced search on InterestedParties and InterestedPartiesAddresses records. This method will return
     * all InterestedPartiesAddresses (IPA) records without being filtered. For instance if address type = 1 or
     * country_province = 'CA' is required, Hibernate will load the entire set.
     *
     * At this point a work round is being implemented so that the records are processed manually. This needs to be
     * revisited for a better solution
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @return the list of type InterestedParty objects
     */
    public List<InterestedParty> advancedSearchOnInterestedParty(List<Expression> seList,
                                                                 HibernateOperatorEnum associationRelation);

    /**
     * Performs an advanced search on Agent representatives
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @return the list of type AgentRepresentative objects
     */
    public List<AgentRepresentative> advancedSearchOnAgentRepresentative(List<Expression> seList,
                                                                         HibernateOperatorEnum associationRelation);

    /**
     * Performs search on active agent representatives
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @param userName the user name of the agent representative
     * @return the list of type AgentRepresentative objects
     */
    public List<AgentRepresentative> advancedSearchOnActiveAgentRepresentative(List<Expression> seList,
                                                                               HibernateOperatorEnum associationRelation,
                                                                               String userName);

    /**
     * Performs search on active representatives email addresses
     *
     * @param seList the search expression list
     * @param associationRelation the operator (AND or OR)
     * @param userName the user name of the agent representative
     * @return the list of type AgentRepresentative objects
     */
    public List<String> advancedSearchOnAgentRepresentativeEmailAddress(List<Expression> seList,
                                                                        HibernateOperatorEnum associationRelation,
                                                                        String userName);

}
