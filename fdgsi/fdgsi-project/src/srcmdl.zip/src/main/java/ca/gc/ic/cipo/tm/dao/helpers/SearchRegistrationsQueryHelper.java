package ca.gc.ic.cipo.tm.dao.helpers;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Helper for building query string for search registrations for renewal
 */
public final class SearchRegistrationsQueryHelper {

    /**
     * Exclusion query for web transactions
     */
    private static final String FILTER_WEB_STRANSACTIONS = " AND not exists (SELECT wt.* FROM TM.WEB_TRANSACTIONS wt where (1=1) AND wt.FILE_NUMBER = rr.file_number AND "
        + " wt.EXTENSION_COUNTER = rr.EXTENSION_COUNTER AND  wt.status_code IN (4, 6)) ";

    /**
     * SQL query for filtering applications
     */
    private static final String FILTER_APPLICATIONS = " AND rr.FILE_NUMBER not in ( select APP.FILE_NUMBER from APPLICATIONS APP where (1=1) AND APP.FILE_NUMBER = rr.FILE_NUMBER AND APP.EXTENSION_COUNTER = rr.EXTENSION_COUNTER AND APP.IR_NUMBER IS NOT NULL ) ";

    /**
     * Default sort column
     */
    private static final String SORT_COL_1 = "RENEWAL_DUE_DATE";

    /**
     * Default sort column
     */
    private static final String SORT_COL_2 = "FILE_NUMBER";

    /**
     * Order by clause
     */
    private static final String ORDER_BY_SQL = " order by rr." + SORT_COL_1 + " asc, rr." + SORT_COL_2 + " asc ";

    /**
     * Query SQL to be used when file number is to be provided
     */
    private static final String APPICATION_NUMBER_SQL_STR = " rr.FILE_NUMBER = :fileNumber ";

    /**
     * Extension counter
     */
    private static final String EXTENSION_COUNTER_SQL_STR = " rr.EXTENSION_COUNTER = :extensionCounter ";

    /**
     * Query SQL to be used when registration number is to be provided
     */
    private static final String REGISTRATION_NUMBER_SQL_STR = " rr.REGISTRATION_NUMBER = :registrationNumber ";

    /**
     * Query SQL when Legislation code is provided
     */
    private static final String LEGISLATION_CODE_SQL_STR = " rr.LEGISLATION = :legislation ";

    /**
     * Query SQL when Agent number is provided
     */
    private static final String AGENT_NUMBER_SQL_STR = " rr.AGENT_NUMBER IN ( :agentNumbers )  ";

    /**
     * Query SQL when Trademark name s provided
     */
    private static final String TRADEMARK_NAME_SQL_STR = " upper(rr.TEXT) like upper(:text) ";

    /**
     * Query SQL when Owner name is provided
     */
    private static final String OWNER_NAME_SQL_STR = " upper(rr.OWNER_NAME) like upper(:ownerName) ";

    /**
     * Query SQL for advance search, application status has to be registered
     */
    private static final String REGISTERED_STATUS_SQL_STR = " rr.STATUS_CODE = 12 ";

    /**
     * Renewal start and end date SQL query string
     */
    private static final String START_END_DATE_SQL_STR = "( rr.RENEWAL_END_DATE is null and trunc(rr.RENEWAL_DUE_DATE) <= :renewalEndDate )   or   ( trunc(rr.RENEWAL_END_DATE) >= :renewalStartDate and trunc(rr.RENEWAL_START_DATE) <= :renewalEndDate )";

    /**
     * Start SQL Query string
     */
    private static final String START_SQL_STR;

    /**
     * End SQL Query string
     */
    private static final String END_SQL_STR;

    static {
        StringBuilder sql = new StringBuilder();
        sql.append(" select * from (   SELECT /*+ RESULT_CACHE */ {rr.*} from {h-schema}TM_WEB rr ");
        sql.append(" where (1 = 1) ");
        START_SQL_STR = sql.toString();

        END_SQL_STR = " ) where rownum <= :rowNum ".toString();

    }

    /**
     * Builds and returns the query string based on the search criteria
     */
    public String buildQuery(SearchRegistrationCriteria searchCriteria) {
        StringBuilder sb = new StringBuilder();
        boolean fileNumberOrRegNumberProvided = false;

        if (searchCriteria != null) {
            sb.append(START_SQL_STR);

            // application number
            if (searchCriteria.getApplicationNumber() != null) {
                if (searchCriteria.getApplicationNumber().getFileNumber() != null) {
                    sb.append(" and ").append(APPICATION_NUMBER_SQL_STR);
                }
                if (searchCriteria.getApplicationNumber().getExtensionCounter() != null) {
                    sb.append(" and ").append(EXTENSION_COUNTER_SQL_STR);
                }
                fileNumberOrRegNumberProvided = true;
            }

            // registration number
            if (searchCriteria.getRegistrationNumber() != null) {
                sb.append(" and ").append(REGISTRATION_NUMBER_SQL_STR);
                fileNumberOrRegNumberProvided = true;
            }

            // legislation code
            if (searchCriteria.getLegislationCode() != null) {
                sb.append(" and ").append(LEGISLATION_CODE_SQL_STR);
            }

            boolean includeApplicationsFilter = false;

            // advance search (agent has to exist)
            if (!CollectionUtils.isEmpty(searchCriteria.getAgentNumbers())) {

                // application must have registered status
                sb.append(" and ").append(REGISTERED_STATUS_SQL_STR);

                // agent number
                sb.append(" and ").append(AGENT_NUMBER_SQL_STR);

                // text
                if (StringUtils.hasText(searchCriteria.getTrademarkName())) {
                    sb.append(" and ").append(TRADEMARK_NAME_SQL_STR);
                }

                // Owner name
                if (StringUtils.hasText(searchCriteria.getApplicantName())) {
                    sb.append(" and ").append(OWNER_NAME_SQL_STR);
                }

                includeApplicationsFilter = true;

                sb.append(" and ( ").append(START_END_DATE_SQL_STR).append(" )  ");

            } // ~end of if (!CollectionUtils.isEmpty(searchCriteria.getAgentNumbers())) {

            /**
             * filter out file number that present in WEB_TRANSACTIONS table only when file number or registration
             * number is not provided.
             */
            if (!fileNumberOrRegNumberProvided) {
                sb.append(FILTER_WEB_STRANSACTIONS);
            }

            /**
             * When searching by date filter or owner or trademark name, filter the applications on excluding the
             * IR_NUMBER. and when not searching for an application or registration number
             */
            if (includeApplicationsFilter && !fileNumberOrRegNumberProvided) {
                sb.append(FILTER_APPLICATIONS);
            }

            sb.append(ORDER_BY_SQL);

            sb.append(END_SQL_STR);
        }
        return sb.toString();
    }
}
