/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseId;
import ca.gc.ic.cipo.tm.model.OralHearingAttendees;
import ca.gc.ic.cipo.tm.model.OralHearingAttendeesId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface OralHearingAttendeesDao {

    public Set<OralHearingAttendees> getOralHearingAttendees(Integer fileNumber, Integer extensionCounter,
                                                             Integer oppCaseNumber);

    public Set<OralHearingAttendees> getOralHearingAttendees(Integer fileNumber, Integer extensionCounter,
                                                             Integer oppCaseNumber, Integer attendeeType);

    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCaseId oppositionCaseId);

    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCase oppostionCase);

    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCaseId oppositionCaseId, Integer attendeeType);

    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCase oppostionCase, Integer attendeeType);

    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCaseId oppositionCaseId,
                                                             OralHearingAttendeesId oralHearingAttendeesId);

}
