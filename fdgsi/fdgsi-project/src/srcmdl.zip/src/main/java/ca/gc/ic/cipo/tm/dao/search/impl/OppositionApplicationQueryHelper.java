package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.builders.NativeExpressionSQLBuilder;
import ca.gc.ic.cipo.tm.enumerator.RelationshipType;
import ca.gc.ic.cipo.tm.enumerator.SearchItemType;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class OppositionApplicationQueryHelper {

    private static final int MAX_RESULTS_SIZE = 100;

    private static final String MAIN_SELECT = " select * from ( ";

    private OppositionApplicationQueryHelper() {
    }

    public static QueryAndParams createNativeSQLQuery(Map<SearchItemType, Boolean> searchedItemsTypeMap,
                                                      List<Expression> expressions, HibernateOperatorEnum operator) {

        if (CollectionUtils.isEmpty(searchedItemsTypeMap)) {
            throw new IllegalArgumentException("Expected at least one item in SearchItemType map");
        }

        if (CollectionUtils.isEmpty(expressions)) {
            throw new IllegalArgumentException("Expected at least one Search Expression");
        }

        operator = Objects.requireNonNull(operator);

        StringBuilder sb = new StringBuilder();
        sb.append(MAIN_SELECT).append(" select app.* from APPLICATIONS app ");

        if (searchedItemsTypeMap.containsKey(SearchItemType.TRADEMARK_NAME)) {
            sb.append(" inner join TRADE_MARKS tm on app.FILE_NUMBER = tm.FILE_NUMBER ");
        }
        if (isApplicantOrOpponentSearch(searchedItemsTypeMap)) {
            sb.append(
                " inner join INTERESTED_PARTIES IP on IP.FILE_NUMBER = app.FILE_NUMBER and IP.EXTENSION_COUNTER = app.EXTENSION_COUNTER ");

            if (isApplicantSearch(searchedItemsTypeMap)) {
                sb.append(" AND IP.RELATIONSHIP_TYPE = " + RelationshipType.OWNER.getValue());
                sb.append(" ");
            }

            if (isOpponentSearch(searchedItemsTypeMap)) {
                sb.append(" AND IP.RELATIONSHIP_TYPE = " + RelationshipType.OPPONENT.getValue());
                sb.append(" ");
            }
        }

        sb.append(" WHERE (1=1) AND ( ");

        NativeExpressionSQLBuilder expressionSQLBuilder = new NativeExpressionSQLBuilder.Builder(expressions, operator)
            .buildQuery();

        String finalSQL = expressionSQLBuilder.toFinalSQL();

        sb.append(finalSQL).append(" ) ");

        sb.append(" ) where rownum <=").append(MAX_RESULTS_SIZE);

        Map<String, Object> paramsMap = expressionSQLBuilder.toParametersMap();
        MultiValueMap<String, Object> paramsList = expressionSQLBuilder.toParameterListMap();
        return new QueryHelper.QueryAndParams(sb.toString(), paramsMap, paramsList);
    }

    private static boolean isApplicantOrOpponentSearch(Map<SearchItemType, Boolean> searchItemTypesMap) {
        return (isApplicantSearch(searchItemTypesMap) || isOpponentSearch(searchItemTypesMap));
    }

    private static boolean isApplicantSearch(Map<SearchItemType, Boolean> searchItemTypesMap) {
        return searchItemTypesMap.containsKey(SearchItemType.APPLICANT_NAME);
    }

    private static boolean isOpponentSearch(Map<SearchItemType, Boolean> searchItemTypesMap) {
        return searchItemTypesMap.containsKey(SearchItemType.OPPONENT_NAME);
    }

}
