package ca.gc.ic.cipo.tm.dao.repository;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OppositionIpDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.OppositionIp;
import ca.gc.ic.cipo.tm.model.OppositionIpId;

@Repository("oppositionIpDao")
public class OppositionIpDaoImpl extends HibernateBaseDao implements OppositionIpDao {

    private static final long serialVersionUID = 6361678633197632415L;

    @Override
    public OppositionIp getOppositionIp(OppositionIpId oppositionIpId) {
        OppositionIp result = null;
        try {
            Criteria criteria = getSession().createCriteria(OppositionIp.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                oppositionIpId.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                oppositionIpId.getExtensionCounter()));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_IP_ID_IP_NUMBER.getValue(), oppositionIpId.getIpNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_IP_ID_OPP_CASE_NUMBER.getValue(),
                oppositionIpId.getOppCaseNumber()));
            result = super.findUniqueByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("There are no Good Service Claims with parameters [" + oppositionIpId.getFileNumber() + ", "
                + oppositionIpId.getExtensionCounter() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return result;
    }
}
