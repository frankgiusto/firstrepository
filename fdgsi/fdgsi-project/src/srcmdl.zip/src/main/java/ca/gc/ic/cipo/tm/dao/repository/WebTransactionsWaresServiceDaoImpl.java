package ca.gc.ic.cipo.tm.dao.repository;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.WebTransactionsWaresServiceDao;

@Repository("webTransactionsWaresServiceDao")
public class WebTransactionsWaresServiceDaoImpl extends HibernateBaseDao implements WebTransactionsWaresServiceDao {

    private static final long serialVersionUID = 1L;

}
