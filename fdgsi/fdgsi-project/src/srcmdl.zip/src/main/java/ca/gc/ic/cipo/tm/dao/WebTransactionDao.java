package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.WebTransactions;

public interface WebTransactionDao {

    /**
     * Persist web transactions information
     *
     * @param webTransaction the WebTransactions entity
     */
    public void saveWebTransaction(WebTransactions webTransaction);

    /**
     * Determines if renewal exist in trademark
     *
     * @param applicationNumber the application file number
     * @return true if exist; false otherwise
     */
    boolean isRenewalExistInTrademark(ApplicationNumber applicationNumber);

    /**
     * Persist the web transactions information followed by invoke flush from the current session. This is needed since
     * the files are requires to be moves to the file by invoking a stored procedure as soon as the transaction is
     * received from ecomm application.
     *
     * @see ca.gc.ic.cipo.tm.ttps.processors.impl.RegistrationRenewalTransactionProcessorImpl.sendRenewalTransactionInfo
     *      in TTPS Web Service
     *
     * @param webTransaction the WebTransactions entity object
     */
    void saveWebTransactionWithflush(WebTransactions webTransaction);

}
