/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.DocumentLocationDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DocumentLocation;
import ca.gc.ic.cipo.tm.model.DocumentLocationId;

/**
 * @author duanj
 *
 */
@Repository("documentLocationDao")
public class DocumentLocationDaoImpl extends HibernateBaseDao implements DocumentLocationDao {

    private static final long serialVersionUID = -1514466928605430137L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(DocumentLocationDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public DocumentLocation getDocumentLocation(DocumentLocationId documentLocationId, Integer extensionCounter,
                                                Integer oppCaseNumber) {
        DocumentLocation dl = new DocumentLocation();
        try {
            Criteria criteria = getSession().createCriteria(DocumentLocation.class);
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_ID_FILE_NUMBER.getValue(),
                documentLocationId.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_ID_FILE_TYPE.getValue(),
                documentLocationId.getFileType()));
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_ID_SEQUENCE_NUMBER.getValue(),
                documentLocationId.getSequenceNumber()));
            criteria.add(
                Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria
                .add(Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_OPP_CASE_NUMBER.getValue(), oppCaseNumber));

            dl = findUniqueByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("There is no Document Location with given DocumentLocationId ("
                + documentLocationId.getFileNumber() + ", " + documentLocationId.getFileType() + ", "
                + documentLocationId.getSequenceNumber() + ", " + ")/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return dl;
    }

    /** {@inheritDoc} */
    @Override
    public List<DocumentLocation> getDocumentLocations(ApplicationNumber applicationNumber) {
        return this.getDocumentLocations(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public List<DocumentLocation> getDocumentLocations(Integer fileNumber) {
        List<DocumentLocation> docLocations = new ArrayList<DocumentLocation>();
        try {
            Criteria criteria = getSession().createCriteria(DocumentLocation.class);
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_ID_FILE_NUMBER.getValue(), fileNumber));
            criteria.addOrder(Order.asc(ModelPropertyType.DOCUMENT_LOCATION_ID_SEQUENCE_NUMBER.getValue()));

            docLocations = findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("There are no Document Locations with parameters [" + fileNumber + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }

        return docLocations;
    }

    /** {@inheritDoc} */
    @Override
    public List<DocumentLocation> getDocumentLocations(Integer fileNumber, Integer extensionCounter) {
        List<DocumentLocation> docLocations = new ArrayList<DocumentLocation>();
        try {
            Criteria criteria = getSession().createCriteria(DocumentLocation.class);
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_ID_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.DOCUMENT_LOCATION_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.addOrder(Order.asc(ModelPropertyType.DOCUMENT_LOCATION_ID_SEQUENCE_NUMBER.getValue()));

            docLocations = findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("There are no Document Locations with parameters [" + fileNumber + ", " + extensionCounter
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return docLocations;
    }

    /** {@inheritDoc} */
    @Override
    public void saveDocumentLocation(DocumentLocation documentLocation) {
        Session session = getSession();
        session.saveOrUpdate(documentLocation);
    }

}
