/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.FinancialTransactionsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FinancialTransactions;
import ca.gc.ic.cipo.tm.model.FinancialTransactionsId;

/**
 * The FinancialTransactionsDaoImpl retrieves data from the FINANCIAL_TRANSACTIONS Table using Hibernate.
 *
 * @see financialTransactionsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */

@Repository("financialTransactionsDao")
public class FinancialTransactionsDaoImpl extends HibernateBaseDao implements FinancialTransactionsDao {

    /**
     *
     */
    private static final long serialVersionUID = 1559008521075177130L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(FinancialTransactionsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(Integer fileNumber, Integer extensionCounter) {

        List<FinancialTransactions> transactions = new ArrayList<FinancialTransactions>();
        try {
            Criteria criteria = getSession().createCriteria(FinancialTransactions.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            transactions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving financial transactions with parameters [" + fileNumber + ", "
                + extensionCounter + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<FinancialTransactions>(transactions);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(Integer fileNumber, Integer extensionCounter,
                                                               Integer arNumber, Integer financialTransactionNumber) {
        // TODO Auto-generated method stub
        List<FinancialTransactions> transactions = new ArrayList<FinancialTransactions>();
        try {
            Criteria criteria = getSession().createCriteria(FinancialTransactions.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.FINANCIAL_TRANSACTIONS_ID_AR_NUMBER.getValue(), arNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.FINANCIAL_TRANSACTIONS_ID_TRANSACTION_NUMBER.getValue(),
                financialTransactionNumber));

            transactions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving financial transactions with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + ", " + financialTransactionNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<FinancialTransactions>(transactions);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getFinancialTransactions(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(Application application) {
        // TODO Auto-generated method stub
        return this.getFinancialTransactions(
            new ApplicationNumber(application.getFileNumber(), application.getExtensionCounter()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(ApplicationNumber applicationNumber, Integer arNumber,
                                                               Integer financialTransactionNumber) {
        // TODO Auto-generated method stub
        return this.getFinancialTransactions(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(),
            arNumber, financialTransactionNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(Application application, Integer arNumber,
                                                               Integer financialTransactionNumber) {
        // TODO Auto-generated method stub
        return this.getFinancialTransactions(application.getFileNumber(), application.getExtensionCounter(), arNumber,
            financialTransactionNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FinancialTransactions> getFinancialTransactions(ApplicationNumber applicationNumber,
                                                               FinancialTransactionsId transactionId) {
        // TODO Auto-generated method stub
        return this.getFinancialTransactions(applicationNumber, transactionId.getArNumber(),
            transactionId.getFinancialTransactionNumber());
    }

    // get the list of Agent Representatives
    @Override
    public Set<AgentRepresentative> getAgentRepresentatives(Integer replacedBy) {

        String sql =
            // Select all Agent Representatives related to this email.
            "select {ar.*} from agents_reps ar " + "join financial_transactions ft on ft.AR_NUMBER = ar.REPLACED_BY "
                + "where( ar.REPLACED_BY  = :replacedBy)";

        logger.debug("Executing SQL statement = " + sql);

        // Set the runtime parameters - memberOf
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.AGENT_REPRESENTATIVE_REPLACED_BY.getValue(), replacedBy);

        // Declare the SQL query and attach the entity AgentRepresentative to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("ar", AgentRepresentative.class);
        List<AgentRepresentative> agentRepresentatives = new ArrayList<AgentRepresentative>();
        try {
            agentRepresentatives = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving agent representatives for financial transactions with parameters ["
                + replacedBy + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AgentRepresentative>(agentRepresentatives);

    }

    @Override
    public void saveFinancialTransactions(FinancialTransactions financialTransactions) {
        Session session = getSession();
        session.saveOrUpdate(financialTransactions);
    }

}
