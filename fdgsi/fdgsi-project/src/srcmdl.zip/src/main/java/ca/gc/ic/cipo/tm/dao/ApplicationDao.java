package ca.gc.ic.cipo.tm.dao;

import java.util.List;
import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationEmails;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.Authorities;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.FinancialTransactions;
import ca.gc.ic.cipo.tm.model.FittIdentifiers;
import ca.gc.ic.cipo.tm.model.ProcessAction;

/**
 * The ApplicationDAO is the interface used to retrieve a given Trade-mark Application with basic information.
 *
 * @author denisj1
 * @author giustof added getNextApplicationNumber().
 *
 */
public interface ApplicationDao {

    /**
     * Set classification required ind
     * 
     * @param ApplicationNumber The file number and extension counter.
     * @param Ind The value to set up.
     * @return the next application number
     */
    public void setClassificationRequiredInd(ApplicationNumber appNumber, int ind);

    /**
     * Gets the next application number. This dao method calls the NEXT_FILE_NUMBER stored procedure in Intrepid db to
     * return the next available application number.
     *
     * @return the next application number
     */
    public Long getNextApplicationNumber();

    /**
     * Retrieve the Trademark Application model associated with the given file number and extension counter.
     *
     * @param fileNumber The file number.
     * @param extensionCounter The extension counter.
     *
     * @return The Trademark Application model.
     */
    public Application getApplication(String fileNumber, String extensionCounter);

    /**
     * Retrieve the Trademark Application model associated with the given file number and extension counter.
     *
     * @param fileNumber The file number.
     * @param extensionCounter The extension counter.
     *
     * @return The Trademark Application model.
     */
    public Application getApplication(Integer fileNumber, Integer extensionCounter);

    /**
     * Retrieve the Trademark Application model associated with the given file number and extension counter.
     *
     * @param appNumber The application number.
     *
     * @return The Trademark Application model.
     */
    public Application getApplication(ApplicationNumber appNumber);

    /**
     * Retrieve the list of Trademark Application models associated with the given file number.
     *
     * @param fileNumber The file number of an application.
     *
     * @return The list of Trademark Application models.
     */
    List<Application> getApplications(Integer fileNumber);

    /**
     * Retrieve the Trademark type associated with the application number.
     *
     * @param appNumber The application number.
     *
     * @return The Trademark type.
     */
    public Integer getTrademarkType(ApplicationNumber appNumber);

    /**
     * Gets the application by a ClassificationRequiredIndRange number
     *
     * @param ind the number of ClassificationRequiredInd to be used to return application
     * @param lowestApplicationNumber the lowest Number to be included in the request
     * @param highestApplicationNumber the highest Number to be included in the request
     * @param limit, limit the number of element to return
     * @return a list of applications by ClassificationRequiredInd
     */
    public List<Application> getApplicationsByClassificationRequiredIndRange(int ind, Integer lowestApplicationNumber,
                                                                             Integer highestApplicationNumber,
                                                                             Integer limit);

    /**
     * Gets the application by a ClassificationRequiredInd number
     *
     * @param ind the number of ClassificationRequiredInd to be used to return application
     * @return a list of applications by ClassificationRequiredInd
     */
    public List<Application> getApplicationsByClassificationRequiredInd(int ind);

    /**
     * Retrieve the Trademark Application number associated with the given legislation code and registration number.
     *
     * @param legislation The legislation code.
     * @param regNumber The registration number.
     *
     * @return The Trademark Application number.
     */
    // TODO I think it was taken as is from TDRS, but need to be careful here (or change the return type), does not
    // necessarily return an unique record since there are duplicates in the database...
    public ApplicationNumber lookupApplicationNumber(Integer legislation, Integer regNumber);

    // Retrieve the list of Authorities
    // TODO need to be reviewed, authorityId is a PK, other parameters are not necessary, should return a single object.
    // Not sure what goal it needs to achieve.
    public List<Authorities> getAuthorities(Integer fileNumber, Integer extensionCounter, String authorityId);

    // Retrieve the list of financial transactions
    public List<FinancialTransactions> getFinancialTransactions(Integer fileNumber, Integer extensionCounter);

    // Retrieve the list of data correction actions log
    // TODO not used for now I think, not reviewed
    @Deprecated
    public List<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter);

    // Retrieve the list of process actions
    public List<ProcessAction> getProcessActions(Integer fileNumber, Integer extensionCounter);

    // Retrieve the list of FITT Identifiers
    public List<FittIdentifiers> getFittIdentifiers(Integer fileNumber, Integer extensionCounter);

    // Retrieve the list of assignment amendment work sheet files
    // TODO not used for now I think, not reviewed
    @Deprecated
    public List<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                        Integer extensionCounter);

    // Retrieve the list of email jobs
    // TODO not used for now I think, not reviewed
    @Deprecated
    public List<EmailJobs> getEmailJobs(Integer fileNumber, Integer extensionCounter);

    // Retrieve the list of application emails
    public List<ApplicationEmails> getApplicationEmails(Integer fileNumber, Integer extensionCounter);

    /**
     * Gets the application by ids. Specifically IR Number and Document Id
     *
     * @param irNumber the ir number
     * @param intlFilingRecordId the intl filing record id
     * @return the application by ids
     */
    public List<Application> getApplicationByIds(String irNumber, String intlFilingRecordId);

    /**
     * Gets the application by ir number.
     *
     * @param irNumber the ir number
     * @return the application by ir number
     */
    public List<Application> getApplicationByIrNumber(String irNumber);

    // TODO what is the difference with getTrademarkApplicationsByAgentNumber? It should be documented if there is one,
    // or a single function should be used...
    public Set<Application> getApplicationsByAgent(int agentNumber);

    /**
     * Save application.
     *
     * @param application the application
     */
    public void saveApplication(Application application);

    /**
     * Returns the collection of trademark applications for the specific agent.
     *
     * @param agentNumber The agent number
     * @return Collection of Application objects
     */
    List<Application> getTrademarkApplicationsByAgentNumber(Integer agentNumber);

    /**
     * Copy mark. This is an Intrepid stored procedure. Warning ! - This stored procedure does a COMMIT. TODO - create
     * dao Method DeleteMark to call Intrepid stored procedure by same name to clean up if necessary.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @return the application number
     */
    public ApplicationNumber copyMark(Integer fileNumber, Integer extensionCounter);

    /**
     * Copy files. This is an Intrepid stored procedure. Warning ! - This stored procedure does a COMMIT. TODO - create
     * dao Method DeleteMark to call Intrepid stored procedure by same name to clean up if necessary.
     *
     * @param newFileNumber
     * @param newExtensionCounter
     * @param origFileNumber
     * @param origExtensionCounter
     */
    public void copyFiles(Integer newFileNumber, Integer newExtensionCounter, Integer origFileNumber,
                          Integer origExtensionCounter);

}
