package ca.gc.ic.cipo.tm.dao.helpers;

import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Helper for building query string for search adjusted renewal fee
 */
public final class SearchAdjustedRenewalFeeQueryHelper {

    /**
     * Query SQL to be used when file number is to be provided
     */
    private static final String APPICATION_NUMBER_SQL = " and ap.file_number = :fileNumber and ap.extension_counter = 0 ";

    /**
     * Query SQL to be used when registration number is to be provided
     */
    private static final String REGISTRATION_NUMBER_SQL = " and ap.registration_number = :registrationNumber ";

    /**
     * Query SQL to be used when legislation code is to be provided
     */
    private static final String LEGISLATION_CODE_SQL = " and ap.legislation = :legislation ";

    /**
     * Query SQL to be used when trademark name is provided
     */
    private static final String TRADEMARK_NAME_SQL = " and upper(tm.text) like upper(:trademarkText) ";

    /**
     * Start SQL Query string
     */
    private static final String START_SQL;

    /**
     * End SQL Query string
     */
    private static final String END_SQL;

    /**
     * Query SQL to be used when Requestor User is provided
     */
    private static final String REQUESTOR_USER_SQL;

    /** Query for applicant name */
    private static final String APPLICANT_NAME_SQL = " and upper(ip.name) like upper(:applicantName) ";

    /**
     * Query for date range when supplied from the ecommerce application
     */
    private static final String DATE_RANGE_SQL;

    static {
        /** Start section */
        StringBuilder sb = new StringBuilder();
        sb.append(" select * from ( ");
        sb.append(" select ap.file_number as fileNumber, ");
        sb.append(" ap.extension_counter as extensionCounter, ");
        sb.append(" ap.registration_number as registrationNumber, ");
        sb.append(" ap.legislation as legislation, ");
        sb.append(" tm.text as trademarkText, ");
        sb.append(" ac.response_date as responseDate, ");
        sb.append(" ac.additional_info as additionalInfo ");
        sb.append(
            " from {h-schema}applications ap, {h-schema}actions ac, {h-schema}trade_marks tm, {h-schema}interested_parties ip ");
        sb.append(" where ap.file_number = ac.file_number ");
        sb.append(" and ap.extension_counter = ac.extension_counter ");
        sb.append(" and ap.file_number = ip.file_number ");
        sb.append(" and ap.extension_counter = ip.extension_counter ");
        sb.append(" and ap.file_number = tm.file_number ");
        sb.append(" and ac.action_code = 178 ");

        // Gets the latest action code 178
        sb.append(" and ac.action_date = (");
        sb.append(" select max(action_date)");
        sb.append(" from {h-schema}actions");
        sb.append(" where action_code = 178");
        sb.append(" and file_number = ap.file_number");
        sb.append(" and extension_counter = ap.extension_counter");
        sb.append(" )");

        // Ensures there is not action code 179 after latest action code 178
        sb.append(" and not exists (");
        sb.append(" select *");
        sb.append(" from {h-schema}actions");
        sb.append(" where action_code = 179");
        sb.append(" and file_number = ap.file_number");
        sb.append(" and extension_counter = ap.extension_counter");
        sb.append(" and action_date >= ac.action_date");
        sb.append(" )");

        sb.append(" and ap.status_code = 12 ");
        sb.append(" and ap.legislation in (1, 2, 3, 5) ");
        sb.append(" and ap.ir_number is null ");
        sb.append(" and ip.relationship_type = 1 ");
        START_SQL = sb.toString();

        /**
         * Requestor User section Checks if the requestor is an active agent, if it is, adds the agent within the firm
         * section. If the requestor isn't an active agent, do not add any conditions.
         */
        sb = new StringBuilder();
        sb.append(" and ");
        sb.append(" ( ");
        sb.append("   (exists (select * from {h-schema}agents_reps ar, {h-schema}agent_user_xref au ");
        sb.append(
            "       where ar.ar_number = au.ar_number and au.user_id = :requestorUserId and ar.status_code = 1 and ar.ar_type in (1,3)) ");
        sb.append("     /*add the agents within the firm condition*/ ");
        sb.append("     and (  ip.agent_number in  ( ( ");
        sb.append(
            "       select distinct ar.ar_number from {h-schema}agents_reps ar where ar.status_code = 1 start with ar.ar_number in ( ");
        sb.append(
            "       select ar_number from {h-schema}agent_user_xref where user_id = :requestorUserId ) connect by prior ar.member_of = ar.ar_number)  union ( ");
        sb.append(
            "       select distinct ar.member_of from {h-schema}agents_reps ar where ar.status_code = 1 start with ar.ar_number in ( ");
        sb.append(
            "       select ar_number from {h-schema}agent_user_xref where user_id = :requestorUserId )  connect by prior ar.member_of = ar.ar_number) ) ) ");
        sb.append("   ) ");
        sb.append(" or ");
        sb.append("   (not exists (select * from {h-schema}agents_reps ar, {h-schema}agent_user_xref au ");
        sb.append(
            "       where ar.ar_number = au.ar_number and au.user_id = :requestorUserId and ar.status_code = 1 and ar.ar_type in (1,3)) ");
        sb.append("     /*do not add any condition*/ ");
        sb.append("     and 1 = 1 ");
        sb.append("   ) ");
        sb.append(" ) ");
        REQUESTOR_USER_SQL = sb.toString();

        /** date range sql */
        sb = new StringBuilder();
        sb.append(" and ac.response_date between :startDate and :endDate ");
        DATE_RANGE_SQL = sb.toString();

        /** end section */
        sb = new StringBuilder();
        sb.append(" order by ac.response_date asc, ap.file_number asc ");
        sb.append(" ) ");
        sb.append(" where rownum <= :rowNum ");
        END_SQL = sb.toString();
    }

    /**
     * Builds and returns the query string based on the search criteria
     */
    public String buildQuery(SearchRegistrationCriteria searchCriteria) {
        StringBuilder sb = new StringBuilder();
        boolean fileNumberProvided = false;
        // Start
        sb.append(START_SQL);

        // application number
        if (searchCriteria.getApplicationNumber() != null
            && searchCriteria.getApplicationNumber().getFileNumber() != null) {
            sb.append(APPICATION_NUMBER_SQL);
            fileNumberProvided = true;
        }

        // Registration number
        if (searchCriteria.getRegistrationNumber() != null) {
            sb.append(REGISTRATION_NUMBER_SQL);
        }

        // Legislation code
        if (searchCriteria.getLegislationCode() != null) {
            sb.append(LEGISLATION_CODE_SQL);
        }

        // Trademark name
        if (StringUtils.hasText(searchCriteria.getTrademarkName())) {
            sb.append(TRADEMARK_NAME_SQL);
        }

        // Applicant name
        if (StringUtils.hasText(searchCriteria.getApplicantName())) {
            sb.append(APPLICANT_NAME_SQL);
        }

        // Requestor Id
        if (StringUtils.hasText(searchCriteria.getRequestorUserId())) {
            sb.append(REQUESTOR_USER_SQL);
        }

        // if file number is not provided then dates are mandatory
        if (!fileNumberProvided) {
            sb.append(DATE_RANGE_SQL);
        }

        sb.append(END_SQL);
        return sb.toString();
    }
}
