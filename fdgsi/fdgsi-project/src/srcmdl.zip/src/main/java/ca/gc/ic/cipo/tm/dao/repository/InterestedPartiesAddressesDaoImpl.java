/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.dao.InterestedPartiesAddressesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;

/**
 * @author houreich The InterestedPartiesAddressesDaoImpl retrieves data from the INTERESTED_PARTIES_ADDRESSES Table
 *         using Hibernate.
 *
 * @see ClaimDao
 * @see HibernateBaseDAO
 */

@Repository("InterestedPartiesAddressesDao")
public class InterestedPartiesAddressesDaoImpl extends HibernateBaseDao implements InterestedPartiesAddressesDao {

    private static final long serialVersionUID = -1852120463934477049L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(InterestedPartiesAddressesDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public List<InterestedPartiesAddresses> getInterestedPartiesAddresses(Integer fileNumber, Integer extensionCounter,
                                                                          Integer ipNumber) {
        List<InterestedPartiesAddresses> results = Collections.<InterestedPartiesAddresses> emptyList();
        try {
            Criteria criteria = getSession().createCriteria(InterestedPartiesAddresses.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_ID_IP_NUMBER.getValue(), ipNumber));
            results = super.findByCriteria(criteria);

        } catch (Throwable ex) {
            logger.error("Error retrieving InterestedPartiesAddresses with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + ipNumber + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return results;
    }

    @Override
    public void saveInterestedPartiesAddresses(InterestedPartiesAddresses interestedPartiesAddresses) {
        Session session = getSession();
        session.saveOrUpdate(interestedPartiesAddresses);
    }

}
