package ca.gc.ic.cipo.tm.type;

import java.util.Properties;

/**
 * Trademark related document types interface.
 *
 * @author SeguinA3
 */
// TODO remove class
@Deprecated
public interface TradeMarkDocType {

    public String path(Properties property);

}
