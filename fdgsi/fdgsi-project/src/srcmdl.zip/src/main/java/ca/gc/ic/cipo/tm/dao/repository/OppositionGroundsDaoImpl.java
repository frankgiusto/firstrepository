package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OppositionGroundsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionGrounds;

@Repository("oppositionGroundsDao")
public class OppositionGroundsDaoImpl extends HibernateBaseDao implements OppositionGroundsDao {

    private static final long serialVersionUID = 6036890098130199055L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(OppositionGroundsDaoImpl.class);

    @Override
    public List<OppositionGrounds> getOppositonGroundsByApplication(ApplicationNumber applicationNumberModel) {
        Objects.requireNonNull(applicationNumberModel);
        Objects.requireNonNull(applicationNumberModel.getFileNumber());
        Objects.requireNonNull(applicationNumberModel.getExtensionCounter());

        List<OppositionGrounds> results = Collections.<OppositionGrounds> emptyList();
        try {
            Criteria criteria = getSession().createCriteria(OppositionGrounds.class);
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_GROUNDS_FILE_NUMBER.getValue(),
                applicationNumberModel.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_GROUNDS_EXTENSTION_COUNTER.getValue(),
                applicationNumberModel.getExtensionCounter()));
            results = super.findByCriteria(criteria);
        } catch (Throwable ex) {
            LOG.error(
                "Error retrieving oppositon grounds for application [" + applicationNumberModel + "]" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return results;
    }

    @Override
    public void saveOppositionGrounds(OppositionGrounds oppositionGrounds) {
        // super.saveOrUpdateEntity(OppositionGrounds.class, oppositionGrounds);
        super.saveEntity(OppositionGrounds.class, oppositionGrounds);
    }

}
