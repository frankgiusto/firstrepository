package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.GoodsServicesClaimDao;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.Pair;
import ca.gc.ic.cipo.tm.dao.helpers.QueryResultHelper;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ClaimId;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;
import ca.gc.ic.cipo.tm.model.GoodServiceId;

@Repository("goodsServicesClaimDao")
public class GoodsServicesClaimDaoImpl extends HibernateBaseDao implements GoodsServicesClaimDao {

    private static final long serialVersionUID = -5348971141451404971L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(GoodsServicesClaimDaoImpl.class);

    @Override
    public List<GoodServiceClaim> getGoodServiceClaims(ApplicationNumber applicationNumber) {
        List<GoodServiceClaim> goodServiceClaims = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            goodServiceClaims = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Good Service Claims for application: [ " + applicationNumber + " ]"
                + System.lineSeparator() + ex.getMessage());
            throw new DataAccessException(ex);
        }
        return goodServiceClaims;
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsOrderByClaimType(ApplicationNumber applicationNumber) {
        List<GoodServiceClaim> goodServiceClaims = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.addOrder(Order.asc(ModelPropertyType.WS_CLAIM_ID_CLAIM_TYPE.getValue()));
            goodServiceClaims = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Good Service Claims for application: [ " + applicationNumber + " ]"
                + System.lineSeparator() + ex.getMessage());

            throw new DataAccessException(ex);
        }
        return goodServiceClaims;
    }

    @Override
    public MultiValueMap<Pair<Integer, Integer>, GoodServiceClaim> getOrderedGoodServiceClaims(ApplicationNumber applicationNumber) {
        Objects.requireNonNull(applicationNumber);
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            // order by claim_type, claim_number, ws_type, ws_number;
            criteria.addOrder(Order.asc(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_CLAIM_TYPE.getValue()));
            criteria.addOrder(Order.asc(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_CLAIM_NUMBER.getValue()));
            criteria.addOrder(Order.asc(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_TYPE.getValue()));
            criteria.addOrder(Order.asc(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_NUMBER.getValue()));

            List<GoodServiceClaim> goodServiceClaims = super.findByCriteria(criteria);
            return QueryResultHelper.toOrderedMultiValueList(goodServiceClaims);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Ordered Good Service Claims for application: [ " + applicationNumber
                + " ]" + System.lineSeparator() + ex.getMessage());
            throw new DataAccessException(ex);
        }
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByGSKeyAndClaimType(ApplicationNumber applicationNumber,
                                                                          Integer gsType, Integer gsNumber,
                                                                          Integer claimType) {
        List<GoodServiceClaim> results = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_TYPE.getValue(), gsType));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_NUMBER.getValue(), gsNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.WS_CLAIM_ID_CLAIM_TYPE.getValue(), claimType));

            criteria.addOrder(Order.asc(ModelPropertyType.WS_CLAIM_ID_CLAIM_TYPE.getValue()));
            results = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Good Service Claims for application number  [" + applicationNumber
                + " and type " + gsType + " number " + gsNumber + " and claim type " + claimType + " ] "
                + System.lineSeparator() + ex.getMessage());
            throw new DataAccessException(ex);
        }
        return results;
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByGSKey(Application application, Integer goodServiceType,
                                                              Integer goodServiceNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceClaimsByGSKey(applicationNumber, goodServiceType, goodServiceNumber);
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByGSKey(ApplicationNumber applicationNumber,
                                                              GoodServiceId goodServiceId) {
        return this.getGoodServiceClaimsByGSKey(applicationNumber, goodServiceId.getType(), goodServiceId.getNumber());
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByGSKey(ApplicationNumber applicationNumber,
                                                              Integer goodServiceType, Integer goodServiceNumber) {
        List<GoodServiceClaim> goodServiceClaims = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_TYPE.getValue(), goodServiceType));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_NUMBER.getValue(), goodServiceNumber));
            goodServiceClaims = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Good Service Claims for application number  [" + applicationNumber
                + " and type " + goodServiceType + " number " + goodServiceNumber + " ] " + System.lineSeparator()
                + ex.getMessage());
            throw new DataAccessException(ex);
        }
        return goodServiceClaims;
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByClaimKey(Application application, Integer claimType,
                                                                 Integer claimNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceClaimsByClaimKey(applicationNumber, claimType, claimNumber);
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByClaimKey(ApplicationNumber applicationNumber, ClaimId claimId) {
        return this.getGoodServiceClaimsByClaimKey(applicationNumber, claimId.getClaimType(), claimId.getClaimNumber());
    }

    @Override
    public List<GoodServiceClaim> getGoodServiceClaimsByClaimKey(ApplicationNumber applicationNumber, Integer claimType,
                                                                 Integer claimNumber) {
        List<GoodServiceClaim> goodServiceClaims = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.WS_CLAIM_ID_CLAIM_TYPE.getValue(), claimType));
            criteria.add(Restrictions.eq(ModelPropertyType.WS_CLAIM_ID_CLAIM_NUMBER.getValue(), claimNumber));
            goodServiceClaims = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Good Service Claims for application number  [" + applicationNumber
                + " and claim type " + claimType + " claim number " + claimNumber + " ] " + System.lineSeparator()
                + ex.getMessage());
            throw new DataAccessException(ex);
        }
        return goodServiceClaims;
    }

    @Override
    public GoodServiceClaim getGoodServiceClaimsByKeys(ApplicationNumber applicationNumber, ClaimId claimId,
                                                       GoodServiceId goodServiceId) {
        return this.getGoodServiceClaimsByKeys(applicationNumber, goodServiceId.getType(), goodServiceId.getNumber(),
            claimId.getClaimType(), claimId.getClaimNumber());
    }

    @Override
    public GoodServiceClaim getGoodServiceClaimsByKeys(ApplicationNumber applicationNumber, Integer goodServiceType,
                                                       Integer goodServiceNumber, Integer claimType,
                                                       Integer claimNumber) {
        GoodServiceClaim goodServiceClaims = new GoodServiceClaim();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceClaim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_TYPE.getValue(), goodServiceType));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_NUMBER.getValue(), goodServiceNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.WS_CLAIM_ID_CLAIM_TYPE.getValue(), claimType));
            criteria.add(Restrictions.eq(ModelPropertyType.WS_CLAIM_ID_CLAIM_NUMBER.getValue(), claimNumber));
            goodServiceClaims = super.findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Problem in retrieving Good Service Claims for application number  [" + applicationNumber
                + "] " + System.lineSeparator() + ex.getMessage());
            throw new DataAccessException(ex);
        }
        return goodServiceClaims;
    }

    public void getGoodServiceClaims(GoodService goodService) {
        Hibernate.initialize(goodService.getGoodServiceClaims());
    }

    @Override
    public void saveGoodServiceClaim(GoodServiceClaim goodServiceClaim) {
        Session session = getSession();
        session.saveOrUpdate(goodServiceClaim);
    }
}
