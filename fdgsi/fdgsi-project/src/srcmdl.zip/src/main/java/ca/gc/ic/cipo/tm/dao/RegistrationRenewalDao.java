package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.RegistrationRenewal;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Contract interface for Searching registrations for renewal
 */
public interface RegistrationRenewalDao {

    /**
     * Search registered applications for renewal
     *
     * @param searchCriteria the Search Criteria
     * @return list of SearchRenewalView type objects
     */
    public List<RegistrationRenewal> searchRegistrationsForRenewal(SearchRegistrationCriteria searchCriteria);

}
