package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.repository.HibernateBaseDao;
import ca.gc.ic.cipo.tm.dao.search.AgentSearch;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@Repository("agentSearch")
public class AgentSearchImpl extends HibernateBaseDao implements AgentSearch {

    private static final long serialVersionUID = 5970414186095719563L;

    @Override
    public List<AgentRepresentative> searchAgents(List<Expression> expressions, HibernateOperatorEnum searchOperator) {
        // build the query
        QueryHelper.QueryAndParams queryAndParams = AgentQueryHelper.createNativeSQLQuery(expressions, searchOperator);
        return executeQueryAndGet(queryAndParams);
    }

    private List<AgentRepresentative> executeQueryAndGet(QueryAndParams queryAndParams) {
        // final sql
        String finalSQL = queryAndParams.getSqlQuery();

        // map of parameter name along with the values
        Map<String, Object> paramsMap = queryAndParams.getParamsMap();

        // multi value map of parameters list (if applicable)
        MultiValueMap<String, Object> parameterListMap = queryAndParams.getParameterListMap();

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(finalSQL, paramsMap);
        QueryHelper.populateSQLQueryWithParametersListIfApplicable(parameterListMap, sqlQuery);

        @SuppressWarnings("unchecked")
        List<AgentRepresentative> results = sqlQuery.addEntity("AR", AgentRepresentative.class).list();
        return results;
    }

    @Override
    public List<String> getAgentEmailAddresses(List<Expression> expressions, HibernateOperatorEnum searchOperator) {
        // build the query
        QueryHelper.QueryAndParams queryAndParams = AgentQueryHelper.createNativeSQLQueryAgentEmails(expressions,
            searchOperator);
        return executeQueryAndGetResults(queryAndParams);
    }

    private List<String> executeQueryAndGetResults(QueryAndParams queryAndParams) {
        // final sql
        String finalSQL = queryAndParams.getSqlQuery();

        // map of parameter name along with the values
        Map<String, Object> paramsMap = queryAndParams.getParamsMap();

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(finalSQL, paramsMap);
        sqlQuery.addScalar("AGENT_EMAIL", StringType.INSTANCE);

        @SuppressWarnings("unchecked")
        List<String> results = sqlQuery.list();
        return results;
    }

}
