package ca.gc.ic.cipo.tm.dao.search;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.repository.HibernateBaseDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.AgentUserXref;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * This GenericSearch implementation provides generic search functions to retrieves a list of Trade-mark Application or
 * specified part of the application using Hibernate Criteria object.
 *
 * @author wangg2
 */
@Repository("genericSearch")
public class GenericSearchImpl extends HibernateBaseDao implements GenericSearch {

    private static final long serialVersionUID = -1154947662071752551L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(GenericSearchImpl.class);

    private static final int MAX_RESULT = 100;

    public static final String ADDRESSES_ALIAS = "ad";

    /*
     * Basic search that only query Application information
     */
    @Override
    public List<Application> basicSearchOnApplication(List<Expression> seList,
                                                      HibernateOperatorEnum associationRelation) {
        List<Application> applications = new ArrayList<Application>();
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.setMaxResults(MAX_RESULT);
            criteria.addOrder(Order.asc(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue()))
                .addOrder(Order.asc(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue()));

            updateCriteriaWithOperatorRelation(criteria, associationRelation, seList);
            applications = super.findByCriteria(criteria);

        } catch (HibernateException he) {
            logger.debug("Error calling basicSearchOnApplication with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return applications;
    }

    /*
     * Advanced search that queries Applications and associated InterestedParties
     */
    @Override
    public List<Application> advancedSearchOnApplication(List<Expression> seList,
                                                         HibernateOperatorEnum associationRelation) {
        List<Application> applications = new ArrayList<Application>();
        try {
            // following code is composing criterion for Application
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            criteria.setMaxResults(MAX_RESULT);
            criteria.addOrder(Order.asc(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue()))
                .addOrder(Order.asc(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue()));

            // Create a seList of those SearchExpression for EntityModel =
            // 'Application'
            List<Expression> seListForApplication = filterExpressionListByEntity(seList, Application.class);
            if (!CollectionUtils.isEmpty(seListForApplication)) {
                updateCriteriaWithOperatorRelation(criteria, associationRelation, seListForApplication);
            }

            // following code is composing criterion for InterestedParty

            // Create a seList of those SearchExpression for EntityModel =
            // 'InterestedParty'
            List<Expression> seListForInterestedParty = filterExpressionListByEntity(seList, InterestedParty.class);
            if (!CollectionUtils.isEmpty(seListForInterestedParty)) {
                Criteria criteria2 = criteria.createCriteria("interestedParties");
                criteria2.createAlias(ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue() + "."
                    + ModelPropertyType.INTERESTED_PARTIES_ADDRESSES.getValue(), ADDRESSES_ALIAS);
                updateCriteriaWithOperatorRelation(criteria2, associationRelation, seListForInterestedParty);
            }
            applications = super.findByCriteria(criteria);
        } catch (HibernateException he) {
            logger.debug("Error calling advancedSearchOnApplication with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }
        return applications;
    }

    /*
     * Basic search that only query TradeMark information
     */
    @Override
    public List<TradeMark> basicSearchOnTradeMark(List<Expression> seList, HibernateOperatorEnum associationRelation) {
        List<TradeMark> trademarks = new ArrayList<TradeMark>();
        try {
            Criteria criteria = getSession().createCriteria(TradeMark.class);
            criteria.setMaxResults(MAX_RESULT);
            criteria.addOrder(Order.asc(ModelPropertyType.TRADE_MARK_TEXT.getValue()));

            updateCriteriaWithOperatorRelation(criteria, associationRelation, seList);
            trademarks = super.findByCriteria(criteria);

        } catch (HibernateException he) {
            logger.debug("Error calling basicSearchOnTradeMark with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return trademarks;
    }

    /*
     * Basic search that only query InterestedParty information
     */
    @Override
    public List<InterestedParty> basicSearchOnInterestedParty(List<Expression> seList,
                                                              HibernateOperatorEnum associationRelation) {
        List<InterestedParty> applications = new ArrayList<InterestedParty>();
        try {
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.setMaxResults(MAX_RESULT);
            criteria.addOrder(Order.asc(ModelPropertyType.INTERESTED_PARTY_CONTACT_NAME.getValue()));

            updateCriteriaWithOperatorRelation(criteria, associationRelation, seList);

            applications = super.findByCriteria(criteria);

        } catch (HibernateException he) {
            logger.debug("Error calling basicSearchOnInterestedParty with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return applications;
    }

    @Override
    public List<InterestedParty> basicSearchOnInterestedPartyWithPagination(List<Expression> seList,
                                                                            HibernateOperatorEnum associationRelation,
                                                                            Integer pageNumber, Integer pageSize) {
        List<InterestedParty> applications = new ArrayList<InterestedParty>();
        try {
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.setMaxResults(MAX_RESULT);
            criteria.addOrder(Order.asc(ModelPropertyType.INTERESTED_PARTY_CONTACT_NAME.getValue()));

            // pagination configuration
            if (pageSize != null && pageSize != 0) {
                criteria.setMaxResults(pageSize);
                if (pageNumber != null && pageNumber > 0) {
                    criteria.setFirstResult((pageNumber - 1) * pageSize);
                }
            }

            updateCriteriaWithOperatorRelation(criteria, associationRelation, seList);
            applications = super.findByCriteria(criteria);

        } catch (HibernateException he) {
            logger.debug("Error calling basicSearchOnInterestedPartyWithPagination with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return applications;
    }

    @Override
    /** @{inheritDoc} */
    public List<InterestedParty> advancedSearchOnInterestedParty(List<Expression> seList,
                                                                 HibernateOperatorEnum associationRelation) {
        List<InterestedParty> interestedParties = new ArrayList<>();
        try {
            // following code is composing criterion for InterestedParty
            Criteria criteria = getSession().createCriteria(InterestedParty.class);

            criteria.createAlias(ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue() + "."
                + ModelPropertyType.INTERESTED_PARTIES_ADDRESSES.getValue(), ADDRESSES_ALIAS);

            criteria.addOrder(Order.asc(ModelPropertyType.INTERESTED_PARTY_CONTACT_NAME.getValue()));
            criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            criteria.setMaxResults(MAX_RESULT);

            // Create a seList of those SearchExpression for EntityModel =
            // 'InterestedParty'
            List<Expression> seListInterestedParty = filterExpressionListByEntity(seList, InterestedParty.class);

            updateCriteriaWithOperatorRelation(criteria, associationRelation, seListInterestedParty);

            interestedParties = super.findByCriteria(criteria);

        } catch (

        HibernateException he) {
            logger.debug("Error calling advancedSearchOnInterestedParty with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return interestedParties;
    }

    @Override
    public List<AgentRepresentative> advancedSearchOnAgentRepresentative(List<Expression> seList,
                                                                         HibernateOperatorEnum associationRelation) {
        List<AgentRepresentative> agentRepresentatives = new ArrayList<AgentRepresentative>();
        try {
            // following code is composing criterion for Application
            Criteria criteria = getSession().createCriteria(AgentRepresentative.class);
            criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            criteria.setMaxResults(MAX_RESULT);

            // Create a seList of those SearchExpression for EntityModel =
            // 'AgentRepresentative'
            List<Expression> seListForApplication = filterExpressionListByEntity(seList, AgentRepresentative.class);
            if (!seListForApplication.isEmpty()) {
                updateCriteriaWithOperatorRelation(criteria, associationRelation, seListForApplication);
            }

            // find by the root criteria
            criteria.addOrder(Order.asc(ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT_NAME.getValue()));
            agentRepresentatives = super.findByCriteria(criteria);

        } catch (HibernateException he) {
            logger.debug("Error calling advancedSearchOnInterestedParty with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return agentRepresentatives;
    }

    @Override
    public List<String> advancedSearchOnAgentRepresentativeEmailAddress(List<Expression> seList,
                                                                        HibernateOperatorEnum associationRelation,
                                                                        String userName) {
        List<String> agentRepresentatives = new ArrayList<String>();
        try {
            // following code is composing criterion for Application
            Criteria criteria = getSession().createCriteria(AgentRepresentative.class, "ag");
            criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            criteria.setMaxResults(MAX_RESULT);

            // Create a seList of those SearchExpression for EntityModel =
            // 'AgentRepresentative'
            List<Expression> seListForApplication = filterExpressionListByEntity(seList, AgentRepresentative.class);
            if (!seListForApplication.isEmpty()) {
                updateCriteriaWithOperatorRelation(criteria, associationRelation, seListForApplication);
            }

            // find by the root criteria
            criteria.addOrder(Order.asc(ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT_NAME.getValue()));

            Criteria agentCr = getSession().createCriteria(AgentUserXref.class, "u");
            agentCr.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

            agentCr.setProjection(Projections.projectionList().add(Projections.groupProperty("u.emailAddress")));
            agentCr.add(Restrictions.eq("u.userId", userName));
            agentCr.add(Restrictions.isNotNull("u.emailAddress"));

            agentRepresentatives = super.findByCriteria(agentCr);

        } catch (HibernateException he) {
            logger.debug("Error calling advancedSearchOnInterestedParty with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return agentRepresentatives;
    }

    public List<String> advancedSearchOnAgentRepresentativeEmailAddress2(List<Expression> seList,
                                                                         HibernateOperatorEnum associationRelation,
                                                                         String userName) {
        List<String> agentRepresentatives = new ArrayList<>();
        try {

            Criteria agentUserXrefCriteria = getSession().createCriteria(AgentUserXref.class, "xref");

            // following code is composing criterion for Application
            Criteria criteria = getSession().createCriteria(AgentRepresentative.class, "ag");
            criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            criteria.setMaxResults(MAX_RESULT);

            // Create a seList of those SearchExpression for EntityModel =
            // 'AgentRepresentative'
            List<Expression> seListForApplication = filterExpressionListByEntity(seList, AgentRepresentative.class);
            if (!seListForApplication.isEmpty()) {
                updateCriteriaWithOperatorRelation(criteria, associationRelation, seListForApplication);
            }

            // find by the root criteria
            criteria.addOrder(Order.asc(ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT_NAME.getValue()));

            Criteria agentCr = getSession().createCriteria(AgentUserXref.class, "u");
            agentCr.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

            agentCr.setProjection(Projections.projectionList().add(Projections.groupProperty("u.emailAddress")));
            agentCr.add(Restrictions.eq("u.userId", userName));
            agentCr.add(Restrictions.isNotNull("u.emailAddress"));

            agentRepresentatives = super.findByCriteria(agentCr);

        } catch (HibernateException he) {
            logger.debug("Error calling advancedSearchOnInterestedParty with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return agentRepresentatives;
    }

    /*
     * Advanced search that queries associated Agents, Representatives
     */
    @Override
    public List<AgentRepresentative> advancedSearchOnActiveAgentRepresentative(List<Expression> seList,
                                                                               HibernateOperatorEnum associationRelation,
                                                                               String userName) {

        List<AgentRepresentative> agentRepresentatives = new ArrayList<AgentRepresentative>();
        try {
            // following code is composing criterion for Application
            Criteria criteria = getSession().createCriteria(AgentRepresentative.class, "agent");
            criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
            criteria.setMaxResults(MAX_RESULT);

            // Create a seList of those SearchExpression for EntityModel =
            // 'AgentRepresentative'
            List<Expression> seListForApplication = filterExpressionListByEntity(seList, AgentRepresentative.class);
            if (!seListForApplication.isEmpty()) {
                updateCriteriaWithOperatorRelation(criteria, associationRelation, seListForApplication);
            }

            // find by the root criteria
            criteria.addOrder(Order.asc(ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT_NAME.getValue()));

            DetachedCriteria agentCr = DetachedCriteria.forClass(AgentUserXref.class, "u");
            agentCr.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);

            agentCr.setProjection(Projections.projectionList().add(Projections.groupProperty("arNumber")));
            agentCr.add(Restrictions.eq("u.userId", userName));
            // Now using subqueries you can achieve your goal
            criteria.add(Subqueries.propertyIn("arNumber", agentCr));

            agentRepresentatives = super.findByCriteria(criteria);

        } catch (HibernateException he) {
            logger.debug("Error calling advancedSearchOnInterestedParty with message: " + he.getMessage());
            throw new DataAccessException(he.getMessage());
        }

        return agentRepresentatives;
    }

    private List<Expression> filterExpressionListByEntity(List<Expression> seList, Class<?> entityClass) {
        List<Expression> seListForEntity = new ArrayList<Expression>();
        List<Expression> expList = new ArrayList<Expression>();
        boolean isAndOrOrExpression = false;

        for (Expression exp : seList) {

            if (exp instanceof AndExpression) {
                expList = ((AndExpression) exp).getExpList();
                isAndOrOrExpression = true;

            } else if (exp instanceof OrExpression) {
                expList = ((OrExpression) exp).getExpList();
                isAndOrOrExpression = true;
            }

            // is it And/Or Expression
            if (isAndOrOrExpression) {

                if (exp instanceof OrExpression || exp instanceof AndExpression) {

                    seListForEntity.add(exp);

                } else {
                    for (Expression subExpression : expList) {
                        if (subExpression instanceof OperatorExpression) {
                            SearchExpression searchExpression = ((OperatorExpression) subExpression)
                                .getSearchExpression();
                            if (searchExpression.getEntityClass().equals(entityClass)) {
                                if (!seListForEntity.contains(subExpression)) {
                                    seListForEntity.add(subExpression);
                                }

                            }
                        } else if (subExpression instanceof EqualExpression) {
                            SearchExpression searchExpression = ((EqualExpression) subExpression).getSearchExpression();
                            if (searchExpression.getEntityClass().equals(entityClass)) {
                                if (!seListForEntity.contains(subExpression)) {
                                    seListForEntity.add(subExpression);
                                }

                            }
                        } else if (subExpression instanceof OrExpression || subExpression instanceof AndExpression) {
                            seListForEntity.add(subExpression);
                        }
                    }
                }
            }

            // if Expression is the terminal expression

            if (exp instanceof OperatorExpression) {
                SearchExpression searchExpression = ((OperatorExpression) exp).getSearchExpression();

                if (searchExpression.getEntityClass().equals(entityClass)) {
                    seListForEntity.add(exp);
                }
            } else if (exp instanceof EqualExpression) {
                SearchExpression searchExpression = ((EqualExpression) exp).getSearchExpression();
                if (searchExpression.getEntityClass().equals(entityClass)) {
                    seListForEntity.add(exp);
                }
            }
        } // ~end of for (Expression exp : seList) {
        return seListForEntity;
    }

    public boolean exists(Expression exp, List<Expression> expList) {

        boolean exists = false;
        SearchExpression searchExp = null;
        SearchExpression searchExpression = null;

        if (exp instanceof EqualExpression) {
            searchExp = ((EqualExpression) exp).getSearchExpression();
        } else if (exp instanceof OperatorExpression) {
            searchExp = ((OperatorExpression) exp).getSearchExpression();
        }

        if (!CollectionUtils.isEmpty(expList)) {
            for (Expression expression : expList) {
                if (expression instanceof EqualExpression) {
                    searchExpression = ((EqualExpression) expression).getSearchExpression();
                } else if (expression instanceof OperatorExpression) {
                    searchExpression = ((OperatorExpression) expression).getSearchExpression();
                }
                if (searchExpression.getNestedModelPropertyType()
                    .equalsIgnoreCase(searchExp.getNestedModelPropertyType())) {
                    return true;
                }
            }
        }
        return exists;
    }

    private void updateCriteriaWithOperatorRelation(Criteria criteria, HibernateOperatorEnum associationRelation,
                                                    List<Expression> seList) {
        if (associationRelation.equals(HibernateOperatorEnum.AND)) {
            AndExpression andExpression = new AndExpression(seList);
            criteria.add(andExpression.compose());
        }
        if (associationRelation.equals(HibernateOperatorEnum.OR)) {
            OrExpression orExpression = new OrExpression(seList);
            criteria.add(orExpression.compose());
        }

    }
}
