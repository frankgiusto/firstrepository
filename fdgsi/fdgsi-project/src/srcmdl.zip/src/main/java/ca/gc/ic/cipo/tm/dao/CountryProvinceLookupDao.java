package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.CountryProvince;

/**
 * CountriesProvincesLookupDAO is an interface used to find meta information
 * related to a country or province based on a code type, a code, and/or 
 * language.  The country  or province code are widely used in order to 
 * dynamically retrieve a description of the code based on a given language.  
 * 
 * @author DenisJ1
 *
 */
public interface CountryProvinceLookupDao {

	/**
	 * Retrieve the Country or Province for the given code type, code value and language.
	 *  
	 * @param codeType The type of code to retrieve (Countries or Provinces).
	 * @param code The code value to retrieve.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return The Country/Province information if found, otherwise null. 
	 */
	public CountryProvince get(Integer codeType, String code, Integer language);	
	
	/**
	 * Retrieve Countries or Provinces list for the given code type.
	 *  
	 * @param codeType The type of code to retrieve (Countries or Provinces).
	 * 
	 * @return A list of Country/Province information if found, otherwise null. 
	 */
	public List<CountryProvince> list(Integer codeType);
	
	/**
	 * Retrieve Countries or Provinces list for the given code type and language.
	 *  
	 * @param codeType The type of code to retrieve (Countries or Provinces).
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return A list of Country/Province information if found, otherwise null. 
	 */	
	public List<CountryProvince> list(Integer codeType, Integer language);	
	
	/**
	 * Retrieve a Country by it's country code (i.e.: CA) in a specific language.
	 *   
	 * @param countryCode
	 * @param language
	 * @return A CountryProvince Object
	 */
	public CountryProvince getCountry(String countryCode, Integer language);

	// Convenience methods
	public List<CountryProvince> getCountriesByLanguages(Integer language);
	public List<CountryProvince> getProvincesByLanguages(Integer language);
	public List<CountryProvince> getCountries();
	public List<CountryProvince> getProvinces();

}
