package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.SearchRegRenTransactionHistory;
import ca.gc.ic.cipo.tm.model.SearchRegRenTransactionHistoryCriteria;

/**
 * Contract interface for Searching Transaction History
 */
public interface SearchRegRenTransactionHistoryDao {

    /**
     * Interface to retrieve actions based on the search criteria
     *
     * @param searchCriteria the SearchCriteria object encapsulating the search fields.
     * @return the list of SearchRegRenTransactionHistory type objects
     */
    public List<SearchRegRenTransactionHistory> searchRegRenTransactionHistory(SearchRegRenTransactionHistoryCriteria searchCriteria);

}
