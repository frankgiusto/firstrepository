package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;

import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public abstract class OperatorExpression implements Expression, Serializable {

    private static final long serialVersionUID = 3941946098793064611L;

    protected SearchExpression searchExpression;

    protected HibernateOperatorEnum operatorEnum;

    public OperatorExpression(SearchExpression searchExpression, HibernateOperatorEnum operator) {
        this.searchExpression = searchExpression;
        this.operatorEnum = operator;
    }

    public SearchExpression getSearchExpression() {
        return searchExpression;
    }

    public void setSearchExpression(SearchExpression searchExpression) {
        this.searchExpression = searchExpression;
    }

    public HibernateOperatorEnum getOperatorEnum() {
        return operatorEnum;
    }

    @Override
    public Object compose() {

        return null;
    }

}
