package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ApplicationText;

public interface ApplicationTextDao {

    /**
     * Retrieve a collection of Application Text based on the Application Number object containing the file number and
     * extension counter
     *
     * @param applicationNumber
     * @return Collection of ApplicationText Object
     */
    public List<ApplicationText> getApplicationText(ApplicationNumber applicationNumber);

    /**
     * Retrieve a collection of Application Text based on the Application Number Object containing the file number and
     * extension counter, a text type and original Indicator value.
     *
     * @param applicationNumber
     * @param textType
     * @param originalInd
     * @return Collection of ApplicationText Object
     */
    public ApplicationText getApplicationText(ApplicationNumber applicationNumber, Integer textType,
                                              Integer originalInd);

    /**
     * Saves the application text record into the DB
     *
     * @param applicationText the ApplicationText entity instance representing a single record
     */
    public void saveApplicationText(ApplicationText applicationText);
}
