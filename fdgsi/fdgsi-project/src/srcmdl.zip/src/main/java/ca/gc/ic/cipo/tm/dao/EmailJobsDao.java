/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.EmailJobsId;
import ca.gc.ic.cipo.tm.model.PdfFiles;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface EmailJobsDao {

    public Set<EmailJobs> getEmailJobs(Integer fileNumber, Integer extensionCounter);

    public Set<EmailJobs> getEmailJobs(Integer fileNumber, Integer extensionCounter, Integer emailJobNumber,
                                       Integer arNumber);

    public Set<EmailJobs> getEmailJobs(ApplicationNumber applicationNumber);

    public Set<EmailJobs> getEmailJobs(Application application);

    public Set<EmailJobs> getEmailJobs(ApplicationNumber applicationNumber, Integer emailJobNumber, Integer arNumber);

    public Set<EmailJobs> getEmailJobs(Application application, Integer emailJobNumber, Integer arNumber);

    public Set<EmailJobs> getEmailJobs(ApplicationNumber appplicationNumber, EmailJobsId emailJobsId);

    // get the list of Agent Representatives
    public Set<AgentRepresentative> getAgentRepresentatives(Integer memberOf);

    // get the PDF Files
    public Set<PdfFiles> getPdfFiles(Integer fileNumber, Integer extensionCounter, Integer emailJobNumber);

}
