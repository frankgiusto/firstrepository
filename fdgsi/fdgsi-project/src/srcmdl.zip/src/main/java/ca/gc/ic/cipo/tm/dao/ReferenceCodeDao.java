package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.model.ReferenceCode;

/**
 * ReferenceCodesDAO is an interface used to find a reference code
 * based on a code type, a code, and/or language.  The reference 
 * code are widely used in order to dynamically retrieve a description
 * of the code based on a given language.  
 * 
 * @see ReferenceCode
 * 
 * @author DenisJ1
 *
 */
@Repository("referenceCodeDao")
public interface ReferenceCodeDao {	
	
	/**
	 * Retrieve the reference code for the given code type, code value and language.
	 *  
	 * @param codeType The type of code to retrieve.
	 * @param code The code value to retrieve.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return The reference code information if found, otherwise null. 
	 */
	public ReferenceCode getCode(Integer codeType, Integer code, Integer language);		
	
	/**
	 * Retrieve a reference code list for the given language.
	 *  
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return A list of reference code information if found, otherwise null. 
	 */
	public List<ReferenceCode> listCodesByLanguage(Integer language);

	
	/**
	 * Retrieve a reference code list for the given code type.
	 *  
	 * @param codeType The type of code to retrieve.
	 * 
	 * @return A list of reference code information if found, otherwise null. 
	 */
	public List<ReferenceCode> listCodesByType(Integer codeType);
	
	/**
	 * Retrieve a reference code list for the given code type and language.
	 *  
	 * @param codeType The type of code to retrieve.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return A list of reference code information if found, otherwise null. 
	 */	
	public List<ReferenceCode> listCodesByType(Integer codeType, Integer language);

	/**
	 * Retrieve the reference code of all the languages for a given code type and code.
	 * 
	 * @param codeType the type of the code to retrieve
	 * @param code the code of the type of code to retrieve
	 * 
	 * @return a List of reference code information if found, otherwise null.
	 */
	public List<ReferenceCode> listCodesByTypeAndCode(Integer codeType, Integer code);
	
	/**
	 * Retrieve the reference code for the given description and language.
	 *  
	 * @param description The reference code description.
	 * @param codeType The type of code to retrieve.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return The reference code information if found, otherwise null. 
	 */
	public ReferenceCode getCodeByDescription(String description, Integer codeType, Integer language);
	
	/**
	 * The following methods are convenience methods to get a set of reference codes 
	 * in a specific language, just by calling the appropriate method.
	 * The Reference code Qualifier injected into the class will decide the language to use during the retrieval of the data.
	 * 
	 * i.e.:  @Autowired @Qualifier("frenchReferenceCodeDao")  -- This will get the Reference Code information in French. 
	 * i.e.:  @Autowired @Qualifier("englishReferenceCodeDao")  -- This will get the Reference Code information in English. 
	 * 
	 */
	public List<ReferenceCode> getClaimTypes();
	public List<ReferenceCode> getActions();
	public List<ReferenceCode> getGoodsAndServices();
	public List<ReferenceCode> getTrademarkClass();
	public List<ReferenceCode> getTrademarkType();
	public List<ReferenceCode> getDocumentStoredOutputCode();
	public List<ReferenceCode> getTypeOfDocuments();

	public ReferenceCode getClaimType(Integer code);
	public ReferenceCode getAction(Integer code);
	public ReferenceCode getGoodAndService(Integer code);
	public ReferenceCode getTrademarkClass(Integer code);
	public ReferenceCode getTrademarkType(Integer code);
	public ReferenceCode getDocumentStoredOutputCode(Integer code);
	public ReferenceCode getTypeOfDocument(Integer code);
	
}
