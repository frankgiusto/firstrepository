/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AgentRepresentativeActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.AgentRepresentativeActions;
import ca.gc.ic.cipo.tm.model.AuthoritiesId;

/**
 * The agentRepresentativeActionsDaoImpl retrieves data from the AR_ACTIONS Table using Hibernate.
 *
 * @see AgentRepresentativeActionsDaoImpl
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("agentRepresentativeActionsDao")
public class AgentRepresentativeActionsDaoImpl extends HibernateBaseDao implements AgentRepresentativeActionsDao {

    /**
     *
     */
    private static final long serialVersionUID = 7716092459131829016L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(AgentRepresentativeActionsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<AgentRepresentativeActions> getAgentRepresentativeActions(Integer arNumber, String authorityId) {
        // TODO Auto-generated method stub
        List<AgentRepresentativeActions> agentRepresentativeActions = new ArrayList<AgentRepresentativeActions>();
        try {
            Criteria criteria = getSession().createCriteria(AgentRepresentativeActions.class);
            criteria.add(Restrictions.eq(ModelPropertyType.AGENT_REPRESENTATIVE_AR_NUMBER.getValue(), arNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.AGENT_REPRESENTATIVE_ACTIONS_ID_AUTHORITY_ID.getValue(),
                authorityId));
            agentRepresentativeActions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving agent representative actions with parameters [" + arNumber + ", "
                + authorityId + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<AgentRepresentativeActions>(agentRepresentativeActions);
    }

    @Override
    public Set<AgentRepresentativeActions> getAgentRepresentativeActions(AgentRepresentative agentRepresentative,
                                                                         AuthoritiesId authoritiesId) {
        return this.getAgentRepresentativeActions(agentRepresentative.getArNumber(), authoritiesId.getAuthorityId());
    }
}
