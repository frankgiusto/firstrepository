package ca.gc.ic.cipo.tm.type;

import java.util.Properties;

// TODO remove class
@Deprecated
public class TradeMarkDocTypeDesign implements TradeMarkDocType {

    @Override
    public String path(Properties property) {
        if (null == property) {
            return "";
        }
        return property.getProperty(TradeMarkPropertyKey.CONTENT_PATH_DESIGNS.getValue());
    }
}
