package ca.gc.ic.cipo.tm.dao.search;

import java.util.List;

import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Interface for providing search on InterestedParties and InterestedPartiesAddresses. Utilizes the Expression objects
 * and builds a native SQL
 */
public interface InterestedPartySearch {

    /**
     * Search for applicants based on the search expressions (criteria) Address type will always be Primary. Used for
     * Filing applicant search
     *
     * @param expression the collection of expressions
     * @param searchOperator (AND or OR)
     * @return the list of retrieved InterestedPart objects
     */
    public List<InterestedParty> searchApplicants(List<Expression> expressions, HibernateOperatorEnum searchOperator);

    /**
     * Search for interested parties based on the search expressions (criteria). No restrictions on address types: Used
     * by TMOB or other applications besides Filing
     *
     * @param expression the collection of expressions
     * @param searchOperator (AND or OR)
     * @return the list of retrieved InterestedPart objects
     */
    public List<InterestedParty> searchInterestedParties(List<Expression> expressions,
                                                         HibernateOperatorEnum searchOperator);

}
