/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AgentUserXrefDao;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentUserXref;

/**
 * @author houreich
 *
 */
@Repository("agentUserXrefDao")
public class AgentUserXrefDaoImpl extends HibernateBaseDao implements AgentUserXrefDao {

    /**
     *
     */
    private static final long serialVersionUID = 8538094458317262039L;

    /** {@inheritDoc} */
    @Override
    public List<AgentUserXref> getAgentUserXrefs(String userId, Integer arNumber) {
        // TODO Auto-generated method stub
        List<AgentUserXref> agentUserXrefs = new ArrayList<AgentUserXref>();

        try {
            Criteria criteria = getSession().createCriteria(AgentUserXref.class);
            criteria.add(Restrictions.eq("userId", userId));
            criteria.add(Restrictions.eq("arNumber", arNumber));
            agentUserXrefs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "Error retrieving application with parameters [" + userId + ", " + arNumber + "] /n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }

        return agentUserXrefs;
    }

}
