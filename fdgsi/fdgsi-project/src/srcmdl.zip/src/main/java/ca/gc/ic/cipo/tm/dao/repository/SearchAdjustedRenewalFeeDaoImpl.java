package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.SearchAdjustedRenewalFeeDao;
import ca.gc.ic.cipo.tm.dao.helpers.SearchAdjustedRenewalFeeQueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.SearchConstants;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.SearchAdjustedRenewalFee;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * The SearchAdjustedRenewalFeeDaoImpl retrieves data from the many Tables using Hibernate.
 *
 * @see SearchAdjustedRenewalFeeDao
 * @see HibernateBaseDAO
 *
 * @author Peloquip
 *
 */
@Repository("searchAdjustedRenewalFeeDao")
public class SearchAdjustedRenewalFeeDaoImpl extends HibernateBaseDao implements SearchAdjustedRenewalFeeDao {

    private static final long serialVersionUID = 3638898933175290930L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(SearchAdjustedRenewalFeeDaoImpl.class);

    @Override
    public List<SearchAdjustedRenewalFee> searchAdjustedRenewalFee(SearchRegistrationCriteria searchCriteria) {
        List<SearchAdjustedRenewalFee> results = doSearchAdjustedRenewalFee(searchCriteria);
        return results;
    }

    public List<SearchAdjustedRenewalFee> doSearchAdjustedRenewalFee(SearchRegistrationCriteria searchCriteria) {

        LOG.debug("About to retrieve SearchAdjustedRenewalFee");
        checkFileNumberOrDatesIfApplicable(searchCriteria);

        // Setting the parameters
        Map<String, Object> parameters = new HashMap<>();
        boolean fileNumberProvided = false;

        // Search by application number - including extension counter (set to 0 by default in the sql)
        if (searchCriteria.getApplicationNumber() != null
            && searchCriteria.getApplicationNumber().getFileNumber() != null) {
            parameters.put(SearchConstants.SEARCH_FILE_NUMBER.getValue(),
                searchCriteria.getApplicationNumber().getFileNumber());
            fileNumberProvided = true;
        }
        // Search by registration number
        if (searchCriteria.getRegistrationNumber() != null) {
            parameters.put(SearchConstants.SEARCH_REGISTRATION_NUMBER.getValue(),
                searchCriteria.getRegistrationNumber());
        }

        // legislation code
        if (searchCriteria.getLegislationCode() != null) {
            parameters.put(SearchConstants.SEARCH_LEGISLATION.getValue(), searchCriteria.getLegislationCode());
        }

        // the requestor is always provided, the query test if it's an active agent to include the agent within the firm
        // sub query
        if (StringUtils.hasText(searchCriteria.getRequestorUserId())) {
            parameters.put(SearchConstants.SEARCH_REQUESTOR_USER_ID.getValue(), searchCriteria.getRequestorUserId());
        }

        // Search by trademark name, only available for Agents
        if (StringUtils.hasText(searchCriteria.getTrademarkName())) {
            parameters.put(SearchConstants.SEARCH_TRADEMARK_TEXT.getValue(),
                "%" + searchCriteria.getTrademarkName() + "%");
        }

        // Search by applicant name, only available for Agents
        if (StringUtils.hasText(searchCriteria.getApplicantName())) {
            parameters.put(SearchConstants.SEARCH_APPLICANT_NAME.getValue(),
                "%" + searchCriteria.getApplicantName() + "%");
        }

        // max results
        if (searchCriteria.getMaxResults() != null) {
            parameters.put("rowNum", searchCriteria.getMaxResults());
        }

        // Building the sql query
        SearchAdjustedRenewalFeeQueryHelper queryHelper = new SearchAdjustedRenewalFeeQueryHelper();
        String sql = queryHelper.buildQuery(searchCriteria);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(sql, parameters);

        sqlQuery = sqlQuery.addScalar(SearchConstants.SEARCH_FILE_NUMBER.getValue(), IntegerType.INSTANCE)
            .addScalar(SearchConstants.SEARCH_EXTENSION_COUNTER.getValue(), IntegerType.INSTANCE)
            .addScalar(SearchConstants.SEARCH_REGISTRATION_NUMBER.getValue(), IntegerType.INSTANCE)
            .addScalar(SearchConstants.SEARCH_LEGISLATION.getValue(), IntegerType.INSTANCE)
            .addScalar(SearchConstants.SEARCH_TRADEMARK_TEXT.getValue(), StringType.INSTANCE)
            .addScalar(SearchConstants.SEARCH_ADDITIONAL_INFO.getValue(), StringType.INSTANCE)
            .addScalar(SearchConstants.SEARCH_RESPONSE_DATE.getValue(), DateType.INSTANCE);

        /**
         * In case no file number is provided as part of the search criteria
         */
        if (!fileNumberProvided) {
            sqlQuery
                .setDate(SearchConstants.SEARCH_START_DATE.getValue(),
                    searchCriteria.getStartDate()) /* always provided when file number is not provided */
                .setDate(SearchConstants.SEARCH_END_DATE.getValue(),
                    searchCriteria.getEndDate()); /* always provided when file number is not present */
        }

        sqlQuery.setResultTransformer(Transformers.aliasToBean(SearchAdjustedRenewalFee.class));
        @SuppressWarnings("unchecked")
        List<SearchAdjustedRenewalFee> result = sqlQuery.list();
        return result;
    }

    private void checkFileNumberOrDatesIfApplicable(SearchRegistrationCriteria searchCriteria) {
        if (searchCriteria != null) {
            if (isApplicationNumberNotProvided(searchCriteria.getApplicationNumber())) {
                if (searchCriteria.getStartDate() == null && searchCriteria.getEndDate() == null) {
                    throw new IllegalArgumentException(
                        "Application number not part of search. Expected Start date and End date: but was [null]");
                }
            }
        }
    }

    private boolean isApplicationNumberNotProvided(ApplicationNumber applicationNumber) {
        boolean result = (applicationNumber == null
            || (applicationNumber.getFileNumber() == null || applicationNumber.getExtensionCounter() == null)
            || (applicationNumber.getFileNumber() <= 0 || applicationNumber.getExtensionCounter() < 0));
        return result;
    }

}
