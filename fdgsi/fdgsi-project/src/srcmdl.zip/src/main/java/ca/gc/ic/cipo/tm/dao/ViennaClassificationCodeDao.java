package ca.gc.ic.cipo.tm.dao;

import java.util.Collection;

import ca.gc.ic.cipo.tm.model.ViennaClassificationCode;

/**
 * ViennaClassificationCodesDAO is an interface used to find a Vienna 
 * classification codes and descriptions based on category, division,  
 * section and/or language.    
 * 
 * @see ViennaClassificationCode
 * 
 * @author DenisJ1
 *
 */
public interface ViennaClassificationCodeDao {	
	
	/**
	 * Retrieve the Vienna Classification code for the given category, division, 
	 * section and language.
	 *  
	 * @param category The Vienna Category.
	 * @param division The Vienna Division.
	 * @param section The Vienna Section.
	 * @param language The language to retrieve (English or French).
	 * 
	 * @return The Vienna Classification code information if found, otherwise null. 
	 */
	public ViennaClassificationCode getClassificationCode(Integer category, Integer division, Integer section, Integer language);

	/**
	 * Retrieve the collection of Vienna Classification codes based on the given language. 
	 *
 	 * @param language The language to retrieve (English or French).
 	 * 
	 * @return A Collection of Vienna Classification code information if found, otherwise null. 
	 */
	public Collection<ViennaClassificationCode> listClassificationCodesByLanguage(Integer language);
	
	/**
	 * Retrieve the collection of Vienna Classification codes for the given category, 
	 * division and section.
	 *  
	 * @param category The Vienna Category.
	 * @param division The Vienna Division.
	 * @param section The Vienna Section.
	 * 
	 * @return A list of Vienna Classification code information if found, otherwise null. 
	 */
	public Collection<ViennaClassificationCode> listClassificationCodes(Integer category, Integer division, Integer section);
}
