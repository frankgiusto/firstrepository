package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;

/**
 * Dao Interface contract for Agent representatives.
 *
 * @author sagary
 */
public interface AgentRepresentativeDao extends BaseDao {

    /**
     * Retrieve and return the list of active agents for the specified User Id.
     *
     * @param userId the User Id
     * @return the Collection of AgentRepresentative objects
     */
    public List<AgentRepresentative> getActiveAgents(String userId);

    /**
     * Retrieve and return a AgentRepresentative from the supplied agent number
     *
     * @param arNumber the agent number
     * @return the AgentRepresentative entity model
     */
    public AgentRepresentative getAgentRepresentative(Integer arNumber);

    /**
     * Retrieves and return the next agent number (AR_NUMBER).
     *
     * @return the max ar_numner + 1
     */
    public Integer getNextAgentRepresentativeNumber();

}
