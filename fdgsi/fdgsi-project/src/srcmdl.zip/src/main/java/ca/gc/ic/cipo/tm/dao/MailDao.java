/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.Mail;

public interface MailDao {

    public void saveMail(Mail mail);

    public List<Mail> getMailByFileId(Integer fileNumber);

    public void updateMailAttachedIndicator(Integer fileType, Integer fileNumber, String attachmentFilename);

    public void updateMailAttachedIndicatorWithAuthority(Integer fileNumber, String processedByAuthorityID,
                                                         Integer fileType);

    public void updateMailAttachedIndicatorWithAuthority(Integer fileNumber, String processedByAuthorityID,
                                                         Integer fileType, Integer mailType);

    public Mail getMail(Integer fileNumber, Integer fileType, Integer mailAttachedInd, String attachmentFilename);

    public void deleteMailRecord(Integer fileNumber, Integer fileType, String attachmentFilename);

}
