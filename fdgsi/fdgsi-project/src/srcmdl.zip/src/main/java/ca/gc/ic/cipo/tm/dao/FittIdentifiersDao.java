/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FittIdentifiers;
import ca.gc.ic.cipo.tm.model.FittIdentifiersId;

/**
 * @author houreich
 *
 */
public interface FittIdentifiersDao {

    public Set<FittIdentifiers> getFittIdentifiers(Integer fileNumber, Integer extensionCounter);

    // TODO should return single object, PK
    public Set<FittIdentifiers> getFittIdentifiers(Integer fileNumber, Integer extensionCounter, String mrUID);

    public Set<FittIdentifiers> getFittIdentifiers(ApplicationNumber applicationNumber);

    // TODO remove, Application is an ApplicationNumber
    @Deprecated
    public Set<FittIdentifiers> getFittIdentifiers(Application application);

    // TODO should return single object, PK
    public Set<FittIdentifiers> getFittIdentifiers(ApplicationNumber applicationNumber, String mrUID);

    // TODO remove, Application is an ApplicationNumber
    @Deprecated
    public Set<FittIdentifiers> getFittIdentifiers(Application application, String mrUID);

    // TODO remove ApplicationNumber, FittIdentifiersId is sufficient, return a single object (PK)
    public Set<FittIdentifiers> getFittIdentifiers(ApplicationNumber applicationNumber,
                                                   FittIdentifiersId fittIdentifiersId);

    public void saveFittIdentifiers(FittIdentifiers fittIdentifiers);

}
