package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.RegistrationRenewalDao;
import ca.gc.ic.cipo.tm.dao.helpers.SearchRegistrationsQueryHelper;
import ca.gc.ic.cipo.tm.model.RegistrationRenewal;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Implementation for RegistrationRenewalDao interface
 */
@Repository("registrationRenewalDao")
public class RegistrationRenewalDaoImpl extends HibernateBaseDao implements RegistrationRenewalDao {

    private static final long serialVersionUID = -3007602294779384438L;

    @Override
    public List<RegistrationRenewal> searchRegistrationsForRenewal(SearchRegistrationCriteria searchCriteria) {
        return doSearchRegistrationsForRenewal(searchCriteria);
    }

    private List<RegistrationRenewal> doSearchRegistrationsForRenewal(SearchRegistrationCriteria searchCriteria) {

        if (isSearchCriteriaNull(searchCriteria) && !StringUtils.hasText(searchCriteria.getTrademarkName())
            && !StringUtils.hasText(searchCriteria.getApplicantName())

            && (CollectionUtils.isEmpty(searchCriteria.getAgentNumbers()) && searchCriteria.getStartDate() == null
                && searchCriteria.getEndDate() == null)) {

            throw new IllegalArgumentException("Search criteria is not valid at least one field must be provided");
        }

        if (searchCriteria.getMaxResults() <= 0) {
            throw new IllegalArgumentException(
                "Results size expected: greater than 0 - but was " + searchCriteria.getMaxResults());
        }

        SearchRegistrationsQueryHelper queryHelper = new SearchRegistrationsQueryHelper();
        String sql = queryHelper.buildQuery(searchCriteria);

        Map<String, Object> parameters = new HashMap<>();

        if (searchCriteria.getApplicationNumber() != null) {
            if (searchCriteria.getApplicationNumber().getFileNumber() != null) {
                parameters.put("fileNumber", searchCriteria.getApplicationNumber().getFileNumber());
            }

            if (searchCriteria.getApplicationNumber().getExtensionCounter() != null) {
                parameters.put("extensionCounter", searchCriteria.getApplicationNumber().getExtensionCounter());
            }
        }

        if (searchCriteria.getRegistrationNumber() != null) {
            parameters.put("registrationNumber", searchCriteria.getRegistrationNumber());
        }

        if (searchCriteria.getLegislationCode() != null) {
            parameters.put("legislation", searchCriteria.getLegislationCode());
        }

        // trademark name
        if (StringUtils.hasText(searchCriteria.getTrademarkName())) {
            parameters.put("text", "%" + searchCriteria.getTrademarkName() + "%");
        }

        // owner name
        if (StringUtils.hasText(searchCriteria.getApplicantName())) {
            parameters.put("ownerName", "%" + searchCriteria.getApplicantName() + "%");
        }

        // max results
        if (searchCriteria.getMaxResults() != null) {
            parameters.put("rowNum", searchCriteria.getMaxResults());
        }

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(sql, parameters);

        // if agent numbers provided
        if (!CollectionUtils.isEmpty(searchCriteria.getAgentNumbers())) {

            // agent numbers
            sqlQuery.setParameterList("agentNumbers", searchCriteria.getAgentNumbers());

            // start date filter
            if (searchCriteria.getStartDate() != null) {
                sqlQuery.setDate("renewalStartDate", searchCriteria.getStartDate());
            }
            // end date filter
            if (searchCriteria.getEndDate() != null) {
                sqlQuery.setDate("renewalEndDate", searchCriteria.getEndDate());
            }

        }

        sqlQuery.addEntity("rr", RegistrationRenewal.class);

        @SuppressWarnings("unchecked")
        List<RegistrationRenewal> results = sqlQuery.list();
        return results;
    }

    private boolean isSearchCriteriaNull(SearchRegistrationCriteria searchCriteria) {
        return (searchCriteria == null || ((searchCriteria.getApplicationNumber() == null
            || searchCriteria.getApplicationNumber().getFileNumber() == null
                && searchCriteria.getApplicationNumber().getExtensionCounter() == null)
            && searchCriteria.getRegistrationNumber() == null && searchCriteria.getLegislationCode() == null));
    }

}
