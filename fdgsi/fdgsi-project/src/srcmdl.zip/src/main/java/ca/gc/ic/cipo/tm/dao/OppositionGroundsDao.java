package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionGrounds;

public interface OppositionGroundsDao extends BaseDao {

    /**
     * Retrieve a list of Opposition Grounds for the specified application number
     *
     * @param applicationNumberModel the application number
     * @return the list of OppositionGrounds
     */
    List<OppositionGrounds> getOppositonGroundsByApplication(ApplicationNumber applicationNumberModel);

    void saveOppositionGrounds(OppositionGrounds oppositionGrounds);

}
