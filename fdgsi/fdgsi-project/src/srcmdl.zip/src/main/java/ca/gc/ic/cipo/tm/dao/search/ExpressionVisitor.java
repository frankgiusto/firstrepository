package ca.gc.ic.cipo.tm.dao.search;

import java.util.Map;

import org.springframework.util.MultiValueMap;

/**
 * Visits the Expression objects and builds the appropriate where clause SQL
 */
public interface ExpressionVisitor {

    /***
     * Visits and builds the Like expression ('%seach_item%')
     */
    public void visit(LikeExpression likeExpression);

    /***
     * Visits and builds the IN expression
     */
    public void visit(InExpression inExpression);

    /***
     * Visits and builds the Equal expression
     */
    public void visit(EqualExpression equalxpression);

    /***
     * Visits and builds the starts with expression ('%seach_item')
     */
    public void visit(StartWithExpression startWithExpression);

    /***
     * Visits and builds the ends with expression ('seach_item%')
     */
    public void visit(EndWithExpression endWithExpression);

    /***
     * Builds the final query expression
     */
    public String toExpressionQueryString();

    /***
     * Returns the Map of key as parameter names and Object as value
     */
    public Map<String, Object> toParametersMap();

    /***
     * Returns the MultiValue map of key as parameter names and List<Object> as value. Used for IN expressions -
     * primarily
     */
    public MultiValueMap<String, Object> toParameterListMap();

}
