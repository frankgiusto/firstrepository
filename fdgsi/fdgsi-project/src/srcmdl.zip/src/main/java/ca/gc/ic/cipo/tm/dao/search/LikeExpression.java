package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class LikeExpression extends OperatorExpression implements Expression, Serializable {

    private static final long serialVersionUID = 3941946098793064611L;

    public LikeExpression(SearchExpression searchExpression) {
        super(searchExpression, HibernateOperatorEnum.LIKE);
    }

    @Override
    public Criterion compose() {
        if (searchExpression.getOperator() != null && searchExpression.getValues() != null) {
            String property = searchExpression.getNestedModelPropertyType() != null
                ? searchExpression.getNestedModelPropertyType() : searchExpression.getModelPropertyType().getValue();

            String value = searchExpression.firstValueToString();
            return Restrictions.ilike(property, value, MatchMode.ANYWHERE);

        }
        return null;
    }

    @Override
    public void accept(ExpressionVisitor expressionVisitor) {
        expressionVisitor.visit(this);
    }

}
