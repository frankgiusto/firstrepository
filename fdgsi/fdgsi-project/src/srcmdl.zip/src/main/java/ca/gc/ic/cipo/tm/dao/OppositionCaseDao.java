package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.enumerator.OppositionCaseType;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCase;

/**
 * The OppositionCaseDao is an interface used to find and maintain TM opposition cases and actions information.
 *
 * @author wangg2
 *
 */
public interface OppositionCaseDao {

    /**
     * Retrieve and return a list of opposition cases for the specific application number
     *
     * @param applicationNumber the application file number
     * @return the list of type OppositionCase objects
     */
    public List<OppositionCase> getOppositionCases(ApplicationNumber applicationNumber);

    /**
     * Retrieve and return a Opposition case for the specific application file number and case number
     */
    public OppositionCase getOppositionCase(ApplicationNumber applicationNumber, Integer caseNumber);

    /**
     * Persist the Opposition case in the DB
     *
     * @param oppositionCase the Opposition case entity object
     */
    public void saveOppositionCase(OppositionCase oppositionCase);

    /**
     * Retrieves and returns the next available opposition case number for the specific file number and extension
     * counter
     *
     * @param fileNumber the application file number
     * @param extCounter the extension counter
     * @return the returned case number + 1 if not null; else 1 on null
     */
    public Integer getNextOppositionCaseNumberForApplication(Integer fileNumber, Integer extCounter);

    /**
     * Retrieves and returns the collection of Opposition cases by opposition case type
     *
     * @param applicationNumber the file number
     * @param oppCaseType the Opposition case type
     * @return the collection type OppositionCase objects
     */
    public List<OppositionCase> getOppositionCasesByCaseType(ApplicationNumber applicationNumber,
                                                             OppositionCaseType oppCaseType);
}
