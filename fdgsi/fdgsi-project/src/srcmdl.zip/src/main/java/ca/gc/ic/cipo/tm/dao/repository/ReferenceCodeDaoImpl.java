package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ReferenceCodeDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.enumerator.ReferenceCodeType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ReferenceCode;

/**
 * This ReferenceCodesDAO implementation is used to find reference codes based on a code type, a code, and/or language
 * using Hibernate.
 *
 * @see ReferenceCode
 * @see ReferenceCodeDao
 * @see HibernateBaseDAO
 *
 * @author denisj1
 * @author SeguinA3 - Ported and re-factored from TDRS
 */
@Repository("referenceCodeDao")
public class ReferenceCodeDaoImpl extends HibernateBaseDao implements ReferenceCodeDao {

    private static final long serialVersionUID = 5604512609565010266L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ReferenceCodeDaoImpl.class);

    public ReferenceCodeDaoImpl() {
    }

    @Override
    public ReferenceCode getCode(Integer codeType, Integer code, Integer language) {
        logger.debug("getRefCode - Hibernate Session Id = " + getSession().hashCode() + " for [" + codeType + "," + code
            + "," + language + "]" + " - Object = " + this.hashCode());

        ReferenceCode referenceCode = new ReferenceCode();
        try {
            Criteria criteria = getSession().createCriteria(ReferenceCode.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE_TYPE.getValue(), codeType));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE.getValue(), code));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_LANGUAGE.getValue(), language));
            referenceCode = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Reference Code with parameters [" + codeType + ", " + code + ", " + language
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return referenceCode;
    }

    @Override
    public List<ReferenceCode> listCodesByLanguage(Integer language) {
        logger.debug("listRefCodeByLanguage - Hibernate Session Id = " + getSession().hashCode() + " for [" + language
            + "]" + " - Object = " + this.hashCode());

        List<ReferenceCode> referenceCodes = new ArrayList<ReferenceCode>();
        try {
            Criteria criteria = getSession().createCriteria(ReferenceCode.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_LANGUAGE.getValue(), language));
            referenceCodes = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Reference Code with parameters [" + language + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return referenceCodes;
    }

    @Override
    public List<ReferenceCode> listCodesByType(Integer codeType) {
        logger.debug("listRefCodeByCodeType - Hibernate Session Id = " + getSession().hashCode() + " for [" + codeType
            + "]" + " - Object = " + this.hashCode());

        List<ReferenceCode> referenceCodes = new ArrayList<ReferenceCode>();
        try {
            Criteria criteria = getSession().createCriteria(ReferenceCode.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE_TYPE.getValue(), codeType));
            referenceCodes = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Reference Code with parameters [" + codeType + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return referenceCodes;
    }

    @Override
    public List<ReferenceCode> listCodesByType(Integer codeType, Integer language) {
        logger.debug("listRefCodeByType - Hibernate Session Id = " + getSession().hashCode() + " for [" + codeType + ","
            + language + "]" + " - Object = " + this.hashCode());

        List<ReferenceCode> referenceCodes = new ArrayList<ReferenceCode>();
        try {
            Criteria criteria = getSession().createCriteria(ReferenceCode.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE_TYPE.getValue(), codeType));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_LANGUAGE.getValue(), language));
            referenceCodes = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "There are no Reference Code with parameters [" + codeType + ", " + language + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }

        return referenceCodes;
    }

    @Override
    public ReferenceCode getCodeByDescription(String description, Integer codeType, Integer language) {
        logger.debug("getCodeByDescription - Hibernate Session Id = " + getSession().hashCode() + " for [" + description
            + ", " + codeType + "," + language + "]" + " - Object = " + this.hashCode());

        ReferenceCode referenceCode = new ReferenceCode();
        try {
            Criteria criteria = getSession().createCriteria(ReferenceCode.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_DESCRIPTION.getValue(), description));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE_TYPE.getValue(), codeType));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_LANGUAGE.getValue(), language));
            referenceCode = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Reference Code with parameters [" + description + ", " + codeType + ", "
                + language + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return referenceCode;
    }

    @Override
    public List<ReferenceCode> listCodesByTypeAndCode(Integer codeType, Integer code) {
        logger.debug("getCodesByTypeAndCode - Hibernate Session Id = " + getSession().hashCode() + " for [ " + codeType
            + ", " + code + "] - Object = " + this.hashCode());

        List<ReferenceCode> referenceCodes = new ArrayList<ReferenceCode>();
        try {
            Criteria criteria = getSession().createCriteria(ReferenceCode.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE_TYPE.getValue(), codeType));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE.getValue(), code));
            referenceCodes = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "There are no Reference Code with parameters [" + codeType + ", " + code + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return referenceCodes;
    }

    // Convenience methods
    @Override
    public List<ReferenceCode> getClaimTypes() {
        return verifyInstances(listCodesByType(ReferenceCodeType.CLAIM_TYPE.getValue()));
    }

    @Override
    public List<ReferenceCode> getActions() {
        return verifyInstances(listCodesByType(ReferenceCodeType.ACTIONS.getValue()));
    }

    @Override
    public List<ReferenceCode> getGoodsAndServices() {
        return verifyInstances(listCodesByType(ReferenceCodeType.GOODS_SERVICES.getValue()));
    }

    @Override
    public List<ReferenceCode> getTrademarkClass() {
        return verifyInstances(listCodesByType(ReferenceCodeType.TRADEMARK_CLASS.getValue()));
    }

    @Override
    public List<ReferenceCode> getTrademarkType() {
        return verifyInstances(listCodesByType(ReferenceCodeType.TRADEMARK_TYPE.getValue()));
    }

    @Override
    public List<ReferenceCode> getDocumentStoredOutputCode() {
        return verifyInstances(listCodesByType(ReferenceCodeType.OUTPUT_TITLE.getValue()));
    }

    @Override
    public List<ReferenceCode> getTypeOfDocuments() {
        return verifyInstances(listCodesByType(ReferenceCodeType.TYPE_OF_DOCUMENTS.getValue()));
    }

    /**
     * The following methods are supported when using either the French or English Reference Code DAO Implementation.
     */
    @Override
    public ReferenceCode getClaimType(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    @Override
    public ReferenceCode getAction(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    @Override
    public ReferenceCode getGoodAndService(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    @Override
    public ReferenceCode getTrademarkClass(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    @Override
    public ReferenceCode getDocumentStoredOutputCode(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    @Override
    public ReferenceCode getTypeOfDocument(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    @Override
    public ReferenceCode getTrademarkType(Integer code) {
        throw new UnsupportedOperationException("Use either French or English Reference Code DAO implementation");
    }

    /**
     * These protected methods verifies that no null objects will be returned
     *
     * @param referenceCode
     * @return ReferenceCode
     */
    protected List<ReferenceCode> verifyInstances(List<ReferenceCode> referenceCodes) {
        List<ReferenceCode> noNullList = new ArrayList<ReferenceCode>();
        for (ReferenceCode referenceCode : referenceCodes) {
            noNullList.add(verifyInstance(referenceCode));
        }
        return noNullList;
    }

    protected ReferenceCode verifyInstance(ReferenceCode referenceCode) {
        if (null == referenceCode) {
            referenceCode = new ReferenceCode();
            referenceCode.setDescription("Reference Code not available.");
        }
        return referenceCode;
    }

}
