/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.MadridApplicationXrefDao;
import ca.gc.ic.cipo.tm.model.MadridApplicationXref;

@Repository("madridApplicationXrefDao")
public class MadridApplicationXrefDaoImpl extends HibernateBaseDao implements MadridApplicationXrefDao {

    private static final long serialVersionUID = 8301490304682620800L;

    private static final String DELETE_QUERY_SQL = " DELETE from MADRID_APPLICATIONS_XREF where FILE_NUMBER = :fileNumber and EXTENSION_COUNTER = :extensionCounter and WIPO_REFERENCE_NUMBER = :wipoReferenceNumber ";

    private static final String COUNT_QUERY_SQL = " SELECT COUNT(*) from MADRID_APPLICATIONS_XREF where WIPO_REFERENCE_NUMBER = :wipoReferenceNumber ";

    @Override
    public void saveMadridApplicationXref(MadridApplicationXref madridApplicationXref) {
        Session session = getSession();
        session.saveOrUpdate(madridApplicationXref);
    }

    @Override
    public void deleteMadridApplicationXref(int fileNumber, int extensionCounter, String wipoReferenceNumber) {
        checkWipoReferenceNumber(wipoReferenceNumber);
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("fileNumber", fileNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("wipoReferenceNumber", wipoReferenceNumber);

        executeSQLUpdate(DELETE_QUERY_SQL, parameters);
    }

    @Override
    public Long countMadridApplicationXref(String wipoReferenceNumber) {
        checkWipoReferenceNumber(wipoReferenceNumber);
        SQLQuery query = getSessionFactory().getCurrentSession().createSQLQuery(COUNT_QUERY_SQL);
        query.setString("wipoReferenceNumber", wipoReferenceNumber);

        BigDecimal count = (BigDecimal) query.uniqueResult();
        return count.longValue();
    }

    private void checkWipoReferenceNumber(String wipoRefNumber) {
        if (!StringUtils.hasText(wipoRefNumber)) {
            throw new IllegalArgumentException("Expected: <Wipo Reference Number> but was: < " + wipoRefNumber + " >");
        }
    }

}
