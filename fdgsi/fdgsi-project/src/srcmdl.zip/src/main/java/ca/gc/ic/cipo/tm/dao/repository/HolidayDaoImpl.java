package ca.gc.ic.cipo.tm.dao.repository;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.HolidayDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;

/**
 * @author Charles Hein - CIPO / OPIC
 */
@Repository("holidayDao")
public class HolidayDaoImpl extends HibernateBaseDao implements HolidayDao {

    private static final long serialVersionUID = 4453346339379248042L;

    private static final String CHECK_HOLIDAY_SQL = " SELECT count(*) from DIES_NONS where dies_date = :date and tmo_open_ind = 0 ";

    /**
     * Verifies if the date falls on an holiday.
     *
     * @param date the date to verify
     * @return true if it is an holiday, false otherwise.
     */
    @Override
    public boolean isHoliday(Date date) {
        boolean isHoliday = false;
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.HOLIDAY_DATE.getValue(), date);

        SQLQuery query = (SQLQuery) createSQLQuery(CHECK_HOLIDAY_SQL, parameters);

        Object result = query.uniqueResult();
        if (result instanceof BigDecimal) {
            isHoliday = ((BigDecimal) result).intValue() > 0;
        }
        return isHoliday;
    }

    /**
     * Gets the date that is not an holiday at or after the specified date.
     *
     * @param date the date to verify
     * @return the date at or after the specified one that is not an holiday.
     */
    @Override
    public Date getOpenBusinessDate(Date date) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        Boolean isHoliday = false;
        do {
            Date testDate = calendar.getTime();
            // Checks for holiday
            isHoliday = isHoliday(testDate);
            if (!isHoliday) {
                // Not an holiday
                // Checks for weekend.
                int dow = calendar.get(Calendar.DAY_OF_WEEK);
                isHoliday = (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY);
            }
            if (isHoliday) {
                // move to next day
                calendar.add(Calendar.DAY_OF_YEAR, 1);
            }
        } while (isHoliday);

        return calendar.getTime();
    }

}
