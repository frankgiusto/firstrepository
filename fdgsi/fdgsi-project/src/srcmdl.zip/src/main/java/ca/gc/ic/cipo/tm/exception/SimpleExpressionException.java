package ca.gc.ic.cipo.tm.exception;

public class SimpleExpressionException extends RuntimeException {

    private static final long serialVersionUID = -2567128937059836293L;

    /**
     * Constructor.
     * 
     * @param message A brief description of the error
     */
    public SimpleExpressionException(String message) {
        super(message);
    }

    /**
     * Constructor.
     * 
     * @param cause the root cause of the problem
     */
    public SimpleExpressionException(Throwable cause) {
        super(cause);
    }

    /**
     * Constructor.
     * 
     * @param message
     * @param cause
     */
    public SimpleExpressionException(String message, Throwable cause) {
        super(message, cause);
    }
}
