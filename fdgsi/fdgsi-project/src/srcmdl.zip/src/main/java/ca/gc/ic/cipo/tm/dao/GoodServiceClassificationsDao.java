package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodServiceClassification;
import ca.gc.ic.cipo.tm.model.GoodServiceClassificationId;

public interface GoodServiceClassificationsDao {

    public Set<GoodServiceClassification> getGoodServiceClassifications(ApplicationNumber applicationNumber);

    public Set<GoodServiceClassification> getGoodServiceClassifications(Application application);

    public Set<GoodServiceClassification> getGoodServiceClassifications(ApplicationNumber applicationNumber,
                                                                        Integer niceClassCode);

    public Set<GoodServiceClassification> getGoodServiceClassifications(Application application, Integer niceClassCode);

    public Set<GoodServiceClassification> getGoodServiceClassifications(GoodServiceClassificationId goodServiceClassificationId);

    public void deleteGoodServiceClassifications(ApplicationNumber applicationNumber);

    public void setGoodServiceClassification(GoodServiceClassification goodServiceClassification);

    public void saveGoodServiceClassification(GoodServiceClassification goodServiceClassification);
}
