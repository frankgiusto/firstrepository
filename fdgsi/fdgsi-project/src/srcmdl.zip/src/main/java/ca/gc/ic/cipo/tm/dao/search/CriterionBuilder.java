package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.criterion.Criterion;

@Deprecated
// TODO: Candidate for remoavl
public class CriterionBuilder implements Serializable {

    private static final long serialVersionUID = -5479914784058969216L;

    private List<Expression> expressions;

    public CriterionBuilder() {
    }

    public CriterionBuilder(List<Expression> expressions) {
        this.expressions = expressions;
    }

    public List<Expression> getExpressions() {
        return expressions;
    }

    public void setExpressions(List<Expression> expressions) {
        this.expressions = expressions;
    }

    public void addExpression(Expression expression) {
        expressions.add(expression);
    }

    public List<Criterion> build() {
        List<Criterion> criterions = new ArrayList<Criterion>();
        for (Expression expression : expressions) {
            criterions.add((Criterion) expression.compose());
        }

        return criterions;
    }

}
