/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.Authorities;

/**
 * DAO Interface for Authorities table
 */
public interface AuthoritiesDao extends BaseDao {

    /**
     * Retrieve and return authorities information by authority user id
     *
     * @param userId the Authority UserId
     * @return the {@link Authorities} entity object
     */
    Authorities getAuthoritiesInformationByAuthorityUserId(String userId);

}
