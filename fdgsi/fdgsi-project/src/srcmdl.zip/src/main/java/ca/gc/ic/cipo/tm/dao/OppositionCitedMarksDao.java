package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCitedMarks;

/**
 * Interface for OppositionCitedMarks data access
 */
public interface OppositionCitedMarksDao extends BaseDao {

    /**
     * Retrieve and return a list of OppositionCitedMarks from the specified application number and opposition sequence
     * number
     *
     * @param applicationNumber the application number
     * @param oppositionSeqNumber the opposition sequence number
     * @return the collection of type OppositionCitedMarks
     */
    public List<OppositionCitedMarks> getOppositionCitedMarks(ApplicationNumber applicationNumber,
                                                              Integer oppositionSeqNumber);

    /**
     * Retrieve opposition cited marks by Opposition grounds sequence number
     *
     * @param oppositionSeqNumber opposition grounds sequence number
     * @return the collection of type OppositionCitedMarks objects
     */
    public List<OppositionCitedMarks> getOppositionCitedMarksByOppositionSequenceNumber(Integer oppositionSeqNumber);

    void saveOppositionCitedMarks(OppositionCitedMarks oppositionCitedMarks);

}
