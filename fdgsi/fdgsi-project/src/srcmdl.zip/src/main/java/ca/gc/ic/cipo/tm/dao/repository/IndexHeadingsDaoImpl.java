package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.IndexHeadingsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.IndexHeading;

@Repository("indexHeadingsDao")
public class IndexHeadingsDaoImpl extends HibernateBaseDao implements IndexHeadingsDao {

    private static final long serialVersionUID = -6877797649452771965L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(IndexHeadingsDaoImpl.class);

    @Override
    public List<IndexHeading> getIndexHeadings(ApplicationNumber applicationNumber) {
        try {
            Criteria criteria = getSession().createCriteria(IndexHeading.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            return super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Index Headings with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + "]/n" + ex.getMessage());
            throw new DataAccessException(ex);
        }
    }

    @Override
    public List<IndexHeading> getIndexHeadings(Application application) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getIndexHeadings(applicationNumber);
    }

    @Override
    public List<IndexHeading> getIndexHeadings(ApplicationNumber applicationNumber, Integer sequenceNumber) {
        try {
            Criteria criteria = getSession().createCriteria(IndexHeading.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria
                .add(Restrictions.eq(ModelPropertyType.INDEX_HEADING_ID_SEQUENCE_NUMBER.getValue(), sequenceNumber));
            return super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Index Headings with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + ", " + sequenceNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
    }

    @Override
    public List<IndexHeading> getIndexHeadings(Application application, Integer sequenceNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getIndexHeadings(applicationNumber, sequenceNumber);
    }

}
