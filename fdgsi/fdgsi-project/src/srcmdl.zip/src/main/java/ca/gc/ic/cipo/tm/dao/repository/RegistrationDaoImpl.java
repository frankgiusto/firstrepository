package ca.gc.ic.cipo.tm.dao.repository;

import java.sql.Blob;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.BlobType;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.RegistrationDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Registration;

@Repository("registrationDao")
public class RegistrationDaoImpl extends HibernateBaseDao implements RegistrationDao {

    private static final long serialVersionUID = 1L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(RegistrationDaoImpl.class);

    /**
     * SQL query for isRegistrationExistsInTrademark (two parts combine using UNION) See isRegistrationExistsInTrademark
     * method
     */
    private static final String REG_EXIST_TRADEMARK_1_SQL = "select 1 as found from EC_REGISTRATION where cipoec_tm_apltn_no = :fileNumber and apltn_extn_cntr = :extensionCounter ";

    private static final String REG_EXIST_TRADEMARK_2_SQL = "select cipoec_tm_apltn_no from EC_EXTOFTIME where cipoec_tm_apltn_no = :fileNumber and apltn_extn_cntr = :extensionCounter ";

    private static final String IS_REG_EXISTS_IN_TRDAEMARK_SQL = REG_EXIST_TRADEMARK_1_SQL;

    /**
     * Get the registration page document.
     */
    @Override
    public Blob getRegistrationPageForRegistration(Integer applicationNumber, Integer extensionCounter,
                                                   Integer transactionNumber) {
        final String registrationSql = "select rgs_pg_blob from ec_registration ec, regfeedecuse_history re"
            + " where ec.cipoec_srvc_itm_seq_no = re.cipoec_srvc_itm_seq_no"
            + " and ec.cipoec_tm_apltn_no = :applicationNumber" + " and apltn_extn_cntr = :extensionCounter"
            + " and pymt_trans_no = :transactionNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("applicationNumber", applicationNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("transactionNumber", transactionNumber);
        Blob registrationDoc = (Blob) ((SQLQuery) super.createSQLQuery(registrationSql, parameters))
            .addScalar("rgs_pg_blob", BlobType.INSTANCE).uniqueResult();
        return registrationDoc;
    } // End of the getRegistration method.

    /**
     * Get the registration certificate document.
     */
    @Override
    public Blob getRegistrationCertificate(Integer applicationNumber, Integer extensionCounter,
                                           Integer transactionNumber) {
        final String registrationCertificateSql = "select rgs_crt_blob from ec_registration ec, regfeedecuse_history re"
            + " where ec.cipoec_srvc_itm_seq_no = re.cipoec_srvc_itm_seq_no"
            + " and ec.cipoec_tm_apltn_no = :applicationNumber" + " and apltn_extn_cntr = :extensionCounter"
            + " and pymt_trans_no = :transactionNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("applicationNumber", applicationNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("transactionNumber", transactionNumber);
        Blob registrationCertificateDoc = (Blob) ((SQLQuery) super.createSQLQuery(registrationCertificateSql,
            parameters)).addScalar("rgs_crt_blob", BlobType.INSTANCE).uniqueResult();
        return registrationCertificateDoc;
    } // End of the getRegistrationCertificate method.

    /**
     * Get the declaration of use document.
     */
    @Override
    public Blob getDeclarationOfUse(Integer applicationNumber, Integer extensionCounter, Integer transactionNumber) {
        final String declarationOfUseSql = "select dec_use_blob from ec_registration ec, regfeedecuse_history re"
            + " where ec.cipoec_srvc_itm_seq_no = re.cipoec_srvc_itm_seq_no"
            + " and ec.cipoec_tm_apltn_no = :applicationNumber" + " and apltn_extn_cntr = :extensionCounter"
            + " and pymt_trans_no = :transactionNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("applicationNumber", applicationNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("transactionNumber", transactionNumber);
        Blob declarationOfUseDoc = (Blob) ((SQLQuery) super.createSQLQuery(declarationOfUseSql, parameters))
            .addScalar("dec_use_blob", BlobType.INSTANCE).uniqueResult();
        return declarationOfUseDoc;
    } // End of the getDeclarationOfUse method.

    /**
     * Get the extension of time document.
     */
    @Override
    public Blob getExtensionOfTime(Integer applicationNumber, Integer extensionCounter, Integer transactionNumber) {
        final String extensionOfTimeSql = "select ext_ntc_blob from ec_extoftime ec, regfeedecuse_history re"
            + " where ec.cipoec_srvc_itm_seq_no = re.cipoec_srvc_itm_seq_no"
            + " and ec.cipoec_tm_apltn_no = :applicationNumber" + " and apltn_extn_cntr = :extensionCounter"
            + " and pymt_trans_no = :transactionNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("applicationNumber", applicationNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("transactionNumber", transactionNumber);
        Blob extensionOfTimeDoc = (Blob) ((SQLQuery) super.createSQLQuery(extensionOfTimeSql, parameters))
            .addScalar("ext_ntc_blob", BlobType.INSTANCE).uniqueResult();
        return extensionOfTimeDoc;
    } // End of the getExtensionOfTime method.

    /**
     * Get the renewal certificate document.
     */
    @Override
    public Blob getRenewalCertificate(Integer fileNumber, Integer extensionCounter, Integer confirmationNumber) {
        final String renewalCertificateSql = "select renewal_certificate from web_transactions"
            + " where file_number = :fileNumber" + " and extension_counter = :extensionCounter"
            + " and confirmation_number = :confirmationNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", fileNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("confirmationNumber", confirmationNumber);
        Blob renewalCertificateDoc = (Blob) ((SQLQuery) super.createSQLQuery(renewalCertificateSql, parameters))
            .addScalar("renewal_certificate", BlobType.INSTANCE).uniqueResult();
        return renewalCertificateDoc;
    } // End of the getRenewalCertificate method.

    /**
     * Get the registration page document for renewal.
     */
    @Override
    public Blob getRegistrationPageForRenewal(Integer fileNumber, Integer extensionCounter,
                                              Integer confirmationNumber) {
        final String registrationPageSql = "select registration_page from web_transactions"
            + " where file_number = :fileNumber" + " and extension_counter = :extensionCounter"
            + " and confirmation_number = :confirmationNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", fileNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("confirmationNumber", confirmationNumber);
        Blob registrationPageDoc = (Blob) ((SQLQuery) super.createSQLQuery(registrationPageSql, parameters))
            .addScalar("registration_page", BlobType.INSTANCE).uniqueResult();
        return registrationPageDoc;
    } // End of the getRegistrationPage method.

    /**
     * Get the acknowledgment notice document.
     */
    @Override
    public Blob getAcknowledgementNotice(Integer fileNumber, Integer extensionCounter, Integer confirmationNumber) {
        final String acknowledgementNoticeSql = "select acknowledgement_notice from web_transactions"
            + " where file_number = :fileNumber" + " and extension_counter = :extensionCounter"
            + " and confirmation_number = :confirmationNumber";
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", fileNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("confirmationNumber", confirmationNumber);
        Blob acknowledgementNoticeDoc = (Blob) ((SQLQuery) super.createSQLQuery(acknowledgementNoticeSql, parameters))
            .addScalar("acknowledgement_notice", BlobType.INSTANCE).uniqueResult();
        return acknowledgementNoticeDoc;
    } // End of the getAcknowledgementNotice method.

    @Override
    public boolean isRegistrationExistsInTrademark(ApplicationNumber applicationNumber) {
        Objects.requireNonNull(applicationNumber);
        Map<String, Object> params = new HashMap<>();
        params.put("fileNumber", applicationNumber.getFileNumber());
        params.put("extensionCounter", applicationNumber.getExtensionCounter());
        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(IS_REG_EXISTS_IN_TRDAEMARK_SQL, params);
        sqlQuery.addScalar("found", IntegerType.INSTANCE);

        Integer result = (Integer) sqlQuery.uniqueResult();
        return (result != null);
    }// ~ End of isRegistrationExistsInTrademark

    /** {@inheritDoc} */
    @Override
    public void saveRegistration(Registration registration) {
        LOG.debug("Start saving Registration info");
        Session session = getSession();
        session.saveOrUpdate(registration);
        LOG.debug("Saved Registration info");
    }

} // End of the RegistrationDaoImpl class.
