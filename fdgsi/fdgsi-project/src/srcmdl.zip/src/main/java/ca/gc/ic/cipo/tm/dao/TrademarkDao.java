package ca.gc.ic.cipo.tm.dao;

import java.util.List;
import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FigurativeElement;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.model.TradeMarkInfo;

/**
 * The TrademarkDao is an interface used to find and maintain trade mark information.
 *
 * @author SeguinA3
 *
 */
public interface TrademarkDao {

    // Current TradeMark
    //TODO Should not return a list, one to one association
    public List<TradeMark> getTrademark(Application application);

    public TradeMark getTrademark(Integer fileNumber);

    public Set<FigurativeElement> getTradeMarkFigurativeElements(ApplicationNumber applicationNumber);

    // New to Bill C31/C8
    public List<TradeMarkInfo> getTradeMarkInfo(ApplicationNumber applicationNumber);

    public List<TradeMarkInfo> getTradeMarkInfo(ApplicationNumber applicationNumber, Integer type);

    public void saveTrademark(TradeMark trademark);

}
