package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.CitedLinksDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.CitedLinks;

@Repository("citedLinksDao")
public class CitedLinksDaoImpl extends HibernateBaseDao implements CitedLinksDao {

    private static final long serialVersionUID = 8871289166824455612L;

    @Override
    /** @{inheritDoc} */
    public List<CitedLinks> getCitedLinks(ApplicationNumber applicationNumber, Integer citedSectionNumber,
                                          Integer citedFileNumber, Integer citedExtensionCounter) {
        List<CitedLinks> citedLinks = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(CitedLinks.class);
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_SECTION_NUMBER.getValue(), citedSectionNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_CITED_FILE_NUMBER.getValue(), citedFileNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_CITED_EXTENSION_COUNTER.getValue(),
                citedExtensionCounter));
            citedLinks = super.findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Unable to retrieved cited links for application number [" + applicationNumber.getFileNumber()
                + ", " + applicationNumber.getExtensionCounter() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return citedLinks;
    }

    @Override
    /** @{inheritDoc} */
    public List<CitedLinks> getCitedLinksForFileNumber(ApplicationNumber applicationNumber) {
        List<CitedLinks> citedLinks = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(CitedLinks.class);
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.CITED_LINKS_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            citedLinks = super.findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Unable to retrieved cited links for application number [" + applicationNumber.getFileNumber()
                + ", " + applicationNumber.getExtensionCounter() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return citedLinks;
    }

    @Override
    /** @{inheritDoc} */
    public void saveCitedLinks(CitedLinks citedLinks) {
        super.saveOrUpdateEntity(CitedLinks.class, citedLinks);
    }
}
