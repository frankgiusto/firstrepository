package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;
import java.util.List;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class EndWithExpression extends OperatorExpression implements Expression, Serializable {

    private static final long serialVersionUID = 3941946098793064611L;

    public EndWithExpression(SearchExpression searchExpression) {
        super(searchExpression, HibernateOperatorEnum.END_WITH);
    }

    @Override
    public Criterion compose() {
        HibernateOperatorEnum operator = searchExpression.getOperator();
        List<Object> values = searchExpression.getValues();

        String property = null;

        if (operator != null && values != null) {

            property = searchExpression.getNestedModelPropertyType() != null
                ? searchExpression.getNestedModelPropertyType() : searchExpression.getModelPropertyType().getValue();

            String value = searchExpression.firstValueToString();
            return Restrictions.ilike(property, value, MatchMode.END);
        }

        return null;
    }

    @Override
    public void accept(ExpressionVisitor expressionVisitor) {
        expressionVisitor.visit(this);
    }

}
