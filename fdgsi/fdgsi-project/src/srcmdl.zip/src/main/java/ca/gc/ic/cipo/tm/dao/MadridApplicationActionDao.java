/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.MadridApplicationAction;

/**
 * @author giustof
 *
 */
public interface MadridApplicationActionDao {

    public Long getNextMadridApplicationActionNumber();

    public void saveMadridApplicationAction(MadridApplicationAction madridApplicationAction);

    public List<MadridApplicationAction> getMadridApplicationActionByReferenceNumber(String referenceNumber);
}
