package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.OppositionIp;
import ca.gc.ic.cipo.tm.model.OppositionIpId;

public interface OppositionIpDao extends BaseDao {

    OppositionIp getOppositionIp(OppositionIpId oppositionIpId);

}
