package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DocumentStored;

public interface DocumentStoredDao {

	public List<DocumentStored> getDocumentStored(Integer fileNumber);
	public List<DocumentStored> getDocumentStored(ApplicationNumber applicationNumber);
	public List<DocumentStored> getDocumentStored(Integer fileNumber, Integer extensionCounter);

}
