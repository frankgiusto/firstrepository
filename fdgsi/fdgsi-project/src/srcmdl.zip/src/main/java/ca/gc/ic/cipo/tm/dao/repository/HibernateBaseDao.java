package ca.gc.ic.cipo.tm.dao.repository;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.type.OperatorEnum;
import ca.gc.ic.cipo.tm.type.Property;

/**
 * Basic DAO operations dependent with Hibernate's specific classes
 *
 * @see Autowired
 * @see SessionFactory
 *
 * @author SeguinA3
 *
 */

public abstract class HibernateBaseDao implements Serializable, BaseDao {

    private static final long serialVersionUID = -8688473006487128511L;

    /** Logger. */
    protected static final Logger logger = Logger.getLogger(HibernateBaseDao.class);

    /** Hibernate Session factory. */
    private SessionFactory sessionFactory;

    /**
     * Default constructor. Build an abstract Hibernate DAO to persist a specific entity model.
     */
    protected HibernateBaseDao() {
        this.sessionFactory = null;
    }

    /**
     * Return the Hibernate Session Factory.
     *
     * @return A reference of the Session factory if it exists, otherwise null.
     */
    protected SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    /**
     * Sets the Hibernate Session factory.
     *
     * @param sessionFactory The Session factory.
     */
    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /**
     * Return the current session associated to the local thread using the session factory. No session information is
     * available for storage operation. This function should be used for read only operations only since no auditing
     * trail information is required.
     *
     * @return The current session if it exists, otherwise null.
     */
    protected Session getSession() {
        return sessionFactory != null ? sessionFactory.getCurrentSession() : null;
    }

    /**
     * Return the current session associated to the local thread using the session factory. No session information is
     * available for storage operation. This function should be used for a insert/update operations only since auditing
     * information is required.
     *
     * @return The current session if it exists, otherwise null.
     */
    protected Session getSession(String userId) {
        return sessionFactory != null ? sessionFactory.getCurrentSession() : null;
    }

    /**
     * Returns true if the entity is connected to the current Hibernate session.
     *
     * @param entity The entity to verify.
     *
     * @return <code>True</code> if the entity is connected to the current session, otherwise <code>false</code>.
     */
    public <TEntity> boolean contains(TEntity entity) {
        return contains(getSession(), entity);
    }

    /**
     * Returns true if the entity is connected to the current Hibernate session.
     *
     * @param session The Hibernate session.
     * @param entity The entity to verify.
     *
     * @return <code>True</code> if the entity is connected to the current session, otherwise <code>false</code>.
     */
    protected <TEntity> boolean contains(Session session, TEntity entity) {
        return session.contains(entity);
    }

    /**
     * Flushes changes in the Hibernate cache to the data store.
     */
    public void flush() {
        flush(getSession());
    }

    /**
     * Flushes changes in the Hibernate cache to the data store.
     *
     * @param session The Hibernate session.
     */
    protected void flush(Session session) {
        session.flush();
    }

    /**
     * Build a simple criterion that match the given comparison operator.
     *
     * @param propertyName Name of the property.
     * @param value Value of the property.
     * @param operation Comparison operator.
     *
     * @return A Criterion representing the given property with it's value.
     */
    public static Criterion toCriterion(String propertyName, Object value, OperatorEnum operation) {

        Criterion criterion = null;

        if (propertyName != null) {
            if (operation == OperatorEnum.EQUAL) {
                criterion = Restrictions.eq(propertyName, value);
            } else if (operation == OperatorEnum.NOT_EQUAL) {
                criterion = Restrictions.ne(propertyName, value);
            } else if (operation == OperatorEnum.LESS_OR_EQ) {
                criterion = Restrictions.le(propertyName, value);
            } else if (operation == OperatorEnum.LESS_THAN) {
                criterion = Restrictions.lt(propertyName, value);
            } else if (operation == OperatorEnum.GREATER_OR_EQ) {
                criterion = Restrictions.ge(propertyName, value);
            } else if (operation == OperatorEnum.GREATER_THAN) {
                criterion = Restrictions.gt(propertyName, value);
            } else if (operation == OperatorEnum.LIKE) {
                criterion = Restrictions.like(propertyName, value);
            } else if (operation == OperatorEnum.NOT_LIKE) {
                criterion = Restrictions.not(Restrictions.like(propertyName, value));
            } else {
                throw new IllegalArgumentException("Search operation NOT supported ...");
            }
        }
        return criterion;
    }

    /**
     * Add an Order By.
     *
     * @param orderBy Order by details.
     *
     * @return The resulting criteria.
     */

    public Criteria addOrder(Criteria criteria, Property property) {
        if (property.getOrderByEnum().isAscending()) {
            criteria.addOrder(Order.asc(property.getName()));
        } else {
            criteria.addOrder(Order.desc(property.getName()));
        }
        return criteria;
    }

    /**
     * Add a list of Order By.
     *
     * @param ordersBy List of order by details.
     *
     * @return The resulting criteria.
     */
    public Criteria addOrder(Criteria criteria, List<Property> properties) {
        for (Property property : properties) {
            addOrder(criteria, property);
        }
        return criteria;
    }

    /**
     * Return the persistent instance of the given entity class with the given key identifier, assuming that the
     * instance exists. Throw an unrecoverable exception if there is no matching database row.
     *
     * @param entityClass The entity class.
     * @param key The key identifier of the entity.
     *
     * @return The persistent entity.
     */
    public <TKey, TEntity> TEntity load(Class<TEntity> entityClass, TKey key) {
        return load(getSession(), entityClass, key);
    }

    /**
     * Return the persistent instance of the given entity class with the given key identifier, assuming that the
     * instance exists. Throw an unrecoverable exception if there is no matching database row.
     *
     * @param session The Hibernate session.
     * @param entityClass The entity class.
     * @param key The key identifier of the entity.
     *
     * @return The persistent entity.
     */
    @SuppressWarnings("unchecked")
    protected <TKey, TEntity> TEntity load(Session session, Class<TEntity> entityClass, TKey key) {

        TEntity entity = null;
        try {
            entity = (TEntity) session.load(entityClass, (Serializable) key);
        } catch (HibernateException e) {
            logger.error("Hibernate error while loading entity", e);
            throw new DataAccessException(e);
        }
        return entity;
    }

    /**
     * Read the persistent state associated with the given identifier into the given entity transient instance. Throw an
     * unrecoverable exception if there is no matching database row.
     *
     * @param entity The transient entity.
     * @param key The key identifier of the transient entity.
     *
     */
    public <TKey, TEntity> void load(TEntity entity, TKey key) {

        load(getSession(), entity, key);
    }

    /**
     * Read the persistent state associated with the given identifier into the given entity transient instance. Throw an
     * unrecoverable exception if there is no matching database row.
     *
     * @param session The Hibernate session.
     * @param entity The transient entity.
     * @param key The key identifier of the transient entity.
     *
     */
    protected <TKey, TEntity> void load(Session session, TEntity entity, TKey key) {

        try {
            session.load(entity, (Serializable) key);
        } catch (HibernateException e) {
            logger.error("Hibernate error while loading entity", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Make a transient instance persistent and add it to the data store. This operation cascades to associated
     * instances if the association is mapped with cascade="persist". Throws an error if the entity already exists.
     *
     * This is different from <code>save()</code> in that it does not guarantee that the object will be assigned an
     * identifier immediately. With <code>save()</code> a call is made to the data store immediately if the id is
     * generated by the data store so that the id can be determined. With <code>persist</code> this call may not occur
     * until flush time.
     *
     * @param entity The entity to persist.
     *
     * @see save
     */
    public <TEntity> void persist(TEntity entity) {
        persist(getSession(), entity);
    }

    /**
     * Make a transient instance persistent and add it to the data store. This operation cascades to associated
     * instances if the association is mapped with cascade="persist". Throws an error if the entity already exists.
     *
     * This is different from <code>save()</code> in that it does not guarantee that the object will be assigned an
     * identifier immediately. With <code>save()</code> a call is made to the data store immediately if the id is
     * generated by the data store so that the id can be determined. With <code>persist</code> this call may not occur
     * until flush time.
     *
     * @param session The Hibernate session.
     * @param entity The entity to persist.
     *
     * @see save
     */
    protected <TEntity> void persist(Session session, TEntity entity) {
        try {
            session.persist(entity);
        } catch (HibernateException e) {
            logger.error("Hibernate error while persisting entity", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Persist the given transient entity and add it to the data store, first assigning a generated identifier. (Or
     * using the current value of the identifier property if the assigned generator is used.) This operation cascades to
     * associated instances if the association is mapped with cascade="save-update".
     *
     * This is different from <code>persist()</code> in that it does guarantee that the object will be assigned an
     * identifier immediately. With <code>save()</code> a call is made to the data store immediately if the id is
     * generated by the data store so that the id can be determined. With <code>persist</code> this call may not occur
     * until flush time.
     *
     * @param entity The entity to saved.
     *
     * @return The id of the newly saved entity.
     *
     * @see create
     * @see update
     */
    public <TKey, TEntity> TKey save(TEntity entity) {
        return save(getSession(), entity);
    }

    /**
     * Persist the given transient entity and add it to the data store, first assigning a generated identifier. (Or
     * using the current value of the identifier property if the assigned generator is used.) This operation cascades to
     * associated instances if the association is mapped with cascade="save-update".
     *
     * This is different from <code>persist()</code> in that it does guarantee that the object will be assigned an
     * identifier immediately. With <code>save()</code> a call is made to the data store immediately if the id is
     * generated by the data store so that the id can be determined. With <code>persist</code> this call may not occur
     * until flush time.
     *
     * @param session The Hibernate session.
     * @param entity The entity to saved.
     *
     * @return The id of the newly saved entity.
     *
     * @see create
     * @see update
     */
    @SuppressWarnings("unchecked")
    protected <TKey, TEntity> TKey save(Session session, TEntity entity) {
        TKey id = null;
        try {
            id = (TKey) session.save(entity);
        } catch (HibernateException e) {
            logger.error("Hibernate error while saving entity", e);
            throw new DataAccessException(e);
        }

        return id;
    }

    /**
     * <p>
     * Calls Hibernate's <code>saveOrUpdate()</code>, which behaves as follows:
     *
     * Either <code>save()</code> or <code>update()</code> based on the following rules:
     * <ul>
     * <li>If the object is already persistent in this session, do nothing
     * <li>If another object associated with the session has the same identifier, throw an exception
     * <li>If the object has no identifier property, save() it
     * <li>If the object's identifier has the value assigned to a newly instantiated object, save() it
     * <li>If the object is versioned (by a &lt;version&gt; or &lt;timestamp&gt;), and the version property value is the
     * same value assigned to a newly instantiated object, save() it
     * <li>Otherwise update() the object
     * </ul>
     *
     * @param entity The entity to saved or update.
     *
     * @see save
     * @see update
     */
    protected <TEntity> void saveOrUpdate(TEntity entity) {
        saveOrUpdate(getSession(), entity);
    }

    /**
     * <p>
     * Calls Hibernate's <code>saveOrUpdate()</code>, which behaves as follows:
     *
     * Either <code>save()</code> or <code>update()</code> based on the following rules:
     * <ul>
     * <li>If the object is already persistent in this session, do nothing
     * <li>If another object associated with the session has the same identifier, throw an exception
     * <li>If the object has no identifier property, save() it
     * <li>If the object's identifier has the value assigned to a newly instantiated object, save() it
     * <li>If the object is versioned (by a &lt;version&gt; or &lt;timestamp&gt;), and the version property value is the
     * same value assigned to a newly instantiated object, save() it
     * <li>Otherwise update() the object
     * </ul>
     *
     * @param session The Hibernate session.
     * @param entity The entity to saved or update.
     *
     * @see save
     * @see update
     */
    protected <TEntity> void saveOrUpdate(Session session, TEntity entity) {
        try {
            session.saveOrUpdate(entity);
        } catch (HibernateException e) {
            logger.error("Hibernate error while saving/updating entity", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * <p>
     * Update the persistent instance with the identifier of the given detached instance. If there is a persistent
     * instance with the same identifier, an exception is thrown. This operation cascades to associated instances if the
     * association is mapped with cascade="save-update".
     *
     * <p>
     * The difference between <code>update()</code> and <code>merge()</code> is significant: <code>update()</code> will
     * make the given object persistent and throw and error if another object with the same ID is already persistent in
     * the Session. <code>merge()</code> doesn't care if another object is already persistent, but it also doesn't make
     * the given object persistent; it just copies over the values to the data store.
     *
     * @param entity The entity to update.
     *
     * @see merge
     * @see save
     */
    public <TEntity> TEntity update(TEntity entity) {
        return update(getSession(), entity);
    }

    /**
     * <p>
     * Update the persistent instance with the identifier of the given detached instance. If there is a persistent
     * instance with the same identifier, an exception is thrown. This operation cascades to associated instances if the
     * association is mapped with cascade="save-update".
     *
     * <p>
     * The difference between <code>update()</code> and <code>merge()</code> is significant: <code>update()</code> will
     * make the given object persistent and throw and error if another object with the same ID is already persistent in
     * the Session. <code>merge()</code> doesn't care if another object is already persistent, but it also doesn't make
     * the given object persistent; it just copies over the values to the data store.
     *
     * @param session The Hibernate session.
     * @param entity The entity to update.
     *
     * @see merge
     * @see save
     */
    protected <TEntity> TEntity update(Session session, TEntity entity) {
        try {
            session.update(entity);
        } catch (HibernateException e) {
            logger.error("Hibernate error while updating entity", e);
            throw new DataAccessException(e);
        }
        return entity;
    }

    /**
     * <p>
     * Copy the state of the given object onto the persistent object with the same identifier. If there is no persistent
     * instance currently associated with the session, it will be loaded. Return the persistent instance. If the given
     * instance is unsaved, save a copy of and return it as a newly persistent instance. The given instance does not
     * become associated with the session. This operation cascades to associated instances if the association is mapped
     * with cascade="merge".
     *
     * <p>
     * The difference between <code>update()</code> and <code>merge()</code> is significant: <code>update()</code> will
     * make the given object persistent and throw and error if another object with the same ID is already persistent in
     * the Session. <code>merge()</code> doesn't care if another object is already persistent, but it also doesn't make
     * the given object persistent; it just copies over the values to the data store.
     *
     * @param entity The entity to merge.
     *
     * @see update
     */
    public <TEntity> TEntity merge(TEntity entity) {

        return merge(getSession(), entity);
    }

    /**
     * <p>
     * Copy the state of the given object onto the persistent object with the same identifier. If there is no persistent
     * instance currently associated with the session, it will be loaded. Return the persistent instance. If the given
     * instance is unsaved, save a copy of and return it as a newly persistent instance. The given instance does not
     * become associated with the session. This operation cascades to associated instances if the association is mapped
     * with cascade="merge".
     *
     * <p>
     * The difference between <code>update()</code> and <code>merge()</code> is significant: <code>update()</code> will
     * make the given object persistent and throw and error if another object with the same ID is already persistent in
     * the Session. <code>merge()</code> doesn't care if another object is already persistent, but it also doesn't make
     * the given object persistent; it just copies over the values to the data store.
     *
     * @param entity The entity to merge.
     *
     * @see update
     */
    @SuppressWarnings("unchecked")
    public <TEntity> TEntity merge(Session session, TEntity entity) {

        TEntity mergeEntity = null;
        try {
            mergeEntity = (TEntity) session.merge(entity);
        } catch (HibernateException e) {
            logger.error("Hibernate error while merging entity", e);
            throw new DataAccessException(e);
        }

        return mergeEntity;
    }

    /**
     * Remove the entity of the specified class with the specified id from the data store.
     *
     * @param entityClass The entity class.
     * @param key The key of the entity.
     *
     * @return <code>True</code> if the object is found in the data store and deleted, <code>false</code> if the item is
     *         not found.
     */
    public <TKey, TEntity> boolean deleteById(Class<TEntity> entityClass, TKey key) {

        if (key != null) {
            TEntity entity = find(entityClass, key);
            if (entity != null) {
                return delete(key, entity);
            }
        }
        return false;
    }

    /**
     * Remove the specified entities from the data store.
     *
     * @param entities The list of entities.
     */
    @SuppressWarnings("unchecked")
    public <TEntity> void deleteEntities(TEntity... entities) {

        for (TEntity entity : entities) {
            delete(entity);
        }
    }

    /**
     * Remove the specified entities Id from the data store.
     *
     * @param entityClass The entity class.
     * @param entitiesId The list of entities Id.
     *
     * @return <code>True</code> if all entities are found in the data store and deleted, <code>false</code> if any was
     *         not found or deleted.
     */
    @SuppressWarnings("unchecked")
    public <TKey, TEntity> boolean deleteEntitiesById(Class<TEntity> entityClass, TKey... entitiesId) {

        boolean allDeleted = true;
        for (TKey id : entitiesId) {
            if (id != null) {
                if (!deleteById(entityClass, id)) {
                    allDeleted = false;
                }
            }
        }

        return allDeleted;
    }

    /**
     * Remove the entity from the data store.
     *
     * @param entity The entity to delete.
     */
    public <TEntity> void delete(TEntity entity) {
        delete(getSession(), entity);
    }

    /**
     * Remove the entity from the data store.
     *
     * @param entity The entity to delete.
     */
    protected <TEntity> void delete(Session session, TEntity entity) {

        try {
            session.delete(entity);
        } catch (HibernateException e) {
            logger.error("Hibernate error while deleting entity", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Remove the entity of the specified class with the specified id and entity from the data store.
     *
     * @param key The key of the entity.
     * @param entity The entity to delete.
     *
     * @return <code>True</code> if the entity is found in the data store and deleted, <code>false</code> if not found
     *         or deleted.
     */
    protected <TKey, TEntity> boolean delete(TKey key, TEntity entity) {

        return delete(getSession(), key, entity);
    }

    /**
     * Remove the entity of the specified class with the specified id and entity from the data store.
     *
     * @param key The key of the entity.
     * @param entity The entity to delete.
     *
     * @return <code>True</code> if the entity is found in the data store and deleted, <code>false</code> if not found
     *         or deleted.
     */
    protected <TKey, TEntity> boolean delete(Session session, TKey key, TEntity entity) {

        boolean deleted = false;
        try {
            if (key != null) {
                session.delete(entity);
                deleted = true;
            }
        } catch (HibernateException e) {
            logger.error("Hibernate error while deleting entity", e);
            throw new DataAccessException(e);
        }
        return deleted;
    }

    /**
     * Return the persistent instance of the given entity class with the given key identifier, or null if there is no
     * such persistent instance.
     *
     * @param entityClass The entity class.
     * @param key The key of the entity.
     *
     * @return The entity if found, otherwise null.
     */
    public <TKey, TEntity> TEntity find(Class<TEntity> entityClass, TKey key) {
        return find(getSession(), entityClass, key);
    }

    /**
     * Return the persistent instance of the given entity class with the given key identifier, or null if there is no
     * such persistent instance.
     *
     * @param entityClass The entity class.
     * @param key The key of the entity.
     *
     * @return The entity if found, otherwise null.
     */
    @SuppressWarnings("unchecked")
    protected <TKey, TEntity> TEntity find(Session session, Class<TEntity> entityClass, TKey key) {
        TEntity result = null;
        try {
            result = (TEntity) session.get(entityClass, (Serializable) key);
        } catch (HibernateException e) {
            logger.error("Hibernate error while finding entity", e);
            throw new DataAccessException(e);
        }

        return result;
    }

    /**
     * Get a list of all the entities of the specified class type from the data store. The returned list might be null.
     *
     * @param entityClass The entity class.
     *
     * @return List of entities.
     */
    protected <TEntity> List<TEntity> findAll(Class<TEntity> entityClass) {

        return findAll(getSession(), entityClass);
    }

    /**
     * Get a list of all the entities of the specified class type from the data store. The returned list might be null.
     *
     * @param entityClass The entity class.
     *
     * @return List of entities.
     */
    @SuppressWarnings("unchecked")
    public <TEntity> List<TEntity> findAll(Session session, Class<TEntity> entityClass) {

        List<TEntity> listResult = null;
        try {
            Criteria criteria = session.createCriteria(entityClass);
            listResult = (criteria != null) ? criteria.list() : null;
        } catch (HibernateException e) {
            logger.error("Hibernate error while finding entities", e);
            throw new DataAccessException(e);
        }

        return listResult;
    }

    /**
     * Get a list of entities base on the given named query with its associated parameters. The returned list might be
     * null.
     *
     * @param name The named query.
     * @param parameters The list of parameters if any.
     *
     * @return The list of entities.
     */
    public List<?> findByNamedQuery(String name, Map<String, Object> parameters) {

        try {
            Query query = getNamedQuery(name, parameters);
            return query.list();
        } catch (HibernateException e) {
            logger.error("Hibernate error while finding entity using named query", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Get a list of entities base on the given Hibernate query with its associated parameters. The returned list might
     * be null.
     *
     * @param ql The query using Hibernate Native Query Language (HQL).
     * @param parameters The list of parameters if any.
     *
     * @return The list of entities.
     */
    public List<?> findByNativeQuery(String ql, Map<String, Object> parameters) {

        try {
            Query query = createNativeQuery(ql, parameters);
            return query.list();
        } catch (HibernateException e) {
            logger.error("Hibernate error while finding entity using native query", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Get a list of entities base on the given SQL query with its associated parameters. The returned list might be
     * null.
     *
     * @param sql The SQL query.
     * @param parameters The list of parameters if any.
     *
     * @return The list of entities.
     */
    public List<?> findBySQLQuery(String sql, Map<String, Object> parameters) {

        try {
            Query query = createSQLQuery(sql, parameters);
            return query.list();
        } catch (HibernateException e) {
            logger.error("Hibernate error while finding entity using SQL query", e);
            throw new DataAccessException(e);
        }
    }

    public <TEntity> List<?> findByExample(Class<TEntity> entityClass, TEntity example) {
        return findByExample(getSession(), entityClass, example);
    }

    protected <TEntity> List<?> findByExample(Session session, Class<TEntity> entityClass, TEntity example) {
        try {
            Example instanceExample = Example.create(example);

            // Create criteria based on the example
            Criteria criteria = session.createCriteria(entityClass).add(instanceExample);
            return criteria.list();
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a find by example", e);
            throw new DataAccessException(e);
        }
    }

    public <TEntity> List<?> findByExample(Class<TEntity> entityClass, TEntity example, int firstResult,
                                           int maxResults) {

        return findByExample(getSession(), entityClass, example, firstResult, maxResults);
    }

    protected <TEntity> List<?> findByExample(Session session, Class<TEntity> entityClass, TEntity example,
                                              int firstResult, int maxResults) {

        try {
            Example instanceExample = Example.create(example).excludeZeroes();

            // Create criteria based on the example
            Criteria criteria = session.createCriteria(entityClass).add(instanceExample);
            criteria.setFirstResult(firstResult);
            criteria.setMaxResults(maxResults);
            return criteria.list();
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a find by example", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Execute an Hibernate query (insert, update or delete) with its associated parameters.
     *
     * @param ql The query using Hibernate Native Query Language (HQL).
     * @param parameters The list of parameters if any.
     *
     * @return <code>True</code> if the execution of the query was successful and one or more rows have been modified in
     *         the data store, <code>false</code> otherwise.
     */
    public boolean executeNativeUpdate(String ql, Map<String, Object> parameters) {

        boolean queryResult = false;
        try {
            Query query = createNativeQuery(ql, parameters);
            int result = query.executeUpdate();
            queryResult = (result > 0);
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a native update", e);
            throw new DataAccessException(e);
        }

        return queryResult;
    }

    /**
     * Execute an SQL query (insert, update or delete) with its associated parameters.
     *
     * @param sql The SQL query.
     * @param parameters The list of parameters if any.
     *
     * @return <code>True</code> if the execution of the query was successful and one or more rows have been modified in
     *         the data store, <code>false</code> otherwise.
     */
    public boolean executeSQLUpdate(String sql, Map<String, Object> parameters) {

        boolean queryResult = false;
        try {
            Query query = createSQLQuery(sql, parameters);
            int result = query.executeUpdate();
            queryResult = (result > 0);
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a SQL update", e);
            throw new DataAccessException(e);
        }

        return queryResult;
    }

    protected Query getNamedQuery(String name, Map<String, Object> parameters) {
        return getNamedQuery(getSession(), name, parameters);
    }

    protected Query getNamedQuery(Session session, String name, Map<String, Object> parameters) {
        Query query = session.getNamedQuery(name);
        // If any parameters, then add it.
        if (parameters != null) {
            for (Map.Entry<String, Object> param : parameters.entrySet()) {
                query.setParameter(param.getKey(), param.getValue());
            }
        }
        return query;
    }

    protected Query createNativeQuery(String ql, Map<String, Object> parameters) {
        return createNativeQuery(getSession(), ql, parameters);
    }

    protected Query createNativeQuery(Session session, String ql, Map<String, Object> parameters) {
        Query query = session.createQuery(ql);
        // If any parameters, then add it.
        if (parameters != null) {
            for (Map.Entry<String, Object> param : parameters.entrySet()) {
                query.setParameter(param.getKey(), param.getValue());
            }
        }
        return query;
    }

    protected Query createSQLQuery(String sql, Map<String, Object> parameters) {
        return createSQLQuery(getSession(), sql, parameters);
    }

    protected Query createSQLQuery(Session session, String sql, Map<String, Object> parameters) {

        Query query = session.createSQLQuery(sql);
        // If any parameters, then add it.
        if (!CollectionUtils.isEmpty(parameters)) {
            for (Map.Entry<String, Object> param : parameters.entrySet()) {
                query.setParameter(param.getKey(), param.getValue());
            }
        }
        return query;
    }

    /**
     * Return list of entities model that match the given criteria.
     *
     * @param entityClass The entity class.
     * @param criteria The criteria.
     * @return
     *
     * @return A list of entities.
     */
    @SuppressWarnings("unchecked")
    protected <TEntity> TEntity findUniqueByCriteria(Criteria criteria) {
        try {
            return (TEntity) criteria.uniqueResult();
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a find by criteria", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Return list of entities model that match the given criteria.
     *
     * @param entityClass The entity class.
     * @param criteria The criteria.
     *
     * @return A list of entities.
     */
    @SuppressWarnings("unchecked")
    protected <TEntity> List<TEntity> findByCriteria(Criteria criteria) {

        try {
            return criteria.list();
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a find by criteria", e);
            throw new DataAccessException(e);
        }
    }

    /**
     * Return list of entities model that match the given criterion.
     *
     * @param entityClass The entity class.
     * @param criterion The list of criterion.
     *
     * @return A list of entities.
     */
    protected <TEntity> List<?> findByCriteria(Class<TEntity> entityClass, Criterion... criterion) {
        return findByCriteria(getSession(), entityClass, criterion);
    }

    @SuppressWarnings("unchecked")
    protected <TEntity> List<?> findByCriteria(Session session, Class<TEntity> entityClass, Criterion... criterion) {
        List<TEntity> listResult = null;

        try {
            Criteria crit = session.createCriteria(entityClass);
            if (criterion != null) {
                for (Criterion c : criterion) {
                    crit.add(c);
                }
                listResult = crit.list();
            }
        } catch (HibernateException e) {
            logger.error("Hibernate error while executing a find by criteria", e);
            throw new DataAccessException(e);
        }
        return listResult;
    }

    @Override
    /** @{inheritDoc} */
    public <T extends Serializable> void saveOrUpdateEntity(Class<T> entity, Object obj) {
        Objects.requireNonNull(obj);
        Session session = getSession();
        session.saveOrUpdate(entity.cast(obj));
    }

    @Override
    /** @{inheritDoc} */
    public <T extends Serializable> void saveEntity(Class<T> entity, Object obj) {
        Objects.requireNonNull(obj);
        Session session = getSession();
        session.save(entity.cast(obj));
    }
}
