package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.RegistrationRenewal;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

public interface SearchRenewalDao {

    public List<RegistrationRenewal> searchRegistrationsForRenewal(SearchRegistrationCriteria searchCriteria);
}
