package ca.gc.ic.cipo.tm.dao;

import java.util.Date;

/**
 *
 * @author Charles Hein - CIPO / OPIC
 *
 */
public interface HolidayDao {

	/**
	 * Verifies if the date falls on an holiday.
	 * @param date the date to verify
	 * @return true if it is an holiday, false otherwise.
	 */
    boolean isHoliday(Date date);

    /**
     * Gets the date that is not an holiday at or after the specified date.
     * @param date the date to verify
     * @return the date at or after the specified one that is not an holiday.
     */
    Date getOpenBusinessDate(Date date);

}
