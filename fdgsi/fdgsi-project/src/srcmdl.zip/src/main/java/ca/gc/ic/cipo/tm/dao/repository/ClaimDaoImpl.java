package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ClaimDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.ClaimId;

/**
 * The ClaimDaoImpl retrieves data from the Claim Table using Hibernate.
 *
 * @see ClaimDao
 * @see HibernateBaseDAO
 *
 * @author SeguinA3
 *
 */
@Repository("claimDao")
public class ClaimDaoImpl extends HibernateBaseDao implements ClaimDao {

    private static final long serialVersionUID = -6877797649452771965L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ClaimDaoImpl.class);

    @Override
    public List<Claim> getClaim(ApplicationNumber applicationNumber) {
        return this.getClaim(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    @Override
    public Claim getClaim(ApplicationNumber applicationNumber, Integer claimType, Integer claimNumber) {
        return this.getClaim(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(), claimType,
            claimNumber);
    }

    @Override
    public Claim getClaim(ApplicationNumber applicationNumber, ClaimId claimId) {
        return this.getClaim(applicationNumber, claimId.getClaimType(), claimId.getClaimNumber());
    }

    @Override
    public List<Claim> getClaim(Integer fileNumber, Integer extensionCounter) {
        List<Claim> claims = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(Claim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            claims = super.findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Error retrieving claim with parameters [" + fileNumber + ", " + extensionCounter + "]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return claims;
    }

    @Override
    public Claim getClaim(Integer fileNumber, Integer extensionCounter, Integer claimType, Integer claimNumber) {
        try {
            Criteria criteria = getSession().createCriteria(Claim.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_ID_CLAIM_TYPE.getValue(), claimType));
            criteria.add(Restrictions.eq(ModelPropertyType.CLAIM_ID_CLAIM_NUMBER.getValue(), claimNumber));
            return super.findUniqueByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Error retrieving claim with parameters [" + fileNumber + ", " + extensionCounter + ", "
                + claimType + ", " + claimNumber + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
    }

    @Override
    public void saveClaim(Claim claim) {
        Session session = getSession();
        session.saveOrUpdate(claim);
    }

    @Override
    public void deleteClaim(Claim claim) {
        try {
            delete(claim);
        } catch (Exception he) {
            String message = "Could not delete " + claim.toString() + " - message: " + he.getMessage();
            throw new DataAccessException(message, he);
        }
    }
}
