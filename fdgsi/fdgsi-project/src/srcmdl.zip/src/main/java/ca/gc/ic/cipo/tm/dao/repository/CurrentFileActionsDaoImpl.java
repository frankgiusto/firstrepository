package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.CurrentFileActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.CurrentFileActions;
import ca.gc.ic.cipo.tm.model.CurrentFileActionsId;
import ca.gc.ic.cipo.tm.model.PullingLists;
import ca.gc.ic.cipo.tm.model.PullingListsId;

/**
 * The CurrentFileActionsDaoImpl retrieves data from the CURRENT_FILE_ACTIONS Table using Hibernate.
 *
 * @see CurrentFileActionsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
@Repository("currentFileActionsDaoImpl")
@Deprecated
public class CurrentFileActionsDaoImpl extends HibernateBaseDao implements CurrentFileActionsDao {

    /**
     *
     */
    private static final long serialVersionUID = 912878275271879329L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(CurrentFileActionsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(Integer pullingListNumber) {
        // TODO Auto-generated method stub
        List<CurrentFileActions> currentFileActions = new ArrayList<CurrentFileActions>();
        try {
            Criteria criteria = getSession().createCriteria(CurrentFileActions.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.PULLING_LISTS_ID_PULLING_LIST_NUMBER.getValue(), pullingListNumber));
            currentFileActions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving current file actions  with parameters [" + pullingListNumber + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<CurrentFileActions>(currentFileActions);
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(Integer pullingListNumber, String receiverAuthorityId) {
        // TODO Auto-generated method stub
        List<CurrentFileActions> currentFileActions = new ArrayList<CurrentFileActions>();
        try {
            Criteria criteria = getSession().createCriteria(CurrentFileActions.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.PULLING_LISTS_ID_PULLING_LIST_NUMBER.getValue(), pullingListNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.CURRENT_FILE_ACTIONS_ID_RECEIVER_AUTHORITY_ID.getValue(),
                receiverAuthorityId));
            currentFileActions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving current file actions  with parameters [" + pullingListNumber + ", "
                + receiverAuthorityId + ", " + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<CurrentFileActions>(currentFileActions);
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(Integer pullingListNumber, String receiverAuthorityId,
                                                         String senderAuthorityId) {
        // TODO Auto-generated method stub
        List<CurrentFileActions> currentFileActions = new ArrayList<CurrentFileActions>();
        try {
            Criteria criteria = getSession().createCriteria(CurrentFileActions.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.PULLING_LISTS_ID_PULLING_LIST_NUMBER.getValue(), pullingListNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.CURRENT_FILE_ACTIONS_ID_RECEIVER_AUTHORITY_ID.getValue(),
                receiverAuthorityId));
            criteria.add(Restrictions.eq(ModelPropertyType.CURRENT_FILE_ACTIONS_ID_SENDER_AUTHORITY_ID.getValue(),
                senderAuthorityId));
            currentFileActions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving current file actions  with parameters [" + pullingListNumber + ", "
                + receiverAuthorityId + ", " + senderAuthorityId + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<CurrentFileActions>(currentFileActions);
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(PullingListsId pullingListsId) {
        // TODO Auto-generated method stub
        return this.getCurrentFileActions(pullingListsId.getPullingListNumber());
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(PullingLists pullingLists) {
        // TODO Auto-generated method stub
        return this.getCurrentFileActions(new PullingListsId(pullingLists.getFileNumber(),
            pullingLists.getExtensionCounter(), pullingLists.getWorkSheetNumber(), pullingLists.getAuthorityId(),
            pullingLists.getSectionAuthorityId(), pullingLists.getPullingListNumber()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(PullingListsId pullingListsId, String receiverAuthorityId,
                                                         String senderAuthorityId) {
        // TODO Auto-generated method stub
        return this.getCurrentFileActions(pullingListsId.getPullingListNumber(), receiverAuthorityId,
            senderAuthorityId);
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(PullingLists pullingLists, String receiverAuthorityId,
                                                         String senderAuthorityId) {
        // TODO Auto-generated method stub
        return this.getCurrentFileActions(pullingLists.getPullingListNumber(), receiverAuthorityId, senderAuthorityId);
    }

    /** {@inheritDoc} */
    @Override
    public Set<CurrentFileActions> getCurrentFileActions(PullingListsId pullingListsId,
                                                         CurrentFileActionsId currentFileActionsId) {
        // TODO Auto-generated method stub
        return this.getCurrentFileActions(pullingListsId, currentFileActionsId.getReceiverAuthorityId(),
            currentFileActionsId.getSenderAuthorityId());
    }

}
