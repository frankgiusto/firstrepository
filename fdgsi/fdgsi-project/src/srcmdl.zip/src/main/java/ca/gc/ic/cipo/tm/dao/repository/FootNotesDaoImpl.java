package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.FootNotesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.FootnoteId;

@Repository("footNotesDao")
public class FootNotesDaoImpl extends HibernateBaseDao implements FootNotesDao {

    private static final long serialVersionUID = 3278191203384467977L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(FootNotesDaoImpl.class);

    @Override
    public Set<Footnote> getFootNotes(ApplicationNumber applicationNumber) {
        List<Footnote> footnotes = new ArrayList<Footnote>();
        try {
            Criteria criteria = getSession().createCriteria(Footnote.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            footnotes = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Foot Notes for Application with parameters [" + applicationNumber.getFileNumber()
                + ", " + applicationNumber.getExtensionCounter() + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<Footnote>(footnotes);
    }

    @Override
    public Set<Footnote> getFootNotes(Application application) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getFootNotes(applicationNumber);
    }

    @Override
    public Set<Footnote> getFootNotes(ApplicationNumber applicationNumber, Integer footNoteSequence) {
        List<Footnote> footnotes = new ArrayList<Footnote>();
        try {
            Criteria criteria = getSession().createCriteria(Footnote.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.FOOTNOTE_ID_SEQUENCE_NUMBER.getValue(), footNoteSequence));
            footnotes = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Foot Notes for Application with parameters [" + applicationNumber.getFileNumber()
                + ", " + applicationNumber.getExtensionCounter() + ", " + footNoteSequence + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<Footnote>(footnotes);
    }

    @Override
    public Set<Footnote> getFootNotes(Application application, Integer footNoteSequence) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getFootNotes(applicationNumber, footNoteSequence);
    }

    @Override
    public Set<Footnote> getFootNotes(FootnoteId footNoteId) {
        ApplicationNumber applicationNumber = new ApplicationNumber(footNoteId.getFileNumber(),
            footNoteId.getExtensionCounter());
        return this.getFootNotes(applicationNumber, footNoteId.getSequenceNumber());
    }

    @Override
    public void saveFootNote(Footnote footnote) {

        Session session = getSession();
        session.saveOrUpdate(footnote);
    }

}
