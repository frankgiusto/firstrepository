/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FinancialTransactions;
import ca.gc.ic.cipo.tm.model.FinancialTransactionsId;

/**
 * @author houreich
 *
 */

public interface FinancialTransactionsDao {

    public Set<FinancialTransactions> getFinancialTransactions(Integer fileNumber, Integer extensionCounter);

    // TODO financialTransactionNumber should be the only parameter and a single object should be returned
    public Set<FinancialTransactions> getFinancialTransactions(Integer fileNumber, Integer extensionCounter,
                                                               Integer arNumber, Integer financialTransactionNumber);

    public Set<FinancialTransactions> getFinancialTransactions(ApplicationNumber applicationNumber);

    // TODO remove, using ApplicationNumber is the same
    @Deprecated
    public Set<FinancialTransactions> getFinancialTransactions(Application application);

    // TODO remove, using the financialTransactionNumber is sufficient
    @Deprecated
    public Set<FinancialTransactions> getFinancialTransactions(ApplicationNumber applicationNumber, Integer arNumber,
                                                               Integer financialTransactionNumber);

    // TODO remove, using the financialTransactionNumber is sufficient
    @Deprecated
    public Set<FinancialTransactions> getFinancialTransactions(Application application, Integer arNumber,
                                                               Integer financialTransactionNumber);

    // TODO remove applicationNumber, using the FinancialTransactionsId is sufficient, return a single object
    public Set<FinancialTransactions> getFinancialTransactions(ApplicationNumber applicationNumber,
                                                               FinancialTransactionsId transactionId);

    // get the list of Agent Representatives

    // TODO I am not sure what is the goal to achieve with this query... Is it to retrieve the agent_reps record
    // associated with a financial transaction?
    // If so, it should be implemented in the AgentRepresentativeDao instead. Not sure if using replacedBy is needed by
    // a requirement, probably you want to use the ar_number directly?
    public Set<AgentRepresentative> getAgentRepresentatives(Integer replacedBy);

    public void saveFinancialTransactions(FinancialTransactions financialTransactions);
}
