package ca.gc.ic.cipo.tm.dao.helpers;

import java.util.Arrays;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.type.IntegerType;
import org.springframework.util.StringUtils;

/**
 * Query helper utility for SearchRegRenTransactionHistory
 */
public final class SearchRegRenTransactionHistoryQueryHelper {

    /**
     * Filter registration transaction type
     */
    private static final String SEARCH_FILTER_REGISTRATION = "1";

    /**
     * Filter renewal transaction type
     */
    private static final String SEARCH_FILTER_RENEWAL = "2";

    /**
     * Filter extension of time transaction type
     */
    private static final String SEARCH_FILTER_EXT_OF_TIME = "3";

    /**
     * Valid transaction types
     */
    private static final List<String> VALID_TRANSACTION_TYPES = Arrays.asList(SEARCH_FILTER_REGISTRATION,
        SEARCH_FILTER_RENEWAL, SEARCH_FILTER_EXT_OF_TIME);

    private static final String REGISTRATION_SQL = " select ec.cipoec_tm_apltn_no as fileNumber, ec.apltn_extn_cntr as extensionCounter, "
        + " ec.prcs_stat_cd as status, "
        + " (case when length(rgs_pg_blob) > 0 then 1 else 0 end) as registrationPageExists, "
        + " (case when length(rgs_crt_blob) > 0 then 1 else 0 end) as registrationCertificateExists, "
        + " (case when length(dec_use_blob) > 0 then 1 else 0 end) as declarationOfUseExists "
        + " from {h-schema}ec_registration ec, {h-schema}regfeedecuse_history re "
        + " where ec.cipoec_srvc_itm_seq_no = re.cipoec_srvc_itm_seq_no (+) "
        + " and ec.cipoec_tm_apltn_no = :fileNumber and ec.apltn_extn_cntr = 0 "
        + " and ec.pymt_trans_no = :confirmationNumber ";

    private static final String EXTENSION_OF_TIME_SQL = " select ec.cipoec_tm_apltn_no as fileNumber, ec.apltn_extn_cntr as extensionCounter, "
        + " ec.prcs_stat_cd as status, "
        + " (case when length(ext_ntc_blob) > 0 then 1 else 0 end) as extensionOfTimeExists "
        + " from {h-schema}ec_extoftime ec, {h-schema}regfeedecuse_history re "
        + " where ec.cipoec_srvc_itm_seq_no = re.cipoec_srvc_itm_seq_no (+) "
        + " and ec.cipoec_tm_apltn_no = :fileNumber and ec.apltn_extn_cntr = 0 "
        + " and ec.pymt_trans_no = :confirmationNumber ";

    private static final String RENEWAL_SQL = " select we.file_number as fileNumber, extension_counter as extensionCounter, "
        + " we.status_code as status, "
        + " (case when length(renewal_certificate) > 0 then 1 else 0 end) as registrationCertificateExists, "
        + " (case when length(registration_page) > 0 then 1 else 0 end) as registrationPageExists, "
        + " (case when length(acknowledgement_notice) > 0 then 1 else 0 end) as renewalPageExists "
        + " from {h-schema}web_transactions we " + " where we.file_number = :fileNumber and we.extension_counter = 0 "
        + " and we.confirmation_number = :confirmationNumber ";

    private SearchRegRenTransactionHistoryQueryHelper() {
    }

    /**
     * Determines in case valid transaction type is provided; throws Exception otherwise
     *
     * @param transactionType the type of the transaction
     */
    public static void checkTransactionType(String transactionType) {
        if (!StringUtils.hasText(transactionType)) {
            throw new IllegalArgumentException(
                "Search criteria is not valid, mandatory transaction type is not provided. Expected: [Transaction type] but was: "
                    + transactionType);
        }

        if (!VALID_TRANSACTION_TYPES.contains(transactionType)) {
            throw new IllegalArgumentException(
                "Search criteria is not valid, mandatory transaction type is not provided. Expected: [Transaction type] but was: "
                    + transactionType);
        }

    }

    /**
     * Return the transaction type specific query
     *
     * @param transactionType the type of the transaction
     * @return the SQL Query string
     */
    public static String getRegRenTransactionHistoryQuery(String transactionType) {
        String query = null;
        switch (transactionType) {
            case SEARCH_FILTER_REGISTRATION:
                query = REGISTRATION_SQL;
                break;
            case SEARCH_FILTER_EXT_OF_TIME:
                query = EXTENSION_OF_TIME_SQL;
                break;

            case SEARCH_FILTER_RENEWAL:
                query = RENEWAL_SQL;
                break;

        }
        return query;
    }

    /**
     * Updates the SQLQuery object with the scalar information based on transaction type
     *
     * @param sqlQuery the SQLQuery object
     * @param transactionType the type of the transaction
     */
    public static void updateSQLQueryWithScalarInfo(SQLQuery sqlQuery, String transactionType) {
        switch (transactionType) {
            case SEARCH_FILTER_REGISTRATION:
                sqlQuery.addScalar(SearchConstants.SEARCH_FILE_NUMBER.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_EXTENSION_COUNTER.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_TRANSACTION_STATUS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_REGISTRATION_PAGE_EXISTS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_REGISTRATION_CERTIFICATE_EXISTS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_DECLARATION_OF_USE_EXISTS.getValue(), IntegerType.INSTANCE);
                break;
            case SEARCH_FILTER_EXT_OF_TIME:
                sqlQuery.addScalar(SearchConstants.SEARCH_FILE_NUMBER.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_EXTENSION_COUNTER.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_TRANSACTION_STATUS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_EXTENSION_OF_TIME_EXISTS.getValue(), IntegerType.INSTANCE);
                break;

            case SEARCH_FILTER_RENEWAL:
                sqlQuery.addScalar(SearchConstants.SEARCH_FILE_NUMBER.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_EXTENSION_COUNTER.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_TRANSACTION_STATUS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_REGISTRATION_CERTIFICATE_EXISTS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_REGISTRATION_PAGE_EXISTS.getValue(), IntegerType.INSTANCE)
                    .addScalar(SearchConstants.SEARCH_RENEWAL_PAGE_EXISTS.getValue(), IntegerType.INSTANCE);
                break;
        }
    }
}
