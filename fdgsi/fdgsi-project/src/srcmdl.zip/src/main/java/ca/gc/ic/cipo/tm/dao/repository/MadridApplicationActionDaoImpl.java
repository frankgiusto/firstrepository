/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.MadridApplicationActionDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.MadridApplicationAction;

/**
 * @author giustof
 *
 */
@Repository("madridApplicationActionDao")
public class MadridApplicationActionDaoImpl extends HibernateBaseDao implements MadridApplicationActionDao {

    /**
     *
     */
    private static final long serialVersionUID = 8301490304682620800L;

    @Override
    public List<MadridApplicationAction> getMadridApplicationActionByReferenceNumber(String referenceNumber) {

        List<MadridApplicationAction> madridApplicationActionList = new ArrayList<MadridApplicationAction>();
        try {
            Criteria criteria = getSession().createCriteria(MadridApplicationAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.MADRID_APPLICATIONS_WIPO_REFERENCE_NUMBER.getValue(),
                referenceNumber));
            madridApplicationActionList = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving Madrid Application Actions with parameters [" + referenceNumber + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return madridApplicationActionList;
    }

    @Override
    public void saveMadridApplicationAction(MadridApplicationAction madridApplicationAction) {
        Session session = getSession();
        session.saveOrUpdate(madridApplicationAction);
    }

    @Override
    public Long getNextMadridApplicationActionNumber() {
        String queryString = "select MAA_SEQUENCE.nextval from dual";
        SQLQuery query = getSessionFactory().getCurrentSession().createSQLQuery(queryString);

        BigDecimal num = (BigDecimal) query.uniqueResult();
        return num.longValue();
    }

}
