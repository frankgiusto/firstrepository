package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ReferenceTextDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ReferenceText;

/**
 * This ReferenceTextDAO implementation is used to find reference text based on a code type, a code level, and/or
 * language using Hibernate.
 *
 * @see ReferenceText
 * @see ReferenceTextDao
 * @see HibernateBaseDAO
 *
 * @author denisj1
 * @author SeguinA3 - Ported and re-factored from TDRS
 */
@Repository("referenceTextDao")
public class ReferenceTextDaoImpl extends HibernateBaseDao implements ReferenceTextDao {

    private static final long serialVersionUID = -4169021499508780284L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ReferenceTextDaoImpl.class);

    @Override
    public ReferenceText get(Integer code, Integer codeLevel, Integer language) {
        logger.debug("getRefText - Hibernate Session Id = " + getSession().hashCode() + " for [" + code + ","
            + codeLevel + "," + language + "]" + " - Object = " + this.hashCode());

        ReferenceText refText = null;

        try {
            Criteria criteria = getSession().createCriteria(ReferenceText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_TEXT_ID_CODE.getValue(), code));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_TEXT_ID_CODE_LEVEL.getValue(), codeLevel));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_TEXT_ID_LANGUAGE.getValue(), language));
            refText = (ReferenceText) criteria.uniqueResult();

        } catch (Exception ex) {
            logger.error("There are no Reference Text with parameters [" + code + ", " + codeLevel + ", " + language
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return refText;
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ReferenceText> list(Integer code) {
        logger.debug("listRefText - Hibernate Session Id = " + getSession().hashCode() + " for [" + code + "]"
            + " - Object = " + this.hashCode());
        Criteria criteria = getSession().createCriteria(ReferenceText.class);
        criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_CODE_ID_CODE_TYPE.getValue(), code));
        return criteria.list();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ReferenceText> list(Integer code, Integer language) {
        logger.debug("listRefText - Hibernate Session Id = " + getSession().hashCode() + " for [" + code + ","
            + language + "]" + " - Object = " + this.hashCode());

        List<ReferenceText> referenceTexts = new ArrayList<ReferenceText>();

        try {
            Criteria criteria = getSession().createCriteria(ReferenceText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_TEXT_ID_CODE.getValue(), code));
            criteria.add(Restrictions.eq(ModelPropertyType.REFERENCE_TEXT_ID_LANGUAGE.getValue(), language));
            referenceTexts = criteria.list();

        } catch (Exception ex) {
            logger.error(
                "There are no Reference Text with parameters [" + code + ", " + language + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return referenceTexts;
    }

}
