/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.SelectedParagraphs;
import ca.gc.ic.cipo.tm.model.SelectedParagraphsId;

// TODO not used for now
@Deprecated
public interface SelectedParagraphsDao {

    public Set<SelectedParagraphs> getSelectedParagraphs(Integer fileNumber, Integer extensionCounter,
                                                         Integer processType, Integer processCode, String authorityId);

    public Set<SelectedParagraphs> getSelectedParagraphs(Integer fileNumber, Integer extensionCounter,
                                                         Integer processType, Integer processCode, String authorityId,
                                                         Integer sequenceNumber);

    public Set<SelectedParagraphs> getSelectedParagraphs(ProcessAction processActions);

    public Set<SelectedParagraphs> getSelectedParagraphs(ProcessAction processActions, Integer sequenceNumber);

    public Set<SelectedParagraphs> getSelectedParagraphs(ProcessAction processActions,
                                                         SelectedParagraphsId selectedParagraphsId);

}
