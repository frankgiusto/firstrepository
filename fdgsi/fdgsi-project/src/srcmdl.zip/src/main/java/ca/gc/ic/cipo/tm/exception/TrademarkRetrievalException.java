package ca.gc.ic.cipo.tm.exception;

/**
 * TrademarkRetrievalException is a runtime exception implementation that 
 * is raise when a Trademarks Application or it's content cannot be retrieved, 
 * loaded or transferred.  
 *  
 * @author DenisJ1
 */
public class TrademarkRetrievalException extends RuntimeException {

    /**
	 * Unique serial ID.
	 */
	private static final long serialVersionUID = 5516328513326849526L;

	/**
     * Constructor.
     */
    public TrademarkRetrievalException() {
        super();
    }

    /**
     * Constructor.
     * 
     * @param message the message.
     */
    public TrademarkRetrievalException(final String message) {
        super(message);
    }
    
    /**
     * Constructor.
     * 
     * @param message The message.
     * @param throwable The throwable if any.
     */
    public TrademarkRetrievalException(final String message, Throwable throwable) {
        super(message, throwable);
    }
}
