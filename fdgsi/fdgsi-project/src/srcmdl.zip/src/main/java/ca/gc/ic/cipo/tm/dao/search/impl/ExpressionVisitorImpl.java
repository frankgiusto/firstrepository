package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.MatchMode;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.search.EndWithExpression;
import ca.gc.ic.cipo.tm.dao.search.EqualExpression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionVisitor;
import ca.gc.ic.cipo.tm.dao.search.InExpression;
import ca.gc.ic.cipo.tm.dao.search.LikeExpression;
import ca.gc.ic.cipo.tm.dao.search.SearchExpression;
import ca.gc.ic.cipo.tm.dao.search.StartWithExpression;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Visits the appropriate Expression objects and builds the search expression SQL (basically where clause)
 */
public class ExpressionVisitorImpl implements ExpressionVisitor {

    /** SQL to build - (where clause) */
    private final StringBuilder sb;

    /** Only AND or OR */
    private final HibernateOperatorEnum operator;

    /** Named Parameters map */
    private final Map<String, Object> parameters;

    /** Parameters list multi value map */
    private final MultiValueMap<String, Object> parameterListMap;

    public ExpressionVisitorImpl(HibernateOperatorEnum operator) {
        super();
        this.operator = operator;
        this.sb = new StringBuilder();
        this.parameters = new LinkedHashMap<>();
        this.parameterListMap = new LinkedMultiValueMap<>();
    }

    @Override
    public void visit(LikeExpression likeExpression) {
        SearchExpression searchExpression = likeExpression.getSearchExpression();
        String paramName = searchExpression.getParamName();
        String dbColumn = searchExpression.getDbColumn();
        buildOperatorString(sb);
        sb.append(" upper" + '(' + dbColumn + ')' + " like upper(" + ":" + paramName + ") ");
        parameters.put(paramName, MatchMode.ANYWHERE.toMatchString(searchExpression.getValueString()));
    }

    @Override
    public void visit(StartWithExpression startWithExpression) {
        SearchExpression searchExpression = startWithExpression.getSearchExpression();
        String paramName = searchExpression.getParamName();
        String dbColumn = searchExpression.getDbColumn();
        buildOperatorString(sb);
        sb.append(" upper" + '(' + dbColumn + ')' + " like upper(" + ":" + paramName + ") ");
        parameters.put(paramName, MatchMode.START.toMatchString(searchExpression.getValueString()));
    }

    @Override
    public void visit(EndWithExpression endWithExpression) {
        SearchExpression searchExpression = endWithExpression.getSearchExpression();
        String dbColumn = searchExpression.getDbColumn();
        String paramName = searchExpression.getParamName();
        buildOperatorString(sb);
        sb.append(" upper" + '(' + dbColumn + ')' + " like upper(" + ":" + paramName + ") ");
        parameters.put(paramName, MatchMode.END.toMatchString(searchExpression.getValueString()));

    }

    @Override
    public void visit(InExpression inExpression) {
        SearchExpression searchExpression = inExpression.getSearchExpression();
        String paramName = searchExpression.getParamName();
        String dbColumn = searchExpression.getDbColumn();
        buildOperatorString(sb);
        sb.append(dbColumn).append(" ").append("IN ( " + ":" + paramName + " )");
        List<Object> values = searchExpression.getValues();
        // Just for in expression values are handled bit differently
        if (!CollectionUtils.isEmpty(values)) {
            parameterListMap.put(paramName, values);
        }
    }

    @Override
    public void visit(EqualExpression equalExpression) {
        SearchExpression searchExpression = equalExpression.getSearchExpression();
        String paramName = searchExpression.getParamName();
        String dbColumn = searchExpression.getDbColumn();
        buildOperatorString(sb);
        sb.append(dbColumn).append(" = ").append(":" + paramName + " ");
        parameters.put(paramName, searchExpression.getValueString());
    }

    @Override
    public String toExpressionQueryString() {
        return sb.toString();
    }

    @Override
    public Map<String, Object> toParametersMap() {
        return this.parameters;
    }

    @Override
    public MultiValueMap<String, Object> toParameterListMap() {
        return parameterListMap;
    }

    private void buildOperatorString(StringBuilder sb) {
        if (operator == null) {
            throw new IllegalStateException("No operator specified: expected AND or OR ");
        }

        if (sb.length() > 0) {
            sb.append("  " + operator.getValue() + " ");
        }
    }
}
