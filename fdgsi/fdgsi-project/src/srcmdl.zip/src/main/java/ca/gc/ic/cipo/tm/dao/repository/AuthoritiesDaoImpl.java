/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AuthoritiesDao;
import ca.gc.ic.cipo.tm.model.Authorities;

/**
 * The authoritiesDaoImpl retrieves data from the AUTHORITIES Table using Hibernate.
 *
 * @see AuthoritiesDao
 * @see HibernateBaseDAO
 */
@Repository("authoritiesDao")
public class AuthoritiesDaoImpl extends HibernateBaseDao implements AuthoritiesDao {

    private static final long serialVersionUID = 8421672198316935748L;

    /** {@inheritDoc} */
    @Override
    public Authorities getAuthoritiesInformationByAuthorityUserId(String userId) {
        return super.find(Authorities.class, userId);
    }
}
