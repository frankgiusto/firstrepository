/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ProcessActionsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.ProcessActionId;

/**
 * The ProcessActionsDaoImpl retrieves data from the PROCESS_ACTIONS Table using Hibernate.
 *
 * @see ProcessActionsDao
 * @see HibernateBaseDAO
 * @author houreich, giustof - added primary key
 */
@Repository("processActionsDao")
public class ProcessActionsDaoImpl extends HibernateBaseDao implements ProcessActionsDao {

    private static final long serialVersionUID = 8822495828710293391L;

    private static final Logger logger = Logger.getLogger(ProcessActionsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<ProcessAction> getProcessActions(Integer fileNumber, Integer extensionCounter) {
        // TODO Auto-generated method stub
        List<ProcessAction> processActionsList = new ArrayList<ProcessAction>();
        try {
            Criteria criteria = getSession().createCriteria(ProcessAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            processActionsList = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving process actions with parameters [" + fileNumber + ", " + extensionCounter
                + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<ProcessAction>(processActionsList);
    }

    @Override
    public List<ProcessAction> getProcessActionsByReferenceNumber(String referenceNumber) {

        List<ProcessAction> processActionsList = new ArrayList<ProcessAction>();
        try {
            Criteria criteria = getSession().createCriteria(ProcessAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.MADRID_APPLICATIONS_WIPO_REFERENCE_NUMBER.getValue(),
                referenceNumber));
            processActionsList = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "Error retrieving process actions with parameters [" + referenceNumber + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return processActionsList;
    }

    /** {@inheritDoc} */
    @Override
    public Set<ProcessAction> getProcessActions(Integer fileNumber, Integer extensionCounter, String authorityId) {
        // TODO Auto-generated method stub
        List<ProcessAction> processActionsList = new ArrayList<ProcessAction>();
        try {
            Criteria criteria = getSession().createCriteria(ProcessAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.PROCESS_ACTIONS_ID_AUTHORITY_ID.getValue(), authorityId));

            processActionsList = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving process actions with parameters [" + fileNumber + ", " + extensionCounter
                + ", " + ", " + authorityId + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        return new HashSet<ProcessAction>(processActionsList);
    }

    /** {@inheritDoc} */
    @Override
    public Set<ProcessAction> getProcessActions(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getProcessActions(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public Set<ProcessAction> getProcessActions(ApplicationNumber applicationNumber, String authorityId) {
        // TODO Auto-generated method stub
        return this.getProcessActions(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(),
            authorityId);
    }

    /** {@inheritDoc} */
    @Override
    public Set<ProcessAction> getProcessActions(ApplicationNumber applicationNumber, ProcessActionId processActionsId) {
        // TODO Auto-generated method stub
        return this.getProcessActions(applicationNumber, processActionsId.getAuthorityId());
    }

    @Override
    public List<ProcessAction> getProcessActionsByCodes(List<Integer> processActionCodes) {

        List<ProcessAction> processActionList = null;

        Criteria criteria = getSession().createCriteria(ProcessAction.class);
        Criterion condition1 = Restrictions.isNotNull("irNumber");
        Criterion condition2 = Restrictions.isNotNull("wipoReferenceNumber");

        criteria.add(Restrictions.or(condition1, condition2));
        criteria.add(Restrictions.in("processCode", processActionCodes));

        try {
            processActionList = findByCriteria(criteria);
        } catch (HibernateException he) {
            logger.error(he);
        }
        return processActionList;
    }

    @Override
    public void saveProcessActions(ProcessAction processActions) {
        Session session = getSession();
        session.saveOrUpdate(processActions);
    }

    @Override
    public void deleteProcessAction(ProcessAction entity) {
        try {
            delete(entity);
        } catch (Exception he) {
            String message = "Could not delete " + entity.toString() + " - message: " + he.getMessage();
            throw new DataAccessException(message, he);
        }
    }

    @Override
    public ProcessAction getById(Serializable id) {
        return find(ProcessAction.class, id);
    }

    @Override
    public int getCount(Set<Integer> processCodes) {
        Session session = getSession();
        return ((Number) session.createCriteria(ProcessAction.class).add(Restrictions.in("processCode", processCodes))
            .setProjection(Projections.rowCount()).uniqueResult()).intValue();
    }
}
