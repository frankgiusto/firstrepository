/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.AgentUserXref;

/**
 * @author houreich
 *
 */
public interface AgentUserXrefDao {

    public List<AgentUserXref> getAgentUserXrefs(String userId, Integer arNumber);

}
