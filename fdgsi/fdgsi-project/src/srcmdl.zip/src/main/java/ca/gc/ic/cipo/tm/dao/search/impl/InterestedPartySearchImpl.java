package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.repository.HibernateBaseDao;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.InterestedPartySearch;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@Repository("interestedPartySearch")
public class InterestedPartySearchImpl extends HibernateBaseDao implements InterestedPartySearch {

    private static final long serialVersionUID = 1L;

    @Override
    public List<InterestedParty> searchApplicants(List<Expression> expressions, HibernateOperatorEnum searchOperator) {

        // build the query
        QueryHelper.QueryAndParams queryAndParams = InterestedPartyQueryHelper.createNativeSQLQuery(expressions,
            searchOperator);
        return executeQueryAndGet(queryAndParams);
    }

    @Override
    public List<InterestedParty> searchInterestedParties(List<Expression> expressions,
                                                         HibernateOperatorEnum searchOperator) {
        // build the query
        QueryHelper.QueryAndParams queryAndParams = InterestedPartyQueryHelper
            .createNativeSQLQueryInterestedParties(expressions, searchOperator);

        return executeQueryAndGet(queryAndParams);
    }

    private List<InterestedParty> executeQueryAndGet(QueryAndParams queryAndParams) {
        // final sql
        String finalSQL = queryAndParams.getSqlQuery();

        // map of parameter name along with the values
        Map<String, Object> paramsMap = queryAndParams.getParamsMap();

        // multi value map of parameters list (if applicable)
        MultiValueMap<String, Object> parameterListMap = queryAndParams.getParameterListMap();

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(finalSQL, paramsMap);
        QueryHelper.populateSQLQueryWithParametersListIfApplicable(parameterListMap, sqlQuery);

        @SuppressWarnings("unchecked")
        List<InterestedParty> results = sqlQuery.addEntity("IP", InterestedParty.class).list();
        return results;
    }
}
