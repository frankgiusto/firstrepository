/*
 * Copyright (c) 2019 CIPO Created on Feb 12, 2019
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.TradeMarkLock;

/**
 * Simple DAO interface for acquiring and releasing locks in the Intrepid LOCKED_TRADE_MARKS table.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
public interface TradeMarkLockDao {

    /**
     * This method will insert a row into the LOCKED_TRADE_MARKS table. A row in this table should prevent other users
     * from making changes to the file.
     *
     * @param fileNumber the file number of the trademark
     * @param extensionCounter the extension counter of the trademark (this is typically 0 for International requests)
     * @param userName the user name who is acquiring the lock (this value is not validated against any credential
     *            repository)
     * @return an object representing the lock
     */
    public TradeMarkLock acquireLock(Integer fileNumber, Integer extensionCounter, String userName);

    /**
     * This method will release any existing locks matching the required file number and extension counter. Only one
     * lock should ever exist for the combination of file number + extension counter. If no locks exist for the
     * combination this method will return <code>null</code> but this condition will not be considered an exception.
     *
     * @param fileNumber
     * @param extensionCounter
     * @return the details of the trademark lock that was released or null if none existed
     */
    public TradeMarkLock releaseLock(Integer fileNumber, Integer extensionCounter);

    /**
     * A convenience method to get a list of current locks based on one or more criteria. An error will result if no
     * criteria is provided.
     *
     * @param fileNumber [optional] the file number of the trademark
     * @param extensionCounter [optional] the extension counter
     * @param userName [optional] the user name who acquired the lock
     * @return the list of locks matching the criteria - can be empty
     */
    public List<TradeMarkLock> listLocks(Integer fileNumber, Integer extensionCounter, String userName);
}
