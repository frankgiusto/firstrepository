package ca.gc.ic.cipo.tm.exception;

public class DataAccessException extends RuntimeException {

	private static final long serialVersionUID = -2567128937059836293L;

	/**
	 * Constructor.
	 * @param message A brief description of the error
	 */
	public DataAccessException(String message) {
		super(message);
	}

	/**
	 * Constructor.
	 * @param cause the root cause of the problem
	 */
	public DataAccessException(Throwable cause) {
		super(cause);
	}	

	/**
	 * Constructor.
	 * @param message
	 * @param cause
	 */
	public DataAccessException(String message, Throwable cause) {
		super(message, cause);
	}
}
