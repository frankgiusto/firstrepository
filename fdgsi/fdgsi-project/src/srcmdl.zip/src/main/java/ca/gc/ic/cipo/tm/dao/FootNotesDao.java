package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Footnote;
import ca.gc.ic.cipo.tm.model.FootnoteId;

public interface FootNotesDao {

    /**
     * This method will retrieve the foot notes of an application
     *
     * @param applicationNumber
     * @return Collection of Footnote Objects
     */
    public Set<Footnote> getFootNotes(ApplicationNumber applicationNumber);

    /**
     * This method will retrieve the foot notes of an application base on an application object
     *
     * @param application
     * @return Collection of Footnote Objects
     */
    // TODO remove duplication using ApplicationNumber
    @Deprecated
    public Set<Footnote> getFootNotes(Application application);

    /**
     * This method will retrieve the foot notes of an application based on an application number object and a foot note
     * sequence number.
     *
     * @param applicationNumber
     * @param footNoteSequence
     * @return Collection of Footnote Objects
     */
    // TODO PK, should return single object
    public Set<Footnote> getFootNotes(ApplicationNumber applicationNumber, Integer footNoteSequence);

    /**
     * This method will retrieve the foot notes of an application based on an application object and a foot note
     * sequence number.
     *
     * @param application
     * @param footNoteSequence
     * @return Collection of Footnote Objects
     */
    // TODO remove
    @Deprecated
    public Set<Footnote> getFootNotes(Application application, Integer footNoteSequence);

    /**
     * This method will retrieve the foot notes of an application based on the foot note identifier
     *
     * @param footNoteId
     * @return Collection of Footnote Objects
     */
    // TODO, pk, should return single object
    public Set<Footnote> getFootNotes(FootnoteId footNoteId);

    /**
     * This method will save a foot note.
     *
     * @param footnote the footnote
     */
    public void saveFootNote(Footnote footnote);
}
