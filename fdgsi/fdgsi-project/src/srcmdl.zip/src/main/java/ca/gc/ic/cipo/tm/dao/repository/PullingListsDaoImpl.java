/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.PullingListsDao;

/**
 * The PullingListsDaoImpl retrieves data from the PULLING_LISTS Table using Hibernate.
 *
 * @see PullingListsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("pullingListsDaoImpl")
public class PullingListsDaoImpl extends HibernateBaseDao implements PullingListsDao {

    private static final long serialVersionUID = 4140940428447910293L;

}
