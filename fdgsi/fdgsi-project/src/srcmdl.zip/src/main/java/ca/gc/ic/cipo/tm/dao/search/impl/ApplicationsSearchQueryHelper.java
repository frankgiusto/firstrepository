package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.builders.NativeExpressionSQLBuilder;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Utility for building the applications query
 */
public final class ApplicationsSearchQueryHelper {

    private static final int MAX_RESULTS_SIZE = 100;

    private static final String MAIN_SELECT = " select * from ( ";

    private ApplicationsSearchQueryHelper() {
    }

    public static QueryAndParams createNativeSQLQuery(List<Expression> expressions,
                                                      HibernateOperatorEnum operatorEnum) {

        if (CollectionUtils.isEmpty(expressions)) {
            throw new IllegalArgumentException("Expected at least one Search Expression");
        }

        operatorEnum = Objects.requireNonNull(operatorEnum);

        StringBuilder sb = new StringBuilder();

        sb.append(MAIN_SELECT).append(" select {AP.*} from APPLICATIONS AP ");
        sb.append(" where (1=1) ");
        sb.append(" and ( ");

        NativeExpressionSQLBuilder expressionSQLBuilder = new NativeExpressionSQLBuilder.Builder(expressions,
            operatorEnum).buildQuery();

        // where clause to filter out results based on search expressions
        String expSQL = expressionSQLBuilder.toFinalSQL();

        sb.append(expSQL).append(" ) ");

        sb.append(" order by AP.FILE_NUMBER, AP.EXTENSION_COUNTER ");
        sb.append(" ) where rownum <=").append(MAX_RESULTS_SIZE);

        return new QueryHelper.QueryAndParams(sb.toString(), expressionSQLBuilder.toParametersMap(),
            expressionSQLBuilder.toParameterListMap());
    }

}
