package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.model.CountryProvince;


@Repository("englishCountryProvinceLookupDao")
public class EnglishCountryProvinceLookupDaoImpl extends
		CountryProvinceLookupDaoImpl {

	private static final long serialVersionUID = 6112241580116278889L;

	public List<CountryProvince> getCountries() {
		return super.getCountriesByLanguages(LanguageType.ENGLISH.getValue());
	}
	
	public List<CountryProvince> getProvinces() {
		return super.getProvincesByLanguages(LanguageType.ENGLISH.getValue());
	}
}
