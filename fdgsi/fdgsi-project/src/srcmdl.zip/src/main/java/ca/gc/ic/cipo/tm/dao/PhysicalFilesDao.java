/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.PhysicalFiles;

public interface PhysicalFilesDao {

    public Set<PhysicalFiles> getPhysicalFiles(Integer fileNumber, Integer fileType);

    public Set<PhysicalFiles> getPhysicalFiles(Integer fileNumber, Integer fileType, String locationAuthorityId);

    public void savePhysicalFiles(PhysicalFiles physicalFiles);
}
