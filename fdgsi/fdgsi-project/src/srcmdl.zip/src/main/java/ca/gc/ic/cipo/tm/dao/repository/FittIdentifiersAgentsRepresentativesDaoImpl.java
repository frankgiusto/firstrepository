/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.FittIdentifiersAgentsRepresentativesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.FittIdentifiersAgentsRepresentatives;
import ca.gc.ic.cipo.tm.model.FittIdentifiersAgentsRepresentativesId;

/**
 * The FittIdentifiersAgentsRepresentativesDaoImpl retrieves data from the FITT_IDENTIFIERS_AR Table using Hibernate.
 *
 * @see AgentRepresentativeActionsDaoImpl
 * @see HibernateBaseDAO
 * @author houreich
 *
 */

// TODO not used for now I think, not reviewed
@Deprecated
@Repository("fittIdentifiersAgentsRepresentativesDao")
public class FittIdentifiersAgentsRepresentativesDaoImpl extends HibernateBaseDao
    implements FittIdentifiersAgentsRepresentativesDao {

    /**
     *
     */
    private static final long serialVersionUID = -696414646392929937L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(FittIdentifiersDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiersAgentsRepresentatives> getFittIdentifiersAgentsRepresentatives(Integer arNumber) {
        // TODO Auto-generated method stub
        List<FittIdentifiersAgentsRepresentatives> fittIdentifiersAgentsRepresentatives = new ArrayList<FittIdentifiersAgentsRepresentatives>();
        try {
            Criteria criteria = getSession().createCriteria(FittIdentifiersAgentsRepresentatives.class);
            criteria.add(Restrictions.eq(ModelPropertyType.AGENT_REPRESENTATIVE_AR_NUMBER.getValue(), arNumber));
            fittIdentifiersAgentsRepresentatives = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving fitt identifiers with parameters [" + arNumber + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<FittIdentifiersAgentsRepresentatives>(fittIdentifiersAgentsRepresentatives);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiersAgentsRepresentatives> getFittIdentifiersAgentsRepresentatives(Integer arNumber,
                                                                                             String mrUID) {
        // TODO Auto-generated method stub
        List<FittIdentifiersAgentsRepresentatives> fittIdentifiersAgentsRepresentatives = new ArrayList<FittIdentifiersAgentsRepresentatives>();
        try {
            Criteria criteria = getSession().createCriteria(FittIdentifiersAgentsRepresentatives.class);
            criteria.add(Restrictions.eq(ModelPropertyType.AGENT_REPRESENTATIVE_AR_NUMBER.getValue(), arNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.FITT_IDENTIFIERS_MRUID.getValue(), mrUID));
            fittIdentifiersAgentsRepresentatives = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving fitt identifiers with parameters [" + arNumber + ", " + mrUID + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<FittIdentifiersAgentsRepresentatives>(fittIdentifiersAgentsRepresentatives);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiersAgentsRepresentatives> getFittIdentifiersAgentsRepresentatives(AgentRepresentative agentRepresentative) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiersAgentsRepresentatives(agentRepresentative.getArNumber());
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiersAgentsRepresentatives> getFittIdentifiersAgentsRepresentatives(AgentRepresentative agentRepresentative,
                                                                                             String mrUID) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiersAgentsRepresentatives(agentRepresentative.getArNumber(), mrUID);
    }

    /** {@inheritDoc} */
    @Override
    public Set<FittIdentifiersAgentsRepresentatives> getFittIdentifiersAgentsRepresentatives(AgentRepresentative agentRepresentative,
                                                                                             FittIdentifiersAgentsRepresentativesId fittIdentifiersAgentsRepresentativesId) {
        // TODO Auto-generated method stub
        return this.getFittIdentifiersAgentsRepresentatives(agentRepresentative.getArNumber(),
            fittIdentifiersAgentsRepresentativesId.getMrUID());
    }

}
