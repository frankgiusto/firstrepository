package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;

public interface WebTransactionsWaresServiceDao extends BaseDao {

}
