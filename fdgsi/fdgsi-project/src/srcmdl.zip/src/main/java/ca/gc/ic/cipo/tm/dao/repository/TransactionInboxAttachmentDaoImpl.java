package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.TransactionInboxAttachmentDao;
import ca.gc.ic.cipo.tm.enumerator.AttachmentType;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.FiledTransaction;
import ca.gc.ic.cipo.tm.model.TransactionInboxAttachment;

/**
 * This TransactionInboxAttachmentDao implementation is used to save and find transaction inbox attachment using
 * Hibernate.
 *
 * @see TransactionInboxAttachment
 * @see TransactionInboxAttachmentDAO
 * @see HibernateBaseDAO
 *
 * @author MengW
 * @author SeguinA3 - Re-factored for code consistency
 */

@Repository("transactionInboxAttachmentDao")
public class TransactionInboxAttachmentDaoImpl extends HibernateBaseDao implements TransactionInboxAttachmentDao {

    private static final long serialVersionUID = -7330857956467443436L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(TransactionInboxAttachmentDaoImpl.class);

    /**
     * Specific to CR-72 work to retrieve the Inbox attachment information
     */
    private static final String INBOX_ATTACHMENT_QUERY = " SELECT  {ta.*} from {h-schema}EC_TRANSACTION_INBOX ti inner join {h-schema}EC_TRANSACTION_INBOX_ATTCH ta  ON "
        + " ti.TRANSACTION_INBOX_SEQ_NO = ta.TRANSACTION_INBOX_SEQ_NO "
        + " WHERE ti.FILE_NUMBER = :fileNumber and ti.EXTENSION_COUNTER = :extensionCounter "
        + " AND ti.EC_REFERENCE_NUMBER = :ecReferenceNumber " + " AND ta.ATTACHMENT_TYPE = :attachmentType";

    /**
     * Query to retrieve subset of information from EC_TRANSACTION_INBOX_ATTCH table with no attachment type filtering
     */
    private static final String INBOX_ATTACHMENT_QUERY_MIN_NO_ATTACH = " select  attach.INBOX_ATTACHMENT_SEQ_NO as attachmentSeqNum, attach.ATTACHMENT_TYPE as attachmentType, attach.ATTACHMENT_FORMAT as atachmentFormat, "
        + "   attach.ATTACHMENT_FILENAME as attachmentFileName "
        + "   from EC_TRANSACTION_INBOX_ATTCH attach   where  attach.TRANSACTION_INBOX_SEQ_NO = :transactionInboxSeqNumber "
        + "   order by attach.ATTACHMENT_TYPE";

    /**
     * Query to retrieve subset of information from EC_TRANSACTION_INBOX_ATTCH table
     */
    private static final String INBOX_ATTACHMENT_QUERY_MIN = " select  attach.INBOX_ATTACHMENT_SEQ_NO as attachmentSeqNum, attach.ATTACHMENT_TYPE as attachmentType, "
        + "   attach.ATTACHMENT_FILENAME as attachmentFileName "
        + "   from EC_TRANSACTION_INBOX_ATTCH attach   where  attach.TRANSACTION_INBOX_SEQ_NO = :transactionInboxSeqNumber  and    attach.ATTACHMENT_TYPE in (:attachmentTypes) "
        + "   order by attach.ATTACHMENT_TYPE";

    /**
     * Attachment types for retrieving subset of attachments only
     */
    private static final List<Integer> ATTACHMENT_TYPES = Arrays.asList(AttachmentType.PAYMENT_RECEIPT.attachmentType(),
        AttachmentType.PDF.attachmentType());

    @Override
    /** @{inheritDoc} */
    public Map<Integer, List<TransactionInboxAttachment>> getTransactionAttachmentsMap(Integer transactionInboxSeqNumber) {
        MultiValueMap<Integer, TransactionInboxAttachment> attachmentsMap = new LinkedMultiValueMap<>();
        List<TransactionInboxAttachment> attachments = getTransactionAttachmentList(transactionInboxSeqNumber);
        if (!CollectionUtils.isEmpty(attachments)) {
            for (TransactionInboxAttachment transactionInboxAttachment : attachments) {
                attachmentsMap.add(transactionInboxAttachment.getAttachmentType(), transactionInboxAttachment);
            }
        }
        return attachmentsMap;
    }

    @Override
    /** @{inheritDoc} */
    public List<TransactionInboxAttachment> getTransactionAttachmentList(Integer transactionInboxSeqNumber) {
        try {
            Objects.requireNonNull(transactionInboxSeqNumber);
            Criteria criteria = getSession().createCriteria(TransactionInboxAttachment.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.TRANSACTION_INBOX_ATTACHMENT_TRANSACTION_INBOX_SEQ_NUM.getValue(),
                    transactionInboxSeqNumber));
            return super.findByCriteria(criteria);
        } catch (Exception ex) {
            String errorMsg = "Problem in retrieving transaction attachment for Transaction Inbox Sequence number [ "
                + transactionInboxSeqNumber + " ] " + ex.getMessage();
            LOG.error(errorMsg);
            throw new DataAccessException(errorMsg, ex);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    /** @{inheritDoc} */
    public List<TransactionInboxAttachment> getTransactionAttachmentMinimumInfoList(Integer transactionInboxSeqNumber) {
        try {
            Objects.requireNonNull(transactionInboxSeqNumber);
            Map<String, Object> params = new HashMap<>();
            params.put("transactionInboxSeqNumber", transactionInboxSeqNumber);

            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(INBOX_ATTACHMENT_QUERY_MIN, params);
            sqlQuery.setParameterList("attachmentTypes", ATTACHMENT_TYPES);

            sqlQuery.addScalar("attachmentSeqNum", IntegerType.INSTANCE);
            sqlQuery.addScalar("attachmentType", IntegerType.INSTANCE);
            sqlQuery.addScalar("attachmentFileName", StringType.INSTANCE);

            sqlQuery.setResultTransformer(Transformers.aliasToBean(TransactionInboxAttachment.class));

            return sqlQuery.list();
        } catch (Exception ex) {
            String errorMsg = "Problem in retrieving transaction attachment for Transaction Inbox Sequence number [ "
                + transactionInboxSeqNumber + " ] " + ex.getMessage();
            LOG.error(errorMsg);
            throw new DataAccessException(errorMsg, ex);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    /** @{inheritDoc} */
    public List<TransactionInboxAttachment> getAllTransactionAttachmentMinimumInfoList(Integer transactionInboxSeqNumber) {
        try {
            Objects.requireNonNull(transactionInboxSeqNumber);
            Map<String, Object> params = new HashMap<>();
            params.put("transactionInboxSeqNumber", transactionInboxSeqNumber);

            // INBOX_ATTACHMENT_QUERY_MIN_NO_ATTACH
            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(INBOX_ATTACHMENT_QUERY_MIN_NO_ATTACH, params);

            sqlQuery.addScalar("attachmentSeqNum", IntegerType.INSTANCE);
            sqlQuery.addScalar("attachmentType", IntegerType.INSTANCE);
            sqlQuery.addScalar("atachmentFormat", IntegerType.INSTANCE);
            sqlQuery.addScalar("attachmentFileName", StringType.INSTANCE);

            sqlQuery.setResultTransformer(Transformers.aliasToBean(TransactionInboxAttachment.class));

            return sqlQuery.list();
        } catch (Exception ex) {
            String errorMsg = "Problem in retrieving transaction attachment for Transaction Inbox Sequence number [ "
                + transactionInboxSeqNumber + " ] " + ex.getMessage();
            LOG.error(errorMsg);
            throw new DataAccessException(errorMsg, ex);
        }
    }

    @Override
    /** @{inheritDoc} */
    public TransactionInboxAttachment getTransactionAttachment(Integer inboxAttachmentSeqNumber) {
        TransactionInboxAttachment returnValue = null;
        long startTime = System.currentTimeMillis();
        try {
            Objects.requireNonNull(inboxAttachmentSeqNumber);
            returnValue = (TransactionInboxAttachment) super.getSession().get(TransactionInboxAttachment.class,
                inboxAttachmentSeqNumber);
        } catch (Exception ex) {
            LOG.error("Transaction Attachment [ " + inboxAttachmentSeqNumber + "] doesn't exists\n" + ex.getMessage());
            throw new DataAccessException("Transaction Attachment [ " + inboxAttachmentSeqNumber + "] doesn't exists",
                ex);
        }

        if (inboxAttachmentSeqNumber != null) {
            LOG.trace("Time to read Attachment [ " + inboxAttachmentSeqNumber + "] = "
                + (System.currentTimeMillis() - startTime) + " ms");
        }
        return returnValue;
    }

    @Override
    /** @{inheritDoc} */
    public void saveTransactionAttachment(TransactionInboxAttachment attachment) {
        Session session = getSession();
        session.saveOrUpdate(attachment);
    }

    @Override
    /** @{inheritDoc} */
    public TransactionInboxAttachment retrieveTransactionXmlBlob(FiledTransaction filedTransaction) {
        try {
            checkFiledTransaction(filedTransaction);
            Map<String, Object> params = new HashMap<>();
            params.put("fileNumber", filedTransaction.getApplicationNumber().getFileNumber());
            params.put("extensionCounter", filedTransaction.getApplicationNumber().getExtensionCounter());
            params.put("ecReferenceNumber", filedTransaction.getEcReferenceNumber());
            params.put("attachmentType", AttachmentType.XML.attachmentType());

            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(INBOX_ATTACHMENT_QUERY, params);
            sqlQuery.addEntity("ta", TransactionInboxAttachment.class);

            TransactionInboxAttachment result = (TransactionInboxAttachment) sqlQuery.uniqueResult();
            return result;
        } catch (Throwable ex) {
            String errorMsg = " Problem in retrieving transaction XML BLOB  ";
            if (filedTransaction != null && filedTransaction.getApplicationNumber() != null) {
                LOG.error(errorMsg + " for application " + filedTransaction.getApplicationNumber(), ex);
            }
            throw new DataAccessException(ex);
        }
    }

    @Override
    /** @{inheritDoc} */
    public TransactionInboxAttachment retrieveApplicationFormBlob(FiledTransaction filedTransaction) {
        try {
            Objects.requireNonNull(filedTransaction);
            Objects.requireNonNull(filedTransaction.getApplicationNumber());
            Objects.requireNonNull(filedTransaction.getEcReferenceNumber());
            Map<String, Object> params = new HashMap<>();
            params.put("fileNumber", filedTransaction.getApplicationNumber().getFileNumber());
            params.put("extensionCounter", filedTransaction.getApplicationNumber().getExtensionCounter());
            params.put("ecReferenceNumber", filedTransaction.getEcReferenceNumber());
            params.put("attachmentType", AttachmentType.PDF.attachmentType());

            SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(INBOX_ATTACHMENT_QUERY, params);
            sqlQuery.addEntity("ta", TransactionInboxAttachment.class);

            TransactionInboxAttachment result = (TransactionInboxAttachment) sqlQuery.uniqueResult();
            return result;
        } catch (Throwable ex) {
            String errorMsg = " Problem in retrieving transaction XML BLOB  ";
            if (filedTransaction != null && filedTransaction.getApplicationNumber() != null) {
                LOG.error(errorMsg + " for application " + filedTransaction.getApplicationNumber(), ex);
            }
            throw new DataAccessException(ex);
        }
    }

    private void checkFiledTransaction(FiledTransaction filedTransaction) {
        Objects.requireNonNull(filedTransaction);
        Objects.requireNonNull(filedTransaction.getApplicationNumber());
        Objects.requireNonNull(filedTransaction.getApplicationNumber().getFileNumber());
        Objects.requireNonNull(filedTransaction.getApplicationNumber().getExtensionCounter());
        Objects.requireNonNull(filedTransaction.getEcReferenceNumber());
    }
}
