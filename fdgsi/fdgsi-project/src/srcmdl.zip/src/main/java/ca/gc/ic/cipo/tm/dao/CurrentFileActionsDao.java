/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.CurrentFileActions;
import ca.gc.ic.cipo.tm.model.CurrentFileActionsId;
import ca.gc.ic.cipo.tm.model.PullingLists;
import ca.gc.ic.cipo.tm.model.PullingListsId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface CurrentFileActionsDao {

    public Set<CurrentFileActions> getCurrentFileActions(Integer pullingListNumber);

    public Set<CurrentFileActions> getCurrentFileActions(Integer pullingListNumber, String receiverAuthorityId);

    public Set<CurrentFileActions> getCurrentFileActions(Integer pullingListNumber, String receiverAuthorityId,
                                                         String senderAuthorityId);

    public Set<CurrentFileActions> getCurrentFileActions(PullingListsId pullingListsId);

    public Set<CurrentFileActions> getCurrentFileActions(PullingLists pullingLists);

    public Set<CurrentFileActions> getCurrentFileActions(PullingListsId pullingListsId, String receiverAuthorityId,
                                                         String senderAuthorityId);

    public Set<CurrentFileActions> getCurrentFileActions(PullingLists pullingLists, String receiverAuthorityId,
                                                         String senderAuthorityId);

    public Set<CurrentFileActions> getCurrentFileActions(PullingListsId pullingListsId,
                                                         CurrentFileActionsId currentFileActionsId);

}
