/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.model.FigurativeElement;

/**
 * @author giustof
 *
 */
public interface FigurativeElementsDao {

    public void saveFigurativeElement(FigurativeElement figurativeElement);

}
