package ca.gc.ic.cipo.tm.type;

import java.util.Properties;

import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.enumerator.TradeMarkType;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GenericDocumentMetadata;
import ca.gc.ic.cipo.tm.model.GiTranslationId;

/**
 * Defines the Trademark related document types.
 *
 */
// TODO remove class
@Deprecated
public enum TradeMarkDocumentType {

    DESIGN(TradeMarkType.DESIGN.getValue(), TradeMarkPropertyKey.CONTENT_PATH_DESIGNS.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // basename is file number
            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setFileNumber(Integer.parseInt(documentId));
            return applicationNumber;
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // DESIGN does not have specific custom metadata
        }

        @Override
        public String getDocumentIdFormat() {
            return "%1$07d";
        }
    },
    SOUND(TradeMarkType.SOUND.getValue(), TradeMarkPropertyKey.CONTENT_PATH_SOUNDS.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // basename is file number
            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setFileNumber(Integer.parseInt(documentId));
            return applicationNumber;
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // SOUND does not have specific custom metadata
        }

        @Override
        public String getDocumentIdFormat() {
            return "%1$07d";
        }
    },
    VIDEO(TradeMarkType.MOTION.getValue(), TradeMarkPropertyKey.CONTENT_PATH_VIDEOS.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // basename is file number
            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setFileNumber(Integer.parseInt(documentId));
            return applicationNumber;
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // Video does not have specific custom metadata
        }

        @Override
        public String getDocumentIdFormat() {
            return "%1$07d";
        }
    },
    WORD(TradeMarkType.WORD.getValue(), TradeMarkPropertyKey.CONTENT_PATH_WORD.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub
            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub
            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub
            throw new java.lang.UnsupportedOperationException();
        }
    },
    TEXT(TradeMarkType.STANDARD_CHARACTERS.getValue(), TradeMarkPropertyKey.CONTENT_PATH_STANDARD_CHARACTER
        .getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub
            throw new java.lang.UnsupportedOperationException();
        }
    },
    COLOR(TradeMarkType.COLOR.getValue(), TradeMarkPropertyKey.CONTENT_PATH_COLOR.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    THREE_DIMENSIONAL(TradeMarkType.THREE_DIMENSIONAL.getValue(), TradeMarkPropertyKey.CONTENT_PATH_THREE_DIMENSIONAL
        .getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    HOLOGRAM(TradeMarkType.HOLOGRAM.getValue(), TradeMarkPropertyKey.CONTENT_PATH_HOLOGRAM.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    MOTION(TradeMarkType.MOTION.getValue(), TradeMarkPropertyKey.CONTENT_PATH_MOTION.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    PACKAGING_GOOD(TradeMarkType.PACKAGING_GOOD.getValue(), TradeMarkPropertyKey.CONTENT_PATH_PACKAGING_GOODS
        .getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    POSITIONAL(TradeMarkType.POSITIONAL.getValue(), TradeMarkPropertyKey.CONTENT_PATH_POSITIONAL.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    TASTE(TradeMarkType.TASTE.getValue(), TradeMarkPropertyKey.CONTENT_PATH_TASTE.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    SCENT(TradeMarkType.SCENT.getValue(), TradeMarkPropertyKey.CONTENT_PATH_SCENT.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    TEXTURE(TradeMarkType.TEXTURE.getValue(), TradeMarkPropertyKey.CONTENT_PATH_TEXTURE.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }

        @Override
        public String getDocumentIdFormat() {
            // TODO Auto-generated method stub

            throw new java.lang.UnsupportedOperationException();
        }
    },
    GI_TRANSLATION(Integer.valueOf(800), TradeMarkPropertyKey.CONTENT_PATH_GI.getValue()) {

        @Override
        public ApplicationNumber getAppNumber(String documentId) {
            // basename is [file number]-[extension]-[sequence]
            GiTranslationId giTranslationId = new GiTranslationId();
            String[] numbers = documentId.split("-");
            if (numbers.length != 3) {
                throw new IllegalArgumentException(
                    "DocumentId [" + documentId + "] is an invalid GI document id, format xxxxxxx-xx-xx is expected.");
            }

            giTranslationId.setFileNumber(Integer.valueOf(numbers[0]));
            giTranslationId.setExtensionCounter(Integer.valueOf(numbers[1]));
            giTranslationId.setSequenceNumber(Integer.valueOf(numbers[2]));
            return giTranslationId;
        }

        /**
         * For Gis, we need an extra extension counter and sequence number to identify the document
         */
        @Override
        public void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId) {
            GiTranslationId giTranslationId = (GiTranslationId) getAppNumber(documentId);
            metadata.addCustomMetadata(ModelPropertyType.TRADE_MARK_FILE_NUMBER.getValue(),
                giTranslationId.getExtensionCounter());
            metadata.addCustomMetadata(ModelPropertyType.GI_SEQUENCE_NUMBER.getValue(),
                giTranslationId.getSequenceNumber());

        }

        @Override
        public String getDocumentIdFormat() {
            return "%1$07d-%2$02d-%3$02d";
        }

    };

    /** The document type value - business meaning. */
    private final Integer value;

    /** The default path where the document is stored. */
    private final String path;

    private TradeMarkDocumentType(Integer value, String path) {
        this.value = value;
        this.path = path;
    }

    public Integer getValue() {
        return value;
    }

    public String getPath() {
        return this.path;
    }

    public String getPath(Properties property) {
        return property.getProperty(path);
    }

    public static TradeMarkDocumentType getValueOf(Integer value) {
        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null");
        }
        for (TradeMarkDocumentType type : values()) {
            if (value.equals(type.getValue())) {
                return type;
            }
        }
        throw new IllegalArgumentException("Trademark document type not found for undefined value = " + value);
    }

    /**
     * Build a new application number (or an application number descendant) using the document id (basename)
     *
     * @param documentId Corresponds to the basename
     */
    public abstract ApplicationNumber getAppNumber(String documentId);

    /**
     * @param metadata The metadata to update
     * @param documentId The document id to build specific metadata
     */
    public abstract void addDocIdCustomMetaData(GenericDocumentMetadata metadata, String documentId);

    /**
     *
     * @return The document id (basename, i.e. filename without the extension) of the Trademark Document format
     */
    public abstract String getDocumentIdFormat();
}
