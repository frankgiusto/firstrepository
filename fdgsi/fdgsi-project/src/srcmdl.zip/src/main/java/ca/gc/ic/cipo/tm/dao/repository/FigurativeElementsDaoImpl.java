/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.FigurativeElementsDao;
import ca.gc.ic.cipo.tm.model.FigurativeElement;

/**
 * @author giustof Dao implementation methods for FIGURATIVE_ELEMENTS table.
 *
 * @see HibernateBaseDAO
 */

@Repository("figurativeElementsDao")
public class FigurativeElementsDaoImpl extends HibernateBaseDao implements FigurativeElementsDao {

    /**
     *
     */
    private static final long serialVersionUID = 1244705750491001791L;

    @Override
    public void saveFigurativeElement(FigurativeElement figurativeElement) {
        Session session = getSession();
        session.saveOrUpdate(figurativeElement);
    }

}
