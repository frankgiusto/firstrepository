package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Claim;
import ca.gc.ic.cipo.tm.model.ClaimId;

public interface ClaimDao {

    /**
     * Gets the claim.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @return the claim
     */
    public List<Claim> getClaim(Integer fileNumber, Integer extensionCounter);

    /**
     * Gets the claim.
     *
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @param claimType the claim type
     * @param claimNumber the claim number
     * @return the claim
     */
    public Claim getClaim(Integer fileNumber, Integer extensionCounter, Integer claimType, Integer claimNumber);

    /**
     * Gets the claim.
     *
     * @param applicationNumber the application number
     * @return the claim
     */
    public List<Claim> getClaim(ApplicationNumber applicationNumber);

    /**
     * Gets the claim.
     *
     * @param applicationNumber the application number
     * @param claimType the claim type
     * @param claimNumber the claim number
     * @return the claim
     */
    public Claim getClaim(ApplicationNumber applicationNumber, Integer claimType, Integer claimNumber);

    /**
     * Gets the claim.
     *
     * @param applicationNumber the application number
     * @param claimId the claim id
     * @return the claim
     */
    public Claim getClaim(ApplicationNumber applicationNumber, ClaimId claimId);

    /**
     * Save claim.
     *
     * @param claim the claim
     */
    public void saveClaim(Claim claim);

    /**
     * Delete claim.
     *
     * @param claim the claim
     */
    public void deleteClaim(Claim claim);
}
