package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.OppositionActionCodes;

/**
 * @author duanj
 *
 */
public interface OppositionActionCodesDao extends BaseDao {

    /**
     * Gets an OppositionActionCodes object with given codes
     *
     * @param oppStageCode
     * @param oppActionCode
     * @param oppActionType
     *
     * @return
     */
    public OppositionActionCodes getOppositionActionCodes(Integer oppStageCode, Integer oppActionCode,
                                                          Integer oppActionType);

}
