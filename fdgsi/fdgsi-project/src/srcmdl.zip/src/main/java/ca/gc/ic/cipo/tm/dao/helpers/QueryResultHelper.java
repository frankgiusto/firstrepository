package ca.gc.ic.cipo.tm.dao.helpers;

import java.util.List;

import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.Pair;
import ca.gc.ic.cipo.tm.model.GoodServiceClaim;

/**
 * Sample utility for post processing query results
 */
public final class QueryResultHelper {

    private QueryResultHelper() {
    }

    /**
     * Places the goods and services into multi-value map by claim type and claim number ordering
     *
     * @param goodServiceClaims the list of GoodServiceClaims
     * @return the MultiValueMap of key of type and value of type GoodServiceClaim
     */
    public static MultiValueMap<Pair<Integer, Integer>, GoodServiceClaim> toOrderedMultiValueList(List<GoodServiceClaim> goodServiceClaims) {
        MultiValueMap<Pair<Integer, Integer>, GoodServiceClaim> results = new LinkedMultiValueMap<>();
        if (!CollectionUtils.isEmpty(goodServiceClaims)) {
            for (GoodServiceClaim eachGoodServiceClaim : goodServiceClaims) {
                results.add(new Pair<>(eachGoodServiceClaim.getClaimType(), eachGoodServiceClaim.getClaimNumber()),
                    eachGoodServiceClaim);
            }
        }
        return results;
    }
}
