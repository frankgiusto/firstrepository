package ca.gc.ic.cipo.tm.dao.search;

import java.util.List;

import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Interface for providing search on AGENT_REPS. Utilizes the Expression objects and builds a native SQL
 */
public interface AgentSearch {

    public List<AgentRepresentative> searchAgents(List<Expression> expressions, HibernateOperatorEnum searchOperator);

    List<String> getAgentEmailAddresses(List<Expression> expressions, HibernateOperatorEnum searchOperator);
}
