package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ActionDao;
import ca.gc.ic.cipo.tm.enumerator.ActionCode;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Action;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;

/**
 * The ActionDaoImpl retrieves data from the Action Table using Hibernate. Note: Updates are not allowed in Actions
 * table. This table has a history of no primary key and it will remain that way. For update please do a select followed
 * by an insert.
 *
 * The saveAction method uses non hibernate way to insert the record into the table. For update please do a select first
 * and then followed by Insert. For retrieval use Hibernate. Please see the mapping details of the table:
 * /tm-model-dao/src/main/resources/mapping/Action.hbm.xml
 *
 * Oracle ROWID has been added to the mapping which helps in retrieval of the rows from the DB to guarantee uniqueness.
 *
 * @see ActionDao
 * @see HibernateBaseDAO
 * @author SeguinA3
 */
@Repository("actionDao")
public class ActionDaoImpl extends HibernateBaseDao implements ActionDao {

    private static final long serialVersionUID = 3708335624770579742L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ActionDaoImpl.class);

    private static final String CHECK_ACTION_CODE_SQL = " select 1 as found from ACTIONS a1 where a1.FILE_NUMBER = :fileNumber and a1.EXTENSION_COUNTER = :extCounter "
        + " and a1.ACTION_CODE = :actionCode_70 and not exists (select 1 from ACTIONS a2 "
        + " where a2.FILE_NUMBER = a1.FILE_NUMBER and a2.EXTENSION_COUNTER = a1.EXTENSION_COUNTER"
        + " and a2.ACTION_CODE = :actionCode_71 and a2.ACTION_DATE >= a1.ACTION_DATE)";

    private static final String CHECK_ADJUSTED_FEE_RECEIVED_SQL = "select count(*) as found " + "from ACTIONS ac "
        + "where ac.file_number = :fileNumber " + "and ac.extension_counter = :extensionCounter "
        // Adjustment requested
        + "and ac.action_code = 178 " + "and ac.action_date = ( "
        // Latest adjustment requested
        + "select max(action_date) " + "from actions " + "where action_code = 178 "
        + "and file_number = ac.file_number " + "and extension_counter = ac.extension_counter " + " ) "
        + "and exists ( "
        // Adustment received after last adjustment request
        + "select *  " + "from ACTIONS " + "where action_code = 179 " + "and file_number = ac.file_number "
        + "and extension_counter = ac.extension_counter " + "and action_date >= ac.action_date " + " ) ";

    private static final String ADVERTISED_DATE_SQL = " select ADD_MONTHS(MAX(a.ACTION_DATE),2) as END_ADVERTISED_DATE from ACTIONS a where a.FILE_NUMBER = :fileNumber "
        + " and a.EXTENSION_COUNTER = :extensionCounter and a.ACTION_CODE in ( ";

    private static final String GET_ACTIONS_ON_AFTER_SQL = "select a1.FILE_NUMBER as fileNumber,a1.EXTENSION_COUNTER as extensionCounter, "
        + "a1.ACTION_CODE as actionCode, a1.ACTION_DATE as actionDate, "
        + "a1.AUTHORITY_ID as authorityId, a1.PERFORMED_BY_AUTHORITY_ID as performedByAuthorityId, "
        + "a1.RESPONSE_DATE as responseDate,a1.ADDITIONAL_INFO as additionalInfo from ACTIONS a1 "

        + " where a1.FILE_NUMBER = :applicationNumber and a1.EXTENSION_COUNTER = :extensionCounter"
        + " and exists (select 1 from ACTIONS a2"
        + " where a1.FILE_NUMBER = a2.FILE_NUMBER and a1.EXTENSION_COUNTER = a2.EXTENSION_COUNTER"
        + " and a2.ACTION_CODE = 50"

        + " and not exists (select 1 from ACTIONS a3 where a3.FILE_NUMBER = a2.FILE_NUMBER and a3.EXTENSION_COUNTER = a2.EXTENSION_COUNTER"
        + " and a3.ACTION_CODE = 52" + " and a3.ACTION_DATE >= a2.ACTION_DATE ))"

        + " and a1.ACTION_DATE >= (select max(ACTION_DATE) from ACTIONS a2"
        + " where a1.FILE_NUMBER = a2.FILE_NUMBER and a1.EXTENSION_COUNTER = a2.EXTENSION_COUNTER"
        + " and a2.ACTION_CODE = 50)" + " and a1.ACTION_CODE != 50" + " order by a1.ACTION_DATE";

    private static final String INSERT_SQL = "INSERT INTO ACTIONS (FILE_NUMBER,EXTENSION_COUNTER,ACTION_CODE,ACTION_DATE,AUTHORITY_ID,PERFORMED_BY_AUTHORITY_ID,RESPONSE_DATE,ADDITIONAL_INFO) values (:file_number,:extension_counter,:action_code,:action_date,:authority_id,:performed_by_authority_id,:response_date,:additional_info)";

    private static final List<ActionCode> ADVERTIED_ACTIONS;
    static {
        ADVERTIED_ACTIONS = new ArrayList<>(2);
        ADVERTIED_ACTIONS.add(ActionCode.ADVERTISED);
        ADVERTIED_ACTIONS.add(ActionCode.RE_ADVERTISED);
    }

    @Override
    public List<Action> getActions(Integer fileNumber, Integer extensionCounter) {
        return this.getActions(new ApplicationNumber(fileNumber, extensionCounter));
    }

    @Override
    public List<Action> getActions(ApplicationNumber applicationNumber) {
        List<Action> actions = Collections.<Action> emptyList();
        if (applicationNumber == null || applicationNumber.getFileNumber() == null
            || applicationNumber.getFileNumber() < 0) {
            // return empty list
            return actions;
        }

        try {
            Criteria criteria = getSession().createCriteria(Action.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            actions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return actions;
    }

    @Override
    public void saveAction(Action action) {
        Objects.requireNonNull(action);
        checkNotNullFields(action);
        getSession().flush();
        Query query = getSession().createSQLQuery(INSERT_SQL);
        query.setParameter("file_number", action.getFileNumber(), IntegerType.INSTANCE);
        query.setParameter("extension_counter", action.getExtensionCounter(), IntegerType.INSTANCE);
        query.setParameter("action_code", action.getActionCode(), IntegerType.INSTANCE);

        // action date
        query.setParameter("action_date", action.getActionDate(), TimestampType.INSTANCE);

        // response date
        query.setParameter("response_date", action.getResponseDate(), TimestampType.INSTANCE);

        // authority id
        query.setParameter("authority_id", action.getAuthorityId(), StringType.INSTANCE);

        // following are nullable fields
        query.setParameter("performed_by_authority_id", action.getPerformedByAuthorityId(), StringType.INSTANCE);

        // additional info
        query.setParameter("additional_info", action.getAdditionalInfo(), StringType.INSTANCE);
        query.executeUpdate();
    }

    private void checkNotNullFields(Action action) {
        Objects.requireNonNull(action, "Expected Action to be not null but was " + action);
        checkFileNumber(action.getFileNumber());
        checkExtCounter(action.getExtensionCounter());
        checkActionCode(action.getActionCode());
        checkActionDate(action.getActionDate());
        checkAuthorityId(action.getAuthorityId());
    }

    private void checkFileNumber(Integer fileNumber) {
        Objects.requireNonNull(fileNumber, "Expected non null file number but was " + fileNumber);

        if (fileNumber <= 0) {
            throw new RuntimeException("Expected <<FILE NUMBER>> greater than 0 but was " + fileNumber);
        }
    }

    private void checkExtCounter(Integer extCounter) {
        Objects.requireNonNull(extCounter, "Expected non null <<EXTENSION COUNTER>> but was " + extCounter);
    }

    private void checkActionCode(Integer actionCode) {
        Objects.requireNonNull(actionCode == null, "Expected non null <<ACTION CODE>> but was " + actionCode);
    }

    private void checkActionDate(Date actionDate) {
        Objects.requireNonNull(actionDate, "Expected non null <<ACTION>> Date but was " + actionDate);
    }

    private void checkAuthorityId(String authorityId) {
        Objects.requireNonNull(authorityId, "Expected non null <<AUTHORITY_ID>> but was " + authorityId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Action> getActionsOnOrAfterAllowed(Integer fileNumber, Integer extensionCounter) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("applicationNumber", fileNumber);
        parameters.put("extensionCounter", extensionCounter);
        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(GET_ACTIONS_ON_AFTER_SQL, parameters);
        sqlQuery.addScalar("fileNumber", IntegerType.INSTANCE);
        sqlQuery.addScalar("extensionCounter", IntegerType.INSTANCE);
        sqlQuery.addScalar("actionCode", IntegerType.INSTANCE);
        sqlQuery.addScalar("actionDate", DateType.INSTANCE);
        sqlQuery.addScalar("authorityId", StringType.INSTANCE);
        sqlQuery.addScalar("performedByAuthorityId", StringType.INSTANCE);
        sqlQuery.addScalar("responseDate", DateType.INSTANCE);
        sqlQuery.addScalar("additionalInfo", StringType.INSTANCE);
        sqlQuery.setResultTransformer(Transformers.aliasToBean(Action.class));
        return sqlQuery.list();
    } // End of the getActionsOnOrAfterAllowed method.

    @Override
    public boolean isOpposedActionRecordNotFound(ApplicationNumber applicationNumber, ActionCode actionCode) {
        Map<String, Object> params = new HashMap<>();
        params.put("fileNumber", applicationNumber.getFileNumber());
        params.put("extCounter", applicationNumber.getExtensionCounter());
        params.put("actionCode_70", actionCode.getValue());
        params.put("actionCode_71", ActionCode.OPPOSITION_REMOVED.getValue());

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(CHECK_ACTION_CODE_SQL, params);
        sqlQuery.addScalar("found", IntegerType.INSTANCE);

        Integer result = (Integer) sqlQuery.uniqueResult();
        return (result == null);
    }

    @Override
    public Date getEndOfAdvertisedDate(ApplicationNumber applicationNumber) {
        String finalSQL = ADVERTISED_DATE_SQL + " " + buildActionCodesString(ADVERTIED_ACTIONS) + " ) ";
        Map<String, Object> params = new HashMap<>();
        params.put("fileNumber", applicationNumber.getFileNumber());
        params.put("extensionCounter", applicationNumber.getExtensionCounter());

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(finalSQL, params);
        sqlQuery.addScalar("END_ADVERTISED_DATE", DateType.INSTANCE);
        Date result = (Date) sqlQuery.uniqueResult();
        return result;
    }

    private String buildActionCodesString(List<ActionCode> actionCodes) {
        StringBuilder sb = new StringBuilder();
        Iterator<ActionCode> iter = actionCodes.iterator();
        while (iter.hasNext()) {
            sb.append(iter.next().getValue());
            if (iter.hasNext()) {
                sb.append(",");
            }
        }
        return sb.toString();
    }

    @Override
    public boolean isAdjustedRenewalFeeReceived(ApplicationNumber applicationNumber) {
        return doCheckifAdjustedRenewalFeeProcessed(applicationNumber);
    }

    private boolean doCheckifAdjustedRenewalFeeProcessed(ApplicationNumber applicationNumber) {
        Objects.requireNonNull(applicationNumber);
        Map<String, Object> params = new HashMap<>();
        params.put("fileNumber", applicationNumber.getFileNumber());
        params.put("extensionCounter", applicationNumber.getExtensionCounter());
        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(CHECK_ADJUSTED_FEE_RECEIVED_SQL, params);
        sqlQuery.addScalar("found", IntegerType.INSTANCE);

        Integer result = (Integer) sqlQuery.uniqueResult();

        return (result.intValue() > 0);
    }
}
