package ca.gc.ic.cipo.tm.type;

import javax.activation.MimetypesFileTypeMap;

/**
 * A customize implementation of MIME types to file extension mappings for Trademark Feature using a standard
 * <code>MimetypesFileTypeMap</code> underneath.
 *
 * <p>
 * By default, the mappings used by JavaX Activation Framework read the <code>mimetypes.default</code> file located on
 * the class path.
 *
 * <p>
 * Additional mappings can be added via the command addMimeTypes.
 *
 * @author denisj1
 * @see javax.activation.MimetypesFileTypeMap
 */
// TODO remove class
@Deprecated
public class TradeMarkDocumentMimeType extends MimetypesFileTypeMap {

    public TradeMarkDocumentMimeType() {

        // Make sure the following list of MIME types exists.
        // If already exists, they will be overridden.

        // Add text Mime Types.
        addMimeTypes("text/plain txt text TXT TEXT");

        // Add applications Mime Types.
        addMimeTypes("application/pdf pdf");

        // Add Images Mime Types.
        addMimeTypes("image/gif	gif GIF");
        addMimeTypes("image/jpeg jpeg jpg jpe JPG");
        addMimeTypes("image/tiff tiff tif");
        addMimeTypes("image/x-png png");

        // Add Audio Mime Types.
        addMimeTypes("audio/x-wav wav");
        addMimeTypes("audio/mpeg mp3");

        // Add Videos Mime Types.
        addMimeTypes("video/x-msvideo avi");
        addMimeTypes("video/x-ms-wmv wmv");
        addMimeTypes("video/mpeg mpeg mpg mpe");
        addMimeTypes("video/quicktime qt mov");
    }
}
