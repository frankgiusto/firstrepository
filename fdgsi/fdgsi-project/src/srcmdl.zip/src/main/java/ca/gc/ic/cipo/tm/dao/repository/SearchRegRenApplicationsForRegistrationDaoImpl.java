package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.SearchRegRenApplicationsForRegistrationDao;
import ca.gc.ic.cipo.tm.dao.helpers.SearchApplicationsQueryHelper;
import ca.gc.ic.cipo.tm.model.RegfeedecuseAllowed;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Implementation for SearchRegRenApplicationsForRegistrationDao interface
 */
@Repository("searchRegRenApplicationsForRegistrationDao")
public class SearchRegRenApplicationsForRegistrationDaoImpl extends HibernateBaseDao
    implements SearchRegRenApplicationsForRegistrationDao {

    private static final long serialVersionUID = 1L;

    @Override
    public List<RegfeedecuseAllowed> searchApplicationsForRegistration(SearchRegistrationCriteria searchCriteria) {
        return doSearchApplicationsForRegistration(searchCriteria);
    }

    private List<RegfeedecuseAllowed> doSearchApplicationsForRegistration(SearchRegistrationCriteria searchCriteria) {

        if (searchCriteria == null) {
            throw new IllegalArgumentException("Search criteria must not be null");
        }

        if (noSearchParametersProvided(searchCriteria)) {
            throw new IllegalArgumentException("Search criteria must not be empty or null");
        }

        if (searchCriteria.getMaxResults() <= 0) {
            throw new IllegalArgumentException(
                "Results size expected: greater than 0 - but was " + searchCriteria.getMaxResults());
        }

        SearchApplicationsQueryHelper queryHelper = new SearchApplicationsQueryHelper();
        String sql = queryHelper.buildQuery(searchCriteria);

        Map<String, Object> parameters = new HashMap<>();

        if (searchCriteria.getApplicationNumber() != null) {
            if (searchCriteria.getApplicationNumber().getFileNumber() != null) {
                parameters.put("fileNumber", searchCriteria.getApplicationNumber().getFileNumber());
            }
            if (searchCriteria.getApplicationNumber().getExtensionCounter() != null) {
                parameters.put("extensionCounter", searchCriteria.getApplicationNumber().getExtensionCounter());
            }
        }

        // applicant name
        if (StringUtils.hasText(searchCriteria.getApplicantName())) {
            parameters.put("ownerName", "%" + searchCriteria.getApplicantName() + "%");
        }

        // trademark name
        if (StringUtils.hasText(searchCriteria.getTrademarkName())) {
            parameters.put("tmText", "%" + searchCriteria.getTrademarkName() + "%");
        }

        // requestor user id
        if (StringUtils.hasText(searchCriteria.getRequestorUserId())) {
            parameters.put("requestorUserId", searchCriteria.getRequestorUserId());
        }

        // max results
        if (searchCriteria.getMaxResults() != null) {
            parameters.put("rowNum", searchCriteria.getMaxResults());
        }

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(sql, parameters);

        if (!CollectionUtils.isEmpty(searchCriteria.getAgentNumbers())) {
            // agent number
            sqlQuery.setParameterList("agentNumbers", searchCriteria.getAgentNumbers());

            // start date filter
            if (searchCriteria.getStartDate() != null) {
                sqlQuery.setDate("startDate", searchCriteria.getStartDate());
            }
            // end date filter
            if (searchCriteria.getEndDate() != null) {
                sqlQuery.setDate("endDate", searchCriteria.getEndDate());
            }
        }

        sqlQuery.addEntity("rr", RegfeedecuseAllowed.class);

        @SuppressWarnings("unchecked")
        List<RegfeedecuseAllowed> results = sqlQuery.list();
        return results;
    }

    /**
     * Checks if any of the search parameters are provided
     */
    private boolean noSearchParametersProvided(SearchRegistrationCriteria searchCriteria) {
        return (((searchCriteria.getApplicationNumber() == null
            || searchCriteria.getApplicationNumber().getFileNumber() == null
                && searchCriteria.getApplicationNumber().getExtensionCounter() == null)
            && !StringUtils.hasText(searchCriteria.getTrademarkName())
            && !StringUtils.hasText(searchCriteria.getApplicantName())
            && !StringUtils.hasText(searchCriteria.getRequestorUserId())
            && (CollectionUtils.isEmpty(searchCriteria.getAgentNumbers())) && searchCriteria.getStartDate() == null
            && searchCriteria.getEndDate() == null));
    }
}
