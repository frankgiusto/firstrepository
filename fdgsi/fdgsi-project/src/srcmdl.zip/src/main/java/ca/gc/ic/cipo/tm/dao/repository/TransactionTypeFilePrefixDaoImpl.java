package ca.gc.ic.cipo.tm.dao.repository;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.TransactionTypeFilePrefixDao;
import ca.gc.ic.cipo.tm.model.TransactionTypeFilePrefix;

/**
 * Implementation for TransactionTypeFilePrefixDao interface
 */
@Repository("transactionTypeFilePrefixDao")
public class TransactionTypeFilePrefixDaoImpl extends HibernateBaseDao implements TransactionTypeFilePrefixDao {

    private static final long serialVersionUID = -9212449443373518806L;

    @Override
    public TransactionTypeFilePrefix getTransactionTypeFilePrefix(Integer transactionType) {
        return super.find(TransactionTypeFilePrefix.class, transactionType);
    }
}
