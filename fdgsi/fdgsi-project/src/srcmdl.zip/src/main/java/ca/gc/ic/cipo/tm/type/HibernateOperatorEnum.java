package ca.gc.ic.cipo.tm.type;

public enum HibernateOperatorEnum {

    /** Equal = */
    EQUAL("eq"),

    /** Not Equal <> */
    NOT_EQUAL("ne"),

    /** Greater than > */
    GREATER_THAN("gt"),

    /** Less than < */
    LESS_THAN("lt"),

    /** Greater than or equal to >= */
    GREATER_THAN_OR_EQUAL_TO("ge"),

    /** Less than or equal to <= */
    LESS_THAN_OR_EQUAL_TO("le"),

    /** Between */
    BETWEEN("between"),

    /** like */
    LIKE("like"),

    /** IN */
    IN("in"),

    /** is null */
    IS_NULL("isNull"),

    /** is not null */
    IS_NOT_NULL("isNotNull"),

    /** Starts with */
    START_WITH("start_with"),

    /** Ends with */
    END_WITH("end_with"),

    /** AND */
    AND("and"),

    /** OR */
    OR("or"),

    /** NOT */
    NOT("not");

    private String value;

    private HibernateOperatorEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public Boolean isEqualTo(HibernateOperatorEnum operator) {
        return (this.value == operator.getValue());
    }
}
