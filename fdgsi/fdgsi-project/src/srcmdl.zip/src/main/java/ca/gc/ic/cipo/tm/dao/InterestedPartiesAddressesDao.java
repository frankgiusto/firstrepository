/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.InterestedPartiesAddresses;

/**
 * @author houreich
 */
public interface InterestedPartiesAddressesDao {

    public List<InterestedPartiesAddresses> getInterestedPartiesAddresses(Integer fileNumber, Integer extensionCounter,
                                                                          Integer ipNumber);

    public void saveInterestedPartiesAddresses(InterestedPartiesAddresses interestedPartiesAddresses);

}
