package ca.gc.ic.cipo.tm.dao.search.builders;

import java.util.List;
import java.util.Map;

import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.ExpressionVisitor;
import ca.gc.ic.cipo.tm.dao.search.impl.ExpressionVisitorImpl;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Native query builder - for where clause SQL.
 *
 * @see ca.gc.ic.cipo.tm.dao.search.impl.ExpressionVisitorImpl.ExpressionVisitorImpl
 */
public class NativeExpressionSQLBuilder {

    /**
     * The final SQL produced
     */
    private final String finalSQL;

    /**
     * Map of parameters as name as key and value as parameter value
     */
    private final Map<String, Object> paramsMap;

    /**
     * Map of parameters as name as key and list of values as parameter value (used for IN clause)
     */
    private final MultiValueMap<String, Object> parameterListMap;

    private NativeExpressionSQLBuilder(String sql, ExpressionVisitor expressionVisitor) {
        super();
        finalSQL = sql;
        paramsMap = expressionVisitor.toParametersMap();
        parameterListMap = expressionVisitor.toParameterListMap();
    }

    public String toFinalSQL() {
        return this.finalSQL;
    }

    public Map<String, Object> toParametersMap() {
        return this.paramsMap;
    }

    public MultiValueMap<String, Object> toParameterListMap() {
        return this.parameterListMap;
    }

    public static class Builder {

        private final List<Expression> expressions;

        private final ExpressionVisitor expressionVisitor;

        public Builder(List<Expression> expressions, HibernateOperatorEnum operator) {
            super();
            this.expressions = expressions;
            expressionVisitor = new ExpressionVisitorImpl(operator);
        }

        private String buildExpressionString() {
            for (Expression eachExp : expressions) {
                eachExp.accept(expressionVisitor);
            }
            return expressionVisitor.toExpressionQueryString();
        }

        private String buildFinalSQL() {
            StringBuilder sb = new StringBuilder();
            sb.append(buildExpressionString());
            return sb.toString();
        }

        public NativeExpressionSQLBuilder buildQuery() {
            String sql = buildFinalSQL();
            return new NativeExpressionSQLBuilder(sql, expressionVisitor);
        }
    }
}
