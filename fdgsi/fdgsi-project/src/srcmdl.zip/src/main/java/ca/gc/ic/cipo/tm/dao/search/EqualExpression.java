package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public class EqualExpression implements Expression, Serializable {

    private static final long serialVersionUID = 3941946098793064611L;

    private SearchExpression searchExpression;

    // Constructor
    public EqualExpression() {
    }

    public EqualExpression(SearchExpression searchExpression) {
        this.searchExpression = searchExpression;
    }

    // Getters/Setters
    public SearchExpression getSearchExpression() {
        return searchExpression;
    }

    public void setSearchExpression(SearchExpression searchExpression) {
        this.searchExpression = searchExpression;
    }

    @Override
    public Criterion compose() {
        Criterion expression = null;
        HibernateOperatorEnum operator = searchExpression.getOperator();

        if (searchExpression.getOperator() != null && searchExpression.getValues() != null) {
            String property = searchExpression.getNestedModelPropertyType() != null
                ? searchExpression.getNestedModelPropertyType() : searchExpression.getModelPropertyType().getValue();

            if (HibernateOperatorEnum.EQUAL.isEqualTo(operator)) {
                Object searchExpressionValue = searchExpression.getValues().get(0);

                if (searchExpressionValue instanceof String) {
                    expression = Restrictions.ilike(property, (String) searchExpressionValue, MatchMode.EXACT);
                } else {
                    expression = Restrictions.eq(property, searchExpressionValue);
                }
            }
        }
        return expression;
    }

    @Override
    public void accept(ExpressionVisitor expressionVisitor) {
        expressionVisitor.visit(this);
    }
}
