package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.DocumentStoredDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DocumentStored;

/**
 * The DocumentStoredDaoImpl retrieves data from the Claim Text Table using Hibernate.
 *
 * @see DocumentStoreDao
 * @see HibernateBaseDAO
 *
 * @author SeguinA3
 *
 */
@Repository("documentStoredDao")
public class DocumentStoredDaoImpl extends HibernateBaseDao implements DocumentStoredDao {

    private static final long serialVersionUID = 7546613230156901739L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(DocumentStoredDaoImpl.class);

    @Override
    public List<DocumentStored> getDocumentStored(Integer fileNumber) {
        List<DocumentStored> documentStored = new ArrayList<DocumentStored>();
        try {
            Criteria criteria = getSession().createCriteria(DocumentStored.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            documentStored = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Document Stored with parameters [" + fileNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return documentStored;
    }

    @Override
    public List<DocumentStored> getDocumentStored(ApplicationNumber applicationNumber) {
        return this.getDocumentStored(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    @Override
    public List<DocumentStored> getDocumentStored(Integer fileNumber, Integer extensionCounter) {
        List<DocumentStored> documentStored = new ArrayList<DocumentStored>();
        try {
            Criteria criteria = getSession().createCriteria(DocumentStored.class);
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_STORED_ID.getValue() + "."
                + ModelPropertyType.DOCUMENT_STORED_ID_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.DOCUMENT_STORED_ID.getValue() + "."
                + ModelPropertyType.DOCUMENT_STORED_ID_EXTENSION_COUNTER.getValue(), extensionCounter));
            documentStored = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Document Stored with parameters [" + fileNumber + ", " + extensionCounter + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return documentStored;
    }

}
