/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationEmails;
import ca.gc.ic.cipo.tm.model.ApplicationEmailsId;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;

/**
 * @author houreich
 *
 */
public interface ApplicationEmailsDao {

    public Set<ApplicationEmails> getApplicationEmails(Integer fileNumber, Integer extensionCounter);

    // TODO remove, emailsSeq is sufficient, should probably be named by key or something like that
    @Deprecated
    public Set<ApplicationEmails> getApplicationEmails(Integer fileNumber, Integer extensionCounter, Integer emailSeq);

    public Set<ApplicationEmails> getApplicationEmails(ApplicationNumber applicationNumber);

    // TODO remove unneeded
    @Deprecated
    public Set<ApplicationEmails> getApplicationEmails(Application application);

    // TODO PK, should return single object, remove ApplicationNumber, not needed since emailSeq is sufficient
    public Set<ApplicationEmails> getApplicationEmails(ApplicationNumber applicationNumber, Integer emailSeq);

    // TODO remove unneeded
    @Deprecated
    public Set<ApplicationEmails> getApplicationEmails(Application application, Integer emailSeq);

    // TODO remove unneeded ApplicationNumber(ApplicationEmailsId is an ApplicationNumber), return a single object
    public Set<ApplicationEmails> getApplicationEmails(ApplicationNumber applicationNumber,
                                                       ApplicationEmailsId applicationEmailsId);

    public void saveApplicationEmails(ApplicationEmails applicationEmails);

}
