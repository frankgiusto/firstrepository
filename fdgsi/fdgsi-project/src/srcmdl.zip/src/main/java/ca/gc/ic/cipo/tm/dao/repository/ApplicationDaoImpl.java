package ca.gc.ic.cipo.tm.dao.repository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.orm.hibernate4.SessionFactoryUtils;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ApplicationDao;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.Pair;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationEmails;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.Authorities;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.FinancialTransactions;
import ca.gc.ic.cipo.tm.model.FittIdentifiers;
import ca.gc.ic.cipo.tm.model.ProcessAction;

/**
 * This ApplicationDAO implementation retrieves a given Trade-mark Application or specified part of the application
 * using Hibernate.
 *
 * @see Application
 * @see ApplicationDao
 * @see HibernateBaseDao
 *
 * @author DenisJ1
 * @author SeguinA3 - Ported and re-factored from TDRS
 * @author giustof - Added getNextApplicationNumber()
 *
 */
@Repository("applicationDao")
public class ApplicationDaoImpl extends HibernateBaseDao implements ApplicationDao {

    private static final long serialVersionUID = 4453346339379248042L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ApplicationDaoImpl.class);

    private static final String FILE_NUMBER_PROCEDURE_NAME = "NEXT_FILE_NUMBER";

    private static final String PARAM_FILE_NUM_RESULT = "fileNumber";

    private static final int MAX_RESULT = 100;

    private static final String TRADEMARK_APPLICATIONS_SQL_STRING = "select   distinct AP.* from APPLICATIONS AP "
        + " inner join INTERESTED_PARTIES IP on AP.FILE_NUMBER = IP.FILE_NUMBER and AP.EXTENSION_COUNTER = IP.EXTENSION_COUNTER "
        // join with AGENTS_REPS
        + " inner join AGENTS_REPS AR on IP.AGENT_NUMBER = AR.AR_NUMBER "
        // filter by agent number
        + " where  IP.AGENT_NUMBER = :agentNumber";

    @Override
    public Application getApplication(String fileNumber, String extensionCounter) {
        ApplicationNumber id = new ApplicationNumber();
        id.setFileNumber(Integer.valueOf(fileNumber));
        id.setExtensionCounter(Integer.valueOf(extensionCounter));
        return getApplication(id);
    }

    @Override
    public Long getNextApplicationNumber() {

        JdbcTemplate jdbcTemplate = new JdbcTemplate(SessionFactoryUtils.getDataSource(getSessionFactory()));

        Long applicationNumber = null;
        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName(FILE_NUMBER_PROCEDURE_NAME)
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(new SqlOutParameter(PARAM_FILE_NUM_RESULT, Types.NUMERIC));
            Map<String, Object> out = retryableExecute(jdbcCall);

            applicationNumber = ((BigDecimal) out.get(PARAM_FILE_NUM_RESULT)).longValue();
            logger.info("Got file number " + applicationNumber);

        } catch (Exception ex) {
            logger.error("Unable to get tm file number in the database", ex);
            throw new DataAccessException("Unable to  to get tm file number in the database", ex);
        }
        return applicationNumber;
    }

    /**
     *
     * Copy mark. This is an Intrepid stored procedure.
     *
     * @param fileNumber the file number of the application that needs to be copied
     * @param extensionCounter the extension counter of the application that needs to be copied
     *
     * @return the new application number
     */
    @Override
    public ApplicationNumber copyMark(Integer fileNumber, Integer extensionCounter) {

        JdbcTemplate jdbcTemplate = new JdbcTemplate(SessionFactoryUtils.getDataSource(getSessionFactory()));

        Long newApplicationNumber = getNextApplicationNumber();

        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("COPYMARK")
                .withoutProcedureColumnMetaDataAccess();

            jdbcCall.declareParameters(new SqlParameter("NNEW_FILE_NUMBER", Types.NUMERIC))
                .declareParameters(new SqlParameter("NNEW_EXTENSION_COUNTER", Types.NUMERIC))
                .declareParameters(new SqlParameter("NORIGINAL_FILE_NUMBER", Types.NUMERIC))
                .declareParameters(new SqlParameter("NORIGINAL_EXTENSION_COUNTER", Types.NUMERIC));

            Map<String, Object> input = new HashMap<String, Object>();
            input.put("NNEW_FILE_NUMBER", newApplicationNumber);
            input.put("NNEW_EXTENSION_COUNTER", extensionCounter);
            input.put("NORIGINAL_FILE_NUMBER", fileNumber);
            input.put("NORIGINAL_EXTENSION_COUNTER", extensionCounter);

            jdbcCall.execute(input);

            ApplicationNumber applicationNumber = new ApplicationNumber();
            applicationNumber.setExtensionCounter(0);
            applicationNumber.setFileNumber(newApplicationNumber.intValue());

            return applicationNumber;

        } catch (Exception ex) {
            logger.error("Unable to COPYMARK", ex);
            throw new DataAccessException("Unable to COPYMARK", ex);
        }
    }

    /**
     *
     * Copy mark. This is an Intrepid stored procedure.
     *
     * @param fileNumber the file number of the application that needs to be copied
     * @param extensionCounter the extension counter of the application that needs to be copied
     *
     * @return the new application number
     */
    @Override
    public void copyFiles(Integer newFileNumber, Integer newExtensionCounter, Integer origFileNumber,
                          Integer origExtensionCounter) {

        JdbcTemplate jdbcTemplate = new JdbcTemplate(SessionFactoryUtils.getDataSource(getSessionFactory()));

        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("COPY_FILES")
                .withoutProcedureColumnMetaDataAccess();

            jdbcCall.declareParameters(new SqlParameter("NORIGINALFILENUMBER", Types.NUMERIC))
                .declareParameters(new SqlParameter("NORIGINALEXTENSIONCOUNTER", Types.NUMERIC))
                .declareParameters(new SqlParameter("NNEWFILENUMBER", Types.NUMERIC))
                .declareParameters(new SqlParameter("NNEWEXTENSIONCOUNTER", Types.NUMERIC));

            Map<String, Object> input = new HashMap<String, Object>();
            input.put("NORIGINALFILENUMBER", origFileNumber);
            input.put("NORIGINALEXTENSIONCOUNTER", origExtensionCounter);
            input.put("NNEWFILENUMBER", newFileNumber);
            input.put("NNEWEXTENSIONCOUNTER", newExtensionCounter);

            jdbcCall.execute(input);

        } catch (Exception ex) {
            logger.error("Unable to COPY_FILES", ex);
            throw new DataAccessException("Unable to COPY_FILES", ex);
        }
    }

    @Override
    public Application getApplication(Integer fileNumber, Integer extensionCounter) {
        long startTime = System.currentTimeMillis();
        Application application = new Application();
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            application = super.findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application with parameters [" + fileNumber + ", " + extensionCounter + "]"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        logger.trace("Time to read application [ " + fileNumber + ", " + extensionCounter + "] = "
            + (System.currentTimeMillis() - startTime) + " ms");

        return application;
    }

    @Override
    public Application getApplication(ApplicationNumber appNumber) {
        return this.getApplication(appNumber.getFileNumber(), appNumber.getExtensionCounter());
    }

    @Override
    public List<Application> getApplications(Integer fileNumber) {
        long startTime = System.currentTimeMillis();
        List<Application> applications = new ArrayList<Application>();
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));

            applications = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application with parameters [" + fileNumber + "]" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        logger.trace(
            "Time to read application [ " + fileNumber + "] = " + (System.currentTimeMillis() - startTime) + " ms");

        return applications;
    }

    @Override
    public Integer getTrademarkType(ApplicationNumber applicationNumber) {
        Integer trademarkType = 0;
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.setProjection(Projections.projectionList()
                .add(Projections.property(ModelPropertyType.APPLICATION_TRADE_MARK_TYPE.getValue()), "tradeMarkType"));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));

            trademarkType = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving trademark type with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + "]" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return trademarkType;
    }

    @Override
    public ApplicationNumber lookupApplicationNumber(Integer legislation, Integer regNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber();
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.setProjection(Projections.projectionList()
                .add(Projections.property(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue()), "fileNumber")
                .add(Projections.property(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue()),
                    "extensionCounter"));

            // TODO: It seems that a registration number is always unique for a
            // given application number but not
            // for an application number and extension counter. Which extension
            // should we used ?
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_LEGISLATION.getValue(), legislation));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_REGISTRATION_NUMBER.getValue(), regNumber));
            criteria.setResultTransformer(Transformers.aliasToBean(ApplicationNumber.class));

            applicationNumber = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application number with parameters [" + legislation + ", " + regNumber
                + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return applicationNumber;
    }

    @Override
    public List<Authorities> getAuthorities(Integer fileNumber, Integer extensionCounter, String authorityId) {

        String sql =
            // Select all authorities related to this
            // application.
            "select {auth.*} from authorities auth "
                + "join aa_work_sheets aaws on auth.AUTHORITY_ID = aaws.AUTHORITY_ID "
                + "join aa_work_sheet_files aawf on aaws.WORK_SHEET_NUMBER = aawf.WORK_SHEET_NUMBER "
                + "join applications ap on aawf.FILE_NUMBER = ap.FILE_NUMBER and aawf.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (aawf.FILE_NUMBER = :fileNumber and aawf.EXTENSION_COUNTER = :extensionCounter and aaws.AUTHORITY_ID = :authorityId)";

        // Set the runtime parameters - fileNumber, extensionCounter and
        // authorityId
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);
        parameters.put(ModelPropertyType.AA_WORK_SHEETS_ID_AUTHORITY_ID.getValue(), authorityId);
        // Declare the SQL query and attach the entity Action to it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("auth", Authorities.class);
        List<Authorities> authorities = new ArrayList<Authorities>();
        try {
            authorities = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving authorities details parameters [" + fileNumber + ", " + extensionCounter
                + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<Authorities>(authorities);
        return authorities;
    }

    @Override
    public List<FinancialTransactions> getFinancialTransactions(Integer fileNumber, Integer extensionCounter) {

        String sql =
            // Select all financial transactions related to this
            // application.
            "select {ft.*} from financial_transactions ft "
                + "join applications ap on ft.FILE_NUMBER = ap.FILE_NUMBER and ft.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (ft.FILE_NUMBER = :fileNumber and ft.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity FinancialTransactions to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("ft", FinancialTransactions.class);
        List<FinancialTransactions> financialTransactions = new ArrayList<FinancialTransactions>();
        try {
            financialTransactions = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving financialTransactions details parameters [" + fileNumber + ", "
                + extensionCounter + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<FinancialTransactions>(financialTransactions);

        return financialTransactions;
    }

    // Retrieve the list of data correction actions log
    @Override
    // TODO not used for now I think, not reviewed
    @Deprecated
    public List<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter) {

        String sql =
            // Select all data corrections actions log related to this
            // application.
            "select {dtc.*} from data_correction_actions_log dtc "
                + "join applications ap on dtc.FILE_NUMBER = ap.FILE_NUMBER and dtc.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (dtc.FILE_NUMBER = :fileNumber and dtc.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity DataCorrectionActionsLog
        // to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("dtc", DataCorrectionActionsLog.class);
        List<DataCorrectionActionsLog> dataCorrectionActionsLogs = new ArrayList<DataCorrectionActionsLog>();
        try {
            dataCorrectionActionsLogs = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving dataCorrectionActionsLogs details parameters [" + fileNumber + ", "
                + extensionCounter + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<DataCorrectionActionsLog>(dataCorrectionActionsLogs);

        return dataCorrectionActionsLogs;
    }

    // Retrieve the list of process actions
    @Override
    public List<ProcessAction> getProcessActions(Integer fileNumber, Integer extensionCounter) {

        String sql =
            // Select all process actions related to this
            // application.
            "select {pa.*} from process_actions pa "
                + "join applications ap on pa.FILE_NUMBER = ap.FILE_NUMBER and pa.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (pa.FILE_NUMBER = :fileNumber and pa.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity ProcessActions to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("pa", ProcessAction.class);
        List<ProcessAction> processActions = new ArrayList<ProcessAction>();
        try {
            processActions = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving processActions details parameters [" + fileNumber + ", " + extensionCounter
                + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<ProcessActions>(processActions);

        return processActions;
    }

    // Retrieve the list of FITT Identifiers
    @Override
    public List<FittIdentifiers> getFittIdentifiers(Integer fileNumber, Integer extensionCounter) {

        String sql =
            // Select all FITT Identifiers related to this
            // application.
            "select {fa.*} from fitt_identifiers fa "
                + "join applications ap on fa.FILE_NUMBER = ap.FILE_NUMBER and fa.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (fa.FILE_NUMBER = :fileNumber and fa.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity FittIdentifiers to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("fa", FittIdentifiers.class);
        List<FittIdentifiers> fittIdentifiers = new ArrayList<FittIdentifiers>();
        try {
            fittIdentifiers = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving fittIdentifiers details parameters [" + fileNumber + ", " + extensionCounter
                + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<FittIdentifiers>(fittIdentifiers);

        return fittIdentifiers;
    }

    // Retrieve the list of assignment amendment work sheet files
    @Override
    // TODO not used for now I think, not reviewed
    @Deprecated
    public List<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                        Integer extensionCounter) {

        String sql =
            // Select all AssignmentAmendmentWorkSheetFiles related to this
            // application.
            "select {wsf.*} from aa_work_sheet_files wsf "
                + "join applications ap on wsf.FILE_NUMBER = ap.FILE_NUMBER and wsf.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (wsf.FILE_NUMBER = :fileNumber and wsf.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity
        // AssignmentAmendmentWorkSheetFiles to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("wsf", AssignmentAmendmentWorkSheetFiles.class);
        List<AssignmentAmendmentWorkSheetFiles> assignmentAmendmentWorkSheetFiles = new ArrayList<AssignmentAmendmentWorkSheetFiles>();
        try {
            assignmentAmendmentWorkSheetFiles = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving AssignmentAmendmentWorkSheetFiles details parameters [" + fileNumber + ", "
                + extensionCounter + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<AssignmentAmendmentWorkSheetFiles>(assignmentAmendmentWorkSheetFiles);

        return assignmentAmendmentWorkSheetFiles;
    }

    // Retrieve the list of email jobs
    @Override
    // TODO not used for now I think, not reviewed
    @Deprecated
    public List<EmailJobs> getEmailJobs(Integer fileNumber, Integer extensionCounter) {

        String sql =
            // Select all EmailJobs related to this
            // application.
            "select {ej.*} from e_mail_jobs ej "
                + "join applications ap on ej.FILE_NUMBER = ap.FILE_NUMBER and ej.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (ej.FILE_NUMBER = :fileNumber and ej.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity
        // EmailJobs to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("ej", EmailJobs.class);
        List<EmailJobs> emailJobs = new ArrayList<EmailJobs>();
        try {
            emailJobs = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving emailJobs details parameters [" + fileNumber + ", " + extensionCounter
                + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<EmailJobs>(emailJobs);

        return emailJobs;
    }

    // Retrieve the list of application emails
    @Override
    public List<ApplicationEmails> getApplicationEmails(Integer fileNumber, Integer extensionCounter) {

        String sql =
            // Select all ApplicationEmails related to this
            // application.
            "select {ae.*} from application_emails ae "
                + "join applications ap on ae.FILE_NUMBER = ap.FILE_NUMBER and ae.EXTENSION_COUNTER = ap.EXTENSION_COUNTER "
                + "where (ae.FILE_NUMBER = :fileNumber and ae.EXTENSION_COUNTER = :extensionCounter )";

        // Set the runtime parameters - fileNumber, extensionCounter

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity
        // EmailJobs to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("ae", ApplicationEmails.class);
        List<ApplicationEmails> applicationEmails = new ArrayList<ApplicationEmails>();
        try {
            applicationEmails = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving applicationEmails details parameters [" + fileNumber + ", "
                + extensionCounter + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        // return new HashList<ApplicationEmails>(applicationEmails);

        return applicationEmails;
    }

    @Override
    public List<Application> getApplicationByIrNumber(String irNumber) {
        if (StringUtils.isBlank(irNumber)) {
            throw new IllegalArgumentException("invalid parameters. irNumber must not be blank.");
        }
        Map<String, Object> parameters = new HashMap<String, Object>();
        StringBuilder sqlQuery = new StringBuilder("select {ap.*} from applications ap where ");
        sqlQuery.append("IR_NUMBER = :irNumber");
        parameters.put(ModelPropertyType.APPLICATION_IR_NUMBER.getValue(), irNumber);

        // Declare the SQL query and attach the entity
        // Application to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sqlQuery.toString(), parameters);
        query.addEntity("ap", Application.class);
        List<Application> applications = new ArrayList<Application>();
        try {
            applications = query.list();

        } catch (Exception ex) {
            logger.error(
                "Error retrieving application by ids. Details parameters [" + irNumber + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return applications;
    }

    @Override
    public List<Application> getApplicationByIds(String irNumber, String intlFilingRecordId) {

        if (StringUtils.isBlank(irNumber) || StringUtils.isBlank(intlFilingRecordId)) {
            throw new IllegalArgumentException("invalid parameters. Both parameters require values.");
        }
        Map<String, Object> parameters = new HashMap<String, Object>();
        StringBuilder sqlQuery = new StringBuilder("select {ap.*} from applications ap where ");

        sqlQuery.append("IR_NUMBER = :irNumber");
        parameters.put(ModelPropertyType.APPLICATION_IR_NUMBER.getValue(), irNumber);
        sqlQuery.append(" and INTL_FILING_RECORD_ID = :intlFilingRecordId");
        parameters.put(ModelPropertyType.APPLICATION_INTL_FILING_RECORD_ID.getValue(), intlFilingRecordId);

        // Declare the SQL query and attach the entity
        // Application to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sqlQuery.toString(), parameters);
        query.addEntity("ap", Application.class);
        List<Application> applications = new ArrayList<Application>();
        try {
            applications = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving application by ids. Details parameters [" + irNumber + ", "
                + intlFilingRecordId + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return applications;
    }

    @Override
    public Set<Application> getApplicationsByAgent(int agentNumber) {
        long startTime = System.currentTimeMillis();
        List<Application> applications = new ArrayList<Application>();
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.setMaxResults(MAX_RESULT).createCriteria("interestedParties").createCriteria("agent")
                .add(Restrictions.eq(ModelPropertyType.AGENT_REPRESENTATIVE_AR_NUMBER.getValue(),
                    Integer.valueOf(agentNumber)));

            applications = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application for associated interested party with paramaters[" + agentNumber
                + "] /n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        logger.trace("Time to read applications by agent = " + (System.currentTimeMillis() - startTime) + " ms");

        return new HashSet<Application>(applications);
    }

    @Override
    public void saveApplication(Application application) {
        Session session = getSession();
        session.saveOrUpdate(application);
    }

    private Map<String, Object> retryableExecute(SimpleJdbcCall jdbcCall) throws SQLException {

        Map<String, Object> result = null;
        int tryCount = 0;
        while (tryCount < 2) {
            tryCount++;
            try {
                result = jdbcCall.execute();
                break;
            } catch (Exception ex) {
                logger.warn("Unable to execute procedure " + jdbcCall.getClass().getName(), ex);
                logger.warn("Retrying another time");
                if (tryCount >= 2) {
                    throw new SQLException("Unable to execute procedure " + jdbcCall.getClass().getName(), ex);
                }
            }
        }

        return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    /** @{inheritDoc} */
    public List<Application> getTrademarkApplicationsByAgentNumber(Integer agentNumber) {
        List<Pair<String, Object>> params = new ArrayList<>();
        params.add(new Pair<String, Object>("agentNumber", agentNumber));
        Map<String, Object> parameters = QueryHelper.fillParameters(params);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(TRADEMARK_APPLICATIONS_SQL_STRING, parameters);
        sqlQuery.addEntity("AP", Application.class).setMaxResults(MAX_RESULT);

        return sqlQuery.list();
    }

    @Override
    /** @{inheritDoc} */
    public void setClassificationRequiredInd(ApplicationNumber applicationNumber, int ind) {
        logger.info("setClassificationRequiredInd:" + applicationNumber.getFileNumber() + ":"
            + applicationNumber.getExtensionCounter() + ":" + ind);
        try {
            Application app = getApplication(applicationNumber);
            app.setClassificationRequiredInd(ind);
            // getSession().saveOrUpdate(app);
        } catch (Exception ex) {
            logger.error("There are no App Classification with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

    }

    @Override
    /** @{inheritDoc} */
    public List<Application> getApplicationsByClassificationRequiredIndRange(int ind, Integer lowestApplicationNumber,
                                                                             Integer highestApplicationNumber,
                                                                             Integer limit) {
        List<Application> applications = new ArrayList<Application>();
        try {
            Criteria criteria = getSession().createCriteria(Application.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_CLASSIFICATION_REQUIRED_IND.getValue(), ind));
            if (lowestApplicationNumber != null && lowestApplicationNumber.intValue() > 0) {
                criteria.add(Restrictions.ge(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                    lowestApplicationNumber.intValue()));
            }
            if (highestApplicationNumber != null && lowestApplicationNumber.intValue() > 0) {
                criteria.add(Restrictions.le(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                    highestApplicationNumber.intValue()));
            }
            if (limit != null && limit > 0) {
                criteria.setMaxResults(limit);
            }

            applications = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no ClassificationRequiredInd with parameters [" + ind + "]/n" + ex.getMessage(),
                ex);
            throw new DataAccessException(ex);
        }
        return applications;
    }

    @Override
    /** @{inheritDoc} */
    public List<Application> getApplicationsByClassificationRequiredInd(int ind) {
        return getApplicationsByClassificationRequiredIndRange(ind, null, null, null);
    }
}
