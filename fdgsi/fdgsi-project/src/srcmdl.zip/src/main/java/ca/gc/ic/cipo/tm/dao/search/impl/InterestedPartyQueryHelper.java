package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.builders.NativeExpressionSQLBuilder;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

/**
 * Utility to create the native SQL query specific to IP and IPA table searches
 */
public final class InterestedPartyQueryHelper {

    private static final int MAX_RESULTS_SIZE = 100;

    private static final String MAIN_SELECT = " select * from ( ";

    private static final String INNER_SELECT_1 = " select IP.* from INTERESTED_PARTIES IP inner join ( ";

    private static final String INNER_SELECT_2 = " select max(ip.FILE_NUMBER) as FILE_NUMBER , max(Ip.Extension_Counter) as EXTENSION_COUNTER, max(ip.ip_number) as IP_NUMBER ";

    private static final String FROM_SQL = "    from INTERESTED_PARTIES IP inner join INTERESTED_PARTIES_ADDRESSES IPA on IP.FILE_NUMBER = IPA.FILE_NUMBER "
        + " and IP.EXTENSION_COUNTER = IPA.EXTENSION_COUNTER and IP.IP_NUMBER = IPA.IP_NUMBER ";

    private InterestedPartyQueryHelper() {
    }

    /**
     * The Query generated is specific to IP table search. This is specific to Filing application where applicants are
     * always searched on Primary address (type = 1) and other supplied search criteria filters. The results should be
     * non duplication. The query uses group by clause on IP.NAME and other address items based on supplied search
     * criteria.
     *
     *
     * @param searchedItemsTypeMap the Map of key SearhItemType and Boolean as value.
     * @param expressions the list of Expressions
     * @param operatorEnum the Operator to connect the expressions
     * @return the QueryAndParams encapsulating query and query parameters.
     */
    public static QueryAndParams createNativeSQLQuery(List<Expression> expressions,
                                                      HibernateOperatorEnum operatorEnum) {

        if (CollectionUtils.isEmpty(expressions)) {
            throw new IllegalArgumentException("Expected at least one Search Expression");
        }

        operatorEnum = Objects.requireNonNull(operatorEnum);

        StringBuilder sb = new StringBuilder();
        sb.append(MAIN_SELECT).append(INNER_SELECT_1).append(INNER_SELECT_2).append(FROM_SQL);
        sb.append(" where (1=1) ");
        sb.append(" and ( ");

        NativeExpressionSQLBuilder expressionSQLBuilder = new NativeExpressionSQLBuilder.Builder(expressions,
            operatorEnum).buildQuery();

        // where clause to filter out results
        String expSQL = expressionSQLBuilder.toFinalSQL();

        sb.append(expSQL).append(" ) ");
        sb.append(" group by  ");
        sb.append(" IP.NAME, IPA.COUNTRY_PROVINCE, IPA.ADDRESS,IP.TELEPHONE_NUMBER ");

        sb.append(" order by IP.NAME ");
        sb.append(" ) results ");
        sb.append(
            " ON IP.file_number = results.file_number and IP.EXTENSION_COUNTER = results.EXTENSION_COUNTER and IP.IP_NUMBER = results.IP_NUMBER ");
        sb.append(" ) where rownum <=").append(MAX_RESULTS_SIZE);

        return new QueryAndParams(sb.toString(), expressionSQLBuilder.toParametersMap(),
            expressionSQLBuilder.toParameterListMap());
    }

    /**
     * The Query generated is specific to IP table search. There is no specific filters with regards to Address type
     * and/or distinct result sets. No group by clause is used to return distinct results
     *
     * Specific to TMOB application or applications.
     *
     * @param expressions the list of Expressions
     * @param operatorEnum the Operator to connect the expressions
     * @return the QueryAndParams encapsulating query and query parameters.
     */
    public static QueryAndParams createNativeSQLQueryInterestedParties(List<Expression> expressions,
                                                                       HibernateOperatorEnum operatorEnum) {
        if (CollectionUtils.isEmpty(expressions)) {
            throw new IllegalArgumentException("Expected at least one Search Expression");
        }

        operatorEnum = Objects.requireNonNull(operatorEnum);

        StringBuilder sb = new StringBuilder();
        sb.append(MAIN_SELECT);
        sb.append(" select {IP.*} ").append(FROM_SQL);

        sb.append(" where (1=1) ");
        sb.append(" and ( ");

        NativeExpressionSQLBuilder expressionSQLBuilder = new NativeExpressionSQLBuilder.Builder(expressions,
            operatorEnum).buildQuery();

        // where clause to filter out results
        String expSQL = expressionSQLBuilder.toFinalSQL();

        sb.append(expSQL).append(" ) ");
        sb.append(" order by IP.name");
        sb.append(" ) where rownum <=").append(MAX_RESULTS_SIZE);

        return new QueryAndParams(sb.toString(), expressionSQLBuilder.toParametersMap(),
            expressionSQLBuilder.toParameterListMap());

    }
}
