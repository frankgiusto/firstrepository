/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.MadridApplication;

/**
 * @author giustof
 *
 */
public interface MadridApplicationDao {

    /**
     * Gets the madrid application by reference number.
     *
     * @param referenceNumber the reference number
     * @return the madrid application by reference number
     */
    public MadridApplication getMadridApplicationByReferenceNumber(String referenceNumber);

    /**
     * Gets the madrid application by ir number.
     *
     * @param irNumber the ir number
     * @return the madrid application by ir number
     */
    public List<MadridApplication> getMadridApplicationByIrNumber(String irNumber);

    /**
     * Save madrid application.
     *
     * @param MadridApplication the madrid application
     */
    public void saveMadridApplication(MadridApplication MadridApplication);
}
