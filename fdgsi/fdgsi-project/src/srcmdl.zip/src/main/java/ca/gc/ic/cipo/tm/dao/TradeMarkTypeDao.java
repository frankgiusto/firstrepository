package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.model.TrademarkType;

public interface TradeMarkTypeDao {

    public Set<TrademarkType> getTradeMarkTypes(TradeMark tradeMark);

}
