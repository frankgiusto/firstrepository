/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OralHearingAttendeesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseId;
import ca.gc.ic.cipo.tm.model.OralHearingAttendees;
import ca.gc.ic.cipo.tm.model.OralHearingAttendeesId;

/**
 * The OralHearingAttendeesDaoImpl retrieves data from the ORAL_HEARING_ATTENDEES Table using Hibernate.
 *
 * @see OralHearingAttendeesDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("oralHearingAttendeesDao")
public class OralHearingAttendeesDaoImpl extends HibernateBaseDao implements OralHearingAttendeesDao {

    /**
     *
     */
    private static final long serialVersionUID = 6936080135358217149L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(OralHearingAttendeesDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(Integer fileNumber, Integer extensionCounter,
                                                             Integer oppCaseNumber) {
        // TODO Auto-generated method stub
        List<OralHearingAttendees> oralHearingAttendees = new ArrayList<OralHearingAttendees>();
        try {
            Criteria criteria = getSession().createCriteria(OralHearingAttendees.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria
                .add(Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ID_OPP_CASE_NUMBER.getValue(), oppCaseNumber));
            oralHearingAttendees = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving oral hearing attendees with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + oppCaseNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<OralHearingAttendees>(oralHearingAttendees);
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(Integer fileNumber, Integer extensionCounter,
                                                             Integer oppCaseNumber, Integer attendeeType) {
        // TODO Auto-generated method stub
        List<OralHearingAttendees> oralHearingAttendees = new ArrayList<OralHearingAttendees>();
        try {
            Criteria criteria = getSession().createCriteria(OralHearingAttendees.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria
                .add(Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ID_OPP_CASE_NUMBER.getValue(), oppCaseNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.ORAL_HEARING_ATTENDEES_ID_ATTENDEE_TYPE.getValue(), attendeeType));
            oralHearingAttendees = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving oral hearing attendees with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + oppCaseNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<OralHearingAttendees>(oralHearingAttendees);
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCaseId oppositionCaseId) {
        // TODO Auto-generated method stub
        return this.getOralHearingAttendees(oppositionCaseId.getFileNumber(), oppositionCaseId.getExtensionCounter(),
            oppositionCaseId.getOppCaseNumber());
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCase oppostionCase) {
        // TODO Auto-generated method stub
        return this.getOralHearingAttendees(new OppositionCaseId(oppostionCase.getFileNumber(),
            oppostionCase.getExtensionCounter(), oppostionCase.getOppCaseNumber()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCaseId oppositionCaseId, Integer attendeeType) {
        // TODO Auto-generated method stub
        return this.getOralHearingAttendees(oppositionCaseId.getFileNumber(), oppositionCaseId.getExtensionCounter(),
            oppositionCaseId.getOppCaseNumber(), attendeeType);
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCase oppostionCase, Integer attendeeType) {
        // TODO Auto-generated method stub
        return this.getOralHearingAttendees(oppostionCase.getFileNumber(), oppostionCase.getExtensionCounter(),
            oppostionCase.getOppCaseNumber(), attendeeType);
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingAttendees> getOralHearingAttendees(OppositionCaseId oppositionCaseId,
                                                             OralHearingAttendeesId oralHearingAttendeesId) {
        // TODO Auto-generated method stub
        return this.getOralHearingAttendees(oppositionCaseId, oralHearingAttendeesId.getAttendeeType());
    }

}
