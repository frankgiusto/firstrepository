package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;

public interface OppositionCaseActionDao extends BaseDao {

    /**
     * Retrieve and return the previous deadline date for the specified Opposition case action
     */
    public OppositionCaseAction getPreviousDeadlineDateForOpposition(OppositionCaseAction oppositionCaseAction);

    /**
     * Retrieve and return the list of type OppositionCaseAction objects
     *
     * @param applicationNumber the application file number
     * @param caseNumber the Opposition case number
     * @return the list of OppositionCaseActions
     */
    public List<OppositionCaseAction> getOppositionCaseActions(ApplicationNumber applicationNumber, Integer caseNumber);

    /**
     * Retrieve and return the list of type OppositionCaseAction objects
     *
     * @param fileNumber the application file number
     * @param extensionCounter the extension counter
     * @param caseNumber the opposition case number
     * @return the list of OppositionCaseActions
     */
    public List<OppositionCaseAction> getOppositionCaseActions(Integer fileNumber, Integer extensionCounter,
                                                               Integer caseNumber);

    /**
     * Retrieve and return the OppositionCaseAction for the specified criteria.
     *
     * @param applicationNumber the application file number
     * @param caseNumber the opposition case number
     * @param actionCode the Opposition action code
     * @return the OppositionCaseAction
     */
    public OppositionCaseAction getOppositionCaseAction(ApplicationNumber applicationNumber, Integer caseNumber,
                                                        Integer actionCode);

    /**
     * Retrieve and return the OppositionCaseAction for the specified application number, opposition case number and
     * action code
     *
     * @param applicationNumber the application file number
     * @param caseNumber the Opposition case number
     * @param oppStageCode the Opposition stage code
     * @param oppActionCode the Opposition action code
     * @return the OppositionCaseAction
     */
    public OppositionCaseAction getOppositionCaseAction(ApplicationNumber applicationNumber, Integer caseNumber,
                                                        Integer oppStageCode, Integer oppActionCode);

    /**
     * Retrieve and return a boolean to determine if cooling off period has already been granted for a given opposition
     * case and role (applicant/opponent) exists.
     *
     * @param applicationNumber the application file number
     * @param caseNumber the Opposition case number
     * @param oppActionCode the Opposition action code
     * @return Boolean true if cooling off allowed; false otherwise
     */
    public boolean isCoolingOffAllowedForOppositionCase(ApplicationNumber applicationNumber, Integer caseNumber,
                                                        Integer oppActionCode);

    /**
     * Retrieves and returns a list of active opposition case actions for specified criteria
     *
     * @param applicationNumber the application file number
     * @param oppCaseNumber the Opposition case number
     * @param oppActionType the Opposition action type code
     * @return the collection of type OppositionCaseAction objects
     */
    List<OppositionCaseAction> getActiveOppositionCaseActions(ApplicationNumber applicationNumber,
                                                              Integer oppCaseNumber, Integer oppActionType);

}
