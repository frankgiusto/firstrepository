package ca.gc.ic.cipo.tm.dao.helpers;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Helper for building query string for search applications for registration
 */
public final class SearchApplicationsQueryHelper {

    /**
     * DUE Date is null
     */
    private static final String NULL_DATE_SQL_STR = " rr.DUE_DATE is null ";

    /**
     * Start date SQL
     */
    private static final String START_DATE_SQL_STR = " TRUNC(rr.DUE_DATE) >= :startDate ";

    /**
     * End date SQL
     */
    private static final String END_DATE_SQL_STR = " TRUNC(rr.DUE_DATE) <= :endDate ";

    /**
     * Query SQL to be used when file number is to be provided
     */
    private static final String APPICATION_NUMBER_SQL_STR = " rr.file_number = :fileNumber ";

    /**
     * Query for extension counter
     */
    private static final String EXTENSION_COUNTER_SQL_STR = " rr.extension_counter = :extensionCounter ";

    /**
     * Query SQL when Agent number is provided
     */
    private static final String AGENT_NUMBER_SQL_STR = " rr.AR_NUMBER IN ( :agentNumbers )  ";

    /**
     * Query SQL to be used when trademark name is provided
     */
    private static final String TRADEMARK_NAME_SQL_STR = " upper(rr.tm_text) like upper(:tmText) ";

    /**
     * Query SQL to be used when applicant name is provided
     */
    private static final String APPLICANT_NAME_SQL_STR = " upper(rr.owner_name) like upper(:ownerName) ";

    /**
     * Start SQL Query string
     */
    private static final String START_SQL_STR;

    /**
     * End SQL Query string
     */
    private static final String END_SQL_STR;

    /**
     * Query SQL to be used when Requestor User is provided
     */
    private static final String REQUESTOR_USER_SQL_STR;

    /***
     * Filter EC Registrations
     */
    private static final String FILTER_EC_REGISTRATIONS = " and not exists ( select ec.* from EC_REGISTRATION ec where ec.cipoec_tm_apltn_no = rr.file_number and ec.apltn_extn_cntr = rr.extension_counter ) ";

    /**
     * Filter out (exclude with 1 in it for Pending issues related DB fields)
     */
    private static final String FILTER_PENDING_ISSUES_SQL = " and ( rr.LOOSE_MAIL <> 1 OR rr.PENDING_OWNER <> 1 OR rr.PENDING_SEIZURE <> 1 OR rr.ASSIGNMENT_WORKSHEET <> 1 OR rr.SEIZURE <> 1 ) ";

    static {
        StringBuilder sql = new StringBuilder();

        /** Start section */
        sql.append(" select * from (   SELECT /*+ RESULT_CACHE */ {rr.*} from {h-schema}REGFEEDECUSE_ALLOWED rr ");
        sql.append(" where (1 = 1) ");
        START_SQL_STR = sql.toString();

        /**
         * Requestor User section Checks if the requestor is an active agent, if it is, adds the agent within the firm
         * section. If the requestor isn't an active agent, do not add any conditions.
         */
        sql = new StringBuilder();
        sql.append(" ( ");
        sql.append("   (exists (select * from {h-schema}agents_reps ar, {h-schema}agent_user_xref au ");
        sql.append(
            "       where ar.ar_number = au.ar_number and au.user_id = :requestorUserId and ar.status_code = 1 and ar.ar_type in (1,3)) ");
        sql.append("     /*add the agents within the firm condition*/ ");
        sql.append("     and (  rr.ar_number in  ( ( ");
        sql.append(
            "       select distinct ar.ar_number from {h-schema}agents_reps ar where ar.status_code = 1 start with ar.ar_number in ( ");
        sql.append(
            "       select ar_number from {h-schema}agent_user_xref where user_id = :requestorUserId ) connect by prior ar.member_of = ar.ar_number)  union ( ");
        sql.append(
            "       select distinct ar.member_of from {h-schema}agents_reps ar where ar.status_code = 1 start with ar.ar_number in ( ");
        sql.append(
            "       select ar_number from {h-schema}agent_user_xref where user_id = :requestorUserId )  connect by prior ar.member_of = ar.ar_number) ) ) ");
        sql.append("   ) ");
        sql.append(" or ");
        sql.append("   (not exists (select * from {h-schema}agents_reps ar, {h-schema}agent_user_xref au ");
        sql.append(
            "       where ar.ar_number = au.ar_number and au.user_id = :requestorUserId and ar.status_code = 1 and ar.ar_type in (1,3)) ");
        sql.append("     /*do not add any condition*/ ");
        sql.append("     and 1 = 1 ");
        sql.append("   ) ");
        sql.append(" ) ");
        REQUESTOR_USER_SQL_STR = sql.toString();

        /** end section */
        sql = new StringBuilder();
        sql.append("  order by rr.due_date asc, rr.file_number asc    ");
        sql.append(" ) "); /* closing bracket from the outside select statement */
        sql.append(" where rownum <= :rowNum ");
        END_SQL_STR = sql.toString();
    }

    public String buildQuery(SearchRegistrationCriteria searchCriteria) {
        StringBuilder sb = new StringBuilder();
        boolean fileNumberProvided = false;

        if (searchCriteria != null) {
            sb.append(START_SQL_STR);

            // application number
            if (searchCriteria.getApplicationNumber() != null) {
                if (searchCriteria.getApplicationNumber().getFileNumber() != null) {
                    sb.append(" and ").append(APPICATION_NUMBER_SQL_STR);
                    fileNumberProvided = true;
                }
                if (searchCriteria.getApplicationNumber().getExtensionCounter() != null) {
                    sb.append(" and ").append(EXTENSION_COUNTER_SQL_STR);
                }
            }

            // advance search (agent has to exist)
            if (!CollectionUtils.isEmpty(searchCriteria.getAgentNumbers())) {

                // agent number
                sb.append(" and ").append(AGENT_NUMBER_SQL_STR);

                if (StringUtils.hasText(searchCriteria.getRequestorUserId())) {
                    // requester user id
                    sb.append(" and ").append(REQUESTOR_USER_SQL_STR);
                }

                // text
                if (StringUtils.hasText(searchCriteria.getTrademarkName())) {
                    sb.append(" and ").append(TRADEMARK_NAME_SQL_STR);
                }

                // Owner name
                if (StringUtils.hasText(searchCriteria.getApplicantName())) {
                    sb.append(" and ").append(APPLICANT_NAME_SQL_STR);
                }

             // Date filter
                // and (rr.DUE_DATE is null or (TRUNC(rr.DUE_DATE) >= :startDate and TRUNC(rr.DUE_DATE) <= :endDate))
                // TMHOTFIX-5
                sb.append(" and (").append(NULL_DATE_SQL_STR).append(" or (").append(START_DATE_SQL_STR).append(" and ")
                    .append(END_DATE_SQL_STR).append("))");
            }

            /** Filter file numbers from EC Registrations only when file number is not provided */
            if (!fileNumberProvided) {
                sb.append(FILTER_EC_REGISTRATIONS);
                sb.append(FILTER_PENDING_ISSUES_SQL);
            }

            sb.append(END_SQL_STR);
        }
        return sb.toString();
    }
}
