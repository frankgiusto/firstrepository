/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLogId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface DataCorrectionActionsLogDao {

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter);

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter,
                                                                      String dataCorrectionAuthorityId);

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(ApplicationNumber applicationNumber);

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Application application);

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(ApplicationNumber applicationNumber,
                                                                      String dataCorrectionAuthorityId);

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Application application,
                                                                      String dataCorrectionAuthorityId);

    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(ApplicationNumber applicationNumber,
                                                                      DataCorrectionActionsLogId dataCorrectionActionsLogId);

}
