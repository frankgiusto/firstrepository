package ca.gc.ic.cipo.tm.dao;

import java.sql.Blob;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.Registration;

// TODO: Auto-generated Javadoc
/**
 * The Interface RegistrationDao.
 */
public interface RegistrationDao {

    /**
     * Return the transaction document for the registration page.
     *
     * @param applicationNumber The application number.
     * @param extensionCounter The extension counter number.
     * @param transactionNumber The transaction number.
     * @return the registration
     */
    public Blob getRegistrationPageForRegistration(Integer applicationNumber, Integer extensionCounter,
                                                   Integer transactionNumber);

    /**
     * Return the transaction document for the registration page.
     *
     * @param applicationNumber The application number.
     * @param extensionCounter The extension counter number.
     * @param transactionNumber The transaction number.
     * @return the registration certificate
     */
    public Blob getRegistrationCertificate(Integer applicationNumber, Integer extensionCounter,
                                           Integer transactionNumber);

    /**
     * Return the transaction document for the declaration of use.
     *
     * @param applicationNumber The application number.
     * @param extensionCounter The extension counter number.
     * @param transactionNumber The transaction number.
     * @return the declaration of use
     */
    public Blob getDeclarationOfUse(Integer applicationNumber, Integer extensionCounter, Integer transactionNumber);

    /**
     * Return the transaction document for the extension of time.
     *
     * @param applicationNumber The application number.
     * @param extensionCounter The extension counter number.
     * @param transactionNumber The transaction number.
     * @return the extension of time
     */
    public Blob getExtensionOfTime(Integer applicationNumber, Integer extensionCounter, Integer transactionNumber);

    /**
     * Return the transaction document for the renewal certificate.
     *
     * @param fileNumber The file number.
     * @param extensionCounter The extension counter number.
     * @param confirmationNumber The confirmation number.
     * @return the renewal certificate
     */
    public Blob getRenewalCertificate(Integer fileNumber, Integer extensionCounter, Integer confirmationNumber);

    /**
     * Return the transaction document for the renewal notice.
     *
     * @param fileNumber The file number.
     * @param extensionCounter The extension counter number.
     * @param confirmationNumber The confirmation number.
     * @return the registration page
     */
    public Blob getRegistrationPageForRenewal(Integer fileNumber, Integer extensionCounter, Integer confirmationNumber);

    /**
     * Return the transaction document for the acknowledgement notice.
     *
     * @param fileNumber The file number.
     * @param extensionCounter The extension counter number.
     * @param confirmationNumber The confirmation number.
     * @return the acknowledgement notice
     */
    public Blob getAcknowledgementNotice(Integer fileNumber, Integer extensionCounter, Integer confirmationNumber);

    /**
     * Save registration information into EC_REGISTRATION table.
     *
     * @param registration the registration
     */
    public void saveRegistration(Registration registration);

    /**
     * Determines if registration exists in trademark
     *
     * @param applicationNumber the application file number
     * @return true if exists; false otherwise
     */
    boolean isRegistrationExistsInTrademark(ApplicationNumber applicationNumber);

} // End of the RegistrationDao Interface.