package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.model.CountryProvince;


@Repository("frenchCountryProvinceLookupDao")
public class FrenchCountryProvinceLookupDaoImpl extends
		CountryProvinceLookupDaoImpl {

	private static final long serialVersionUID = 6112241580116278889L;

	public List<CountryProvince> getCountries() {
		return super.getCountriesByLanguages(LanguageType.FRENCH.getValue());
	}
	
	public List<CountryProvince> getProvinces() {
		return super.getProvincesByLanguages(LanguageType.FRENCH.getValue());
	}
}
