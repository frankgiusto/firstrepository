/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.PhysicalFilesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.PhysicalFiles;

/**
 * The PhysicalFilesDaoImpl retrieves data from the PHYSICAL_FILES Table using Hibernate.
 */
@Repository("physicalFilesDao")
public class PhysicalFilesDaoImpl extends HibernateBaseDao implements PhysicalFilesDao {

    private static final long serialVersionUID = 5778089496474900250L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(PhysicalFilesDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<PhysicalFiles> getPhysicalFiles(Integer fileNumber, Integer fileType) {
        List<PhysicalFiles> physicalFiles = new ArrayList<PhysicalFiles>();
        try {
            Criteria criteria = getSession().createCriteria(PhysicalFiles.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.PHYSICAL_FILES_ID_FILE_TYPE.getValue(), fileType));
            physicalFiles = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving physical files with parameters [" + fileNumber + ", " + fileType + "]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<PhysicalFiles>(physicalFiles);
    }

    /** {@inheritDoc} */
    @Override
    public Set<PhysicalFiles> getPhysicalFiles(Integer fileNumber, Integer fileType, String locationAuthorityId) {
        List<PhysicalFiles> physicalFiles = new ArrayList<PhysicalFiles>();
        try {
            Criteria criteria = getSession().createCriteria(PhysicalFiles.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            physicalFiles = super.findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Error retrieving physical files with parameters [" + fileNumber + ", " + fileType + ", "
                + locationAuthorityId + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<PhysicalFiles>(physicalFiles);
    }

    @Override
    public void savePhysicalFiles(PhysicalFiles physicalFiles) {
        Session session = getSession();
        session.saveOrUpdate(physicalFiles);
    }
}
