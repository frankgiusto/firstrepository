package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;
import java.util.List;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

public class OrExpression implements Expression, Serializable {

    private static final long serialVersionUID = 7011179918891718980L;

    private List<Expression> expList;

    public OrExpression(List<Expression> expList) {
        this.expList = expList;
    }

    public List<Expression> getExpList() {
        return expList;
    }

    public void setExpList(List<Expression> expList) {
        this.expList = expList;
    }

    @Override
    public Disjunction compose() {
        Disjunction disjunction = null;

        if (this.expList != null && !this.expList.isEmpty()) {
            disjunction = Restrictions.disjunction();
            for (Expression exp : this.expList) {
                disjunction.add((Criterion) exp.compose());
            }
        }
        return disjunction;
    }

    @Override
    public void accept(ExpressionVisitor expressionVisitor) {
        // do nothing

    }

}
