/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.OppositionCaseActionDao;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.Pair;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.enumerator.OppositionCaseActionCodeType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCaseAction;

/**
 * The OppositionCaseActionDaoImpl retrieves data from the OPPOSITION_CASE_ACTIONS Table using Hibernate.
 *
 * @see oppositionCaseActionDao
 * @see HibernateBaseDAO
 */
@Repository("oppositionCaseActionDao")
public class OppositionCaseActionDaoImpl extends HibernateBaseDao implements OppositionCaseActionDao {

    private static final long serialVersionUID = -526637620983726598L;

    private static final String PREVIOUS_DEADLINE_DATE_SQL = "select distinct {ca.*} from OPPOSITION_CASE_ACTIONS ca where ca.OPP_STAGE_CODE = :oppStageCode and ca.OPP_ACTION_CODE = :oppActionCode and ca.OPP_ACTION_TYPE = :oppActionTypeCode and ca.FILE_NUMBER = :fileNumber and ca.EXTENSION_COUNTER = :extCounter and ca.OPP_CASE_NUMBER = :oppCaseNumber";

    private static final String AVAILABLE_CASE_ACTIONS_SQL = "  select {oca.*} from OPPOSITION_CASE_ACTIONS oca where oca.FILE_NUMBER = :fileNumber and oca.EXTENSION_COUNTER = :extCounter "
        + " and oca.OPP_CASE_NUMBER = :oppCaseNumber and oca.OPP_ACTION_TYPE = :oppActionType and decode(oca.DELETE_CODE, NULL, 0 , oca.DELETE_CODE) = 0  and oca.OPP_ACTION_CODE IN ( :actionCodes ) and "
        + "(TRUNC(oca.EFFECTIVE_DATE) >= TRUNC(sysdate) OR (SELECT rtrim(TO_CHAR(TRUNC(oca.EFFECTIVE_DATE),'DAY')) FROM dual) IN ('SATURDAY','SUNDAY') OR ((SELECT COUNT(*) FROM DIES_NONS WHERE dies_date  = TRUNC(oca.EFFECTIVE_DATE) AND tmo_open_ind = 0)>0))";

    @Override
    public OppositionCaseAction getPreviousDeadlineDateForOpposition(OppositionCaseAction oppositionCaseAction) {
        List<Pair<String, Object>> params = new ArrayList<>();
        params.add(new Pair<String, Object>("oppStageCode", oppositionCaseAction.getOppStageCode()));
        params.add(new Pair<String, Object>("oppActionCode", oppositionCaseAction.getOppActionCode()));
        params.add(new Pair<String, Object>("oppActionTypeCode", oppositionCaseAction.getOppActionType()));
        params.add(new Pair<String, Object>("fileNumber", oppositionCaseAction.getFileNumber()));
        params.add(new Pair<String, Object>("extCounter", oppositionCaseAction.getExtensionCounter()));
        params.add(new Pair<String, Object>("oppCaseNumber", oppositionCaseAction.getOppCaseNumber()));
        Map<String, Object> parameters = QueryHelper.fillParameters(params);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(PREVIOUS_DEADLINE_DATE_SQL, parameters);
        sqlQuery.addEntity("ca", OppositionCaseAction.class);

        OppositionCaseAction result = (OppositionCaseAction) sqlQuery.uniqueResult();
        return result;
    }

    @Override
    public List<OppositionCaseAction> getOppositionCaseActions(ApplicationNumber applicationNumber,
                                                               Integer caseNumber) {
        List<OppositionCaseAction> oppositionCaseActions = new ArrayList<OppositionCaseAction>();
        try {
            Objects.requireNonNull(applicationNumber);
            Objects.requireNonNull(caseNumber);

            Criteria criteria = getSession().createCriteria(OppositionCaseAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
            oppositionCaseActions = super.findByCriteria(criteria);

        } catch (Throwable ex) {
            if (applicationNumber != null && caseNumber != null) {
                logger.error("Problem in retrieving Opposition Case Action(s) with parameters ["
                    + applicationNumber.getFileNumber() + ", " + applicationNumber.getExtensionCounter() + ", "
                    + caseNumber + "]\n" + ex.getMessage(), ex);
            }
            throw new DataAccessException(ex);
        }
        return oppositionCaseActions;
    }

    @Override
    public OppositionCaseAction getOppositionCaseAction(ApplicationNumber applicationNumber, Integer caseNumber,
                                                        Integer oppStageCode, Integer oppActionCode) {
        OppositionCaseAction oppositionCaseAction = null;
        try {
            Objects.requireNonNull(applicationNumber);
            Objects.requireNonNull(caseNumber);
            Objects.requireNonNull(oppStageCode);
            Objects.requireNonNull(oppActionCode);
            Criteria criteria = getSession().createCriteria(OppositionCaseAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_STAGE_CODE.getValue(), oppStageCode));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_ACTION_CODE.getValue(), oppActionCode));
            oppositionCaseAction = super.findUniqueByCriteria(criteria);

        } catch (Throwable ex) {
            if (applicationNumber != null && caseNumber != null && oppStageCode != null && oppActionCode != null) {
                logger.error("Problem in retrieving Opposition Case Action(s) with parameters ["
                    + applicationNumber.getFileNumber() + ", " + applicationNumber.getExtensionCounter() + ", "
                    + caseNumber + ", " + oppStageCode + ", " + oppActionCode + "]\n" + ex.getMessage(), ex);
            }
            throw new DataAccessException(ex);
        }
        return oppositionCaseAction;
    }

    @Override
    public boolean isCoolingOffAllowedForOppositionCase(ApplicationNumber applicationNumber, Integer caseNumber,
                                                        Integer oppActionCode) {

        List<OppositionCaseAction> oppositionCaseActions = Collections.<OppositionCaseAction> emptyList();

        try {
            Objects.requireNonNull(applicationNumber);
            Objects.requireNonNull(caseNumber);
            Objects.requireNonNull(oppActionCode);
            Criteria criteria = getSession().createCriteria(OppositionCaseAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_ACTION_CODE.getValue(), oppActionCode));
            oppositionCaseActions = super.findByCriteria(criteria);

        } catch (Throwable ex) {
            if (applicationNumber != null && caseNumber != null && oppActionCode != null) {
                logger.error("Problem in retrieving Opposition Case Action(s) with parameters ["
                    + applicationNumber.getFileNumber() + ", " + applicationNumber.getExtensionCounter() + ", "
                    + oppActionCode + "]\n" + ex.getMessage(), ex);
            }
            throw new DataAccessException(ex);
        }

        return (!oppositionCaseActions.isEmpty());
    }

    @Override
    public List<OppositionCaseAction> getActiveOppositionCaseActions(ApplicationNumber applicationNumber,
                                                                     Integer oppCaseNumber, Integer oppActionType) {
        Objects.requireNonNull(applicationNumber);
        Objects.requireNonNull(oppCaseNumber);
        Objects.requireNonNull(oppActionType);

        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", applicationNumber.getFileNumber());
        parameters.put("extCounter", applicationNumber.getExtensionCounter());
        parameters.put("oppCaseNumber", oppCaseNumber);
        parameters.put("oppActionType", oppActionType);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(AVAILABLE_CASE_ACTIONS_SQL, parameters);
        // action codes
        sqlQuery.setParameterList("actionCodes", OppositionCaseActionCodeType.actionCodesAvailableActionsList());
        sqlQuery.addEntity("oca", OppositionCaseAction.class);

        @SuppressWarnings("unchecked")
        List<OppositionCaseAction> results = sqlQuery.list();
        return results;
    }

    @Override
    public List<OppositionCaseAction> getOppositionCaseActions(Integer fileNumber, Integer extensionCounter,
                                                               Integer caseNumber) {
        List<OppositionCaseAction> oppositionCaseActions = new ArrayList<OppositionCaseAction>();
        try {
            Criteria criteria = getSession().createCriteria(OppositionCaseAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
            oppositionCaseActions = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Opposition Case Action  of Application with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + caseNumber + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return oppositionCaseActions;
    }

    @Override
    public OppositionCaseAction getOppositionCaseAction(ApplicationNumber applicationNumber, Integer caseNumber,
                                                        Integer actionCode) {
        try {
            Criteria criteria = getSession().createCriteria(OppositionCaseAction.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));

            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_OPP_ACTION_CODE.getValue(), actionCode));

            criteria.addOrder(Order.desc(ModelPropertyType.OPPOSITION_CASE_ACTION_ID_ACTION_DATE.getValue()));

            List<OppositionCaseAction> results = super.findByCriteria(criteria);
            if (!CollectionUtils.isEmpty(results)) {
                return results.get(0);
            }

        } catch (Exception ex) {
            logger.error("There are no Opposition Case Action  of Application with parameters ["
                + applicationNumber.getFileNumber() + ", " + applicationNumber.getExtensionCounter() + ", " + actionCode
                + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new OppositionCaseAction();
    }

}
