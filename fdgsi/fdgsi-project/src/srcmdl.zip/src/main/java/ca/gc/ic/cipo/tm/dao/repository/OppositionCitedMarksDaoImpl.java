package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OppositionCitedMarksDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.OppositionCitedMarks;

@Repository("oppositionCitedMarksDao")
public class OppositionCitedMarksDaoImpl extends HibernateBaseDao implements OppositionCitedMarksDao {

    private static final long serialVersionUID = 1683519420728415650L;

    @Override
    /** @{inheritDoc} */
    public List<OppositionCitedMarks> getOppositionCitedMarks(ApplicationNumber applicationNumber,
                                                              Integer oppositionSeqNumber) {

        List<OppositionCitedMarks> oppositionCitedMarks = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(OppositionCitedMarks.class);
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_CITED_MARKS_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_CITED_MARKS_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_CITED_MARKS_SEQUENCE_NUMBER.getValue(),
                oppositionSeqNumber));
            oppositionCitedMarks = super.findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Problem in retrieving Opposition Cited Marks for file number  [" + applicationNumber
                + " and opposition sequence number " + oppositionSeqNumber + " ] " + System.lineSeparator()
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return oppositionCitedMarks;
    }

    @Override
    /** @{inheritDoc} */
    public List<OppositionCitedMarks> getOppositionCitedMarksByOppositionSequenceNumber(Integer oppositionSeqNumber) {

        List<OppositionCitedMarks> oppositionCitedMarks = new ArrayList<>();
        try {
            Criteria criteria = getSession().createCriteria(OppositionCitedMarks.class);
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_CITED_MARKS_SEQUENCE_NUMBER.getValue(),
                oppositionSeqNumber));
            oppositionCitedMarks = super.findByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("Problem in retrieving Opposition Cited Marks for opposition grounds sequence number  ["
                + oppositionSeqNumber + " ] " + System.lineSeparator() + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return oppositionCitedMarks;
    }

    @Override
    public void saveOppositionCitedMarks(OppositionCitedMarks oppositionCitedMarks) {
        super.saveOrUpdateEntity(OppositionCitedMarks.class, oppositionCitedMarks);
    }

}
