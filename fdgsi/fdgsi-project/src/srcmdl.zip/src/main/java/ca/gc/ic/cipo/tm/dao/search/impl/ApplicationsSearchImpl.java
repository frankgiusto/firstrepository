package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.repository.HibernateBaseDao;
import ca.gc.ic.cipo.tm.dao.search.ApplicationsSearch;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@Repository("applicationsSearch")
public class ApplicationsSearchImpl extends HibernateBaseDao implements ApplicationsSearch {

    private static final long serialVersionUID = -7759425854974997368L;

    @Override
    /** @{inheritDoc} */
    public List<Application> searchApplications(List<Expression> expressions, HibernateOperatorEnum searchOperator) {

        QueryAndParams queryAndParams = ApplicationsSearchQueryHelper.createNativeSQLQuery(expressions, searchOperator);
        return executeQueryAndGet(queryAndParams);
    }

    private List<Application> executeQueryAndGet(QueryAndParams queryAndParams) {
        // final sql
        String finalSQL = queryAndParams.getSqlQuery();

        // map of parameter name along with the values
        Map<String, Object> paramsMap = queryAndParams.getParamsMap();

        // multi value map of parameters list (if applicable)
        MultiValueMap<String, Object> parameterListMap = queryAndParams.getParameterListMap();

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(finalSQL, paramsMap);
        QueryHelper.populateSQLQueryWithParametersListIfApplicable(parameterListMap, sqlQuery);

        @SuppressWarnings("unchecked")
        List<Application> results = sqlQuery.addEntity("AP", Application.class).list();
        return results;
    }

}
