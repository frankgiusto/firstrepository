package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.GoodsServicesTextDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.GoodServiceTextId;

@Repository("goodsServicesTextDao")
public class GoodsServicesTextDaoImpl extends HibernateBaseDao implements GoodsServicesTextDao {

    private static final long serialVersionUID = -6877797649452771965L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(GoodsServicesTextDaoImpl.class);

    @Override
    public List<GoodServiceText> getGoodServiceText(ApplicationNumber applicationNumber) {
        List<GoodServiceText> goodServiceTexts = new ArrayList<GoodServiceText>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            goodServiceTexts = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Good Service Text with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return goodServiceTexts;
    }

    @Override
    public List<GoodServiceText> getGoodServiceText(Application application) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceText(applicationNumber);
    }

    @Override
    public List<GoodServiceText> getGoodServiceText(ApplicationNumber applicationNumber, Integer goodServiceType,
                                                    Integer goodServiceNumber) {
        List<GoodServiceText> goodServiceTexts = new ArrayList<GoodServiceText>();
        try {
            Criteria criteria = getSession().createCriteria(GoodServiceText.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_TYPE.getValue(), goodServiceType));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_NUMBER.getValue(), goodServiceNumber));
            goodServiceTexts = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Good Service Text with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + ", " + goodServiceType + ", " + goodServiceNumber + "]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return goodServiceTexts;
    }

    @Override
    public List<GoodServiceText> getGoodServiceText(Application application, Integer goodServiceType,
                                                    Integer goodServiceNumber) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceText(applicationNumber, goodServiceType, goodServiceNumber);
    }

    @Override
    public List<GoodServiceText> getGoodServiceText(ApplicationNumber applicationNumber, Integer goodServiceType,
                                                    Integer goodServiceNumber, Integer originalInd) {
        List<GoodServiceText> goodServiceTexts = new ArrayList<GoodServiceText>();
        try {
            Criteria criteria = getSession().createCriteria(GoodService.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_TYPE.getValue(), goodServiceType));
            criteria.add(Restrictions.eq(ModelPropertyType.GOOD_SERVICE_CLAIM_ID_NUMBER.getValue(), goodServiceNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.WARE_SERVICE_TEXT_ID_ORIGINAL_IND.getValue(), originalInd));
            goodServiceTexts = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Good Service Text with parameters [" + applicationNumber.getFileNumber() + ", "
                + applicationNumber.getExtensionCounter() + ", " + goodServiceType + ", " + goodServiceNumber + ", "
                + originalInd + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return goodServiceTexts;
    }

    @Override
    public List<GoodServiceText> getGoodServiceText(Application application, Integer goodServiceType,
                                                    Integer goodServiceNumber, Integer originalInd) {
        ApplicationNumber applicationNumber = new ApplicationNumber(application.getFileNumber(),
            application.getExtensionCounter());
        return this.getGoodServiceText(applicationNumber, goodServiceType, goodServiceNumber, originalInd);
    }

    @Override
    public List<GoodServiceText> getGoodServiceText(GoodServiceTextId goodServiceTextId) {
        ApplicationNumber applicationNumber = new ApplicationNumber(goodServiceTextId.getFileNumber(),
            goodServiceTextId.getExtensionCounter());
        return this.getGoodServiceText(applicationNumber, goodServiceTextId.getType(), goodServiceTextId.getNumber(),
            goodServiceTextId.getOriginalInd());
    }

    @Override
    public void saveGoodServiceText(GoodServiceText goodServiceText) {

        Session session = getSession();
        session.saveOrUpdate(goodServiceText);

    }

    @Override
    public void deleteGoodServiceText(GoodServiceText goodServiceText) {
        try {
            delete(goodServiceText);
        } catch (Exception he) {
            String message = "Could not delete " + goodServiceText.toString() + " - message: " + he.getMessage();
            throw new DataAccessException(message, he);
        }
    }
}
