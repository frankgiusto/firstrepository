/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.model.MadridApplicationXref;

/**
 * @author giustof
 *
 */
public interface MadridApplicationXrefDao {

    public void saveMadridApplicationXref(MadridApplicationXref madridApplicationXref);

    public void deleteMadridApplicationXref(int fileNumber, int extensionCounter, String wipoReferenceNumber);

    public Long countMadridApplicationXref(String wipoReferenceNumber);
}
