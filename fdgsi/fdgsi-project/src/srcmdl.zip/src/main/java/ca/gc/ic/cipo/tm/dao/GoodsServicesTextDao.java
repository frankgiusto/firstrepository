package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodServiceText;
import ca.gc.ic.cipo.tm.model.GoodServiceTextId;

public interface GoodsServicesTextDao {

    public List<GoodServiceText> getGoodServiceText(ApplicationNumber applicationNumber);

    public List<GoodServiceText> getGoodServiceText(Application application);

    public List<GoodServiceText> getGoodServiceText(ApplicationNumber applicationNumber, Integer goodServiceType,
                                                    Integer goodServiceNumber);

    public List<GoodServiceText> getGoodServiceText(Application application, Integer goodServiceType,
                                                    Integer goodServiceNumber);

    public List<GoodServiceText> getGoodServiceText(ApplicationNumber applicationNumber, Integer goodServiceType,
                                                    Integer goodServiceNumber, Integer originalInd);

    public List<GoodServiceText> getGoodServiceText(Application application, Integer goodServiceType,
                                                    Integer goodServiceNumber, Integer originalInd);

    public List<GoodServiceText> getGoodServiceText(GoodServiceTextId goodServiceTextId);

    public void saveGoodServiceText(GoodServiceText goodServiceText);

    /**
     * Delete goods services text.
     *
     * @param goodServiceText the good service text
     */
    public void deleteGoodServiceText(GoodServiceText goodServiceText);
}
