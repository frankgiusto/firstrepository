package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.TrademarkDao;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FigurativeElement;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.model.TradeMarkInfo;

@Repository("trademarkDao")
public class TrademarkDaoImpl extends HibernateBaseDao implements TrademarkDao {

    private static final long serialVersionUID = 4158315158162349316L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(TrademarkDaoImpl.class);

    private static final String TRADE_MARK_INFO_SQL = " select TM.TEXT as trademarkName, APP.TRADE_MARK_CLASS as trademarkClass, "
        + " TM.FILE_NUMBER as fileNumber , app_t.TEXT as fullDescription from TRADE_MARKS tm inner join APPLICATIONS app on tm.FILE_NUMBER = app.FILE_NUMBER "
        + " left join APPLICATION_TEXTS app_t on app_t.FILE_NUMBER = tm.FILE_NUMBER and app_t.TEXT_TYPE = :textType "
        + " where tm.FILE_NUMBER = :fileNumber ";
//TODO should not return a list, one to one association
    @Override
    public List<TradeMark> getTrademark(Application application) {
        List<TradeMark> trademarks = new ArrayList<TradeMark>();
        trademarks.add(this.getTrademark(application.getFileNumber()));
        return trademarks;
    }

    @Override
    public TradeMark getTrademark(Integer fileNumber) {
        return super.find(TradeMark.class, fileNumber);
    }

    @Override
    public Set<FigurativeElement> getTradeMarkFigurativeElements(ApplicationNumber applicationNumber) {
        TradeMark tradeMark = this.getTrademark(applicationNumber.getFileNumber());
        return tradeMark.getFigurativeElements();

    }

    @Override
    public List<TradeMarkInfo> getTradeMarkInfo(ApplicationNumber applicationNumber) {
        List<TradeMarkInfo> results = doGetBasicTradeMarkInfo(applicationNumber, 30);
        return results;
    }

    @Override
    public List<TradeMarkInfo> getTradeMarkInfo(ApplicationNumber applicationNumber, Integer type) {
        List<TradeMarkInfo> results = doGetBasicTradeMarkInfo(applicationNumber, type);
        return results;
    }

    private List<TradeMarkInfo> doGetBasicTradeMarkInfo(ApplicationNumber applicationNumber, Integer type) {
        checkApplicationNumber(applicationNumber);
        LOG.debug("About to retrieve TradeMark info");
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", applicationNumber.getFileNumber());
        parameters.put("textType", type);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(TRADE_MARK_INFO_SQL, parameters);
        sqlQuery.addScalar("trademarkName", StringType.INSTANCE).addScalar("fullDescription", StringType.INSTANCE)
            .addScalar("trademarkClass", IntegerType.INSTANCE);
        sqlQuery.addScalar("fileNumber", IntegerType.INSTANCE);
        sqlQuery.setResultTransformer(new AliasToBeanResultTransformer(TradeMarkInfo.class));

        @SuppressWarnings("unchecked")
        List<TradeMarkInfo> results = sqlQuery.list();
        LOG.debug("Retrieved TradeMark info");
        return results;
    }

    private void checkApplicationNumber(ApplicationNumber applicationNumber) {
        Objects.requireNonNull(applicationNumber, "Invalid Application Number: must not be blank or null");
    }

    @Override
    public void saveTrademark(TradeMark trademark) {
        LOG.debug("About to save TradeMark info");
        Session session = getSession();
        session.saveOrUpdate(trademark);
        LOG.debug("TradeMark info saved successfully");
    }
}
