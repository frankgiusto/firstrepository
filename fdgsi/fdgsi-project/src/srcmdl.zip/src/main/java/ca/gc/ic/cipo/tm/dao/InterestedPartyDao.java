package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.InterestedParty;

/**
 * The InterestedPartyDao is the interface to retrieve Applicant/Agents from and application.
 *
 * @author SeguinA3
 * @version 1.0
 */
public interface InterestedPartyDao {

    /**
     * Retrieves and return the Interested Party by the file number, extension counter and the IpNumber
     */
    public InterestedParty getInterestedPartyByIpNumber(Integer fileNumber, Integer extensionCounter, Integer ipNumber);

    /**
     * Retrieves and return the Interested Party by the file number and IP number.
     */
    public InterestedParty getInterestedPartyByIpNumber(ApplicationNumber applicationNumber, Integer ipNumber);

    /**
     * Save or update the IP record
     *
     * @param interestedParty
     */
    public void saveInterestedParty(InterestedParty interestedParty);

    /**
     * This method will retrieve the Interested Party by file number, extension counter and relationship Type.
     */
    public InterestedParty getInterestedPartyByFileNumberExtensionCounterRelationshipType(Integer fileNumber,
                                                                                          Integer extensionCounter,
                                                                                          Integer relationshipType);

    /**
     * Returns the IP information for primary applicant by application number
     */
    public InterestedParty getApplicant(ApplicationNumber applicationNumber);

    /**
     * Returns the IP information for primary applicant by application number
     */
    public InterestedParty getApplicant(Integer fileNumber, Integer extCounter);

    /**
     * Retrieves and returns the IP for Opposition case
     *
     * @param applicationNumber the application file number
     * @param caseNumber the opposition case number
     * @return the list of InterestedParty objects
     */
    public List<InterestedParty> getInterestedPartiesForOppositionCase(ApplicationNumber applicationNumber,
                                                                       Integer caseNumber);

    /**
     * Returns the next IP number for the specific file number and extension counter
     *
     * @param fileNumber the application file number
     * @param extCounter the extension counter
     * @return the next IP number; can return NULL if no file number is found in IP table
     */
    public Integer getNextIpNumber(Integer fileNumber, Integer extCounter);

    /**
     * Retrieves and return the IP by file number and relationship type
     *
     * @param applicationNumber the application number
     * @param ipNumber the IP number
     * @param relationshipType the type of the relationship
     * @return the InterestedParty model object
     */
    public InterestedParty getInterestedPartyByFileNumberIPNumberAndRelationshipType(ApplicationNumber applicationNumber,
                                                                                     Integer ipNumber,
                                                                                     Integer relationshipType);

    /**
     *
     * @param fileNumber
     * @param extensionCounter
     * @param relationshipType
     * @return
     */
    Integer getIPNumberByFileNumberExtensionCounterRelationshipType(Integer fileNumber, Integer extensionCounter,
                                                                    Integer relationshipType);

    /**
     * Retrieve a list of type InterestedParty objects based on supplied file number, extension counter and relationship
     * type
     * 
     * @param fileNumber the file number
     * @param extensionCounter the extension counter
     * @param relationshipType the relationship type
     * @return the list of type InterestedParty objects
     */
    List<InterestedParty> getInterestedPartiesByApplicationNumberAndRelationshipType(Integer fileNumber,
                                                                                     Integer extensionCounter,
                                                                                     Integer relationshipType);
}
