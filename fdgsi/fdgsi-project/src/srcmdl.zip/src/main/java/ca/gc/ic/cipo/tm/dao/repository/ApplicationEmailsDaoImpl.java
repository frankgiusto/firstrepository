/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.ApplicationEmailsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationEmails;
import ca.gc.ic.cipo.tm.model.ApplicationEmailsId;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;

/**
 * The ApplicationEmailsDaoImpl retrieves data from the APPLICATION_EMAILS table using Hibernate.
 *
 * @see ApplicationEmailsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
@Repository("applicationEmailsDao")
public class ApplicationEmailsDaoImpl extends HibernateBaseDao implements ApplicationEmailsDao {

    /**
     *
     */
    private static final long serialVersionUID = 3835839238055816968L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(ApplicationEmailsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(Integer fileNumber, Integer extensionCounter) {
        // TODO Auto-generated method stub
        List<ApplicationEmails> applicationEmails = new ArrayList<ApplicationEmails>();
        try {
            Criteria criteria = getSession().createCriteria(ApplicationEmails.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            applicationEmails = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application emails with parameters [" + fileNumber + ", " + extensionCounter
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<ApplicationEmails>(applicationEmails);
    }

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(Integer fileNumber, Integer extensionCounter, Integer emailSeq) {
        // TODO Auto-generated method stub
        List<ApplicationEmails> applicationEmails = new ArrayList<ApplicationEmails>();
        try {
            Criteria criteria = getSession().createCriteria(ApplicationEmails.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_EMAILS_ID_EMAIL_SEQ.getValue(), emailSeq));
            applicationEmails = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving application emails  with parameters [" + fileNumber + ", " + extensionCounter
                + ", " + emailSeq + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<ApplicationEmails>(applicationEmails);
    }

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getApplicationEmails(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(Application application) {
        // TODO Auto-generated method stub
        return this.getApplicationEmails(
            new ApplicationNumber(application.getFileNumber(), application.getExtensionCounter()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(ApplicationNumber applicationNumber, Integer emailSeq) {
        // TODO Auto-generated method stub
        return this.getApplicationEmails(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(),
            emailSeq);
    }

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(Application application, Integer emailSeq) {
        // TODO Auto-generated method stub
        return this.getApplicationEmails(application.getFileNumber(), application.getExtensionCounter(), emailSeq);
    }

    /** {@inheritDoc} */
    @Override
    public Set<ApplicationEmails> getApplicationEmails(ApplicationNumber applicationNumber,
                                                       ApplicationEmailsId applicationEmailsId) {
        // TODO Auto-generated method stub
        return this.getApplicationEmails(applicationNumber, applicationEmailsId.getEmailSeq());
    }

    @Override
    public void saveApplicationEmails(ApplicationEmails applicationEmails) {
        // TODO Auto-generated method stub
        Session session = getSession();
        session.saveOrUpdate(applicationEmails);
    }

}
