package ca.gc.ic.cipo.tm.dao.repository;

import java.io.Serializable;

/**
 * Base Dao interface - can be extended by Dao interfaces. Contract for common operations. The implementation is
 * provided by HibernateBaseDao.
 *
 * @author sagary
 */
public interface BaseDao {

    /**
     * Save or update the specified Entity object
     *
     * @param entity the Entity class type
     * @param obj the entity object to save
     */
    public <T extends Serializable> void saveOrUpdateEntity(Class<T> entity, Object obj);

    /**
     * Save a specified Entity object
     *
     * @param entity the entity class type to
     * @param obj the object instance of the entity
     */
    <T extends Serializable> void saveEntity(Class<T> entity, Object obj);

    /**
     * Flushes changes in the Hibernate cache to the data store. Provided as a convenience for DAO implementations to
     * provide capability for flushing the session independently of save.
     */
    void flush();

}
