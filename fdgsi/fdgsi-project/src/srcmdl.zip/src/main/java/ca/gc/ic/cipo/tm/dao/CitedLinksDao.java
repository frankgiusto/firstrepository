package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.CitedLinks;

/**
 * Contract for CitedLinks data access
 */
public interface CitedLinksDao {

    /**
     * Retrieve and return a list of CitedLinks for the specified application number and other cited linked related
     * parameters
     */
    public List<CitedLinks> getCitedLinks(ApplicationNumber applicationNumber, Integer citedSectionNumber,
                                          Integer citedFileNumber, Integer citedExtensionCounter);

    /**
     * Retrieve and return a list of Cited links for the specified application number
     * 
     * @param applicationNumber the application file number
     * @return the collection of type CitedLinks objects
     */
    List<CitedLinks> getCitedLinksForFileNumber(ApplicationNumber applicationNumber);

    /**
     * Save a single CitedLinks record in the DB
     * 
     * @param citedLinks the CitedLinks object
     */
    public void saveCitedLinks(CitedLinks citedLinks);

}
