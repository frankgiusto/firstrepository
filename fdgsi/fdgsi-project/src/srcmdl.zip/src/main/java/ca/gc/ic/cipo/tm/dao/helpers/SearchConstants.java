package ca.gc.ic.cipo.tm.dao.helpers;

/**
 * This class hold the values for the search criteria type and returned parameters for TM reg-renewal search methods
 *
 * @author Peloquip
 *
 */
public enum SearchConstants {

    /** Search File number */
    SEARCH_FILE_NUMBER("fileNumber"),
    /** Search Extension counter */
    SEARCH_EXTENSION_COUNTER("extensionCounter"),
    /** Search Registration number */
    SEARCH_REGISTRATION_NUMBER("registrationNumber"),
    /** Search legislation */
    SEARCH_LEGISLATION("legislation"),
    /** Search trademark text */
    SEARCH_TRADEMARK_TEXT("trademarkText"),
    /** Search applicant name */
    SEARCH_APPLICANT_NAME("applicantName"),
    /** Search additional info */
    SEARCH_ADDITIONAL_INFO("additionalInfo"),
    /** Search Requestor User Id */
    SEARCH_REQUESTOR_USER_ID("requestorUserId"),
    /** Search response date */
    SEARCH_RESPONSE_DATE("responseDate"),
    /** Search request date */
    SEARCH_REQUEST_DATE("requestDate"),
    /** Search start date */
    SEARCH_START_DATE("startDate"),
    /** Search end date */
    SEARCH_END_DATE("endDate"),
    /** Search trademark name */
    SEARCH_TRADEMARK_NAME("trademarkName"),
    /** Search renewal due date */
    SEARCH_RENEWAL_DUE_DATE("renewalDueDate"),
    /** Search not before date */
    SEARCH_NOT_BEFORE_DATE("notBeforeDate"),
    /** Search not after date */
    SEARCH_NOT_AFTER_DATE("notAfterDate"),

    /** Search confirmation number */
    SEARCH_CONFIRMATION_NUMBER("confirmationNumber"),
    /** Search transaction type */
    SEARCH_TRANSACTION_TYPE("transactionType"),
    /** Search status */
    SEARCH_TRANSACTION_STATUS("status"),
    /** Search document type */
    SEARCH_DOCUMENT_TYPE("documentType"),
    /** Search registration certificate exists */
    SEARCH_REGISTRATION_CERTIFICATE_EXISTS("registrationCertificateExists"),
    /** Search registration page exists */
    SEARCH_REGISTRATION_PAGE_EXISTS("registrationPageExists"),
    /** Search declaration of use exists */
    SEARCH_DECLARATION_OF_USE_EXISTS("declarationOfUseExists"),
    /** Search extension of time exists */
    SEARCH_EXTENSION_OF_TIME_EXISTS("extensionOfTimeExists"),
    /** Search renewal page exists */
    SEARCH_RENEWAL_PAGE_EXISTS("renewalPageExists"),
    /** Agent reference number */
    SEARCH_AR_NUMBER("arNumber"),
    /** looseMail */
    SEARCH_LOOSE_MAIL("looseMail"),
    /** Pending owner */
    SEARCH_PENDING_OWNER("pendingOwner"),
    /** Pending seizure */
    SEARCH_PENDING_SEIZURE("pendingSeizure"),
    /** assignmentWorksheet */
    SEARCH_ASSIGNMENT_WORKSHEET("assignmentWorksheet"),
    /** seizure */
    SEARCH_SEIZURE("seizure"),
    /** Allowed response date */
    SEARCH_ALLOWED_RESPONSE_DATE("allowedResponseDate"),
    /** Last application date */
    SEARCH_LAST_APPICATION_DATE("lastApplicationDate"),
    /** Search owner name */
    SEARCH_OWNER_NAME("ownerName"),
    /** Search due date */
    SEARCH_DUE_DATE("dueDate");

    private String value;

    private SearchConstants(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
