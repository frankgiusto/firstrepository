package ca.gc.ic.cipo.tm.dao.repository;

import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OppositionActionCodesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.OppositionActionCodes;

/**
 * This daoImpl retrieves data from the OPPOSITION_ACTION_CODES table
 *
 * @author duanj
 *
 */
@Repository("oppositionActionCodesDao")
public class OppositionActionCodesDaoImpl extends HibernateBaseDao implements OppositionActionCodesDao {

    private static final long serialVersionUID = -2032729166761935864L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(OppositionActionCodesDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public OppositionActionCodes getOppositionActionCodes(Integer oppStageCode, Integer oppActionCode,
                                                          Integer oppActionType) {
        OppositionActionCodes oppActionCodes = new OppositionActionCodes();

        Objects.requireNonNull(oppStageCode);
        Objects.requireNonNull(oppActionCode);
        Objects.requireNonNull(oppActionType);

        try {
            Criteria criteria = getSession().createCriteria(OppositionActionCodes.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.OPPOSITION_ACTION_CODES_ID_OPP_STAGE_CODE.getValue(), oppStageCode));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_ACTION_CODES_ID_OPP_ACTION_CODE.getValue(),
                oppActionCode));
            criteria.add(Restrictions.eq(ModelPropertyType.OPPOSITION_ACTION_CODES_ID_OPP_ACTION_TYPE.getValue(),
                oppActionType));

            oppActionCodes = findUniqueByCriteria(criteria);
        } catch (Exception ex) {
            logger.error("There is no OppositionActionCodes object with given codes ("
                + oppActionCodes.getOppStageCode() + ", " + oppActionCodes.getOppActionCode() + ", "
                + oppActionCodes.getOppActionType() + ", " + ")/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return oppActionCodes;
    }

}
