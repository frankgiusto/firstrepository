package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.IndexHeading;

public interface IndexHeadingsDao {

    public List<IndexHeading> getIndexHeadings(ApplicationNumber applicationNumber);

    // TODO remove, Application is an ApplicationNumber
    @Deprecated
    public List<IndexHeading> getIndexHeadings(Application application);

    // TODO, should return a single IndexHeading, PK
    public List<IndexHeading> getIndexHeadings(ApplicationNumber applicationNumber, Integer sequenceNumber);

    // TODO remove, Application is an ApplicationNumber
    @Deprecated
    public List<IndexHeading> getIndexHeadings(Application application, Integer sequenceNumber);
}
