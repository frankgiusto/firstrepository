/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.OralHearingDetailsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.OppositionCase;
import ca.gc.ic.cipo.tm.model.OppositionCaseId;
import ca.gc.ic.cipo.tm.model.OralHearingDetails;

/**
 * The OralHearingAttendeesDaoImpl retrieves data from the ORAL_HEARING_DETAILS Table using Hibernate.
 *
 * @see OralHearingDetailsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("oralHearingDetailsDao")

public class OralHearingDetailsDaoImpl extends HibernateBaseDao implements OralHearingDetailsDao {

    /**
     *
     */
    private static final long serialVersionUID = 59561057568441183L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(OralHearingDetailsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    // TODO not used for now I think, not reviewed
    @Deprecated
    public Set<OralHearingDetails> getOralHearingDetails(Integer fileNumber, Integer extensionCounter,
                                                         Integer oppCaseNumber) {
        // TODO Auto-generated method stub
        List<OralHearingDetails> oralHearingDetails = new ArrayList<OralHearingDetails>();
        try {
            Criteria criteria = getSession().createCriteria(OralHearingDetails.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria
                .add(Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ID_OPP_CASE_NUMBER.getValue(), oppCaseNumber));
            oralHearingDetails = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving oral hearing attendees with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + oppCaseNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<OralHearingDetails>(oralHearingDetails);
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingDetails> getOralHearingDetails(OppositionCaseId oppositionCaseId) {
        // TODO Auto-generated method stub
        return this.getOralHearingDetails(oppositionCaseId.getFileNumber(), oppositionCaseId.getExtensionCounter(),
            oppositionCaseId.getOppCaseNumber());
    }

    /** {@inheritDoc} */
    @Override
    public Set<OralHearingDetails> getOralHearingDetails(OppositionCase oppostionCase) {
        // TODO Auto-generated method stub
        return this.getOralHearingDetails(new OppositionCaseId(oppostionCase.getFileNumber(),
            oppostionCase.getExtensionCounter(), oppostionCase.getOppCaseNumber()));
    }

}
