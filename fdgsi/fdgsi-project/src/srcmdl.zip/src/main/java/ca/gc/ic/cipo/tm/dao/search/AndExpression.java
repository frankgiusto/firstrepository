package ca.gc.ic.cipo.tm.dao.search;

import java.io.Serializable;
import java.util.List;

import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class AndExpression implements Expression, Serializable {

    private static final long serialVersionUID = 7130578679011772735L;

    private List<Expression> expList;

    public AndExpression(List<Expression> expList) {
        this.expList = expList;
    }

    public List<Expression> getExpList() {
        return expList;
    }

    public void setExpList(List<Expression> expList) {
        this.expList = expList;
    }

    @Override
    public Conjunction compose() {
        Conjunction conjunction = null;

        if (this.expList != null && !this.expList.isEmpty()) {
            conjunction = Restrictions.conjunction();
            for (Expression exp : this.expList) {
                conjunction.add((Criterion) exp.compose());
            }
        }
        return conjunction;
    }

    @Override
    public void accept(ExpressionVisitor expressionVisitor) {
        // do nothing
    }

}
