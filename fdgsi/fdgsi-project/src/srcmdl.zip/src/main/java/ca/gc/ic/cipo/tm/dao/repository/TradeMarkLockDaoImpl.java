/*
 * Copyright (c) 2019 CIPO Created on Feb 12, 2019
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.TradeMarkLockDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.TradeMarkLock;

/**
 * The implementation DAO to acquire, release, and list locks stored in the Intrepid LOCKED_TRADE_MARKS table.
 *
 * @author D.Rodrigues
 * @version 1.0
 */
@Repository("tradeMarkLockDao")
public class TradeMarkLockDaoImpl extends HibernateBaseDao implements TradeMarkLockDao {

    /**
     * Unique serial ID.
     */
    private static final long serialVersionUID = 6123023357798212978L;

    /*
     * (non-Javadoc)
     *
     * @see ca.gc.ic.cipo.tm.dao.TradeMarkLockDao#acquireLock(java.lang.Integer, java.lang.Integer, java.lang.String)
     */
    @Override
    public TradeMarkLock acquireLock(Integer fileNumber, Integer extensionCounter, String userName) {
        if (fileNumber == null || extensionCounter == null || StringUtils.isBlank(userName)) {
            throw new DataAccessException(String.format(
                "A File number, extension counter, and user name are required to acquire a lock. Received values [%s, %s, %s]",
                fileNumber, extensionCounter, userName));
        }

        // Check for an existing lock on the file number and extension and NOT the provided userName
        Criteria criteria = getSession().createCriteria(TradeMarkLock.class);
        criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
        criteria
            .add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));

        // JIRA TMMADCON-1769 - attempting to acquire a lock with the *same* user name is now an error
        // criteria.add(Restrictions.ne("userName", userName));

        // There should only ever be 1 existing lock. If more than one row is returned from
        // this call then a serious data integrity problem exists
        TradeMarkLock currentLock = findUniqueByCriteria(criteria);

        // If a lock exist for this file number + extension for any *other* user, fail the acquisition
        if (currentLock != null) {
            getSession().evict(currentLock);
            throw new DataAccessException(String.format(
                "Another user [%s] already possesses a lock for File Number [%s] and Extension Counter [%s]",
                currentLock.getUserName(), currentLock.getFileNumber(), currentLock.getExtensionCounter()));
        }

        // Check for an existing lock on the file number and extension and the provided userName
        criteria = getSession().createCriteria(TradeMarkLock.class);
        criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
        criteria
            .add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
        criteria.add(Restrictions.eq("userName", userName));

        currentLock = findUniqueByCriteria(criteria);
        if (currentLock != null) {
            getSession().evict(currentLock);
            return currentLock;
        }

        // Set the values on a model object
        TradeMarkLock lock = new TradeMarkLock();
        lock.setFileNumber(fileNumber);
        lock.setExtensionCounter(extensionCounter);
        lock.setUserName(userName);
        // Use a default - SIDs aren't used because the Java connection pool makes them meaningless
        lock.setSid(new Integer(999));

        // Save or update (if the row exists for the same user)
        saveOrUpdate(lock);

        return lock;
    }

    /*
     * (non-Javadoc)
     *
     * @see ca.gc.ic.cipo.tm.dao.TradeMarkLockDao#releaseLock(java.lang.Integer, java.lang.Integer)
     */
    @Override
    public TradeMarkLock releaseLock(Integer fileNumber, Integer extensionCounter) {
        if (fileNumber == null || extensionCounter == null) {
            throw new DataAccessException(String.format(
                "A File number and extension counter are required to release a lock. Received values [%s, %s]",
                fileNumber, extensionCounter));
        }

        // Set the values on a model object
        TradeMarkLock lock = new TradeMarkLock();
        lock.setFileNumber(fileNumber);
        lock.setExtensionCounter(extensionCounter);

        delete(lock);

        return lock;
    }

    /*
     * (non-Javadoc)
     *
     * @see ca.gc.ic.cipo.tm.dao.TradeMarkLockDao#listLocks(java.lang.Integer, java.lang.Integer, java.lang.String)
     */
    @Override
    public List<TradeMarkLock> listLocks(Integer fileNumber, Integer extensionCounter, String userName) {
        // Ensure at least a user name or file number were provided
        if (fileNumber == null && StringUtils.isBlank(userName)) {
            throw new DataAccessException(String.format(
                "The minimum criteria to list current locks is either a file number or user name. Received values [%s, %s]",
                fileNumber, userName));
        }

        // Create the criteria based on what user provided
        Criteria criteria = getSession().createCriteria(TradeMarkLock.class);
        if (fileNumber != null) {
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
        }
        if (extensionCounter != null) {
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
        }
        if (!StringUtils.isBlank(userName)) {
            criteria.add(Restrictions.eq("userName", userName));
        }

        List<TradeMarkLock> lockList = findByCriteria(criteria);

        return lockList;
    }

}
