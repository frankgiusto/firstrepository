package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.model.StoreFileStoredProcedureParameters;

/**
 * Common interface to PL/SQL stored procedure calls
 */
public interface StoredProcedureDao {

    /**
     * Calls the STORE_FILE PL/SQL stored procedure
     *
     * @param storeProcedureName the name of the stored procedure
     * @param params the StoreFileStoredProcedureParameters
     * @return true if success; false otherwise
     */
    boolean callStoreFile(String storeProcedureName, StoreFileStoredProcedureParameters params);

}
