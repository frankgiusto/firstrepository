/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AssignmentAmendmentWorkSheetsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentTransaction;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFilesId;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheets;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetsId;

/**
 * The AAWorkSheetsDaoImpl retrieves data from the AA_WORK_SHEETS Table using Hibernate.
 *
 * @see aAWorkSheetsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("aAWorkSheetsDao")
public class AssignmentAmendmentWorkSheetsDaoImpl extends HibernateBaseDao implements AssignmentAmendmentWorkSheetsDao {

    /**
     *
     */
    private static final long serialVersionUID = 5856910459186098289L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(AssignmentAmendmentWorkSheetsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(Integer workSheetNumber) {
        // TODO Auto-generated method stub
        List<AssignmentAmendmentWorkSheets> aaWorkSheets = new ArrayList<AssignmentAmendmentWorkSheets>();
        try {
            Criteria criteria = getSession().createCriteria(AssignmentAmendmentWorkSheets.class);
            criteria.add(Restrictions.eq(ModelPropertyType.AA_WORK_SHEET_FILES_WORK_SHEET_ID_NUMBER.getValue(),
                workSheetNumber));
            aaWorkSheets = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "Error retrieving AA Work Sheets with parameters [" + workSheetNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AssignmentAmendmentWorkSheets>(aaWorkSheets);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(Integer workSheetNumber,
                                                                               String authorityId) {
        // TODO Auto-generated method stub
        List<AssignmentAmendmentWorkSheets> aaWorkSheets = new ArrayList<AssignmentAmendmentWorkSheets>();
        try {
            Criteria criteria = getSession().createCriteria(AssignmentAmendmentWorkSheets.class);
            criteria.add(Restrictions.eq(ModelPropertyType.AA_WORK_SHEET_FILES_WORK_SHEET_ID_NUMBER.getValue(),
                workSheetNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.AA_WORK_SHEETS_ID_AUTHORITY_ID.getValue(), authorityId));
            aaWorkSheets = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving AA Work Sheets with parameters [" + workSheetNumber + ", " + authorityId
                + ", " + workSheetNumber + ", " + authorityId + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AssignmentAmendmentWorkSheets>(aaWorkSheets);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFilesId aAWorkSheetFilesId) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheets(aAWorkSheetFilesId.getWorkSheetNumber());
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFiles aAWorkSheetFiles) {
        // TODO Auto-generated method stub
        return this
            .getAssignmentAmendmentWorkSheets(new AssignmentAmendmentWorkSheetFilesId(aAWorkSheetFiles.getFileNumber(),
                aAWorkSheetFiles.getExtensionCounter(), aAWorkSheetFiles.getWorkSheetNumber()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFilesId aAWorkSheetFilesId,
                                                                               String authorityId) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheets(aAWorkSheetFilesId.getWorkSheetNumber(), authorityId);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFiles aAWorkSheetFiles,
                                                                               String authorityId) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheets(aAWorkSheetFiles.getWorkSheetNumber(), authorityId);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheets> getAssignmentAmendmentWorkSheets(AssignmentAmendmentWorkSheetFilesId aAWorkSheetFilesId,
                                                                               AssignmentAmendmentWorkSheetsId aAWorkSheetsId) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheets(aAWorkSheetFilesId, aAWorkSheetsId.getAuthorityId());
    }

    @Override
    public Set<AssignmentAmendmentTransaction> getAssignmentAmendmentTransactions(String authorityId,
                                                                                  Integer workSheetNumber,
                                                                                  Integer aatNumber) {

        String sql =
            // Select all assignment amendment transactions related to this
            // work sheet file.
            "select {aat.*} from aa_transactions aat "
                + "join aa_work_sheets aaw on aat.AUTHORITY_ID = aaw.AUTHORITY_ID and aat.WORK_SHEET_NUMBER = aaw.WORK_SHEET_NUMBER and aat.AAT_NUMBER is not null "
                + "where (aat.AUTHORITY_ID = :authorityId and aat.WORK_SHEET_NUMBER = :workSheetNumber and aat.AAT_NUMBER =:aatNumber)";

        logger.debug("Executing SQL statement = " + sql);

        // Set the runtime parameters - authorityId, workSheetNumber and
        // aatNumber.
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.AA_WORK_SHEETS_ID_AUTHORITY_ID.getValue(), authorityId);
        parameters.put(ModelPropertyType.AA_WORK_SHEET_FILES_WORK_SHEET_ID_NUMBER.getValue(), workSheetNumber);
        parameters.put(ModelPropertyType.ASSIGNMENT_AMENDMENT_TRANSACTION_AAT_NUMBER.getValue(), aatNumber);

        // Declare the SQL query and attach the entity AssociatedMark to it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("aat", AssignmentAmendmentTransaction.class);
        List<AssignmentAmendmentTransaction> assignmentAmendmentTransactions = new ArrayList<AssignmentAmendmentTransaction>();
        try {
            assignmentAmendmentTransactions = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving assignment amendment transactionsfor Application with parameters ["
                + authorityId + ", " + workSheetNumber + ", " + aatNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AssignmentAmendmentTransaction>(assignmentAmendmentTransactions);
    }

    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                       Integer extensionCounter,
                                                                                       Integer workSheetNumber) {

        String sql =
            // Select all assignment amendment work sheet files related to
            // this
            // work sheet .
            "select {wsf.*} from aa_work_sheet_files wsf "
                + "join aa_work_sheets aaw on wsf.WORK_SHEET_NUMBER = aaw.WORK_SHEET_NUMBER "
                + "join applications ap on ap.FILE_NUMBER = wsf.WORK_SHEET_NUMBER and ap.EXTENSION_COUNTER = wsf.EXTENSION_COUNTER "
                + "where (wsf.WORK_SHEET_NUMBER = :workSheetNumber and wsf.FILE_NUMBER = :fileNumber and wsf.EXTENSION_COUNTER = :extensionCounter)";

        logger.debug("Executing SQL statement = " + sql);

        // Set the runtime parameters - fileNumber, extensionCounter and
        // workSheetNumber
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);
        parameters.put(ModelPropertyType.ASSIGNMENT_AMENDMENT_TRANSACTION_WORK_SHEET_NUMBER.getValue(),
            workSheetNumber);

        // Declare the SQL query and attach the entity
        // AssignmentAmendmentWorkSheetFiles to it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("wsf", AssignmentAmendmentWorkSheetFiles.class);
        List<AssignmentAmendmentWorkSheetFiles> assignmentAmendmentWorkSheetFiles = new ArrayList<AssignmentAmendmentWorkSheetFiles>();
        try {
            assignmentAmendmentWorkSheetFiles = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving assignment amendment work sheet files for Application with parameters ["
                + fileNumber + ", " + extensionCounter + ", " + workSheetNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AssignmentAmendmentWorkSheetFiles>(assignmentAmendmentWorkSheetFiles);

    }

}
