package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.NiceReference;
import ca.gc.ic.cipo.tm.model.NiceReferenceId;

/**
 * This interface will retrieve/maintain the NICE Reference table
 * 
 * @author SeguinA3
 *
 */
public interface NiceReferenceDao {

	/**
	 * This method will retrieve the Nice Reference row
	 * 
	 * @param niceEdition
	 * @param niceClassCode
	 * @return NiceReference object.
	 */
	public NiceReference getNiceReference(Integer niceEdition, Integer niceClassCode);
	
	/**
	 * This method will retrieve the Nice Reference row
	 * 
	 * @param niceReferenceId
	 * @return NiceReference object.
	 */
	public NiceReference getNiceReference(NiceReferenceId niceReferenceId);
	
	/**
	 * This method will retrieve all the Nice Reference based on the Nice Edition
	 * 
	 * @param niceEdition
	 * @return Collection of NiceReference Objects
	 */
	public List<NiceReference> getNiceReferences(Integer niceEdition);
	
	/**
	 * This method will retrieve all the Nice Reference based on the Current Nice Edition 
	 * Configured in the configuration.property file.
	 * 
	 * @return Collection of NiceReference Objects
	 */
	public List<NiceReference> getCurrentNiceReferences();
	
}
