/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import ca.gc.ic.cipo.tm.dao.repository.BaseDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.ProcessAction;
import ca.gc.ic.cipo.tm.model.ProcessActionId;

/**
 * @author houreich
 *
 */
// TODO review again when question about table are answered
public interface ProcessActionsDao extends BaseDao {

    public Set<ProcessAction> getProcessActions(Integer fileNumber, Integer extensionCounter);

    public Set<ProcessAction> getProcessActions(Integer fileNumber, Integer extensionCounter, String authorityId);

    public Set<ProcessAction> getProcessActions(ApplicationNumber applicationNumber);

    public Set<ProcessAction> getProcessActions(ApplicationNumber applicationNumber, String authorityId);

    // TODO remove ApplicationNumber, ProcessActionsId is already of this type
    public Set<ProcessAction> getProcessActions(ApplicationNumber applicationNumber, ProcessActionId processActionsId);

    public void saveProcessActions(ProcessAction processActions);

    public List<ProcessAction> getProcessActionsByCodes(List<Integer> processActionCodes);

    public List<ProcessAction> getProcessActionsByReferenceNumber(String referenceNumber);

    public void deleteProcessAction(ProcessAction entity);

    public ProcessAction getById(Serializable id);

    public int getCount(Set<Integer> processCodes);
}
