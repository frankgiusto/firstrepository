package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.InterestedPartyDao;
import ca.gc.ic.cipo.tm.enumerator.InterestedPartyRelationshipType;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.OppositionIp;

/**
 * The Interested Party Data Access Object retrieves/commits data to the Interested party Database Table.
 */
@Repository("interestedPartyDao")
public class InterestedPartyDaoImpl extends HibernateBaseDao implements InterestedPartyDao {

    private static final long serialVersionUID = -4161665877795753135L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(InterestedPartyDaoImpl.class);

    private static final String INT_PARTY_RELATIONSHIP_TYPE = " select max(IP.IP_NUMBER) as IPNUMBER from INTERESTED_PARTIES IP WHERE IP.FILE_NUMBER = :fileNumber and IP.EXTENSION_COUNTER = :extensionCounter and IP.RELATIONSHIP_TYPE = :relationshipType ";

    @Override
    public InterestedParty getInterestedPartyByIpNumber(ApplicationNumber applicationNumber, Integer ipNumber) {
        return this.getInterestedPartyByIpNumber(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter(), ipNumber);
    }

    @Override
    public InterestedParty getInterestedPartyByIpNumber(Integer fileNumber, Integer extensionCounter,
                                                        Integer ipNumber) {
        InterestedParty interestedParty = new InterestedParty();
        List<InterestedParty> results = null;
        try {
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_ID_IP_NUMBER.getValue(), ipNumber));

            /**
             * Should always be one applicant but due to certain old records have to prevent the Exception to be thrown
             * to avoid grief to callers
             */
            results = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Interested Party of Application with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + ipNumber + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        if (!CollectionUtils.isEmpty(results)) {
            interestedParty = results.get(0);
        }
        return interestedParty;

    }

    @Override
    @Deprecated
    /**
     * Please use:
     * ca.gc.ic.cipo.tm.dao.repository.InterestedPartyDaoImpl.getInterestedPartiesByApplicationNumberAndRelationshipType
     * (Integer, Integer, Integer)
     */
    public InterestedParty getInterestedPartyByFileNumberExtensionCounterRelationshipType(Integer fileNumber,
                                                                                          Integer extensionCounter,
                                                                                          Integer relationshipType) {
        InterestedParty interestedParty = new InterestedParty();
        try {
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(
                Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE.getValue(), relationshipType));
            interestedParty = super.findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no Interested Party of Application with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + ", " + relationshipType + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        return interestedParty;
    }

    @Override
    public List<InterestedParty> getInterestedPartiesByApplicationNumberAndRelationshipType(Integer fileNumber,
                                                                                            Integer extensionCounter,
                                                                                            Integer relationshipType) {
        List<InterestedParty> interestedParties = new ArrayList<>();
        try {
            Objects.requireNonNull(fileNumber);
            Objects.requireNonNull(extensionCounter);
            Objects.requireNonNull(relationshipType);
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(
                Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE.getValue(), relationshipType));
            interestedParties = super.findByCriteria(criteria);

        } catch (Throwable ex) {
            logger.error("Problem occured in retrieving Interestd parties by Application number ["
                + new ApplicationNumber(fileNumber, extensionCounter) + ", " + relationshipType + "]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        return interestedParties;
    }

    @Override
    public Integer getIPNumberByFileNumberExtensionCounterRelationshipType(Integer fileNumber, Integer extensionCounter,
                                                                           Integer relationshipType) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("fileNumber", fileNumber);
        parameters.put("extensionCounter", extensionCounter);
        parameters.put("relationshipType", relationshipType);

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(INT_PARTY_RELATIONSHIP_TYPE, parameters);
        sqlQuery.addScalar("IPNUMBER", IntegerType.INSTANCE);

        Object result = sqlQuery.uniqueResult();
        if (result instanceof Integer) {
            return ((Integer) result);
        }
        return null;
    }

    @Override
    public InterestedParty getInterestedPartyByFileNumberIPNumberAndRelationshipType(ApplicationNumber applicationNumber,
                                                                                     Integer ipNumber,
                                                                                     Integer relationshipType) {
        InterestedParty interestedParty = new InterestedParty();
        try {
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
                applicationNumber.getFileNumber()));
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
                applicationNumber.getExtensionCounter()));
            criteria.add(Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_ID_IP_NUMBER.getValue(), ipNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE.getValue(), relationshipType));
            interestedParty = super.findUniqueByCriteria(criteria);
        } catch (Throwable ex) {
            logger.error("Problem in retrieving Interested Party for Application [" + applicationNumber + " ]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        return interestedParty;
    }

    /** {@inheritDoc} */
    @Override
    public List<InterestedParty> getInterestedPartiesForOppositionCase(ApplicationNumber applicationNumber,
                                                                       Integer caseNumber) {
        List<InterestedParty> interestedPartyList = new ArrayList<>();
        List<OppositionIp> oppositionIpList = null;

        Criteria interestedPartyCriteria = getSession().createCriteria(OppositionIp.class);
        interestedPartyCriteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(),
            applicationNumber.getFileNumber()));
        interestedPartyCriteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(),
            applicationNumber.getExtensionCounter()));
        interestedPartyCriteria
            .add(Restrictions.eq(ModelPropertyType.OPPOSITION_CASE_ID_OPP_CASE_NUMBER.getValue(), caseNumber));
        oppositionIpList = super.findByCriteria(interestedPartyCriteria);

        if (!CollectionUtils.isEmpty(oppositionIpList)) {
            for (OppositionIp oppositionIp : oppositionIpList) {
                interestedPartyList.add(oppositionIp.getInterestedParty());
            }
        }
        return interestedPartyList;
    }

    @Override
    public void saveInterestedParty(InterestedParty interestedParty) {
        Session session = getSession();
        session.saveOrUpdate(interestedParty);
    }

    @Override
    public InterestedParty getApplicant(ApplicationNumber applicationNumber) {
        applicationNumber = Objects.requireNonNull(applicationNumber);
        return getApplicant(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    @Override
    public InterestedParty getApplicant(Integer fileNumber, Integer extCounter) {
        try {
            fileNumber = Objects.requireNonNull(fileNumber);
            extCounter = Objects.requireNonNull(extCounter);
            Criteria criteria = getSession().createCriteria(InterestedParty.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria
                .add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE.getValue(),
                InterestedPartyRelationshipType.OWNER.getValue()));

            /**
             * Prevent Hibernate exception to be thrown for duplicate records. There can or might be records in DB with
             * duplicate entries.
             */
            List<InterestedParty> results = super.findByCriteria(criteria);
            if (!CollectionUtils.isEmpty(results)) {
                return results.get(0);
            }
        } catch (Exception ex) {
            logger.error("There are no Interested Party By RelationshipType (Owner) for Application with parameters ["
                + fileNumber + ", " + extCounter + ", "
                + ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE.getValue() + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new InterestedParty();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Integer getNextIpNumber(Integer fileNumber, Integer extCounter) {
        Integer ipNumber = null;
        fileNumber = Objects.requireNonNull(fileNumber);
        extCounter = Objects.requireNonNull(extCounter);
        Criteria criteria = getSession().createCriteria(InterestedParty.class);
        criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
        criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extCounter));
        criteria.setProjection(Projections.max("ipNumber"));
        ipNumber = (Integer) criteria.uniqueResult();
        if (ipNumber != null) {
            ipNumber = ipNumber + 1;
        }
        return ipNumber;
    }
}
