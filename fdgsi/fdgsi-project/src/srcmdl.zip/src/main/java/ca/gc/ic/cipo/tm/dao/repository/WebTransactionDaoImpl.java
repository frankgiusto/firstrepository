package ca.gc.ic.cipo.tm.dao.repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.type.IntegerType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.WebTransactionDao;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.WebTransactions;

@Repository("webTransactionDao")
public class WebTransactionDaoImpl extends HibernateBaseDao implements WebTransactionDao {

    private static final long serialVersionUID = -5762642126050543343L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(WebTransactionDaoImpl.class);

    private static final String IS_RENEWAL_EXISTS_IN_TRDAEMARK_SQL = " SELECT 1 as found FROM WEB_TRANSACTIONS wt where wt.file_number = :fileNumber AND   "
        + "wt.extension_counter = :extensionCounter AND  wt.status_code IN (4, 6) ";

    @Override
    public boolean isRenewalExistInTrademark(ApplicationNumber applicationNumber) {
        Objects.requireNonNull(applicationNumber);
        Map<String, Object> params = new HashMap<>();
        params.put("fileNumber", applicationNumber.getFileNumber());
        params.put("extensionCounter", applicationNumber.getExtensionCounter());
        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(IS_RENEWAL_EXISTS_IN_TRDAEMARK_SQL, params);
        sqlQuery.addScalar("found", IntegerType.INSTANCE);

        Integer result = (Integer) sqlQuery.uniqueResult();
        return (result != null);

    }

    @Override
    public void saveWebTransaction(WebTransactions webTransaction) {
        logger.debug("Start saving Web Tansaction info");
        Session session = getSession();
        session.saveOrUpdate(webTransaction);
        logger.debug("Saved webTransaction info");
    }

    @Override
    /** @{inheritDoc} */
    public void saveWebTransactionWithflush(WebTransactions webTransaction) {
        logger.debug("Start saving Web Tansaction info");
        Session session = getSession();
        session.saveOrUpdate(webTransaction);
        super.flush();
        logger.debug("Saved webTransaction info");
    }
}
