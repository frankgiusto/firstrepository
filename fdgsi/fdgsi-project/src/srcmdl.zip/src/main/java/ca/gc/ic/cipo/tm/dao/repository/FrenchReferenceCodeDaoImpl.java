package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.enumerator.LanguageType;
import ca.gc.ic.cipo.tm.enumerator.ReferenceCodeType;
import ca.gc.ic.cipo.tm.model.ReferenceCode;

/**
 * Usage:
 *
 * This class will be use to get reference information in French
 * To inject this class, use with the annotation @Autowired the @Qualifier("frenchReferenceCodeDao")
 *
 * Code:
 *
 * @Autowired
 * @Qualifier("frenchReferenceCodeDao")
 * private ReferenceCodeDao frenchReferenceCodeDao;
 *
 *
 * @see ReferenceCodeDaoImpl
 *
 * @author SeguinA3
 *
 */

@Repository("frenchReferenceCodeDao")
public class FrenchReferenceCodeDaoImpl extends ReferenceCodeDaoImpl {

	private static final long serialVersionUID = -7182381262670397529L;

	@Override
	public List<ReferenceCode> getClaimTypes() {
		return verifyInstances(listCodesByType(ReferenceCodeType.CLAIM_TYPE.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public List<ReferenceCode> getActions() {
		return verifyInstances(listCodesByType(ReferenceCodeType.ACTIONS.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public List<ReferenceCode> getGoodsAndServices() {
		return verifyInstances(listCodesByType(ReferenceCodeType.GOODS_SERVICES.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public List<ReferenceCode> getTrademarkType() {
		return verifyInstances(listCodesByType(ReferenceCodeType.TRADEMARK_TYPE.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public List<ReferenceCode> getTrademarkClass() {
		return verifyInstances(listCodesByType(ReferenceCodeType.TRADEMARK_CLASS.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public List<ReferenceCode> getDocumentStoredOutputCode() {
		return verifyInstances(listCodesByType(ReferenceCodeType.OUTPUT_TITLE.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public List<ReferenceCode> getTypeOfDocuments() {
		return verifyInstances(listCodesByType(ReferenceCodeType.TYPE_OF_DOCUMENTS.getValue(), LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getClaimType(Integer code) {
		return verifyInstance(getCode(ReferenceCodeType.CLAIM_TYPE.getValue(), code, LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getAction(Integer code){
		return verifyInstance(getCode(ReferenceCodeType.ACTIONS.getValue(), code, LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getGoodAndService(Integer code){
		return verifyInstance(getCode(ReferenceCodeType.GOODS_SERVICES.getValue(), code, LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getTrademarkClass(Integer code) {
		return verifyInstance(getCode(ReferenceCodeType.TRADEMARK_CLASS.getValue(), code, LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getDocumentStoredOutputCode(Integer code){
		return verifyInstance(getCode(ReferenceCodeType.OUTPUT_TITLE.getValue(), code, LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getTypeOfDocument(Integer code){
		return verifyInstance(getCode(ReferenceCodeType.TYPE_OF_DOCUMENTS.getValue(), code, LanguageType.FRENCH.getValue()));
	}

	@Override
	public ReferenceCode getTrademarkType(Integer code) {
		return verifyInstance(getCode(ReferenceCodeType.TRADEMARK_TYPE.getValue(), code, LanguageType.FRENCH.getValue()));
	}
}
