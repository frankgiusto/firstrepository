package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.SearchAdjustedRenewalFee;
import ca.gc.ic.cipo.tm.model.SearchRegistrationCriteria;

/**
 * Contract interface for Searching adjusted renewal fee
 */
public interface SearchAdjustedRenewalFeeDao {

    /**
     * Interface to retrieve actions based on the search criteria
     *
     * @param searchCriteria the SearchCriteria object encapsulating the search fields.
     * @return the list of SearchAdjustedRenewalFee type objects
     */
    public List<SearchAdjustedRenewalFee> searchAdjustedRenewalFee(SearchRegistrationCriteria searchCriteria);

}
