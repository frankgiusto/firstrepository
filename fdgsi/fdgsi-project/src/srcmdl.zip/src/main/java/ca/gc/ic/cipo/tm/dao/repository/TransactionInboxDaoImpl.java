package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.TimestampType;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.TransactionInboxDao;
import ca.gc.ic.cipo.tm.enumerator.AttachmentType;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.enumerator.TransactionType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FiledTransactionResult;
import ca.gc.ic.cipo.tm.model.TransactionInbox;

/**
 * This TransactionInboxDao implementation is used to save and find transaction inbox item using Hibernate.
 *
 * @see TransactionInbox
 * @see TransactionInboxDAO
 * @see HibernateBaseDAO
 */
@Repository("transactionInboxDao")
public class TransactionInboxDaoImpl extends HibernateBaseDao implements TransactionInboxDao {

    private static final long serialVersionUID = -2628047260937502089L;

    /** Log4J logger. */
    private static final Logger LOG = Logger.getLogger(TransactionInboxDaoImpl.class);

    private static final String FILED_TRANS_SQL_QUERY = "SELECT A.FILE_NUMBER as fileNumber, A.EXTENSION_COUNTER as extensionCounter, A.EC_REFERENCE_NUMBER as serviceItemNum, A.TRANSACTION_TYPE as transactionType, "
        + "A.EC_PAYMENT_DATE  as mailRoomDate "
        + "  FROM EC_TRANSACTION_INBOX A, EC_TRANSACTION_INBOX_ATTCH B, TM.APPLICATIONS C WHERE A.FILE_NUMBER = C.FILE_NUMBER AND A.EXTENSION_COUNTER = C.EXTENSION_COUNTER "
        + "  AND ((C.STATUS_CODE in ( " + "  9, " + // -- Advertised
        "     10, " + // -- Opposed
        "     11, " + // -- Allowed
        "     25, " + // -- Default - Allowed
        "     40, " + // -- Registration Pending
        "     41) " + // -- Default - Registration Pending
        "   AND A.EC_PAYMENT_DATE >= (SELECT MAX(D.ACTION_DATE) FROM TM.ACTIONS D WHERE D.FILE_NUMBER = C.FILE_NUMBER AND "
        + " D.EXTENSION_COUNTER = A.EXTENSION_COUNTER AND C.FILE_NUMBER = A.FILE_NUMBER AND C.EXTENSION_COUNTER = A.EXTENSION_COUNTER AND D.ACTION_CODE = 42)) "
        + " OR (C.STATUS_CODE in (" + "1, " + // -- Pre-formalized"+
        "   2, " + // -- Formalized"+
        "   6, " + // -- Default - Searched"+
        "   7, " + // -- Approved"+
        "   26 ))) " + // -- Searched"+
        " AND A.TRANSACTION_TYPE in ( :transactionTypes ) " + // -- Filing a new application
        " AND A.TRANSACTION_INBOX_SEQ_NO = B.TRANSACTION_INBOX_SEQ_NO " + "AND B.ATTACHMENT_TYPE = :attachmentType " + 
        " AND ATTACHMENT_FILE is not null " + "AND DBMS_LOB.GETLENGTH (ATTACHMENT_FILE) > 0 "
        + " AND A.FILE_NUMBER = :fileNumber AND A.EXTENSION_COUNTER = :extensionCounter "
        + " ORDER BY A.EC_PAYMENT_DATE desc ";

    @Override
    public TransactionInbox getTransactionItem(int transactionSeqNumber) {
        long startTime = System.currentTimeMillis();
        TransactionInbox transactionInboxItem = new TransactionInbox();

        try {
            Criteria criteria = getSession().createCriteria(TransactionInbox.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.TRANSACTION_INBOX_ATTACHMENT_TRANSACTION_INBOX_SEQ_NUM.getValue(),
                    transactionSeqNumber));
            transactionInboxItem = super.findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error(
                "Transaction sequence number [ " + transactionSeqNumber + "] doesn't exists\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        if (transactionInboxItem != null) {
            LOG.trace("Time to read application [ " + transactionInboxItem.getFileNumber() + ", "
                + transactionInboxItem.getExtensionCounter() + "] = " + (System.currentTimeMillis() - startTime)
                + " ms");
        }
        return transactionInboxItem;
    }

    @Override
    public List<FiledTransactionResult> retrieveTransactionsForAmendment(ApplicationNumber applicationNumberModel) {
        Map<String, Object> params = new HashMap<>();
        params.put("fileNumber", applicationNumberModel.getFileNumber());
        params.put("extensionCounter", applicationNumberModel.getExtensionCounter());
        params.put("attachmentType", AttachmentType.XML.attachmentType());

        SQLQuery sqlQuery = (SQLQuery) super.createSQLQuery(FILED_TRANS_SQL_QUERY, params);

        sqlQuery.addScalar("fileNumber", IntegerType.INSTANCE);
        sqlQuery.addScalar("extensionCounter", IntegerType.INSTANCE);
        sqlQuery.addScalar("serviceItemNum", IntegerType.INSTANCE);
        sqlQuery.addScalar("transactionType", IntegerType.INSTANCE);
        sqlQuery.addScalar("mailRoomDate", TimestampType.INSTANCE);

        // 301 and 302
        sqlQuery.setParameterList("transactionTypes",
            new Integer[]{TransactionType.FILING_NEW_APPLICATION.transactionType(),
                TransactionType.FILING_REVISED_APPLICATION.transactionType()});

        @SuppressWarnings("unchecked")
        List<FiledTransactionResult> results = sqlQuery
            .setResultTransformer(Transformers.aliasToBean(FiledTransactionResult.class)).list();
        return results;
    }

    @Override
    public void saveTransactionItem(TransactionInbox transaction) {
        Session session = super.getSession();
        session.saveOrUpdate(transaction);
    }

    @Override
    public void deleteTransactionInbox(Integer transactionInboxSequenceNumber) {
        super.deleteById(TransactionInbox.class, transactionInboxSequenceNumber);

    }

    @Override
    public List<TransactionInbox> getTransactionByStatusTransactionDetail(String statusTransactionDetail) {
        List<TransactionInbox> transactionInboxList = new ArrayList<TransactionInbox>();
        try {
            Criteria criteria = getSession().createCriteria(TransactionInbox.class);
            criteria.add(Restrictions.eq(ModelPropertyType.TRANSACTION_INBOX_TRANSACTION_STATUS_DETAILS.getValue(),
                statusTransactionDetail));
            transactionInboxList = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error occurred during the retrieval of the transaction inbox status: "
                + statusTransactionDetail + "\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return transactionInboxList;
    }
}
