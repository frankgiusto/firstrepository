package ca.gc.ic.cipo.tm.dao.repository;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.NiceReferenceDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.NiceReference;
import ca.gc.ic.cipo.tm.model.NiceReferenceId;
import ca.gc.ic.cipo.tm.type.TradeMarkPropertyKey;
import ca.gc.ic.cipo.util.cipher.PropertiesFileCipherUtility;

@Repository("niceReferenceDao")
public class NiceReferenceDaoImpl extends HibernateBaseDao implements NiceReferenceDao {

    private static final long serialVersionUID = 3791437487251074953L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(NiceReferenceDaoImpl.class);

    private static final String CONFIG_FILE = "configuration.properties";

    private Properties property;

    @Override
    public NiceReference getNiceReference(Integer niceEdition, Integer niceClassCode) {
        NiceReference niceReference = new NiceReference();

        try {
            Criteria criteria = getSession().createCriteria(NiceReference.class);
            criteria.add(Restrictions.eq(ModelPropertyType.NICE_REFERENCE_ID.getValue() + "."
                + ModelPropertyType.NICE_REFERENCE_ID_NICE_EDITION.getValue(), niceEdition));
            criteria.add(Restrictions.eq(ModelPropertyType.NICE_REFERENCE_ID.getValue() + "."
                + ModelPropertyType.NICE_REFERENCE_ID_NICE_CLASS_CODE.getValue(), niceClassCode));
            niceReference = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error occurred retrieving nice reference - [" + niceEdition + ", " + niceClassCode + "]\n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return niceReference;
    }

    @Override
    public List<NiceReference> getCurrentNiceReferences() {
        String currentEdition = property.getProperty(TradeMarkPropertyKey.NICE_CLASS_CURRENT_EDITION.getValue());
        return getNiceReferences(Integer.valueOf(currentEdition));
    }

    @Override
    public NiceReference getNiceReference(NiceReferenceId niceReferenceId) {
        return this.getNiceReference(niceReferenceId.getNiceEdition(), niceReferenceId.getNiceClassCode());
    }

    @Override
    public List<NiceReference> getNiceReferences(Integer niceEdition) {
        List<NiceReference> niceReferences = new ArrayList<NiceReference>();

        try {
            Criteria criteria = getSession().createCriteria(NiceReference.class);
            criteria.add(Restrictions.eq(ModelPropertyType.NICE_REFERENCE_ID.getValue() + "."
                + ModelPropertyType.NICE_REFERENCE_ID_NICE_EDITION.getValue(), niceEdition));
            niceReferences = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error occurred retrieving nice reference - [" + niceEdition + "]\n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return niceReferences;

    }

    @PostConstruct
    public void init() {
        InputStream input = NiceReferenceDaoImpl.class.getClassLoader().getResourceAsStream(CONFIG_FILE);
        property = PropertiesFileCipherUtility.getProperties(input);
    }

}
