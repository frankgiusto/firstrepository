package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.GoodService;
import ca.gc.ic.cipo.tm.model.GoodServiceId;

public interface GoodsServicesDao {

    /**
     *
     * @param applicationNumber
     * @return
     */
    public List<GoodService> getGoodService(ApplicationNumber applicationNumber);

    /**
     *
     * @param application
     * @return
     */
    // TODO duplication of ApplicationNumber query
    @Deprecated
    public List<GoodService> getGoodService(Application application);

    /**
     *
     * @param applicationNumber
     * @param goodServiceType
     * @param goodServiceNumber
     * @return
     */
    public List<GoodService> getGoodService(ApplicationNumber applicationNumber, Integer goodServiceType,
                                            Integer goodServiceNumber);

    /**
     *
     * @param application
     * @param goodServiceType
     * @param goodServiceNumber
     * @return
     */
    // TODO duplication of ApplicationNumber query
    @Deprecated
    public List<GoodService> getGoodService(Application application, Integer goodServiceType,
                                            Integer goodServiceNumber);

    /**
     *
     * @param goodServiceId
     * @return
     */
    // TODO should return a single GoodService since it is PK
    public List<GoodService> getGoodService(GoodServiceId goodServiceId);

    /**
     *
     * @param goodsService
     */
    public void saveGoodsServices(GoodService goodsService);

    /**
     * Delete goods services.
     *
     * @param goodsService the goods service
     */
    public void deleteGoodsServices(GoodService goodsService);

    List<GoodService> getGoodServiceWithSortEnabled(ApplicationNumber applicationNumber);

    /**
     * This method will return a count of Unique Classified Goods and Services
     *
     * @param applicationNumber
     * @return Integer
     */
    Integer getUniqueClassifiedGoods(ApplicationNumber applicationNumber);

    /**
     * This method will return a count of Unclassified Goods and Services
     *
     * @param applicationNumber
     * @return Integer
     */
    Integer getUnclassifiedGoods(ApplicationNumber applicationNumber);

}
