package ca.gc.ic.cipo.tm.dao.search.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.util.CollectionUtils;

import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper;
import ca.gc.ic.cipo.tm.dao.helpers.QueryHelper.QueryAndParams;
import ca.gc.ic.cipo.tm.dao.search.Expression;
import ca.gc.ic.cipo.tm.dao.search.builders.NativeExpressionSQLBuilder;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

public final class AgentQueryHelper {

    private static final int MAX_RESULTS_SIZE = 100;

    private static final String MAIN_SELECT = " select * from ( ";

    private static final String AGENTS_SQL = " select {AR.*} from {h-schema}agents_reps AR inner join {h-schema}agent_user_xref userRef "
        + " on AR.ar_number = userRef.ar_number  ";

    private static final String AGENTS_EMAIL_SQL = "  SELECT xref.e_mail_address AS AGENT_EMAIL from {h-schema}AGENT_USER_XREF xref inner join {h-schema}AGENTS_REPS ar on xref.ar_number = ar.ar_number ";

    private static final String ACTIVE_AGENTS_CHECK_SQL = " ar.status_code = 1 and ar.ar_type in (1,3) ";

    private static final String AGENTS_EMAIL_GROUP_BY_SQL = " GROUP BY xref.e_mail_address ";

    private AgentQueryHelper() {
    }

    public static QueryAndParams createNativeSQLQuery(List<Expression> expressions,
                                                      HibernateOperatorEnum operatorEnum) {

        if (CollectionUtils.isEmpty(expressions)) {
            throw new IllegalArgumentException("Expected at least one Search Expression");
        }

        operatorEnum = Objects.requireNonNull(operatorEnum);

        StringBuilder sb = new StringBuilder();

        sb.append(MAIN_SELECT).append(AGENTS_SQL);
        sb.append(" where (1=1) ");
        sb.append(" and ( ");

        NativeExpressionSQLBuilder expressionSQLBuilder = new NativeExpressionSQLBuilder.Builder(expressions,
            operatorEnum).buildQuery();

        // where clause to filter out results
        String expSQL = expressionSQLBuilder.toFinalSQL();

        sb.append(expSQL).append(" ) ");

        sb.append(" order by AR.name ");
        sb.append(" ) where rownum <=").append(MAX_RESULTS_SIZE);

        return new QueryHelper.QueryAndParams(sb.toString(), expressionSQLBuilder.toParametersMap(),
            expressionSQLBuilder.toParameterListMap());
    }

    public static QueryAndParams createNativeSQLQueryAgentEmails(List<Expression> expressions,
                                                                 HibernateOperatorEnum operatorEnum) {

        if (CollectionUtils.isEmpty(expressions)) {
            throw new IllegalArgumentException("Expected at least one Search Expression");
        }

        operatorEnum = Objects.requireNonNull(operatorEnum);

        StringBuilder sb = new StringBuilder();

        sb.append(AGENTS_EMAIL_SQL);
        sb.append(" where (1=1) ");
        sb.append(" and ( ");

        NativeExpressionSQLBuilder expressionSQLBuilder = new NativeExpressionSQLBuilder.Builder(expressions,
            operatorEnum).buildQuery();

        // where clause to filter out results
        String expSQL = expressionSQLBuilder.toFinalSQL();
        sb.append(expSQL);
        sb.append(" and ");
        sb.append(ACTIVE_AGENTS_CHECK_SQL);
        sb.append(" ) ");

        sb.append(AGENTS_EMAIL_GROUP_BY_SQL);

        return new QueryHelper.QueryAndParams(sb.toString(), expressionSQLBuilder.toParametersMap(),
            expressionSQLBuilder.toParameterListMap());
    }

}
