package ca.gc.ic.cipo.tm.dao.search;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.enumerator.AddressType;
import ca.gc.ic.cipo.tm.enumerator.InterestedPartyRelationshipType;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.SimpleExpressionException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.InterestedParty;
import ca.gc.ic.cipo.tm.model.TradeMark;
import ca.gc.ic.cipo.tm.type.CountryCanadaProvinceEnum;
import ca.gc.ic.cipo.tm.type.HibernateOperatorEnum;

@Service("searchExpressionConstructor")
public final class SearchExpressionConstructor {

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(SearchExpressionConstructor.class);

    /**
     * This method will create a Hibernate SimpleExpression object to search Applications by the application number
     *
     * @param appNumber
     * @param operator
     * @return SimpleExpression
     */
    public Expression generateSearchExpressionOnApplicationNumber(Integer appNumber, HibernateOperatorEnum operator) {
        if (appNumber == null) {
            logger.debug("Invalid application number.");
            throw new SimpleExpressionException("Invalid application number.");
        }
        return makeSearchExpression(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER, operator, appNumber,
            Application.class);
    }

    public Expression generateSearchExpressionOnApplicationNumberString(String appNumber,
                                                                        HibernateOperatorEnum operator) {
        if (appNumber == null) {
            logger.debug("Invalid application number.");
            throw new SimpleExpressionException("Invalid application number.");
        }
        return makeSearchExpression(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER, operator, appNumber,
            Application.class);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search Applications by Registration Number
     *
     * @param regNumber
     * @param operator
     * @return SimpleExpression
     */
    public Expression generateSearchExpressionOnRegistrationNumber(Integer regNumber, HibernateOperatorEnum operator) {
        if (regNumber == null) {
            logger.debug("Invalid registration number.");
            throw new SimpleExpressionException("Invalid registration number.");
        }
        return makeSearchExpression(ModelPropertyType.APPLICATION_REGISTRATION_NUMBER, operator, regNumber,
            Application.class);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search Applications by Trademark name
     *
     * @param trademark name
     * @param operator
     * @return SimpleExpression
     */
    public Expression generateSearchExpressionOnTrademarkName(String trademarkName, HibernateOperatorEnum operator) {
        if (trademarkName == null) {
            logger.debug("Invalid trademark name.");
            throw new SimpleExpressionException("Invalid trademark name.");
        }

        return makeSearchExpression(ModelPropertyType.TRADE_MARK_TEXT, operator, trademarkName, TradeMark.class);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search the interested party by country/province
     * code
     *
     * @param countryProvince
     * @param operator
     * @return SimpleExpression
     */
    public Expression generateSearchExpressionOnInterestedPartyCountryProvince(String countryProvince,
                                                                               HibernateOperatorEnum operator) {
        SearchExpression se = null;
        if (countryProvince != null) {
            if (countryProvince.equals(CountryCanadaProvinceEnum.CA.getValue())) {
                se = new SearchExpression(
                    GenericSearchImpl.ADDRESSES_ALIAS + "." + ModelPropertyType.ADDRESS_COUNTRY_PROVINCE.getValue(),
                    operator, CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList(), InterestedParty.class);
            } else {
                se = new SearchExpression(
                    GenericSearchImpl.ADDRESSES_ALIAS + "." + ModelPropertyType.ADDRESS_COUNTRY_PROVINCE.getValue(),
                    operator, countryProvince, InterestedParty.class);
            }
        }
        return ExpressionFactory.getExpression(se);
    }

    /**
     * Generates and return the search expression for address type
     *
     * @param addressType the address type
     * @param operator the hibernate operator
     * @return search expression
     */
    public Expression generateSearchExpressionForAddressType(AddressType addressType, HibernateOperatorEnum operator) {
        if (addressType != null) {
            SearchExpression se = new SearchExpression(
                GenericSearchImpl.ADDRESSES_ALIAS + "." + ModelPropertyType.ADDRESS_ADDRESS_TYPE.getValue(), operator,
                addressType.getValue(), InterestedParty.class);
            return ExpressionFactory.getExpression(se);
        }
        return null;
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search the interested party by address line
     */
    public Expression generateSearchExpressionOnInterestedPartyAddressLine(String addressLine,
                                                                           HibernateOperatorEnum operator) {
        SearchExpression se = null;
        if (addressLine != null) {
            se = new SearchExpression(
                GenericSearchImpl.ADDRESSES_ALIAS + "." + ModelPropertyType.ADDRESS_ADDRESS.getValue(), operator,
                addressLine, InterestedParty.class);
        }
        return ExpressionFactory.getExpression(se);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search the AgentRepresentative by address line
     */
    public Expression generateSearchExpressionOnAgentAddressLine(String addressLine, HibernateOperatorEnum operator) {

        SearchExpression searchExpression = null;
        if (addressLine != null) {
            searchExpression = new SearchExpression(
                ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT.getValue() + "."
                    + ModelPropertyType.ADDRESS_ADDRESS.getValue() + "." + ModelPropertyType.ADDRESS_ADDRESS.getValue(),
                operator, addressLine, AgentRepresentative.class);
        }
        return ExpressionFactory.getExpression(searchExpression);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search Agent Representative by country/province
     * code
     */
    public Expression generateSearchExpressionOnAgentCountryProvince(String countryProvince,
                                                                     HibernateOperatorEnum operator) {

        SearchExpression searchExpression = null;
        if (null == countryProvince) {
            logger.debug("Invalid country province.");
            throw new SimpleExpressionException("Invalid country province.");
        }

        if (countryProvince.equals(CountryCanadaProvinceEnum.CA.getValue())) {
            searchExpression = new SearchExpression(
                ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT.getValue() + "."
                    + ModelPropertyType.ADDRESS_ADDRESS.getValue() + "."
                    + ModelPropertyType.ADDRESS_COUNTRY_PROVINCE.getValue(),
                HibernateOperatorEnum.IN, CountryCanadaProvinceEnum.getCountryCanadaProvinceEnumList(),
                AgentRepresentative.class);
        } else {

            // contact.address.countryProvince
            searchExpression = new SearchExpression(
                ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT.getValue() + "."
                    + ModelPropertyType.ADDRESS_ADDRESS.getValue() + "."
                    + ModelPropertyType.ADDRESS_COUNTRY_PROVINCE.getValue(),
                operator, countryProvince, AgentRepresentative.class);
        }

        return ExpressionFactory.getExpression(searchExpression);
    }

    /**
     * This method will create a list of Expression to search Applicants
     */
    public List<Expression> generateSearchExpressionOnApplicant() {
        // construct search expression for primary applicant
        SearchExpression searchExpression = new SearchExpression(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE,
            HibernateOperatorEnum.EQUAL, InterestedPartyRelationshipType.OWNER.getValue(), InterestedParty.class);

        List<Expression> expressions = new ArrayList<Expression>();
        expressions.add(ExpressionFactory.getExpression(searchExpression));
        return expressions;
    }

    /**
     * This method will create a list of Expression object to search Opponents
     */
    public List<Expression> generateSearchExpressionOnOpponent() {
        // construct search expression for primary applicant
        SearchExpression searchExpression = new SearchExpression(ModelPropertyType.INTERESTED_PARTY_RELATIONSHIP_TYPE,
            HibernateOperatorEnum.EQUAL, InterestedPartyRelationshipType.OPPONENT.getValue(), InterestedParty.class);

        List<Expression> expressions = new ArrayList<Expression>();
        expressions.add(ExpressionFactory.getExpression(searchExpression));
        return expressions;
    }

    /**
     * This method will create a list of Expression objects to search Legal Entity (Organization) by name
     */
    public List<Expression> generateSearchExpressionOnLegalEntityName(String nameLegalEntity,
                                                                      HibernateOperatorEnum operator) {
        if (null == nameLegalEntity) {
            logger.debug("Invalid Name Legal Entity.");
            throw new SimpleExpressionException("Invalid Name Legal Entity.");
        }

        List<Expression> expressions = new ArrayList<Expression>();

        SearchExpression searchExpression = new SearchExpression(
            ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue() + "." + ModelPropertyType.CONTACT_NAME.getValue(),
            operator, nameLegalEntity, InterestedParty.class);

        expressions.add(ExpressionFactory.getExpression(searchExpression));
        return expressions;
    }

    /**
     * This method will create a list of Expression objects to search Agents by name
     */
    public List<Expression> generateSearchExpressionOnAgentName(String agentName, HibernateOperatorEnum operator) {
        if (null == agentName) {
            logger.debug("Invalid agent name.");
            throw new SimpleExpressionException("Invalid agent name.");
        }

        SearchExpression searchExpression = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT.getValue() + "." + ModelPropertyType.CONTACT_NAME.getValue(),
            operator, agentName, AgentRepresentative.class);

        List<Expression> expressions = new ArrayList<Expression>();
        expressions.add(ExpressionFactory.getExpression(searchExpression));
        return expressions;
    }

    /**
     * This method will create a list of Expression objects to search Agents by name
     */
    public List<Expression> generateSearchExpressionOnAgentNameForIsActiveAgent(String agentName,
                                                                                HibernateOperatorEnum operator) {
        if (!StringUtils.hasText(agentName)) {
            logger.debug("Invalid agent name.");
            throw new SimpleExpressionException("Invalid agent name.");
        }

        List<Expression> arTypeExpressions = new ArrayList<Expression>();
        SearchExpression searchExpressionArType1 = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_AR_TYPE.getValue(), HibernateOperatorEnum.EQUAL, 1,
            AgentRepresentative.class);

        arTypeExpressions.add(ExpressionFactory.getExpression(searchExpressionArType1));

        SearchExpression searchExpressionArType3 = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_AR_TYPE.getValue(), HibernateOperatorEnum.EQUAL, 3,
            AgentRepresentative.class);

        arTypeExpressions.add(ExpressionFactory.getExpression(searchExpressionArType3));

        OrExpression arTypeOrExpression = new OrExpression(arTypeExpressions);

        SearchExpression searchExpressionStatusCode = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_STATUS_CODE.getValue(), HibernateOperatorEnum.EQUAL, 1,
            AgentRepresentative.class);

        List<Expression> allExpressions = new ArrayList<Expression>();
        allExpressions.add(arTypeOrExpression);
        allExpressions.add(ExpressionFactory.getExpression(searchExpressionStatusCode));

        AndExpression andExpression = new AndExpression(allExpressions);
        List<Expression> resultExpressions = new ArrayList<Expression>();
        resultExpressions.add(andExpression);

        return resultExpressions;
    }

    /**
     * This method will create a list of Expression objects to search Agents by name
     */
    public List<Expression> generateSearchExpressionOnAgentNameForGetAgentEmailAddresses(String agentName,
                                                                                         HibernateOperatorEnum operator) {
        if (!StringUtils.hasText(agentName)) {
            logger.debug("Invalid agent name.");
            throw new SimpleExpressionException("Invalid agent name.");
        }

        List<Expression> emailAddressExpressions = new ArrayList<Expression>();
        SearchExpression searchExpression = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT.getValue() + "."
                + ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT_E_MAIL_ADDRESS.getValue(),
            operator, agentName, AgentRepresentative.class);
        emailAddressExpressions.add(ExpressionFactory.getExpression(searchExpression));
        return emailAddressExpressions;
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search Interested Party by phone number
     */
    public Expression generateSearchExpressionOnPhone(String phone, HibernateOperatorEnum operator) {
        if (!StringUtils.hasText(phone)) {
            logger.debug("Invalid phone number.");
            throw new SimpleExpressionException("Invalid phone number.");
        }

        SearchExpression searchExpression = new SearchExpression(ModelPropertyType.INTERESTED_PARTY_CONTACT.getValue()
            + "." + ModelPropertyType.CONTACT_PHONE_NUMBER.getValue(), operator, phone, InterestedParty.class);

        return ExpressionFactory.getExpression(searchExpression);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search Agents by phone number
     */
    public Expression generateSearchExpressionOnAgentPhone(String phone, HibernateOperatorEnum operator) {
        if (!StringUtils.hasText(phone)) {
            logger.debug("Invalid phone number.");
            throw new SimpleExpressionException("Invalid phone number.");
        }

        SearchExpression searchExpression = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_CONTACT.getValue() + "."
                + ModelPropertyType.CONTACT_PHONE_NUMBER.getValue(),
            operator, phone, AgentRepresentative.class);

        return ExpressionFactory.getExpression(searchExpression);
    }

    /**
     * This method will create a Hibernate SimpleExpression object to search Agents by their number
     */
    public Expression generateSearchExpressionOnAgentNumber(Integer agentNumber, HibernateOperatorEnum operator) {
        if (agentNumber == null) {
            logger.debug("Invalid agent number.");
            throw new SimpleExpressionException("Invalid agent number.");
        }

        SearchExpression searchExpression = new SearchExpression(
            ModelPropertyType.AGENT_REPRESENTATIVE_AR_NUMBER.getValue(), HibernateOperatorEnum.EQUAL, agentNumber,
            AgentRepresentative.class);

        return ExpressionFactory.getExpression(searchExpression);
    }

    private Expression makeSearchExpression(ModelPropertyType modelPropertyType, HibernateOperatorEnum operator,
                                            Object value, Class<?> classType) {
        SearchExpression searchExpression = new SearchExpression(modelPropertyType, operator, value, classType);
        return ExpressionFactory.getExpression(searchExpression);
    }
}