package ca.gc.ic.cipo.tm.dao;


import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssociatedMark;

/**
 * The AssociatedMarkDAO is the interface used to retrieve a marks
 * associated with a given application.  
 * 
 * @author Denisj1
 *
 */
public interface AssociatedMarkDao  {

	/**
	 * Retrieve Associated Marks
	 * based on file number and extension counter
	 * @param fileNumber
	 * @param extensionCounter
	 * @return Collection of AssociatedMark Objects
	 */
	public List<AssociatedMark> listAssociatedMarks(Integer fileNumber, Integer extensionCounter);
	
	/**
	 * Retrieve Associated Marks
	 * based on the application number object
	 * @param appNumber
	 * @return Collection of AssociatedMark Objects
	 */
	public List<AssociatedMark> listAssociatedMarks(ApplicationNumber appNumber);
	
	/**
	 * Retrieve Associated Marks to publish
	 * based on file number and extension counter
	 * @param fileNumber
	 * @param extensionCounter
	 * @return Collection of AssociatedMark Objects.
	 */
	public List<AssociatedMark> listAssociatedMarksToPublish(Integer fileNumber, Integer extensionCounter);
	
	/**
	 * Retrieve Associated Marks to publish
	 * based on the application number object
	 * @param appNumber
	 * @return
	 */
	public List<AssociatedMark> listAssociatedMarksToPublish(ApplicationNumber appNumber);
}
