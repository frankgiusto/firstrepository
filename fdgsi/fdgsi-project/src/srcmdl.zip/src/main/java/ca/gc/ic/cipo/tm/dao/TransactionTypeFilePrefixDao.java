package ca.gc.ic.cipo.tm.dao;

import ca.gc.ic.cipo.tm.model.TransactionTypeFilePrefix;

/**
 * Interface for TransactionTypeFilePrefixDao.
 */
public interface TransactionTypeFilePrefixDao {

    /**
     * Retrieve and return the {@link TransactionTypeFilePrefix} from a specified transaction type
     * 
     * @param transactionType the Transaction type
     * @return the TransactionTypeFilePrefix entity object
     */
    public TransactionTypeFilePrefix getTransactionTypeFilePrefix(Integer transactionType);

}
