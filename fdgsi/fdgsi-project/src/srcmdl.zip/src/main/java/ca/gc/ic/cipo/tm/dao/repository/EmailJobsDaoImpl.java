/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.EmailJobsDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.AgentRepresentative;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.EmailJobs;
import ca.gc.ic.cipo.tm.model.EmailJobsId;
import ca.gc.ic.cipo.tm.model.PdfFiles;

/**
 * The EmailJobsDaoImpl retrieves data from the E_MAIL_JOBS Table using Hibernate.
 *
 * @see EmailJobsDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("emailJobsDao")
public class EmailJobsDaoImpl extends HibernateBaseDao implements EmailJobsDao {

    /**
     *
     */
    private static final long serialVersionUID = -4691617875853232153L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(EmailJobsDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(Integer fileNumber, Integer extensionCounter) {
        // TODO Auto-generated method stub
        List<EmailJobs> emailJobs = new ArrayList<EmailJobs>();
        try {
            Criteria criteria = getSession().createCriteria(EmailJobs.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            emailJobs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving email jobs with parameters [" + fileNumber + ", " + extensionCounter + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<EmailJobs>(emailJobs);
    }

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(Integer fileNumber, Integer extensionCounter, Integer emailJobNumber,
                                       Integer arNumber) {
        // TODO Auto-generated method stub
        List<EmailJobs> emailJobs = new ArrayList<EmailJobs>();
        try {
            Criteria criteria = getSession().createCriteria(EmailJobs.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.EMAIL_JOBS_ID_EMAIL_JOB_NUMBER.getValue(), emailJobNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.EMAIL_JOBS_ID_AR_NUMBER.getValue(), arNumber));
            emailJobs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving email jobs with parameters [" + fileNumber + ", " + extensionCounter + ", "
                + emailJobNumber + ", " + arNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<EmailJobs>(emailJobs);
    }

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getEmailJobs(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());

    }

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(Application application) {
        // TODO Auto-generated method stub
        return this.getEmailJobs(new ApplicationNumber(application.getFileNumber(), application.getExtensionCounter()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(ApplicationNumber applicationNumber, Integer emailJobNumber, Integer arNumber) {
        // TODO Auto-generated method stub
        return this.getEmailJobs(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter(),
            emailJobNumber, arNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(Application application, Integer emailJobNumber, Integer arNumber) {
        // TODO Auto-generated method stub
        return this.getEmailJobs(application.getFileNumber(), application.getExtensionCounter(), emailJobNumber,
            arNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<EmailJobs> getEmailJobs(ApplicationNumber applicationNumber, EmailJobsId emailJobsId) {
        // TODO Auto-generated method stub
        return this.getEmailJobs(applicationNumber, emailJobsId.getEmailJobNumber(), emailJobsId.getArNumber());
    }

    // get the list of Agent Representatives
    @Override
    public Set<AgentRepresentative> getAgentRepresentatives(Integer memberOf) {

        String sql =
            // Select all Agent Representatives related to this email.
            "select {ar.*} from agents_reps ar " + "join e_mail_jobs em on em.AR_NUMBER = ar.MEMBER_OF "
                + "where( ar.MEMBER_OF  = :memberOf)";

        logger.debug("Executing SQL statement = " + sql);

        // Set the runtime parameters - memberOf
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.AGENT_REPRESENTATIVE_MEMBER_OF.getValue(), memberOf);

        // Declare the SQL query and attach the entity AgentRepresentative to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("ar", AgentRepresentative.class);
        List<AgentRepresentative> agentRepresentatives = new ArrayList<AgentRepresentative>();
        try {
            agentRepresentatives = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving agent representatives for email jobs with parameters [" + memberOf + "]/n"
                + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AgentRepresentative>(agentRepresentatives);

    }

    // get the PDF Files
    @Override
    public Set<PdfFiles> getPdfFiles(Integer fileNumber, Integer extensionCounter, Integer emailJobNumber) {

        String sql =
            // Select all PDF Files related to this email.
            "select {pf.*} from pdf_files pf " + "join e_mail_jobs em on em.E_MAIL_JOB_NUMBER = pf.E_MAIL_JOB_NUMBER "
                + "join applications app on app.FILE_NUMBER = em.FILE_NUMBER and app.EXTENSION_COUNTER = em.EXTENSION_COUNTER "
                + "where(app.FILE_NUMBER = :fileNumber and app.EXTENSION_COUNTER = :extensionCounter and pf.E_MAIL_JOB_NUMBER  = :emailJobNumber)";

        logger.debug("Executing SQL statement = " + sql);

        // Set the runtime parameters - memberOf
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);
        parameters.put(ModelPropertyType.EMAIL_JOBS_ID_EMAIL_JOB_NUMBER.getValue(), emailJobNumber);

        // Declare the SQL query and attach the entity PdfFiles to
        // it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("pf", PdfFiles.class);
        List<PdfFiles> pdfFiles = new ArrayList<PdfFiles>();
        try {
            pdfFiles = query.list();

        } catch (Exception ex) {
            logger.error("Error retrieving PDF Files for email jobs with parameters  [" + fileNumber + ", "
                + extensionCounter + ", " + emailJobNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<PdfFiles>(pdfFiles);
    }
}
