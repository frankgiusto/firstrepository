/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AssignmentAmendmentWorkSheetFilesDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFilesId;

/**
 * The AAWorkSheetFilesDaoImpl retrieves data from the AA_WORK_SHEET_FILES Table using Hibernate.
 *
 * @see aAWorkSheetFilesDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("aAWorkSheetFilesDao")
public class AssignmentAmendmentWorkSheetFilesDaoImpl extends HibernateBaseDao
    implements AssignmentAmendmentWorkSheetFilesDao {

    /**
     *
     */
    private static final long serialVersionUID = -4179957250188434633L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(AssignmentAmendmentWorkSheetFilesDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                       Integer extensionCounter) {
        // TODO Auto-generated method stub
        List<AssignmentAmendmentWorkSheetFiles> aaWorkSheetFiles = new ArrayList<AssignmentAmendmentWorkSheetFiles>();
        try {
            Criteria criteria = getSession().createCriteria(AssignmentAmendmentWorkSheetFiles.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            aaWorkSheetFiles = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving AA Work Sheet Files with parameters [" + fileNumber + ", " + extensionCounter
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return new HashSet<AssignmentAmendmentWorkSheetFiles>(aaWorkSheetFiles);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                       Integer extensionCounter,
                                                                                       Integer workSheetNumber) {
        // TODO Auto-generated method stub
        List<AssignmentAmendmentWorkSheetFiles> aAworkSheetFiles = new ArrayList<AssignmentAmendmentWorkSheetFiles>();
        try {
            Criteria criteria = getSession().createCriteria(AssignmentAmendmentWorkSheetFiles.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(Restrictions.eq(ModelPropertyType.AA_WORK_SHEET_FILES_WORK_SHEET_ID_NUMBER.getValue(),
                workSheetNumber));

            aAworkSheetFiles = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving assignment amendment worksheet files with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + ", " + workSheetNumber + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }

        return new HashSet<AssignmentAmendmentWorkSheetFiles>(aAworkSheetFiles);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheetFiles(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Application application) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheetFiles(
            new ApplicationNumber(application.getFileNumber(), application.getExtensionCounter()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(ApplicationNumber applicationNumber,
                                                                                       Integer workSheetNumber) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheetFiles(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter(), workSheetNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Application application,
                                                                                       Integer workSheetNumber) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheetFiles(application.getFileNumber(), application.getExtensionCounter(),
            workSheetNumber);
    }

    /** {@inheritDoc} */
    @Override
    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(ApplicationNumber applicationNumber,
                                                                                       AssignmentAmendmentWorkSheetFilesId aaWorkSheetFilesId) {
        // TODO Auto-generated method stub
        return this.getAssignmentAmendmentWorkSheetFiles(applicationNumber, aaWorkSheetFilesId.getWorkSheetNumber());
    }

}
