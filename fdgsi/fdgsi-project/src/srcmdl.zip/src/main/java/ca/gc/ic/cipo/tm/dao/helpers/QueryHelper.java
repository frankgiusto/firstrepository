package ca.gc.ic.cipo.tm.dao.helpers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;

/**
 * Simple utility for queries
 */
public final class QueryHelper {

    private QueryHelper() {
    }

    /**
     * Create and return the parameters map of keys and values. Make sure to align key with the value when passing in
     * the parameter values. Creates a new Map and returns the same to the caller with populate parameters.
     *
     * @param <V1> the parameter key
     * @param <V2> the parameter value
     */
    public static Map<String, Object> fillParameters(List<Pair<String, Object>> params) {
        Map<String, Object> parameters = new HashMap<>();
        if (!CollectionUtils.isEmpty(params)) {
            for (Pair<String, Object> eachPair : params) {
                parameters.put(eachPair.getValue1(), eachPair.getValue2());
            }
        }
        return parameters;
    }

    /**
     * Simple Key pair holder
     *
     * @author SagarY
     *
     * @param <V1> the key
     * @param <V2> the value
     */
    public static class Pair<V1, V2> {

        private V1 v1;

        private V2 v2;

        public Pair(V1 v1, V2 v2) {
            this.v1 = v1;
            this.v2 = v2;
        }

        /** {@inheritDoc} */
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((v1 == null) ? 0 : v1.hashCode());
            result = prime * result + ((v2 == null) ? 0 : v2.hashCode());
            return result;
        }

        /** {@inheritDoc} */
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            Pair<?, ?> other = (Pair<?, ?>) obj;
            if (v1 == null) {
                if (other.v1 != null) {
                    return false;
                }
            } else if (!v1.equals(other.v1)) {
                return false;
            }
            if (v2 == null) {
                if (other.v2 != null) {
                    return false;
                }
            } else if (!v2.equals(other.v2)) {
                return false;
            }
            return true;
        }

        public V1 getValue1() {
            return v1;
        }

        public V2 getValue2() {
            return v2;
        }
    }

    public static class QueryAndParams {

        private final String sqlQuery;

        private final Map<String, Object> paramsMap;

        private final MultiValueMap<String, Object> parameterListMap;

        public QueryAndParams(String sqlQuery, Map<String, Object> paramsMap,
                              MultiValueMap<String, Object> parameterListMap) {
            super();
            this.sqlQuery = sqlQuery;
            this.paramsMap = paramsMap;
            this.parameterListMap = parameterListMap;
        }

        public String getSqlQuery() {
            return sqlQuery;
        }

        public Map<String, Object> getParamsMap() {
            return paramsMap;
        }

        public MultiValueMap<String, Object> getParameterListMap() {
            return parameterListMap;
        }
    }

    /**
     * Updating SQLQuery object in case parameters lists
     *
     * @param parameterListMap the multi value map for parameter lists
     * @param sqlQuery the SQLQuery object
     */
    public static void populateSQLQueryWithParametersListIfApplicable(MultiValueMap<String, Object> parameterListMap,
                                                                      SQLQuery sqlQuery) {
        if (!CollectionUtils.isEmpty(parameterListMap)) {
            for (Map.Entry<String, List<Object>> eachEntry : parameterListMap.entrySet()) {
                sqlQuery.setParameterList(eachEntry.getKey(), eachEntry.getValue());
            }
        }
    }
}
