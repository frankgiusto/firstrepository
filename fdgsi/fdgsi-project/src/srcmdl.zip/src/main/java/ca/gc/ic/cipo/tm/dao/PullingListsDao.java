/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface PullingListsDao {

}
