package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ca.gc.ic.cipo.tm.dao.CountryProvinceLookupDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.enumerator.ReferenceCodeType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.CountryProvince;

/**
 * This CountriesProvincesLookupDAO implementation is used to find meta information related to a country or province
 * based on a code type, a code, and/or language using Hibernate.
 *
 * @see CountryProvinceLookupDao
 * @see HibernateBaseDAO
 *
 * @author DenisJ1
 * @author SeguinA3 - Ported and re-factored from TDRS
 *
 */
@Repository("countryProvinceLookupDao")
@Transactional(readOnly = true)
public class CountryProvinceLookupDaoImpl extends HibernateBaseDao implements CountryProvinceLookupDao {

    private static final long serialVersionUID = -6496290339267639386L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(CountryProvinceLookupDaoImpl.class);

    public CountryProvinceLookupDaoImpl() {
    }

    @Override
    public CountryProvince get(Integer codeType, String code, Integer language) {
        CountryProvince countryProvince = new CountryProvince();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(), codeType));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_CODE.getValue(), code));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_LANGUAGE.getValue(), language));
            countryProvince = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("getCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " There are no Country Province with parameters for [" + codeType + ", " + code + "," + language
                + "]\n" + " - Object = " + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException("getCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + codeType + ", " + code + "," + language + "]/n" + ex.getMessage());
        }

        return countryProvince;
    }

    @Override
    public List<CountryProvince> list(Integer codeType) {
        List<CountryProvince> countryProvinces = new ArrayList<CountryProvince>();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(), codeType));
            countryProvinces = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " There are no list of Country Provinces with parameters for [" + codeType + "]" + " - Object = "
                + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + codeType + "]/n" + ex.getMessage());
        }

        return countryProvinces;

    }

    @Override
    public List<CountryProvince> list(Integer codeType, Integer language) {
        List<CountryProvince> countryProvinces = new ArrayList<CountryProvince>();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(), codeType));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_LANGUAGE.getValue(), language));
            countryProvinces = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " There are no list of Country Provinces with parameters for [" + codeType + language + "]"
                + " - Object = " + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + codeType + language + "]" + ex.getMessage());
        }

        return countryProvinces;
    }

    @Override
    public CountryProvince getCountry(String countryCode, Integer language) {
        CountryProvince countryProvince = new CountryProvince();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_CODE.getValue(), countryCode));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_LANGUAGE.getValue(), language));
            countryProvince = findUniqueByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " There are no Country with parameters for [" + countryCode + language + "]" + " - Object = "
                + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + countryCode + language + "]/n" + ex.getMessage());
        }

        return countryProvince;
    }

    @Override
    public List<CountryProvince> getCountries() {
        List<CountryProvince> countryProvinces = new ArrayList<CountryProvince>();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(),
                ReferenceCodeType.COUNTRY.getValue()));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_COUNTRY_OF_UNION_IND.getValue(),
                Integer.valueOf(1)));
            countryProvinces = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("There are no list of Country Provinces - listCountryCode - Hibernate Session Id = "
                + getSession().hashCode() + "]" + " - Object = " + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException(
                "listCountryCode - Hibernate Session Id = " + getSession().hashCode() + "/n" + ex.getMessage());
        }

        return countryProvinces;
    }

    @Override
    public List<CountryProvince> getCountriesByLanguages(Integer language) {
        List<CountryProvince> countryProvinces = new ArrayList<CountryProvince>();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(),
                ReferenceCodeType.COUNTRY.getValue()));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_LANGUAGE.getValue(), language));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_COUNTRY_OF_UNION_IND.getValue(),
                Integer.valueOf(1)));
            countryProvinces = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " There are no list of Country Provinces with parameters for [" + language + "]" + " - Object = "
                + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + language + "]/n" + ex.getMessage());
        }

        return countryProvinces;
    }

    @Override
    public List<CountryProvince> getProvinces() {
        List<CountryProvince> countryProvinces = new ArrayList<CountryProvince>();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(),
                ReferenceCodeType.PROVINCE.getValue()));
            countryProvinces = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("listCountryCode - Hibernate Session Id = " + getSession().hashCode() + "]" + " - Object = "
                + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException(
                "listCountryCode - Hibernate Session Id = " + getSession().hashCode() + "]/n" + ex.getMessage());
        }

        return countryProvinces;
    }

    @Override
    public List<CountryProvince> getProvincesByLanguages(Integer language) {
        logger.debug("listCountryCode - Hibernate Session Id = " + getSession().hashCode() + " for [" + language + "]"
            + " - Object = " + this.hashCode());
        List<CountryProvince> countryProvinces = new ArrayList<CountryProvince>();
        try {
            Criteria criteria = getSession().createCriteria(CountryProvince.class);
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_TYPE.getValue(),
                ReferenceCodeType.PROVINCE.getValue()));
            criteria.add(Restrictions.eq(ModelPropertyType.COUNTRY_PROVINCE_ID_LANGUAGE.getValue(), language));
            countryProvinces = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " There are no list of Country Provinces by province  for [" + language + "]" + " - Object = "
                + this.hashCode() + ex.getMessage(), ex);
            throw new DataAccessException("listCountryCode - Hibernate Session Id = " + getSession().hashCode()
                + " for [" + language + "]/n" + ex.getMessage());
        }

        return countryProvinces;
    }

}
