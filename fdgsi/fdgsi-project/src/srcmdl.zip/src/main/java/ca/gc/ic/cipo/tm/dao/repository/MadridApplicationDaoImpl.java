/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import ca.gc.ic.cipo.tm.dao.MadridApplicationDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.MadridApplication;

/**
 * @author giustof
 *
 */
@Repository("madridApplicationDao")
public class MadridApplicationDaoImpl extends HibernateBaseDao implements MadridApplicationDao {

    /**
     *
     */
    private static final long serialVersionUID = 8301490304682620800L;

    @Override
    public MadridApplication getMadridApplicationByReferenceNumber(String referenceNumber) {
        if (null == referenceNumber) {
            throw new IllegalArgumentException("invalid parameters. referenceNumber must not be blank.");
        }

        MadridApplication application = null;
        Criteria criteria = getSession().createCriteria(MadridApplication.class);
        criteria.add(
            Restrictions.eq(ModelPropertyType.MADRID_APPLICATIONS_WIPO_REFERENCE_NUMBER.getValue(), referenceNumber));
        try {
            application = findUniqueByCriteria(criteria);
        } catch (HibernateException ex) {
            logger.error("Error retrieving madrid applications by referenceNumber number. Details parameters ["
                + referenceNumber + "] \n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return application;
    }

    @Override
    public List<MadridApplication> getMadridApplicationByIrNumber(String irNumber) {
        if (StringUtils.isEmpty(irNumber)) {
            throw new IllegalArgumentException("Expected valid IR number but was: [ " + irNumber + " ]");
        }

        List<MadridApplication> applications = null;
        Criteria criteria = getSession().createCriteria(MadridApplication.class);
        criteria.add(Restrictions.eq(ModelPropertyType.MADRID_APPLICATIONS_IR_NUMBER.getValue(), irNumber));
        try {
            applications = findByCriteria(criteria);
        } catch (HibernateException ex) {
            logger.error("Error retrieving madrid applications by ir number. Details of parameters [" + irNumber
                + "] \n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return applications;
    }

    @Override
    public void saveMadridApplication(MadridApplication madridApplication) {
        Session session = getSession();
        session.saveOrUpdate(madridApplication);
    }

}
