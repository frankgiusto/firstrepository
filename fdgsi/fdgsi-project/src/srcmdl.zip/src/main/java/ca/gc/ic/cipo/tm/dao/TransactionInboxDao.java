package ca.gc.ic.cipo.tm.dao;

import java.util.List;

import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.FiledTransactionResult;
import ca.gc.ic.cipo.tm.model.TransactionInbox;

/**
 * An interface DAO that manages transaction inbox in trademark database. This is a simple CRUD DAO.
 *
 * @author MengW
 */

public interface TransactionInboxDao {

    /**
     * Return a reference of Transaction Inbox based on the given transaction sequence number.
     *
     * @param transactionSeqNumber The transaction inbox sequence number.
     * @return A TransactionInbox reference.
     */

    public TransactionInbox getTransactionItem(int transactionSeqNumber);

    /**
     * Save the Transaction Inbox with the given information
     *
     * @param transaction inbox information to save or update.
     */
    public void saveTransactionItem(TransactionInbox transaction);

    /**
     * Retrieve and return previously filed transaction for Amendment
     *
     * @param applicationNumberModel the application file number
     * @return the list of type TransactionInbox object
     */
    public List<FiledTransactionResult> retrieveTransactionsForAmendment(ApplicationNumber applicationNumberModel);

    /**
     *
     * @param transactionInboxSequenceNumber
     */
    public void deleteTransactionInbox(Integer transactionInboxSequenceNumber);

    /**
     *
     * @param statusTransactionDetail
     * @return a list of TransactionInbox records
     */
    public List<TransactionInbox> getTransactionByStatusTransactionDetail(String statusTransactionDetail);

}
