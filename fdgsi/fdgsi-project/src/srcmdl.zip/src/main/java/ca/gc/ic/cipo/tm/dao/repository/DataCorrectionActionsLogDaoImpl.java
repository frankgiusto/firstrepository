/**
 *
 */
package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.DataCorrectionActionsLogDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLog;
import ca.gc.ic.cipo.tm.model.DataCorrectionActionsLogId;

/**
 * The DataCorrectionActionsLogDaoImpl retrieves data from the DATA_CORRECTION_ACTIONS_LOG Table using Hibernate.
 *
 * @see DataCorrectionActionsLogDao
 * @see HibernateBaseDAO
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
@Repository("dataCorrectionActionsLogDao")
public class DataCorrectionActionsLogDaoImpl extends HibernateBaseDao implements DataCorrectionActionsLogDao {

    /**
     *
     */
    private static final long serialVersionUID = -5195306159641261822L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(DataCorrectionActionsLogDaoImpl.class);

    /** {@inheritDoc} */
    @Override
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter) {
        // TODO Auto-generated method stub
        List<DataCorrectionActionsLog> dataCorrectionActionsLogs = new ArrayList<DataCorrectionActionsLog>();
        try {
            Criteria criteria = getSession().createCriteria(DataCorrectionActionsLog.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            dataCorrectionActionsLogs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving data correction action logs with parameters [" + fileNumber + ", "
                + extensionCounter + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return new HashSet<DataCorrectionActionsLog>(dataCorrectionActionsLogs);
    }

    /** {@inheritDoc} */
    @Override
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Integer fileNumber, Integer extensionCounter,
                                                                      String dataCorrectionAuthorityId) {
        // TODO Auto-generated method stub
        List<DataCorrectionActionsLog> dataCorrectionActionsLogs = new ArrayList<DataCorrectionActionsLog>();
        try {
            Criteria criteria = getSession().createCriteria(DataCorrectionActionsLog.class);
            criteria.add(Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(
                Restrictions.eq(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter));
            criteria.add(
                Restrictions.eq(ModelPropertyType.DATA_CORRECTION_ACTIONS_LOG_DATA_CORRECTION_AUTHORITY_ID.getValue(),
                    dataCorrectionAuthorityId));

            dataCorrectionActionsLogs = super.findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving data correction action logs with parameters [" + fileNumber + ", "
                + extensionCounter + ", " + ", " + dataCorrectionAuthorityId + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex.getMessage());
        }
        return new HashSet<DataCorrectionActionsLog>(dataCorrectionActionsLogs);
    }

    /** {@inheritDoc} */
    @Override
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(ApplicationNumber applicationNumber) {
        // TODO Auto-generated method stub
        return this.getDataCorrectionActionsLogs(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter());
    }

    /** {@inheritDoc} */
    @Override
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Application application) {
        // TODO Auto-generated method stub
        return this.getDataCorrectionActionsLogs(
            new ApplicationNumber(application.getFileNumber(), application.getExtensionCounter()));
    }

    /** {@inheritDoc} */
    @Override
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(ApplicationNumber applicationNumber,
                                                                      String dataCorrectionAuthorityId) {
        // TODO Auto-generated method stub
        return this.getDataCorrectionActionsLogs(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter(), dataCorrectionAuthorityId);
    }

    /** {@inheritDoc} */
    @Override
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(Application application,
                                                                      String dataCorrectionAuthorityId) {
        // TODO Auto-generated method stub
        return this.getDataCorrectionActionsLogs(application.getFileNumber(), application.getExtensionCounter(),
            dataCorrectionAuthorityId);
    }

    /** {@inheritDoc} */
    @Override
    // TODO not used for now I think, not reviewed
    @Deprecated
    public Set<DataCorrectionActionsLog> getDataCorrectionActionsLogs(ApplicationNumber applicationNumber,
                                                                      DataCorrectionActionsLogId dataCorrectionActionsLogId) {
        // TODO Auto-generated method stub
        return this.getDataCorrectionActionsLogs(applicationNumber,
            dataCorrectionActionsLogId.getDataCorrectionAuthorityId());
    }

}
