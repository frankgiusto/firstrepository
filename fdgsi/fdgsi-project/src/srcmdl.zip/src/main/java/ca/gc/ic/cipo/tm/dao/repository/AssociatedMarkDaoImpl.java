package ca.gc.ic.cipo.tm.dao.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import ca.gc.ic.cipo.tm.dao.AssociatedMarkDao;
import ca.gc.ic.cipo.tm.enumerator.ModelPropertyType;
import ca.gc.ic.cipo.tm.exception.DataAccessException;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssociatedMark;

/**
 * The AssociatedMarkDAOImpl is the Hibernate implementation of the AssociatedMarkDAO. It basically provides API to
 * interact with Associated Marks associated to a given application number.
 *
 * @author Denisj1
 * @author SeguinA3 - Ported and re-factored from TDRS
 *
 */
@Repository("associatedMarkDao")
public class AssociatedMarkDaoImpl extends HibernateBaseDao implements AssociatedMarkDao {

    private static final long serialVersionUID = 5541613993848993742L;

    /** Log4J logger. */
    private static final Logger logger = Logger.getLogger(AssociatedMarkDaoImpl.class);

    @Override
    public List<AssociatedMark> listAssociatedMarks(ApplicationNumber applicationNumber) {
        return this.listAssociatedMarks(applicationNumber.getFileNumber(), applicationNumber.getExtensionCounter());
    }

    @Override
    public List<AssociatedMark> listAssociatedMarks(Integer fileNumber, Integer extensionCounter) {
        logger.trace("listAssociatedMarks - Hibernate Session Id = " + getSession().hashCode() + " for [" + fileNumber
            + "," + extensionCounter + "]" + " - Object = " + this.hashCode());
        List<AssociatedMark> associatedMarks = new ArrayList<AssociatedMark>();
        try {
            Criteria criteria = getSession().createCriteria(AssociatedMark.class);
            criteria.add(
                Restrictions.eq(ModelPropertyType.ASSOCIATED_MARK_ID_ASSOCIATED_FILE_NUMBER.getValue(), fileNumber));
            criteria.add(Restrictions.eq(ModelPropertyType.ASSOCIATED_MARK_ID_ASSOCIATED_EXTENSION_COUNTER.getValue(),
                extensionCounter));
            associatedMarks = findByCriteria(criteria);

        } catch (Exception ex) {
            logger.error("Error retrieving associated marks with parameters [" + fileNumber + ", " + extensionCounter
                + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }
        return associatedMarks;
    }

    @Override
    public List<AssociatedMark> listAssociatedMarksToPublish(ApplicationNumber applicationNumber) {
        return this.listAssociatedMarksToPublish(applicationNumber.getFileNumber(),
            applicationNumber.getExtensionCounter());
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<AssociatedMark> listAssociatedMarksToPublish(Integer fileNumber, Integer extensionCounter) {
        logger.debug("listAssociatedMarksToPublish - Hibernate Session Id = " + getSession().hashCode() + " for ["
            + fileNumber + "," + extensionCounter + "]" + " - Object = " + this.hashCode());

        // IMPORTANT
        // This query has been extracted from the old Cobol dissemination
        // program. Since
        // this query will eventually be deprecated with legislation changes
        // (C-8 and C-31),
        // not a lot of time was spent on trying to optimize it. The only
        // optimization that
        // was done is a single query that returns the result instead of having
        // to process
        // in memory each rows and do some filtering.

        String sql =
            // Select all associated mark related to this application.
            "select {am.*} from associated_marks am "
                + "where ((am.FILE_NUMBER = :fileNumber and am.EXTENSION_COUNTER = :extensionCounter) "
                + "or (am.ASSOCIATED_FILE_NUMBER = :fileNumber and am.ASSOCIATED_EXTENSION_COUNTER = :extensionCounter)) "
                + "minus " +

                // Select all associated marks related to this
                // application that as the following
                // business rules.
                "select {am.*} from associated_marks am "
                + "join applications am_ap on am_ap.file_number = am.ASSOCIATED_FILE_NUMBER and am_ap.EXTENSION_COUNTER = am.ASSOCIATED_EXTENSION_COUNTER "
                + "join applications ap on ap.FILE_NUMBER = am.FILE_NUMBER and ap.EXTENSION_COUNTER = am.EXTENSION_COUNTER "
                + "where (((am.FILE_NUMBER = :fileNumber and am.EXTENSION_COUNTER = :extensionCounter) or (am.ASSOCIATED_FILE_NUMBER = :fileNumber and am.ASSOCIATED_EXTENSION_COUNTER = :extensionCounter)) "
                +

                // Expunged or cancelled
                "and ((am_ap.status_code in (13, 14, 30) or ap.status_code in (13, 14, 30)) " +

                // Inactive Pending and AM Inactive Pending
                "or (ap.status_code in (3, 4, 5, 16, 17, 18, 19, 20, 22, 31, 32) or am_ap.status_code in (3, 4, 5, 16, 17, 18, 19, 20, 22, 31, 32) or "
                + "   (ap.status_code = 15 and ap.section_9_code is null) or (am_ap.status_code = 15 and am_ap.section_9_code is null)) "
                +

                // Active Pending and AM Inactive Registration
                "or ((ap.status_code in (1, 2, 6, 7, 8, 10, 11, 25, 26, 34) or (ap.status_code = 9 and ap.section_9_code is null)) and "
                + "   (am_ap.status_code in (13, 14, 24, 28, 29, 30) or (am_ap.status_code = 15 and am_ap.section_9_code is not null))) "
                +

                // Inactive Registration and AM Active Pending
                "or ((ap.status_code in (13, 14, 24, 28, 29, 30) or (ap.status_code = 15 and ap.section_9_code is not null)) and "
                + "    (am_ap.status_code in (1, 2, 6, 7, 8, 10, 11, 25, 26, 34) or (am_ap.status_code = 9 and am_ap.section_9_code is null))) "
                +

                // Active Registration and AM Active Registration
                "or ((((ap.status_code in (12, 23, 27) or (ap.status_code = 9 and ap.section_9_code is not null)) and "
                + "      (am_ap.status_code in (12, 23, 27) or (am_ap.status_code = 9 and am_ap.section_9_code is not null))) "
                +

                // Active Registration and AM Inactive Registration
                "  or ((ap.status_code in (12, 23, 27) or (ap.status_code = 9 and ap.section_9_code is not null)) and "
                + "      (am_ap.status_code in (13, 14, 24, 28, 29, 30) or (am_ap.status_code = 15 and am_ap.section_9_code is not null))) "
                +

                // Inactive Registration and AM Active Registration
                "  or ((ap.status_code in (13, 14, 24, 28, 29, 30) or (ap.status_code = 15 and ap.section_9_code is not null)) and "
                + "      (am_ap.status_code in (12, 23, 27) or (am_ap.status_code = 9 and am_ap.section_9_code is not null))) "
                +

                // Inactive Registration and AM Inactive Registration
                "  or ((ap.status_code in (13, 14, 24, 28, 29, 30) or (ap.status_code = 15 and ap.section_9_code is not null)) and "
                + "      (am_ap.status_code in (13, 14, 24, 28, 29, 30) or (am_ap.status_code = 15 and am_ap.section_9_code is not null)))) "
                + "  and am.ACTIVE_AT_REGISTRATION_IND = 0)))";

        logger.debug("Executing SQL statement = " + sql);

        // Set the runtime parameters - filenumber and extension.
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_FILE_NUMBER.getValue(), fileNumber);
        parameters.put(ModelPropertyType.APPLICATION_NUMBER_EXTENSION_COUNTER.getValue(), extensionCounter);

        // Declare the SQL query and attach the entity AssociatedMark to it.
        SQLQuery query = (SQLQuery) createSQLQuery(sql, parameters);
        query.addEntity("am", AssociatedMark.class);
        List<AssociatedMark> associatedMarks = new ArrayList<AssociatedMark>();
        try {
            associatedMarks = query.list();
        } catch (Exception ex) {
            logger.error("Error retrieving associated marks to publish with parameters [" + fileNumber + ", "
                + extensionCounter + "]/n" + ex.getMessage(), ex);
            throw new DataAccessException(ex);
        }

        return associatedMarks;
    }
}
