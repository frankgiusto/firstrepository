/**
 *
 */
package ca.gc.ic.cipo.tm.dao;

import java.util.Set;

import ca.gc.ic.cipo.tm.model.Application;
import ca.gc.ic.cipo.tm.model.ApplicationNumber;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFiles;
import ca.gc.ic.cipo.tm.model.AssignmentAmendmentWorkSheetFilesId;

/**
 * @author houreich
 *
 */
// TODO not used for now I think, not reviewed
@Deprecated
public interface AssignmentAmendmentWorkSheetFilesDao {

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                       Integer extensionCounter);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Integer fileNumber,
                                                                                       Integer extensionCounter,
                                                                                       Integer workSheetNumber);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(ApplicationNumber applicationNumber);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Application application);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(ApplicationNumber applicationNumber,
                                                                                       Integer workSheetNumber);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(Application application,
                                                                                       Integer workSheetNumber);

    public Set<AssignmentAmendmentWorkSheetFiles> getAssignmentAmendmentWorkSheetFiles(ApplicationNumber applicationNumber,
                                                                                       AssignmentAmendmentWorkSheetFilesId aaWorkSheetFilesId);

}
