package ca.gc.ic.cipo.tm.type;

public enum OrderByEnum {
	ASCENDING("ASC"), DESCENDING("DESC");
	
	private final String value;

	private OrderByEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public boolean isAscending() {
		return (getValue() == ASCENDING.getValue());
	}
}
